//
//  AppDelegate.h
//  XSLog
//
//  Created by xisi on 2024/6/2.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>


@end

