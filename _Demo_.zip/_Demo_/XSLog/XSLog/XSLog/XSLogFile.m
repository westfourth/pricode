//
//  XSLogFile.m
//  XSLog
//
//  Created by xisi on 2024/6/2.
//

#import "XSLogFile.h"

@implementation XSLogFile

/// 日志目录
+ (NSString *)logDir {
    NSString *docPath = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES).firstObject;
    NSString *dirName = @"XSLog";
    NSString *path = [docPath stringByAppendingPathComponent:dirName];
    BOOL exists = [NSFileManager.defaultManager fileExistsAtPath:path];
    if (exists == NO) {
        NSError *error = nil;
        [NSFileManager.defaultManager createDirectoryAtPath:path withIntermediateDirectories:YES attributes:nil error:&error];
    }
    return path;
}

/// 日志文件列表（非全路径）
+ (NSArray<NSString *> *)logFiles:(XSLogFileType)type {
    NSError *error = nil;
    NSArray<NSString *> *array = [NSFileManager.defaultManager contentsOfDirectoryAtPath:[self logDir] error:&error];
    array = [array sortedArrayUsingComparator:^NSComparisonResult(NSString *str1, NSString *str2) {
        NSComparisonResult result = [str1 compare:str2];
        return result == NSOrderedDescending ? NSOrderedAscending : NSOrderedDescending;
    }];
    NSString *suffix = [self suffixForType:type];
    if (suffix == nil) {
        return array;
    }
    
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"self ENDSWITH $suffix"];
    predicate = [predicate predicateWithSubstitutionVariables:@{@"suffix": suffix}];
    NSArray *filterArray = [array filteredArrayUsingPredicate:predicate];
    return filterArray;
}

/// 获取日志文件全路径
+ (NSString *)logFilePath:(NSString *)filename {
    NSString *path = [[self logDir] stringByAppendingPathComponent:filename];
    return path;
}

/// 删除日志
+ (BOOL)deleteLog:(NSString *)filename {
    NSString *path = [[self logDir] stringByAppendingPathComponent:filename];
    NSError *error = nil;
    BOOL success = [NSFileManager.defaultManager removeItemAtPath:path error:&error];
    return success;
}

/// 删除所有日志
+ (void)deleteAllLogs {
    NSError *error = nil;
    [NSFileManager.defaultManager removeItemAtPath:[self logDir] error:&error];
}


/// 日志文件前缀名，根据时间动态生成
+ (NSString *)filenamePrefix {
    NSDateFormatter *f = [NSDateFormatter new];
    f.dateFormat = @"yyyy-MM-dd_HH.mm.ss_SSSS";
    NSString *s = [f stringFromDate:NSDate.date];
    return s;
}

/// 日志文件后缀名
+ (NSString * _Nullable)suffixForType:(XSLogFileType)type {
    NSString *suffix = nil;
    switch (type) {
        case XSLogFileTypeAll:
            break;
        case XSLogFileTypeDebug:
            suffix = @"debug.log";
            break;
        case XSLogFileTypeFile:
            suffix = @"file.log";;
            break;
        case XSLogFileTypeCrash:
            suffix = @"crash.log";
            break;
        case XSLogFileTypeHTTP:
            suffix = @"http.log";
            break;
        default:
            break;
    }
    return suffix;
}

@end
