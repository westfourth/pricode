//
//  XSLog+HTTP.h
//  XSLog
//
//  Created by xisi on 2024/6/4.
//

#import "XSLog.h"

NS_ASSUME_NONNULL_BEGIN

/// 更新值后，使用`httpLog:`记录更新后的数据
@interface XSHTTPLogModel : NSObject
@property (readonly, nonatomic) NSString *filename;
@property (nullable, nonatomic) NSURLRequest *request;
@property (nullable, nonatomic) NSHTTPURLResponse *response;
@property (nullable, nonatomic) NSData *responseData;
@property (nullable, nonatomic) NSError *responseError;
@end


@interface XSLog (HTTP)

/// 网络日志，该方法的每条信息有单独的文件
+ (void)httpLog:(XSHTTPLogModel *)model;

@end

NS_ASSUME_NONNULL_END
