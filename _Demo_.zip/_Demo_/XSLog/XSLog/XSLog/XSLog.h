//
//  XSLog.h
//  XSLog
//
//  Created by xisi on 2024/6/2.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface XSLog : NSObject

/// 启用
+ (void)enable;

/// 调试日志，该方法的所有信息共用一个文件
+ (void)log:(NSString *)text;

@end

NS_ASSUME_NONNULL_END
