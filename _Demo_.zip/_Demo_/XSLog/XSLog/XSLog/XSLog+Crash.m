//
//  XSLog+Crash.m
//  XSLog
//
//  Created by xisi on 2024/6/4.
//

#import "XSLog+Crash.h"
#import "XSLogFile.h"

static NSUncaughtExceptionHandler *PreUncaughtExceptionHandler = NULL;

@implementation XSLog (Crash)

//  崩溃日志
+ (void)addCrashLog {
    PreUncaughtExceptionHandler = NSGetUncaughtExceptionHandler();
    NSSetUncaughtExceptionHandler(uncaught_exception_handler);
}

static void uncaught_exception_handler(NSException *exception) {
    if (PreUncaughtExceptionHandler != NULL) {
        PreUncaughtExceptionHandler(exception);
    }
    [XSLog logException:exception];
}

+ (void)logException:(NSException *)exception {
    NSString *text = exception.debugDescription;
    NSString *suffix = [XSLogFile suffixForType:XSLogFileTypeCrash];
    NSString *filename = [NSString stringWithFormat:@"%@.%@", [XSLogFile filenamePrefix], suffix];
    
    NSString *path = [XSLogFile logFilePath:filename];
    NSError *error = nil;
    [text writeToFile:path atomically:YES encoding:NSUTF8StringEncoding error:&error];
    NSLog(@">>> Saved Log: %@", path);
}

@end
