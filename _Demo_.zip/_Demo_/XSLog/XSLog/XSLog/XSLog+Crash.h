//
//  XSLog+Crash.h
//  XSLog
//
//  Created by xisi on 2024/6/4.
//

#import "XSLog.h"

NS_ASSUME_NONNULL_BEGIN

/// NSException崩溃日志
@interface XSLog (Crash)

//  崩溃日志
+ (void)addCrashLog;

@end

NS_ASSUME_NONNULL_END
