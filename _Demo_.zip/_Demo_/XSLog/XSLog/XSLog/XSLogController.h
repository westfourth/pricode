//
//  XSLogController.h
//  XSLog
//
//  Created by xisi on 2024/6/2.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

/// Exception日志查看
@interface XSLogController : UITableViewController

@end

NS_ASSUME_NONNULL_END
