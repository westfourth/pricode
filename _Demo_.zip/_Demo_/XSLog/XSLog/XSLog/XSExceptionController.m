//
//  XSExceptionController.m
//  XSExceptionLog
//
//  Created by xisi on 2024/6/2.
//

#import "XSLogController.h"
#import "XSExceptionFile.h"
#import <WebKit/WKWebView.h>

@interface XSLogController ()
@property (nonatomic) NSArray<NSString *> *array;
@property (nonatomic) NSInteger selectedRow;;
@end

@implementation XSLogController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"Exceptions";
    self.array = [XSExceptionFile logFiles];
    self.selectedRow = -1;
    [self.tableView registerClass:UITableViewCell.class forCellReuseIdentifier:@"ID"];
    
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"Close" style:UIBarButtonItemStyleDone target:self action:@selector(closeControlller:)];
}


//MARK: -   TableView

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.array.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    NSString *fileName = self.array[indexPath.row];
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"ID" forIndexPath:indexPath];
    cell.textLabel.text = fileName;
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    self.selectedRow = indexPath.row;
    NSString *fileName = self.array[indexPath.row];
    NSString *path = [XSExceptionFile logFilePath:fileName];
    NSError *error = nil;
    NSString *content = [[NSString alloc] initWithContentsOfFile:path encoding:NSUTF8StringEncoding error:&error];
    
    UITextView *textView = [UITextView new];
    textView.text = content;
    textView.editable = NO;
    
    UIViewController *vc = [UIViewController new];
    vc.title = fileName;
    vc.view = textView;
    vc.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"Copy" style:UIBarButtonItemStyleDone target:self action:@selector(copyText:)];
    [self.navigationController pushViewController:vc animated:YES];
}


//MARK: -   action

- (void)closeControlller:(id)sender {
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)copyText:(id)sender {
    if (self.selectedRow < 0 || self.selectedRow > self.array.count - 1) {
        return;
    }
    NSString *fileName = self.array[self.selectedRow];
    NSString *path = [XSExceptionFile logFilePath:fileName];
    NSError *error = nil;
    NSString *content = [[NSString alloc] initWithContentsOfFile:path encoding:NSUTF8StringEncoding error:&error];
    
    //  alert弹窗
    UIPasteboard.generalPasteboard.string = content;
    [self alertSuccess];
}

//  alert弹窗
- (void)alertSuccess {
    UIAlertController *vc = [UIAlertController alertControllerWithTitle:@"Copy Success" message:nil preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *action = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        
    }];
    [vc addAction:action];
    [self presentViewController:vc animated:YES completion:nil];
}

@end
