//
//  XSLog+File.m
//  XSLog
//
//  Created by xisi on 2024/6/4.
//

#import "XSLog+File.h"
#import "XSLogFile.h"

@implementation XSLog (File)

/// 文件日志，该方法的每条信息有单独的文件
+ (void)fileLog:(NSString *)text {
    NSString *suffix = [XSLogFile suffixForType:XSLogFileTypeFile];
    NSString *filename = [NSString stringWithFormat:@"%@.%@", [XSLogFile filenamePrefix], suffix];
    
    NSString *path = [XSLogFile logFilePath:filename];
    NSError *error = nil;
    [text writeToFile:path atomically:YES encoding:NSUTF8StringEncoding error:&error];
    NSLog(@">>> Saved Log: %@", path);
}

@end
