//
//  XSLog.m
//  XSLog
//
//  Created by xisi on 2024/6/2.
//

#import "XSLog.h"
#import <UIKit/UIKit.h>
#import <objc/runtime.h>
#import "XSLogFile.h"
#import "XSLog+Crash.h"
#import "XSLog+Viewer.h"

@interface XSLog ()
/// 日志文件名
@property (class, nonatomic) NSString *logFilename;
/// 日志文件内容
@property (class, nonatomic) NSMutableString *logContent;
/// 日志格式化
@property (class, nonatomic) NSDateFormatter *logFormatter;
@end

@implementation XSLog

+ (void)enable {
    //  调试日志
    [self addDebugLog];
    //  监听事件，保存调试日志
    [self addDebugObserver];
    //  崩溃日志
    [self addCrashLog];
    //  晃动手机查看日志
    [self addMotion];
}


//MARK: -   调试日志

//  调试日志
+ (void)addDebugLog {
    NSString *suffix = [XSLogFile suffixForType:XSLogFileTypeDebug];
    NSString *filename = [NSString stringWithFormat:@"%@.%@", [XSLogFile filenamePrefix], suffix];
    NSDateFormatter *formatter = [NSDateFormatter new];
    formatter.dateFormat = @"yyyy-MM-dd HH:mm:ss SSSS";
    
    self.logFilename = filename;
    self.logContent = [NSMutableString new];
    self.logFormatter = formatter;
}

/// 调试日志，该方法的所有信息共用一个文件
+ (void)log:(NSString *)text {
    [self.logContent appendString:@"\n"];
    NSString *dateString = [self.logFormatter stringFromDate:NSDate.date];
    [self.logContent appendString:dateString];
    [self.logContent appendString:@"\n"];
    [self.logContent appendString:text];
}

+ (void)saveDebugLog:(NSNotification *)notification {
    if (self.logContent.length == 0) {
        return;
    }
    NSString *filename = self.logFilename;
    NSString *path = [XSLogFile logFilePath:filename];
    NSError *error = nil;
    [self.logContent writeToFile:path atomically:YES encoding:NSUTF8StringEncoding error:&error];
    NSLog(@">>> Saved Log: %@", path);
}

//  监听事件，保存日志
+ (void)addDebugObserver {
    NSArray *list = @[
        XSLogControllerWillPresentNotification,
        UIApplicationWillResignActiveNotification,
        UIApplicationWillTerminateNotification,
    ];
    for (NSString *name in list) {
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(saveDebugLog:) name:name object:nil];
    }
}


//MARK: -   property

+ (NSString *)logFilename {
    return objc_getAssociatedObject(self, @selector(logFilename));
}

+ (void)setLogFilename:(NSString *)logFilename {
    objc_setAssociatedObject(self, @selector(logFilename), logFilename, OBJC_ASSOCIATION_RETAIN);
}

+ (NSMutableString *)logContent {
    return objc_getAssociatedObject(self, @selector(logContent));
}

+ (void)setLogContent:(NSMutableString *)logContent {
    objc_setAssociatedObject(self, @selector(logContent), logContent, OBJC_ASSOCIATION_RETAIN);
}

+ (NSDateFormatter *)logFormatter {
    return objc_getAssociatedObject(self, @selector(logFormatter));
}

+ (void)setLogFormatter:(NSDateFormatter *)logFormatter {
    objc_setAssociatedObject(self, @selector(logFormatter), logFormatter, OBJC_ASSOCIATION_RETAIN);
}

@end
