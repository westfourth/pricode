//
//  XSLogFile.h
//  XSLog
//
//  Created by xisi on 2024/6/2.
//

#import <Foundation/Foundation.h>

typedef NS_ENUM(NSInteger, XSLogFileType) {
    XSLogFileTypeAll,           //  所有日志
    XSLogFileTypeDebug,         //  调试日志
    XSLogFileTypeFile,          //  文件日志
    XSLogFileTypeCrash,         //  崩溃日志
    XSLogFileTypeHTTP,          //  网络日志
};

NS_ASSUME_NONNULL_BEGIN

@interface XSLogFile : NSObject

/// 日志目录
+ (NSString *)logDir;

/// 日志文件列表（非全路径）
+ (NSArray<NSString *> *)logFiles:(XSLogFileType)type;

/// 获取日志文件全路径
+ (NSString *)logFilePath:(NSString *)filename;

/// 删除日志
+ (BOOL)deleteLog:(NSString *)filename;

/// 删除所有日志
+ (void)deleteAllLogs;


/// 日志文件前缀名，根据时间动态生成
+ (NSString *)filenamePrefix;

/// 日志文件后缀名
+ (NSString * _Nullable)suffixForType:(XSLogFileType)type;

@end

NS_ASSUME_NONNULL_END
