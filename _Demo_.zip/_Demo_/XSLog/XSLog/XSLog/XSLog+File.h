//
//  XSLog+File.h
//  XSLog
//
//  Created by xisi on 2024/6/4.
//

#import "XSLog.h"

NS_ASSUME_NONNULL_BEGIN

@interface XSLog (File)

/// 文件日志，该方法的每条信息有单独的文件
+ (void)fileLog:(NSString *)text;

@end

NS_ASSUME_NONNULL_END
