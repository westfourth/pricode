//
//  XSLog+HTTP.m
//  XSLog
//
//  Created by xisi on 2024/6/4.
//

#import "XSLog+HTTP.h"
#import "XSLogFile.h"

@implementation XSHTTPLogModel

- (instancetype)init
{
    self = [super init];
    if (self) {
        NSString *suffix = [XSLogFile suffixForType:XSLogFileTypeHTTP];
        NSString *filename = [NSString stringWithFormat:@"%@.%@", [XSLogFile filenamePrefix], suffix];
        _filename = filename;
    }
    return self;
}

@end


@implementation XSLog (HTTP)

/// 网络日志，该方法的每条信息有单独的文件
+ (void)httpLog:(XSHTTPLogModel *)model {
    NSMutableString *text = [NSMutableString new];
    
    [self text:text addRequest:model.request];
    [self text:text addBodyData:model.request.HTTPBody];
    
    [self text:text addResponseHeader:model.response];
    [self text:text addBodyData:model.responseData];
    [self text:text addResponseError:model.responseError];
    
    NSString *path = [XSLogFile logFilePath:model.filename];
    NSError *error = nil;
    [text writeToFile:path atomically:YES encoding:NSUTF8StringEncoding error:&error];
    NSLog(@">>> Saved Log: %@", path);
}


//MARK: -   Request

+ (void)text:(NSMutableString *)text addRequest:(NSURLRequest * _Nullable)request  {
    if (request == nil) {
        return;
    }
    [text appendString:@"________________________ request ________________________"];
    [text appendString:@"\n"];
    
    NSString *method = request.HTTPMethod;
    if (method.length) {
        [text appendString:method];
        [text appendString:@"  "];
    }
    
    NSString *url = request.URL.absoluteString;
    if (url.length) {
        [text appendString:url];
        [text appendString:@"\n"];
    }
    
    NSString *header = request.allHTTPHeaderFields.debugDescription;
    if (header.length) {
        [text appendString:header];
        [text appendString:@"\n"];
    }
}


//MARK: -   Reponse

+ (void)text:(NSMutableString *)text addResponseHeader:(NSURLResponse * _Nullable)response {
    if (response == nil) {
        return;
    }
    [text appendString:@"________________________ response ________________________"];
    [text appendString:@"\n"];
    
    NSString *header = response.debugDescription;
    if (header.length) {
        [text appendString:header];
        [text appendString:@"\n"];
    }
}

+ (void)text:(NSMutableString *)text addBodyData:(NSData * _Nullable)data {
    if (data == nil) {
        return;
    }
    NSString *body = nil;
    
    NSError *jsonError = nil;
    id json = [NSJSONSerialization JSONObjectWithData:data options:0 error:&jsonError];
    //  json
    if (jsonError == nil) {
        body = [json debugDescription];
    } else {
        body = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
    }
    
    if (body.length) {
        [text appendString:@"\n"];
        [text appendString:body];
        [text appendString:@"\n"];
    }
}

+ (void)text:(NSMutableString *)text addResponseError:(NSError * _Nullable)error {
    if (error == nil) {
        return;
    }
    [text appendString:@"________________________ error ________________________"];
    [text appendString:@"\n"];
    
    NSString *desc = error.debugDescription;
    if (text.length) {
        [text appendString:@"\n"];
        [text appendString:desc];
        [text appendString:@"\n"];
    }
}

@end
