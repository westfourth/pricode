//
//  XSLogController.m
//  XSLog
//
//  Created by xisi on 2024/6/2.
//

#import "XSLogController.h"
#import "XSLogFile.h"
#import <WebKit/WKWebView.h>

@interface XSLogController ()
@property (nonatomic) NSArray<NSString *> *array;
@property (nonatomic) XSLogFileType fileType;
@end

@implementation XSLogController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"Exceptions";
    self.fileType = XSLogFileTypeAll;
    self.array = [XSLogFile logFiles:self.fileType];
    
    [self.tableView registerClass:UITableViewCell.class forCellReuseIdentifier:@"ID"];
    [self setupItems];
}

- (void)setupItems {
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithImage:[UIImage systemImageNamed:@"xmark"] style:UIBarButtonItemStyleDone target:self action:@selector(closeControlller:)];
    UIBarButtonItem *categoryItem = [[UIBarButtonItem alloc] initWithImage:[UIImage systemImageNamed:@"list.bullet.circle.fill"] style:UIBarButtonItemStyleDone target:self action:@selector(chooseLogType:)];
    UIBarButtonItem *deleteItem = [[UIBarButtonItem alloc] initWithImage:[UIImage systemImageNamed:@"trash.fill"] style:UIBarButtonItemStyleDone target:self action:@selector(deleteAllLog:)];
    self.navigationItem.rightBarButtonItems = @[categoryItem, deleteItem];
}

- (void)updateDataAndUI {
    self.array = [XSLogFile logFiles:self.fileType];
    [self.tableView reloadData];
}


//MARK: -   TableView

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.array.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    NSString *filename = self.array[indexPath.row];
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"ID" forIndexPath:indexPath];
    cell.textLabel.text = filename;
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    return cell;
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    NSString *filename = self.array[indexPath.row];
    [XSLogFile deleteLog:filename];
    [self updateDataAndUI];
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    NSString *filename = self.array[indexPath.row];
    NSString *path = [XSLogFile logFilePath:filename];
    NSError *error = nil;
    NSString *content = [[NSString alloc] initWithContentsOfFile:path encoding:NSUTF8StringEncoding error:&error];
    
    UITextView *textView = [UITextView new];
    textView.text = content;
    textView.editable = NO;
    
    UIViewController *vc = [UIViewController new];
    vc.title = filename;
    vc.view = textView;
    vc.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithImage:[UIImage systemImageNamed:@"doc.on.doc.fill"] style:UIBarButtonItemStyleDone target:self action:@selector(copyText:)];
    [self.navigationController pushViewController:vc animated:YES];
}


//MARK: -   BarButtonItem Action

- (void)closeControlller:(UIBarButtonItem *)item {
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)chooseLogType:(UIBarButtonItem *)item {
    __weak typeof (self) weakSelf = self;
    UIAlertController *vc = [UIAlertController alertControllerWithTitle:@"Choose Category" message:nil preferredStyle:UIAlertControllerStyleActionSheet];
    
    NSArray *titles = @[@"All Log", @"Debug Log", @"File Log", @"Crash Log", @"HTTP Log"];
    NSArray *types = @[@(XSLogFileTypeAll), @(XSLogFileTypeDebug), @(XSLogFileTypeFile), @(XSLogFileTypeCrash), @(XSLogFileTypeHTTP)];
    
    for (NSInteger i = 0; i < titles.count; i++) {
        NSString *title = titles[i];
        XSLogFileType type = [types[i] integerValue];
        UIAlertAction *action = [UIAlertAction actionWithTitle:title style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
            weakSelf.fileType = type;
            [weakSelf updateDataAndUI];
        }];
        [vc addAction:action];
    }
    
    UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
        
    }];
    [vc addAction:cancelAction];
    [self presentViewController:vc animated:YES completion:nil];
}

- (void)deleteAllLog:(UIBarButtonItem *)item {
    UIAlertController *vc = [UIAlertController alertControllerWithTitle:nil message:@"Delete All Logs?" preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction *sureAction = [UIAlertAction actionWithTitle:@"Sure" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action) {
        [XSLogFile deleteAllLogs];
        [self updateDataAndUI];
    }];
    UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
        
    }];
    [vc addAction:sureAction];
    [vc addAction:cancelAction];
    [self presentViewController:vc animated:YES completion:nil];
}


//MARK: -   次级页面

- (void)copyText:(UIBarButtonItem *)item {
    UIViewController *topVC = self.navigationController.topViewController;
    UIView *view = topVC.view;
    if ([view isKindOfClass:UITextView.class]) {
        UITextView *textView = (UITextView *)view;
        NSString *content = textView.text;
        UIPasteboard.generalPasteboard.string = content;
        [self alertMessage:@"Copy Success"];
    } else {
        [self alertMessage:@"Copy Failed"];
    }
}

//  alert弹窗
- (void)alertMessage:(NSString *)message {
    UIAlertController *vc = [UIAlertController alertControllerWithTitle:nil message:message preferredStyle:UIAlertControllerStyleAlert];
    [self presentViewController:vc animated:YES completion:^{
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.75 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [vc dismissViewControllerAnimated:YES completion:nil];
        });
    }];
}

@end
