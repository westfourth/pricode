//
//  XSLog+Viewer.m
//  XSLog
//
//  Created by xisi on 2024/6/4.
//

#import "XSLog+Viewer.h"
#import <UIKit/UIKit.h>
#import <objc/runtime.h>
#import "XSLogController.h"

NSString *const XSLogControllerWillPresentNotification = @"XSLogControllerWillPresentNotification";

@implementation XSLog (Viewer)

/// 晃动手机查看日志
+ (void)addMotion {
    Class cls = UIApplication.class;
    SEL sel = @selector(motionBegan:withEvent:);
    Method m = class_getInstanceMethod(cls, sel);
    const char *types = method_getTypeEncoding(m);
    IMP imp0 = method_getImplementation(m);
    IMP imp = imp_implementationWithBlock(^(UIApplication *app, UIEventSubtype motion, UIEvent *event){
        ((void (*)(UIApplication *, SEL, UIEventSubtype, UIEvent *))imp0)(app, sel, motion, event);
        [self app:app motionBegan:motion withEvent:event];
    });
    BOOL success = class_addMethod(cls, sel, imp, types);
    if (!success) {
        method_setImplementation(m, imp);
    }
}

+ (void)app:(UIApplication *)app motionBegan:(UIEventSubtype)motion withEvent:(UIEvent *)event {
    if (motion != UIEventSubtypeMotionShake) {
        return;
    }
    
    //  先保存调试日志
    [NSNotificationCenter.defaultCenter postNotificationName:XSLogControllerWillPresentNotification object:nil];
    
    UIWindow *window = app.keyWindow;
    XSLogController *vc = [XSLogController new];
    UINavigationController *navVC = [[UINavigationController alloc] initWithRootViewController:vc];
    navVC.modalPresentationStyle = UIModalPresentationFullScreen;
    [window.rootViewController presentViewController:navVC animated:YES completion:nil];
}

@end
