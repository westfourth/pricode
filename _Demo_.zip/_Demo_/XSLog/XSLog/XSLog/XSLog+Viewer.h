//
//  XSLog+Viewer.h
//  XSLog
//
//  Created by xisi on 2024/6/4.
//

#import "XSLog.h"

NS_ASSUME_NONNULL_BEGIN

extern NSString *const XSLogControllerWillPresentNotification;

/// 晃动手机查看日志
@interface XSLog (Viewer)

/// 晃动手机查看日志
+ (void)addMotion;

@end

NS_ASSUME_NONNULL_END
