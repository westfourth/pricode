//
//  AppDelegate.m
//  XSLog
//
//  Created by xisi on 2024/6/2.
//

#import "AppDelegate.h"
#import "XSLog.h"

@interface AppDelegate ()

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    puts(NSTemporaryDirectory().UTF8String);
    
    [XSLog enable];
    
    return YES;
}


@end
