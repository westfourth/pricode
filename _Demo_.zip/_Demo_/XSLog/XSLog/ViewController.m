//
//  ViewController.m
//  XSLog
//
//  Created by xisi on 2024/6/2.
//

#import "ViewController.h"
#import "XSLog.h"
#import "XSLog+File.h"
#import "XSLog+HTTP.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = UIColor.redColor;
    
}

- (IBAction)crash:(id)sender {
    NSArray *array = [NSArray new];
    id a = array[1];
}

- (IBAction)file:(id)sender {
    NSDictionary *dict = @{
        @"view": self.view,
        @"color": UIColor.redColor,
        @"viewControlller": self,
    };
    [XSLog fileLog:dict.debugDescription];
}

- (IBAction)debug:(id)sender {
    static int i = 0;
    NSString *text = [NSString stringWithFormat:@"%d", i++];
    [XSLog log:text];
}

- (IBAction)baidu:(id)sender {
    [self request:@"https://www.baidu.com"];
}

- (IBAction)json:(id)sender {
    [self request:@"https://api.itbook.store/1.0/search/mongodb"];
}



- (void)request:(NSString *)urlString {
    NSURL *url = [NSURL URLWithString:urlString];
    NSMutableURLRequest *req = [NSMutableURLRequest requestWithURL:url];
    [req setValue:@"zh-CN,zh-Hans;q=0.9" forHTTPHeaderField:@"Accept-Language"];
    
    XSHTTPLogModel *model = [XSHTTPLogModel new];
    model.request = req;
    [XSLog httpLog:model];
    
    NSURLSessionDataTask *task = [NSURLSession.sharedSession dataTaskWithRequest:req completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
        NSHTTPURLResponse *res = response;
        NSString *text = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
        
        model.response = response;
        model.responseData = data;
        model.responseError = error;
        [XSLog httpLog:model];
        
        puts(__func__);
    }];
    [task resume];
}


@end
