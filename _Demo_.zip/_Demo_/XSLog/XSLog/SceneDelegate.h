//
//  SceneDelegate.h
//  XSLog
//
//  Created by xisi on 2024/6/2.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

