//
//  CViewController.m
//  Transitions
//
//  Created by xisi on 2022/1/18.
//

#import "CViewController.h"

@interface CViewController () 

@end

@implementation CViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

@end
