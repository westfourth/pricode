//
//  NavigateViewController.m
//  Transitions
//
//  Created by xisi on 2022/1/19.
//

#import "NavigateViewController.h"
#import "XSNavigationTransition.h"

@interface NavigateViewController ()

@end

@implementation NavigateViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.layer.contents = (__bridge id)[UIImage imageNamed:@"beauty"].CGImage;
}

//- (void)viewDidAppear:(BOOL)animated {
//    [super viewDidAppear:animated];
//    self.navigationController.interactivePopGestureRecognizer.enabled = NO;
//}
//
//- (void)viewWillDisappear:(BOOL)animated {
//    [super viewWillDisappear:animated];
//    self.navigationController.interactivePopGestureRecognizer.enabled = YES;
//}


@end
