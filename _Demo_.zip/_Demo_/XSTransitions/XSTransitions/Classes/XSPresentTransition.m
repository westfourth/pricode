//
//  XSPresentTransition.m
//  Transitions
//
//  Created by xisi on 2022/1/19.
//

#import "XSPresentTransition.h"

@implementation XSPresentTransition

- (instancetype)init
{
    self = [super init];
    if (self) {
        self.height = [UIScreen mainScreen].bounds.size.height / 2.0;
    }
    return self;
}

- (NSTimeInterval)transitionDuration:(nullable id<UIViewControllerContextTransitioning>)transitionContext {
    return 0.25;
}

- (void)animateTransition:(nonnull id<UIViewControllerContextTransitioning>)transitionContext {
    UIViewController *toVC = [transitionContext viewControllerForKey:UITransitionContextToViewControllerKey];
    UIView *containerView = [transitionContext containerView];
    
    [containerView addSubview:toVC.view];
    //  添加点击手势
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tap:)];
    tap.delegate = self;
    [containerView addGestureRecognizer:tap];
    
    CGRect rect = containerView.frame;
    rect.origin.y = CGRectGetMaxY(rect);
    rect.size.height = self.height;
    toVC.view.frame = rect;
    //
    containerView.backgroundColor = [UIColor clearColor];
    
    NSTimeInterval duration = [self transitionDuration:transitionContext];
    [UIView animateWithDuration:duration animations:^{
        CGRect rect = containerView.frame;
        rect.origin.y = CGRectGetMaxY(rect) - self.height;
        rect.size.height = self.height;
        toVC.view.frame = rect;
        //
        containerView.backgroundColor = [[UIColor blackColor] colorWithAlphaComponent:0.4];
    } completion:^(BOOL finished) {
        BOOL canceled = [transitionContext transitionWasCancelled];
        [transitionContext completeTransition:!canceled];
    }];
}

- (void)tap:(UITapGestureRecognizer *)tap {
    if (self.tapBlank) {
        self.tapBlank();
    }
}

- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldReceiveTouch:(UITouch *)touch {
    return gestureRecognizer.view == touch.view;
}

@end
