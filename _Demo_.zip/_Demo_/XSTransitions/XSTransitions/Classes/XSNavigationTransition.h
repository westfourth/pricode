//
//  XSNavigationTransition.h
//  Transitions
//
//  Created by xisi on 2022/1/19.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface XSNavigationTransition : NSObject <UIViewControllerAnimatedTransitioning>

///  必须为Push、Pop，不然出错
@property (nonatomic) UINavigationControllerOperation operation;


// MARK: -  对UINavigationController的支持

+ (void)navigationController:(UINavigationController *)navVC pan:(UIScreenEdgePanGestureRecognizer *)pan percentTransition:(UIPercentDrivenInteractiveTransition * __strong _Nullable * _Nullable)percentTransition;

@end

NS_ASSUME_NONNULL_END
