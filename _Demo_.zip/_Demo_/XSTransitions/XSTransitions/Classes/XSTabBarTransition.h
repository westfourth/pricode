//
//  XSTabBarTransition.h
//  Transitions
//
//  Created by xisi on 2022/1/19.
//

#import <UIKit/UIKit.h>

/// 手指滑动方向
typedef NS_ENUM(NSUInteger, XSTabBarTransitionDirection) {
    XSTabBarTransitionDirectionRight,       //!<  从左到右；类似Navigagtion.pop
    XSTabBarTransitionDirectionLeft,        //!<  从右到左；类似Navigagtion.push
};

NS_ASSUME_NONNULL_BEGIN

/// UITabbarController左右滚动
@interface XSTabBarTransition : NSObject <UIViewControllerAnimatedTransitioning>

@property (nonatomic) XSTabBarTransitionDirection direction;      //  默认：Right


// MARK: -  对UITabBarController的支持

+ (void)tabBarController:(UITabBarController *)tabBarVC transition:(XSTabBarTransition *)scrollTransition fromViewController:(UIViewController *)fromVC toViewController:(UIViewController *)toVC;

+ (void)tabBarController:(UITabBarController *)tabBarVC  pan:(UIPanGestureRecognizer *)pan percentTransition:(UIPercentDrivenInteractiveTransition * __strong _Nullable * _Nullable)percentTransition completion:(void (^_Nullable)(void))completion;

@end

NS_ASSUME_NONNULL_END
