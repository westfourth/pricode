//
//  XSNavigationTransition.m
//  Transitions
//
//  Created by xisi on 2022/1/19.
//

#import "XSNavigationTransition.h"

@implementation XSNavigationTransition

- (NSTimeInterval)transitionDuration:(nullable id<UIViewControllerContextTransitioning>)transitionContext {
    return 0.25;
}

- (void)animateTransition:(nonnull id<UIViewControllerContextTransitioning>)transitionContext {
    if (self.operation == UINavigationControllerOperationPush) {
        [self animateTransitionPush:transitionContext];
    } else if (self.operation == UINavigationControllerOperationPop) {
        [self animateTransitionPop:transitionContext];
    } else {
        NSAssert(NO, @"不支持该操作：UINavigationControllerOperationNone");
    }
}

//  Push
- (void)animateTransitionPush:(nonnull id<UIViewControllerContextTransitioning>)transitionContext {
    UIViewController *fromVC = [transitionContext viewControllerForKey:UITransitionContextFromViewControllerKey];
    UIViewController *toVC = [transitionContext viewControllerForKey:UITransitionContextToViewControllerKey];
    UIView *containerView = [transitionContext containerView];
    
    [containerView addSubview:toVC.view];
    
    CGRect rect = containerView.bounds;
    toVC.view.transform = CGAffineTransformMakeTranslation(rect.size.width, 0);
    
    NSTimeInterval duration = [self transitionDuration:transitionContext];
    
    [UIView animateWithDuration:duration animations:^{
        toVC.view.transform = CGAffineTransformIdentity;
        fromVC.view.transform = CGAffineTransformMakeTranslation(-rect.size.width / 4.0, 0);
    } completion:^(BOOL finished) {
        toVC.view.transform = CGAffineTransformIdentity;
        fromVC.view.transform = CGAffineTransformIdentity;
        BOOL canceled = [transitionContext transitionWasCancelled];
        [transitionContext completeTransition:!canceled];
    }];
}

//  Pop
- (void)animateTransitionPop:(nonnull id<UIViewControllerContextTransitioning>)transitionContext {
    UIViewController *fromVC = [transitionContext viewControllerForKey:UITransitionContextFromViewControllerKey];
    UIViewController *toVC = [transitionContext viewControllerForKey:UITransitionContextToViewControllerKey];
    UIView *containerView = [transitionContext containerView];
    
    [containerView insertSubview:toVC.view belowSubview:fromVC.view];
    
    CGRect rect = containerView.bounds;
    toVC.view.transform = CGAffineTransformMakeTranslation(-rect.size.width / 4.0, 0);
    
    NSTimeInterval duration = [self transitionDuration:transitionContext];
    [UIView animateWithDuration:duration animations:^{
        toVC.view.transform = CGAffineTransformIdentity;
        fromVC.view.transform = CGAffineTransformMakeTranslation(rect.size.width, 0);
    } completion:^(BOOL finished) {
        toVC.view.transform = CGAffineTransformIdentity;
        fromVC.view.transform = CGAffineTransformIdentity;
        BOOL canceled = [transitionContext transitionWasCancelled];
        [transitionContext completeTransition:!canceled];
    }];
}

// MARK: -  对UINavigationController的支持

+ (void)navigationController:(UINavigationController *)navVC pan:(UIScreenEdgePanGestureRecognizer *)pan percentTransition:(UIPercentDrivenInteractiveTransition * __strong _Nullable * _Nullable)percentTransition {
    CGPoint point = [pan translationInView:pan.view];
    float progress = point.x / pan.view.bounds.size.width;

    if (pan.state == UIGestureRecognizerStateBegan) {
        *percentTransition = [UIPercentDrivenInteractiveTransition new];
        [navVC popViewControllerAnimated:YES];
    } else if (pan.state == UIGestureRecognizerStateChanged) {
        [*percentTransition updateInteractiveTransition:progress];
    } else if (pan.state == UIGestureRecognizerStateEnded ||
               pan.state == UIGestureRecognizerStateCancelled ||
               pan.state == UIGestureRecognizerStateFailed) {
        if (progress > 0.5) {
            [*percentTransition finishInteractiveTransition];
        } else {
            [*percentTransition cancelInteractiveTransition];
        }
        *percentTransition = nil;
    }
}

@end
