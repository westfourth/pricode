//
//  XSAlertTransition.m
//  Transitions
//
//  Created by xisi on 2022/1/19.
//

#import "XSAlertTransition.h"

@implementation XSAlertTransition

- (instancetype)init
{
    self = [super init];
    if (self) {
        self.size = CGSizeMake(270, 124);
    }
    return self;
}

- (NSTimeInterval)transitionDuration:(nullable id<UIViewControllerContextTransitioning>)transitionContext {
    return 0.25;
}

- (void)animateTransition:(nonnull id<UIViewControllerContextTransitioning>)transitionContext {
    if (self.type == XSAlertTransitionTypeShow) {
        [self animateTransitionShow:transitionContext];
    } else {
        [self animateTransitionHide:transitionContext];
    }
}

- (void)animateTransitionShow:(nonnull id<UIViewControllerContextTransitioning>)transitionContext {
    UIViewController *toVC = [transitionContext viewControllerForKey:UITransitionContextToViewControllerKey];
    UIView *containerView = [transitionContext containerView];
    
    [containerView addSubview:toVC.view];
    
    toVC.view.frame = (CGRect){.size = self.size};
    toVC.view.center = containerView.center;
    //
    containerView.backgroundColor = [UIColor clearColor];
    
    NSTimeInterval duration = [self transitionDuration:transitionContext];
    [UIView animateKeyframesWithDuration:duration delay:0 options:0 animations:^{
        containerView.backgroundColor = [[UIColor blackColor] colorWithAlphaComponent:0.4];
        
        [UIView addKeyframeWithRelativeStartTime:0 relativeDuration:0.5 animations:^{
            toVC.view.transform = CGAffineTransformMakeScale(1.1, 1.1);
        }];
        [UIView addKeyframeWithRelativeStartTime:0.5 relativeDuration:0.5 animations:^{
            toVC.view.transform = CGAffineTransformIdentity;
        }];
    } completion:^(BOOL finished) {
        BOOL canceled = [transitionContext transitionWasCancelled];
        [transitionContext completeTransition:!canceled];
    }];
}

- (void)animateTransitionHide:(nonnull id<UIViewControllerContextTransitioning>)transitionContext {
    UIViewController *fromVC = [transitionContext viewControllerForKey:UITransitionContextFromViewControllerKey];
    UIView *containerView = [transitionContext containerView];
    
    //
    containerView.backgroundColor = [[UIColor blackColor] colorWithAlphaComponent:0.4];
    
    NSTimeInterval duration = [self transitionDuration:transitionContext];
    [UIView animateWithDuration:duration animations:^{
        fromVC.view.transform = CGAffineTransformMakeScale(0.8, 0.8);
        fromVC.view.alpha = 0;
        //
        containerView.backgroundColor = [UIColor clearColor];
    } completion:^(BOOL finished) {
        BOOL canceled = [transitionContext transitionWasCancelled];
        [transitionContext completeTransition:!canceled];
    }];
}

@end



// MARK: -  XSAlertTransitionDelegate

@interface XSAlertTransitionDelegate ()
@property (nonatomic) XSAlertTransition *transition;
@end

@implementation XSAlertTransitionDelegate

+ (instancetype)share {
    static id instance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [[self class] new];
    });
    return instance;
}

- (instancetype)init
{
    self = [super init];
    if (self) {
        self.transition = [XSAlertTransition new];
    }
    return self;
}

- (nullable id <UIViewControllerAnimatedTransitioning>)animationControllerForPresentedController:(UIViewController *)presented presentingController:(UIViewController *)presenting sourceController:(UIViewController *)source {
    self.transition.type = XSAlertTransitionTypeShow;
    return self.transition;
}

- (nullable id <UIViewControllerAnimatedTransitioning>)animationControllerForDismissedController:(UIViewController *)dismissed {
    self.transition.type = XSAlertTransitionTypeHide;
    return self.transition;
}

@end
