//
//  XSAlertTransition.h
//  Transitions
//
//  Created by xisi on 2022/1/19.
//

#import <UIKit/UIKit.h>


typedef NS_ENUM(NSUInteger, XSAlertTransitionType) {
    XSAlertTransitionTypeShow,      //!<  Present
    XSAlertTransitionTypeHide,      //!<  Dismiss
};

NS_ASSUME_NONNULL_BEGIN

@interface XSAlertTransition : NSObject <UIViewControllerAnimatedTransitioning>

/// 默认：{270, 124}
@property (nonatomic) CGSize size;

@property (nonatomic) XSAlertTransitionType type;       //!<  默认Show

@end



// MARK: -  XSAlertTransitionDelegate

@interface XSAlertTransitionDelegate : NSObject <UIViewControllerTransitioningDelegate>

+ (instancetype)share;

@end

NS_ASSUME_NONNULL_END
