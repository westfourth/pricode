//
//  XSDismissTransition.m
//  Transitions
//
//  Created by xisi on 2022/1/19.
//

#import "XSDismissTransition.h"

@implementation XSDismissTransition

- (NSTimeInterval)transitionDuration:(nullable id<UIViewControllerContextTransitioning>)transitionContext {
    return 0.25;
}

- (void)animateTransition:(nonnull id<UIViewControllerContextTransitioning>)transitionContext {
    UIViewController *fromVC = [transitionContext viewControllerForKey:UITransitionContextFromViewControllerKey];
    UIView *containerView = [transitionContext containerView];
    
    //
    containerView.backgroundColor = [[UIColor blackColor] colorWithAlphaComponent:0.4];
    
    NSTimeInterval duration = [self transitionDuration:transitionContext];
    [UIView animateWithDuration:duration animations:^{
        CGRect rect = fromVC.view.frame;
        rect.origin.y = CGRectGetMaxY(rect);
        fromVC.view.frame = rect;
        //
        containerView.backgroundColor = [UIColor clearColor];
    } completion:^(BOOL finished) {
        BOOL canceled = [transitionContext transitionWasCancelled];
        [transitionContext completeTransition:!canceled];
    }];
}


// MARK: -  对UITabBarController的支持

+ (void)viewController:(UIViewController *)vc pan:(UIPanGestureRecognizer *)pan percentTransition:(UIPercentDrivenInteractiveTransition * __strong _Nullable * _Nullable)percentTransition {
    
    CGPoint point = [pan translationInView:pan.view];
    float progress = point.y / pan.view.bounds.size.height;

    if (pan.state == UIGestureRecognizerStateBegan) {
        *percentTransition = [UIPercentDrivenInteractiveTransition new];
        [vc dismissViewControllerAnimated:YES completion:nil];
    } else if (pan.state == UIGestureRecognizerStateChanged) {
        [*percentTransition updateInteractiveTransition:progress];
    } else if (pan.state == UIGestureRecognizerStateEnded ||
               pan.state == UIGestureRecognizerStateCancelled ||
               pan.state == UIGestureRecognizerStateFailed) {
        if (progress > 0.5) {
            [*percentTransition finishInteractiveTransition];
        } else {
            [*percentTransition cancelInteractiveTransition];
        }
        *percentTransition = nil;
    }
    
}

@end
