//
//  AppDelegate.h
//  Transitions
//
//  Created by xisi on 2022/1/18.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>


@end

