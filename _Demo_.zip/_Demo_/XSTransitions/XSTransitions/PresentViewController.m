//
//  PresentViewController.m
//  Transitions
//
//  Created by xisi on 2022/1/19.
//

#import "PresentViewController.h"
#import "XSPresentTransition.h"
#import "XSDismissTransition.h"

@interface PresentViewController () <UIViewControllerTransitioningDelegate>
@property (nonatomic) XSPresentTransition *presentTransition;
@property (nullable, nonatomic) UIPercentDrivenInteractiveTransition *percentTransition;
@end

@implementation PresentViewController

- (void)awakeFromNib {
    [super awakeFromNib];
    //  必须为OverFullScreen
    self.modalPresentationStyle = UIModalPresentationOverFullScreen;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.transitioningDelegate = self;
    self.view.layer.cornerRadius = 20;
    //
    UIPanGestureRecognizer *pan = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(handlePan:)];
    [self.view addGestureRecognizer:pan];
}

- (IBAction)clickDismiss:(UIButton *)sender {
    [self dismissViewControllerAnimated:YES completion:nil];
}

//  上下滑动
- (void)handlePan:(UIPanGestureRecognizer *)pan {
    [XSDismissTransition viewController:self pan:pan percentTransition:&_percentTransition];
}

// MARK: -  transition

- (nullable id <UIViewControllerAnimatedTransitioning>)animationControllerForPresentedController:(UIViewController *)presented presentingController:(UIViewController *)presenting sourceController:(UIViewController *)source {
    self.presentTransition = [XSPresentTransition new];
    self.presentTransition.height = 300;
    self.presentTransition.tapBlank = ^{
        puts(__func__);
    };
    return self.presentTransition;
}

- (nullable id <UIViewControllerAnimatedTransitioning>)animationControllerForDismissedController:(UIViewController *)dismissed {
    return [XSDismissTransition new];
}

- (nullable id <UIViewControllerInteractiveTransitioning>)interactionControllerForPresentation:(id <UIViewControllerAnimatedTransitioning>)animator {
    return self.percentTransition;
}

- (nullable id <UIViewControllerInteractiveTransitioning>)interactionControllerForDismissal:(id <UIViewControllerAnimatedTransitioning>)animator {
    puts(__func__);
    return self.percentTransition;
}

@end
