//
//  AViewController.m
//  Transitions
//
//  Created by xisi on 2022/1/18.
//

#import "AViewController.h"
#import "XSTabBarTransition.h"

@interface AViewController () <UITabBarControllerDelegate>
@property (weak, nonatomic) IBOutlet UISegmentedControl *segmentedControl;
@property (nonatomic) XSTabBarTransition *scrollTransition;
@property (nullable, nonatomic) UIPercentDrivenInteractiveTransition *percentTransition;
@end

@implementation AViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.delegate = self;
    self.scrollTransition = [XSTabBarTransition new];
    //
    UIPanGestureRecognizer *pan = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(handlePan:)];
    [self.view addGestureRecognizer:pan];
}

- (IBAction)segmentedControlDidChange:(UISegmentedControl *)sender {
    self.selectedIndex = sender.selectedSegmentIndex;
}

//  左右滑动
- (void)handlePan:(UIPanGestureRecognizer *)pan {
    [XSTabBarTransition tabBarController:self pan:pan percentTransition:&_percentTransition completion:^{
        self.segmentedControl.selectedSegmentIndex = self.selectedIndex;
    }];
}

- (id<UIViewControllerAnimatedTransitioning>)tabBarController:(UITabBarController *)tabBarController animationControllerForTransitionFromViewController:(UIViewController *)fromVC toViewController:(UIViewController *)toVC {
    [XSTabBarTransition tabBarController:self transition:self.scrollTransition fromViewController:fromVC toViewController:toVC];
    return self.scrollTransition;
}

- (id<UIViewControllerInteractiveTransitioning>)tabBarController:(UITabBarController *)tabBarController interactionControllerForAnimationController:(id<UIViewControllerAnimatedTransitioning>)animationController {
    return self.percentTransition;
}

@end
