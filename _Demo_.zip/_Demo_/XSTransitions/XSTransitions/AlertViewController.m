//
//  AlertViewController.m
//  Transitions
//
//  Created by xisi on 2022/1/19.
//

#import "AlertViewController.h"
#import "XSAlertTransition.h"

@interface AlertViewController ()
@end

@implementation AlertViewController

- (void)awakeFromNib {
    [super awakeFromNib];
    //  必须为OverFullScreen
    self.modalPresentationStyle = UIModalPresentationOverFullScreen;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.transitioningDelegate = [XSAlertTransitionDelegate share];
    self.view.layer.cornerRadius = 20;
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    [self dismissViewControllerAnimated:YES completion:nil];
}

@end
