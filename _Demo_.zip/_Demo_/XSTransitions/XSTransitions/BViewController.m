//
//  BViewController.m
//  Transitions
//
//  Created by xisi on 2022/1/18.
//

#import "BViewController.h"
#import "XSNavigationTransition.h"

@interface BViewController () <UINavigationControllerDelegate>
@property (nullable, nonatomic) UIPercentDrivenInteractiveTransition *percentTransition;
@end

@implementation BViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.layer.contents = (__bridge id)[UIImage imageNamed:@"beauty"].CGImage;
    self.navigationController.delegate = self;
    
//    UIScreenEdgePanGestureRecognizer *pan = [[UIScreenEdgePanGestureRecognizer alloc] initWithTarget:self action:@selector(interactivePop:)];
//    pan.edges = UIRectEdgeLeft;
//    [self.navigationController.view addGestureRecognizer:pan];
    
    UIPanGestureRecognizer *pan = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(interactivePop:)];
    [self.navigationController.view addGestureRecognizer:pan];
}

- (void)interactivePop:(UIScreenEdgePanGestureRecognizer *)pan {
    [XSNavigationTransition navigationController:self.navigationController pan:pan percentTransition:&_percentTransition];
}

// MARK: -

- (nullable id <UIViewControllerInteractiveTransitioning>)navigationController:(UINavigationController *)navigationController
                          interactionControllerForAnimationController:(id <UIViewControllerAnimatedTransitioning>) animationController {
    return self.percentTransition;
}

- (nullable id <UIViewControllerAnimatedTransitioning>)navigationController:(UINavigationController *)navigationController
                                   animationControllerForOperation:(UINavigationControllerOperation)operation
                                                fromViewController:(UIViewController *)fromVC
                                                  toViewController:(UIViewController *)toVC {
//    return nil;
    XSNavigationTransition *transition = [XSNavigationTransition new];
    transition.operation = operation;
    return transition;
}

@end
