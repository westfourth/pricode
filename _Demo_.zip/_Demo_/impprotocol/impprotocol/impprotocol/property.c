//
//  property.m
//  Markdown
//
//  Created by hanxin on 2021/12/31.
//

#include "property.h"
#include <string.h>
#include <ctype.h>

static char *strsub(const char *s, char start, char end);
static char* upper_first_letter(const char *name);

/**
    判断property是否只读

    @param  prop    属性
 */
BOOL property_is_readonly(objc_property_t prop) {
    BOOL readonly = NO;
    unsigned int num = 0;
    objc_property_attribute_t *attrs = property_copyAttributeList(prop, &num);
    for (int j = 0; j < num; j++) {
        objc_property_attribute_t attr = attrs[j];
        if (strcmp(attr.name, "R") == 0) {
            readonly = YES;
            break;
        }
    }
    free(attrs);
    return readonly;
}

/**
    判断property是否有对应的ivar

    @param  prop    属性
    @param  cls     类名
 */
BOOL property_has_ivar_in_class(objc_property_t prop, Class cls) {
    const char *name = property_getName(prop);
    //  获取name对应的_name
    size_t len = strlen(name) + 2;
    char _name[len];
    strcpy(_name, "_");
    strcat(_name, name);
    strcat(_name, "\0");
    
    Ivar _ivar = class_getInstanceVariable(cls, _name);
    Ivar ivar = class_getInstanceVariable(cls, name);
    if (_ivar == NULL && ivar == NULL) {
        return NO;
    }
    return YES;
}

/**
    获取property声明的class

    @example 获取 @property (nonatomic) SubTestObject *sub; 结果为：\c SubTestObject
    
    @example 获取 @property (nonatomic) NSString <NSCopying> *name; 结果为：\c NSString
 */
Class property_get_class(objc_property_t prop) {
    char *sub = NULL;
    const char *v = property_copyAttributeValue(prop, "T");
    if (strchr(v, '<')) {       //  T@"NSString<NSCopying>"
        sub = strsub(v, '"', '<');
    } else {                    //  T@"NSString"
        sub = strsub(v, '"', '"');
    }
    Class cls = objc_getClass(sub);
    free(sub);
    free((void *)v);
    return cls;
}

/**
    获取property声明的protocol同名的class

    @example 获取 @property (nonatomic) NSArray<SubTestObject *> <SubTestObject> *list; 结果为：<SubTestObject>中的 \c SubTestObject
    
    @example 获取 @property (nonatomic) NSString <NSCopying> *name; 结果为：\c NSCopying

    @note   因为声明protocol时，这个protocol可能不存在，所以返回与这个protocol同名的class
 */
Class property_get_protocol_class(objc_property_t prop) {
    const char *v = property_copyAttributeValue(prop, "T");
    char *sub = strsub(v, '<', '>');
    Class cls = objc_getClass(sub);
    free(sub);
    free((void *)v);
    return cls;
}

/**
 getter方法名称
 
 @param  prop    属性
 */
SEL property_getter_sel(objc_property_t prop) {
    const char *name = property_getName(prop);
    SEL sel = sel_registerName(name);
    return sel;
}

/**
 setter方法名称
 
 @param  prop    属性
 */
SEL property_setter_sel(objc_property_t prop) {
    const char *name = property_getName(prop);
    char *upperName = upper_first_letter(name);
    
    size_t len = strlen(upperName) + 5;
    char s[len];
    strcpy(s, "set");
    strcat(s, upperName);
    strcat(s, ":");
    
    SEL sel = sel_registerName(s);
    free(upperName);
    return sel;
}

/**
 getter typeEncoding
 
 @param  prop    属性
 
 @note  调用free()释放
 */
const char* property_getter_types(objc_property_t prop) {
    char *propType = property_copyAttributeValue(prop, "T");
    char *s = malloc(sizeof(char) * (strlen(propType) + 3));
    strcpy(s, propType);
    strcat(s, "@:\0");
    free(propType);
    return s;
}

/**
 setter typeEncoding
 
 @param  prop    属性
 
 @note  调用free()释放
 */
const char* property_setter_types(objc_property_t prop) {
    char *propType = property_copyAttributeValue(prop, "T");
    char *s = malloc(sizeof(char) * (strlen(propType) + 4));
    strcpy(s, "v@:");
    strcat(s, propType);
    free(propType);
    return s;
}


//MARK: - static function

/**
    字符串截取

    @param  start       顺序匹配上的第一个字符
    @param  end           倒序匹配上的第一个字符

    @return 子串为排除start、end字符的字符串
 
    @note  调用free()释放
 */
static char *strsub(const char *s, char start, char end) {
    int from = 0, to = 0;
    for (int i = 0; i < strlen(s); i++) {
        if (start == s[i]) {
            from = i;
            break;
        }
    }
    for (int i = (int)strlen(s) - 1; i >= 0; i--) {
        if (end == s[i]) {
            to = i;
            break;
        }
    }
    
    int len = to - from;
    if (len <= 0) {
        return NULL;
    }
    char *sub = malloc(sizeof(char) * len);
    for (int i = from + 1; i < to; i++) {
        sub[i - (from + 1)] = s[i];
    }
    sub[len - 1] = '\0';
    return sub;
}

/**
 首字母大写
 
 @note  调用free()释放
 */
static char* upper_first_letter(const char *name) {
    char *s = malloc(sizeof(char) * (strlen(name) + 1));
    strcpy(s, name);
    strcat(s, "\0");
    s[0] = toupper(s[0]);
    return s;
}
