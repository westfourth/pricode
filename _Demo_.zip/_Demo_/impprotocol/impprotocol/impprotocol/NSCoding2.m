//
//  NSCoding2.m
//  Markdown
//
//  Created by hanxin on 2021/12/20.
//

#import "NSCoding2.h"
#import "property.h"
#import "impprotocol.h"

@impprotocol(NSCoding2)

- (instancetype)initWithCoder:(NSCoder *)coder {
    self = [super init];
    if (self) {
        unsigned int count = 0;
        objc_property_t *props = class_copyPropertyList([self class], &count);
        for (int i = 0; i < count; i++) {
            objc_property_t prop = props[i];

            //  忽略readonly并且没有ivar的属性
            BOOL isReadonly = property_is_readonly(prop);
            BOOL hasIvar = property_has_ivar_in_class(prop, [self class]);
            if (isReadonly && !hasIvar) {
                continue;
            }
            
            const char *name = property_getName(prop);
            NSString *key = @(name);
            NSObject *value = [coder decodeObjectForKey:key];
            if (value) {
                [self setValue:value forKey:key];
            }
        }
        free(props);
    }
    return self;
}

- (void)encodeWithCoder:(NSCoder *)coder {
    unsigned int count = 0;
    objc_property_t *props = class_copyPropertyList([self class], &count);
    for (int i = 0; i < count; i++) {
        objc_property_t prop = props[i];
        
        //  忽略readonly并且没有ivar的属性
        BOOL isReadonly = property_is_readonly(prop);
        BOOL hasIvar = property_has_ivar_in_class(prop, [self class]);
        if (isReadonly && !hasIvar) {
            continue;
        }
        
        const char *name = property_getName(prop);
        NSString *key = @(name);
        NSObject *value = [self valueForKey:key];
        [coder encodeObject:value forKey:key];
    }
    free(props);
}

@end
