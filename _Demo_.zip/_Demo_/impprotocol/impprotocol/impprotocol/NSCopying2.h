//
//  NSCopying.h
//  Markdown
//
//  Created by hanxin on 2021/12/20.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

/**
    不使用 NSCopying 的原因：防止对系统的采用 NSCopying 协议的类产生影响。
 */
@protocol NSCopying2
- (id)copyWithZone:(nullable NSZone *)zone;
@end

NS_ASSUME_NONNULL_END
