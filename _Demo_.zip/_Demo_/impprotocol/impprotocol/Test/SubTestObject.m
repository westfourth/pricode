//
//  SubTestObject.m
//  impprotocol
//
//  Created by hanxin on 2023/12/11.
//

#import "SubTestObject.h"

@implementation SubTestObject

@end
