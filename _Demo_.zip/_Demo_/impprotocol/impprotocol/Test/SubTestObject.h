//
//  SubTestObject.h
//  impprotocol
//
//  Created by hanxin on 2023/12/11.
//

#import <Foundation/Foundation.h>
#import "NSCopying2.h"

NS_ASSUME_NONNULL_BEGIN

@interface SubTestObject : NSObject <NSCopying2>

@property (readonly) NSString *name;
@property NSArray *array;

@end

NS_ASSUME_NONNULL_END
