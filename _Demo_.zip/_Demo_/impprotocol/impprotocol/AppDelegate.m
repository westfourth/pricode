//
//  AppDelegate.m
//  impprotocol
//
//  Created by hanxin on 2023/12/11.
//

#import "AppDelegate.h"
#import <objc/runtime.h>
@protocol ABCD1234;
@class ABCD1234;

@interface AppDelegate ()
@property (nonatomic, readonly) NSString *aaa;
@end

@implementation AppDelegate
@synthesize aaa = aaa;


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    
    Protocol *p = objc_getProtocol("ABCD1234");
    Class cls = objc_getClass("ABCD1234");
    
    return YES;
}


#pragma mark - UISceneSession lifecycle


- (UISceneConfiguration *)application:(UIApplication *)application configurationForConnectingSceneSession:(UISceneSession *)connectingSceneSession options:(UISceneConnectionOptions *)options {
    // Called when a new scene session is being created.
    // Use this method to select a configuration to create the new scene with.
    return [[UISceneConfiguration alloc] initWithName:@"Default Configuration" sessionRole:connectingSceneSession.role];
}


- (void)application:(UIApplication *)application didDiscardSceneSessions:(NSSet<UISceneSession *> *)sceneSessions {
    // Called when the user discards a scene session.
    // If any sessions were discarded while the application was not running, this will be called shortly after application:didFinishLaunchingWithOptions.
    // Use this method to release any resources that were specific to the discarded scenes, as they will not return.
}


@end
