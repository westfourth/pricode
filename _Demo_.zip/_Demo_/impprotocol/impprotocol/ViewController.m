//
//  ViewController.m
//  impprotocol
//
//  Created by hanxin on 2023/12/11.
//

#import "ViewController.h"
#import "SubTestObject.h"
#import <objc/runtime.h>
#import "NSCopying2.h"
#import "NSPlisting.h"
#include "property.h"
@protocol SubTestObject;

@interface ViewController () 
//  T@"NSArray<SubTestObject>",&,N,V_list
//  T@"NSArray",&,N,V_list
@property (nonatomic) NSArray<SubTestObject *> <SubTestObject> *list;
@end

@implementation ViewController


- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
//    [self printProps];
    
    [self testSubTestObject];
}

- (void)testSubTestObject {
    SubTestObject *t = [SubTestObject new];
    t.array = [NSMutableArray arrayWithArray:@[@"AAA", @"BBB"]];
    [t setValue:@"Tom" forKey:@"name"];
    
    SubTestObject *t2 = [t copy];
    puts(__func__);
}


//MARK: -   print

- (void)printProtolMethods {
    Protocol *proto = @protocol(NSPlisting);
    unsigned int count = 0;
    struct objc_method_description *descs = protocol_copyMethodDescriptionList(proto, YES, YES, &count);
    for (int j = 0; j < count; j++) {
        struct objc_method_description desc = descs[j];
        puts(desc.name);
    }
    free(descs);
}

- (void)printClassMethods {
    Class cls = objc_getClass("NSPlisting_NSObject");
    unsigned int count = 0;
    Method *ms = class_copyMethodList(cls, &count);
    for (int i = 0; i < count; i++) {
        Method m = ms[i];
        SEL sel = method_getName(m);
        const char *name = sel_getName(sel);
        puts(name);
    }
}

- (void)printProps {
    unsigned int count = 0;
    objc_property_t *props = class_copyPropertyList([self class], &count);
    for (int i = 0; i < count; i++) {
        objc_property_t prop = props[i];
        
        SEL sel = property_getter_sel(prop);
        SEL sel2 = property_setter_sel(prop);
        
        const char *types = property_getAttributes(prop);
        puts(types);
        [self printPropAttrs:prop];
    }
    free(props);
}

- (void)printPropAttrs:(objc_property_t)prop {
    unsigned int count = 0;
    objc_property_attribute_t *attrs = property_copyAttributeList(prop, &count);
    for (int i = 0; i < count; i++) {
        objc_property_attribute_t attr = attrs[i];
        printf("%s: %s\n", attr.name, attr.value);
    }
    free(attrs);
}


@end
