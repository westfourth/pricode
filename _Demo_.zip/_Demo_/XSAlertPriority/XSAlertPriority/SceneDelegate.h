//
//  SceneDelegate.h
//  XSAlertPriority
//
//  Created by xisi on 2022/6/2.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

