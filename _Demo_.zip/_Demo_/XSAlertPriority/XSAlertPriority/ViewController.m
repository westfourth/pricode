//
//  ViewController.m
//  XSAlertPriority
//
//  Created by xisi on 2022/6/2.
//

#import "ViewController.h"
#import "MBProgressHUD.h"
#import "MBProgressHUD+Priority.h"
#import "TestView.h"
#import <objc/runtime.h>

@interface ViewController ()
@property (weak, nonatomic) IBOutlet UISlider *slider1;
@property (weak, nonatomic) IBOutlet UISlider *slider2;
@property (weak, nonatomic) IBOutlet UISlider *slider3;

@property (weak, nonatomic) IBOutlet UILabel *label1;
@property (weak, nonatomic) IBOutlet UILabel *label2;
@property (weak, nonatomic) IBOutlet UILabel *label3;

@property (weak, nonatomic) IBOutlet UISwitch *switch1;
@property (weak, nonatomic) IBOutlet UISwitch *switch2;
@property (weak, nonatomic) IBOutlet UISwitch *switch3;

@property (nonatomic) NSInteger flag;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.flag = 1;
}

- (IBAction)sliderDidChange:(UISlider *)slider {
    UILabel *label = [self labelWithTag:slider.tag];
    label.text = [NSString stringWithFormat:@"%ld", (NSInteger)slider.value];
}

- (UILabel *)labelWithTag:(NSInteger)tag {
    if (tag == 1) {
        return self.label1;
    } else if (tag == 2) {
        return self.label2;
    } else if (tag == 3) {
        return self.label3;
    } else {
        return nil;
    }
}

- (IBAction)show:(id)sender {
    if (self.flag == 1) {
        MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
        hud.backgroundColor = [UIColor redColor];
        hud.alertPriority = self.slider1.value;
        hud.removedWhenLowerPriority = self.switch1.on;
    } else if (self.flag == 2) {
        MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
        hud.backgroundColor = [UIColor greenColor];
        hud.alertPriority = self.slider2.value;
        hud.removedWhenLowerPriority = self.switch2.on;
    } else if (self.flag == 3) {
        MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
        hud.backgroundColor = [UIColor blueColor];
        hud.alertPriority = self.slider3.value;
        hud.removedWhenLowerPriority = self.switch3.on;
    } else {
        [self showAlertVC];
    }
    self.flag++;
}

- (void)showAlertVC {
    __weak typeof(self) weakSelf = self;
    UIAlertController *vc = [UIAlertController alertControllerWithTitle:@"重新开始" message:@"已弹窗三次，是否重新开始" preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *cancel = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action) {
        
    }];
    UIAlertAction *sure = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action) {
        weakSelf.flag = 1;
        //  移除所有hud
        MBProgressHUD *hud = nil;
        do {
            hud = [MBProgressHUD HUDForView:self.view];
            [MBProgressHUD hideHUDForView:self.view animated:NO];
        } while (hud != nil);
    }];
    [vc addAction:cancel];
    [vc addAction:sure];
    [self presentViewController:vc animated:YES completion:nil];
}

- (IBAction)hide:(id)sender {
    [MBProgressHUD hideHUDForView:self.view animated:YES];
    if (self.flag > 1) {
        self.flag--;
    }
}


@end
