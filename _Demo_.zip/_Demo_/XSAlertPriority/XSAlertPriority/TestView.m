//
//  TestView.m
//  XSAlertPriority
//
//  Created by xisi on 2022/6/2.
//

#import "TestView.h"

@implementation TestView

- (void)dealloc {
    puts(__func__);
}

@end
