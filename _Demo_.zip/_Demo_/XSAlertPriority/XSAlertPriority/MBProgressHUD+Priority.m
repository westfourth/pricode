//
//  MBProgressHUD+Priority.m
//  XSAlertPriority
//
//  Created by xisi on 2022/6/2.
//

#import "MBProgressHUD+Priority.h"

@implementation MBProgressHUD (Priority)

@end
