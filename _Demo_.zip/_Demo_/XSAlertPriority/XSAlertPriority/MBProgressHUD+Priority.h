//
//  MBProgressHUD+Priority.h
//  XSAlertPriority
//
//  Created by xisi on 2022/6/2.
//

#import <MBProgressHUD/MBProgressHUD.h>
#import "XSAlertPriority.h"

NS_ASSUME_NONNULL_BEGIN

//  只要采用 XSAlertPriority 协议即可，程序会自动实现协议里面的方法。
@interface MBProgressHUD (Priority) <XSAlertPriority>

@end

NS_ASSUME_NONNULL_END
