//
//  AppDelegate.h
//  XSAlertPriority
//
//  Created by xisi on 2022/6/2.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>


@end

