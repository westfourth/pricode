//
//  XSRefreshHeader.h
//  XSRefresh
//
//  Created by xisi on 2022/1/15.
//

#import <UIKit/UIKit.h>
#import "XSRefresh.h"

NS_ASSUME_NONNULL_BEGIN

@interface XSRefreshDemoHeader : UIView <XSRefresh>

@property (nonatomic) UILabel *label;

@end

NS_ASSUME_NONNULL_END
