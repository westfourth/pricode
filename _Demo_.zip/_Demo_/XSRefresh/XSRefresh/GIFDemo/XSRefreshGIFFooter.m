//
//  XSRefreshGIFFooter.m
//  XSRefresh
//
//  Created by xisi on 2022/1/16.
//

#import "XSRefreshGIFFooter.h"
#import "UIImage+XSGIF.h"

@implementation XSRefreshGIFFooter

- (void)awakeFromNib {
    [super awakeFromNib];
    self.image = [UIImage gifImageNamed:@"loading2.gif"];
}

//  MARK: - XSRefresh

- (void)beginRefreshing {
    self.imageView.image = self.image;
}

- (void)endRefreshing {
    self.imageView.image = nil;
}

- (void)dragDidBeganWithExtent:(CGFloat)extent {
    printf(">>> Began %f%%\n", extent);
    float process = [self getProcess:extent];
    self.imageView.image = self.image.images.firstObject;
}

- (void)dragDidChangedWithExtent:(CGFloat)extent {
//    printf(">>> Changed %f%%\n", extent);
    float process = [self getProcess:extent];
    long index = self.image.images.count * process;
    index = MIN(index, self.image.images.count - 1);
    self.imageView.image = self.image.images[index];
}

- (void)dragDidEndedWithExtent:(CGFloat)extent {
    printf(">>> Ended %f%%\n", extent);
    float process = [self getProcess:extent];
    self.imageView.image = self.image.images.firstObject;
}

- (float)getProcess:(CGFloat)extent {
    float process = extent * 1.0 / [[self class] refreshExtent];
    process = MIN(process, 1);
    process = MAX(process, 0);
    return process;
}

+ (CGFloat)height {
    return 80;
}

+ (CGFloat)refreshExtent {
    return 100;
}

@end
