//
//  XSRefreshGIFViewController.m
//  XSRefresh
//
//  Created by xisi on 2022/1/16.
//

#import "XSRefreshGIFViewController.h"
#import "UIScrollView+XSRefresh.h"
#import "XSRefreshGIFHeader.h"
#import "UIImage+XSGIF.h"

@interface XSRefreshGIFViewController ()
@property (nonatomic) NSMutableArray *array;
@end

@implementation XSRefreshGIFViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationController.toolbarHidden = NO;
    
    [UIScrollView registerClassOrNib:[XSRefreshGIFHeader class] forType:XSRefreshViewTypeHeader];
    UINib *nib = [UINib nibWithNibName:@"XSRefreshGIFFooter" bundle:nil];
    [UIScrollView registerClassOrNib:nib forType:XSRefreshViewTypeFooter];
    
    self.array = [NSMutableArray new];
    for (int i = 0; i < 10; i++) {
        [self.array addObject:@(i)];
    }
    
//    XSRefreshGIFHeader *footer = [XSRefreshGIFHeader new];
//    footer.image = [UIImage gifImageNamed:@"loading2.gif"];
//    self.tableView.refreshFooter = footer;
    
//    self.tableView.refreshAnimated = YES;
    
    [self setupRefreshBlock];
}

- (void)setupRefreshBlock {
    __weak typeof (self) weakSelf = self;
    self.tableView.refreshHeaderBlock = ^{
        NSLog(@">>> 刷新顶部数据");
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            weakSelf.array = [NSMutableArray new];
            for (int i = 0; i < 10; i++) {
                [weakSelf.array addObject:@(i)];
            }
            [weakSelf.tableView endRefreshHeader];
            [weakSelf.tableView reloadData];
        });
    };
    self.tableView.refreshFooterBlock = ^{
        NSLog(@">>> 刷新底部数据");
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            for (int i = 0; i < 10; i++) {
                [weakSelf.array addObject:@(i)];
            }
            [weakSelf.tableView endRefreshFooter];
            [weakSelf.tableView reloadData];
        });
    };
}

- (IBAction)beginRefreshHeader:(id)sender {
    [self.tableView beginRefreshHeader];
}

- (IBAction)endRefreshHeader:(id)sender {
    [self.tableView endRefreshHeader];
}

- (IBAction)beginRefreshFooter:(id)sender {
    [self.tableView beginRefreshFooter];
}

- (IBAction)endRefreshFooter:(id)sender {
    [self.tableView endRefreshFooter];
}

#pragma mark - Table view data source


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.array.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"ID" forIndexPath:indexPath];
    cell.textLabel.text = [NSString stringWithFormat:@"row - %ld", (long)indexPath.row];
    if (indexPath.row % 2 == 0) {
        cell.backgroundColor = [[UIColor redColor] colorWithAlphaComponent:0.05];
    } else {
        cell.backgroundColor = [[UIColor greenColor] colorWithAlphaComponent:0.05];
    }
    return cell;
}


@end
