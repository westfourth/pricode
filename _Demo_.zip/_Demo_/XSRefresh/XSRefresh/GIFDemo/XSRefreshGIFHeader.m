//
//  XSRefreshGIFHeader.m
//  XSRefresh
//
//  Created by xisi on 2022/1/16.
//

#import "XSRefreshGIFHeader.h"
#import "UIImage+XSGIF.h"

@implementation XSRefreshGIFHeader

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = [UIColor whiteColor];
        self.imageView = [UIImageView new];
        [self addSubview:self.imageView];
        self.image = [UIImage gifImageNamed:@"loading1.gif"];
    }
    return self;
}

- (void)layoutSubviews {
    [super layoutSubviews];
    CGFloat heihgt = [[self class] height] * 2.5;
    CGFloat width = self.image.size.width / self.image.size.height * heihgt;
    CGFloat x = (self.bounds.size.width - width) / 2.0;
    CGFloat y = (self.bounds.size.height - heihgt) / 2.0;
    self.imageView.frame = CGRectMake(x, y, width, heihgt);
}

//  MARK: - XSRefresh

- (void)beginRefreshing {
    self.imageView.image = self.image;
}

- (void)endRefreshing {
    self.imageView.image = nil;
}

- (void)dragDidBeganWithExtent:(CGFloat)extent {
    printf(">>> Began %f%%\n", extent);
    float process = [self getProcess:extent];
    self.imageView.image = self.image.images.firstObject;
}

- (void)dragDidChangedWithExtent:(CGFloat)extent {
//    printf(">>> Changed %f%%\n", extent);
    float process = [self getProcess:extent];
    long index = self.image.images.count * process;
    index = MIN(index, self.image.images.count - 1);
    self.imageView.image = self.image.images[index];
}

- (void)dragDidEndedWithExtent:(CGFloat)extent {
    printf(">>> Ended %f%%\n", extent);
    float process = [self getProcess:extent];
    self.imageView.image = self.image.images.firstObject;
}

- (float)getProcess:(CGFloat)extent {
    float process = extent * 1.0 / [[self class] refreshExtent];
    process = MIN(process, 1);
    process = MAX(process, 0);
    return process;
}

+ (CGFloat)height {
    return 80;
}

+ (CGFloat)refreshExtent {
    return 100;
}

@end
