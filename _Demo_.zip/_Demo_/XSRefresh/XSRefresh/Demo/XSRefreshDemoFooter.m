//
//  XSRefreshDemoFooter.m
//  XSRefresh
//
//  Created by xisi on 2022/1/15.
//

#import "XSRefreshDemoFooter.h"

@implementation XSRefreshDemoFooter

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = [UIColor greenColor];
        self.label = [UILabel new];
        [self addSubview:self.label];
        self.label.textAlignment = NSTextAlignmentCenter;
    }
    return self;
}

- (void)layoutSubviews {
    [super layoutSubviews];
    self.label.frame = self.bounds;
}

//  MARK: - XSRefresh

- (void)beginRefreshing {
    puts(__func__);
}

- (void)endRefreshing {
    puts(__func__);
}

- (void)dragDidBeganWithExtent:(CGFloat)extent {
    printf(">>> Began %f\n", extent);
    int process = extent * 1.0 / [[self class] refreshExtent] * 100;
    self.label.text = [NSString stringWithFormat:@"开始  %d%%", process];
    //
}

- (void)dragDidChangedWithExtent:(CGFloat)extent {
//    printf(">>> Changed %f\n", extent);
    int process = extent * 1.0 / [[self class] refreshExtent] * 100;
    self.label.text = [NSString stringWithFormat:@"变化  %d%%", process];
    //
}

- (void)dragDidEndedWithExtent:(CGFloat)extent {
    printf(">>> Ended %f\n", extent);
    int process = extent * 1.0 / [[self class] refreshExtent] * 100;
    self.label.text = [NSString stringWithFormat:@"结束  %d%%", process];
}

+ (CGFloat)height {
    return 80;
}

+ (CGFloat)refreshExtent {
    return 100;
}

@end
