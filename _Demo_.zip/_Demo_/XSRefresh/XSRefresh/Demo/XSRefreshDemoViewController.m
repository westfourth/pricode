//
//  XSRefreshDemoViewController.m
//  XSRefresh
//
//  Created by xisi on 2022/1/15.
//

#import "XSRefreshDemoViewController.h"
#import "UIScrollView+XSRefresh.h"
#import "XSRefreshDemoHeader.h"
#import "XSRefreshDemoFooter.h"

@interface XSRefreshDemoViewController ()
@property (weak, nonatomic) IBOutlet UIScrollView *scrollView;

@property (weak, nonatomic) IBOutlet NSLayoutConstraint *bigHeight;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *smallHeight;

@end

@implementation XSRefreshDemoViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationController.toolbarHidden = NO;
    
    [UIScrollView registerClassOrNib:[XSRefreshDemoHeader class] forType:XSRefreshViewTypeHeader];
    [UIScrollView registerClassOrNib:[XSRefreshDemoFooter class] forType:XSRefreshViewTypeFooter];
    
    self.scrollView.alwaysBounceVertical = YES;
    self.scrollView.refreshAnimated = YES;
    
    self.scrollView.refreshHeaderBlock = ^{
        NSLog(@">>> 刷新顶部数据");
    };
    self.scrollView.refreshFooterBlock = ^{
        NSLog(@">>> 刷新底部数据");
    };
}


- (IBAction)beginRefreshHeader:(id)sender {
    [self.scrollView beginRefreshHeader];
}

- (IBAction)endRefreshHeader:(id)sender {
    [self.scrollView endRefreshHeader];
}

- (IBAction)beginRefreshFooter:(id)sender {
    [self.scrollView beginRefreshFooter];
}

- (IBAction)endRefreshFooter:(id)sender {
    [self.scrollView endRefreshFooter];
}

- (IBAction)clickChangeImage:(UIBarButtonItem *)sender {
    if ([sender.title isEqualToString:@"小图"]) {
        self.bigHeight.active = NO;
        self.smallHeight.active = YES;
        sender.title = @"大图";
    } else {
        self.bigHeight.active = YES;
        self.smallHeight.active = NO;
        sender.title = @"小图";
    }
}

@end
