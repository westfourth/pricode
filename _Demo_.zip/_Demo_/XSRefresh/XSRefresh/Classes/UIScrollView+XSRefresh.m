//
//  UIScrollView+XSRefresh.m
//  XSRefresh
//
//  Created by xisi on 2022/1/15.
//

#import "UIScrollView+XSRefresh.h"
#import <objc/runtime.h>

typedef NS_ENUM(NSUInteger, XSRefreshActionType) {
    XSRefreshActionTypeBegin,       //!<
    XSRefreshActionTypeEnd,         //!<
};

@implementation UIScrollView (XSRefresh)

//  MARK: - load

+ (void)load {
    [self refresh_load_handlePan];
    [self refresh_load_layoutSubviews];
}

+ (void)refresh_load_layoutSubviews {
    SEL sel = @selector(layoutSubviews);
    for (Class cls in @[[UIScrollView class], [UITableView class], [UICollectionView class]]) {
        Method m = class_getInstanceMethod(cls, sel);
        IMP imp0 = method_getImplementation(m);
        IMP imp1 = imp_implementationWithBlock(^void(__kindof UIScrollView *self){
            ((void (*)(__kindof UIScrollView*, SEL))imp0)(self, sel);
            [self refresh_override_layoutSubviews];
        });
        method_setImplementation(m, imp1);
    }
}

+ (void)refresh_load_handlePan {
    Class cls = [UIScrollView class];
    SEL sel = sel_registerName("handlePan:");
    Method m = class_getInstanceMethod(cls, sel);
    IMP imp0 = method_getImplementation(m);
    IMP imp1 = imp_implementationWithBlock(^void(UIScrollView *self, UIPanGestureRecognizer *pan){
        ((void (*)(UIScrollView*, SEL, UIPanGestureRecognizer*))imp0)(self, sel, pan);
        [self refresh_override_handlePan:pan];
    });
    method_setImplementation(m, imp1);
}


// MARK: -  override

/// 对 layoutSubviews 方法扩充
- (void)refresh_override_layoutSubviews {
    if (self.refreshHeader) {
        CGFloat height = [[self.refreshHeader class] height];
        self.refreshHeader.frame = CGRectMake(0, -height, self.bounds.size.width, height);
        [self sendSubviewToBack:self.refreshHeader];
    }
    if (self.refreshFooter) {
        CGFloat height = [[self.refreshFooter class] height];
        self.refreshFooter.frame = CGRectMake(0, self.contentSize.height, self.bounds.size.width, height);
        [self sendSubviewToBack:self.refreshFooter];
    }
}

/// 对 handlePan: 方法补充
- (void)refresh_override_handlePan:(UIPanGestureRecognizer *)pan {
    CGFloat topExtent = -(self.contentOffset.y + self.adjustedContentInset.top);
    CGFloat bottomExtent = 0;
    if (self.contentSize.height <= self.bounds.size.height) {
        bottomExtent = self.contentOffset.y + self.adjustedContentInset.top;
    } else {
        bottomExtent = self.contentOffset.y + self.bounds.size.height - self.contentSize.height - self.adjustedContentInset.bottom;
    }
    
    [self refresh_drag:pan view:self.refreshHeader extent:topExtent];
    [self refresh_drag:pan view:self.refreshFooter extent:bottomExtent];
}

- (void)refresh_drag:(UIPanGestureRecognizer *)pan view:(UIView<XSRefresh> *)view extent:(CGFloat)extent {
    if (view == nil) {
        return;
    }
    
    if (pan.state == UIGestureRecognizerStateBegan) {
        [view dragDidBeganWithExtent:extent];
    } else if (pan.state == UIGestureRecognizerStateChanged) {
        [view dragDidChangedWithExtent:extent];
    } else if (pan.state == UIGestureRecognizerStateEnded ||
               pan.state == UIGestureRecognizerStateCancelled ||
               pan.state == UIGestureRecognizerStateFailed) {
        [view dragDidEndedWithExtent:extent];
        
        if (extent >= [[view class] refreshExtent]) {
            if (view == self.refreshHeader) {
                [self beginRefreshHeader];
            } else {
                [self beginRefreshFooter];
            }
        }
    }
}


//  MARK: - register

+ (void)registerClassOrNib:(id)classOrNib forType:(XSRefreshViewType)type {
    objc_setAssociatedObject(self, [UIScrollView classOrNibKeyforType:type], classOrNib, OBJC_ASSOCIATION_RETAIN);
}

+ (id)classOrNibforType:(XSRefreshViewType)type {
    return objc_getAssociatedObject(self, [UIScrollView classOrNibKeyforType:type]);
}

/**
    key 所在的内存地址必须一致。以下就不行：
    @code
        const void *key = [NSString stringWithFormat:@"UIScrollView+XSRefresh-%ld", type].UTF8String;
    @endcode
    因为每次调用，key的地址不一样。
 */
+ (const void *)classOrNibKeyforType:(XSRefreshViewType)type {
    NSString *key = [NSString stringWithFormat:@"UIScrollView+XSRefresh-%ld", type];
    SEL sel = sel_getUid(key.UTF8String);
    return sel;
}

+ (UIView<XSRefresh> *)initViewforType:(XSRefreshViewType)type {
    UIView<XSRefresh> *view = nil;
    id classOrNib = [UIScrollView classOrNibforType:type];
    if (object_isClass(classOrNib)) {
        Class cls = classOrNib;
        view = [cls new];
    } else if ([classOrNib isKindOfClass:[UINib class]]) {
        UINib *nib = classOrNib;
        view = [nib instantiateWithOwner:nil options:nil].firstObject;
    }
    return view;
}


//  MARK: - property

- (__kindof UIView<XSRefresh> *)refreshHeader {
    return objc_getAssociatedObject(self, @selector(refreshHeader));
}

- (void)setRefreshHeader:(__kindof UIView<XSRefresh> *)refreshHeader {
    [self addSubview:refreshHeader];
    objc_setAssociatedObject(self, @selector(refreshHeader), refreshHeader, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
}

- (__kindof UIView<XSRefresh> *)refreshFooter {
    return objc_getAssociatedObject(self, @selector(refreshFooter));
}

- (void)setRefreshFooter:(__kindof UIView<XSRefresh> *)refreshFooter {
    [self addSubview:refreshFooter];
    objc_setAssociatedObject(self, @selector(refreshFooter), refreshFooter, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
}

//

- (void (^)(void))refreshHeaderBlock {
    return objc_getAssociatedObject(self, @selector(refreshHeaderBlock));
}

- (void)setRefreshHeaderBlock:(void (^)(void))refreshHeaderBlock {
    if (self.refreshHeader == nil) {
        self.refreshHeader = [UIScrollView initViewforType:XSRefreshViewTypeHeader];
    }
    objc_setAssociatedObject(self, @selector(refreshHeaderBlock), refreshHeaderBlock, OBJC_ASSOCIATION_COPY_NONATOMIC);
}

- (void (^)(void))refreshFooterBlock {
    return objc_getAssociatedObject(self, @selector(refreshFooterBlock));
}

- (void)setRefreshFooterBlock:(void (^)(void))refreshFooterBlock {
    if (self.refreshFooter == nil) {
        self.refreshFooter = [UIScrollView initViewforType:XSRefreshViewTypeFooter];
    }
    objc_setAssociatedObject(self, @selector(refreshFooterBlock), refreshFooterBlock, OBJC_ASSOCIATION_COPY_NONATOMIC);
}

//

- (BOOL)refreshAnimated {
    return [objc_getAssociatedObject(self, @selector(refreshAnimated)) boolValue];
}

- (void)setRefreshAnimated:(BOOL)refreshAnimated {
    objc_setAssociatedObject(self, @selector(refreshAnimated), @(refreshAnimated), OBJC_ASSOCIATION_ASSIGN);
}

- (BOOL)headerIsRefreshing {
    return [objc_getAssociatedObject(self, @selector(headerIsRefreshing)) boolValue];
}

- (void)setHeaderIsRefreshing:(BOOL)headerIsRefreshing {
    objc_setAssociatedObject(self, @selector(headerIsRefreshing), @(headerIsRefreshing), OBJC_ASSOCIATION_ASSIGN);
}

- (BOOL)footerIsRefreshing {
    return [objc_getAssociatedObject(self, @selector(footerIsRefreshing)) boolValue];
}

- (void)setFooterIsRefreshing:(BOOL)footerIsRefreshing {
    objc_setAssociatedObject(self, @selector(footerIsRefreshing), @(footerIsRefreshing), OBJC_ASSOCIATION_ASSIGN);
}


//  MARK: - refresh

- (void)beginRefreshHeader {
    if (self.headerIsRefreshing == YES) {
        return;
    }
    self.headerIsRefreshing = YES;
    [self.refreshHeader beginRefreshing];
    [self refreshHeaderWithActionType:XSRefreshActionTypeBegin];
    //
    if (self.refreshHeaderBlock) {
        self.refreshHeaderBlock();
    }
}

- (void)endRefreshHeader {
    if (self.headerIsRefreshing == NO) {
        return;
    }
    self.headerIsRefreshing = NO;
    [self.refreshHeader endRefreshing];
    [self refreshHeaderWithActionType:XSRefreshActionTypeEnd];
}

- (void)refreshHeaderWithActionType:(XSRefreshActionType)type {
    UIEdgeInsets inset = self.contentInset;
    if (type == XSRefreshActionTypeBegin) {
        inset.top += [[self.refreshHeader class] refreshExtent];
    } else {
        inset.top -= [[self.refreshHeader class] refreshExtent];
    }
    
    [UIView animateWithDuration:0.25 animations:^{
        self.contentInset = inset;
        if (self.refreshAnimated) {
            CGFloat offsetY = self.adjustedContentInset.top;
            self.contentOffset = CGPointMake(0, -offsetY);
        }
    }];
}

- (void)beginRefreshFooter {
    if (self.footerIsRefreshing == YES) {
        return;
    }
    self.footerIsRefreshing = YES;
    [self.refreshFooter beginRefreshing];
    [self refreshFooterWithActionType:XSRefreshActionTypeBegin];
    //
    if (self.refreshFooterBlock) {
        self.refreshFooterBlock();
    }
}

- (void)endRefreshFooter {
    if (self.footerIsRefreshing == NO) {
        return;
    }
    self.footerIsRefreshing = NO;
    [self.refreshFooter endRefreshing];
    [self refreshFooterWithActionType:XSRefreshActionTypeEnd];
}

- (void)refreshFooterWithActionType:(XSRefreshActionType)type {
    UIEdgeInsets inset = self.contentInset;
    //  不注释，会导致偏移
//    if (type == XSRefreshActionTypeBegin) {
//        inset.bottom += [[self.refreshFooter class] refreshExtent];
//    } else {
//        inset.bottom -= [[self.refreshFooter class] refreshExtent];
//    }
    
    [UIView animateWithDuration:0.25 animations:^{
        self.contentInset = inset;
        if (self.refreshAnimated) {
            CGFloat offsetY = 0;
            if (self.contentSize.height <= self.bounds.size.height) {
                offsetY = self.adjustedContentInset.bottom;
            } else {
                offsetY = self.contentSize.height - self.bounds.size.height +  self.adjustedContentInset.bottom;
            }
            self.contentOffset = CGPointMake(0, offsetY);
        }
    }];
}

@end
