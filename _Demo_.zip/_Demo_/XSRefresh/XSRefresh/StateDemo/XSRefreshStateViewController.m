//
//  XSRefreshStateViewController.m
//  XSRefresh
//
//  Created by xisi on 2022/1/16.
//

#import "XSRefreshStateViewController.h"
#import "XSRefreshStateCell.h"
#import "UIScrollView+XSRefresh.h"
#import "XSRefreshGIFHeader.h"

@interface XSRefreshStateViewController ()
@property (nonatomic) NSMutableArray *array;
@end

@implementation XSRefreshStateViewController

static NSString * const reuseIdentifier = @"Cell";

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationController.toolbarHidden = NO;
    
    XSRefreshGIFHeader *footer = [XSRefreshGIFHeader new];
    self.collectionView.refreshFooter = footer;
    
    self.array = [NSMutableArray new];
    for (int i = 0; i < 10; i++) {
        [self.array addObject:@(i)];
    }
    
    UICollectionViewFlowLayout *layout = (UICollectionViewFlowLayout *)self.collectionViewLayout;
    int column = 3;
    CGFloat width = (self.view.bounds.size.width - (column - 1) * layout.minimumInteritemSpacing) / column;
    layout.itemSize = CGSizeMake(width, width);
    
    [self setupRefreshBlock];
}

- (void)setupRefreshBlock {
    __weak typeof (self) weakSelf = self;
    self.collectionView.refreshHeaderBlock = ^{
        NSLog(@">>> 刷新顶部数据");
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            weakSelf.array = [NSMutableArray new];
            for (int i = 0; i < 10; i++) {
                [weakSelf.array addObject:@(i)];
            }
            [weakSelf.collectionView endRefreshHeader];
            [weakSelf.collectionView reloadData];
        });
    };
    self.collectionView.refreshFooterBlock = ^{
        NSLog(@">>> 刷新底部数据");
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            for (int i = 0; i < 10; i++) {
                [weakSelf.array addObject:@(i)];
            }
            [weakSelf.collectionView endRefreshFooter];
            [weakSelf.collectionView reloadData];
        });
    };
}

- (IBAction)beginRefreshHeader:(id)sender {
    [self.collectionView beginRefreshHeader];
}

- (IBAction)endRefreshHeader:(id)sender {
    [self.collectionView endRefreshHeader];
}

- (IBAction)beginRefreshFooter:(id)sender {
    [self.collectionView beginRefreshFooter];
}

- (IBAction)endRefreshFooter:(id)sender {
    [self.collectionView endRefreshFooter];
}

#pragma mark - data source

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return self.array.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    XSRefreshStateCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:reuseIdentifier forIndexPath:indexPath];
    cell.label.text = [NSString stringWithFormat:@"%ld", (long)indexPath.row];
    return cell;
}

@end
