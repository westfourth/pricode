//
//  XSRefreshStateCell.m
//  XSRefresh
//
//  Created by xisi on 2022/1/16.
//

#import "XSRefreshStateCell.h"

@implementation XSRefreshStateCell

- (void)awakeFromNib {
    [super awakeFromNib];
}

@end
