//
//  M3u8Pather.m
//  M3u8Downloader
//
//  Created by xisi on 2023/2/13.
//

#import "M3u8DefaultPather.h"

@implementation M3u8DefaultPather
@synthesize videoDir = _videoDir;

- (instancetype)init {
    self = [super init];
    if (self) {
        self.videoDir = NSTemporaryDirectory();
    }
    return self;
}

/// 该m3u8视频目录路径
- (NSString *)dirForM3u8:(NSURL *)m3u8Url {
    NSURL *url2 = [m3u8Url URLByDeletingLastPathComponent];
    NSString *dirName;
    if (self.absoluteMode == NO) {
        dirName = url2.lastPathComponent;
    } else {
        dirName = url2.path;
        if ([dirName hasPrefix:@"/"]) {
            dirName = [dirName substringFromIndex:1];
        }
        dirName = [dirName stringByReplacingOccurrencesOfString:@"/" withString:@"\\"];
    }
    
    NSString *dirPath = [self.videoDir stringByAppendingPathComponent:dirName];
    BOOL exist = [NSFileManager.defaultManager fileExistsAtPath:dirPath];
    if (!exist) {
        NSError *error = nil;
        [NSFileManager.defaultManager createDirectoryAtPath:dirPath withIntermediateDirectories:YES attributes:nil error:&error];
    }
    return dirPath;
}

/// m3u8文件对应的路径
- (NSString *)pathForM3u8:(NSURL *)m3u8Url {
    NSString *fileName = m3u8Url.lastPathComponent;
    NSString *filePath = [[self dirForM3u8:m3u8Url] stringByAppendingPathComponent:fileName];
    return filePath;
}

/// ts文件对应的路径
- (NSString *)pathForTs:(NSURL *)tsUrl m3u8:(NSURL *)m3u8Url {
    NSString *fileName = tsUrl.lastPathComponent;
    NSString *filePath = [[self dirForM3u8:m3u8Url] stringByAppendingPathComponent:fileName];
    return filePath;
}

/// key文件对应的路径
- (NSString *)pathForKey:(NSURL *)keyUrl m3u8:(NSURL *)m3u8Url {
    NSString *fileName = keyUrl.lastPathComponent;
    NSString *filePath = [[self dirForM3u8:m3u8Url] stringByAppendingPathComponent:fileName];
    return filePath;
}

/// .complete文件对应的路径。当下载完m3u8、ts后才会生成此文件。
- (NSString *)pathForComplete:(NSURL *)m3u8Url {
    NSString *fileName = @".completed";
    NSString *filePath = [[self dirForM3u8:m3u8Url] stringByAppendingPathComponent:fileName];
    return filePath;
}


//MARK: -   optional

/// mp4文件对应的路径
- (NSString *)pathForMp4:(NSURL *)m3u8Url {
    NSString *fileName = m3u8Url.lastPathComponent;
    fileName = [fileName stringByDeletingPathExtension];
    fileName = [fileName stringByAppendingPathExtension:@"mp4"];
    NSString *filePath = [[self dirForM3u8:m3u8Url] stringByAppendingPathComponent:fileName];
    return filePath;
}

@end
