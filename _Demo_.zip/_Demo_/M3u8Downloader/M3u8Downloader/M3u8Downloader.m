//
//  M3u8Downloader.m
//  M3u8Downloader
//
//  Created by xisi on 2023/2/13.
//

#import "M3u8Downloader.h"
#import "M3u8DefaultPather.h"
#import "M3u8DefaultParser.h"

static void m3u8_printf(const char *format, ...) {
    BOOL enabled = M3u8Downloader.shared.logEnabled;
    if (!enabled) return;
    va_list args;
    va_start(args, format);
    va_end(args);
    vprintf(format, args);
}


@interface M3u8Downloader ()
@property (nonatomic) NSLock *lock;     //  性能瓶颈在网络，只用一个锁影响甚微
@property (nonatomic) dispatch_queue_t queue;
@end


@implementation M3u8Downloader

+ (instancetype)shared {
    static id instance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [[self class] new];
    });
    return instance;
}

- (instancetype)init
{
    self = [super init];
    if (self) {
        self.lock = [NSLock new];
        self.queue = dispatch_get_global_queue(0, 0);
        
        self.session = [NSURLSession sharedSession];
        self.maxConcurrent = 10;
        _pendings = [NSMutableArray new];
        _downloadings = [NSMutableArray new];
        
        self.pather = [M3u8DefaultPather new];
        self.parser = [M3u8DefaultParser new];
    }
    return self;
}

//  下载视频
- (void)download:(M3u8MuItem *)muItem {
    dispatch_async(self.queue, ^{
        //  视频已下载完成
        if ([self status:muItem] == M3u8ItemStatusDownloaded) {
            m3u8_printf("%s %s\n", ">>> 已存在: ", muItem.url.absoluteString.UTF8String);
            return;
        }
        
        if (self.downloadings.count >= self.maxConcurrent) {
            //  加入到pendings队列
            [self.lock lock];
            if (![self.pendings containsObject:muItem]) {
                [self.pendings addObject:muItem];
            }
            [self.lock unlock];
        } else {
            //  加入到downloadings队列
            [self.lock lock];
            if (![self.downloadings containsObject:muItem]) {
                [self.downloadings addObject:muItem];
            }
            [self.lock unlock];
            //  下载
            [self downloadItem:muItem];
        }
    });
}

//  取消下载视频
- (void)cancel:(M3u8MuItem *)muItem {
    //  从downloadings队列中移除
    [self.lock lock];
    [self.downloadings removeObject:muItem];
    [self.lock unlock];
}

//  下载后续的视频
- (void)downloadNext {
    if (self.pendings.count) {
        M3u8MuItem *first = self.pendings.firstObject;
        [self.lock lock];
        [self.pendings removeObject:first];
        [self.lock unlock];
        //  下载
        [self download:first];
    }
}

//  下载
- (void)downloadItem:(M3u8Item *)item {
    //  已取消
    if (![self.downloadings containsObject:item.muItem]) {
        //  下载后续的视频
        [self downloadNext];
        return;
    }
    
    //  将要请求
    [self willDownload:item];
    
    /*================ 本地 ================*/
    if ([self itemIsDownloaded:item]) {
        [self didDownload:item];
        return;
    }
    
    /*================ 远程 ================*/
    NSURL *url = item.url;
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url];
    if (self.httper && [self.httper respondsToSelector:@selector(willRequest:)]) {
        [self.httper willRequest:request];
    }
    
    NSURLSessionDownloadTask *task = [self.session downloadTaskWithRequest:request completionHandler:^(NSURL * _Nullable location, NSURLResponse * _Nullable response, NSError * _Nullable error) {     //  非主线程
        //  收到响应
        if (self.httper && [self.httper respondsToSelector:@selector(didResponse:error:)]) {
            [self.httper didResponse:response error:error];
        }
        
        if (error) {
            //  从downloadings队列中移除
            [self.lock lock];
            [self.downloadings removeObject:item.muItem];
            [self.lock unlock];
            //  下载后续的视频
            [self downloadNext];
            return;
        }
        
        //  移动文件
        [self moveFile:location item:item];
        
        [self didDownload:item];
    }];
    [task resume];
}

//  将要请求
- (void)willDownload:(M3u8Item *)item {
    if ([item isKindOfClass:M3u8MuItem.class]) {
        [self willDownloadM3u8:(M3u8MuItem *)item];
    } else if ([item isKindOfClass:M3u8TsItem.class]) {
        [self willDownloadTs:(M3u8TsItem *)item];
    } else if ([item isKindOfClass:M3u8KeyItem.class]) {
        [self willDownloadKey:(M3u8KeyItem *)item];
    }
}

//  收到响应
- (void)didDownload:(M3u8Item *)item {
    if ([item isKindOfClass:M3u8MuItem.class]) {
        [self didDownloadM3u8:(M3u8MuItem *)item];
    } else if ([item isKindOfClass:M3u8TsItem.class]) {
        [self didDownloadTs:(M3u8TsItem *)item];
    }else if ([item isKindOfClass:M3u8KeyItem.class]) {
        [self didDownloadKey:(M3u8KeyItem *)item];
    }
}


//MARK: -   生命周期

//  m3u8将要请求
- (void)willDownloadM3u8:(M3u8MuItem *)muItem {
    m3u8_printf("%s\n%s\n", __func__, muItem.url.absoluteString.UTF8String);
}

//  m3u8收到响应
- (void)didDownloadM3u8:(M3u8MuItem *)muItem {
    m3u8_printf("%s\n%s\n", __func__, muItem.url.absoluteString.UTF8String);
    
    //  解析
    NSString *path = [self.pather pathForM3u8:muItem.url];
    NSError *error = nil;
    NSString *content = [NSString stringWithContentsOfFile:path encoding:NSUTF8StringEncoding error:&error];
    
    if (self.filter && [self.filter respondsToSelector:@selector(filterContent:)]) {
        content = [self.filter filterContent:content];
        NSError *error = nil;
        [content writeToFile:path atomically:YES encoding:NSUTF8StringEncoding error:&error];
    }
    
    [self.parser parse:muItem content:content];
    
    if (muItem.keyItem) {
        //  下载key
        [self downloadItem:muItem.keyItem];
    } else {
        //  下载第一个ts
        [self.lock lock];
        muItem.downloaded = 0;
        [self.lock unlock];
        if (muItem.tsItems.count > 0) {
            [self downloadItem:muItem.tsItems[muItem.downloaded]];
        } else {
            //  从downloadings队列中移除
            [self.lock lock];
            [self.downloadings removeObject:muItem];
            [self.lock unlock];
            //  下载后续的视频
            [self downloadNext];
        }
    }
}

//  ts将要请求
- (void)willDownloadTs:(M3u8TsItem *)tsItem {
    m3u8_printf("%s\n%s\n", __func__, tsItem.url.absoluteString.UTF8String);
}

//  ts收到响应
- (void)didDownloadTs:(M3u8TsItem *)tsItem {
    m3u8_printf("%s\n%s\n", __func__, tsItem.url.absoluteString.UTF8String);
    M3u8MuItem *muItem = tsItem.muItem;
    
    [self.lock lock];
    muItem.downloaded++;
    [self.lock unlock];
    if (muItem.tsItems.count > 0) {
        if (muItem.downloaded < muItem.tsItems.count) {         //  ts未全部下载完成
            //  主线程回调
            if (muItem.progress) {
                dispatch_async(dispatch_get_main_queue(), ^{
                    muItem.progress(muItem.downloaded, muItem.tsItems.count);
                });
            }
            
            //  下载后续的ts
            [self downloadItem:muItem.tsItems[muItem.downloaded]];
        } else if (muItem.downloaded == muItem.tsItems.count) { //  所有ts下载完成
            //  从downloadings队列中移除
            [self.lock lock];
            [self.downloadings removeObject:muItem];
            [self.lock unlock];
            
            //  生成.completed文件
            [self createCompletedFile:muItem];
            //  主线程回调
            if (muItem.completion) {
                dispatch_async(dispatch_get_main_queue(), ^{
                    muItem.completion(YES, nil);
                });
            }
            //  下载后续的视频
            [self downloadNext];
        }
    }
}

//  key将要请求
- (void)willDownloadKey:(M3u8KeyItem *)keyItem {
    m3u8_printf("%s\n%s\n", __func__, keyItem.url.absoluteString.UTF8String);
}

//  key收到响应
- (void)didDownloadKey:(M3u8KeyItem *)keyItem {
    m3u8_printf("%s\n%s\n", __func__, keyItem.url.absoluteString.UTF8String);
    M3u8MuItem *muItem = keyItem.muItem;
    
    //  下载第一个ts
    [self.lock lock];
    muItem.downloaded = 0;
    [self.lock unlock];
    if (muItem.tsItems.count > 0) {
        [self downloadItem:muItem.tsItems[muItem.downloaded]];
    } else {
        //  从downloadings队列中移除
        [self.lock lock];
        [self.downloadings removeObject:muItem];
        [self.lock unlock];
        //  下载后续的视频
        [self downloadNext];
    }
}


//MARK: -   状态获取

//  是否已经下载完毕
- (BOOL)itemIsDownloaded:(M3u8Item *)item {
    NSString *dstPath = nil;
    if ([item isKindOfClass:M3u8MuItem.class]) {            //  m3u8文件
        M3u8MuItem *muItem = (M3u8MuItem *)item;
        dstPath = [self.pather pathForM3u8:muItem.url];
    } else if ([item isKindOfClass:M3u8TsItem.class]) {     //  ts文件
        M3u8TsItem *tsItem = (M3u8TsItem *)item;
        dstPath = [self.pather pathForTs:tsItem.url m3u8:tsItem.muItem.url];
    } else if ([item isKindOfClass:M3u8KeyItem.class]) {    //  key文件
        M3u8KeyItem *keyItem = (M3u8KeyItem *)item;
        dstPath = [self.pather pathForKey:keyItem.url m3u8:keyItem.muItem.url];
    }
    
    if (dstPath == nil) {
        return NO;
    }
    
    BOOL exist = [NSFileManager.defaultManager fileExistsAtPath:dstPath];
    return exist;
}

//  视频状态
- (M3u8ItemStatus)status:(M3u8Item *)item {
    M3u8MuItem *muItem = item.muItem;
    
    //  1. 判断该视频是否已合成
//    NSString *mp4Path = [self.pather pathForMp4:muItem.url];
//    if ([NSFileManager.defaultManager fileExistsAtPath:mp4Path]) {
//        return M3u8ItemStatusDownloaded;
//    }
    
    //  2. 判断该视频是否已下载
    NSString *completePath = [self.pather pathForComplete:muItem.url];
    if ([NSFileManager.defaultManager fileExistsAtPath:completePath]) {
        return M3u8ItemStatusDownloaded;
    }
    
    //  3. 判断视频在下载中
    if ([self.downloadings containsObject:muItem]) {
        return M3u8ItemStatusDownloading;
    }
    
    return M3u8ItemStatusNone;
}


//MARK: -   文件处理

//  移动文件
- (void)moveFile:(NSURL *)location item:(M3u8Item *)item {
    NSString *srcPath = location.path;
    NSString *dstPath = nil;
    if ([item isKindOfClass:M3u8MuItem.class]) {            //  m3u8文件
        M3u8MuItem *muItem = (M3u8MuItem *)item;
        dstPath = [self.pather pathForM3u8:muItem.url];
    } else if ([item isKindOfClass:M3u8TsItem.class]) {     //  ts文件
        M3u8TsItem *tsItem = (M3u8TsItem *)item;
        dstPath = [self.pather pathForTs:tsItem.url m3u8:tsItem.muItem.url];
    } else if ([item isKindOfClass:M3u8KeyItem.class]) {    //  key文件
        M3u8KeyItem *keyItem = (M3u8KeyItem *)item;
        dstPath = [self.pather pathForKey:keyItem.url m3u8:keyItem.muItem.url];
    }
    
    if (dstPath == nil) {
        return;
    }
    
    NSError *error = nil;
    BOOL success = [NSFileManager.defaultManager moveItemAtPath:srcPath toPath:dstPath error:&error];
}

//  生成.completed文件
- (void)createCompletedFile:(M3u8MuItem *)muItem {
    NSString *dstPath = [self.pather pathForComplete:muItem.url];
    [NSFileManager.defaultManager createFileAtPath:dstPath contents:nil attributes:nil];
    m3u8_printf("%s\n%s\n", __func__, muItem.url.absoluteString.UTF8String);
}

@end
