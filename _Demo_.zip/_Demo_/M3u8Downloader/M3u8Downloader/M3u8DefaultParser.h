//
//  M3u8DefaultParser.h
//  M3u8Downloader
//
//  Created by xisi on 2023/2/14.
//

#import <Foundation/Foundation.h>
#import "M3u8Protocols.h"

NS_ASSUME_NONNULL_BEGIN

/// 默认的m3u8内容解析
@interface M3u8DefaultParser : NSObject <M3u8Parse>

@end

NS_ASSUME_NONNULL_END
