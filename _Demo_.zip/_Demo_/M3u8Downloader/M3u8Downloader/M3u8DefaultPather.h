//
//  M3u8DefaultPather.h
//  M3u8Downloader
//
//  Created by xisi on 2023/2/13.
//

#import <Foundation/Foundation.h>
#import "M3u8Protocols.h"

NS_ASSUME_NONNULL_BEGIN

/**
    默认的路径解析：
    1. m3u8、key、ts都位于同一目录下。
    2. m3u8上一层路径名字为目录名字（这里有可能重名，导致文件被覆盖，发生这种情况需要将absoluteMode设置为YES）。
    3. mp4与m3u8也位于同一目录下。
 */
@interface M3u8DefaultPather : NSObject <M3u8Path>

/**
    是否开启绝对路径模式

    举例：
    https://vip.lzcdn2.com/20220517/6761_76aef660/1200k/hls/mixed.m3u8
    当 absoluteMode = NO 时，目录为：hls。
    当 absoluteMode = YES 时，目录为：20220517\6761_76aef660\1200k\hls。
 */
@property (nonatomic) BOOL absoluteMode;

@end

NS_ASSUME_NONNULL_END
