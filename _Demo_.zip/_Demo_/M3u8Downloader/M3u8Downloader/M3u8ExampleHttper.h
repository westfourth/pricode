//
//  M3u8ExampleHttper.h
//  M3u8Downloader
//
//  Created by xisi on 2023/2/14.
//

#import <Foundation/Foundation.h>
#import "M3u8Protocols.h"

NS_ASSUME_NONNULL_BEGIN

/// 默认的http加工处理
@interface M3u8ExampleHttper : NSObject <M3u8Http>

@end

NS_ASSUME_NONNULL_END
