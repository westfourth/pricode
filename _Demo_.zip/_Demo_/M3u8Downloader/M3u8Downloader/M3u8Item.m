//
//  M3u8Item.m
//  M3u8Downloader
//
//  Created by xisi on 2023/2/13.
//

#import "M3u8Item.h"

@implementation M3u8Item

- (instancetype)initWithURL:(NSURL *)url {
    self = [super init];
    if (self) {
        _url = url;
    }
    return self;
}

@end


//MARK: -   子类

@implementation M3u8MuItem

- (instancetype)initWithURL:(NSURL *)url {
    self = [super initWithURL:url];
    if (self) {
        self.muItem = self;
    }
    return self;
}

@end


@implementation M3u8TsItem
@end


@implementation M3u8KeyItem
@end
