//
//  main.m
//  M3u8Downloader
//
//  Created by xisi on 2023/2/13.
//

#import <Foundation/Foundation.h>
#import "M3u8Item.h"
#import "M3u8Downloader.h"
#import "M3u8DefaultPather.h"
#import "M3u8DefaultParser.h"
#import "M3u8ExampleFilter.h"

void test_parse(void);
void test_pending(void);
void test_download1(void);
void test_download2(void);
void test_filename(void);
void test_filter(void);
NSMutableArray<NSURL *> *parse_urls(NSString *path);

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        
        if (argc != 3) {
            NSString *program = [NSString stringWithFormat:@"%s", argv[0]].lastPathComponent;
            printf("用法: %s [下载列表文件路径] [视频目录路径]\n", program.UTF8String);
            exit(0);
            return 0;
        }
        
        NSString *downloadPath = [NSString stringWithFormat:@"%s", argv[1]];
        NSString *videoDir = [NSString stringWithFormat:@"%s", argv[2]];
        
        M3u8Downloader.shared.logEnabled = YES;
        M3u8Downloader.shared.pather.videoDir = videoDir;
        ((M3u8DefaultPather *)M3u8Downloader.shared.pather).absoluteMode = YES;
        M3u8Downloader.shared.filter = [M3u8ExampleFilter new];
        
        NSArray<NSURL *> *downloadUrls = parse_urls(downloadPath);
        for (NSURL *url in downloadUrls) {
            M3u8MuItem *item = [[M3u8MuItem alloc] initWithURL:url];
            [M3u8Downloader.shared download:item];
        }
    }
    CFRunLoopRun();
    return 0;
}

//  解析多个.m3u8
NSMutableArray<NSURL *> *parse_urls(NSString *path) {
    NSError *error = nil;
    NSString *text = [NSString stringWithContentsOfFile:path encoding:NSUTF8StringEncoding error:&error];
    NSArray<NSString *> *urlStrings = [text componentsSeparatedByString:@"\n"];
    
    NSMutableArray<NSURL *> *urls = [NSMutableArray new];
    for (NSString *urlString in urlStrings) {
        if ([urlString hasPrefix:@"http"]) {
            NSURL *url = [NSURL URLWithString:urlString];
            [urls addObject:url];
        }
    }
    return urls;
}


//MARK: -   test

void test_pending(void) {
    
    NSURL *url1 = [NSURL URLWithString:@"https://t19.cdn2020.com/video/m3u8/2022/09/03/d439b2be/index.m3u8"];
    NSURL *url2 = [NSURL URLWithString:@"https://t19.cdn2020.com/video/m3u8/2022/09/04/cd8ff3bb/index.m3u8"];
    NSURL *url3 = [NSURL URLWithString:@"https://t19.cdn2020.com/video/m3u8/2022/09/04/7c17b17a/index.m3u8"];
    NSURL *url4 = [NSURL URLWithString:@"https://t19.cdn2020.com/video/m3u8/2022/09/04/f2cf4b17/index.m3u8"];
    NSURL *url5 = [NSURL URLWithString:@"https://t19.cdn2020.com/video/m3u8/2022/09/04/790b7a93/index.m3u8"];
    NSURL *url6 = [NSURL URLWithString:@"https://t19.cdn2020.com/video/m3u8/2022/09/04/3ed3c323/index.m3u8"];
    
    NSArray *array1 = @[url1, url2];
    NSArray *array2 = @[url3, url4, url5, url6];
    
    for (NSURL *url in array1) {
        M3u8MuItem *item = [[M3u8MuItem alloc] initWithURL:url];
        [M3u8Downloader.shared download:item];
    }
    
    for (NSURL *url in array2) {
        M3u8MuItem *item = [[M3u8MuItem alloc] initWithURL:url];
        [M3u8Downloader.shared.pendings addObject:item];
    }
}

void test_download1(void) {
    NSURL *url = [NSURL URLWithString:@"https://odcxv.fj-ll.com/media/m3u8/7f2/7f2db9219c555899-85100/index.m3u8"];
    M3u8MuItem *item = [[M3u8MuItem alloc] initWithURL:url];
    [M3u8Downloader.shared download:item];
}

void test_download2(void) {
    NSURL *url = [NSURL URLWithString:@"https://odcxv.fj-ll.com/media/m3u8/42c/42cf5c4a9610d002-87712/index.m3u8"];
    M3u8MuItem *item = [[M3u8MuItem alloc] initWithURL:url];
    [M3u8Downloader.shared download:item];
}

void test_parse(void) {
    NSURL *muUrl = [NSURL URLWithString:@"https://t21.cdn2020.com/video/m3u8/2022/12/16/4f00df59/index.m3u8"];
    NSURL *tsUrl = [NSURL URLWithString:@"https://t21.cdn2020.com/video/m3u8/2022/12/16/4f00df59/0000.ts"];
    NSURL *keyUrl = [NSURL URLWithString:@"https://t21.cdn2020.com/video/m3u8/2022/12/16/enc.key"];
    
    NSString *path = @"/Users/xisi/test/M3u8Downloader/M3u8Downloader/index1.m3u8";
    NSError *error = nil;
    NSString *content = [NSString stringWithContentsOfFile:path encoding:NSUTF8StringEncoding error:&error];
    M3u8DefaultParser *parser = [M3u8DefaultParser new];
    
    M3u8MuItem *muItem = [[M3u8MuItem alloc] initWithURL:muUrl];
    [parser parse:muItem content:content];
}

void test_filename(void) {
    NSURL *url = [NSURL URLWithString:@"https://vip.lzcdn2.com/20220517/6761_76aef660/1200k/hls/mixed.m3u8"];
    M3u8DefaultPather *defaultPather = M3u8Downloader.shared.pather;
    defaultPather.absoluteMode = YES;
    NSString *m3u8 = [M3u8Downloader.shared.pather pathForM3u8:url];
    NSString *mp4 = [M3u8Downloader.shared.pather pathForMp4:url];
    puts(__func__);
}

void test_filter(void) {
    NSString *path = @"/Users/xisi/Desktop/M3u8Downloader/M3u8Downloader/mixed.m3u8";
    NSError *error = nil;
    NSString *content = [NSString stringWithContentsOfFile:path encoding:NSUTF8StringEncoding error:&error];
    
    NSString *pattern = @"#EXTINF:\\d+(\\.\\d+)?,\\n\\w{32}\\.ts\\n(#EXT-X-DISCONTINUITY\\n)?";
    NSRegularExpression *regexp = [NSRegularExpression regularExpressionWithPattern:pattern options:0 error:&error];
    NSString *content2 = [regexp stringByReplacingMatchesInString:content options:0 range:NSMakeRange(0, content.length) withTemplate:@""];
    puts(content2.UTF8String);
    puts(__func__);
}
