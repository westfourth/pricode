//
//  M3u8DefaultParser.m
//  M3u8Downloader
//
//  Created by xisi on 2023/2/14.
//

#import "M3u8DefaultParser.h"
#import "M3u8Item.h"

@implementation M3u8DefaultParser

/// 解析m3u8内容
- (void)parse:(M3u8MuItem *)muItem content:(NSString *)muContent {
    muItem.tsItems = [NSMutableArray new];
    [self parseTs:muItem content:muContent];
    [self parseKey:muItem content:muContent];
}

/// 解析ts
- (void)parseTs:(M3u8MuItem *)muItem content:(NSString *)muContent {
    NSString *pattern = @"\\w+\\.ts";
    NSError *error = nil;
    NSRegularExpression *regexp = [NSRegularExpression regularExpressionWithPattern:pattern options:0 error:&error];
    [regexp enumerateMatchesInString:muContent options:0 range:NSMakeRange(0, muContent.length) usingBlock:^(NSTextCheckingResult * _Nullable result, NSMatchingFlags flags, BOOL * _Nonnull stop) {
        //  path可能为相对路径、也可能为绝对路径
        NSString *path = [muContent substringWithRange:result.range];
        
        NSURL *url = [self absoluteUrlWithPath:path m3u8:muItem.url];
        M3u8TsItem *tsItem = [[M3u8TsItem alloc] initWithURL:url];
        tsItem.muItem = muItem;
        [muItem.tsItems addObject:tsItem];
    }];
}

/// 解析key
- (void)parseKey:(M3u8MuItem *)muItem content:(NSString *)muContent {
    NSString *pattern = @"(?<=#EXT-X-KEY:METHOD=AES-128,URI=\")[\\w|/]+(\\.\\w+)?(?=\")";
    NSError *error = nil;
    NSRegularExpression *regexp = [NSRegularExpression regularExpressionWithPattern:pattern options:0 error:&error];
    [regexp enumerateMatchesInString:muContent options:0 range:NSMakeRange(0, muContent.length) usingBlock:^(NSTextCheckingResult * _Nullable result, NSMatchingFlags flags, BOOL * _Nonnull stop) {
        //  path可能为相对路径、也可能为绝对路径
        NSString *path = [muContent substringWithRange:result.range];
        
        NSURL *url = [self absoluteUrlWithPath:path m3u8:muItem.url];
        M3u8KeyItem *keyItem = [[M3u8KeyItem alloc] initWithURL:url];
        keyItem.muItem = muItem;
        muItem.keyItem = keyItem;
    }];
}

/// 转换为绝对路径
- (NSURL *)absoluteUrlWithPath:(NSString *)path m3u8:(NSURL *)m3u8Url {
    NSURL *url = nil;
    if ([path hasPrefix:@"http"]) {         //  绝对路径
        url = [NSURL URLWithString:path];
    } else if ([path hasPrefix:@"/"]) {     //  相对根目录
        NSURLComponents *comp = [NSURLComponents componentsWithURL:m3u8Url resolvingAgainstBaseURL:YES];
        comp.path = path;
        url = comp.URL;
    } else {
        url = [m3u8Url URLByDeletingLastPathComponent];
        url = [url URLByAppendingPathComponent:path];
    }
    return url;
}

@end
