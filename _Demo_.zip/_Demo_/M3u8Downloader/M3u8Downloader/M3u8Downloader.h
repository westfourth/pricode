//
//  M3u8Downloader.h
//  M3u8Downloader
//
//  Created by xisi on 2023/2/13.
//

#import <Foundation/Foundation.h>
#import "M3u8Item.h"
#import "M3u8Protocols.h"

typedef NS_ENUM(NSInteger, M3u8ItemStatus) {
    M3u8ItemStatusNone,             //!<
    M3u8ItemStatusDownloading,      //!< 正在下载
    M3u8ItemStatusDownloaded,       //!< 已下载
};

NS_ASSUME_NONNULL_BEGIN

/**
    m3u8视频下载器。

    为了减少复杂度，无每个m3u8/ts文件的下载进度回调，整个视频的进度表示为：已下载的ts个数/总ts个数。
    如果该视频已下载，会生成一个.complete文件。
 
    每下载完一个ts，就会从该视频中下载后续的ts。
    每下载完一个视频，就会下载另外一个视频。
    
    并行下载数由download:决定，手动调用了几次，并行下载数就为几次。
 */
@interface M3u8Downloader : NSObject

+ (instancetype)shared;

@property (nonatomic) NSURLSession *session;
@property (nonatomic) BOOL logEnabled;              //!< 日志模式是否开启，默认：NO
@property (nonatomic) NSUInteger maxConcurrent;     //!< 最大并行下载数，默认：10

/// 待下载的m3u8
@property (readonly, nonatomic) NSMutableArray<M3u8MuItem *> *pendings;
/// 下载中的m3u8
@property (readonly, nonatomic) NSMutableArray<M3u8MuItem *> *downloadings;

@property (nonatomic) id <M3u8Path> pather;         //!< 路径映射
@property (nonatomic) id <M3u8Parse> parser;        //!< m3u8内容解析

@property (nullable, nonatomic) id <M3u8Filter> filter;         //!< m3u8内容过滤
@property (nullable, nonatomic) id <M3u8Http> httper;           //!< 请求、响应加工

//  下载视频
- (void)download:(M3u8MuItem *)muItem;

//  取消视频
- (void)cancel:(M3u8MuItem *)muItem;

//  视频状态
- (M3u8ItemStatus)status:(M3u8Item *)item;

@end

NS_ASSUME_NONNULL_END
