//
//  M3u8ExampleFilter.h
//  M3u8Downloader
//
//  Created by xisi on 2024/12/13.
//

#import <Foundation/Foundation.h>
#import "M3u8Protocols.h"

NS_ASSUME_NONNULL_BEGIN

@interface M3u8ExampleFilter : NSObject <M3u8Filter>

@end

NS_ASSUME_NONNULL_END
