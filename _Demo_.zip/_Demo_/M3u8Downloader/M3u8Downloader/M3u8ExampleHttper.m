//
//  M3u8ExampleHttper.m
//  M3u8Downloader
//
//  Created by xisi on 2023/2/14.
//

#import "M3u8ExampleHttper.h"

@implementation M3u8ExampleHttper

/// 将要发送请求
- (void)willRequest:(NSMutableURLRequest *)request {
//    request.cachePolicy = NSURLRequestReloadIgnoringLocalCacheData;
}

/// 收到响应
- (void)didResponse:(NSURLResponse *)response error:(NSError * _Nullable)error {
    
}

@end
