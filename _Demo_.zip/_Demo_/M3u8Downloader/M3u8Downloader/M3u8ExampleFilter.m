//
//  M3u8ExampleFilter.m
//  M3u8Downloader
//
//  Created by xisi on 2024/12/13.
//

#import "M3u8ExampleFilter.h"

@implementation M3u8ExampleFilter

- (NSString *)filterContent:(NSString *)muContent {
    NSError *error = nil;
    NSString *pattern = @"#EXTINF:\\d+(\\.\\d+)?,\\n\\w{32}\\.ts\\n(#EXT-X-DISCONTINUITY\\n)?";
    NSRegularExpression *regexp = [NSRegularExpression regularExpressionWithPattern:pattern options:0 error:&error];
    NSString *newContent = [regexp stringByReplacingMatchesInString:muContent options:0 range:NSMakeRange(0, muContent.length) withTemplate:@""];
    return newContent;
}

@end
