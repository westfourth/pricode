//
//  M3u8Protocols.h
//  M3u8Downloader
//
//  Created by xisi on 2023/2/14.
//

#import <Foundation/Foundation.h>
@class M3u8MuItem;

NS_ASSUME_NONNULL_BEGIN


//MARK: -   M3u8Path

/// 路径解析
@protocol M3u8Path <NSObject>
@required

/// 所有视频都位于此目录下
@property (nonatomic) NSString *videoDir;

/// m3u8文件对应的路径
- (NSString *)pathForM3u8:(NSURL *)m3u8Url;

/// ts文件对应的路径
- (NSString *)pathForTs:(NSURL *)tsUrl m3u8:(NSURL *)m3u8Url;

/// key文件对应的路径
- (NSString *)pathForKey:(NSURL *)keyUrl m3u8:(NSURL *)m3u8Url;

/// .complete文件对应的路径。当下载完m3u8、ts后才会生成此文件。
- (NSString *)pathForComplete:(NSURL *)m3u8Url;

@optional

/// mp4文件对应的路径
- (NSString *)pathForMp4:(NSURL *)m3u8Url;

@end


//MARK: -   M3u8Parse

/// m3u8内容解析
@protocol M3u8Parse <NSObject>
@required

/// 解析m3u8内容（给 muItem.keyItem、muItem.tsItems 赋值）。
- (void)parse:(M3u8MuItem *)muItem content:(NSString *)muContent;

@end


//MARK: -   M3u8Filter

/// m3u8内容过滤，生成新的内容
@protocol M3u8Filter <NSObject>
@optional

/// 生成新的内容
- (NSString *)filterContent:(NSString *)muContent;

@end


//MARK: -   M3u8Http

/// 网络请求
@protocol M3u8Http <NSObject>
@optional

/// 将要发送请求
- (void)willRequest:(NSMutableURLRequest *)request;

/// 收到响应
- (void)didResponse:(NSURLResponse *)response error:(NSError * _Nullable)error;

@end

NS_ASSUME_NONNULL_END
