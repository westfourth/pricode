//
//  M3u8Item.h
//  M3u8Downloader
//
//  Created by xisi on 2023/2/13.
//

#import <Foundation/Foundation.h>
@class M3u8MuItem;
@class M3u8TsItem;
@class M3u8KeyItem;

NS_ASSUME_NONNULL_BEGIN

/// 抽象父类
@interface M3u8Item : NSObject

- (instancetype)initWithURL:(NSURL *)url;

@property (readonly, nonatomic) NSURL *url;
@property (weak, nullable, nonatomic) M3u8MuItem *muItem;

@end


//MARK: -   子类

/// m3u8文件
@interface M3u8MuItem : M3u8Item

@property (nullable, nonatomic) M3u8KeyItem *keyItem;
@property (nonatomic) NSMutableArray<M3u8TsItem *> *tsItems;

/// 已下载的ts数量
@property (nonatomic) NSUInteger downloaded;
/// 进度回调。（downloaded：已下载的ts数量，total：总的ts数量）
@property (nullable, nonatomic) void (^progress)(NSUInteger downloaded, NSUInteger total);
/// 完成回调。（completed == YES时，error == nil）
@property (nullable, nonatomic) void (^completion)(BOOL completed, NSError * _Nullable error);

@end


/// ts文件
@interface M3u8TsItem : M3u8Item
@end


/// ts文件
@interface M3u8KeyItem : M3u8Item
@end

NS_ASSUME_NONNULL_END
