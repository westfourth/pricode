# APP启动优化

**apple官方视频教程：**[Optimizing App Launch](https://developer.apple.com/videos/play/wwdc2019/423)

## 理论

### 启动类型

![](Images/launch_types.png)

| 启动类型 | 描述 |
| :-: | :-- |
| 冷启动 | 系统重启，然后打开该app |
| 热启动 | 最近退出该app，然后打开该app |
| 恢复 | 该app暂停，然后打开该app |

### 启动阶段

![](Images/launch_phase.png)

| 阶段 | 系统处理 | 优化措施 |
| :-- | :-- | :-- |
| System Interface | 1. `dyld`加载共享库 | 1. 避免链接无用的库 <br> 2. 启动时避免加载（使用`dlopen()`和`NSBundle.load()`）动态库 <br> 3. 硬链接所需依赖 |
| Runtime Init | 1. 初始化运行时 <br> 2. 调用`+load`方法 <br> 3. 调用`__attribute__((constructor))`方法 | 1. 减少`+load`方法 <br> 2. 减少`__attribute__((constructor))`方法 |
| UIKit Init | 初始化`UIApplication`和`UIApplicationDelegate` | |
| Application Init | 1. 调用`FinishLaunchingWithOptions` <br> 2. 调用`DidBecomeActive` | 1. 推迟不相关的工作 <br> 2. 异步执行 |
| Initial Frame Render | 1. 调用`loadView` <br> 2. 调用`viewDidLoad` <br> 3. 调用`layoutSubViews` | 1. 减少视图层级 <br> 2. 减少自动布局约束 |


### 动态库

动态库分为两种：
>
1. 苹果系统动态库
1. app本身动态库

苹果系统动态库是所有app共享。当某个app启动时，如果所依赖的苹果系统动态库已启动，那么app的启动速度也会更快。

`dyld3`有库缓存机制。

## instruments操作
>
* 可以三击选择指定的区域
* `command + +` 放大时间轴、`command + -` 缩小时间轴

注意使用instruments做性能分析时，需要使用真机。

## 分析第一步

![](Images/analysis_time.png)

可以看到 Initializing - Process Creation 阶段，CPU只花费了5.00ms，而实际花费了53.01ms，这种差异来自于分析机制本身的开销。

## 分析第二步

我们先故意在代码中插入sleep方法来分析

***
![](Images/load_sample.png)
***
![](Images/did_finish_launch_sample.png)
***
![](Images/load_profile.png)

**Profile分析步骤：**
>
1. 在app（这里是TextKit）中选中一段需要分析的过程
2. 左侧选择Profile选项
3. 逐步展开耗时的列表
4. 找到对应的耗时方法（这里是`+[UIView(XSLayoutSubviews) load]`）

![](Images/system_calls.png)


**System Calls分析步骤：**
>
1. 在app（这里是TextKit）中选中一段需要分析的过程
2. 展开该app，选择对应工作的线程
3. 左侧选择Events: System Calls选项
4. 按照耗时排序
5. 右侧展示耗时的方法（这里是`+[UIView(XSLayoutSubviews) load]`）


## 分析第三步

从而可以找到上述2个方法中插入了sleep，去掉后再分析

![](Images/constructor.png)

可以看到`XSAlertPriority_main`方法耗时

![](Images/constructor_code.png)

由于这个文件并没有使用到，我们可以删掉该文件

