## 创建PDF

```objc
    WKPDFConfiguration *config = [WKPDFConfiguration new];
    [self.webView createPDFWithConfiguration:config completionHandler:^(NSData * _Nullable pdfDocumentData, NSError * _Nullable error) {
        NSString *dir = NSTemporaryDirectory();
        NSString *path = [dir stringByAppendingPathComponent:@"pdf_0.pdf"];
        NSError *error2 = nil;
        [pdfDocumentData writeToFile:path options:0 error:&error2];
    }];
```

生成的PDF大小是`WKWebView.scrollView.contentSize`，因此可用于截长图（先创建PDF，再转为图片）


## 效果

<embed src="PDF/pdf_0.pdf" type="application/pdf" width="50%" height="1046px" />


## 设置宽高（1x2）


```objc
    WKPDFConfiguration *config = [WKPDFConfiguration new];
    config.rect = (CGRect){.size = CGSizeMake(self.webView.bounds.size.width * 1,
                                              self.webView.bounds.size.height * 2)};
```

<embed src="PDF/pdf_1x2.pdf" type="application/pdf" width="50%" height="1387px" />

可以看到，当设置的高度超过`WKWebView`的内容高度时，超出的区域是空白的。

## 设置宽高（2x1）

```objc
    WKPDFConfiguration *config = [WKPDFConfiguration new];
    config.rect = (CGRect){.size = CGSizeMake(self.webView.bounds.size.width * 2,
                                              self.webView.bounds.size.height * 1)};
```
<embed src="PDF/pdf_2x1.pdf" type="application/pdf" width="100%" height="703px" />

可以看到，当设置的宽度超过WKWebView的内容宽度时，超出的区域是空白的。

## 结论

WKWebView在生成PDF时，是以其内容大小生成的，而不是以可见区域生成。


