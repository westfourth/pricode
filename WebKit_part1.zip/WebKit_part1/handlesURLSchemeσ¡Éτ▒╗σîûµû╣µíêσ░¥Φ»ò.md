# handlesURLScheme子类化方案尝试

## 问题

直接改写`+[WKWebView handlesURLScheme:]`，如果app中有其他地方使用了`-[WKWebViewConfiguration setURLSchemeHandler:forURLScheme:]`，可能会引起潜在的问题

```objc
+ (BOOL)handlesURLScheme:(NSString *)urlScheme {
    NSArray *array = @[@"http", @"https"];
    if ([array containsObject:urlScheme]) {
        return NO;
    } else {
        ...
    }
}
```

会导致所有的`http`、`https`都走`WKURLSchemeHandler`，如果其他`WKWebView`设置了`-[WKWebViewConfiguration setURLSchemeHandler:forURLScheme:]`，并且没有对`http`、`https`进行处理，那么就没法收到数据。

## 设想

1. 新建一个`WKWebView `子类，比如类名为`WKWebView2`，添加`+[WKWebView2 handlesURLScheme:]`方法
2. `+[WKWebView handlesURLScheme:]`方法维持原样。
3. 将要使用的`WKWebView`对象类名设置为`WKWebView2`，从而使其走`+[WKWebView2 handlesURLScheme:]`方法

这样就不干涉系统方法`+[WKWebView handlesURLScheme:]`了。

## 实现

```objc
@interface WKWebView (XSClassName)

@property (nonatomic) NSString *className;

@end
```

```objc
@implementation WKWebView (XSClassName)

- (NSString *)className {
    return objc_getAssociatedObject(self, @selector(className));
}

- (void)setClassName:(NSString *)className {
    objc_setAssociatedObject(self, @selector(className), className, OBJC_ASSOCIATION_RETAIN);
    //
    Class cls = [[self class] XSClassName_newClass:className.UTF8String];
    if (cls != NULL) {
        Class preCls = object_setClass(self, cls);
        [[self class] XSClassName_handlesURLScheme:cls];
    }
}

+ (Class _Nullable)XSClassName_newClass:(const char *)className {
    Class superCls = WKWebView.class;
    Class newCls = objc_allocateClassPair(superCls, className, 0);
    if (newCls == NULL) {
        return NULL;
    }
    objc_registerClassPair(newCls);
    return newCls;
}

+ (BOOL)XSClassName_handlesURLScheme:(Class _Nonnull)cls {
    SEL sel = @selector(handlesURLScheme:);
    //  类方法
    Method m = class_getClassMethod(cls, sel);
    const char *types = method_getTypeEncoding(m);
    
    IMP imp0 = method_getImplementation(m);
    IMP imp = imp_implementationWithBlock(^BOOL(Class wvCls, NSString *urlScheme) {
        NSArray *array = @[@"http", @"https"];
        if (wvCls != WKWebView.class && [array containsObject:urlScheme]) {
            return NO;
        } else {
            BOOL result = ((BOOL (*)(Class, SEL, NSString *))imp0)(wvCls, sel, urlScheme);
            return result;
        }
    });
    const char *clsName = class_getName(cls);
    //  类方法存储在元类中
    Class metaClass = objc_getMetaClass(clsName);
    BOOL success = class_addMethod(metaClass, sel, imp, types);
    if (!success) {
        IMP imp2 = method_setImplementation(m, imp);
        success = imp2 == imp0;
    }
    return success;
}

@end
```

**问题：**`Class wvCls`值一值都为`WKWebView`，不会是`WKWebView2`

## 继续尝试

### 尝试1:

```objc
    WKWebViewConfiguration *config = [WKWebViewConfiguration new];
    [config setURLSchemeHandler:self.urlSchemeHandler forURLScheme:@"http"];
    [config setURLSchemeHandler:self.urlSchemeHandler forURLScheme:@"https"];
    
    self.webView = [[WKWebView alloc] initWithFrame:self.view.bounds configuration:config];
```

会触发`self.urlSchemeHandler`的`WKURLSchemeHandler`协议方法

### 尝试2:

```objc
    WKWebViewConfiguration *config = [WKWebViewConfiguration new];    
    self.webView = [[WKWebView alloc] initWithFrame:self.view.bounds configuration:config];
    
    [config setURLSchemeHandler:self.urlSchemeHandler forURLScheme:@"http"];
    [config setURLSchemeHandler:self.urlSchemeHandler forURLScheme:@"https"];
```

不会触发`self.urlSchemeHandler`的`WKURLSchemeHandler`协议方法

**重要：**在`-[WKWebView initWithFrame:configuration:]`方法中说明了是复制了一份`configuration`，因此在原有的`configuration`上更改是没有用的。

```objc
    WKWebViewConfiguration *config = [WKWebViewConfiguration new];
    self.webView = [[WKWebView alloc] initWithFrame:self.view.bounds configuration:config];
    WKWebViewConfiguration *config2 = self.webView.configuration;
```

可以看到`config`与`config2`是不同的实例对象。

### 尝试3:

```objc
    WKWebViewConfiguration *config = [WKWebViewConfiguration new];
    self.webView = [[WKWebView alloc] initWithFrame:self.view.bounds configuration:config];

    WKWebViewConfiguration *config2 = self.webView.configuration;
    [config2 setURLSchemeHandler:self.urlSchemeHandler forURLScheme:@"http"];
    [config2 setURLSchemeHandler:self.urlSchemeHandler forURLScheme:@"https"];
```

不会触发`self.urlSchemeHandler`的`WKURLSchemeHandler`协议方法

## 最简单的尝试

新建`WKWebView`的子类`WKWebView3`，改写`handlesURLScheme:`方法

```objc
@interface WKWebView3 : WKWebView
@end
```

```objc
@implementation WKWebView3

+ (BOOL)handlesURLScheme:(NSString *)urlScheme {
    NSArray *array = @[@"http", @"https"];
    if ([array containsObject:urlScheme]) {
        return NO;
    } else {
        BOOL result = [super handlesURLScheme:urlScheme];
        return result;
    }
}

@end
```

实例化`WKWebView3`

```objc
    WKWebViewConfiguration *config = [WKWebViewConfiguration new];
    [config setURLSchemeHandler:self.urlSchemeHandler forURLScheme:@"http"];
    [config setURLSchemeHandler:self.urlSchemeHandler forURLScheme:@"https"];
    
    self.webView = [[WKWebView3 alloc] initWithFrame:self.view.bounds configuration:config];
```

运行结果直接崩溃：

```sh
*** Terminating app due to uncaught exception 'NSInvalidArgumentException', reason: ''http' is a URL scheme that WKWebView handles natively'
```

## 结论

1. 在`-[WKWebView initWithFrame:configuration:]`前就得设置`setURLSchemeHandler:forURLScheme:`
2. 调用`+handlesURLScheme:`的对象一定是`WKWebView`，不可能是`WKWebView`的子类

因此没法通过创建`WKWebView`子类的方式实现上述设想。

## 遇到的问题？？？

<http://www.so.com>一直卡在人机校验

尝试在request中加入cookie、response中写入cookie，还是无效。