## OC调用JS

**通过`WKWebView`获取不到`JSContext`**

```objc
//  <button id="index-bn" class="se-bn " type="submit">百度一下</button>
//  结果：百度一下
NSString *js = @"document.getElementById('index-bn').innerText";
[self.webView evaluateJavaScript:js completionHandler:^(id _Nullable obj, NSError * _Nullable error) {
    
}];
```

### 再如

```js
function alertFunction(){
    alert("你好，我是一个警告框！");
}
```

```objc
NSString *js = @"alertFunction()";
[self.webView evaluateJavaScript:js completionHandler:^(id _Nullable obj, NSError * _Nullable error) {
    
}];
```

### 选择注入js时机

``` objc
NSString *js = @"document.body.style.background = \"#777\";";
WKUserScript *script = [[WKUserScript alloc] initWithSource:js injectionTime:WKUserScriptInjectionTimeAtDocumentEnd forMainFrameOnly:YES];
[self.webView.configuration.userContentController addUserScript:script];
```

## JS调用OC

通过下面的格式出发回调

```js
window.webkit.messageHandlers.<#name#>.postMessage()
```

### 注册

```objc
@interface CustomScriptMessageHandler : NSObject <WKScriptMessageHandler>
@end

@implementation CustomScriptMessageHandler

- (void)userContentController:(WKUserContentController *)userContentController didReceiveScriptMessage:(WKScriptMessage *)message {
    puts(__func__);
}

@end
```

```objc
CustomScriptMessageHandler *handler = [CustomScriptMessageHandler new];
[self.webView.configuration.userContentController addScriptMessageHandler:handler name:@"customABC"];
```

### 触发

```js
window.webkit.messageHandlers.customABC.postMessage({ title: "标题", content: "内容" });
```

**注意：`customABC`名字保持一致**

