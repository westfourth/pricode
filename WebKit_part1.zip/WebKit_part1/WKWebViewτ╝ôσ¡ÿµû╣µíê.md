# WKWebView缓存方案

### 1. 方案

使用`setURLSchemeHandler:forURLScheme:`处理指定URL scheme

``` objc
    //  1. 一个URL scheme只能被注册一次
    //  2. URL scheme不区分大小写
    //  3. 必须为有效的URL Scheme，例如："ht_tp"、"123" 就是无效的，"abc"、"ab3"是有效的。
    //  4. 必须为 +[WKWebView handlesURLScheme:] 不能处理的。
    [config setURLSchemeHandler:self.urlSchemeHandler forURLScheme:@"http"];
    [config setURLSchemeHandler:self.urlSchemeHandler forURLScheme:@"https"];
```

### 2. 报错

```sh
Terminating app due to uncaught exception 'NSInvalidArgumentException', reason: ''http' is a URL scheme that WKWebView handles natively'
```
原因：`handlesURLScheme:`可以处理http、https。

### 3. 处理

改写`handlesURLScheme:`的实现

```objc
+ (void)runtime_handlesURLScheme {
    Class cls = WKWebView.class;
    SEL sel = @selector(handlesURLScheme:);
    //  类方法
    Method m = class_getClassMethod(cls, sel);
    const char *types = method_getTypeEncoding(m);
    
    IMP imp0 = method_getImplementation(m);
    IMP imp = imp_implementationWithBlock(^BOOL(Class wvCls, NSString *urlScheme) {
        NSArray *array = @[@"http", @"https"];
        if ([array containsObject:urlScheme]) {
            return NO;
        } else {
            BOOL result = ((BOOL (*)(Class, SEL, NSString *))imp0)(wvCls, sel, urlScheme);
            return result;
        }
    });
    const char *clsName = class_getName(cls);
    //  类方法存储在元类中
    Class metaClass = objc_getMetaClass(clsName);
    BOOL success = class_addMethod(metaClass, sel, imp, types);
    if (!success) {
        IMP imp2 = method_setImplementation(m, imp);
        BOOL success2 = imp2 == imp0;
    }
}
```

### 4. 结果

http、https请求都会走`self.urlSchemeHandler`

```objc
- (void)webView:(WKWebView *)webView startURLSchemeTask:(id <WKURLSchemeTask>)urlSchemeTask;
- (void)webView:(WKWebView *)webView stopURLSchemeTask:(id <WKURLSchemeTask>)urlSchemeTask;
```

### 5. 使用

这里只是以请求网络数据举例，本地已缓存的数据同理

```objc
- (void)webView:(WKWebView *)webView startURLSchemeTask:(id <WKURLSchemeTask>)urlSchemeTask {
    NSURL *url = webView.URL;
    NSURLRequest *request = urlSchemeTask.request;

    NSURLSessionTask *task = [NSURLSession.sharedSession dataTaskWithRequest:request completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
        
        SEL sel = sel_registerName("URLSchemeTaskIsStopped");
        BOOL isStopped = objc_getAssociatedObject(urlSchemeTask, sel);
        if (isStopped) {
            return;
        }
        
        if (error) {
            [urlSchemeTask didFailWithError:error];
            return;
        }
        
        if (response) {
            [urlSchemeTask didReceiveResponse:response];
        }
        if (data) {
            [urlSchemeTask didReceiveData:data];
        }
        [urlSchemeTask didFinish];
        
    }];
    [task resume];
}

- (void)webView:(WKWebView *)webView stopURLSchemeTask:(id <WKURLSchemeTask>)urlSchemeTask {
    SEL sel = sel_registerName("URLSchemeTaskIsStopped");
    objc_setAssociatedObject(urlSchemeTask, sel, @YES, OBJC_ASSOCIATION_ASSIGN);
}
```

**注意1：**

先调用`didReceiveResponse:`，再调用`didReceiveData:`，顺序相反则报错：

```sh
*** Terminating app due to uncaught exception 'NSInternalInconsistencyException', reason: 'No response has been sent for this task'
```
**注意2：**

已结束的`WKURLSchemeTask`是不能再接受数据的

`webView:stopURLSchemeTask:`、`didFailWithError:`、`didFinish`三种方式都表示已结束

```objc
*** Terminating app due to uncaught exception 'NSInternalInconsistencyException', reason: 'This task has already been stopped'
```

**注意3：**

```objc
- (void)webView:(WKWebView *)webView startURLSchemeTask:(id <WKURLSchemeTask>)urlSchemeTask {
    NSURL *url = webView.URL;
    NSURLRequest *request = urlSchemeTask.request;
```

webView.URL表示请求的网页，但网页中有相关的其他资源，urlSchemeTask.request就表示当前请求的资源，例如该网页、该网页下的图片、js等资源。
