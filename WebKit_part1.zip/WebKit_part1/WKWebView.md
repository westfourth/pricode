# WKWebView

## 基础

``` objc
WKWebViewConfiguration *config = [WKWebViewConfiguration new];
self.webView = [[WKWebView alloc] initWithFrame:self.view.bounds configuration:config];
[self.view addSubview:self.webView];
```

### 加载网络

```objc
NSURL *url = [NSURL URLWithString:@"https://www.google.com.hk"];
NSURLRequest *req = [NSURLRequest requestWithURL:url];
[self.webView loadRequest:req];
```

### 加载本地

```objc
NSString *path = [NSBundle.mainBundle pathForResource:@"test" ofType:@"html"];
NSError *error = nil;
NSString *string = [[NSString alloc] initWithContentsOfFile:path encoding:NSUTF8StringEncoding error:&error];
[self.webView loadHTMLString:string baseURL:nil];
```

## 基本属性

```objc
//  允许左滑返回上个页面、右滑进入下个页面
self.webView.allowsBackForwardNavigationGestures = YES;
    
//  当前页面之前的所有页面
NSArray *array = self.webView.backForwardList.backList;
//  当前页面之后的所有页面
NSArray *array = self.webView.backForwardList.forwardList;
    
//  监听加载进度
[self.webView addObserver:self forKeyPath:@"estimatedProgress" options:NSKeyValueObservingOptionNew context:nil];
//  监听标题
[self.webView addObserver:self forKeyPath:@"title" options:NSKeyValueObservingOptionNew context:nil];
```

## 基本行为

```objc
//  后退
if ([self.webView canGoBack]) {
    [self.webView goBack];
}
    
    //  前进
if ([self.webView canGoForward]) {
    [self.webView goForward];
}
    
    //  刷新
[self.webView reload];
```

## 代理

**自定义代理**

```objc
self.webView.customUserAgent = @"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.3 Safari/605.1.15";
```

**代理应用名**

```objc
config.applicationNameForUserAgent = @"ABC";
```

**获取代理**

```objc
[self.webView evaluateJavaScript:@"navigator.userAgent" completionHandler:^(id _Nullable result, NSError * _Nullable error) {
    
}];
```

**三种代理**

```sh
# 手机代理
"Mozilla/5.0 (iPhone; CPU iPhone OS 17_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148"
# 桌面代理
"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.3 Safari/605.1.15"
# 代理应用名（applicationNameForUserAgent = @"ABC"）
"Mozilla/5.0 (iPhone; CPU iPhone OS 17_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) ABC"
```



## Cookie

```objc
WKHTTPCookieStore *httpCookieStore = self.webView.configuration.websiteDataStore.httpCookieStore;
[httpCookieStore getAllCookies:^(NSArray<NSHTTPCookie *> * _Nonnull array) {
    for (NSHTTPCookie *cookie in array) {
        NSLog(@">>> Cookie %@ = %@", cookie.name, cookie.value);
        
        if ([cookie.name isEqualToString:@"1P_JAR"]) {
            [httpCookieStore deleteCookie:cookie completionHandler:^{
                
            }];
        }
    }
}];
```

## Find

```objc
WKFindConfiguration *config = [WKFindConfiguration new];
[self.webView findString:@"YY直播" withConfiguration:config completionHandler:^(WKFindResult * _Nonnull result) {
    
}];
```