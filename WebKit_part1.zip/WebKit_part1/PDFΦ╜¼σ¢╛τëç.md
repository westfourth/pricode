## PDF转图片

截长图：先创建PDF，再转为图片，即可达到截长图效果。

```objc
/**
    从PDF指定page生成图片
 
    @param  page 从1开始
 */
+ (nullable UIImage *)pdfImageWithData:(NSData *)pdfData page:(NSInteger)page {
    UIImage *image = nil;
    CFDataRef data = CFBridgingRetain(pdfData);
    CGDataProviderRef provider = CGDataProviderCreateWithCFData(data);
    CGPDFDocumentRef doc = CGPDFDocumentCreateWithProvider(provider);
    
    size_t count = CGPDFDocumentGetNumberOfPages(doc);
    if (page > 0 && page <= count) {
        CGPDFPageRef pageRef = CGPDFDocumentGetPage(doc, page);
        CGPDFPageRetain(pageRef);
        CGRect rect = CGPDFPageGetBoxRect(pageRef, kCGPDFMediaBox);
        
        UIGraphicsBeginImageContextWithOptions(rect.size, NO, 0);
        CGContextRef context = UIGraphicsGetCurrentContext();
        
        //  左下角坐标系 转为 左上角坐标系
        CGContextTranslateCTM(context, 0, rect.size.height);
        CGContextScaleCTM(context, 1, -1);
        
        CGContextDrawPDFPage(context, pageRef);
        CGPDFPageRelease(pageRef);
        
        image = UIGraphicsGetImageFromCurrentImageContext();
        UIGraphicsEndImageContext();
    }
    
    CGPDFDocumentRelease(doc);
    CGDataProviderRelease(provider);
    CFRelease(data);
    return image;
}
```