# iOS签名

## 开发者账号种类

| | 个人 | 公司 | 企业 |
| :-: | :-: | :-: | :-: |
| 费用（$） | 99 | 99 | 299 |
| 允许开发者数量 | 1人 | 多人 | 多人 |
| 最大设备数量 | 100 | 100 | 无限制 |
| 能上AppStore ？ | 能 | 能 | 不能 |

## 签名种类

| | 开发者签名 | 企业签名 | 超级签名 | TF签名 |
| :-: | :-: | :-: | :-: | :-: |
| 原理 | | | 多个 开发者签名 |  |
| 账号 | 个人/公司 | 企业 | 多个 个人/公司 | 个人/公司 |
| 最大设备数量 | 100 | 无限制 | 多个 * 100 | 1万 |

资料：[MDM（Mobile Device Management）](https://support.apple.com/en-hk/guide/deployment/depc0aadd3fe/web)

## 重签名

1. unzip 解压 ipa
1. 替换 mobileprovision
1. 替换 Info.plis 的 bundle_id
1. 使用对应证书签名所有的 framework，然后使用对应证书签名 app
1. zip 打包，更改后缀名为 ipa