# APP瘦身

## Slicing

ipa被上传到App Store Connect后，会被创建不同的变体，以适配不同的设备。

App Store根据不同的设备，分发不同的变体叫做Slicing。

![](Images/slicing.webp)

## Asset

图片放在Asset比放在Bundle中要快。

- Bundle方式：需要读取图片信息，这一步耗时。
- Asset方式：编译时生成`.car`文件，包含资源和索引，索引中包含了图片的信息。

> **注意：`imageNamed:`系列方法会缓存图片，因此大图片不应该使用`imageNamed:`系列方法。**

## Bitcode

Bitcode是一种中间代码，App Store Connect会对开启此配置的app重新编译和链接。当Apple推出新的CPU架构，或者LLVM推出了新的优化，就不需要发布新的安装包。

## on-Demand Resource

按需加载，一部分资源可以放置在苹果服务器上。

|  | 包含在app内 | 影响app大小 | 何时下载 |
| :-- | :-- | :-- | :-- |
| Initial install tags | 是 | 是 | 与app一起下载 |
| Prefetch tag order | 否 | 否 | app下载后开始下载 |
| Downloaded only on demand | 否 | 否 | 开发者控制 |

## 其他优化措施

1. 删除未使用的代码和库。
1. 删除未使用的、或者重复的图片。
1. 压缩特定资源。
1. 大图片采用jpg格式，有损压缩。
1. 非必需资源可放置到服务端。
1. Optimization Level 编译参数 改为 Fastest Smallest。







