//
//  BookCell.h
//  MVP
//
//  Created by mac on 2020/6/20.
//  Copyright © 2020 mac. All rights reserved.
//

#import <UIKit/UIKit.h>
@protocol BookCellDelegate;

NS_ASSUME_NONNULL_BEGIN

//  在View中不会出现Model
@interface BookCell : UITableViewCell

@property (weak, nonatomic) id<BookCellDelegate> delegate;

@property (weak, nonatomic) IBOutlet UIImageView *logoImageView;
@property (weak, nonatomic) IBOutlet UILabel *upLabel;
@property (weak, nonatomic) IBOutlet UILabel *downLabel;
@property (weak, nonatomic) IBOutlet UIButton *collectButton;

@end


@protocol BookCellDelegate <NSObject>

- (void)cell:(BookCell *)cell didClickCollectButton:(UIButton *)button;

@end

NS_ASSUME_NONNULL_END
