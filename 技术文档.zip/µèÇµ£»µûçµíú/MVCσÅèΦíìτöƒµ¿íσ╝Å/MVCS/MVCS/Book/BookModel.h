//
//  BookModel.h
//  MVP
//
//  Created by mac on 2020/6/20.
//  Copyright © 2020 mac. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface BookModel : NSObject

/***************** 数据 *****************/
@property (nonatomic) NSString *title;
@property (nonatomic) NSString *subtitle;
@property (nonatomic) NSString *isbn13;
@property (nonatomic) NSString *price;

@property (nonatomic) NSURL *image;
@property (nonatomic) NSURL *url;

//  isSelected不属于原始数据
@property (nonatomic) BOOL isSelected;

/***************** 数据的操作 *****************/
+ (instancetype)modelFromDict:(NSDictionary *)dict;

@end

NS_ASSUME_NONNULL_END
