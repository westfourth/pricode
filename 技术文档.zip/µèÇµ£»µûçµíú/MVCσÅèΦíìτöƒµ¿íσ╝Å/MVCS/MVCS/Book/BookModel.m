//
//  BookModel.m
//  MVP
//
//  Created by mac on 2020/6/20.
//  Copyright © 2020 mac. All rights reserved.
//

#import "BookModel.h"

@implementation BookModel

+ (instancetype)modelFromDict:(NSDictionary *)dict {
    BookModel *model = [BookModel new];
    model.title = dict[@"title"];
    model.subtitle = dict[@"subtitle"];
    model.isbn13 = dict[@"isbn13"];
    model.price = dict[@"price"];
    
    model.image = [NSURL URLWithString:dict[@"image"]];
    model.url = [NSURL URLWithString:dict[@"url"]];
    return model;
}

@end
