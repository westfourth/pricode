//
//  BookService.m
//  MVCS
//
//  Created by mac on 2020/6/20.
//  Copyright © 2020 mac. All rights reserved.
//

#import "BookService.h"

@implementation BookService

+ (void)fetchBooksWithCompletion:(void (^)(NSError* _Nullable, NSMutableArray<BookModel *> * _Nullable))completion {
    //  模拟耗时操作
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        NSString *path = [[NSBundle mainBundle] pathForResource:@"Book" ofType:@"json"];
        NSData *data = [NSData dataWithContentsOfFile:path];
        
        NSError *error = nil;
        NSDictionary *dict = [NSJSONSerialization JSONObjectWithData:data options:0 error:&error];
        if (error) {
            if (completion) completion(error, nil);
            return;
        }
        NSArray<NSDictionary *> *books = dict[@"books"];
        NSMutableArray<BookModel *> *models = [NSMutableArray new];
        for (NSDictionary *dict in books) {
            BookModel *model = [BookModel modelFromDict:dict];
            [models addObject:model];
        }
        //
        if (completion) completion(nil, models);
    });
}

@end
