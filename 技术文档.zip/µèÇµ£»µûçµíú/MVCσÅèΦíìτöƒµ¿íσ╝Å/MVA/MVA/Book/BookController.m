//
//  BookController.m
//  MVP
//
//  Created by mac on 2020/6/20.
//  Copyright © 2020 mac. All rights reserved.
//

#import "BookController.h"
#import "BookAdapter.h"

@interface BookController () <UITableViewDataSource, UITableViewDelegate> {
    NSMutableArray<BookAdapter *> *_adapters;
}
@property (weak, nonatomic) IBOutlet UITableView *tableView;

@end

@implementation BookController

- (void)viewDidLoad {
    [super viewDidLoad];
    _adapters = [NSMutableArray new];
    
    UINib *nib = [UINib nibWithNibName:@"BookCell" bundle:nil];
    [self.tableView registerNib:nib forCellReuseIdentifier:@"ID"];
    
    [self loadData];
}

- (void)loadData {
    [BookModel fetchBooksWithCompletion:^(NSError * _Nullable error, NSMutableArray<BookModel *> * _Nullable models) {
        if (error) return;
        for (BookModel *model in models) {
            BookAdapter *adapter = [BookAdapter new];
            adapter.model = model;
            [_adapters addObject:adapter];
        }
        [self.tableView reloadData];
    }];
}

//MARK:-    数据源 + 委托

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return _adapters.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    BookAdapter *adapter = _adapters[indexPath.row];
    BookCell *cell = [tableView dequeueReusableCellWithIdentifier:@"ID" forIndexPath:indexPath];
    adapter.view = cell;
    return cell;
}

@end
