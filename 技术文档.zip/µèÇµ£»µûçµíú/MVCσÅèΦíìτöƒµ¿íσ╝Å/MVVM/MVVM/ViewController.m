//
//  ViewController.m
//  MVVM
//
//  Created by mac on 2020/7/1.
//  Copyright © 2020 mac. All rights reserved.
//

#import "ViewController.h"
#import "BookController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (IBAction)clickEnter:(UIBarButtonItem *)sender {
    BookController *vc = [BookController new];
    [self.navigationController pushViewController:vc animated:YES];
}

@end
