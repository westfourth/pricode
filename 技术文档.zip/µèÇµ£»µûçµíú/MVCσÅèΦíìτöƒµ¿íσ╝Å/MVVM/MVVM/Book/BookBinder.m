//
//  BookBinder.m
//  MVVM
//
//  Created by mac on 2020/7/20.
//  Copyright © 2020 mac. All rights reserved.
//

#import "BookBinder.h"

@implementation BookBinder

+ (void)bindView:(BookCell *)cell viewModel:(BookViewModel *)viewModel {
    __weak typeof (cell) weak_cell = cell;
    [RACObserve(viewModel, title) subscribeNext:^(id  _Nullable x) {
        weak_cell.upLabel.text = x;
    }];
    [RACObserve(viewModel, subtitle) subscribeNext:^(id  _Nullable x) {
        weak_cell.downLabel.text = x;
    }];
    [RACObserve(viewModel, isSelected) subscribeNext:^(id  _Nullable x) {
        weak_cell.collectButton.selected = [x boolValue];
    }];
    [[cell.collectButton rac_signalForControlEvents:UIControlEventTouchUpInside] subscribeNext:^(__kindof UIControl * _Nullable x) {
        viewModel.isSelected = !viewModel.isSelected;
    }];
}

@end
