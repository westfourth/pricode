//
//  BookBinder.h
//  MVVM
//
//  Created by mac on 2020/7/20.
//  Copyright © 2020 mac. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <ReactiveObjC/ReactiveObjC.h>
#import "BookCell.h"
#import "BookViewModel.h"

NS_ASSUME_NONNULL_BEGIN

//  DataBinding
@interface BookBinder : NSObject

+ (void)bindView:(BookCell *)cell viewModel:(BookViewModel *)viewModel;

@end

NS_ASSUME_NONNULL_END
