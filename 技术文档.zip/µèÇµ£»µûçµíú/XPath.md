# XPath

## 范例

``` html
<div class="stui-pannel_hd">
	<div class="stui-pannel__head active bottom-line clearfix">
		<h3 class="title">
			正在热播
		</h3>						
	</div>																		
</div>
```

选取h3节点：

1. class属性为title
2. 节点值包含`正在热播`

``` xpath
//h3[@class='title'][contains(., '正在热播')]
```