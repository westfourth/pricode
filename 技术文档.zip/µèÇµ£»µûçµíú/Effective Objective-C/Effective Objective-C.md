## 改善iOS程序的52种方法

1. 在`.h`中最小`#import`其他头文件，可以用`@class`声明
1. 优先使用语法糖`@()`、`@[]`
1. 优先使用类型常量，而不是`#define`
1. 对状态、选项使用`enum`
1. 对类名使用前缀，例如`NS`
1. 指定初始化方法
1. 实现`description`方法
1. 优先使用不可变对象
1. 使用明确清晰的命名
1. 私有方法、变量使用前缀
1. 使用类别分散类实现
1. 对列别方法添加前缀
1. 在类别中避免使用属性
1. 使用类扩展隐藏实现细节
1. 使用协议提供匿名对象
1. 在`dealloc`中释放对象，清除观察状态
1. 在`Exception`中注意释放对象
1. 使用`weak`避免循环引用
1. 使用`AutoReleasePool`减少高内存占用
1. 使用`Zombies`调试内存管理问题
1. 避免使用`retainCount`
1. 对block类型使用`typedef`
1. 使用block回调减少代码分离
1. block中避免循环引用
1. 线程同步使用@synchronized(self)
1. 优先使用GCD，而不是performSelector
1. 知道啥情况使用GCD，啥情况使用Operation
1. 使用dispatch_group
1. 使用dispatch_once
1. 避免使用dispatch_get_current_queue
1. 熟悉系统框架
1. 相对于for循环，优先使用block枚举
1. <font color=blue>使用NSCache做缓存、而不是NSDictionary；使用NSPurgeableData做数据缓存。</font>
1. 保持initialize和load方法简洁
1. 记住NSTimer会持有它的target



## 枚举宏定义源码

``` c
typedef enum ABC: int   ABC;
enum ABC: int {
    ABCa,
    ABCb,
    ABCc,
};
```

``` c
#define NS_ABC(type, name) enum name: type name; enum name: type

typedef NS_ABC(int, ABC) {
    ABCa,
    ABCb,
    ABCc,
};
```

## 变量声明区别

``` objc
@interface Person : NSObject {
    NSString *_name;
    NSUInteger _age;
}
@end
```

内存布局与变量申明的先后顺序一致

正常情况下，编译好的库和头文件是正常调用的。但当头文件新增变量时，这时候变量地址寻址会出错

``` objc
@interface Person : NSObject
@property (nonatomic) NSString *name;
@property (nonatomic) NSUInteger age;
@end
```

## 类扩展

``` objc
@interface Person : NSObject
@property (nonatomic) NSString *name;
@property (nonatomic) NSUInteger age;
@end

//  扩展一
@interface Person ()
@property (nonatomic) NSString *firstName;
@end

//  扩展二
@interface Person ()
@property (nonatomic) NSString *lastName;
@end
```

同一个类可以有多个类扩展


## objc_autoreleaseReturnValue()

``` objc
+ (EOCPerson*)personWithName:(NSString*)name { 
	EOCPerson *person = [[EOCPerson alloc] init]; 
	person.name = name; 	
	objc_autoreleaseReturnValue(person);
}

EOCPerson *tmp = [EOCPerson personWithName:@"Matt Galloway"]; 
_myPerson = objc_retainAutoreleasedReturnValue(tmp);
```

伪代码

``` objc
id objc_autoreleaseReturnValue(id object) { 
	if ( /* caller will retain object */ ) {
		set_flag(object);
		return object; ///< No autorelease 
	} else {
		return [object autorelease]; 
	}
}
	
id objc_retainAutoreleasedReturnValue(id object) { 
	if (get_flag(object)) {
		clear_flag(object);
		return object; ///< No retain 
	} else {
		return [object retain]; 
	}
}
```

## NSZombieEnabled

原理伪代码一

``` objc
// Obtain the class of the object being deallocated
Class cls = object_getClass(self); 
// Get the class's name
const char *clsName = class_getName(cls); 
// Prepend _NSZombie_ to the class name
const char *zombieClsName = "_NSZombie_" + clsName; 
// See if the specific zombie class exists
Class zombieCls = objc_lookUpClass(zombieClsName);
// If the specific zombie class doesn't exist, // then it needs to be created
if (!zombieCls) {
	// Obtain the template zombie class called _NSZombie_
	Class baseZombieCls = objc_lookUpClass("_NSZombie_");
	// Duplicate the base zombie class, where the new class's // name is the prepended string from 	above
	zombieCls = objc_duplicateClass(baseZombieCls,
	zombieClsName, 0);
}
// Perform normal destruction of the object being deallocated
objc_destructInstance(self);
// Set the class of the object being deallocated // to the zombie class
objc_setClass(self, zombieCls);
// The class of 'self' is now _NSZombie_OriginalClass
```

原理伪代码二

``` objc
// Obtain the object's class
Class cls = object_getClass(self); 
// Get the class's name
const char *clsName = class_getName(cls);
// Check if the class is prefixed with _NSZombie_
if (string_has_prefix(clsName, "_NSZombie_") { 
// If so, this object is a zombie

// Get the original class name by skipping past the
// _NSZombie_, i.e. taking the substring from character 10 
const char *originalClsName = substring_from(clsName, 10);
// Get the selector name of the message
const char *selectorName = sel_getName(_cmd);
// Log a message to indicate which selector is
// being sent to which zombie
Log("*** -[%s %s]: message sent to deallocated instance %p", originalClsName, selectorName, self);
// Kill the application
abort(); 
}
```

## 多线程之多读单写

多读单写指同一时刻允许多个线程同时读取，但只能有一个线程写入，并且该线程写入时，没有其他线程读取。

![](Images/多读单写.png)


## initialize

``` objc
//  AViewController
+ (void)initialize {
    if (self == [AViewController class]) {
        puts(">>> before A");
        BViewController *vc = [BViewController new];
        puts(">>> after A");
    }
}
```

``` objc
//  BViewController
+ (void)initialize {
    if (self == [BViewController class]) {
        puts(">>> before B");
        AViewController *vc = [AViewController new];
        puts(">>> after B");
    }
}
```

执行 `[AViewController new];`

结果：

``` objc
>>> before A
>>> before B
>>> after B
>>> after A
```

---

``` objc
static NSMutableArray *array;

+ (void)initialize {
    if (self == [AViewController class]) {
        array = [NSMutableArray new];
    }
}
```

``` objc
    [AViewController new];
    [array addObject:@"AAA"];
```

结果：**`array`中没有元素**



