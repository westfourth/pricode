# \_\_attribute\_\_

## \_\_attribute\_\_((weak))

``` c
int  __attribute__((weak))  func(void)
{
    ...
    return 0;
}
```

将func转成`弱符号类型`

* 如果遇到`强符号类型`（即外部模块定义了func，`extern int func(void);`），那么我们在本模块中执行的func将会是外部模块定义的func。
* 如果外部模块没有定义func，那么将会调用这个弱符号，相当于增加了一个默认函数。

**原理**：`链接器`发现：

* 如果同时存在`弱符号`和`强符号`，就先选择`强符号`。
* 如果发现`强符号`不存在，只存在`弱符号`，则选择`弱符号`。
* 如果都不存在，静态链接，编译时报错；动态链接，系统无法启动。

**weak属性只会在静态库中生效，动态库中不会生效。**


## __attribute__((objc_boxable))

**可以将`struct`类型、`union`类型 装成`NSValue`对象**


``` objc
typedef struct __attribute__((objc_boxable)) {
    CGFloat x, y, width, height;
} XXRect;
```

``` objc
@interface NSValue (XXRect)
@property (readonly) XXRect xxRectValue;
@end

@implementation NSValue (XXRect)

- (XXRect)xxRectValue {
    XXRect rect;
    [self getValue:&rect size:sizeof(XXRect)];
    return rect;
}

@end
```

使用

>
``` objc
XXRect rect1 = {1, 2, 3, 4};
NSValue *value = @(rect1);
XXRect rect2 = value.xxRectValue;
```

## __attribute__((enable_if))

**只能用在 C 函数上**

``` c
void check(NSUInteger age)
__attribute__((enable_if(age > 0 && age < 100, "年龄在0~100之间")))
{
    printf(">>> %ld\n", age);
}
```

调用
>
``` c
check(0);		//	编译错误
```