# UICollectionView


## 右对齐

<center>
<img src="Images/右对齐1.png" width=50% border=1 />
</center>

* **第1种：直接设置collectionView的属性**

``` objc
#	collectionView
self.collectionView.semanticContentAttribute = UISemanticContentAttributeForceRightToLeft;
```

* **第2种：子类化UICollectionViewFlowLayout**

``` objc
@interface AFLayout : UICollectionViewFlowLayout
@end

@implementation AFLayout

- (UIUserInterfaceLayoutDirection)developmentLayoutDirection {
    return UIUserInterfaceLayoutDirectionRightToLeft;
}

- (BOOL)flipsHorizontallyInOppositeLayoutDirection {
    return YES;
}

@end
```

* **第3种：分别对collectionView、cell使用transform**

``` objc
#	collectionView
self.collectionView.transform = CGAffineTransformMakeScale(-1, 1);

#	cell
cell.contentView.transform = CGAffineTransformMakeScale(-1, 1);
```

* **第4种：修改LayoutAttributes**

<center>
<img src="Images/右对齐2.png" width=50% border=1 />
<h6>严格右对齐</h6>
</center>

``` objc
@interface AFLayout : UICollectionViewFlowLayout
@end


@implementation AFLayout

- (NSArray<__kindof UICollectionViewLayoutAttributes *> *)layoutAttributesForElementsInRect:(CGRect)rect {
    NSArray<UICollectionViewLayoutAttributes *> *array = [super layoutAttributesForElementsInRect:rect];
    //  倒序遍历
    for (UICollectionViewLayoutAttributes *attributes in array.reverseObjectEnumerator) {
        UICollectionElementCategory category = attributes.representedElementCategory;
        if (category == UICollectionElementCategoryCell) {
            [self applyLayoutAttributes:attributes inArray:array];
        }
    }
    return array;
}

- (void)applyLayoutAttributes:(UICollectionViewLayoutAttributes *)attributes inArray:(NSArray<UICollectionViewLayoutAttributes *> *)array {
    UICollectionViewLayoutAttributes *rear = [self rearLayoutAttributes:attributes inArray:array];
    if (rear != nil) {
        if (CGRectGetMinX(rear.frame) - CGRectGetMaxX(attributes.frame) > self.minimumLineSpacing) {
            CGRect frame = attributes.frame;
            frame.origin.x = CGRectGetMinX(rear.frame) - self.minimumLineSpacing - CGRectGetWidth(frame);
            attributes.frame = frame;
        }
    } else {
        //  最后一个
        if (CGRectGetMaxX(attributes.frame) != CGRectGetMaxX(UIScreen.mainScreen.bounds)) {
            CGRect frame = attributes.frame;
            frame.origin.x = CGRectGetMaxX(UIScreen.mainScreen.bounds) - CGRectGetWidth(frame);
            attributes.frame = frame;
        }
    }
}

/**
    获取下一个 UICollectionViewLayoutAttributes，
 
    @return 如果返回nil，表示此 UICollectionViewLayoutAttributes 为此section最后一个
 */
- (nullable UICollectionViewLayoutAttributes *)rearLayoutAttributes:(UICollectionViewLayoutAttributes *)attributes inArray:(NSArray<UICollectionViewLayoutAttributes *> *)array {
    
    NSIndexPath *indexPath = attributes.indexPath;
    NSIndexPath *rearIndexPath = nil;
    NSInteger itemCount = [self.collectionView numberOfItemsInSection:indexPath.section];
    
    if (indexPath.item + 1 < itemCount) {
        rearIndexPath = [NSIndexPath indexPathForItem:indexPath.item + 1 inSection:indexPath.section];
    } else {
        return nil;
    }
    
    for (UICollectionViewLayoutAttributes *cur in array) {
        if (cur.indexPath.section == rearIndexPath.section && cur.indexPath.item == rearIndexPath.item) {
            return cur;
        }
    }
    return nil;
}

@end
```


## Decoration

<center>
<img src="Images/Decoration.png" width=50% border=1 />
</center>

* **AFDecoration**

``` objc
@interface AFDecoration : UICollectionReusableView
@end
```

* **AFLayout**

``` objc
@interface AFLayout : UICollectionViewFlowLayout
@end

@implementation AFLayout

- (void)prepareLayout {
    [super prepareLayout];
    
    //  注册
    [self registerClass:AFDecoration.class forDecorationViewOfKind:@"Dec"];
    
    self.decorationArray = [NSMutableArray new];
    NSInteger section = [self.collectionView numberOfSections];
    for (int i = 0; i < section; i++) {
        NSIndexPath *indexPath = [NSIndexPath indexPathForItem:0 inSection:i];
        UICollectionViewLayoutAttributes *attributes = [UICollectionViewLayoutAttributes layoutAttributesForDecorationViewOfKind:@"Dec" withIndexPath:indexPath];
        
        //  随便设置一个frame即可看到效果
        CGRect frame = CGRectMake(10, 100 + 200 * i, 300, 150);
        attributes.frame = frame;
        //  sectionHeader.zIndex = 10
        attributes.zIndex = 10;
        
        //  添加数据源
        [self.decorationArray addObject:attributes];
    }
}

//  调用次数 >= 1
- (NSArray<__kindof UICollectionViewLayoutAttributes *> *)layoutAttributesForElementsInRect:(CGRect)rect {
    NSMutableArray<UICollectionViewLayoutAttributes *> *array = [super layoutAttributesForElementsInRect:rect];
    //  cell + decoration
    [array addObjectsFromArray:self.decorationArray];
    return array;
}

```

## 动画

参考：[UICollectionView动画](https://www.liuchungui.com/2015/11/24/uicollectionviewdong-hua/)

```objc
@interface LCGLayout() {
    NSMutableArray *_insertedPaths;
    NSMutableArray *_deletedPaths;
}
@end

@implementation LCGLayout

- (nullable instancetype)initWithCoder:(NSCoder *)coder {
    self = [super initWithCoder:coder];
    if (self) {
        _insertedPaths = [NSMutableArray new];
        _deletedPaths = [NSMutableArray new];
    }
    return self;
}

- (void)prepareForCollectionViewUpdates:(NSArray<UICollectionViewUpdateItem *> *)updateItems {
    for (UICollectionViewUpdateItem *item in updateItems) {
        switch (item.updateAction) {
            case UICollectionUpdateActionInsert:
                [_insertedPaths addObject:item.indexPathAfterUpdate];
                break;
            case UICollectionUpdateActionDelete:
                [_deletedPaths addObject:item.indexPathBeforeUpdate];
                break;
            default:
                break;
        }
    }
}

- (void)finalizeCollectionViewUpdates {
    [_insertedPaths removeAllObjects];
    [_deletedPaths removeAllObjects];
}

- (UICollectionViewLayoutAttributes *)initialLayoutAttributesForAppearingItemAtIndexPath:(NSIndexPath *)itemIndexPath {
    UICollectionViewLayoutAttributes *attrs = [super initialLayoutAttributesForAppearingItemAtIndexPath:itemIndexPath];
    if ([_insertedPaths containsObject:itemIndexPath]) {
        attrs.transform = CGAffineTransformMakeScale(0.1, 0.1);
        attrs.alpha = 0;
    }
    return attrs;
}

- (UICollectionViewLayoutAttributes *)finalLayoutAttributesForDisappearingItemAtIndexPath:(NSIndexPath *)itemIndexPath {
    UICollectionViewLayoutAttributes *attrs = [super finalLayoutAttributesForDisappearingItemAtIndexPath:itemIndexPath];
    if ([_deletedPaths containsObject:itemIndexPath]) {
        attrs.transform = CGAffineTransformMakeScale(0.1, 0.1);
        attrs.alpha = 1;
    }
    return attrs;
}

@end
```

```objc
- (IBAction)delete:(id)sender {
    [_array removeLastObject];
    NSIndexPath *path = [NSIndexPath indexPathForItem:_array.count - 1 inSection:0];
    [self.collectionView performBatchUpdates:^{
        [self.collectionView deleteItemsAtIndexPaths:@[path]];
    } completion:^(BOOL finished) {
        
    }];
}

- (IBAction)add:(id)sender {
    [_array insertObject:[NSString stringWithFormat:@"Row - %ld", _array.count] atIndex:_array.count - 2];
    
    NSIndexPath *path = [NSIndexPath indexPathForItem:_array.count - 2 inSection:0];
    
    //  动画时间
    [UIViewPropertyAnimator runningPropertyAnimatorWithDuration:4 delay:0 options:0 animations:^{
        [self.collectionView performBatchUpdates:^{
            [self.collectionView insertItemsAtIndexPaths:@[path]];
        } completion:^(BOOL finished) {
            
        }];
    } completion:^(UIViewAnimatingPosition finalPosition) {

    }];
}
```
