# Debug Memory Graph

## 示例

```objc
@interface TestViewController ()
@property (nonatomic) void (^block)(void);
@end

@implementation TestViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.block = ^{
        self.view.backgroundColor = UIColor.redColor;
    };
    self.block();
}

@end
```

操作：连续4次进入、退出`TestViewController`


## 内存图

Xcode运行APP，点击 **Debug Memory Graph**

![](Images/debug_memory_graph.png)

左侧可以看到：有4个 `TestViewController` 未被释放。

## 查看被引用

点击右图 `TestViewController` 左上角，查看被引用关系。

![](Images/TestViewController_reference_by.png)

可见：`(TestViewController *)0x14b505fe0` 被 `__NSMallocBlock__: 0x2800cc030` 持有。

## 查看引用

点击右图 `TestViewController` 右上角，查看引用关系

![](Images/TestViewController_reference.png)

可见：`(TestViewController *)0x14b505fe0` 持有 `__NSMallocBlock__: 0x2800cc030` 。

## 展开查看引用关系

点击展开图标。

![](Images/__NSMallocBlock__Expand.png)

可以看到两者互相持有。

![](Images/TestViewController_Expand.png)

## Malloc Stack Logging

![](Images/malloc_stack_no_log.png)

右侧 **Backtrace** 为空。

开启 **Malloc Stack Logging**：

![](Images/malloc_stack_enabled.png)

> `malloc` remembers the function call stack at the time of each allocation.

重新运行app。

![](Images/malloc_stack_log.png)

这时候可以看到 **Backtrace**。

点击 **Backtrace** 黑色代码右侧箭头，即可进入初始化`TestViewController`的代码位置。

## 内存泄漏

1. Xcode运行APP，
1. 点击 **Debug Memory Graph**，
1. 再点击左侧 **Debug Navigator**，
1. 最后点击 **Show only leaked allocations**。

![](Images/show_only_leaked_allocations.png)

5. 点击 **Issue Navigator**，可以看到内存泄漏警告。

![](Images/leak_issue.png)

> 注意：和 **Instruments** -> **Leaks** 一样，有些未调用`CFRelease()`的内存泄漏是检测不到的。

