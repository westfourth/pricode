# Settings Bundle

## 说明

| 类型 | UI |
| :-: | :-: |
| Title | UILabel |
| Text field | UITextField |
| Toggle Switch | UISwitch |
| Slider | UISlider |
| Group | UITableView section |
| Multivalue | 列表选项 |
| Child pane | 子preference |

## 示例1
![](Images/preference_part1.png)
![](Images/preference_part2.png)

**效果：**

![](Images/result.png)

## 示例2
![](Images/preference_sub.png)

**效果：**

![](Images/result_sub.png)

区头部的小写字母显示时会自动变成大写字母，区尾部则原样展示。

区尾部应该展示：Group2，但Group2做了本地化，如下图：

![](Images/localization.png)

## 图片

图片直接放在Settings.bundle里面

![](Images/using_images.png)

## 偏好设置配置：Debug模式有，Release模式无

取消Target Membership

![](Images/cancel_target.png)

添加脚本

![](Images/run_script.png)

注意：如果Settings.bundle被拷贝进app了，那么它会一直存在，不需要时，需要清空DerivedData

## 使用注意

``` objc
    NSUserDefaults *ud = [NSUserDefaults standardUserDefaults];
    NSString *v1 = [ud objectForKey:@"title_preference"];
    NSString *v2 = [ud objectForKey:@"multi_preference"];
    NSString *v3 = [ud objectForKey:@"input_preference"];
    BOOL v4 = [[ud objectForKey:@"enabled_preference"] boolValue];
    float v5 = [[ud objectForKey:@"slider_preference"] floatValue];
```

第一次使用时，通过`objectForKey:`获取得到的值都为nil。只有在手动在**设置**中改变值，或者通过`NSUserDefaults`的`setObject:forKey:`改变值。


