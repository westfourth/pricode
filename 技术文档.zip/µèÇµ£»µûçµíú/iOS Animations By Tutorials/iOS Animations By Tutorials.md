# iOS Animations By Tutorials

## NSLayoutConstraint.active

当 `NSLayoutConstraint.active = NO`时，如果没有强引用，则会被销毁。

## CASpringAnimation

| 属性 | 说明 | 默认 |
| --- | --- | --: |
| damping | 阻尼（摩擦） | 10 |
| mass | 自身重 | 1 |
| stiffness | 重力 | 100 |
| initialVelocity | 初速度 | 0 |