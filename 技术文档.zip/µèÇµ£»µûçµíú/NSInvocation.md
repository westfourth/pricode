# NSInvocation

>
NSInvocation does not support invocations of methods with either variable numbers of arguments or union arguments

**翻译：**
>
`NSInvocation`不支持调用`可变长参数`的**方法**和**函数**，也不支持调用`union`参数

### 举例

```objc
- (int)addA:(int)a, ... {
    int ret = a;
    va_list ap;
    va_start(ap, a);
    int b = va_arg(ap, int);
    ret += b;
    va_end(ap);
    return ret;
}
```

### 正确

```objc
- (void)viewDidLoad {
    [super viewDidLoad];
    [self addA:11, 22];
}
```

### 错误

```objc
- (void)viewDidLoad {
    [super viewDidLoad];
    
    Class cls = self.class;
    SEL sel = @selector(addA:);
    Method m = class_getInstanceMethod(cls, sel);
    const char *types = method_getTypeEncoding(m);
    puts(types);
    
    NSMethodSignature *sig = [NSMethodSignature signatureWithObjCTypes:types];
    NSInvocation *inv = [NSInvocation invocationWithMethodSignature:sig];
    inv.target = self;
    inv.selector = sel;
    
    int a = 11;
    [inv setArgument:&a atIndex:2];
    int b = 22;
    [inv setArgument:&b atIndex:3];
    
    [inv invoke];
    int ret;
    [inv getReturnValue:&ret];
}
```

**报错**
>
Terminating app due to uncaught exception 'NSInvalidArgumentException', reason: '-[NSInvocation setArgument:atIndex:]: index (3) out of bounds [-1, 2]'

即表明使用`NSInvocation `调用`- (int)addA:(int)a, ...`方法时，只能传递一个参数


# 调用约定

```objc
- (int)increase:(int)a b:(int)b {
    return a + b;
}

int increase_v2(id obj, SEL sel, ...) {
    va_list ap;
    va_start(ap, sel);
    
    int a = va_arg(ap, int);
    int b = va_arg(ap, int);
    
    va_end(ap);
    return a + b;
}

- (void)viewDidLoad {
    [super viewDidLoad];

    Class cls = self.class;
    SEL sel0 = @selector(increase:b:);
    SEL sel1 = sel_registerName("increase2:");
    Method m = class_getInstanceMethod(cls, sel0);
    const char *types = method_getTypeEncoding(m);

    IMP imp = increase_v2;
    BOOL success = class_addMethod(cls, sel1, imp, types);
    
    //  正确调用
//    int b = ((int (*)(id, SEL, ...))objc_msgSend)(self, sel1, 11, 22);
    
    //  错误调用，没有遵循调用约定
    NSMethodSignature *sig = [NSMethodSignature signatureWithObjCTypes:types];
    NSInvocation *inv = [NSInvocation invocationWithMethodSignature:sig];
    inv.target = self;
    inv.selector = sel1;
    
    int a = 11;
    [inv setArgument:&a atIndex:2];
    int b = 22;
    [inv setArgument:&b atIndex:3];
    
    [inv invoke];
    int r;
    [inv getReturnValue:&r];
}
```







