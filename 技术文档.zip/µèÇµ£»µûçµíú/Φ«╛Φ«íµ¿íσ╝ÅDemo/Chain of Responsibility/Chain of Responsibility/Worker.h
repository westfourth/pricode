//
//  Worker.h
//  Chain of Responsibility
//
//  Created by mac on 2020/7/17.
//  Copyright © 2020 mac. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger, WorkType) {
    WorkTypeDesign,
    WorkTypeCoding,
    WorkTypeTest,
};

@interface Worker : NSObject

@property WorkType type;
@property Worker *next;

//  Worker是处理对象，message、type是命令对象
- (void)work:(NSString *)message type:(WorkType)type;

@end

NS_ASSUME_NONNULL_END
