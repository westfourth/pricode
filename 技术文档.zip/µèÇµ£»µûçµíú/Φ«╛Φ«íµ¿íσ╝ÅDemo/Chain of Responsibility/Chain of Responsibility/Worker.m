//
//  Worker.m
//  Chain of Responsibility
//
//  Created by mac on 2020/7/17.
//  Copyright © 2020 mac. All rights reserved.
//

#import "Worker.h"

@implementation Worker

- (void)work:(NSString *)message type:(WorkType)type {
    if (type == self.type) {
        //  处理
        NSLog(@">>> %@ - %@ - %ld", [self class], message, type);
    } else {
        //  继续传递
        [_next work:message type:type];
    }
}

@end
