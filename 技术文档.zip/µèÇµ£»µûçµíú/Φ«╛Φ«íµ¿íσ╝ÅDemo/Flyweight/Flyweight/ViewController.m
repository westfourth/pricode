//
//  ViewController.m
//  Flyweight
//
//  Created by mac on 2020/7/16.
//  Copyright © 2020 mac. All rights reserved.
//

#import "ViewController.h"
#import "Worker.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    Worker *a = [Worker new];
    a.ID = 123;
    NSMutableArray *array = [NSMutableArray new];
    for (int i = 0; i < 1e6; i++) {
        //  同一个对象，享元模式
        [array addObject:a];
    }
    puts(__func__);
}


@end
