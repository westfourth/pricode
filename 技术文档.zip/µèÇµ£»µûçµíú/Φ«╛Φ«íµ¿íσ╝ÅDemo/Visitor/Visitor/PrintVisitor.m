//
//  PrintVisitor.m
//  Visitor
//
//  Created by mac on 2020/7/20.
//  Copyright © 2020 mac. All rights reserved.
//

#import "PrintVisitor.h"
#import "Wheel.h"
#import "Engine.h"
#import "Car.h"

@implementation PrintVisitor

- (void)visitCar:(nonnull Car *)car {
    puts(">>> 访问Car");
}

- (void)visitEngine:(nonnull Engine *)engine {
    puts(">>> 访问发动机");
}

- (void)visitWheel:(nonnull Wheel *)wheel {
    printf(">>> 访问轮胎: %s\n", wheel.name.UTF8String);
}

@end
