//
//  Car.m
//  Visitor
//
//  Created by mac on 2020/7/20.
//  Copyright © 2020 mac. All rights reserved.
//

#import "Car.h"
#import "Wheel.h"
#import "Engine.h"

@interface Car () {
    Engine *_engine;
    NSMutableArray<Wheel *> *_wheels;
}

@end

@implementation Car

- (instancetype)init
{
    self = [super init];
    if (self) {
        _engine = [Engine new];
        _wheels = [NSMutableArray new];
        NSArray *names = @[@"左前", @"右前", @"左后", @"左后"];
        for (int i = 0; i < names.count; i++) {
            Wheel *wheel = [Wheel new];
            wheel.name = names[i];
            [_wheels addObject:wheel];
        }
    }
    return self;
}

- (void)accept:(nonnull id<Visitor>)visitor {
    [visitor visitCar:self];
    [_engine accept:visitor];
    for (int i = 0; i < _wheels.count; i++) {
        Wheel *wheel = _wheels[i];
        [wheel accept:visitor];
    }
}

@end
