//
//  Visitor.h
//  Visitor
//
//  Created by mac on 2020/7/20.
//  Copyright © 2020 mac. All rights reserved.
//

#import <Foundation/Foundation.h>
@class Wheel;
@class Engine;
@class Car;

NS_ASSUME_NONNULL_BEGIN

@protocol Visitor <NSObject>

- (void)visitEngine:(Engine *)engine;
- (void)visitWheel:(Wheel *)wheel;
- (void)visitCar:(Car *)car;

@end

@protocol Acceptor <NSObject>

- (void)accept:(id<Visitor>)visitor;

@end

NS_ASSUME_NONNULL_END
