//
//  Wheel.h
//  Visitor
//
//  Created by mac on 2020/7/20.
//  Copyright © 2020 mac. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Visitor.h"

NS_ASSUME_NONNULL_BEGIN

@interface Wheel : NSObject <Acceptor>

@property NSString *name;

@end

NS_ASSUME_NONNULL_END
