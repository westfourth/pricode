//
//  Worker.h
//  Memento
//
//  Created by mac on 2020/7/18.
//  Copyright © 2020 mac. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

//  Originator
@interface Worker : NSObject

@property NSString *name;
@property NSInteger age;

- (void)save;
- (void)restore;

@end

NS_ASSUME_NONNULL_END
