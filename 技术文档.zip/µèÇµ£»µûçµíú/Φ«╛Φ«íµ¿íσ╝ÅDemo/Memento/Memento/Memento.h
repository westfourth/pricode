//
//  Memento.h
//  Memento
//
//  Created by mac on 2020/7/18.
//  Copyright © 2020 mac. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Worker.h"

NS_ASSUME_NONNULL_BEGIN

//  Memento通常是磁盘文件、内存
@interface Memento : NSObject

- (instancetype)initWithState:(Worker *)worker;
- (Worker *)state;

@end

NS_ASSUME_NONNULL_END
