//
//  LoginSuccessState.m
//  State
//
//  Created by mac on 2020/7/18.
//  Copyright © 2020 mac. All rights reserved.
//

#import "LoginSuccessState.h"

@implementation LoginSuccessState

@synthesize loginingEnabled;
@synthesize loginSuccessEnabled;
@synthesize loginFailedEnabled;

- (instancetype)init {
    self = [super init];
    if (self) {
        loginingEnabled = NO;
        loginSuccessEnabled = YES;
        loginFailedEnabled = NO;
    }
    return self;
}

- (void)login:(Context *)ctx {
    NSAssert(NO, @"不可用");
}

- (void)loginFailed:(Context *)ctx {
    NSAssert(NO, @"不可用");
}

- (void)loginSuccess:(Context *)ctx {
    puts(">>> 登陆成功");
}

@end
