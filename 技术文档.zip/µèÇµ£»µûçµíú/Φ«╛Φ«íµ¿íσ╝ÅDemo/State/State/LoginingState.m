//
//  LoginingState.m
//  State
//
//  Created by mac on 2020/7/18.
//  Copyright © 2020 mac. All rights reserved.
//

#import "LoginingState.h"
#import "Context.h"

@implementation LoginingState

@synthesize loginingEnabled;
@synthesize loginSuccessEnabled;
@synthesize loginFailedEnabled;

- (instancetype)init {
    self = [super init];
    if (self) {
        loginingEnabled = YES;
        loginSuccessEnabled = NO;
        loginFailedEnabled = NO;
    }
    return self;
}

- (void)login:(Context *)ctx {
    puts(">>> 正在登陆");
    BOOL flag = arc4random_uniform(2);
    printf(">>> flag = %d\n", flag);
    if (flag) {
        ctx.state = Context.loginSuccessState;
    } else {
        ctx.state = Context.loginFailedState;
    }
}

- (void)loginFailed:(Context *)ctx {
    NSAssert(NO, @"不可用");
}

- (void)loginSuccess:(Context *)ctx {
    NSAssert(NO, @"不可用");
}

@end
