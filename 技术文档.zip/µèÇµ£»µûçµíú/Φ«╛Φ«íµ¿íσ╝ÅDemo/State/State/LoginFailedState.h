//
//  LoginFailedState.h
//  State
//
//  Created by mac on 2020/7/18.
//  Copyright © 2020 mac. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "State.h"

NS_ASSUME_NONNULL_BEGIN

@interface LoginFailedState : NSObject <State>

@end

NS_ASSUME_NONNULL_END
