//
//  ViewController.m
//  State
//
//  Created by mac on 2020/7/18.
//  Copyright © 2020 mac. All rights reserved.
//

#import "ViewController.h"
#import "Context.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    Context *ctx = [Context new];
    ctx.state = Context.loginingState;
    [ctx login];
    [ctx loginSuccess];
}


@end
