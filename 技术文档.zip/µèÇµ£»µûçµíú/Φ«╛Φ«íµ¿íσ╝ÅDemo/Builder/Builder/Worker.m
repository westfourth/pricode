//
//  Worker.m
//  Prototype
//
//  Created by mac on 2020/7/14.
//  Copyright © 2020 mac. All rights reserved.
//

#import "Worker.h"
#import "WorkerBuilder.h"

@implementation Worker

- (WorkerBuilder *)builder {
    return [[WorkerBuilder alloc] initWithWorker:self];
}

@end
