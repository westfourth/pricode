//
//  ViewController.m
//  Observer
//
//  Created by mac on 2020/7/18.
//  Copyright © 2020 mac. All rights reserved.
//

#import "ViewController.h"
#import "NotifyCenter.h"

@interface ViewController () {
    NotifyCenter *_center;
}

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    _center = [NotifyCenter new];
    //  监听
    [_center addObserver:self selector:@selector(observe:) object:nil];
    
    //  状态改变代码...
    
    //  发出
    [_center post:nil];
    //  移除
    [_center removeObserver:self];
}

- (void)observe:(nullable id)object {
    puts(__func__);
}

@end
