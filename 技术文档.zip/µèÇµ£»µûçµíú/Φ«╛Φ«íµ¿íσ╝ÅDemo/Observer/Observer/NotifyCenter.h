//
//  NotifyCenter.h
//  Observer
//
//  Created by mac on 2020/7/18.
//  Copyright © 2020 mac. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface NotifyCenter : NSObject

- (void)addObserver:(id)observer selector:(SEL)aSelector object:(nullable id)object;
- (void)removeObserver:(id)observer;

- (void)post:(nullable id)object;

@end

NS_ASSUME_NONNULL_END
