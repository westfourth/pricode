//
//  ViewController.m
//  Decorator
//
//  Created by mac on 2020/7/16.
//  Copyright © 2020 mac. All rights reserved.
//

#import "ViewController.h"
#import "Worker.h"
#import "WorkerDecorator.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    Worker *w = [Worker new];
    //
    [WorkerDecorator decorate:w];
    //
    [(Worker<Work> *)w work];
    
}




@end
