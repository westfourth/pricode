//
//  ViewController.m
//  Mediator
//
//  Created by mac on 2020/7/17.
//  Copyright © 2020 mac. All rights reserved.
//

#import "ViewController.h"
#import "CodingWorker.h"
#import "TestWorker.h"
#import "Mediator.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    CodingWorker *c = [CodingWorker new];
    c.name = @"张三";
    
    TestWorker *t = [TestWorker new];
    t.name = @"赵四";
    
    Mediator *m = [Mediator new];
    [m registerCoder:c];
    [m registerTester:t];
    
    [c code:1];
}


@end
