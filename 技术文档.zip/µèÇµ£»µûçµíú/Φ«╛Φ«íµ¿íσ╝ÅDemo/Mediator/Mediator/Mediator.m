//
//  Mediator.m
//  Mediator
//
//  Created by mac on 2020/7/17.
//  Copyright © 2020 mac. All rights reserved.
//

#import "Mediator.h"
#import "CodingWorker.h"
#import "TestWorker.h"

@interface Mediator () {
    CodingWorker *_coder;
    TestWorker *_tester;
}

@end

@implementation Mediator

- (void)registerCoder:(CodingWorker *)coder {
    _coder = coder;
    _coder.mediator = self;
}

- (void)registerTester:(TestWorker *)tester {
    _tester = tester;
    _tester.mediator = self;
}

- (void)code:(NSInteger)num {
    [_coder code:num];
}

- (void)test:(NSInteger)num {
    [_tester test:num];
}

@end
