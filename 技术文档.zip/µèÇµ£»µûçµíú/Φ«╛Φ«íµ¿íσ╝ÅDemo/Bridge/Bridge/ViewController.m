//
//  ViewController.m
//  Bridge
//
//  Created by mac on 2020/7/16.
//  Copyright © 2020 mac. All rights reserved.
//

#import "ViewController.h"
#import "DesignWork.h"
#import "CodingWork.h"
#import "Worker.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    DesignWork *d = [DesignWork new];
    CodingWork *c = [CodingWork new];
    
    Worker *w = [Worker new];
    w.name = @"Tom";
    w.age = 33;
    
    [w work:d];
    [w work:c];
}


@end
