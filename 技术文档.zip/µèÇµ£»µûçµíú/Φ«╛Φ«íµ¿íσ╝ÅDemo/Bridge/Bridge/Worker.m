//
//  Worker.m
//  Bridge
//
//  Created by mac on 2020/7/16.
//  Copyright © 2020 mac. All rights reserved.
//

#import "Worker.h"

@implementation Worker

- (void)work:(id<Work>)work {
    [work work:self.name age:self.age];
}

@end
