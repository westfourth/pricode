//
//  CodingWork.m
//  Bridge
//
//  Created by mac on 2020/7/16.
//  Copyright © 2020 mac. All rights reserved.
//

#import "CodingWork.h"

@implementation CodingWork

- (void)work:(NSString *)name age:(NSInteger)age {
    printf(">>> %s-%ld, 开始编码\n", name.UTF8String, age);
}

@end
