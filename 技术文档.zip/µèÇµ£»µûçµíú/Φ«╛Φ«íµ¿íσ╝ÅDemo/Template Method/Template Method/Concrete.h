//
//  Concrete.h
//  Template Method
//
//  Created by mac on 2020/7/18.
//  Copyright © 2020 mac. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "LifeCircle.h"

NS_ASSUME_NONNULL_BEGIN

@interface Concrete : NSObject <LifeCircle>

@end

NS_ASSUME_NONNULL_END
