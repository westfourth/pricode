//
//  ObjectAdapter.h
//  Adapter
//
//  Created by mac on 2020/7/16.
//  Copyright © 2020 mac. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Worker.h"

NS_ASSUME_NONNULL_BEGIN

//  对象适配器模式
@interface ObjectAdapter : NSObject

@property (nonatomic) Worker *worker;

- (void)run;

@end

NS_ASSUME_NONNULL_END
