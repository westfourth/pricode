//
//  Worker.m
//  Adapter
//
//  Created by mac on 2020/7/16.
//  Copyright © 2020 mac. All rights reserved.
//

#import "Worker.h"

@implementation Worker

- (void)work {
    printf(">>> 开始工作\n");
}

@end
