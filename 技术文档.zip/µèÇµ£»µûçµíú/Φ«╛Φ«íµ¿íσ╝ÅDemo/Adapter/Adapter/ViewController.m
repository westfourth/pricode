//
//  ViewController.m
//  Adapter
//
//  Created by mac on 2020/7/16.
//  Copyright © 2020 mac. All rights reserved.
//

#import "ViewController.h"
#import "ObjectAdapter.h"
#import "ClassAdapter.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    //  对象适配器模式
    Worker *w = [Worker new];
    ObjectAdapter *a = [ObjectAdapter new];
    a.worker = w;
    [a run];
    
    //  类适配器模式
    ClassAdapter *c = [ClassAdapter new];
    [c run];
}


@end
