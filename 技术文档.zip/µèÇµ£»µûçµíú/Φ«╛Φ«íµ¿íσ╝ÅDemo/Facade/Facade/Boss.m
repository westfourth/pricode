//
//  Boss.m
//  Facade
//
//  Created by mac on 2020/7/16.
//  Copyright © 2020 mac. All rights reserved.
//

#import "Boss.h"

@implementation Boss

- (void)manage {
    printf(">>> boss-%s manage\n", [self.name UTF8String]);
}

@end
