//
//  ViewController.m
//  Facade
//
//  Created by mac on 2020/7/16.
//  Copyright © 2020 mac. All rights reserved.
//

#import "ViewController.h"
#import "Company.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    Boss *b = [Boss new];
    b.name = @"老板";
    
    Worker *w1 = [Worker new];
    w1.name = @"员工A";
    
    Worker *w2 = [Worker new];
    w2.name = @"员工B";
    
    Worker *w3 = [Worker new];
    w3.name = @"员工C";
    
    Company *c = [Company new];
    c.boss = b;
    c.workers = @[w1, w2, w3];
    
    [c produce];
}


@end
