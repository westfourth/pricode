//
//  Worker.m
//  Prototype
//
//  Created by mac on 2020/7/14.
//  Copyright © 2020 mac. All rights reserved.
//

#import "Worker.h"

@implementation Worker

- (void)work {
    printf(">>> worker-%s work\n", [self.name UTF8String]);
}

@end
