//
//  Company.h
//  Facade
//
//  Created by mac on 2020/7/16.
//  Copyright © 2020 mac. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Boss.h"
#import "Worker.h"

NS_ASSUME_NONNULL_BEGIN

@interface Company : NSObject

@property (nonatomic) Boss *boss;
@property (nonatomic) NSArray<Worker *> *workers;

//  外观模式
- (void)produce;

@end

NS_ASSUME_NONNULL_END
