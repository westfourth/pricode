//
//  Worker.m
//  Prototype
//
//  Created by mac on 2020/7/14.
//  Copyright © 2020 mac. All rights reserved.
//

#import "Worker.h"

@implementation Worker

- (void)setAge:(NSInteger)age {
    _age = age;
    [self.delegate worker:self didChangeAge:age];
}

@end
