//
//  Worker.h
//  Prototype
//
//  Created by mac on 2020/7/14.
//  Copyright © 2020 mac. All rights reserved.
//

#import <Foundation/Foundation.h>
@protocol WorkerDelegate;

NS_ASSUME_NONNULL_BEGIN

@interface Worker : NSObject

@property (weak) id<WorkerDelegate> delegate;

@property (nonatomic) NSString *name;
@property (nonatomic) NSInteger age;

@end


@protocol WorkerDelegate <NSObject>

- (void)worker:(Worker *)worker didChangeAge:(NSInteger)age;

@end

NS_ASSUME_NONNULL_END
