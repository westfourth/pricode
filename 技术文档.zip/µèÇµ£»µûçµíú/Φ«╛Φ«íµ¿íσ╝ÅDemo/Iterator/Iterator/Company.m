//
//  Company.m
//  Iterator
//
//  Created by mac on 2020/7/17.
//  Copyright © 2020 mac. All rights reserved.
//

#import "Company.h"

@interface Company () <Iterator> {
    NSMutableArray<Worker *> *_workers;
    NSInteger _cur;
}

@end

@implementation Company

- (instancetype)init {
    self = [super init];
    if (self) {
        _workers = [NSMutableArray new];
        _cur = 0;
    }
    return self;
}

- (void)addWorker:(Worker *)worker {
    [_workers addObject:worker];
}

- (id<Iterator>)iterate {
    return self;
}

//MARK:-    Iterator

- (id)current {
    return _workers[_cur];
}

- (id)first {
    _cur = 0;
    return _workers.firstObject;
}

- (BOOL)isDone {
    if (_cur >= _workers.count) {
        return YES;
    }
    return NO;
}

- (id)next {
    if (++_cur < _workers.count) {
        return _workers[_cur];
    }
    return nil;
}

@end
