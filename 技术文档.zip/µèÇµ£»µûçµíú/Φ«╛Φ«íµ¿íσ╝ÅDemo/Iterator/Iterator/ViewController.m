//
//  ViewController.m
//  Iterator
//
//  Created by mac on 2020/7/17.
//  Copyright © 2020 mac. All rights reserved.
//

#import "ViewController.h"
#import "Company.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    Worker *w1 = [Worker new];
    w1.name = @"AAA";
    
    Worker *w2 = [Worker new];
    w2.name = @"BBB";
    
    Worker *w3 = [Worker new];
    w3.name = @"CCC";
    
    Company *c = [Company new];
    [c addWorker:w1];
    [c addWorker:w2];
    [c addWorker:w3];
    
    id<Iterator> iterator = [c iterate];
    [iterator first];
    while (![iterator isDone]) {
        Worker *w = [iterator current];
        NSLog(@">>> %@", w.name);
        [iterator next];
    }
}


@end
