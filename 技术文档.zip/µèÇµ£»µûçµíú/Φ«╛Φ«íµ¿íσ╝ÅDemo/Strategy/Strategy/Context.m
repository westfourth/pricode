//
//  Context.m
//  Strategy
//
//  Created by mac on 2020/7/18.
//  Copyright © 2020 mac. All rights reserved.
//

#import "Context.h"

@implementation Context

- (void)doSomething {
    [self.strategy execute];
}

@end
