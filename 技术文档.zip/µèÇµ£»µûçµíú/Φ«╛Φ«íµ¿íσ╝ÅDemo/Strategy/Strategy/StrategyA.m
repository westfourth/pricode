//
//  StrategyA.m
//  Strategy
//
//  Created by mac on 2020/7/18.
//  Copyright © 2020 mac. All rights reserved.
//

#import "StrategyA.h"

@implementation StrategyA

- (void)execute {
    puts(">>> StrategyA");
}

@end
