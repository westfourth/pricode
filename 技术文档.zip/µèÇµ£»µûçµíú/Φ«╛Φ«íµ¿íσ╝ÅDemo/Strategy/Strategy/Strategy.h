//
//  Strategy.h
//  Strategy
//
//  Created by mac on 2020/7/18.
//  Copyright © 2020 mac. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@protocol Strategy <NSObject>

- (void)execute;

@end

NS_ASSUME_NONNULL_END
