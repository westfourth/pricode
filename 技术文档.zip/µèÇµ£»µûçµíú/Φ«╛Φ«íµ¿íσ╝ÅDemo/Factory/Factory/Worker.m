//
//  Worker.m
//  Factory
//
//  Created by mac on 2020/7/15.
//  Copyright © 2020 mac. All rights reserved.
//

#import "Worker.h"

@implementation Worker

+ (instancetype)createInstance {
    return [Worker new];
}

@end
