//
//  Nurse.m
//  Factory
//
//  Created by mac on 2020/7/15.
//  Copyright © 2020 mac. All rights reserved.
//

#import "Nurse.h"

@implementation Nurse

+ (instancetype)createInstance {
    return [Nurse new];
}

@end
