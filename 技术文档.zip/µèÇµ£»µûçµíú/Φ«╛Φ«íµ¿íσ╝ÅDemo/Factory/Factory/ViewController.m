//
//  ViewController.m
//  Factory
//
//  Created by mac on 2020/7/15.
//  Copyright © 2020 mac. All rights reserved.
//

#import "ViewController.h"
#import "Worker.h"
#import "Doctor.h"
#import "Nurse.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    Worker *w = [Worker createInstance];
    Doctor *d = [Doctor createInstance];
    Nurse *n = [Nurse createInstance];
    puts(__func__);
}


@end
