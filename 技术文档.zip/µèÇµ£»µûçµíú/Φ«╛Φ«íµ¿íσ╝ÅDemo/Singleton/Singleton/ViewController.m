//
//  ViewController.m
//  Singleton
//
//  Created by mac on 2020/7/15.
//  Copyright © 2020 mac. All rights reserved.
//

#import "ViewController.h"
#import "Worker.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    Worker *a = [Worker shareInstance];
    Worker *b = [[Worker alloc] init];
    Worker *c = [Worker new];
    Worker *d = [a copy];
    puts(__func__);
}


@end
