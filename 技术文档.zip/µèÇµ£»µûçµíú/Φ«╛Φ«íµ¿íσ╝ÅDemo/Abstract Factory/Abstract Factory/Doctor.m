//
//  Doctor.m
//  Factory
//
//  Created by mac on 2020/7/15.
//  Copyright © 2020 mac. All rights reserved.
//

#import "Doctor.h"

@implementation Doctor

- (void)work {
    printf(">>> Doctor work\n");
}

@end
