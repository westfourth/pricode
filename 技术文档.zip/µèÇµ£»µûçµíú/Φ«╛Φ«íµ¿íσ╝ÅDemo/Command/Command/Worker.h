//
//  Worker.h
//  Prototype
//
//  Created by mac on 2020/7/14.
//  Copyright © 2020 mac. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface Worker : NSObject

//  参数
@property (nonatomic) NSString *name;

//  行动
- (void)work;

@end

NS_ASSUME_NONNULL_END
