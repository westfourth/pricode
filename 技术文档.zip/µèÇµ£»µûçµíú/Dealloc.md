# Dealloc

## 思考

判断下面哪种方式是可行的？

### 方式1

```objc
+ (void)load {
    SEL sel = sel_registerName("dealloc");
    Method m = class_getInstanceMethod([Test class], sel);
    IMP imp0 = method_getImplementation(m);
    IMP imp1 = imp_implementationWithBlock(^void(Test *self) {
        puts(">>>>");
        ((void (*)(Test *, SEL))imp0)(self, sel);
    });
    method_setImplementation(m, imp1);
}
```

### 方式2

```objc
+ (void)load {
    SEL sel = sel_registerName("dealloc");
    Method m = class_getInstanceMethod([Test class], sel);
    const char *s = method_getTypeEncoding(m);
    IMP imp0 = method_getImplementation(m);
    IMP imp1 = imp_implementationWithBlock(^void(Test *self) {
        puts(">>>>");
        ((void (*)(Test *, SEL))imp0)(self, sel);
    });
    class_replaceMethod([Test class], sel, imp1, "v16@0:8");
}

```

### 方式3

```objc
+ (void)load {
    SEL sel = sel_registerName("dealloc");
    Method m = class_getInstanceMethod([Test class], sel);
    SEL sel2 = sel_registerName("dealloc2");
    Method m2 = class_getInstanceMethod([Test class], sel2);
    method_exchangeImplementations(m, m2);
}

- (void)dealloc2 {
    puts(">>>>");
    [self dealloc2];
}
```

### 方式4

```objc
+ (void)load {
    SEL sel = sel_registerName("dealloc");
    Method m = class_getInstanceMethod([Test class], sel);
    IMP imp0 = method_getImplementation(m);
    IMP imp1 = imp_implementationWithBlock(^void(__unsafe_unretained Test *self) {
        puts(">>>>");
        ((void (*)(Test *, SEL))imp0)(self, sel);
    });
    method_setImplementation(m, imp1);
}
```

## 结果

只有 **方式3**、**方式4** 是可行的