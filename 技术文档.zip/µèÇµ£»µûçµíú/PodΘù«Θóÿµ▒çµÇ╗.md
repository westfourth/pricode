## 1. `pod trunk push`后`pod search XXX`不到库

``` sh
$ pod repo

master
- Type: git (remotes/origin/master)
- URL:  https://mirrors.tuna.tsinghua.edu.cn/git/CocoaPods/Specs.git
- Path: /Users/xisi/.cocoapods/repos/master

trunk
- Type: CDN
- URL:  https://cdn.cocoapods.org/
- Path: /Users/xisi/.cocoapods/repos/trunk

westfourth-htmlrequest
- Type: git (main)
- URL:  https://github.com/westfourth/HTMLRequest.git
- Path: /Users/xisi/.cocoapods/repos/westfourth-htmlrequest

3 repos
```

执行`pod repo remove <指定库>`，删除上面的`westfourth-htmlrequest`

## 2. `pod trunk push`后`pod search XXX`不到最新版本

`pod trunk push`过10～15分钟后，执行`pod update XXX`

## 3. `pod lib lint --verbose` 失败

```sh
    The following build commands failed:
    	Ld /Users/xisi/Library/Developer/Xcode/DerivedData/App-aaeqmcjizwqpbsctrkgyjqkolydv/Build/Intermediates.noindex/Pods.build/Release-iphonesimulator/hpple.build/Objects-normal/x86_64/Binary/hpple normal x86_64 (in target 'hpple' from project 'Pods')
```

处理：`pod lib lint --use-libraries --allow-warnings`


## 4. 统一指定最小部署版本

```ruby
post_install do |installer|
  installer.pods_project.targets.each do |target|
    target.build_configurations.each do |config|
      config.build_settings['IPHONEOS_DEPLOYMENT_TARGET'] = '14.0'
    end
  end
end
```

## 5. pod库文件找不到，或者pod有异常

```sh
# 1. 清理缓存
pod cache clean --all
# 2. 移除集成
pod deintegrate
# 3. 添加集成
pod install
```