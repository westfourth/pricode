# Static Analyzer

静态代码分析

步骤：**Xcode** --> **Product** --> **Analyze**


## 可分析类型

### Security Issues

1. Uninitialized Memory（未初始化的内存）
1. Memory Leaks（内存泄漏）
1. Use After Move
1. Use of Strcpy
1. Unchecked Return
1. Values
1. Violation of Reference Counting Rules
1. Use of Rand Functions

### Logical Bugs

1. Null Pointer Deference
1. Division by Zero
1. Dead Stores（死存储是一种局部变量，它被赋值但后续指令不会读取它）
1. Unused Ivars
1. Misuse of Nonnull（非空误用）
1. Method Signatures Mismatch
1. Misuse of Objective-C Generics（Objective-C范型误用）

### Misuses of API's

1. Collection API Misuses
1. Dispatch Anti-Patterns
1. Missing Localizability
1. Improper Handing of NSError

### New Checkes in Xcode 13

1. Infinite Loops
1. Unused and Redundant code
1. Side Effect in Asserts（Assert副作用）
1. C++ Move Misuses

## 举例

### 内存泄漏

**问题：**

![](Images/memory_leak.png)

**处理：**

![](Images/memory_leak_fix.png)


### 死存储

**问题：**

![](Images/dead_store.png)

**处理：**

![](Images/dead_store_fix.png)


### 非空误用

**问题：**

![](Images/misuse_nonnull.png)

**处理：**

![](Images/misuse_nonnull_fix.png)


### 未初始化的内存（变量未初始化）

**问题：**

![](Images/uninitialized_memory.png)

**处理：**

![](Images/uninitialized_memory_fix.png)


### Objective-C范型误用

**问题：**

![](Images/misuse_generic.png)

**处理：**

![](Images/misuse_generic_fix.png)


### Assert副作用

**问题：**

![](Images/assert_side_effect.png)

**处理：**

![](Images/assert_side_effect_fix.png)