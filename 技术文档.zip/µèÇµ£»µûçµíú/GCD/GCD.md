# GCD

## 串行与并行

![](Images/serial_concurrent.png)

- 串行队列：上一个任务执行完之后，才执行下一个任务。
- 并行队列：不等上一个任务执行完，就执行下一个任务。

## 队列与线程的关系
![](Images/queue_thread.png)

XNU 内核是 iOS 和 OS X 的核心部分，它决定线程数。它还会创建线程来执行任务。当任务完成并且正在运行的任务数减少时，XNU 内核会终止不需要的线程。只需使用并发调度队列，XNU 内核就可以完美地管理多个线程以并发运行任务。

## 并行举例

假设有四个线程为并发调度队列准备，

![](Images/concurrent_task_example.png)

blk4 在 Thread0 上执行，因为 blk0 结束了；同理：

blk5 在 Thread2 上执行，因为 blk2 结束了。

## 串行调度队列

当创建串行调度队列并添加任务时，系统会为每个串行调度队列创建一个线程。

![](Images/multiple_serial_dispatch_queues.png)

## dispatch_set_target_queue

- 变更队列的优先级。
- 将当前调度队列中的所有任务重定向到指定的目标队列。

### 变更优先级

```objc
    dispatch_queue_t serialQueue = dispatch_queue_create("q1", DISPATCH_QUEUE_SERIAL);
    dispatch_queue_t globalQueue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
    dispatch_queue_t targetQueue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0);
    
    dispatch_set_target_queue(serialQueue, targetQueue);
    
    dispatch_async(serialQueue, ^{
        NSLog(@">>> Low priority");
    });
    
    dispatch_async(globalQueue, ^{
        NSLog(@">>> High priority");
    });
```

**输出：**

30次执行，有20次先输出 `>>> High priority`

> **注意：当您将系统提供的主调度队列或全局调度队列作为第一个参数传递时，行为是未定义的。**

### 重定向任务

```objc
    dispatch_queue_t q1 = dispatch_queue_create("q1", DISPATCH_QUEUE_CONCURRENT);
    dispatch_queue_t q2 = dispatch_queue_create("q2", DISPATCH_QUEUE_SERIAL);
    dispatch_queue_t q3 = dispatch_queue_create("q3", DISPATCH_QUEUE_SERIAL);
//    dispatch_queue_t q3 = dispatch_get_global_queue(0, 0);
    
    dispatch_queue_t targetQueue = dispatch_queue_create("serial", DISPATCH_QUEUE_SERIAL);
//    dispatch_queue_t targetQueue = dispatch_queue_create("concurrent", DISPATCH_QUEUE_CONCURRENT);
//    dispatch_queue_t targetQueue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0);
    
    dispatch_set_target_queue(q1, targetQueue);
    dispatch_set_target_queue(q2, targetQueue);
    dispatch_set_target_queue(q3, targetQueue);
    

    dispatch_async(q1, ^{
        NSLog(@"q1 = %@", NSThread.currentThread);
        NSLog(@"1");
    });

    dispatch_async(q2, ^{
        NSLog(@"q2 = %@", NSThread.currentThread);
        NSLog(@"2");
    });

    dispatch_async(q3, ^{
        NSLog(@"q3 = %@", NSThread.currentThread);
        NSLog(@"3");
    });
```

**输出：**

```sh
q1 = <NSThread: 0x6000011ec340>{number = 2, name = (null)}
1
q2 = <NSThread: 0x6000011ec340>{number = 2, name = (null)}
2
q3 = <NSThread: 0x6000011ec340>{number = 2, name = (null)}
3
```

## dispatch_after

不是在指定时间后执行任务，而是在指定时间后将任务添加到队列中。

## dispatch_barrier_async

等待队列中的其他任务

![](Images/dispatch_barrier_async.png)

```objc
    NSLog(@"start %@", NSThread.currentThread);
    dispatch_queue_t queue = dispatch_queue_create("barrier", DISPATCH_QUEUE_CONCURRENT);
    
    dispatch_async(queue, ^{ sleep(1); NSLog(@"1 %@", NSThread.currentThread); });
    dispatch_async(queue, ^{ sleep(2); NSLog(@"2 %@", NSThread.currentThread); });
    dispatch_async(queue, ^{ sleep(3); NSLog(@"3 %@", NSThread.currentThread); });
    
    dispatch_barrier_async(queue, ^{ NSLog(@"Barrier %@", NSThread.currentThread); });
    
    dispatch_async(queue, ^{ sleep(1); NSLog(@"A %@", NSThread.currentThread); });
    dispatch_async(queue, ^{ sleep(2); NSLog(@"B %@", NSThread.currentThread); });
    dispatch_async(queue, ^{ sleep(3); NSLog(@"C %@", NSThread.currentThread); });
```

**输出**

```sh
start <_NSMainThread: 0x6000006e4180>{number = 1, name = main}
1 <NSThread: 0x6000006e8140>{number = 2, name = (null)}
2 <NSThread: 0x6000006e8200>{number = 3, name = (null)}
3 <NSThread: 0x6000006f8000>{number = 4, name = (null)}
Barrier <NSThread: 0x6000006f8000>{number = 4, name = (null)}
A <NSThread: 0x6000006f8000>{number = 4, name = (null)}
B <NSThread: 0x6000006e8200>{number = 3, name = (null)}
C <NSThread: 0x6000006e8140>{number = 2, name = (null)}
```

> **注意：只能使用`dispatch_queue_create()`创建的`DISPATCH_QUEUE_CONCURRENT`队列**

## dispatch_sync

**死锁**：调用此函数并以当前队列为目标会导致死锁

**死锁1**

```objc
    dispatch_queue_t queue = dispatch_queue_create("serial", DISPATCH_QUEUE_SERIAL);
    dispatch_sync(queue, ^{
        NSLog(@"start out");
        dispatch_sync(queue, ^{
            NSLog(@"start in");
        });
    });
```

**死锁2**

```objc
    dispatch_queue_t queue = dispatch_queue_create("serial", DISPATCH_QUEUE_SERIAL);
    dispatch_async(queue, ^{
        NSLog(@"start out");
        dispatch_sync(queue, ^{
            NSLog(@"start in");
        });
    });
```

**死锁3**

```objc
    dispatch_queue_t queue = dispatch_queue_create("serial", DISPATCH_QUEUE_SERIAL);
    dispatch_sync(queue, ^{
        NSLog(@"start out");
        dispatch_sync(dispatch_get_main_queue(), ^{
            NSLog(@"start in");
        });
    });
```

> **作为一项性能优化，此函数尽可能在当前线程上执行任务，但有一个例外：提交到主调度队列的任务始终在主线程上运行**

```objc
    NSLog(@"start %@", NSThread.currentThread);
    dispatch_queue_t queue = dispatch_queue_create("serial", DISPATCH_QUEUE_SERIAL);
    
    dispatch_async(queue, ^{
        NSLog(@"2 %@", NSThread.currentThread);
        
        dispatch_sync(dispatch_get_main_queue(), ^{
            NSLog(@"main %@", NSThread.currentThread);
        });
    });
```

**输出：**

```sh
start <_NSMainThread: 0x60000250c240>{number = 1, name = main}
2 <NSThread: 0x600002500200>{number = 2, name = (null)}
main <_NSMainThread: 0x60000250c240>{number = 1, name = main}
```

## dispatch_suspend、dispatch_resume

> 注意：不会影响任何已在运行的任务，只是阻止启动调度队列中但尚未开始的任务。恢复后，这些任务将被执行。

```objc
    NSLog(@"start %@", NSThread.currentThread);
    dispatch_queue_t queue = dispatch_queue_create("serial", DISPATCH_QUEUE_SERIAL);
    
    dispatch_async(queue, ^{
        NSLog(@">>> 2 %@", NSThread.currentThread);
        sleep(2);
        NSLog(@"2 %@", NSThread.currentThread);
    });
    
    dispatch_async(queue, ^{
        NSLog(@">>> 3 %@", NSThread.currentThread);
        sleep(3);
        NSLog(@"3 %@", NSThread.currentThread);
        dispatch_resume(queue);
    });
    
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        NSLog(@">>> end %@", NSThread.currentThread);
        dispatch_suspend(queue);
        NSLog(@"end %@", NSThread.currentThread);
    });
```

**输出：**

```sh
start <_NSMainThread: 0x600003208200>{number = 1, name = main}
>>> 2 <NSThread: 0x60000320c040>{number = 2, name = (null)}
>>> end <_NSMainThread: 0x600003208200>{number = 1, name = main}
end <_NSMainThread: 0x600003208200>{number = 1, name = main}
2 <NSThread: 0x60000320c040>{number = 2, name = (null)}
```