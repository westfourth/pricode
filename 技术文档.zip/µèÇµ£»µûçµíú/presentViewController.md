## presentViewController

### 流程
>
1. 正常流程：`A --> B --> C`
1. 异常流程： `A --> B`，再`A --> C`

说明：`-->`表示`presentViewController:animated:completion:`

异常流程不会弹出C，且程序不会崩溃，但会报错。

### FullScreen模式报错

```sh
 Attempt to present <CViewController: 0x10a205710> on <AViewController: 0x10420f050> (from <AViewController: 0x10420f050>) whose view is not in the window hierarchy.
```

### Automatic模式报错

```sh
 Attempt to present <CViewController: 0x103f140e0> on <AViewController: 0x104906c70> (from <AViewController: 0x104906c70>) which is already presenting <BViewController: 0x103f0e540>.
```