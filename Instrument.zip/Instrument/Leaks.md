# Leaks

内存泄漏分析

资料：[Analyze heap memory](https://developer.apple.com/videos/play/wwdc2024/10173/)

## 简介

**样本**

![](Images/leaks_sample.png)

**符号含义**

| 符号 | 含义 |
| :-: | :-: |
| ![](Images/leaks_no.png) | 没有内存泄漏 |
| ![](Images/leaks_new.png) | 内存泄漏 |
| ![](Images/leaks_no_new.png) | 没有新的内存泄漏 |

## 自身循环引用

### 示例

```objc
@interface TestViewController ()
@property (nonatomic) void (^block)(void);
@end

@implementation TestViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.block = ^{
        self.view.backgroundColor = UIColor.redColor;
    };
    self.block();
}

@end
```

操作：连续4次进入、退出`TestViewController`

### Leaks

![](Images/leaks_circular_reference.png)

可见：自身循环引用，**Instruments -> Leaks** 是检测不出来的。

### Allocations

![](Images/TestViewController_Statistics.png)

![](Images/TestViewController_Allocations.png)

可见：有4个 `TestViewController` 未被释放。


## 相互循环引用

### 示例

```objc
@interface Parent : NSObject
@property (nonatomic) Child *child;
@end

@interface Child : NSObject
@property (nonatomic) Parent *parent;
@end

- (void)testCircleReference {
    Parent *parent = [Parent new];
    Child *child = [Child new];
    
    parent.child = child;
    child.parent = parent;
}
```

操作：连续4次执行 `testCircleReference` 方法

### Leaks

![](Images/leaks_circular_reference_both.png)

可见：相互循环引用，**Instruments -> Leaks** 可以检测出来。

**1. Leaks**

![](Images/leaks_leaks.png)

可见：有4个`Parent`、4个`Child`未被释放。

**2. Circles**

![](Images/leaks_circle.png)

可见：有4个循环引用。

**3. Code**

点击 `Stack Trace` 黑色行，可跳转进入到源代码。

![](Images/leaks_code.png)

可以查看 泄漏次数、泄漏大小。


## NSTimer循环引用

### 示例

```objc
@interface TestViewController ()
@property (nonatomic) NSTimer *timer;
@end

@implementation TestViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self startTimer];
}

- (void)startTimer {
    self.timer = [[NSTimer alloc] initWithFireDate:NSDate.now interval:1 target:self selector:@selector(timer:) userInfo:nil repeats:YES];
    [[NSRunLoop currentRunLoop] addTimer:self.timer forMode:NSDefaultRunLoopMode];
}

- (void)timer:(id)sender {
    puts(__func__);
}

@end
```

操作：连续4次进入、退出`TestViewController`

### Leaks

![](Images/leaks_timer_leaks.png)

可见：NSTimer循环引用，**Instruments -> Leaks** 不能检测内存泄漏。

### Allocations

![](Images/leaks_timer_allocations.png)

可见：有4个 `TestViewController` 未被释放。

### Memory Graph

![](Images/leaks_timer_graph_0.png)

可见：`NSTimer`被`Runloop`持有。

![](Images/leaks_timer_graph_1.png)

可见：`NSTimer`与`TestViewController`相互持有。


## 未Release

### 示例

```objc
+ (nullable UIImage *)gifImageWithData:(NSData *)data {
    CGImageSourceRef imageSource = CGImageSourceCreateWithData((CFDataRef)data, NULL);
    CFStringRef type = CGImageSourceGetType(imageSource);
    if (CFStringCompare(type, kUTTypeGIF, 0) != kCFCompareEqualTo) {
        CFRelease(imageSource);
        return nil;
    }
        
    NSMutableArray<UIImage *> *images = [NSMutableArray new];
    NSTimeInterval duration = 0;
    size_t count = CGImageSourceGetCount(imageSource);
    for (int i = 0; i < count; i++) {
        //  获取每帧时间
        CFDictionaryRef dict = CGImageSourceCopyPropertiesAtIndex(imageSource, i, NULL);
        CFDictionaryRef gifDict = CFDictionaryGetValue(dict, kCGImagePropertyGIFDictionary);
        NSTimeInterval time = 0;
        CFNumberRef delayTime = (CFNumberRef)CFDictionaryGetValue(gifDict, kCGImagePropertyGIFDelayTime);
        CFNumberGetValue(delayTime, CFNumberGetType(delayTime), &time);
        duration += time;
        
        //  获取每帧图片
        CGImageRef image = CGImageSourceCreateImageAtIndex(imageSource, i, NULL);
        UIImage *aImage = [UIImage imageWithCGImage:image];
        [images addObject:aImage];
    }
    UIImage *image = [UIImage animatedImageWithImages:images duration:duration];
    return image;
}
```

### Leaks

![](Images/leaks_release.png)

可见：未release，**Instruments -> Leaks** 可以检测出来。

**1. Leaks**

![](Images/leaks_release_leaks.png)

**2. Circles**

![](Images/leaks_release_circles.png)

可见：没有循环引用。

**3. Call Tree**

![](Images/leaks_release_call_tree.png)

右侧可见最重调用栈

**4. Code**

点击 最重调用栈 黑色行，可跳转进入到源代码。

![](Images/leaks_release_code.png)

可以查看 泄漏次数、泄漏大小。

### 警告

未Release方式 不能检测到所有的未调用`CFRelease()`的内存泄漏。

```objc
+ (nullable UIImage *)gifImageWithData:(NSData *)data {
    CGImageSourceRef imageSource = CGImageSourceCreateWithData((CFDataRef)data, NULL);
    CFStringRef type = CGImageSourceGetType(imageSource);
    if (CFStringCompare(type, kUTTypeGIF, 0) != kCFCompareEqualTo) {
//        CFRelease(imageSource);
        return nil;
    }
        
    NSMutableArray<UIImage *> *images = [NSMutableArray new];
    NSTimeInterval duration = 0;
    size_t count = CGImageSourceGetCount(imageSource);
    for (int i = 0; i < count; i++) {
        //  获取每帧时间
        CFDictionaryRef dict = CGImageSourceCopyPropertiesAtIndex(imageSource, i, NULL);
        CFDictionaryRef gifDict = CFDictionaryGetValue(dict, kCGImagePropertyGIFDictionary);
        NSTimeInterval time = 0;
        CFNumberRef delayTime = (CFNumberRef)CFDictionaryGetValue(gifDict, kCGImagePropertyGIFDelayTime);
        CFNumberGetValue(delayTime, CFNumberGetType(delayTime), &time);
        duration += time;
        CFRelease(dict);
        
        //  获取每帧图片
        CGImageRef image = CGImageSourceCreateImageAtIndex(imageSource, i, NULL);
        UIImage *aImage = [UIImage imageWithCGImage:image];
        [images addObject:aImage];
//        CGImageRelease(image);
    }
//    CFRelease(imageSource);
    UIImage *image = [UIImage animatedImageWithImages:images duration:duration];
    return image;
}
```

上面的代码使用 **Instruments -> Leaks** 检测不到内存泄漏。

![](Images/leaks_analyzer.png)

但 **Static Analyzer** 可以检测到。