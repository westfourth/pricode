# Allocations

显示内存占用情况。

## Statistics

![](Images/statistics_intro.png)

### Allocation Type

| 字段 | 含义 |
| :-: | :-: |
| All Heap & Anonymous VM | 堆内存 + 虚拟内存 |
| All Heap Allocations | 堆内存 |
| All Anonymous VM | 虚拟内存 |

### 表头字段

| 字段 | 含义 |
| :-: | :-- |
| Graph | 是否需要绘制出来 |
| Category | 类别 |
| Persistent | 未释放的内存大小 |
| # Persistent | 未释放的内存块数量 |
| # Transient | 已释放的内存块数量 |
| Total Bytes | 未释放的内存大小 + 已释放的内存大小 |
| # Total | 未释放的内存块数量 + 已释放的内存块数量 |
| Persistent/Total Bytes | 活动内存/申请内存 |

备注：malloc申请一块内存，但该块内存有具体的大小，因此有数量、大小之分。

### Graph

| 勾选 | 显示 |
| :-: | :-: |
| ![](Images/statistics_all_check.png) | ![](Images/statistics_all.png) |
| ![](Images/statistics_all_and_heap_check.png) | ![](Images/statistics_all_and_heap.png) |

### 选取时间段分析

![](Images/allocation_peroid.png)

选取时间段分析适用于：**Statistics**、**Call Trees**、**Allocations List**。


## Generations

**内存增量分析**：对比不同时刻的内存快照。

### 表头字段

| 字段 | 含义 |
| :-: | :-- |
| Snapshot | 快照名 |
| Timestamp | 快照时间 |
| Growth | 内存增量大小 |
| # Persistent | 未释放的内存数量 |

### 举例

1. 点击 **Mark Generation** 创建快照。

![](Images/generation_mark.png)

2. 生成5个快照。

![](Images/generation_count.png)

3. 展开 **Generation C**，可以看到各类型数据内存占用情况。

![](Images/generation_expand.png)

4. 点击 **Generation C** 右侧箭头，查看 **Heaviest Stack Trace**。

![](Images/generation_detail.png)

左侧选中不同的行，右侧 **Heaviest Stack Trace** 会跟着变化。

右侧黑色行表示用户代码（包括第三方源代码）；灰色表示Apple库代码。

5. 点击右侧 **Heaviest Stack Trace** 的某一行，左侧会显示调用栈各函数内存占用情况。

![](Images/generation_stack.png)

可使用 `option` + `鼠标左键` 递归展开。

6. 双击右侧 **Heaviest Stack Trace** 的某一行，跳到源代码，显示某一行内存占用大小。

![](Images/generation_code.png)


## Call Trees

查看调用栈

### 表头字段

| 字段 | 含义 |
| :-: | :-- |
| Bytes Used | 函数/方法涉及的内存大小 |
| Count | 函数/方法涉及的内存数量 |
| Symbol Name | 函数/方法名称 |


### 举例

1. 选取某一个区间。

![](Images/call_trees_peroid.png)

左下侧选择指定行，右下侧展示对应的 **Heaviest Stack Trace**。

2. 展开调用栈。

![](Images/call_trees_trace.png)

3. 隐藏系统库函数/方法，只查看用户函数/方法

![](Images/call_trees_hide.png)

4. 双击某一行，跳到源代码，显示某一行内存占用大小。

![](Images/call_trees_code.png)


## Allocations List

查看内存分配列表

### 表头字段

| 字段 | 含义 |
| :-: | :-- |
| Address | 内存块地址 |
| Category | 内存类型 |
| Timestamp | 内存申请时间 |
| Size | 内存块大小 |
| Responsible | 负责申请该内存块的库 |
| Responsible Caller | 负责申请该内存块的方法 |

### 举例

1. 选取某一个区间，并选中某一个内存块，右侧展示 **Stack Traces**。

![](Images/allocation_list_trace.png)

2. 双击 **Stack Traces** 的某个函数，即可查看对应代码的内存占用情况。

![](Images/allocation_list_code.png)

3. 并选中某一个内存块，点击右侧箭头，查看详情。

![](Images/allocation_list_free.png)

有 **Free** 表示该内存块已被释放。

![](Images/allocation_list_nofree.png)

没有 **Free** 表示该内存块未被释放。

