# Functions

## Basics

```dart
bool isNoble(int atomicNumber) {
  return atomicNumber > 0;
}
```

可省略返回类型。

```dart
isNoble(int atomicNumber) {
  return atomicNumber > 0;
}
```

只有一个表达式时，可以使用速记法。

```dart
bool isNoble(int atomicNumber) => atomicNumber > 0;
```

## Named parameters

- 命名参数 都是可选的，除非明确标记为`required`。
- 命名参数 如果没有提供默认值（编译时常量），那么类型为nullable，并且默认值为`null`。
- 只能有一组命名参数。
- 调用时，命名参数顺序不固定，可选参数可忽略。

**举例1：**

```dart
void enableFlags({bool? bold, bool? hidden}) {
  print('bold = $bold, hidden = $hidden');
}
```

调用

```dart
enableFlags(bold: true, hidden: false);
enableFlags(hidden: true, bold: false);
enableFlags(bold: true);
enableFlags(hidden: true);
enableFlags();
```

输出

```sh
bold = true, hidden = false
bold = false, hidden = true
bold = true, hidden = null
bold = null, hidden = true
bold = null, hidden = null
```

**举例2：**

```dart
void enableFlags({bool bold = true, required bool hidden}) {
  print('bold = $bold, hidden = $hidden');
}
```

调用

```dart
enableFlags(bold: true, hidden: false);
enableFlags(hidden: true, bold: false);
enableFlags(hidden: true);
```

## 参数混用

命名参数 与 位置参数 混用：

- 定义函数时，命名参数组 必须放最后。
- 调用时，命名参数 位置可以任意放置，但（除去 命名参数后）位置参数 的顺序必须与定义时一致。

```dart
void enableFlags(int code, String msg, {bool bold = true, required bool hidden}) {
  print('code = $code, msg = $msg, bold = $bold, hidden = $hidden');
}
```

调用

```dart
enableFlags(0, "Success", hidden: false, bold: true);
enableFlags(1, hidden: false, "Success", bold: true);
enableFlags(hidden: false, 2, "Success", bold: true);
enableFlags(hidden: false, 3, bold: true, "Success");
enableFlags(hidden: false, bold: true, 4, "Success");
```

## Optional positional parameters

使用`[]`将 位置参数 标记为 可选位置参数。

```dart
void enableFlags(int code, String msg, [bool? bold, bool hidden = false]) {
  print('code = $code, msg = $msg, bold = $bold, hidden = $hidden');
}
```

调用

```dart
enableFlags(0, "Success", false, true);
enableFlags(1, "Success", false);
enableFlags(2, "Success");
```

输出

```sh
code = 0, msg = Success, bold = false, hidden = true
code = 1, msg = Success, bold = false, hidden = false
code = 2, msg = Success, bold = null, hidden = false
```

## main()

可选参数`List<String>`。

```dart
// Run the app like this: dart run args.dart 1 test
void main(List<String> arguments) {
  print(arguments);

  assert(arguments.length == 2);
  assert(int.parse(arguments[0]) == 1);
  assert(arguments[1] == 'test');
}
```

## Function types

将函数名替换为`Function`，位置参数 的名称可以忽略，但 命名参数 的名称不可以忽略。

```dart
void greet(String name, {String greeting = 'Hello'}) =>
    print('$greeting $name!');

// Store `greet` in a variable and call it.
void Function(String, {String greeting}) g = greet;
g('Dash', greeting: 'Howdy');
```

## Anonymous functions

**语法：**

```dart
([[Type] param1[, ...]]) {
  codeBlock;
}
```

参数类型为可选。

```dart
void Function(int, int) f = (int a, int b) {
  print("$a + $b = ${a + b}");
};
```

```dart
void Function(int, int) f = (a, b) {
  print("$a + $b = ${a + b}");
};
```

## Lexical closures

A function object that can access variables in its lexical scope when the function sits outside that scope is called a *closure*


```dart
/// Returns a function that adds [addBy] to the
/// function's argument.
Function makeAdder(int addBy) {
  return (int i) => addBy + i;
}

void main() {
  // Create a function that adds 2.
  var add2 = makeAdder(2);

  // Create a function that adds 4.
  var add4 = makeAdder(4);

  assert(add2(3) == 5);
  assert(add4(3) == 7);
}
```

## Tear-offs（分离式函数）

当您引用不带括号的函数、方法或命名构造函数时，Dart 会创建一个分离式函数。

这是一个闭包，它接受与函数相同的参数，并在您调用它时调用底层函数。

函数签名相同（参数类型、个数、顺序一致，返回类型一致）才可以使用。


```dart
var charCodes = [68, 97, 114, 116];
var buffer = StringBuffer();
```

**good**

```dart
// Function tear-off
charCodes.forEach(print);

// Method tear-off
charCodes.forEach(buffer.write);
```

**bad**

```dart
// Function lambda
charCodes.forEach((code) {
  print(code);
});

// Method lambda
charCodes.forEach((code) {
  buffer.write(code);
});
```

## Function Equality

```dart
void foo() {} // A top-level function

class A {
  static void bar() {} // A static method
  void baz() {} // An instance method
}

void main() {
  var a1 = A();
  var a2 = A();

  var b1 = foo == A.bar;          //  false
  var b2 = foo == a1.baz;         //  false
  var b3 = A.bar == a1.baz;       //  false
  var b4 = a1.baz == a2.baz;      //  false
}
```

## Return values

每个函数都有返回值，没有没有指明返回值，那么`return null`被隐式地附加到函数末尾。

```dart
foo() {}

assert(foo() == null);
```

## Generators

用于懒生成一系列数值。

- 同步生成器：返回一个`Iterable`对象。
- 异步生成器：返回一个`Stream`对象。

```dart
Iterable<int> naturalsTo(int n) sync* {
  int k = 0;
  while (k < n) yield k++;
}

void main() {
  var result = naturalsTo(5);
  for (var i in result) {
    print(i);
  }
}
```

```dart
Stream<int> asynchronousNaturalsTo(int n) async* {
  int k = 0;
  while (k < n) yield k++;
}

void main() async {
  var result = asynchronousNaturalsTo(5);
  await for (var i in result) {
    print(i);
  }
}
```

`yield`用于传递值。

**递归**

```dart
Iterable<int> naturalsTo(int n) sync* {
  if (n > 0) {
    yield n;
    yield* naturalsTo(n - 1);
  }
}
```

`yield*`用于递归。

## External functions

```dart
external void someFunc(int i);
```

