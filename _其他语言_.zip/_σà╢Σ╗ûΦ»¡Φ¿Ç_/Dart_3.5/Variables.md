# Variables


## 使用

变量在使用前都应该被初始化。

**类型推断**

```dart
var name = 'Bob';
```

**指明类型**

```dart
String name = 'Bob';
```

## Null safety

Nullable类型默认值为`null`

```dart
String? name  // 可以为 null 或 string

String name   // 只能为 string
```

## Late Variables

延迟初始化变量。

```dart
late String description;

void main() {
  description = 'Feijoada!';
  print(description);
}
```

如果没有`late`修饰，则报错：
> Error: Field 'description' should be initialized because its type 'String' doesn't allow null.

`late`修饰的变量，声明并初始化，那么当变量第一次使用时，初始化才被执行。

## Final & Const

- `final`：只能被赋值一次。
- `const`：编译时常量（const变量是隐式final）。

## assert()

生产模式会被忽略，开发模式抛异常。