# Callable objects

为了允许 Dart 类的实例像函数一样被调用，请实现`call()`方法。

```dart
class WannabeFunction {
  String call(String a, String b, String c) => '$a $b $c!';
}

var wf = WannabeFunction();
var out = wf('Hi', 'there,', 'gang');

void main() => print(out);
```
