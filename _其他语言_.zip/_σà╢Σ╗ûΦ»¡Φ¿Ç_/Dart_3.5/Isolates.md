# Isolates

## run()

生成一个新的后台工作程序。

```dart
const String filename = 'with_keys.json';

void main() async {
  // Read some data.
  final jsonData = await Isolate.run(_readAndParseJson);

  // Use that data.
  print('Number of JSON keys: ${jsonData.length}');
}
```

```dart
Future<Map<String, dynamic>> _readAndParseJson() async {
  final fileData = await File(filename).readAsString();
  final jsonData = jsonDecode(fileData) as Map<String, dynamic>;
  return jsonData;
}
```

### 闭包

使用`isolate`发送闭包

```dart
const String filename = 'with_keys.json';

void main() async {
  // Read some data.
  final jsonData = await Isolate.run(() async {
    final fileData = await File(filename).readAsString();
    final jsonData = jsonDecode(fileData) as Map<String, dynamic>;
    return jsonData;
  });

  // Use that data.
  print('Number of JSON keys: ${jsonData.length}');
}
```

## Ports

`ReceivePort`、`SendPort`这些端口是`isolate`之间相互通信的唯一方式。

> 一个 SendPort 对象只与一个 ReceivePort 相关联，但一个 ReceivePort 可以有多个 SendPort。当您创建 ReceivePort 时，它会为自己创建一个 SendPort。您可以创建其他 SendPort，以便将消息发送到现有的 ReceivePort。

与socket不同，`sendPortA.send()`会把消息发送到与`sendPortA`相关联的`receivePortA`。

```dart
import 'dart:isolate';
import 'dart:convert';
import 'dart:async';


void main() async {
  final worker = Worker();
  await worker.spawn();
  await worker.parseJson('{"AAA": "111", "BBB": "222"}');
}


class Worker {
  late SendPort _sendPort;
  final Completer<void> _isolateReady = Completer.sync();

  //  Spawn a worker isolate
  Future<void> spawn() async {
    final receivePort = ReceivePort();
    receivePort.listen(_handleResponsesFromIsolate);
    await Isolate.spawn(_startRemoteIsolate, receivePort.sendPort);
  }

  //  Handle messages sent back from the worker isolate.
  void _handleResponsesFromIsolate(dynamic message) {
    if (message is SendPort) {
      _sendPort = message;
      _isolateReady.complete();
    } else if (message is Map<String, dynamic>) {
      print(message);
    }
  }

  //  Define a public method that can
  //  be used to send messages to the worker isolate.
  Future<void> parseJson(String message) async {
    await _isolateReady.future;
    _sendPort.send(message);
  }
}


//  Execute code on the worker isolate
void _startRemoteIsolate(SendPort port) {
  final receivePort = ReceivePort();
  port.send(receivePort.sendPort);

  receivePort.listen((dynamic message) async {
    if (message is String) {
      final transformed = jsonDecode(message);
      port.send(transformed);
    }
  });
}
```



