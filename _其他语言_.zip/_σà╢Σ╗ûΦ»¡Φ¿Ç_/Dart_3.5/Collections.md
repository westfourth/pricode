# Collections

## Lists

```dart
var list = <int>[];                 //  创建空List

var list = [1, 2, 3];               //  类型被推断为`List<int>`。
list.add(4);                        //  增
list.remove(2);                     //  删
list.replaceRange(2, 3, [4]);       //  改
var dst = list[2];                  //  查
```

## Sets

```dart
var sets = <int>{};                 //  创建空Set
var sets = Set<int>();              //  创建空Set

var sets = {1, 2, 3};               //  类型被推断为`Set<int>`。
sets.add(4);                        //  增
sets.remove(1);                     //  删
```

## Maps

```dart
var maps = <String, int>{};         //  创建空Map
var maps = Map<String, int>();      //  创建空Map

var maps = {'AA': 11, 'BB': 22};    //  类型被推断为`Map<String, int>`。
map.addAll({'CC': 33});             //  增
maps.remove('AA');                  //  删
map.update('CC', (int value) => 333);       //  改
var dst = maps['CC'];               //  查
```

## Operators

- `...`
- `...?`
- `collection if`
- `collection for`

```dart
var nav = ['Home', 'Furniture', 'Plants', if (promoActive) 'Outlet'];
```

```dart
var nav = ['Home', 'Furniture', 'Plants', if (login case 'Manager') 'Inventory'];
```

```dart
var listOfInts = [1, 2, 3];
var listOfStrings = ['#0', for (var i in listOfInts) '#$i'];
assert(listOfStrings[1] == '#1');
```






