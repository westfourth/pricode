# Libraries & imports

## 3种引入方式

```dart
import 'dart:html';                     //  dart:前缀引入内建库
import 'package:test/test.dart';        //  package:前缀引入包管理提供的库
import '../test.dart';                  //  文件路径引入
```

## 命名空间

如有2个库有同名标识符时，可使用命名空间。

```dart
import 'package:lib1/lib1.dart';
import 'package:lib2/lib2.dart' as lib2;

// Uses Element from lib1.
Element element1 = Element();

// Uses Element from lib2.
lib2.Element element2 = lib2.Element();
```

## 部分引入

```dart
// Import only foo.
import 'package:lib1/lib1.dart' show foo;

// Import all names EXCEPT foo.
import 'package:lib2/lib2.dart' hide foo;
```

## 懒加载

- 只能在web app上使用。
- 多次`loadLibrary()`也只加载一次。

```dart
import 'package:greetings/hello.dart' deferred as hello;
```

```dart
Future<void> greet() async {
  await hello.loadLibrary();
  hello.printGreeting();
}
```