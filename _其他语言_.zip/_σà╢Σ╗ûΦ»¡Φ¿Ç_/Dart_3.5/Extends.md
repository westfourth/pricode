# Extends

- `extends` 继承。
- `@override` 重载。

## noSuchMethod()

为了检测或响应代码尝试使用不存在的方法或实例变量的情况，您可以重写`noSuchMethod()`。

```dart
class Television {
  @override
  void noSuchMethod(Invocation invocation) {
    print('You tried to use a non-existent member: '
        '${invocation.memberName}');
  }
}


void main() {
  dynamic a = Television();
  a.show();               //  Symbol("show")
  // a.name = 'abc';         //  Symbol("name=")
}
```