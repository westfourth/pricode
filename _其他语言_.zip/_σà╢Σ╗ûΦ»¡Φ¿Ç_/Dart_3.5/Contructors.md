# Contructors

## 构造函数

### Generative contructors

**生成构造函数**

```dart
class Point {
  // Initializer list of variables and values
  double x = 2.0;
  double y = 2.0;

  // Generative constructor with initializing formal parameters:
  Point(this.x, this.y);
}
```

### Default constructors

**默认构造函数**：没有参数的生成构造函数.

```dart
class Point {
  double x = 2.0;
  double y = 2.0;

  Point();
}
```


### Named constructors

**命名构造函数**：不会被继承。

```dart
const double xOrigin = 0;
const double yOrigin = 0;

class Point {
  final double x;
  final double y;

  // Sets the x and y instance variables
  // before the constructor body runs.
  Point(this.x, this.y);

  // Named constructor
  Point.origin()
      : x = xOrigin,
        y = yOrigin;
}
```

### Constant constructors

**常量构造函数**：构造函数被`const`修饰，所有实例变量被`final`修饰。

```dart
class ImmutablePoint {
  static const ImmutablePoint origin = ImmutablePoint(0, 0);

  final double x, y;

  const ImmutablePoint(this.x, this.y);
}
```

### Redirecting constructors

**重定向构造函数**：构造函数主体为空，使用this调用其他构造函数。

```dart
class Point {
  double x, y;

  // The main constructor for this class.
  Point(this.x, this.y);

  // Delegates to the main constructor.
  Point.alongXAxis(double x) : this(x, 0);
}
```

### Factory constructors

**工厂构造函数**：

```dart
class Logger {
  final String name;
  bool mute = false;

  // _cache is library-private, thanks to
  // the _ in front of its name.
  static final Map<String, Logger> _cache = <String, Logger>{};

  factory Logger(String name) {
    return _cache.putIfAbsent(name, () => Logger._internal(name));
  }

  factory Logger.fromJson(Map<String, Object> json) {
    return Logger(json['name'].toString());
  }

  Logger._internal(this.name);

  void log(String msg) {
    if (!mute) print(msg);
  }
}
```

> 工厂构造函数不可以访问`this`。

## 实例变量初始化

1. 声明时初始化。
1. 形式参数初始化。
1. 初始化列表。

### 初始化列表

**执行顺序**：初始化列表在函数体之前。

```dart
// Initializer list sets instance variables before
// the constructor body runs.
Point.fromJson(Map<String, double> json)
    : x = json['x']!,
      y = json['y']! {
  print('In Point.fromJson(): ($x, $y)');
}
```

> 初始化列表不能访问`this`。

```dart
Point.withAssert(this.x, this.y) : assert(x >= 0) {
  print('In Point.withAssert(): ($x, $y)');
}
```

## 构造函数继承

Dart 按以下顺序执行构造函数：
- 初始化列表
- 超类的未命名、无参数构造函数
- 主类的无参数构造函数

```dart
class Person {
  String? firstName;

  Person() {
    print('in Person');
  }
}

class Employee extends Person {
  String? lastName;
  
  Employee() {
    print('in Employee');
  }
}

void main() {
  var employee = Employee();
  print(employee);
  // Prints:
  // in Person
  // in Employee
  // Instance of 'Employee'
}
```

如果超类缺少未命名、无参数的构造函数，则调用超类中的构造函数之一。在构造函数主体（如果有）之前，在冒号 (:) 后指定超类构造函数。

```dart
class Person {
  String? firstName;

  Person.fromJson(Map data) {
    print('in Person');
  }
}

class Employee extends Person {
  // Person does not have a default constructor;
  // you must call super.fromJson().
  Employee.fromJson(Map data) : super.fromJson(data) {
    print('in Employee');
  }
}

void main() {
  var employee = Employee.fromJson({});
  print(employee);
  // Prints:
  // in Person
  // in Employee
  // Instance of 'Employee'
}
```

```dart
class Person {
  String? firstName;

  Person.fromJson(Map data) {
    print('in Person');
  }
}

class Employee extends Person {
  String? lastName;
  // Person does not have a default constructor;
  // you must call super.fromJson().
  Employee.fromJson(Map data) : lastName = 'Tom', super.fromJson(data) {
    print('in Employee');
  }
}

void main() {
  var employee = Employee.fromJson({});
  print(employee.lastName);
  // Prints:
  // in Person
  // in Employee
  // Tom
}
```

## 超类参数

```dart
class Vector2d {
  final double x;
  final double y;

  Vector2d(this.x, this.y);
}

class Vector3d extends Vector2d {
  final double z;

  // Forward the x and y parameters to the default super constructor like:
  // Vector3d(final double x, final double y, this.z) : super(x, y);
  Vector3d(super.x, super.y, this.z);

  Vector3d.xAxisError(): z = 0, super(11, 22);
}
```