# Generics

## 类型限制

使用`extends`将范型类型限制为某个类型的子类型。

```dart
class Foo<T extends Object> {
  // Any type provided to Foo for T must be non-nullable.
}
```