# Metadata

给代码提供外的信息。

## 内置

支持：`@Deprecated`, `@deprecated`, `@override`, `@pragma`

```dart
class Television {
  /// Use [turnOn] to turn the power on instead.
  @Deprecated('Use turnOn instead')
  void activate() {
    turnOn();
  }

  /// Turns the TV's power on.
  @deprecated
  void turnOn() {

  }
}
```

## 自定义

```dart
class Todo {
  final String who;
  final String what;

  const Todo(this.who, this.what);
}

@Todo('Dash', 'Implement this function')
void doSomething() {
  print('Do something');
}
```

