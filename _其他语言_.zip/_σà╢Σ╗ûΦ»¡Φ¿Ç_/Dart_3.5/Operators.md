# Operators

## Arithmetic operators

- `/`：除法
- `~/`：除法，舍去小数取整。

```dart
5 / 2;                  //  2.5
5 ~/ 2;                 //  2
```


## Equality operators

- `==`：判断是否相等。
- `identical()`：判断是否为同一个对象。

## Type test operators

| Operator | Meaning |
| :-: | :-: |
| **as** | 类型转换 |
| **is** | 是否是指定的类型 |
| **is!** | 是否不是指定的类型 |

## Conditional Expressions

`expr1 ?? expr2`：如果expr1非空，返回expr1；否则返回expr2。

## Cascade notation

级联表示法（`..`、`?..`）允许对同一个对象做一些列操作。

```dart
var paint = Paint()
  ..color = Colors.black
  ..strokeCap = StrokeCap.round
  ..strokeWidth = 5.0;
```

等同于

```dart
var paint = Paint();
paint.color = Colors.black;
paint.strokeCap = StrokeCap.round;
paint.strokeWidth = 5.0;
```

如果级联对象可能为null，那么对第一个操作使用`?..`

```dart
querySelector('#confirm') // Get an object.
  ?..text = 'Confirm' // Use its members.
  ..classes.add('important')
  ..onClick.listen((e) => window.alert('Confirmed!'))
  ..scrollIntoView();
```

等同于

```dart
var button = querySelector('#confirm');
button?.text = 'Confirm';
button?.classes.add('important');
button?.onClick.listen((e) => window.alert('Confirmed!'));
button?.scrollIntoView();
```

**在有返回值的函数上构造级联时要小心，下面的代码就是错误的**

```dart
var sb = StringBuffer();
sb.write('foo')
  ..write('bar'); // Error: method 'write' isn't defined for 'void'.
```

`sb.write()`返回`void`，不能对`void`进行级联操作。

> 什么情况下可以使用级联表达式？

## Spread Operators

扩展运算符（`...`、`...?`）计算产生集合的表达式，解开结果值，并将其插入到另一个集合中。


```dart
  List list = [1, 2, 3];
  var list2 = [9, ...list];             //  [9, 1, 2, 3]
```

```dart
  List? list = null;
  var list2 = [9, ...?list];            //  [9]
```



