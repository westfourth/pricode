# Typedefs

## 基本使用

```dart
typedef IntList = List<int>;
IntList il = [1, 2, 3];
```

## 带参数

```dart
typedef ListMapper<X> = Map<X, List<X>>;
Map<String, List<String>> m1 = {}; // Verbose.
ListMapper<String> m2 = {}; // Same thing but shorter and clearer.
```

## 别名函数

**形式1**

```dart
typedef MainFunction<T> = T Function(T, T);
```

**形式2**

```dart
typedef T MainFunction<T>(T a, T b);         // 参数名称不能少
```

**举例1**

```dart
typedef Compare<T> = T Function(T a, T b);
int sort(int a, int b) => a - b;
var b = sort is Compare<int>;                   //  true
```

**举例2**

```dart
typedef Print<T> = void Function(T a, T b);

Print<int> f = (int a, int b) {
  print("$a + $b = ${a + b}");
};

f(2, 3);
```