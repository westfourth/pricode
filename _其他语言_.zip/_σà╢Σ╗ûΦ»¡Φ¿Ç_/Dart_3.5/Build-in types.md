# Build-in types

## 内置类型

- Numbers (int, double)
- Strings (String)
- Booleans (bool)
- Records ((value1, value2))
- Functions (Function)
- Lists (List, also known as arrays)
- Sets (Set)
- Maps (Map)
- Runes (Runes; often replaced by the characters API)
- Symbols (Symbol)
- The value null (Null)

## Numbers

```dart
  // String -> int
var one = int.parse('1');                           //  1

// String -> double
var onePointOne = double.parse('1.1');              //  1.1

// int -> String
String oneAsString = 1.toString();                  //  "1"

// double -> String
String piAsString = 3.14159.toStringAsFixed(2);     //  "3.14"
```

## Strings

使用 单引号 或 双引号 都行。

可以使用 `${expression}` 将表达式的值放入字符串中。如果表达式是标识符，则可以省略`{}`

```dart
var s = 'tom';
var s1 = 'Hello $s, Nice day';
var s2 = 'Hello ${s.toUpperCase()}, Nice day';
```

**多行**

```dart
var s1 = """
This is also a
multi-line string.""";

var s2 = """This is also a
multi-line string.""";

var isEqual = s1 == s2;                 //  true
```




