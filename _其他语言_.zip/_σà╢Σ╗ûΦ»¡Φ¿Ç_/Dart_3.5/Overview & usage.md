# Overview & usage

## Matching

```dart
Object obj = ['a', 'b'];

switch (obj) {
  case 1:
    print('one');
  case ['a', 'b']:
    print('a, b');
}
```

## Destructuring

```dart
var numList = [1, 2, 3];
var [a, b, c] = numList;
print(a + b + c);
```

```dart
Object list = ['a', 'z'];

switch (list) {
  case ['a' || 'b', var c]:
    print(c);
}
```

## 出现场景

### 1. 变量声明和赋值

```dart
// Declares new variables a, b, and c.
var (a, [b, c]) = ('str', [1, 2]);
```

```dart
var (a, b) = ('left', 'right');
String x;
String y;

(x, y) = (a, b);
print('$x $y');
```

### 2. for和for-in循环

```dart
Map<String, int> hist = {
  'a': 23,
  'b': 100,
};

for (var MapEntry(key: key, value: count) in hist.entries) {
  print('$key occurred $count times');
}
```

### 3. if-case和switch-case

```dart
Object pair = [1, 2];

if (pair case [int x, int y]) {
  print('Was coordinate array $x,$y');
} else {
  throw FormatException('Invalid coordinates.');
}
```

```dart
switch (pair) {
  case (int a, int b):
    if (a > b) print('First element greater');
  // If false, prints nothing and exits the switch.
  case (int a, int b) when a > b:
    // If false, prints nothing but proceeds to next case.
    print('First element greater');
  case (int a, int b):
    print('First element not greater');
}
```