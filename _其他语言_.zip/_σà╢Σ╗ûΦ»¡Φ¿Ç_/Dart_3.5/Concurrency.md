# Concurrency

## Futures

表示异步操作的结果，该操作最终将以值或错误完成。

```dart
import 'dart:convert';
import 'dart:io';

const String filename = '/tmp/with_keys.json';

void main() async {
  // Read some data.
  final fileData = await _readFileAsync();
  final jsonData = jsonDecode(fileData);

  // Use that data.
  print('Number of JSON keys: ${jsonData.length}');
}

Future<String> _readFileAsync() async {
  final file = File(filename);
  final contents = await file.readAsString();
  return contents.trim();
}
```

> `await`只在`async`函数内有效。

## Streams

在未来一段时间内反复提供值。

```dart
void main() async {

  Stream<int> stream = Stream.periodic(const Duration(seconds: 1), (i) => i);
  Stream<int> stream2 = sumStream(stream);
  await for (final value in stream2) {
    print(value);
  }
}

Stream<int> sumStream(Stream<int> stream) async* {
  var sum = 0;
  await for (final value in stream) {
    yield sum += value;
  }
}
```

- `await-for` 当提供新值时，它会执行循环的每次后续迭代。换句话说，它用于“循环”流。
- `yield` 在返回值流的函数中，使用yield关键字而不是return。

## Isolates

- 使用`Isolate.run()`在单独的线程上执行单个计算。
- 使用`Isolate.spawn()`创建一个可随时间处理多条消息的隔离，或创建一个后台工作器。

```dart
int slowFib(int n) => n <= 1 ? 1 : slowFib(n - 1) + slowFib(n - 2);

// Compute without blocking current isolate.
void fib40() async {
  var result = await Isolate.run(() => slowFib(40));
  print('Fib(40) = $result');
}
```