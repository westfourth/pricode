## Questions

- [x] **单引号 与 双引号 的区别？**

没有区别

- [x] **`>>>`这个符号作用是什么？**

Unsigned shift right

- [ ] **级联操作 是否是只能对没有返回值的函数**

- [ ] **List、Set、Map 集合操作**

- [x] **怎样使用 别名函数**

```dart
typedef Compare<T> = void Function(T a, T b);

Compare<int> f = (int a, int b) {
  print("$a + $b = ${a + b}");
};

f(2, 3);
```

- [x] **位置参数 和 命名参数 混用是咋用的？**

1. 命名参数 只能有一组。
1. 命名参数 位置可任意放置，但（去掉命名参数后）位置参数 顺序必须与函数声明保持一致。

- [ ] **这种构造函数看不懂**

```dart
void main() {
  MyApp app = MyApp(name: 'Spark', age: 11);
}


class MyApp {
  String name = 'Tom';
  int age = 0;

  MyApp({required this.name, required this.age});
}
```

- [x] **这个叫什么**

```dart
var (x, y) = (2, 3);
```

https://dart.dev/language/pattern-types#record