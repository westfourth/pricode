# Records

记录是一种匿名、不可变的聚合类型。将多个对象捆绑为一个对象。

## Record syntax

记录表达式是逗号分隔的命名或位置字段列表，括在括号中。

```dart
var record = ('first', a: 2, b: true, 'last');
```

```dart
// Record type annotation in a variable declaration:
(String, int) record;

// Initialize it with a record expression:
record = ('A string', 123);
```

```dart
// Record type annotation in a variable declaration:
({int a, bool b}) record;

// Initialize it with a record expression:
record = (a: 123, b: true);
```

**注意**

```dart
//  错误
(String, {int a, bool b}, String) record = ('first', a: 2, b: true, 'last');

// Error: A value of type '(String, String, {int a, bool b})' can't be assigned to a variable of type '(String, {int a, bool b})'

//  正确
(String, String, {int a, bool b}) record = ('first', a: 2, b: true, 'last');
```

## Record fields

- 命名字段通过同名的getter。
- 位置字段通过`$<position>`的getter。

```dart
var record = ('first', a: 2, b: true, 'last');

print(record.$1);           // Prints 'first'
print(record.a);            // Prints 2
print(record.b);            // Prints true
print(record.$2);           // Prints 'last'
```

## Record types

```dart
(num, Object) pair = (42, 'a');

var first = pair.$1; // Static type `num`, runtime type `int`.
var second = pair.$2; // Static type `Object`, runtime type `String`.
```

**错误**

```dart
(num, Object) pair = (42, 'a');

int first = pair.$1;
// Error: A value of type 'num' can't be assigned to a variable of type 'int'.
String second = pair.$2;
// Error: A value of type 'Object' can't be assigned to a variable of type 'String'.
```

## Record equality

如果两个记录具有相同的形状（字段集），并且其对应字段具有相同的值，则它们相等。

```dart
(int x, int y, int z) point = (1, 2, 3);
(int r, int g, int b) color = (1, 2, 3);

print(point == color); // Prints 'true'.
```

```dart
({int x, int y, int z}) point = (x: 1, y: 2, z: 3);
({int r, int g, int b}) color = (r: 1, g: 2, b: 3);

print(point == color); // Prints 'false'. Lint: Equals on unrelated types.
```

## Multiple returns
```dart
(int, int) swap((int, int) record) {
  var (a, b) = record;
  return (b, a);
}
```

```dart
(int, int) x = (2, 3);
var (a, b) = swap(x);                   //  a = 3, b = 2
```

**错误**

```dart
(int, int) swap((int, int) record) {
  (int, int) (a, b) = record;           //  报错
  return (b, a);
}
```