# Branches

## if-case

如果模式匹配，则执行这个分支。

```dart
if (pair case [int x, int y]) return Point(x, y);
```

## switch

与C语言不同，不需要`break`。编译时，会进行详尽性检查。

## switch表达式

```dart
// Where slash, star, comma, semicolon, etc., are constant variables...
switch (charCode) {
  case slash || star || plus || minus: // Logical-or pattern
    token = operator(charCode);
  case comma || semicolon: // Logical-or pattern
    token = punctuation(charCode);
  case >= digit0 && <= digit9: // Relational and logical-and patterns
    token = number();
  default:
    throw FormatException('Invalid');
}
```

```dart
token = switch (charCode) {
  slash || star || plus || minus => operator(charCode),
  comma || semicolon => punctuation(charCode),
  >= digit0 && <= digit9 => number(),
  _ => throw FormatException('Invalid')
};
```

switch 表达式的语法与 switch 语句的语法不同：

- case 不以 case 关键字开头。
- case 主体是单个表达式，而不是一系列语句。
- 每个 case 都必须有一个主体；空 case 没有隐式 fallthrough。
- case 模式使用 => 而不是 : 与其主体分隔。
- case 用 , 分隔（允许使用可选的尾随 ,）。
- 默认 case 只能使用 _，而不能同时允许 default 和 _。


## Guard clause

使用关键词`when`设置 Guard clause。

```dart
// Switch statement:
switch (something) {
  case somePattern when some || boolean || expression:
    //             ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^ Guard clause.
    body;
}

// Switch expression:
var value = switch (something) {
  somePattern when some || boolean || expression => body,
  //               ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^ Guard clause.
}

// If-case statement:
if (something case somePattern when some || boolean || expression) {
  //                           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^ Guard clause.
  body;
}
```

