# Classes

## Constructors

下面2个是一样的，为什么？

```dart
var p1 = Point(2, 2);
var p2 = Point.fromJson({'x': 1, 'y': 2});
```

```dart
var p1 = new Point(2, 2);
var p2 = new Point.fromJson({'x': 1, 'y': 2});
```

### 常量构造函数

某些类提供常量构造函数。要使用常量构造函数创建编译时常量，请在构造函数名称前放置 const 关键字。

```dart
var p = const ImmutablePoint(2, 2);
```

```dart
var a = const ImmutablePoint(1, 1);
var b = const ImmutablePoint(1, 1);

assert(identical(a, b)); // They are the same instance!
```

如果常量构造函数位于常量上下文之外，并且在调用时没有使用 const，则会创建一个非常量对象。

```dart
var a = const ImmutablePoint(1, 1); // Creates a constant
var b = ImmutablePoint(1, 1); // Does NOT create a constant

assert(!identical(a, b)); // NOT the same instance!
```

## Object's type

`runtimeType` 获取对象类型。

```dart
print('The type of a is ${a.runtimeType}');
```

> 在生产环境中，`object is Type` 比 `object.runtimeType == Type` 更稳定。

## Instance variables

```dart
class Point {
  double? x; // Declare instance variable x, initially null.
  double? y = 2; // Declare y, initially 2.
  double z = 0; // Declare z, initially 0.
}
```

- `nullable`类型没有初始化值时为`null`，也可以设置默认值。
- `non-nullable`类型在声明时必须初始化值。

### late

非late实例变量在初始化前不能访问this。

```dart
double initialX = 1.5;

class Point {
  // OK, can access declarations that do not depend on `this`:
  double? x = initialX;

  // ERROR, can't access `this` in non-`late` initializer:
  double? y = this.x;

  // OK, can access `this` in `late` initializer:
  late double? z = this.x;

  // OK, `this.x` and `this.y` are parameter declarations, not expressions:
  Point(this.x, this.y);
}
```

### final

final实例变量只能设置一次值。

```dart
class ProfileMark {
  final String name;
  final DateTime start = DateTime.now();

  ProfileMark(this.name);
  ProfileMark.unnamed() : name = '';
}
```

## implements

定义：如果您要创建一个支持类 B 的 API 而不继承 B 的实现的类 A，则类 A 应该实现 B 接口。

```dart
// A person. The implicit interface contains greet().
class Person {
  // In the interface, but visible only in this library.
  final String _name;

  // Not in the interface, since this is a constructor.
  Person(this._name);

  // In the interface.
  String greet(String who) => 'Hello, $who. I am $_name.';
}

// An implementation of the Person interface.
class Impostor implements Person {
  String get _name => '';

  String greet(String who) => 'Hi $who. Do you know who I am?';
}

String greetBob(Person person) => person.greet('Bob');

void main() {
  print(greetBob(Person('Kathy')));
  print(greetBob(Impostor()));
}
```

### 多接口

```dart
class Point implements Comparable, Location {...}
```

## static

使用`static`实现类变量和类方法。

> static变量在使用时才初始化。
