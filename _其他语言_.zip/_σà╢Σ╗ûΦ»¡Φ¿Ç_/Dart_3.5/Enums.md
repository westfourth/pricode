# Enums

## 简单枚举

```dart
enum Color { red, green, blue }
```

## 增强枚举

要声明增强型枚举，请遵循与普通类类似的语法，但有一些额外的要求：
1. 实例变量必须是 final，包括通过 mixins 添加的变量。
1. 所有生成构造函数都必须是常量。
1. 工厂构造函数只能返回固定的已知枚举实例之一。
1. 由于枚举会自动扩展，因此无法扩展其他类。
1. 不能覆盖 index、hashCode 和相等运算符 ==。
1. 不能在枚举中声明名为 values 的成员，因为它会与自动生成的静态值 getter 冲突。
1. 必须在声明的开头声明枚举的所有实例，并且必须至少声明一个实例。

```dart
enum Vehicle implements Comparable<Vehicle> {
  car(tires: 4, passengers: 5, carbonPerKilometer: 400),
  bus(tires: 6, passengers: 50, carbonPerKilometer: 800),
  bicycle(tires: 2, passengers: 1, carbonPerKilometer: 0);

  const Vehicle({
    required this.tires,
    required this.passengers,
    required this.carbonPerKilometer,
  });

  final int tires;
  final int passengers;
  final int carbonPerKilometer;

  int get carbonFootprint => (carbonPerKilometer / passengers).round();

  bool get isTwoWheeled => this == Vehicle.bicycle;

  @override
  int compareTo(Vehicle other) => carbonFootprint - other.carbonFootprint;
}
```

## 使用

### static

像访问其他静态变量一样访问枚举值。

```dart
final favoriteColor = Color.blue;
if (favoriteColor == Color.blue) {
  print('Your favorite color is blue!');
}
```

### index

枚举值索引从0开始。

```dart
assert(Color.red.index == 0);
assert(Color.green.index == 1);
assert(Color.blue.index == 2);
```

### name

枚举值名称。

```dart
print(Color.blue.name); // 'blue'
```

### object

像访问普通对象一样访问枚举值的成员。

```dart
print(Vehicle.car.carbonFootprint);
```
