# Memory Safety

## 冲突产生条件

如果两次访问满足以下所有条件，就会发生冲突：
1. 两次访问并非都是读取，也并非都是原子访问。
1. 它们访问内存中的同一位置。
1. 它们的持续时间重叠。

**错误1：**

```swift
var stepSize = 1

func increment(_ number: inout Int) {
    number += stepSize
}

increment(&stepSize)
// Error: conflicting accesses to stepSize
// Thread 1: Simultaneous accesses to 0x100008000, but modification requires exclusive access
```

![](./Images/memory_increment@2x.png)

**错误2：**

```swift
func balance(_ x: inout Int, _ y: inout Int) {
    let sum = x + y
    x = sum / 2
    y = sum - x
}
var playerOneScore = 42
balance(&playerOneScore, &playerOneScore)
// Error: conflicting accesses to playerOneScore
```

同时对内存中的同一位置执行两次写访问

**错误3：**

```swift
func balance(_ x: inout Int, _ y: inout Int) {
    let sum = x + y
    x = sum / 2
    y = sum - x
}

struct Player {
    var health: Int
    var energy: Int
}

var player = Player(health: 10, energy: 20)
balance(&player.health, &player.energy)
```

值类型（元组、枚举、结构体），改变值的任何部分都会改变整个值。这意味着对其中一个属性的读取或写入访问需要对整个值进行读取或写入访问

**正确：**

```swift
func balance(_ x: inout Int, _ y: inout Int) {
    let sum = x + y
    x = sum / 2
    y = sum - x
}

struct Player {
    var health: Int
    var energy: Int
}

func someFunc() {
    var player = Player(health: 10, energy: 20)
    balance(&player.health, &player.energy)
}
```

如果满足以下所有条件，对结构属性的重叠访问是安全的：
1. 您只访问实例的存储属性，而不是计算属性或类属性。
1. 结构是局部变量的值，而不是全局变量。
1. 结构要么不被任何闭包捕获，要么只被非逃逸闭包捕获。
