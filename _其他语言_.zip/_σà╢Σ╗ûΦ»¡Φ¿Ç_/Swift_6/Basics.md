# Basics

## let

编译时可以没有值，但只能被赋值一次。

## unwrap

简短解包，名称与未解包的名称一致。

```swift
if let nickname {
    print("Hey, \(nickname)")
}
```

## tuple

```swift
let http404Error = (code: 404, msg: "Not Found")
let (statusCode, statusMessage) = http404Error

print(statusCode)                   //  404
print(statusMessage)                //  Not Found

print(http404Error.0)               //  404
print(http404Error.1)               //  Not Found

print(http404Error.code)            //  404
print(http404Error.msg)             //  Not Found
```

```swift
let a: (code: Int, msg: String) = (code: 404, msg: "Not Found")
let b: (Int, String) = (code: 404, msg: "Not Found")
let c: (Int, String) = (404, "Not Found")
```

## assert & precondition

- **assert**：仅在debug模式下有效
- **precondition**：在debug和release模式下都有效

## Assignment Operator

`=` ：与C语言不同，不返回值

## 元组比较条件

1. 元组类型相同。
1. 值个数相等。
1. 每个元素类型都是可比较的。
1. 从左到右比较，直到不相等或结尾。

```swift
(1, "zebra") < (2, "apple")   // true because 1 is less than 2; "zebra" and "apple" aren't compared
(3, "apple") < (3, "bird")    // true because 3 is equal to 3, and "apple" is less than "bird"
(4, "dog") == (4, "dog")      // true because 4 is equal to 4, and "dog" is equal to "dog"
("blue", false) < ("purple", true)  // Error because < can't compare Boolean values
```

## One-Sided Ranges

- `..<` 区间 [start, end)
- `...` 区间 [start, end]

```swift
let range = ...5
range.contains(7)   // false
range.contains(4)   // true
range.contains(-1)  // true
```


