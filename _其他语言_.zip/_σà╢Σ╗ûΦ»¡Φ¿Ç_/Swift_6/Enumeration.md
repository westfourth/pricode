# Enumeration

## 遍历

采用`CaseIterable`协议，访问`allCases`属性

```swift
enum CompassDirection: CaseIterable {
    case north, south, east, west
}

let count = CompassDirection.allCases.count

for direction in CompassDirection.allCases {
    print(direction)
}
```

## 关联值

```swift
enum Barcode {
    case upc(Int, Int, Int, Int)
    case qrCode(String)
}

var productBarcode = Barcode.upc(11, 22, 33, 44)

switch productBarcode {
case let .upc(numberSystem, manufacturer, product, check):
    print("UPC : \(numberSystem), \(manufacturer), \(product), \(check).")
case .qrCode(let productCode):
    print("QR code: \(productCode).")
}
```

## 原始值

1. 整形枚举默认值为0，后续递增。
1. 字符串枚举默认值为该枚举名对应的字符串。

```swift
enum Rank: Int, CaseIterable {
    case first, second, third = 33, fourth
}

enum Compass: String, CaseIterable {
    case east, west, south = "CC", north
}

for i in Rank.allCases {
    print(i.rawValue)                       //  0   1   33  34
}

for i in Compass.allCases {
    print(i.rawValue)                       //  "east"   "west"   "CC"   "north"
}

let c1 = Compass(rawValue: "ABC")           //    nil
let c2 = Compass(rawValue: "south")         //    nil
let c3 = Compass(rawValue: "CC")            //    Compass.south?
```

## 递归枚举

```swift
enum ArithmeticExpression {
    case number(Int)
    indirect case addition(ArithmeticExpression, ArithmeticExpression)
    indirect case multiplication(ArithmeticExpression, ArithmeticExpression)
}
```

也可将`indirect`放在`enum`前面

```swift
indirect enum ArithmeticExpression {
    case number(Int)
    case addition(ArithmeticExpression, ArithmeticExpression)
    case multiplication(ArithmeticExpression, ArithmeticExpression)
}
```

举例

```swift
//  (5 + 4) * 2
let five = ArithmeticExpression.number(5)
let four = ArithmeticExpression.number(4)
let two = ArithmeticExpression.number(2)

let sum = ArithmeticExpression.addition(five, four)
let product = ArithmeticExpression.multiplication(sum, two)

func evaluate(_ expression: ArithmeticExpression) -> Int {
    switch expression {
    case let .number(value):
        return value
    case let .addition(left, right):
        return evaluate(left) + evaluate(right)
    case let .multiplication(left, right):
        return evaluate(left) * evaluate(right)
    }
}

print(evaluate(product))
```