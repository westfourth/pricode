# Concurrency

## 定义和调用

**没有throw**

```swift
func request(url: String) async -> String {
    if (try? await Task.sleep(for: .seconds(2))) != nil {
        return "https://" + url
    }
    return "[Unknown]"
}

var result = await request(url: "www.baidu.com")
print(result)
```

**有throw**

```swift
func request(url: String) async throws -> String {
    try? await Task.sleep(for: .seconds(2))
    return "https://" + url
}

var result = try? await request(url: "www.baidu.com")
if result != nil {
    print(result!)
}
```

## 串行与并行

```swift
let result0 = await request(url: "www.baidu0.com")
let result1 = await request(url: "www.baidu1.com")
let result2 = await request(url: "www.baidu2.com")

let results = [result0, result1, result2]
```

`result0`执行完后再执行`result1`，`result1`执行完后再执行`result2`。

```swift
async let result0 = request(url: "www.baidu0.com")
async let result1 = request(url: "www.baidu1.com")
async let result2 = request(url: "www.baidu2.com")

var results = await [result0, result1, result2]
//  或
var results = [await result0, await result1, await result2]
```

`result0`、`result1`、`result2`同时执行。

## 结构化并行

Each task in a given task group has the same parent task, and each task can have child tasks.

- In a parent task, you can’t forget to wait for its child tasks to complete.
- When setting a higher priority on a child task, the parent task’s priority is automatically escalated.
- When a parent task is canceled, each of its child tasks is also automatically canceled.
- Task-local values propagate to child tasks efficiently and automatically.

```swift
func request(url: String) async -> String {
    if (try? await Task.sleep(for: .seconds(2))) != nil {
        return "https://" + url
    }
    return "[Unknown]"
}

let results = await withTaskGroup(of: String.self) { group in
    group.addTask {
        return await request(url: "www.baidu0.com")
    }
    group.addTask {
        return await request(url: "www.baidu1.com")
    }
    group.addTask {
        return await request(url: "www.baidu2.com")
    }
    
    var results = [String]()
    for await result in group {
        results.append(result)
        print(result)
    }
    
    return results
}
print(results)
```

>更多参考：[Tasks and Task Groups](https://docs.swift.org/swift-book/documentation/the-swift-programming-language/concurrency/#Tasks-and-Task-Groups)

## 非结构化并行

Unlike tasks that are part of a task group, an unstructured task doesn’t have a parent task.

```swift
func request(url: String) async -> String {
    if (try? await Task.sleep(for: .seconds(2))) != nil {
        return "https://" + url
    }
    return "[Unknown]"
}

let task = Task {
    return await request(url: "www.baidu0.com")
}
let result0 = await task.value
```

## Actor

`Actor`在并发代码之间安全地共享信息，`Actor`一次只允许一个`Task`访问其可变状态。

`Actor`是引用类型，使用方法与`struct`和`class`相同。

```swift
actor TemperatureLogger {
    let label: String
    var measurements: [Int]
    private(set) var max: Int

    init(label: String, measurement: Int) {
        self.label = label
        self.measurements = [measurement]
        self.max = measurement
    }
}

extension TemperatureLogger {
    func update(with measurement: Int) {
        measurements.append(measurement)
        if measurement > max {
            max = measurement
        }
    }
}

let logger = TemperatureLogger(label: "Outdoors", measurement: 25)
await logger.update(with: 26)

print(await logger.measurements)
// Prints [25, 26]
print(await logger.max)
// Prints "25"
```

>更多参考：[Actors](https://docs.swift.org/swift-book/documentation/the-swift-programming-language/concurrency/#Actors)

## Sendable

Inside of a task or an instance of an actor, the part of a program that contains mutable state, like variables and properties, is called a `concurrency domain`.

A type that can be shared from one `concurrency domain` to another is known as a `sendable type`.

```swift
struct TemperatureReading: Sendable {
    var measurement: Int
}

extension TemperatureLogger {
    func addReading(from reading: TemperatureReading) {
        measurements.append(reading.measurement)
    }
}


let logger = TemperatureLogger(label: "Tea kettle", measurement: 85)
let reading = TemperatureReading(measurement: 45)
await logger.addReading(from: reading)
```

>更多参考：[Sendable Types](https://docs.swift.org/swift-book/documentation/the-swift-programming-language/concurrency/#Sendable-Types)