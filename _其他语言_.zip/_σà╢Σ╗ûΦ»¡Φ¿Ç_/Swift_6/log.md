# 记录

### 2025-02-11

1. 记忆5遍；
1. 整理之前学习的doc文档；
1. 整理之前学习的markdown文档；

- [ ] [Property](<Property.md>)（`Property Wrapper`）
- [ ] [Concurrency](<Concurrency.md>)（`Task`、`Actor`、`Sendable`）
- [ ] [Macros](<Macros.md>)（`完全不懂`）
- [x] [Generic](<Generic.md>) [`关联类型限制`、`where扩展`]
- [x] [Memory Safety](<Memory Safety.md>)
- [x] [Access Control](<Access Control.md>) [`原则`、`默认等级`、`getter & setter`]
- [ ] [Advanced Operators](<Advanced Operators.md>)（`Result Builders`）