# Error Handling

## throws

在`->`前加上`throws`

```swift
func canThrowErrors() throws -> String

func cannotThrowErrors() -> String
```

## try

```swift
let name = try? vend(name: "")              //  String?
```

如果抛出错误，那么`name`为`nil`

## 错误传播

`throw`抛出错误

```swift
enum ResultError: Error {
    case invalid
    case valid
}

func vend(name: String) throws -> String {
    guard name.count > 0 else {
        throw ResultError.valid
    }
    return "Vend: " + name
}

func vendCar(name: String) throws -> String {
    //  如果出错，会继续传播错误
    return try vend(name: name)
}
```

> 如果出错，函数后续代码不再执行，错误将继续传播

## 错误处理

使用`do-catch`处理错误。`do-catch`语法：

```swift
do {
    try <#expression#>
    <#statements#>
} catch <#pattern 1#> {
    <#statements#>
} catch <#pattern 2#> where <#condition#> {
    <#statements#>
} catch <#pattern 3#>, <#pattern 4#> where <#condition#> {
    <#statements#>
} catch {
    <#statements#>
}
```

如果`catch`后没有表达式，那么表达式会匹配任何错误，并且将错误绑定到局部常量`error`上

```swift
func handleError() {
    do {
        //  如果出错，会继续传播错误
        let str = try vend(name: "")
        print(str)
    } catch ResultError.invalid {
        print("ResultError.invalid")
    } catch {
        print(error)
    }
}

handleError()
```

如果`catch`没有处理所有可能的错误，那么错误将在其所在的范围继续传播

```swift
func handleThrowError() throws {
    do {
        //  如果出错，会继续传播错误
        let str = try vend(name: "")
        print(str)
    } catch ResultError.invalid {
        print("ResultError.invalid")
    }
}

try handleThrowError()
```

> 注意：`do-catch`不能捕捉`try?`抛出的错误

## 指定错误类型

```swift
enum ResultError: Error {
    case invalid
    case valid
}

func vend(name: String) throws(ResultError) -> String {
    guard name.count > 0 else {
        throw .invalid
    }
    return "Vend: " + name
}

do throws(ResultError) {
    let str = try vend(name: "")
    print(str)
} catch {
    switch error {
    case .invalid:
        print("=== invalid")
    case .valid:
        print("=== valid")
    }
}
```


