# Inheritance

## Override

访问父类的属性、方法、下标方法可使用super调用

```swift
class Vehicle {
    var currentSpeed = 0.0
    var description: String {
        return "Vehicle traveling at \(currentSpeed)km/h"
    }
    
    func makeNoise() {
        print("Vehicle make noisse")
    }
    
    subscript(hour: Double) -> Double {
        return currentSpeed * hour
    }
}

class Bicycle: Vehicle {
    var hasBasket = false
    
    override var description: String {
        get {
            print(super.description)
            return "Bicycle traveling at \(currentSpeed + 10)km/h"
        }
        set {
            print("Bicycle override description: " + newValue)
        }
    }
    
    override func makeNoise() {
        super.makeNoise()
        print("Bicycle make noisse")
    }
    
    override subscript(hour: Double) -> Double {
        return super[hour] + 10
    }
}
```

## get、set

- 父类的readonly属性可以被子类override为read-write属性。
- 父类的read-write属性不可以被子类override为readonly属性。

```swift
class Vehicle {
    var description: String {
        get {
            return "Vehicle traveling at 10km/h"
        }
        set {
            print("Vehicle set description: " + newValue)
        }
    }
}

class Bicycle: Vehicle {
    override var description: String {
        get {
            return "Bicycle traveling at 20km/h"
        }
    }
}
```

编译报错：Cannot override mutable property with read-only property 'description'


## willSet、didSet

`willSet`、`didSet` 会自动调用父类的 `willSet`、`didSet`。

```swift
class StepCounter {
    var totalSteps: Int = 0 {
        willSet(newTotalSteps) {
            print("About to set totalSteps to \(newTotalSteps)")
        }
        didSet {
            if totalSteps > oldValue  {
                print("Added \(totalSteps - oldValue) steps")
            }
        }
    }
}

class StepCounter2: StepCounter {
    override var totalSteps: Int {
        willSet(newTotalSteps) {
            print("==About to set totalSteps to \(newTotalSteps)")
        }
        didSet {
            if totalSteps > oldValue  {
                print("==Added \(totalSteps - oldValue) steps")
            }
        }
    }
}

let stepCounter = StepCounter2()
stepCounter.totalSteps = 200
```

输出

```sh
==About to set totalSteps to 200
About to set totalSteps to 200
Added 200 steps
==Added 200 steps
```

## override & overload

| 类别 | 说明 |
| :-: | :-- |
| override | 子类定义了一个与其父类中具有相同名称、参数列表和返回类型的方法，并且子类方法的实现覆盖了父类方法的实现 |
| overload | 一个类里面，方法名字相同，而参数不同。返回类型可以相同也可以不同 |

函数重载，方法重写

### override

```swift
class Parent {
    func test() { }
}

class Child: Parent {
    override func test() { }
}
```

### overload

```c
__attribute__((overloadable)) UIColor* rgb(UInt32 red, UInt32 green, UInt32 blue);
__attribute__((overloadable)) UIColor* rgb(UInt32 red, UInt32 green, UInt32 blue, CGFloat alpha);
```