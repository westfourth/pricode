# Advanced Operators

溢出操作符：`&+`、`&-`、`&*`

不可重载操作符：`=`、`?:`

## 自定义操作符

三种：`prefix`、`infix`、`postfix`。

先声明，再使用。例如：

```swift
prefix operator +++

extension Vector2D {
    static prefix func +++ (vector: inout Vector2D) -> Vector2D {
        vector += vector
        return vector
    }
}
```

## Result Builders

>更多参考：[Result Builders](https://docs.swift.org/swift-book/documentation/the-swift-programming-language/advancedoperators/#Result-Builders)

