# Property

## 种类

- **Stored Property：** 存储值，可以有默认值。
- **Computed Property：** 不存储值，但有get、set方法。
- **Type Property：** 属于类型本身，通常以static或class修饰。

## Property Wrapper

属性包装：`@propertyWrapper`、`wrappedValue`

```swift
@propertyWrapper
struct TenOrLess {
    fileprivate var number = 0
    var wrappedValue: Int {
        get { return number }
        set { number = min(newValue, 10) }
    }
}

struct Rectangle {
    @TenOrLess var width: Int
    @TenOrLess var height: Int
}

//  方式1
var rect = Rectangle(width: TenOrLess(number: 14), height: TenOrLess(number: 4))
//  方式2
var rect2 = Rectangle()

print(rect.width)                   //  14
print(rect.height)                  //  4

rect.width = 6
print(rect.width)                   //  6

rect.height = 16
print(rect.height)                  //  10
```

>更多参考：[Property Wrappers](https://docs.swift.org/swift-book/documentation/the-swift-programming-language/properties#Property-Wrappers)

## Type Proprety

使用`static`声明`type property`，对于`class type`的`computed type property`也可使用`class`申明。


```swift
class SomeClass {
    static var storedTypeProperty = "Some value."
    static var computedTypeProperty: Int {
        return 27
    }
    class var overrideableComputedTypeProperty: Int {
        return 107
    }
}
```

如果是类方法，则不仅可使用`static`修饰，也可使用`class`修饰，计算属性在某种程度上来说也是方法。

> **注意：`store property`不能用`class`声明**

## static 与 class 区别

1. `class`不能在`enum`和`struct`中使用。
1. `store property`不能用`class`声明。
1. `static` 属性和方法不能被重写。