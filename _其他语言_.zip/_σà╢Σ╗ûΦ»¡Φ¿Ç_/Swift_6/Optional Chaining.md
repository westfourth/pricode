# Optional Chaining

## 调用方法

```swift
class Room {
    func printNumberOfRooms() { }
}

var room: Room? = Room()

if room?.printNumberOfRooms() != nil {
    print("Possible")
} else {
    print("Not possible")
}

// Prints "Possible"
```

`printNumberOfRooms()`没有指明返回值，但隐式返回`Void`，`room?.printNumberOfRooms()`链式调用返回`Void?`，`Void? != nil`

## 访问下标

链式访问下标，在`[`前使用`?`

```swift
var testScores = ["Dave": [86, 82, 84], "Bev": [79, 94, 81]]
testScores["Dave"]?[0] = 91
testScores["Bev"]?[0] += 1
testScores["Brian"]?[0] = 72
// the "Dave" array is now [91, 82, 84] and the "Bev" array is now [80, 94, 81]
```