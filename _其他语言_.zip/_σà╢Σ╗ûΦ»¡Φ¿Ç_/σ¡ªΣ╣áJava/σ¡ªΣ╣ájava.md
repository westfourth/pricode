# 基础

## 面向对象编程三原则

* **封装**：
* **继承**：
* **多态**：

## 注意事项

1. java主类名与文件名一致。

## 基本数据类型

基本数据类型不继承`Object`

因为可移植性要求，**Java的基本数据类型所占的空间是固定的。**

| bit | 8 | 16 | 32 | 64 | 32 | 64 | 1 | 16 |
| :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: | :--: |
| **java** | byte | short | int | long | float | double | boolean | char |
| **C** | char | short | **int** | long | float | double | **bool** | **unsigned short** |

C语言 **int** 类型字节数：

* 32位机器上占4个字节；
* 64位机器上占8个字节；

C语言没有 **bool** 类型。

Java的byte、short、int、long没有 **unsiged** 类型，**引用类型** 的默认值为null。

### 类型自动转换条件　

* 两种类型兼容
* 目标类型范围比源类型大

``` java
	int a = 4;
	float b = 5;
	float c = a + b;
```

### 类型强制转换

``` java
	int a = 4;
	float b = 5;
	int c = a + (int)b;
```

### 类型升级规则

* **byte**、**short**、**char** 晋升为 **int**
* **int**、**long**、**float**、**double** 从左到右优先级越来越高

### 不同数量的多维数组

``` java
	int[][] a = new int[4][];
	a[0] = new int[1];
	a[1] = new int[2];
	a[2] = new int[3];
	a[3] = new int[4];
```

### 类型推断

``` java
	var array = new int[5];
```

## 变量类型

* 局部变量没有默认值，所以局部变量被声明后，必须经过初始化，才可以使用。
* 实例变量具有默认值：
	* 数值型变量的默认值是`0`。
	* 布尔型变量的默认值是 `false`。
	* 引用类型变量的默认值是`null`。

>
<font color=blue>`Objective-C`的默认值规则也是完全一致的。</font>

## 流程控制

### foreach

``` java
int [] nums = {1, 2, 3, 4, 5};
for (int i: nums) {
    System.out.println(i);
}
```

### label

``` java
    public static void main(String[] args) {
        first: {
            second: {
                third: {
                    System.out.println("Before break");
                    if (true) break second;
                    System.out.println("After break");
                }
                System.out.println(">>> Second");
            }
            System.out.println(">>> Third");
        }
    }
```

输出
>
``` sh
Before break
>>> Third
```

``` java
    public static void main(String[] args) {
        outer: for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                System.out.print(j + " ");
                if (j >= i) {
                    System.out.println();
                    continue outer;
                }
            }
        }
    }
```

输出
>
``` sh
0 
0 1 
0 1 2 
```

## Java对象和类

### 构造方法

构造方法的名称必须与类同名

``` java
public class Puppy{
   public Puppy(){
   }

   public Puppy(String name){
      // 这个构造器仅有一个参数：name
   }
}
```

一旦定义了自己的构造方法时，默认的构造方法就会失效。

### 内嵌类

``` java
class Outer {
    int x = 10;
    
    Outer(int a) {
        Inner inner = new Inner();
        inner.display(x);
    }
    
    void display() {
        System.out.println("outer = " + x);
    }
    
    class Inner {
        void display(int n) {
            x = n * 2;
            System.out.println("inner = " + n);
        }
    }
}
```

内嵌类中的内部类对外不可见

``` java
//	错误
Outer.Inner in = new Outer.Inner();
//	错误
Inner in = new Inner();
```

## 方法

### static

``` java
public class HelloWorld {
    public static void main(String[] args) {
        System.out.println("start");
        Box.test();
    }
}


class Box {
    static int a = 3;
    static int b;
    
    //  static代码块在这个类载入时（第一次使用）执行，且只执行一次
    static {
        System.out.println("static block initialized");
        b = 4;
    }
    
    static void test() {
        System.out.println("a = " + a + "\n" + "b = " + b);
    }
}
```

输出
>
``` sh
start
static block initialized
a = 3
b = 4
```

### 可变参数

``` java
    static void print(int[] array) {
        for (int i: array) {
            System.out.println("i = " + i);
        }
    }
    
    static void print2(int ... array) {
        for (int i: array) {
            System.out.println("i = " + i);
        }
    }
```

**可变参数必须是最后一个参数，且可变参数只能有一个**。

``` java
public class HelloWorld {
    static void print(int ... array) {
        System.out.println(">>> int");
    }
    
    static void print(boolean ... array) {
        System.out.println(">>> float");
    }
    
    public static void main(String[] args) {
        print();
    }
}
```

编译
>
``` sh
HelloWorld.java:17: 错误: 对print的引用不明确
        print();
        ^
  HelloWorld 中的方法 print(int...) 和 HelloWorld 中的方法 print(boolean...) 都匹配
1 个错误
```

### 可变参数

格式：

``` java
typeName... parameterName
```

举例：

``` java
public void max(double... args) {
	int len = args.length;
}
```

``` java
public void max(double args[]) {
	int len = args.length;
}
```

### finalize()

在对象被垃圾收集器回收之前调用，格式：

``` java
protected void finalize() {
	//
}
```

``` java
System.gc();		//	手动调用java垃圾收集器
```

## 修饰符

| java | oc | 说明 |
| :--: | :--: | :--: | 
| private | @private | 同类中可见，子类不可见 |
| protected | **@protected** | 同类、子类中可见 |
| **default** | @package | 包内可见，包外不可见 |
| public | @public | 所有类可见 |

java默认修饰符`default`，oc默认修饰符`@protected`。

![成员变量访问权限](成员变量访问权限.png)

### java访问权限

private < default < protected < public

### final

* `final`声明的方法不可以被子类`override`
* `final`声明的类中所有的方法都是`final`，且`final`申明的类不可以被继承

## 运算符

### 算数运算符

``` c
int a = 10;
int b = 10;
int a2 = a++;   //  10
int b2 = ++b;   //  11
```

### instanceof

检查该对象是否是一个特定类型

``` java
String name = "James";
boolean b1 = name instanceof String;    //  true
```

## Number类

| 包装类 | 基本数据类型 |
| :--: | :--: |
| Boolean | boolean |
| Byte | byte |
| Short | short |
| Integer | int |
| Long | long |
| Character | char |
| Float | float |
| Double | double |

编译器会自动将基本数据类型装箱成对象类型；或者将对象类型拆箱成基本数据类型。

## 数组

### 数组声明

``` java
dataType[] arrayRefVar;   // 首选的方法

dataType arrayRefVar[];  // 效果相同，但不是首选方法
```

# 面向对象

## 继承

### 继承格式

子类可以继承父类除private属性外的所有属性。

``` java
public class A {};

public class B extends A {};			//	B继承A
```

### 继承接口

java支持值单继承，但可以用接口实现（多继承）

``` java

public class Fruit {};

public class Fruit1 {};

public class Fruit2 {};

public class Apple extends Fruit implements Fruit1, Fruit2 {};
```

### 继承规范

* 子类不继承父类的构造方法
* 子类必须显式/隐式调用直接父类构造方法
* 在子类的构造器中，super调用必须是第一个语句
* super指直接父类，在构造方法中不能调用间接父类的构造方法

### super

``` java
class A {
    int i;
}

class B extends A {
    int i;
    
    B(int x, int y) {
        super.i = x;
        i = y;
    }
}
```

方法名相同，但签名不同时，方法`overload`

``` java
class B extends A {
    void print(int a) {
    }
}

class C extends B {
    void print(double a) {
    }
}
```


## 重写(override)与重载(overload)

* 重写是子类对父类允许访问的方法进行重新编写；返回值、形参都不能改变。
* 重载是方法名字相同、参数不同。

| 区别 | 重载 | 重写 |
| :--: | :--: | --- |
| **参数类型** | 必须修改 | 不能修改 |
| **返回类型** | 可以修改 | 不能修改 |
| **异常** | 可以修改 | 可以减少或删除，一定不能抛出新的或者更广的异常 |
| **访问** | 可以修改 | 一定不能做更严格的限制 |

``` java
public class HelloWorld {
    int a;
    int b;

    HelloWorld() {
        this(1, 2);
    }

    HelloWorld(int a, int b) {
        this.a = a;
        this.b = b;
    }
}
```

## 多态

**多态**是同一种行为具有多种不同表现形式或形态的能力。

多态的实现方式：

1. 重写
1. 接口
1. 抽象类和抽象方法

## 抽象类

抽象类出了不能实例化对象之外，类的其他功能依然存在。抽象类必须被继承才能使用。

### 抽象方法

使用abstract声明抽象方法，抽象方法只包含一个方法名，没有方法体。

``` java
public abstract class Employee
{
   private String name;
     
   public abstract double computePay();
   
   void callmetoo() {
		System.out.println("callmetoo");
	}
}
```

* 如果一个类包含抽象方法，那么该类必须是抽象类。
* 任何子类必须重写父类的抽象方法，或者声明自身为抽象类。

继承抽象方法的子类必须重写该方法；否则该子类也必须声明为抽象类。最终必须有子类实现该抽象方法，否则从最初的父类到最终的子类都不能实例化对象。

## 接口

**接口**是抽象方法的集合。

`java`中的`interface`对应`Objective-C`中的`@protocol`

### 接口与类的区别：

* 接口不能用于实例化对象。
* 接口没有构造方法。
* 接口中所有的方法必须是抽象方法。
* 接口不能包含成员变量，除了static和final变量。
* 接口不是被类继承了，而是要被类实现。
* 接口支持多重继承。

### 接口的声明：

``` java
[可见度] interface 接口名称 [extends 其他接口名称] {
	//	声明变量
	//	抽象方法
}
```

### 接口的实现：

``` java
... implements 接口名称[, 其他接口, 其他接口..., ...] ...
```

### 接口的特性：

* 接口是隐式抽象的，当申明一个接口的时候，不必使用`abstract`关键字。
* 接口中每一个方法也是隐式抽象的，声明式也不需要`abstract`关键字。
* 接口中的方法都是`public`。

### 接口中的变量

``` java
interface ABC {
    int a = 1;
    int b = 2;
    int c = 3;
}

class Test implements ABC {
    void answer2(int i) {
        if (i < c) {
            System.out.println(i + " < c");
        } else {
            System.out.println(i + " > c");
        }
    }
}
```

### 接口默认方法

``` java
interface A {
    default void aaa() {
        System.out.println("aaa");
    }
}
```

用`default`声明方法

### 接口的静态方法

``` java
interface A {
    static void abc() {
        System.out.println("abc");
    }
}
```

调用

``` java
A.abc();
```

接口中的静态方法不被继承

### 接口中的私有方法

``` java
interface A {
    default void aaa() {
        print();
    }
    
    private void print() {
        System.out.println("print");
    }
}
```

接口中的私有方法只能被该接口自身使用。

### 多接口

`接口A`、`接口B`、`类Test`，并且`接口A`、`接口B`中有相同的默认方法：

* 如果`类Test`实现此方法，那么使用`类Test`中的方法。
* 如果`类Test`没实现此方法，那么编译报错。

`接口A`、`接口B`、`类Test`，并且`接口A`、`接口B`中有相同的默认方法，`接口B`继承`接口A`：

1. 优先使用`类Test`中的方法；
2. 如果没有，再使用`接口B`中的方法；
3. 如果没有，再使用`接口A`中的方法。

### 接口继承

``` java
interface A {
    default void aaa() {
        System.out.println("aaa");
    }
}

interface B extends A {
    default void aaa() {
        A.super.aaa();
        System.out.println("bbb");
    }
}
```

### 内嵌接口

``` java
class A {
    //
    interface Callback {
        void callback(int param);
    }
}

class B implements A.Callback {
    //
    public void callback(int param) {
        System.out.println("callback " + param);
    }
}
```

### 标记接口

**标记接口**是没有包含任何方法的接口。

## 包

### 语法格式

``` java
package pkg1[. pkg2[. pkg3...]];
```

### 使用

``` java
import package1[.package2...].(classname|*);
```

### 举例

``` java
package mypack;

public class HelloWorld {
    public static void main(String[] args) {
        B b = new B();
        b.callme();
    }
}

class B  {
    void callme() {
        System.out.println("callme");
    }
}
```

* 该文件必须放在系统目录`mypack`下，即`mypack/HelloWrold.java`
* 使用`javac`编译不限制目录：`javac HelloWorld.java` 或者 `javac mypack/HelloWorld.java`
* 使用`java`运行时，必须在系统目录`mypack`上一层：`java mypack/HelloWorld`

### 导入

#### 1. 要导入的package为子目录

![](Images/包导入_子目录.png)

**Protection.java**

``` java
package p1;

public class Protection {
}
```

**TestBalance.java**

``` java
import p1.*;

public class TestBalance {
    public static void main(String[] args) {
        Protection p = new Protection();
    }
}
```

#### 2. 要导入的package为同级目录
| Protection.java | TestBalance.java |
| --- | --- |
| ![](Images/包导入_同级目录1.png) | ![](Images/包导入_同级目录2.png) |

``` sh
# 编译
javac -classpath ./ p2/TestBalance.java 
# 运行
java p2/TestBalance
```

## 异常

| ![](Images/JAVA异常类型.png)  |
| --- |

* 当try中抛异常时，try中的代码不会继续执行，控制马上交给catch
* catch中Exception子类要在Exception父类的前面，不然编译报错

``` java
	try {
	    int b = 10 / 0;
	    System.out.println(">>> 这段语句不会被执行");
	} catch (ArithmeticException e) {
	    System.out.println(">>> 除以0异常：" + e);
	} catch (ArrayIndexOutOfBoundsException e) {
	    System.out.println(">>> 数组越界异常：" + e);
	} catch (Exception e) {
	    System.out.println(">>> 通用异常" + e);
	}
```

### 内嵌try-catch

``` java
        try {
            int b = 10 / 1;
            
            try {
                int[] c = {1};
                c[1] = 111;
                System.out.println(">>>>>> 这段语句不会被执行");
            } catch (ArithmeticException e) {
                System.out.println(">>>>>> 除以0异常：" + e);
            }
            
        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println(">>> 数组越界异常：" + e);
        }
```

**内层的异常如果没有被catch，会抛向外层catch**

### 多catch

``` java
    static void demopro(boolean b) {
        NullPointerException e = new NullPointerException(">>> Top Layer <<<");
        ArithmeticException a = new ArithmeticException(">>> Cause <<<");
        if (b) {
            throw e;
        } else {
            throw a;
        }
    }
    
    public static void main(String[] args) {
        try {
            demopro(false);
        } catch (NullPointerException | ArithmeticException e) {
            System.out.println(e);
        }
    }
```

### throw

格式：

``` java
throw ThrowableInstance;
```

举例

``` java
    public static void main(String[] args) {
        try {
            demo();
        } catch (NullPointerException e) {
            System.out.println("main >>> " + e);
        }
    }
    
    
    static void demo() {
        try {
            throw new NullPointerException("demo");
        } catch (NullPointerException e) {
            System.out.println("demo >>> " + e);
            throw e;
        }
    }
```

输出：

``` sh
demo >>> java.lang.NullPointerException: demo
main >>> java.lang.NullPointerException: demo
```

### throws

格式：

``` java
type method-name(parameter-list) throws exception-list
{
   // body of method
}
```

举例

``` java
    public static void main(String[] args) {
        try {
            demo(1);
        } catch (ArithmeticException e) {
            System.out.println("ArithmeticException >>> " + e);
        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("ArrayIndexOutOfBoundsException >>> " + e);
        }
    }
    
    
    static void demo(int i) throws ArithmeticException, ArrayIndexOutOfBoundsException {
        if (i == 0) {
            throw new ArithmeticException("0");
        } else if (i == 1) {
            throw new ArrayIndexOutOfBoundsException("1");
        }
        System.out.println(">>> i = " + i);
    }
```

### Exception 

``` java
class CustomException extends Exception {
    public String toString() {
        return "CustomException";
    }
}
```

### 链式Exception

``` java
    static void demopro() {
        NullPointerException e = new NullPointerException(">>> Top Layer <<<");
        ArithmeticException a = new ArithmeticException(">>> Cause <<<");
        e.initCause(a);
        throw e;
    }
    
    public static void main(String[] args) {
        try {
            demopro();
        } catch (NullPointerException e) {
            System.out.println(e);
            System.out.println(e.getCause());
        }
    }
```

## 多线程

### Thread
![](Images/线程.png)

* 主线程最先开始，最后结束

### Runnable

``` java
public class HelloWorld {

    public static void main(String[] args) {
        System.out.println(">>> start" + Thread.currentThread());
        DemoThread d = new DemoThread();
        d.t.start();
        
        Thread t = Thread.currentThread();
        System.out.println("Main Thread: " + t);
        mainExec(t, "Main", 500);
        System.out.println(">>> end" + Thread.currentThread());
    }
    
    public static void mainExec(Thread t, String threadName, long interval) {
        try {
            for (int i = 0; i < 3; i++) {
                Thread.sleep(interval);
                System.out.println(threadName + " Thread: i = " + i);
            }
        } catch (InterruptedException e) {
            System.out.println(threadName + " Thread Interrupted: " + e);
        }
        System.out.println(threadName + " Thread Exit: " + t);
    }
}


class DemoThread implements Runnable {
    Thread t;
    
    DemoThread() {
        //  创建线程
        t = new Thread(this, "DemoThread");
        System.out.println("Child Thread: " + t);
    }
    
    public void run() {
        HelloWorld.mainExec(t, "Child", 1000);
    }
}
```

### Thread

``` java
public class HelloWorld {

    public static void main(String[] args) {
        System.out.println(">>> start" + Thread.currentThread());
        DemoThread2 d = new DemoThread2();
        d.start();
        
        Thread t = Thread.currentThread();
        System.out.println("Main Thread: " + t);
        mainExec(t, "Main", 500);
        System.out.println(">>> end" + Thread.currentThread());
    }
    
    public static void mainExec(Thread t, String threadName, long interval) {
        try {
            for (int i = 0; i < 3; i++) {
                Thread.sleep(interval);
                System.out.println(threadName + " Thread: i = " + i);
            }
        } catch (InterruptedException e) {
            System.out.println(threadName + " Thread Interrupted: " + e);
        }
        System.out.println(threadName + " Thread Exit: " + t);
    }
}

class DemoThread2 extends Thread {
    
    DemoThread2() {
        super("DemoThread2");
        System.out.println("Child Thread: " + this);
    }
    
    public void run() {
        HelloWorld.mainExec(this, "Child", 1000);
    }
}
```

### join()

``` java
public class HelloWorld {

    public static void main(String[] args) {
        System.out.println(">>> start <<< " + Thread.currentThread());
        DemoThread d1 = new DemoThread();
        DemoThread d2 = new DemoThread();
        d1.t.start();
        d2.t.start();
        
        System.out.println("before Thread 1 alive = "+ d1.t.isAlive());
        System.out.println("before Thread 2 alive = "+ d2.t.isAlive());
        System.out.println("before Thread Main alive = "+ Thread.currentThread().isAlive());
        
        try {
            d1.t.join();
            d2.t.join();
        } catch (InterruptedException e) {
            System.out.println("Main Thread Interrupted");
        }
        
        System.out.println("after Thread 1 alive = "+ d1.t.isAlive());
        System.out.println("after Thread 2 alive = "+ d2.t.isAlive());
        System.out.println("after Thread Main alive = "+ Thread.currentThread().isAlive());
        
        System.out.println(">>> end <<< " + Thread.currentThread());
    }
    
    public static void mainExec(Thread t, String threadName, long interval) {
        try {
            for (int i = 0; i < 3; i++) {
                Thread.sleep(interval);
                System.out.println(threadName + " Thread: i = " + i);
            }
        } catch (InterruptedException e) {
            System.out.println(threadName + " Thread Interrupted: " + e);
        }
        System.out.println(threadName + " Thread Exit: " + t);
    }
}

class DemoThread implements Runnable {
    Thread t;
    
    DemoThread() {
        //  创建线程
        t = new Thread(this, "DemoThread");
        System.out.println("Child Thread: " + t);
    }
    
    public void run() {
        HelloWorld.mainExec(t, "Child", 1000);
    }
}
```

当前线程等待join线程结束后，才继续执行

### synchronized

``` java
class Callme {
    synchronized void call(String msg) {
        System.out.println(">>> begin msg: " + msg);
        try {
            Thread.sleep((long)1e3);
        } catch (InterruptedException e) {
            System.out.println(">>> exception: " + e);
        }
        System.out.println(">>> end msg: " + msg);
    }
}
```

synchronized同一个线程可以多次进入，但其他线程只能等待

``` java
class Callme {
    void call(String msg) {
        synchronized(this) {
            System.out.println(">>> begin msg: " + msg);
            try {
                Thread.sleep((long)1e3);
            } catch (InterruptedException e) {
                System.out.println(">>> exception: " + e);
            }
            System.out.println(">>> end msg: " + msg);
        }
    }
}
```

### wait()、notify()、notifyAll()

这三个都是属于`Object`类的方法，所以所有类都有这三个方法，并且这三个方法只能在`synchronized`代码块中使用

``` java
class Product {
    private int n;
    boolean flag;

    synchronized int increase() {
        System.out.println("enter increase thread: " + Thread.currentThread());
        while (flag) {
            try {
                Thread.sleep(1000);
                wait();
            } catch (InterruptedException e) {
                System.out.println("InterruptedException: " + e);
            }
        }
        flag = !flag;
        System.out.println("increase " + ++n);
        notify();
        System.out.println("exit increase thread: " + Thread.currentThread());
        return n;
    }

    synchronized int decrease() {
        System.out.println("enter decrease thread: " + Thread.currentThread());
        while (!flag) {
            try {
                Thread.sleep(1000);
                wait();
            } catch (InterruptedException e) {
                System.out.println("InterruptedException: " + e);
            }
        }
        flag = !flag;
        System.out.println("decrease " + --n);
        notify();
        System.out.println("exit decrease thread: " + Thread.currentThread());
        return n;
    }
}
```

### 死锁

### suspend()、resume()、stop()

### 线程状态

![](Images/线程状态.png)
![](Images/线程状态变化.png)

## enum

``` java
enum Fruit { Apple, Orange, Banana }

Fruit[] list = Fruit.values();
for (Fruit f: list) {
    System.out.println(f);
}

Fruit f1 = Fruit.valueOf("Apple");
```

枚举类型被隐式声明为：`public static final`

``` java
public static enum-type[] values()
public static enum-type valueOf(String str)
```

### 枚举类型是`class type`

``` java
enum Fruit {
    Apple(4),
    Orange,                 //  默认初始化方法
    Banana(8);

    private int price;

    Fruit(int p) {
        price = p;
    }

    //  默认初始化方法
    Fruit() {
        price = -1;
    }

    int getPrice() {
        return price;
    }
}
```

``` java
    Fruit f = Fruit.Banana;
    int o = f.ordinal();        //  2，从0开始
    int price = f.getPrice();   //  8
```

* `enum`不可以继承`class`
* `class`不可以继承`enum`
* `enum`可以继承`enum`，所有`enum`自动继承`java.lang.Enum`

## Annotation

annotation不能继承，但所有的annotation自动继承`Annotation`

### 保留策略：

| Policy | File | When |
| --- | --- | --- |
| **SOURCE** | 在`.java`文件中 | 编译时不可用 |
| **CLASS** | 在`.class`文件中 | 运行时不可用 |
| **RUNTIME** | 在`.class`文件中 | 运行时可用 |

### 举例

``` java
import java.lang.annotation.*;
import java.lang.reflect.*;

@Retention(RetentionPolicy.RUNTIME)
@interface Anno {
    String name();
    int age();
    boolean sex();
}

public class HelloWorld {

    public static void main(String[] args) {
        increase("Tom", 12);
    }

    @Anno(name = "Tom", age = 12, sex = true)
     public static int increase(String name, int age) {
        HelloWorld h = new HelloWorld();
        Class<?> c = h.getClass();
//        Class<?> c = HelloWorld.class;

        System.out.println(c);

        try {
            Method m = c.getMethod("increase", String.class, int.class);
            System.out.println(m);

            Anno a = m.getAnnotation(Anno.class);
            System.out.println(a.name());
            System.out.println(a.age());
            System.out.println(a.sex());
        } catch (NoSuchMethodException e) {
            System.out.println(e);
        }

        return 1;
    }
}
```

``` java
Method getMethod(String methodName, Class<?> ...paramTypes)
```

### 默认值

``` java
@Retention(RetentionPolicy.RUNTIME)
@interface Anno {
    String name();
    int age() default 11;
    boolean sex() default true;
}
```
使用时，只要保证每个`Field`有值即可

``` java
@Anno(name = "Class")
@Anno(age = 12, name = "Class2")
```

### 标记Annotation

``` java
@interface Anno {
	String name();
}

//	使用
@Anno
```

### 单成员Annotation

``` java
@interface Anno {
}

//	使用
@Anno("Class")
```

### Type Annotation

## IO

### 自动关闭文件

``` java
    try (FileInputStream fi = new FileInputStream(filename) {
        //
    } catch (Exception e) {
        //
    }
```

### instanceof

``` java
class A { }
class B { }
class C extends A { }

A a = new A();
B b = new B();
C c = new C();

boolean b1 = a instanceof A;        		//  true
//	boolean b2 = b instanceof A;        //  编译错误
boolean b3 = c instanceof A;        	//  true
boolean b4 = a instanceof C;        	//  false
```

### Native方法

### assert 

``` java
int a = 1;
assert a > 0;								//	形式一
assert a > 1 : "a > 1 return false";		//	形式二
```
执行

``` java
java -ea HelloWorld
```

### static import 

``` java
double a = 3.0;
double b = 4.0;
double c = Math.sqrt(Math.pow(a, 2) + Math.pow(b, 2));
```

``` java
//	导入类成员（变量、方法）
import static java.lang.Math.*;

double a = 3.0;
double b = 4.0;
double c = sqrt(pow(a, 2) + pow(b, 2));
```

## 范型

**只有引用类型才可以使用范型，基础数据类型不可以使用范型。**

举例

``` java
class Gen<T> {
    T obj;

    Gen(T t) {
        obj = t;
    }

    T getObj() {
        return obj;
    }

    void showType() {
        System.out.println(obj.getClass().getName());
    }
}
```

调用 
>
``` java
Gen<Integer> i = new Gen<Integer>(123);
System.out.println(i.getObj());
i.showType();
```
>
``` java
Gen<String> i = new Gen<String>("123");
System.out.println(i.getObj());
i.showType();
```

### 限制范型类型

``` java
class Gen <T extends Number> { }
```

这样T就可以使用Number中的方法了。

``` java
class Gen <T extends MyClass & MyInterface & MyInterface2> { }
```

### 通配符

``` java
class Gen <T extends Number> {
    T a;
    T b;

    Gen(T a, T b) {
        this.a = a;
        this.b = b;
    }

    double sum() {
        return a.doubleValue() + b.doubleValue();
    }

    boolean isSame(Gen<T> g) {		//	错误: 不兼容的类型: Gen<Float>无法转换为Gen<Integer>
        if (sum() == g.sum()) return true;
        return false;
    }
}
```

调用
>
``` java
Gen<Integer> a = new Gen<Integer>(1, 2);
Gen<Float> b = new Gen<Float>((float)1.0, (float)2.0);
boolean equal = a.isSame(b);
```

处理：

``` java
    boolean isSame(Gen<?> g) {
        if (sum() == g.sum()) return true;
        return false;
    }
```

### 限制通配符

``` java
class TwoD {
    int x, y;

    TwoD(int x, int y) {
        this.x = x;
        this.y = y;
    }
}

class ThreeD extends TwoD {
    int z;

    ThreeD(int x, int y, int z) {
        super(x, y);
        this.z = z;
    }
}

class FourD extends ThreeD {
    int t;

    FourD(int x, int y, int z, int t) {
        super(x, y, z);
        this.t = t;
    }
}

class Coords<T extends TwoD> {
    T t;

    Coords(T t) {
        this.t = t;
    }

    static void show(Coords<?> c) {		//	错误: 找不到符号
        System.out.println("x = " + c.t.x + ", y = " + c.t.y + ", z = " + c.t.z);
    }
}
```

调用
>
``` java
TwoD t2 = new TwoD(1, 2);
ThreeD t3 = new ThreeD(11, 22, 33);
FourD t4 = new FourD(111, 222, 333, 444);
Coords<TwoD> c2 = new Coords<TwoD>(t3);
Coords<ThreeD> c3 = new Coords<ThreeD>(t3);
Coords<FourD> c4 = new Coords<FourD>(t4);
Coords.show(c3);
```

改为：

``` java
	static void show(Coords<? extends ThreeD> c) {
	    System.out.println("x = " + c.t.x + ", y = " + c.t.y + ", z = " + c.t.z);
	}
```

格式：

``` java
<? extends superclass>
```
``` java
<? super subclass>
```

### super

``` java
	//	这里不能使用ThreeD里面的成员（变量、方法），只能使用ThreeD父类的成员（变量、方法）
    static void show(Coords<? super ThreeD> c) {
        System.out.println("x = " + c.t.x + ", y = " + c.t.y);
    }
```

调用
>
``` java
Coords<TwoD> c2 = new Coords<TwoD>(t3);
Coords<ThreeD> c3 = new Coords<ThreeD>(t3);
Coords<FourD> c4 = new Coords<FourD>(t4);
//	这里只能传递ThreeD类、ThreeD父类（递归）的实例
Coords.show(c2);
```

### 范型方法

``` java
class Gen {
    public static <T extends Comparable> boolean isIn(T a, T[] list) {
        for (T i: list) {
            if (a.equals(i)) {
                return true;
            }
        }
        return false;
    }
}
```

调用
>
``` java
Integer[] b = {1, 2, 3};
String s = "first";
boolean r = Gen.isIn(s, b);
```

改为下面，编译报错（为啥？？？）：

``` java
class Gen {
    public static <T extends Comparable<T>> boolean isIn(T a, T[] list) {
        for (T i: list) {
            if (a.equals(i)) {
                return true;
            }
        }
        return false;
    }
}
```

### 范型构造器

``` java
class Gen {
    double d;

    <T extends Number> Gen(T t) {
        d = t.doubleValue();
    }
}
```

### 范型接口

``` java
interface Min <T extends Comparable<T>> {
    T min();
}

class Demo <T extends Comparable<T>> implements Min<T> {
    T[] list;

    Demo(T[] list) {
        this.list = list;
    }

    public T min() {
        T mi = list[0];
        for (T i: list) {
            if (mi.compareTo(i) > 0) {
                mi = i;
            }
        }
        return mi;
    }
}
```

**范型接口格式：**

``` java
interface interface-name<type-param-list> { //...
```

**采用范型接口的类格式：**

``` java
class class-name <type-param-list>
	implements interface-name<type-arg-list> { //...
```

### 范型类继承

``` java
class Gen <T> {
    T ob;

    Gen(T t) {
        ob = t;
    }

    T getOb() {
        return ob;
    }
}

class Gen2<T> extends Gen<T> {
    Gen2(T t) {
        super(t);
    }
}
```

**即使子类没有使用范型，也必须指定父类的范型类型**

### 范型类型推断

``` java
Gen<String, Integer> g1 = new Gen<String, Integer>("ABC", 123);
//	简化1
Gen<String, Integer> g2 = new Gen<>("ABC", 123);
//	简化2
var g3 = new Gen<String, Integer>("ABC", 123);
```

**格式：**

``` java
class-name<type-arg-list> var-name = new class-name<>(cons-arg-list)
```

### 范型限制 

**1. 范型类型不可以被初始化**

``` java
class Gen <T> {
    T ob;

    Gen(T t) {
        ob = new T();	//	错误
        ob = t;
    }
}
```

**2. 范型不可以用于静态成员（变量、方法）**

``` java
class Gen <T> {
    static T t;     //  错误

    public static void setOb(T t) {		//  错误
    }
}
```

**3. 不可以初始化范型数组**

这个和范型类型不可以被初始化一样。

``` java
class Gen <T> {
    T ob;

    Gen(T t) {
        T[] list = new T[10];		//	错误
        ob = t;
    }
}
```

**4. 不可以创建明确类型的范型数组**

``` java
class Gen <T> {
    public T ob;

    Gen(T t) {
        ob = t;
    }
}

Gen<String>[] g = new Gen<String>[10];		//	错误
Gen<?>[] g = new Gen<?>[10];				//	正确
```

**5. 范型不可以继承`Thorwable`**

## Lambda表达式

**格式**

``` java
(int a, int b) -> a + b
//	或
(a, b) -> a + b
```

如果其中一个参数申明类型时，那么所有参数都需要申明类型。

### 函数接口

**函数接口**：只有一个抽象方法的接口

``` java
interface MyNum {
    int add(int a, int b);
}
```

使用
>
``` java
MyNum n = (int a, int b) -> a + b;
int result = n.add(1, 2);
System.out.println(result);
```

当只有一个参数时，可以省略括号：

``` java
a -> a + 1;
```

### Block Lambda 表达式

``` java
(a, b) -> {
    int c = a + b;
    return c;
};
```

### 范型函数接口

lambda表达式不能为范型，但函数接口可以为范型。

``` java
interface MyNum <T> {
    T add(T a, T b);
}
```

调用
>
``` java
MyNum<Integer> n = (a, b) -> {
    int c = a + b;
    return c;
};
//
int result = n.add(1, 2);
MyNum<String> s = (a, b) -> {
    return a + b;
};
String result2 = s.add("first", "second");
```

### Lambda表达式作为参数

``` java
public class HelloWorld {
    public static int funcTest(MyNum f, int a, int b) {
        int c = f.add(a, b);
        return c;
    }

    public static void main(String[] args) {
        //  方式一
        MyNum f = (a, b) -> a + b;
        int result = funcTest(f, 11, 4);
        //  方式二
        int result2 = funcTest((a, b) -> a + b, 11, 4);
        System.out.println(result);
    }
}

// 函数接口
interface MyNum {
    int add(int a, int b);
}
```

### Lambda 变量捕捉

``` java
    int c = 2;
    MyNum f = (a, b) -> {
//        c = 3;    //  错误
        return a + b + c;
    };
//        c = 3;    //  错误
```

Lambda捕捉的变量被隐式申明为`final`，在Lambda内外都是不可以改变的。

### 方法引用

``` java
public class HelloWorld {
    public static int funcTest(MyNum f, int a, int b) {
        int c = f.add(a, b);
        return c;
    }

    public static void main(String[] args) {
        int r1 = funcTest(Test::add, 3, 2);
        System.out.println(r1);

        Test t = new Test();
        int r2 = funcTest(t::subtract, 4, 2);
        System.out.println(r2);
    }
}


class Test {
    static int add(int a, int b) {
        return a + b;
    }

    int subtract(int a, int b) {
        return a - b;
    }
}

// 函数接口
interface MyNum {
    int add(int a, int b);
}
```

* 类方法引用格式：`ClassName::staticMethodName`
* 实例方法引用格式：`objRef::instanceMethodName`

**特殊情况**

``` java
public class HelloWorld {
    public static int funcTest(MyNum f, int a, int b) {
        Test t = new Test(a);
        int c = f.add(t, a, b);
        return c;
    }

    public static void main(String[] args) {
        int r1 = funcTest(Test::subtract, 3, 2);
        System.out.println(r1);
    }
}


class Test {
    int a;

    Test(int a) {
        this.a = a;
    }

    static int add(int a, int b) {
        return a + b;
    }

    int subtract(int a, int b) {
        return a - b;
    }
}

// 函数接口
interface MyNum {
    int add(Test t, int a, int b);
}
```

当函数接口中的**第一个参数**的类型与调用时传递的**类名一致**时才可以使用。

* 实例方法引用格式：`ClassName::instanceMethodName`

**super**

* `super::name` 调用父类的方法名
* `typeName:super::name` 调用父接口的方法名

### 范型方法引用

``` java
public class HelloWorld {
    public static <T> boolean test(MyNum<T> f, T a, T b) {
        return f.add(a, b);
    }

    public static void main(String[] args) {
        boolean b = test(Test::<Integer>add, 3, 3);
        System.out.println(b);
    }
}


class Test {
    static <T> boolean add(T a, T b) {
        return a == b;
    }
}

// 函数接口
interface MyNum<T> {
    boolean add(T a, T b);
}
```

注意：`MyNum<T> f`、`Test::<Integer>add`

### 构造方法引用

``` java
public class HelloWorld {
    public static void main(String[] args) {
        MyFunc t = Test::new;
        Test a = t.func(10);
        System.out.println(a.a);
    }
}


class Test {
    int a;

    Test(int a) {
        this.a = a;
    }

    Test() {
        a = 1;
    }
}

interface MyFunc {
    Test func(int a);
}
```

### 范型构造方法引用

``` java
public class HelloWorld {
    public static void main(String[] args) {
        MyFunc<Integer> t = Test<Integer>::new;
        Test<Integer> a = t.func(10);
        System.out.println(a.a);
    }
}


class Test<T> {
    T a;

    Test(T a) {
        this.a = a;
    }

    Test() {
        a = null;
    }
}

interface MyFunc<T> {
    Test<T> func(T a);
}
```

注意：`Test<T>`

### 数组构造器???

``` java
public class HelloWorld {
    public static void main(String[] args) {
        MyFunc<Test[]> array = Test[]::new;
        Test[] a = array.func(100);
        a[0] = new Test(10);
        System.out.println(a[0].a);
    }
}

class Test {
    int a;

    Test(int a) {
        this.a = a;
    }

    Test() {
        a = 0;
    }
}

interface MyFunc<T> {
    T func(int a);
}
```

格式：

``` java
type[]::new
```

### ‼️闭包使用

``` java
public class HelloWorld {
    public static void main(String[] args) {
        MyFunc<Integer, Integer> f = (a, b) -> {
            return a + b;
        };
        Integer r = f.add(3, 4);
        System.out.println(r);
    }
}

interface MyFunc<R, T> {
    R add(T a, T b);
}
```

# 高级

## 数据结构

* 枚举（Enumeration）
* 位集合（BitSet）
* 向量（Vector）
* 栈（Stack）
* 字典（Dictionary）
* 哈希表（Hashtable）
* 属性（Properties）

## 范型

范型是将具体类型参数化，调用时传递具体类型。

范型只在编译之前有效，编译过程中会去范型，使用具体类型。

### 范型方法

``` java
public static <E> void printArray(E[] inputArray) {
	for(E element: inputArray) {
		//
	}
}
```

**限制类型参数的类型种类范围**

``` java
public static <T extends Comparable<T>> T maximum(T x, T y) {
	T max = x;
	if (y.compareTo(max) > 0) {
		max = y;
	}
	retrurn max;
}
```

### 范型类

``` java
public class Box<T> {
	private T t;

	public void add(T t) {
		this.t = t;
	}
}
```

## 序列化

### 序列化

* 该类必须实现java.io.Serializable对象。
* 该类的所有属性必须是可序列化的。如果有一个属性不是可序列化的，则该属性必须注明是短暂的。

``` java
public class Employee implements java.io.Serializable {
	public String name;
}
```

### 序列化对象

``` java
Employee e = new Employee();

try {
	FileOutputStream fileOut = new FileOutputStream("/tmp/employee.ser");
	ObjectOutputStream out = new ObjectOutputStream(fileOut);
	out.writeObject(e);
	out.close();
	fileOut.close();
} catch(IOException i) {
	i.printStackTrace();
}
```

### 反序列化对象

``` java
Employee e = null;
	
try {
	FileInputStream fileIn = new FileInputStream("/tmp/employee.ser");
	ObjectInputStream in = new ObjectInputStream(fileIn);
	e = (Employee) in.readObject();
	in.close();
	fileIn.close();
} catch(IOException i) {
	i.printStackTrace();
}
```

## 多线程编程

### 线程的生命周期

![线程的生命周期](./线程的生命周期.jpeg)

### 创建线程方式

* 实现Runnable接口；
* 继承NSThread类；
* 通过Callable和Future创建；