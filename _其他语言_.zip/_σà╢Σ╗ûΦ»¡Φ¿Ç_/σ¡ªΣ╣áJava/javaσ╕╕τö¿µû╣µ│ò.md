# 内置方法专题

## String

``` java
char charAt(int index)
//	返回指定索引处的char值。

int compareTo(Object o)
//	把这个字符串和另一个对象比较

int compareTo(String antherString)
//	按字典顺序比较两个字符串

int compareToIgnoreCase(String str)
//	按字典顺序比较两个字符串，不考虑大小写

String concat(String str)
//	将指定字符串连接到此字符串的结尾

boolean contentEquals(StringBuffer sb)
//	当且仅当字符串与指定的StringBuffer有相同的字符时候返回真

static String copyValueOf(char[] data)
//	返回指定数组中表示该字符序列的String

static String copyValueOf(char[] data, int offset, int count)
//	返回指定数组中表示该字字符序列的String

boolean endsWith(String suffix)
//	测试字符串是否以指定的后缀结束

boolean equals(Object anObject)
//	将此字符串与指定的对象比较

boolean equalsIgnoreCase(String antherString)
//	将此String与另一个String比较，不考虑大小写

byte[] getBytes()
//	使用平台默认的字符集将此String编码为byte序列，并将结果存储到一个新的byte数组中

byte[] getBytes(String charsetName)
//	使用指定的字符集将此String编码为byte序列，并将结果存储到一个新的byte数组中

int hashCode()
//	返回此字符串的哈希码

int indexOf(int ch)
//	返回指定字符在此字符串中第一次出现处的索引

int indexOf(int ch, int fromIndex)
//	返回在此字符串中第一次出现指定字符处的索引，从指定的索引开始搜索

String intern()
//	返回字符串对象的规范化表示形式

int lastIndexOf(int ch) 
//	返回指定字符在此字符串中最后一给出现处的索引

int lastIndexOf(int ch, int fromIndex)
//	返回指定字符在此字符串中最后一次出现处的索引，从指定的索引开始进行反向搜索

int lastIndexOf(String str)
//	返回指定子字符串在此字符串中最右边出现处的索引

int lastIndexOf(String str, int fromIndex)
//	返回指定子字符串在此字符串中最后一次出现处的索引，从指定的索引开始反向搜索

int length()
//	返回此字符串的长度

boolean matches(String regex)
//	判断此字符串是否匹配给定的正则表达式

boolean regionMatches(boolean ignoreCase, int toffset, String other, int ooffset, int len)
//	判断两个字符串区域是否相等

String replace(char oldChar, char newChar)
//	使用newChar替换该字符串中出现的所有oldChar，并且返回新的字符串

String replaceAll(String regex, String replacement)
//	使用replacement替换正则表达式匹配到的所有子字符串

String replaceFirst(String regex, String replacement)
//	使用replacement替换正则表达式匹配到的第一个子字符串

String[] split(String regex)
//	使用正则表达式拆分此字符串

String[] split(String regex, int limit)
//	使用正则表达式拆分此字符串

boolean startsWith(String prefix)
//	以指定的前缀开始

boolean startsWith(String prefix, int toffset)
//	从指定索引处开始的子字符串是否以指定的前缀开始

CharSequence subSequence(int beginIndex, int endIndex)
//	截取字符序列

String substring(int beginIndex)
//	从指定索引截取字符串

String substring(int beginIndex, int endIndex)
//	截取字符串

char[] toCharArray()
//	将字符串转换为字符数组

String toLowerCase()
//	小写

String toLowerCase(Locale locale)
//	使用指定的Locale将字符串转换成为小写

String toString()
//	返回对象本身

String toUpperCase()
//	大写

String toUpperCase(Locale locale)
//	使用指定的Locale将字符串转换为大写

String trim()
//	忽略头部、尾部空白

static String valueOf(primitive_data_type x)
//	返回给定data type类型x参数的字符串表示形式

```


## StringBuffer、StringBuilder

| 类型 | 读写 | 线程安全 |
| :--: | :--: | :--: |
| **String** | 只读 | 线程安全 |
| **StringBuffer** | 读写 | 非线程安全 |
| **StringBuilder** | 读写 | 线程安全 |

### StringBuffer

``` java
public StringBuffer append(String s)
//	追加字符串

public StringBuffer reverse()
//	字符反转

public delete(int start, int end)
//	删除子字符串

public insert(int offset, int i)
//	插入字符

replace(int start, int end, String str)
//	替换
```

下面方法与`String`方法类似

``` java


```