学习书籍：《The Definitive Guide To HTML5.pdf》

## HTML

### 元素

| 元素 | 描述 |
| :-- | :-- |
| a | 超链接 |
| body | HTML内容 |
| button | button |
| code | 代码 |
| DOCTYPE | HTML开头 |
| head | HTML头部区 |
| hr | 水平横线 |
| html | html区 |
| input | 输入框 |
| label | 标签 |
| p | 段落 |
| style | css样式 |
| table | 表格 |
| td | 表格cell |
| textarea | 多行输入 |
| th | 表格头cell |
| title | HTML标题 |
| tr | 表格列 |

### 属性

* 属性只能添加在（双标签的）开始标签，或者单标签，不能添加在（双标签的）结束标签。
* 多属性使用一个或多个空格区分开，不分先后顺序。

**布尔属性**

```html
<input disabled>
```
**自定义属性**

自定义属性以`data-`开头

```html
<input data-creator="Tom Hanks" data-date="2023-11-28 21:21">
```

**全局属性**

| 属性 | 简述 | 详述 |
| :-- | :-- | :-- |
| accesskey | 快捷键 | Mac下按下`control` + `option` + `<accesskey>` |
| class | 给元素分类 | 多个分类时使用空格分割 |
| contenteditable | 元素可编辑 |  |
| dir | 对齐方式 | 左、右对齐 |
| draggable | 可拖拽 |  |
| hidden | 隐藏 |  |
| id | 标记元素 | 多个元素可以使用同一个id |
| lang | 语言 |  |
| spellcheck | 语法检查 |  |
| style | 样式 |  |
| tabindex | 元素顺序 | 按tab键，负数表示不会被选中 |
| title | tips | 需要光标放置一小段时间 |

```html
<!DOCTYPE html>
<head>
    <meta charset="utf-8">
    <title>WEB TEST（网页测试）</title>

    <style type="text/css">
        .clsA {             /* class分类 */
            font-size: 24px;
        }
        .clsB {
            color: blue;
        }
        #r2l {              /* id标记 */
            color: orange;
            font-size: 24px;
        }
        p, a {              /* 元素 */
            border: 1px solid blue;
        }
    </style>

</head>
<body>
<input class="clsA" type="text" value="name" accesskey="n" tabindex="8">
<input class="clsB" type="password" value="password" accesskey="p" tabindex="5">
<input class="clsA clsB" type="submit" value="Log in" accesskey="s">
<p contenteditable="false"  id="r2l">this is an editable area</p>
<p dir="rtl" id="r2l">this is a right to left</p>
<p dir="ltr" draggable="true" style="background: orange; color: blue; font-size: 20px">this is a left to right</p>
<textarea spellcheck="true">this is somea mispelled text</textarea><br>
<a title="访问">visit</a>

    <script type="text/javascript">
        var elems = document.getElementsByClassName("clsA");
        for (i = 0; i < elems.length; i++) {
            var x = elems[i];
            x.style.border = "solid blue";
        }
    </script>

</body>
</html>
```

## CSS

### 内联CSS

```html
<p dir="ltr" draggable="true" style="background: orange; color: blue; font-size: 20px">this is a left to right</p>
```

### 内嵌CSS

```html
<!DOCTYPE html>
<head>
    <meta charset="utf-8">
    <title>WEB TEST（网页测试）</title>
    <style type="text/css">
        p, a {              /* 元素 */
            border: 1px solid blue;
        }
    </style>
</head>
</html>
```

### 外部CSS

```html
<!DOCTYPE html>
<head>
    <meta charset="utf-8">
    <title>WEB TEST（网页测试）</title>
    <link rel="stylesheet" style="text/css" href="test.css"></link>
</head>
</html>
```

### CSS引用CSS

文件：test.css

```css
	.clsA {             /* class分类 */
	    font-size: 24px;
	    color: blue;
	}
	.clsB {
	    color: blue;
	}
	#r2l {              /* id标记 */
	    color: orange;
	    font-size: 24px;
	}
	p, a {              /* 元素 */
	    border: 1px solid blue;
	}
```

文件：test2.css

```css
	@import "test.css";
	
	a {                 /* 元素 */
	    color: blue;
	    font-size: 24px;
	}
```

html文件

```html
<link rel="stylesheet" style="text/css" href="test2.css"></link>
```

### CSS渲染顺序

> 
1. 内联CSS
1. 内嵌CSS
1. 外部CSS（`link`）
1. 用户CSS（浏览器允许用户自定义CSS）
1. 浏览器CSS（默认的CSS）

**使用`!important`修正顺序**

```css
	a {
	    color: orange !important;
	    font-size: 24px;
	}
```

**一个元素有多个同名属性时，处理顺序（page-52）**

> 
1. 
1. 
1. 

```css

```

### 继承

如果没有找到指定属性的值，将会使用父元素对应属性的值。

不是所有的属性都会被继承，
>
* 外观属性会被继承
* 布局属性不会被继承

使用`inherit`强制继承。


```html
<html>
<head>
    <meta charset="utf-8"></meta>
    <title>WEB网页</title>
    <style type="text/css">
        p {
            color: white;
            background: grey;
            border: medium solid black;
        }
        span {
            border: inherit;
        }
    </style>
</head>
<body>
<a href="https://www.baidu.com">Visit Apress Website</a><br>
<p>I like <span style="font-weight: bold">apples</span> and oranges</p>
<a class="my you" href="https://www.so.com">W3C School</a>
</body>
</html>
```

### 颜色

>
* `rgb(0, 255, 0)`
* `rgb(0, 255, 0, 0.5)`
* `#00FF00`

## JavaScript

>
JavaScript脚本内嵌在网页内时，脚本应该放在网页的最后。

```html
<html>
<head>
    <meta charset="utf-8">
    <title>WEB网页</title>
</head>
<body>
    <p>This is a web test</p>
    <script type="text/javascript">
        document.writeln("你好 ");
    </script>
</body>
</html>
```

### 函数

>
1. 参数个数无需一致。
2. 参数少时，未提供的参数为`undefined `。
3. 参数多时，多余的参数被忽略。
4. 有同名函数时，后面的函数会覆盖前面的函数。

```js
	function myFunc(name, weather) {
	    document.writeln("Hello " + name + "! ");
	    document.writeln("It is " + weather + " today.<br>");
	};
	function myFunc(name, weather, age) {   /* 覆盖前面的函数 */
	    document.writeln("Welcome " + name + "! <br>");
	};
	myFunc("Tom", "Sunny");
	myFunc("Tom");                      /* 第二个参数为undefined */
	myFunc("Tom", "Sunny", "Windy");    /* 第三个参数被忽略 */
```

### 基础类型

三种基础类型：`string`、`number`、`boolean`

```js
    var strA = "This is a string";
    var strB = 'This is also a string';
    var b1 = true;
    var b2 = false;
    var n1 = 3;
    var n2 = 3.14;
    var n3 = 0xFFFF;
```

### 对象

>
* 函数属于某个对象时，该函数就叫方法。
* 当函数为方法时，函数隐式传递了一个this参数，该this为函数所属的对象。

```js
    function myFunc(name, weather) {
        document.writeln("Hello " + name + "! Today is " + weather + "<br>");
    };

    var ob = new Object();
    ob.name = "Tom";
    ob.weather = "Sunny";

    var ob2 = {
        name: "Ada",
        weather: "Windy",
        printMsg: function(name, weather) {     /* 方法 */
            document.writeln("Welcome " + this.name + "! Today is " + weather + "<br>");    /* this */
        },
    };

    ob.name = "Wolf";               /* 引用方式1 */
    ob["weather"] = "Rainy";        /* 引用方式2 */

    myFunc(ob.name, ob.weather);
    myFunc(ob2.name, ob2.weather);
    ob2.printMsg("Hanks", "Snowy");

    delete ob2.name;                /* 删除属性 */
    delete ob2["printMsg"];         /* 删除方法 */

    var hasName = "name" in ob2;    /* 判断是否有该属性 */
    document.writeln("hasName = " + hasName + "<br>");

    for (var prop in ob2) {     /* 遍历属性 */
        document.writeln("key: " + prop + ", value: " + ob2[prop] + "<br>");
    }
```

### 运算符

>
* `==`：比较值
* `===`：比较值和类型
* 基础类型比较值，对象类型比较引用

```js
    var a = 5;
    var b = "5";
    var c = a == b;         /* true, 比较值 */
    var d = a === b;        /* false,比较值、类型 */
```

```js
    var d1 = {
        name: "Tom",
    };
    var d2 = {
        name: "Tom",
    };
    var d3 = d1;

    var c1 = d1 == d2;          /* false */
    var c2 = d1 === d2;         /* false */
    var c3 = d1 == d3;          /* true */
    var c4 = d1 === d3;         /* true */
```

```js
    var a = 5 + 5;          /* 10 */
    var b = 5 + "5";        /* 55 */
    var c = (5).toString() + String(5);     /* 55 */
    var d = Number("5") + Number(b);        /* 60 */
```

### Array

```js
    var a = new Array();
    a[0] = 111;
    a[1] = "BBB";
    a[5] = true;

    var b = [10, "BB", true];

    for (var i = 0; i < a.length; i++) {
        document.writeln("i = " + a[i] + "<br>");
    }
```

### 异常处理

```js
    var myData;
    try {
        var len = myData.length;
    } catch (e) {
        document.writeln("Error: " + e + "<br>");
        document.writeln("number: " + e.number + "<br>");
        document.writeln("name: " + e.name + "<br>");
        document.writeln("message: " + e.message + "<br>");
    } finally {
        document.writeln("=============<br>");
    }
```

### undefined、null

```js
    var a1 = undefined;
    var a2 = null;
    
    var b1 = !a1;           /* true */
    var b2 = !a2;           /* true */
    var b3 = a1 == a2;      /* true */
    var b4 = a1 === a2;     /* false */
```












