# HTML

## 文本标记

| 元素 | 全称 | 描述 |
| :-- | :-- | :-- |
| b | | 粗体 |
| em | | 斜体 |
| i | | 斜体 |
| s | | 删除线 |
| small | | 小字体 |
| strong | | 粗体 |
| sub | | 下标 |
| sup | | 上标 |
| u | | 下划线 |
| br | | 换行 |
| q | | 双引号 |
| bdo | | 文本方向 |
| span | | 没有任何意义 |
| mark | | 黄底黑字 |
| ins | | 下划线 |
| del | | 删除线 |

## 分组标记

| 元素 | 全称 | 描述 |
| :-- | :-- | :-- |
| p | paragraph | 段落 |
| div |  | 与span相似 | 
| pre | preformat | 保留原样 |
| blockquote | 块引用 | 与q相似 |
| hr | horizontal rule | 水平线 |
| ol | ordered list | 有序列表 |
| ul | unordered list | 无序列表 |
| li | list item | 列表元素 |
| dl | definition list | 定义列表 |
| dt | definition title | 定义标题 |
| dd | definition definition | 定义描述 |

## 分区标记

| 元素 | 全称 | 描述 |
| :-- | :-- | :-- |
| h1 | heading | h1 ~ h6 |
| hgroup | | |
| section | | |
| header | | |
| footer | | |
| nav | | |
| article | | |
| aside | | |
| address | | |
| details | | 展开项 |
| summary | | 展开项标题 |

## Table元素

| 元素 | 全称 | 描述 |
| :-- | :-- | :-- |
| table | | |
| tr | table row | 行 |
| td | table data cell |  |
| th | table header cell |  |
| thead | table header | 头部 |
| tfoot | table footer | 尾部 |
| tbody | table body | 体部 |
| colspan |  | 占用列数 |
| rowspan |  | 占用行数 |
| caption |  | 标题 |
| colgroup |  | 指定多少列 |

## 网页内部跳转

```html
<a href="#line40">My Favorite</a>
<p id="line40">我最喜欢的</p>
<a name="line40">我最喜欢的</a>
```

`href="#line40"`会先找`id="line40"`的元素，如果没有找到，会找`name="line40"`的`a`元素

## dl、dt、dd

```html
<dl>
    <dt>Apple</dt>
    <dd>The apple is the pomaceous fruit of the apple tree</dd>
    <dd><i>Malus domestica</i></dd>
    <dt>Banana</dt>
    <dd>The banana is the parthenocarpic fruit of the banana tree</dd>
    <dd><i>Musa acuminata</i></dd>
    <dt>Cherry</dt>
    <dd>The cherry is the stone fruit of the genus <i>Prunus</i></dd>
</dl>
```

![](Images/dl.png)

## details、summay

```html
<details>
    <summary>总结</summary>
    <ol>
        <li>AAA</li>
        <li>BBB</li>
        <li>CCC</li>
    </ol>
</details>
```

![](Images/summary.png)
![](Images/details.png)

## 表单

```html
<html>
<head>
    <meta charset="utf-8">
    <title>WEB网页</title>
</head>
<body>
<form method="post" action="http://localhost:8082/form" id="vote">
    <fieldset>
        <legend>Enter your details</legend>
        <p><label for="fave">Fruit: <input id="fave" name="fave"/></p>
        <p><label for="name">Name: <input autofocus id="name" name="name"/></p>
    </fieldset>
    <fieldset>
        <legend>Vote for three favorite fruits</legend>
        <p><label for="fave1">Fruit1: <input id="fave1" name="fave1"/></p>
        <p><label for="fave2">Fruit2: <input id="fave2" name="fave2"/></p>
        <p><label for="fave3">Fruit3: <input id="fave3" name="fave3"/></p>
    </fieldset>
    <button type="submit" formaction="http://localhost:8082/form" formmethod="post">Submit Vote</button>
    <button>Submit</button>
    <button type="reset">Reset</button>
    <button type="button">do <strong>Not</strong> press</button>
</form>
<button form="vote">Submit2</button>
</body>
</html>
```

![](Images/form.png)


## input属性

| 属性  | 描述 |
| :-- | :-- |
| size | 以字符数指定input长度 |
| maxlength | 最大字符数 |
| value  | 文本 |
| placeholder  | 占位符 |
| datalist  | 下拉列表 |
| disabled  |  |
| readonly  |  |
| type="password"  | 密码 |
| type="number"  | 数字 |
| type="range"  | 滑动条 |
| type="checkbox"  | 复选框 |
| type="search"  | 搜索 |
| type="hidden"  |  |
| type="image"  | 图片 |
| type="file"  | 文件 |

```html
    <datalist id="fruits">
        <option value="一一一" label="Lovely Apple">AAA</option>
        <option value="二二二">BBB</option>
        <option value="三三三">CCC</option>
    </datalist>
```

![](Images/datalist.png)

```html
<p>Price: <input type="number" min="1" max="10" value="5" step="1" id="price" name="price" /></p>
```

![](Images/input_number.png)

```html
<p>Price: <input type="range" min="1" max="10" value="5" step="1" id="price" name="price" /></p>
```

![](Images/input_range.png)

```html
<p>Price: <input type="checkbox" id="veggie" name="veggie" /></p>
```

![](Images/input_checkbox.png)

```html
<fieldset>
    <legend>Vote for your favorite fruit</legend>
    <label>
        <input type="radio" checked value="Apple">Apples
    </label>
    <label>
        <input type="radio" value="Orange">Oranges
    </label>
    <label>
        <input type="radio" value="Cherry">Cherries
    </label>
</fieldset>
```

![](Images/input_radio.png)

```html
<p>email: <input type="email" placeholder="user@domain.com" /></p>
<p>tel: <input type="tel" placeholder="(XXX)-XXX-XXXX" /></p>
<p>url: <input type="url" /></p>
```

![](Images/input_others.png)

```html
<p>url: <input type="date" /></p>
```

![](Images/input_date.png)

```html
<p>select a color: <input type="color" value="#00FF00" /></p>
```

![](Images/input_color.png)

```html
<p>File: <input type="file" name="fileData" /></p>
```

![](Images/input_file.png)

## select属性

```html
<label>
    Favorite Fruit:
    <select>
        <option value="苹果" label="apples">Apple</option>
        <option selected value="橙子" label="oranges">Orange</option>
        <option value="草莓" label="cherries">Cherry</option>
    </select>
</label>
```

![](Images/select1.png)

![](Images/select2.png)

```html
<label>
    Favorite Fruit:
    <select size="3" multiple>
        <option value="苹果" label="apples">Apple</option>
        <option selected value="橙子" label="oranges">Orange</option>
        <option value="草莓" label="cherries">Cherry</option>
    </select>
</label>
```

![](Images/select_multiple.png)

```html
<label>
    Favorite Fruit:
    <select size="7" multiple>
        <optgroup label="选择">
            <option value="苹果" label="apples">Apple</option>
            <option selected value="橙子" label="oranges">Orange</option>
            <option value="草莓" label="cherries">Cherry</option>
        </optgroup>
        <optgroup label="选择2">
            <option value="苹果2" label="apples2">Apple2</option>
            <option selected value="橙子2" label="oranges2">Orange2</option>
        </optgroup>
    </select>
</label>
```

![](Images/select_optgroup.png)

## textarea

```html
<textarea rows="5" cols="20" wrap="soft">Tell us why this is your favorite fruit</textarea>
```

![](Images/textarea.png)

## output

```html
<form method="post" action="http://localhost:8082/form" onsubmit="return false"
oninput="res.value = quant.valueAsNumber * price.valueAsNumber">
    <fieldset>
        <legend>计算器</legend>
        <input type="number" id="quant"> x
        <input type="number" id="price"> =
        <output id="res">
    </fieldset>
</form>
```

![](Images/output.png)

## img

```html
<img src="favicon.ico" alt="Triathlon Image" usemap="#mymap" width="100" height="100">
<map name="mymap">
    <area href="https://www.qq.com" shape="rect" coords="0,0,50,50">
    <area href="https://www.so.com" shape="rect" coords="50,50,100,100">
    <area href="https://www.apple.com.cn" shape="default">
</map>
```

>
图片左上角为坐标原点

| 图形 | 说明 | 详细 |
| :-- | :-- | :-- |
| rect | x1,y1,x2,y2 | 指定左上位置、右下位置 |
| circle | x,y,r | 指定圆中心位置、半径 |
| poly | x1,y1,x2,y2,x3,y3,... | 指定多边形的点，自动闭合 |
| default |  | 图片中的其他未指定的位置 |

## iframe

```html
<ul>
    <li><a href="https://www.so.com" target="myframe">Fruits I Like</a></li>
    <li><a href="https://www.qq.com" target="frame">Activities I Like</a></li>
</ul>
<iframe name="myframe" width="400" height="200"></iframe>
```

点击第一行

![](Images/iframe.png)

## embed

```html
<embed src="https://video.699pic.com/videos/33/16/19/b_zudVXP8iP8YG1638331619.mp4" type="video/mp4" width="400" height="300">
```

![](Images/embed.png)

## object

```html
<object data="https://video.699pic.com/videos/33/16/19/b_zudVXP8iP8YG1638331619.mp4" width="400" height="300" type="video/mp4">
    <param name="allowFullScreen" value="true" />
    播放出错
</object>
```

## progress

```html
<progress value="40" max="100"></progress>
```

![](Images/progress.png)

## meter

```html
<meter min="10" max="100" low="30" high="70" optimum="50" value="80"></meter>
```

![](Images/meter.png)

