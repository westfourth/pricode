## Table样例 1

```html
<html>
<head>
    <meta charset="utf-8">
    <title>WEB网页</title>
    <style type="text/css">
        tr > th {
            background: red;
        }
        tr > th:only-of-type {
            background: orange;
        }
    </style>
</head>
<body>
<table>
    <tr>
        <th>00</th>
        <th>A</th>
        <th>B</th>
        <th>C</th>
    </tr>
    <tr>
        <th>11</th>
        <td>First</td>
        <td>Second</td>
        <td>Third</td>
    </tr>
    <tr>
        <th>22</th>
        <td>第一个</td>
        <td>第二个</td>
        <td>第三个</td>
    </tr>
</table>
</body>
</html>
```

![](../Images/table1.png)


## Table样例 2

```html
<html>
<head>
    <meta charset="utf-8">
    <title>WEB网页</title>
    <style type="text/css">
        thead th, tfoot th {
            background: blue;
        }
        tbody th {
            background: red;
        }
    </style>
</head>
<body>
<table>
    <thead>
        <tr>
            <th>00</th>
            <th>A</th>
            <th>B</th>
            <th>C</th>
        </tr>
    </thead>
    <tfoot>
        <tr>
            <th>99</th>
            <th>X</th>
            <th>Y</th>
            <th>Z</th>
        </tr>
    </tfoot>
    <tbody>
        <tr>
            <th>11</th>
            <td>First</td>
            <td>Second</td>
            <td>Third</td>
        </tr>
        <tr>
            <th>22</th>
            <td>第一个</td>
            <td>第二个</td>
            <td>第三个</td>
        </tr>
    </tbody>
</table>
</body>
</html>
```

![](../Images/table2.png)


## Table样例 3

```html
<html>
<head>
    <meta charset="utf-8">
    <title>WEB网页</title>
    <style type="text/css">
        thead th, tfoot th {
            background: yellow;
        }
        tbody th {
            background: red;
            color: yellow;
        }
        td {
            background: blue;
            color: white;
        }
    </style>
</head>
<body>
<table>
    <thead>
        <tr>
            <th>Rank</th>
            <th>Name</th>
            <th>Color</th>
            <th colspan="2">Size & Votes</th>
        </tr>
    </thead>
    <tfoot>
        <th colspan="5">© 2011 Adam Freeman Fruit Data Enterprises</th>
    </tfoot>
    <tbody>
        <tr>
            <th>Favorite:</th>
            <td>Apples</td>
            <td>Green</td>
            <td>Medium</td>
            <td>500</td>
        </tr>
        <tr>
            <th>2nd Favorite:</th>
            <td>Oranges</td>
            <td>Orange</td>
            <td>Large</td>
            <td>450</td>
        </tr>
        <tr>
            <th>3nd Favorite:</th>
            <td>Pomegranate</td>
            <td colspan="2" rowspan="2">Pomegranates can come in different.</td>
            <td>203</td>
        </tr>
        <tr>
            <th rowspan="2">Joint 4th</th>
            <td>Cherries</td>
            <td rowspan="2">75</td>
        </tr>
        <tr>
            <td>Pineapple</td>
            <td>Brown</td>
            <td>Very Large</td>
        </tr>
    </tbody>
</table>
</body>
</html>
```

![](../Images/table3.png)


## Table样例 4

```html
<html>
<head>
    <meta charset="utf-8">
    <title>WEB网页</title>
    <style type="text/css">
        thead th, tfoot th {
            background: yellow;
        }
        tbody th {
            background: red;
            color: yellow;
        }
        caption {
            text-align: center;
            background: orange;
        }
        #group1 {
            background: blue;
        }
        #group2 {
            background-color: gray;
        }
    </style>
</head>
<body>
<table>
    <caption>Results of the 2011 Fruit Survey</caption>
    <colgroup id="group1" span="3">
    <colgroup id="group2" span="2">
    <thead>
        <tr>
            <th>Rank</th>
            <th>Name</th>
            <th>Color</th>
            <th colspan="2">Size & Votes</th>
        </tr>
    </thead>
    <tfoot>
        <th colspan="5">© 2011 Adam Freeman Fruit Data Enterprises</th>
    </tfoot>
    <tbody>
        <tr>
            <th>Favorite:</th>
            <td>Apples</td>
            <td>Green</td>
            <td>Medium</td>
            <td>500</td>
        </tr>
        <tr>
            <th>2nd Favorite:</th>
            <td>Oranges</td>
            <td>Orange</td>
            <td>Large</td>
            <td>450</td>
        </tr>
        <tr>
            <th>3nd Favorite:</th>
            <td>Pomegranate</td>
            <td colspan="2" rowspan="2">Pomegranates can come in different.</td>
            <td>203</td>
        </tr>
        <tr>
            <th rowspan="2">Joint 4th</th>
            <td>Cherries</td>
            <td rowspan="2">75</td>
        </tr>
        <tr>
            <td>Pineapple</td>
            <td>Brown</td>
            <td>Very Large</td>
        </tr>
    </tbody>
</table>
</body>
</html>
```

![](../Images/table4.png)


## Table样例 5

```html
<html>
<head>
    <meta charset="utf-8">
    <title>WEB网页</title>
    <style type="text/css">
        thead th, tfoot th {
            background: yellow;
        }
        tbody th {
            background: red;
            color: yellow;
        }
        caption {
            text-align: center;
            background: orange;
        }
        #group1 {
            background: blue;
        }
        #col3 {
            background: gray;
        }
    </style>
</head>
<body>
<table>
    <caption>Results of the 2011 Fruit Survey</caption>
    <colgroup id="group1">
        <col id="col1And2" span="2">
        <col id="col3">
    </colgroup>
    <thead>
        <tr>
            <th>Rank</th>
            <th>Name</th>
            <th>Color</th>
            <th colspan="2">Size & Votes</th>
        </tr>
    </thead>
    <tfoot>
        <th colspan="5">© 2011 Adam Freeman Fruit Data Enterprises</th>
    </tfoot>
    <tbody>
        <tr>
            <th>Favorite:</th>
            <td>Apples</td>
            <td>Green</td>
            <td>Medium</td>
            <td>500</td>
        </tr>
        <tr>
            <th>2nd Favorite:</th>
            <td>Oranges</td>
            <td>Orange</td>
            <td>Large</td>
            <td>450</td>
        </tr>
        <tr>
            <th>3nd Favorite:</th>
            <td>Pomegranate</td>
            <td colspan="2" rowspan="2">Pomegranates can come in different.</td>
            <td>203</td>
        </tr>
        <tr>
            <th rowspan="2">Joint 4th</th>
            <td>Cherries</td>
            <td rowspan="2">75</td>
        </tr>
        <tr>
            <td>Pineapple</td>
            <td>Brown</td>
            <td>Very Large</td>
        </tr>
    </tbody>
</table>
</body>
</html>
```

![](../Images/table5.png)