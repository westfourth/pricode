## CSS样例1

```html
<html>
<head>
    <meta charset="utf-8">
    <title>WEB网页</title>
    <style type="text/css">
        * {
            border: red solid;
            padding: 4px;
        }
        body {
            border: blue solid;
        }
    </style>
</head>
<body>
<a href="http://apress.com">Visit the Apress website</a>
<p>I like <span>apples</span> and oranges.</p>
<a href="http://w3c.org">Visit the W3C website</a>
</body>
</html>
```

![](../Images/selector_universal.png)

## CSS样例2

```html
<html>
<head>
    <style type="text/css">
        span.class2 { border: orange solid; }
    </style>
</head>
<body>
<a class="class1 class2" href="http://apress.com">Visit the Apress website</a>
<p>I like <span class="class2">apples</span> and oranges.</p>
<a href="http://w3c.org">Visit the W3C website</a>
</body>
</html>
```

![](../Images/selector_type_class.png)

## CSS样例3

```html
<html>
<head>
    <style type="text/css">
        body > * > span, tr > th {
            border: blue solid;
        }
    </style>
</head>
<body>
<table id="mytable">
    <tr><th>Name</th><th>City</th></tr>
    <tr><td>Adam Freeman</td><td>London</td></tr>
    <tr><td>Joe Smith</td><td>New York</td></tr>
    <tr><td>Anne Jones</td><td>Paris</td></tr>
</table>
<p>I like <span lang="en-uk" class="class2">apples</span> and oranges.</p>
</body>
</html>
```

![](../Images/selector_child.png)

## CSS样例4

```html
<html>
<head>
    <style type="text/css">
        ::first-line { background-color: grey; }
    </style>
</head>
<body>
<p>Fourscore and seven years ago our fathers brought forth
    on this continent a new nation, conceived in liberty, and
    dedicated to the proposition that all men are created equal.</p>
<p>I like <span lang="en-uk" class="class2">apples</span> and oranges.</p>
<a href="http://w3c.org">Visit the W3C website</a><br>
<a href="http://w3c.org">Visit the W3C website</a>
<p>Fourscore and seven years ago our fathers brought forth
    on this continent a new nation, conceived in liberty, and
    dedicated to the proposition that all men are created equal.</p>
</body>
</html>
```

![](../Images/selector_first_line.png)

## CSS样例5

```html
<html>
<head>
    <meta charset="utf-8">
    <style type="text/css">
        a:before {
            content: "开始 ";
        }
        a:after {
            content: " 结束";
        }
    </style>
</head>
<body>
<a href="http://apress.com">Visit the Apress website</a>
<p>I like <span>apples</span> and oranges.</p>
<a href="http://w3c.org">Visit the W3C website</a>
</body>
</html>
```

![](../Images/selector_before_after.png)