## Dom

### getElementsByTagName

```html
<html>
    <head>
        <meta charset="utf-8">
    </head>
    <body>
        <p id="fruittext">
            There are lots of different kinds of fruit - there are over 500
            varieties of <span id="banana">banana</span> alone. By the time we add the
            countless types of apples, oranges, and other well-known fruit, we are faced
            with thousands of choices.
        </p>
        <p id="apples">
            One of the most interesting aspects of fruit is the
            variety available in each country. I live near London, in an area which is
            known for its apples.
        </p>
        <script>
            document.writeln("<pre>URL:" + document.URL);
            var elems = document.getElementsByTagName("p");
            for (var i = 0; i < elems.length; i++) {
                document.writeln("ID:" + elems[i].id);
                elems[i].style.border = "medium solid blue";
                elems[i].style.padding = "4px";
            }
            document.write("</pre>");
        </script>
    </body>
</html>
```

![](Images/getElementsByTagName.png)

### document metadata

![](Images/document_metadata.png)

### location

![](Images/docment_location.png)

### cookie

![](Images/docment_cookie.png)

### readyState

![](Images/docment_readyState.png)

### document property

![](Images/document_property.png)

```html
<!DOCTYPE HTML>
<html>
<head>
    <title>Example</title>
    <meta name="author" content="Adam Freeman"/>
    <meta name="description" content="A simple example"/>
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon" />
    <style>
        pre { border: medium double black; }
    </style>
</head>
<body>
    <pre id="results"></pre>
    <img id="lemon" src="lemon.png" alt="lemon"/>
    <p>
        There are lots of different kinds of fruit - there are over 500 varieties
        of banana alone. By the time we add the countless types of apples, oranges,
        and other well-known fruit, we are faced with thousands of choices.
    </p>
    <img id="apple" src="apple.png" alt="apple"/>
    <p>
        One of the most interesting aspects of fruit is the variety available in
        each country. I live near London, in an area which is known for
        its apples.
    </p>
    <img id="banana" src="banana-small.png" alt="small banana"/>
    <script>
        var resultElement = document.getElementById("results");
        var elems = document.images;
        for (var i = 0; i < elems.length; i++) {
            resultElement.innerHTML += "Image Element: " + elems[i].id + "\n";
        }
        var srcValue = elems.namedItem("apple").src;
        resultElement.innerHTML += "Link:" + srcValue + "\n";
    </script>
    </body>
</html>
```

### getElementBy

![](Images/getElementBy.png)

```html
<!DOCTYPE html>
<head>
    <meta charset="UTF-8">
</head>
<body>
<pre id="results"></pre>
<img id="lemon" class="fruits" tag="abc" name="apple" src="lemon.png" alt="lemon"/>
<p>
    There are lots of different kinds of fruit - there are over 500 varieties
    of banana alone.
</p>
<img id="apple" class="fruits images" name="apple"  src="apple.png" alt="apple"/>
<p>
    One of the most interesting aspects of fruit is the variety available in
    each country.
</p>
<img id="banana" src="banana-small.png" alt="small banana"/>
<script>
    var resultsElement = document.getElementById("results");

    var pElems = document.getElementsByTagName("p");
        resultsElement.innerHTML += "There are " + pElems.length + " p elements\n";

    var fruitsElems = document.getElementsByClassName("fruits");
        resultsElement.innerHTML += "There are " + fruitsElems.length + " elements in the fruits class\n";
    var nameElems = document.getElementsByName("apple");
        resultsElement.innerHTML += "There are " + nameElems.length + " elements with the name 'apple'\n";

    var pElems = document.getElementsByTagName("p");
        resultsElement.innerHTML += "There are " + pElems.length + " elements with the name 'p'\n";
</script>
</body>
</html>
```

### querySelector

![](Images/querySelector.png)

### tree navigation

![](Images/tree_navigation.png)


## Window

### Window

![](Images/window.png)

### Screen

![](Images/screen.png)

### Window Interaction

![](Images/window_interaction.png)

### Prompt

![](Images/prompt.png)

### Browser History

![](Images/browser_history.png)

### Cross Document Message

![](Images/window_post_message.png)
![](Images/window_add_event_listener.png)

```html
<!DOCTYPE HTML>
<html>
<head>
    <title>Example</title>
</head>
<body>
<p id="status">Ready</p>
<button id="send">Send Message</button>
<p>
    <iframe name="nested" src="./test2.html" width="90%" height="300px"></iframe>
</p>
<script>
    document.getElementById("send").onclick = function() {
        window["nested"].postMessage("I like apples", "http://localhost:63342");
        document.getElementById("status").innerHTML = "Message Sent";
    }
</script>
</body>
</html>
```

```html
<!DOCTYPE HTML>
<html>
<head>
    <title>Other Page</title>
</head>
<body>
<h1 id="banner">This is the nested document</h1>
<script>
    window.addEventListener("message", receiveMessage, false);
    function receiveMessage(e) {
        if (e.origin == "http://localhost:63342") {
            displayMessage(e.data);
        } else {
            displayMessage("Message Discarded");
        }
    }
    function displayMessage(msg) {
        document.getElementById("banner").innerHTML = msg;
    }
</script>
</body>
</html>
```

### Timer

![](Images/timer.png)

## Dom Element

### Element Data Property

![](Images/element_data_property.png)

### attribute

![](Images/attribute.png)





