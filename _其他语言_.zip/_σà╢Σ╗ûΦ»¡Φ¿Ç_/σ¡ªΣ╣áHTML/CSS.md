# CSS

## 浏览器特定前缀

![](Images/browser-prefix.png)

## CSS box model

![](Images/css_box_model.png)

![](Images/box_model_relationship.png)

## CSS 选择器

>
《The Definitive Guide To HTML5.pdf》Page-391

| 选择器 | 描述 | 示例 |
| :-- | :-- | :-- |
| `*` | 选择所有元素 | `* { border: red solid; }` |
| `<type>` | 选择指定类型的元素 | `a { border: red solid; }`  |
| `.<class>` </br> `<type>.<class>` | 选择指定class的元素 | `.classA { border: red solid; }` </br> `span.classA { border: red solid; }` |
| `#<id>` </br> `<type>#<id>` | 选择指定id的元素 | `#apress { border: orange solid; }` </br> `span#apress { border: orange solid; }` |
| `[<condition>]` </br> `<type>[condition]` | 选择满足指定条件的元素 | `[href] { border: orange solid; }` </br> `span[href] { border: orange solid; }` |

### 通过属性选择元素

| 选择器 | 描述 | 示例 |
| :-- | :-- | :-- |
| `[attr]` | 选择有attr属性元素 | `[href] { border: orange solid; }` |
| `[attr="val"]` | 选择attr属性为val的元素 | `[href="http://apress.com"] { border: orange solid; }` |
| `[attr^="val"]` | 选择attr属性以val开头的元素 | `[href^="http"] { border: orange solid; }` |
| `[attr$="val"]` | 选择attr属性以val结束的元素 | `[href$="com"] { border: orange solid; }` |
| `[attr*="val"]` | 选择attr属性包含val的元素 | `[href*="apress"] { border: orange solid; }` |
| `[attr~="val"]` | 选择attr属性，其值多个、其中一个为val | `[class~="class1"] { border: orange solid; }` |
| `[attr|="val"]` | 选择attr属性，其值以`-`连接、以val开头 | `[class|="class2"] { border: orange solid; }` |

### 组合选择器

| 选择器 | 描述 | 示例 |
| :-- | :-- | :-- |
| `<selector1>, <selector2>` | 并集 | `a, [class|="class1"] { border: blue solid; }` |
| `<selector1> <selector2>` | 后代 | `p span { border: red solid; }` </br> `#mytable td { border: red solid; }` |
| `<selector1> > <selector2>` | 直接后代 | `tr > th { border: blue solid; }` |
| `<selector1> ~ <selector2>` | 兄弟节点 | `p ~ a { border: blue solid; }` |
| `<selector1> + <selector2>` | 直接兄弟节点 | `p + a { border: blue solid; }` |

### 伪元素选择器

| 选择器 | 描述 | 示例 |
| :-- | :-- | :-- |
| `::first-line` | 选择文本块的第一行 | `::first-line { background-color: grey; }` |
| `::first-letter` | 选择文本块的第一个字母 | `::first-letter { background-color: grey; }` |
| `:before` | 所选元素前插入 | `a:before { content: "开始 "; }` |
| `:after` | 所选元素后插入 | `a:after { content: " 结束"; }` |
| `:root` | 根节点 | `:root { background-color: green; }` |

### child选择器

| 选择器 | 描述 | 示例 |
| :-- | :-- | :-- |
| `:first-child` | | |
| `:last-child` | | |
| `:only-child` | | |
| `:only-of-type` | | |
| `:nth-child(n)` | 第几个，从1开始 | `body > :nth-child(2) { background-color: orange; }` |
| `:nth-last-child(n)` | 倒数第几个，从2开始 | `body > :nth-last-child(2) { background-color: orange; }` |
| `:nth-of-type(n)` | 每个元素的第几个，从1开始 | `body > :nth-of-type(2) { background-color: orange; }` |
| `:nth-last-of-type(n)` | 每个元素的倒数第几个，从1开始 | `body > :nth-last-of-type(1) { background-color: orange; }` |

### UI选择器

| 选择器 | 描述 | 示例 |
| :-- | :-- | :-- |
| `:enabled` |  | `:enabled { background-color: orange; }` |
| `:disabled` |  | `:disabled { background-color: gray; }` |
| `:checked` |  | `:checked + span { background-color: orange; }` |
| `:default` |  | `:default { outline: red solid medium }` |
| `:valid` |  | `:valid { outline: yellow solid medium; }` |
| `:invalid` |  | `:invalid { outline: red solid medium; }` |
| `:in-range` |  | `:in-range { outline: medium solid yellow; }` |
| `:out-of-rangee` |  | `:out-of-range { outline: medium solid red; }` |
| `:required` |  | `:required { outline: medium solid yellow; }` |
| `:optional` |  | `:optional { outline: medium solid red; }` |
| `:link` |  | `:link { background-color: yellow; }` |
| `:visited` |  | `:visited { background-color: blue; }` |
| `:hover` |  | `:hover { background-color: yellow; }` |
| `:active` |  |  |
| `:focus` |  | `:focus { border: solid medium blue; }` |
| `:not` |  | `a:not([href*="apress"]) { border: solid medium blue; }` |
| `:empty` |  | `:empty { border: solid medium red; }` |
| `:lang` |  | `:lang(en) { border: solid medium red; }` |
| `:target` |  | `:target { border: solid medium red; }` |

## Borders、Backgrounds

### border

| 属性 | 描述 | 示例 |
| :-- | :-- | :-- |
| `border-width` | 单位：`em`、`px`、`cm`；<perc>`%`；`thin`、`medium`、`thick` | `border-width: 4px;` |
| `border-style` | 默认：`none`  | `border-style: solid;` |
| `border-color` |  | `border-color: blue;` |

**单边**

| 属性 | 描述 |
| :-- | :-- | :-- |
| `border-top-width` <br> `border-top-style` <br> `border-top-color` | |
| `border-bottom-width` <br> `border-bottom-style` <br> `border-bottom-color` | |
| `border-left-width` <br> `border-left-style` <br> `border-left-color` | |
| `border-right-width` <br> `border-right-style` <br> `border-right-color` | |

**速记**

| 属性 | 描述 |
| :-- | :-- | :-- |
| `border ` | `<width>` `<style>` `<color>` |
| `border-top` <br> `border-bottom` <br> `border-left` <br> `border-right` |  |

**border-style**

![](Images/border-style.png)

**border-radius**

![](Images/border-radius.png)

### background

| 属性 | 描述 | 示例 |
| :-- | :-- | :-- |
| `background-color` |  |  |
| `background-image` |  |  |
| `background-repeat` |  |  |
| `background-size` | `contain`、`cover`、`auto` |  |
| `background-position` |  |  |
| `background-attatchment` |  |  |
| `background-clip` |  |  |
| `background-origin` | `border-box`、`padding-box`、`content-box` |  |
| `background` |  |  |

**background-repeat**

| 属性 | 描述 | 示例 |
| :-- | :-- | :-- |
| `repeat-x` | 水平重复，图片可能展示部分 |  |
| `repeat-y` | 垂直重复，图片可能展示部分 |  |
| `repeat` | 水平、垂直重复，图片可能展示部分 |  |
| `space` | 重复，展示完整 |  |
| `round` | 重复，展示完整，拉伸 |  |
| `no-repeat` | 不重复 |  |

**background-size**

| 属性 | 描述 | 示例 |
| :-- | :-- | :-- |
| `contain` | 保持比例不变，fit |  |
| `cover` | 保持比例不变，fill |  |
| `auto` | 默认 |  |

**background**

![](Images/background.png)

**box-shadow**

格式：`box-shadow: hoffset voffset blur spread color inset`

解释：水平偏移、垂直偏移、模糊半径、伸展半径、颜色、是否向内模糊（默认向外）

```css
box-shadow: 4px 4px 10px 10px blue inset, 4px 4px 10px 10px red;
```

![](Images/box-shadow.png)

**outline**

`outline`与`border`的区别：`outline`不属于页面一部分，因此`outline`不影响布局。

| 属性 | 描述 | 示例 |
| :-- | :-- | :-- |
| `outline-color` | `<color>` |  |
| `outline-offset` | `<length>` |  |
| `outline-style` | 参照`border-style` |  |
| `outline-width` | `thin`、`medium`、`thick`、`<length>` |  |
| `outline` | `<color>` `<style>` `<width>` |  |

## Box Model

`<%>`是按照宽度计算的，而非高度。

| 属性 | 描述 | 示例 |
| :-- | :-- | :-- |
| `padding-top` <br> `padding-right` <br> `padding-bottom` <br> `padding-left` | 1 <br> 2 <br> 3 <br> 4 | |
| `padding` | 1-4 | |
| `margin-top` <br> `margin-right` <br> `margin-bottom` <br> `margin-left` | 1 <br> 2 <br> 3 <br> 4 | |
| `margin` | 1-4 | |

**size属性**

| 属性 | 描述 | 示例 |
| :-- | :-- | :-- |
| `width` <br> `height` | | |
| `min-width` <br> `min-height` | | |
| `max-width` <br> `max-height` | | |
| `box-sizing` | `content-box` <br> `padding-box` <br> `border-box` <br> `margin-box` |  |

**overflow属性**

| 属性 | 描述 | 示例 |
| :-- | :-- | :-- |
| `overflow-x` | | |
| `overflow-y` | | |
| `overflow` | | |

**overflow值**

| 属性 | 描述 | 示例 |
| :-- | :-- | :-- |
| `auto` | | |
| `hidden` | 超出不展示 | |
| `no-content` | 主流浏览器不支持 | |
| `no-display` | 主流浏览器不支持 | |
| `scroll` | 超出滚动 | |
| `visible` | 默认值。超出展示 | |

**visibility属性**

| 属性 | 描述 | 示例 |
| :-- | :-- | :-- |
| `collapse` | 隐藏、不占空间 | |
| `hidden` | 隐藏、占空间 | |
| `visible` | 默认值、展示 | |

| collapse | hidden | visible |
| :-: | :-: | :-: |
| ![](Images/visibility_collapse.png) | ![](Images/visibility_hidden.png) | ![](Images/visibility_visible.png) |

**display属性**

| 属性 | 描述 | 示例 |
| :-- | :-- | :-- |
| `inline` | 字符 | |
| `block` | 段落 | |
| `inline-block` | 行 | |
| `list-item` | 列表 | |
| `run-in` | | |
| `compact` | | |
| `flexbox` | | |
| `table` <br> `inline-table` <br> `table-row-group` <br> `table-header-group` <br> `table-footer-group` <br> `table-row` <br> `table-column-group` <br> `table-column` <br> `table-cell` <br> `table-caption` | 布局table元素 | |
| `ruby` <br> `ruby-base` <br> `ruby-text` <br> `ruby-base-group` <br> `ruby-text-group` | | |
| `none` | 不可见，并且不占空间 | |

**float属性**

| 属性 | 描述 | 示例 |
| :-- | :-- | :-- |
| `left` | （邻近）左对齐 | |
| `right` | （邻近）右对齐 | |
| `none` | 无 | |

**clear属性**

| 属性 | 描述 | 示例 |
| :-- | :-- | :-- |
| `left` | 清除邻近左对齐 | |
| `right` | 清除邻近右对齐 | |
| `both` | 清除邻近左、右对齐 | |
| `none` | 无 | |

## Layout

**position属性**

| 属性 | 描述 | 示例 |
| :-- | :-- | :-- |
| `static` | 默认 | |
| `relative` | 相对static | |
| `absolute` | 相对父元素（有非static值的position属性） | |
| `fixed` | 相对window | |

**z-index属性**

值越大，越靠前，默认值0。

**多列布局**

| 属性 | 描述 | 示例 |
| :-- | :-- | :-- |
| `column-count` | 列数 | |
| `column-fill` | `balance`：水平 <br> `auto`：垂直 | |
| `column-gap` | 列间距 | |
| `column-rule` | 速记 `<width> <style> <color>` | |
| `column-rule-width` <br> `column-rule-style` <br> `column-rule-color`  | | |
| `columns` | 速记 `<span> <width>` | |
| `column-span` | 指定元素所占列数 | |
| `column-width` | 列宽 | |

**Flexbox布局**

| 属性 | 描述 | 示例 |
| :-- | :-- | :-- |
| `box-align` | 次轴对齐方向。<br> `start`、`end`、`center`、`baseline`、`stretch` | |
| `box-flex` | 伸缩 | |
| `box-pack` | 主轴对齐方向。<br> `start`、`end`、`center`、`justify` | |

**Table布局**

![](Images/table_layout.png)


## 文本样式

| 属性 | 描述 | 示例 |
| :-- | :-- | :-- |
| `text-align` | 对齐。<br> `start`、`end`、`left`、`right`、`center`、`justify` | |
| `text-justify` | `auto`、`none`、`inter-word`、`inter-ideograph`、`inter-cluster`、`distribute`、`kashida` | |
| `whitespace` | 空格、换行。<br> `normal`、`nowrap`、`pre`、`pre-line`、`pre-wrap` | |
| `direction` | 对齐。<br> `ltr`、`rtl` | |
| `letter-spacing` | `normal`、`<length>` | |
| `word-spacing` | `normal`、`<length>` | |
| `line-height` | `normal`、`<length>`、`<%>` | |
| `word-wrap` | `normal`、`break-word` | |
| `text-indent` | 块文本首行缩进。<br> `<length>`、`<%>` | |
| `text-decoration` | `none`、`underline`、`overline`、`line-through`、`blink` | |
| `text-transform` | `none`、`capitalize`、`uppercase`、`lowercase` | |
| `text-shadow` | `<h-shadow>` `<v-shadow>` `<blur>` `<color>` | |
| `font-family` | `,`分割，后面的作为备选 | |
| `font-size` | `xx-small`、`x-small`、`small`、`medium`、`large`、`x-large`、`xx-large` <br> `smaller`、`larger` <br> `<length>` <br> `<%>` | |
| `font-style` |  | |
| `font-variant` | `normal`、`<length>` | |
| `font-weight` |  | |
| `font` | `<font-style>` `<font-variant>` `<font-weight>` `<font-size>` `<font-family>` | |

### font-face

```css
    @font-face {
        font-family: 'MyFont';
        font-style: normal;
        font-weight: normal;
        src: url('http://titan/listings/MyFont.woff');
    }
    p{
        font-family: MyFont;
    }
```

## 动画

### Transition

| 属性 | 描述 |
| :-- | :-- |
| `transition-delay` | 延时 |
| `transition-duration` | 时长 |
| `transition-property` | 属性 |
| `transition-timing-function` |  |

```css
#banana:hover {
    font-size: x-large;
    border: medium solid blue;
    background-color: green;
    color: white;
    -webkit-transition-delay: 100ms;
    -webkit-transition-property: background-color, color, font-size, border;
    -webkit-transition-duration: 500ms;
}
```

### Animation

| 属性 | 描述 |
| :-- | :-- |
| `animation-delay` | 延时 |
| `animation-direction` | `normal` `alternate` |
| `animation-duration` |  |
| `animation-iteration-count` |  |
| `animation-name` |  |
| `animation-play-state` | `running` `paused` |
| `animation-timing-function` |  |

```css
#banana:hover {
    -webkit-animation-delay: 100ms;
    -webkit-animation-duration: 1000ms;
    -webkit-animation-timing-function: linear;
    -webkit-animation-iteration-count: 4;
    -webkit-animation-direction: alternate;
    -webkit-animation-name: "GrowShrink";
}
@-webkit-keyframes GrowShrink {
    from {
        font-size: large;
        border: medium solid black;
    }
    50% {
        font-size: large;
        border: medium solid green;
        background-color: green;
    }
    to {
        font-size: x-large;
        border: medium solid blue;
        background-color: blue;
        color: white;
        padding: 4px;
    }
}
```

### Transform ???

## 其他属性、特征

| 属性 | 描述 |
| :-- | :-- |
| `color` |  |
| `opacity` |  |


### table样式

| 属性 | 描述 |
| :-- | :-- |
| `border-collapse` | 控制border是否重合。 `collapse`、`separate` |
| `border-spacing` | border间距。 |
| `caption-side` | 标题位置。 `top`、`bottom` |
| `empty-cells` | 空cell是否显示。 `hide`、`show` |
| `table-layout` | 标题位置。 `auto`、`fixed` |

### list样式

| 属性 | 描述 |
| :-- | :-- |
| `list-style-type` | `none`、`box`、`check`、`circle`、`diamond`、`disc`、`dash`、`square`、`decimal`、`binary`、`lower-alpha`、`upper-alpha` |
| `list-style-image` | |
| `list-style-position` | 与内容是否一体。 `inside`、`outside` |

### cursor样式

| 属性 | 描述 |
| :-- | :-- |
| `cursor` | auto, crosshair, default, help, move, pointer, progress, text, wait, n-resize, s-resize, e-resize, w- resize, ne-resize, nw-resize, se-resize, and sw- resize |

