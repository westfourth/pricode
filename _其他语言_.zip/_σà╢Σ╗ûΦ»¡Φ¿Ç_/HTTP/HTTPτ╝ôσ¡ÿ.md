# HTTP缓存

参考：[HTTP 缓存](https://developer.mozilla.org/zh-CN/docs/Web/HTTP/Caching)

## 1. 启发式缓存

响应中没有给出`Cache-Control`字段

```http
HTTP/1.1 200 OK
Content-Type: text/html
Content-Length: 1024
Date: Tue, 22 Feb 2022 22:22:22 GMT
Last-Modified: Tue, 22 Feb 2021 22:22:22 GMT
```
复用时间建议为：(`Data` - `Last-Modified`) * 0.1

## 2. 基于age的缓存策略

```http
HTTP/1.1 200 OK
Content-Type: text/html
Content-Length: 1024
Date: Tue, 22 Feb 2022 22:22:22 GMT
Cache-Control: max-age=604800
```
只要 `当前时间` < `Date` + `max-age`，那么缓存都是有效的

### 共享缓存

当响应存储在共享缓存中时，需要通知客户端响应的age

```http
HTTP/1.1 200 OK
Content-Type: text/html
Content-Length: 1024
Date: Tue, 22 Feb 2022 22:22:22 GMT
Cache-Control: max-age=604800
Age: 86400
```

只要 `当前时间` + `Age ` < `Date` + `max-age`，那么缓存都是有效的

## 3. Expires或max-age

`Expires`指定明确的过期时间

```http
Expires: Tue, 28 Feb 2022 22:22:22 GMT
```
**优先级：**`Expires ` < `Cache-Control: max-age`

## 4. Vary响应

基于URL区分响应

![](Images/keyed-with-url.png)

但相同的URL，响应内容有时候会不同，例如不同语言时

![](Images/keyed-with-url-and-language.png)

## 5. 验证响应

### If-Modified-Since

```http
HTTP/1.1 200 OK
Content-Type: text/html
Content-Length: 1024
Date: Tue, 22 Feb 2022 22:22:22 GMT
Last-Modified: Tue, 22 Feb 2022 22:00:00 GMT
Cache-Control: max-age=3600
```
到23:22:22之前，响应都是有效的

```http
GET /index.html HTTP/1.1
Host: example.com
Accept: text/html
If-Modified-Since: Tue, 22 Feb 2022 22:00:00 GMT
```
如果内容从指定时间没有更改，那么服务器将响应`304 Not Modified`。

由于此响应仅表示“没有变化”，因此没有响应体

```http
HTTP/1.1 304 Not Modified
Content-Type: text/html
Date: Tue, 22 Feb 2022 23:22:22 GMT
Last-Modified: Tue, 22 Feb 2022 22:00:00 GMT
Cache-Control: max-age=3600
```
收到该响应后，客户端将存储的过期响应恢复为有效的，并且在剩余的1个小时内可以重复使用。

### ETag/If-None-Match

`ETag`多使用`MD5`哈希值

```http
HTTP/1.1 200 OK
Content-Type: text/html
Content-Length: 1024
Date: Tue, 22 Feb 2022 22:22:22 GMT
ETag: "deadbeef"
Cache-Control: max-age=3600
```
如果该响应是过期的，则客户端将此`ETag`值写入到`If-None-Match`

```http
GET /index.html HTTP/1.1
Host: example.com
Accept: text/html
If-None-Match: "deadbeef"
```
如果服务器上的该资源的`ETag`与此`ETag`相同，则服务器返回`304 Not Modified`。

如果服务器上的该资源的`ETag`与此`ETag`不同，则服务器返回`200 OK`和该资源的最新`ETag`、以及该最新资源。

**优先级：**`Last-Modified` < `ETag `，但最好都提供

### 强制重新验证

`no-cache`指令强制验证

```http
HTTP/1.1 200 OK
Content-Type: text/html
Content-Length: 1024
Date: Tue, 22 Feb 2022 22:22:22 GMT
Last-Modified: Tue, 22 Feb 2022 22:00:00 GMT
ETag: deadbeef
Cache-Control: no-cache
```
**注意：**`max-age=0` + `must-revalidate` = `no-cache`

`max-age=0`：响应立即过期
`must-revalidate`：需要在重新验证后才可重用

**注意：**现在应该只使用`no-cache`

## 6. 不使用缓存

`no-cache`需要重新验证后才可重用缓存，但不会阻止响应的存储。

`no-store`不存储响应在任何缓存中，但不会删除相同URL的已存储响应（旧响应可能被重用）。

```http
Cache-Control: no-store
```

## 7. 重新加载和强制重新加载

### 重新加载

为了从页面错误中恢复，或更新到最新版本的资源

```http
GET / HTTP/1.1
Host: example.com
Cache-Control: max-age=0
If-None-Match: "deadbeef"
If-Modified-Since: Tue, 22 Feb 2022 20:20:20 GMT
```
`max-age=0`中间存储的缓存不会被重用

### 强制重新加载

```http
GET / HTTP/1.1
Host: example.com
Pragma: no-cache
Cache-Control: no-cache
```

### 避免重新验证

`immutable`：内容是不可变的，不需要重新验证

```http
Cache-Control: max-age=31536000, immutable
```

