# 资源和URI

## URI语法

参考：[标识互联网上的内容](https://developer.mozilla.org/zh-CN/docs/Web/HTTP/Basics_of_HTTP/Identifying_resources_on_the_Web)

```http
http://www.example.com:80/path/to/myfile.html?key1=value1&key2=value2#Somewhere
```

| 组件 | 举例 |
| :-- | :-- |
| 协议 | http:// |
| 主机 | www.example.com |
| 端口 | :80 |
| 路径 | /path/to/myfile.html |
| 查询 | ?key1=value1&key2=value2 |
| 片段 | #Somewhere |

**注意：**
>
1. `片段`不会随请求发送到服务器。
2. 可表示网页的某个位置，浏览器将滚动到这个位置。
3. 可表示音视频的播放时间，浏览器将定位到该时间。

#### 举例

```http
https://developer.mozilla.org/zh-CN/docs/Learn
tel:+1-816-555-1212
git@github.com:mdn/browser-compat-data.git
ftp://example.org/resource.txt
urn:isbn:9780141036144
```

## Data URL

参考：[Data URL](https://developer.mozilla.org/zh-CN/docs/Web/HTTP/Basics_of_HTTP/Data_URLs)

作用：向文档中插入小文件

#### 语法

```http
data:[mediatype][;base64],<data>
```

| 组件 | 举例 |
| :-- | :-- |
| data: | |
| mediatype | MIME类型，例如：`image/jpeg`，默认：`text/plain;charset=US-ASCII` |
| base64 | base64编码 |
| data | 数据 |

#### 举例

```http
data:text/plain;base64,SGVsbG8sIFdvcmxkIQ%3D%3D
```

## MIME

参考：[MIME 类型](https://developer.mozilla.org/zh-CN/docs/Web/HTTP/Basics_of_HTTP/MIME_types)  
参考：[常见 MIME 类型列表](https://developer.mozilla.org/zh-CN/docs/Web/HTTP/Basics_of_HTTP/MIME_types/Common_types)  
参考：[IANA 媒体类型](https://www.iana.org/assignments/media-types/media-types.xhtml)


**警告：**浏览器使用MIME类型而不是文件扩展名来决定如何处理URL。

#### 语法

```http
type/subtype
type/subtype;parameter=value
```

子类型代表指定类型的确切数据类型；可选参数提供额外的信息。

`text`默认`ASCII`，即`US-ASCII`。


#### 举例

```http
text/plain;charset=UTF-8
application/octet-stream
image/jpeg
```

#### 魔数

![魔数](Images/magic_number.png)



