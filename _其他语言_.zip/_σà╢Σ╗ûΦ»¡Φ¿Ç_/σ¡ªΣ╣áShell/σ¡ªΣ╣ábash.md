## Bash基础

### 1. 基本通配符

| 通配符 | 匹配 |
| :-: | :-: |
| ? | 任何单一字符 |
| * | 任何字符串 |
| [集合] | 集合中的任一个字符 |
| [!集合] | 非集合中的任一个字符 |

![](Images/基本通配符.png)

### 2. 路径名展开

如果能够匹配上，则把匹配上的所有路径名作为结果；

如果不能，则字符串本身作为结果

```c
int main(int argc, const char * argv[]) {
    for (int i = 1; i < argc; i++) {
        puts(argv[i]);
    }
    return 0;
}
```

![](Images/路径名展开.png)

### 3. 大括号展开

![](Images/大括号展开.png)


## Bash基础编程

### 1. 函数声明与调用

```sh
# 申明1
function functname 
{
	shell commands
}

# 申明2
functname () 
{
	shell commands
}

# 调用
functname
functname arg1 arg2 arg3 ...
```

### 2. 变量申明与引用

```sh
# 申明
varname=value

# 引用1
$varname

# 引用2
${varname}
```

### 3. 位置参数

| 位置参数 | 位置参数含义 |
| :-- | :-- |
| $0 | 脚本名称 |
| $1 | 第1个参数 |
| $2 | 第2个参数 |
| $3 | 第3个参数 |
| ... | ... |
| $# | 参数个数 |
| $@ | 各个参数：$1 $2 $3 ... |
| $* | 所有参数组成的字符串（IFS分隔符分割） |

上面的所有变量都是只读

### 4. 变量作用范围

1. 函数有自己的位置参数
2. 变量是全局的（即使变量在函数中申明的也是全局的）
3. 局部变量需要用`local`申明

```sh
#!/bin/bash

function afunc
{
    echo in function: $0 $1 $2
    var1="in function"
    echo var1: $var1
    var2="AAA"
}

var1="outside function"
echo var1: $var1
echo $0: $1 $2
afunc funcarg1 funcarg2
echo var1: $var1
echo var2: $var2
echo $0: $1 $2
```

结果

```sh
var1: outside function
./test.sh: arg1 arag2
in function: ./test.sh funcarg1 funcarg2
var1: in function
var1: in function
var2: AAA
./test.sh: arg1 arag2
```

```sh
function afunc
{
    echo in function: $0 $1 $2
    local var1="in function"
    echo var1: $var1
    var2="AAA"
}
```

### 5. 字符串操作符语法

| 操作符 | 替换 | 作用 |
| :-- | :-- | :-- |
| `${varname:-word}` | 变量存在返回变量值，否则返回word | 如果变量未定义，返回默认值 |
| `${varname:=word}` | 变量存在返回变量值，否则设置变量为word并返回word | 如果变量未定义，设置并返回默认值 |
| `${varname:?word}` | 变量存在返回变量值，否则打印varname: word，并中断当前命令或程序 | 如果变量未定义，捕捉错误 |
| `${varname:+word}` | 变量存在返回word，否则返回null | 测试变量是否存在 |
| `${varname:offset:length}` | 截取变量值，如果没有length则一直到末尾 | 返回变量值的一部分 |

### 6. 模式和模式匹配

| 操作符 | 作用 |
| :-- | :-- |
| `${variable#pattern}` | 如果pattern匹配开头，则删除最短匹配，返回剩余部分 |
| `${variable##pattern}` | 如果pattern匹配开头，则删除最长匹配，返回剩余部分 |
| `${variable%pattern}` | 如果pattern匹配结尾，则删除最短匹配，返回剩余部分 |
| `${variable%%pattern}` | 如果pattern匹配结尾，则删除最长匹配，返回剩余部分 |
| `${variable/pattern/string}` | 使用string替换第一个匹配的 |
| `${variable//pattern/string}` | 使用string替换所有匹配的 |

模式匹配会删除匹配的部分（如果未匹配，则不删除任何字符串，即保留字符串）。


```sh
path="/home/cam/book/long.file.name"

echo ${path#/*/}                #   cam/book/long.file.name
echo ${path##/*/}               #   long.file.name
echo ${path%.*}                 #   /home/cam/book/long.file
echo ${path%%.*}                #   /home/cam/book/long
echo ${path/./_}                #   /home/cam/book/long_file.name
echo ${path//./_}               #   /home/cam/book/long_file_name
```

### 7. 长度运算符

```sh
${#path}						#	返回path字符串的长度
```

### 7. 命令替换

语法：`$(UNIX command)`

```sh
echo $(ls *.pdf)				# 当前目录下的所有pdf文件
```

## 流程控制

`$?`：最后一条执行命令的返回状态
`-a` 和 `-o`：仅限于test条件判断语句中

### 1. if/else

```sh
if condition
then
	statements
[elif condition
	then statements...]
[else
	statements]
fi
```

例如：

```sh
if [ $name="小芬欠钱" ]			# if [ $name = "小芬欠钱" ]
then
    echo "===$name"
fi
```

### 2. for

```sh
for name [in list]
do
	statements that can use
	$name...
done
```

例如：

```sh
IFS=':'
for name in $PATH
do
    echo $name
done
```

**数学for循环**

```sh
for (( initialisation ; ending condition ; update ))
do
	statements...
done
```

例如：

```sh
for (( a=1 ; a<10 ; a++ ))
do
    echo $a
done
```

### 3. case

```sh
case expression in
	patter1 )
	statements ;;
	patter2 )
	statements ;;
	...
esac	
```

例如：

```sh
for name in $(ls)
do
    case ${name#*.} in
        rtf )
        echo "rtf" ;;
        xlsx )
        echo "xlsx" ;;
    esac
done
```

### 4. select

```sh
select name [in list]
do
	statements that can use
done
```

例如：

```sh
select name in $(ls)
do
    if [ $name = "2" ] ; then
        echo $name
    fi
done
```

### 5. while/until

`while`满足条件，`until`不满足条件

```sh
while condition
do
	statements...
done
```

例如：

```sh
i=1
while [ $i -gt 5 ]
do
    echo "===$i"
    i=`expr $i + 1`
done
```

### 10. 字符串比较符号

| 运算符 | 释义 |
| :-: | :-- |
| `str1 = str2` | str1 匹配 str2 |
| `str1 != str2` | str1 不匹配 str2 |
| `str1 < str2` | str1 小于 str2 |
| `str1 > str2` | str1 大于 str2 |
| `-n str1` | str1 不为 null |
| `-z str1` | str1 为 null |

### 11. 文件属性检查

| 运算符 | 为真条件 |
| :-- | :-- |
| `-a file` | 文件存在 |
| `-d file` | 存在且为目录 |
| `-e file` | 文件存在 |
| `-f file` | 存在且为普通文件 |
| `-r file` | 读权限 |
| `-s file` | 存在且不为空 |
| `-w file` | 写权限 |
| `-x file` | 执行权限 |
| `-N file` | 文件最后一次读取后被改动 |
| `-O file` | 自己的文件 |
| `-G file` | 自己组的文件 |
| `file 1 -nt file2` | file1 比 file2 新 |
| `file1 -ot file2` | file1 比 file2 旧 |

### 12. 数学测试符

| 测试符 | 比较 |
| :-- | :-- |
| `-lt` | 小于 |
| `-le` | 小于等于 |
| `-eq` | 等于 |
| `-ge` | 大于等于 |
| `-gt` | 大于 |
| `-ne` | 不等于 |

## 命令行选项、类型声明

### 1. getopts

* 带有`:`表示选项无参数
* 没带`:`表示选项有参数

```sh
while getopts ":ab:c" opt
do
    case $opt in
        a )
            echo "-$opt $OPTARG" ;;
        b )
            echo "-$opt $OPTARG" ;;
        c )
            echo "-$opt $OPTARG" ;;
        ? )
            echo "-$opt $OPTARG" ;;
    esac
done
```

```sh
# 执行
./test.sh -a -b -BBB -c -d -e EEE
# 输出
-a 
-b -BBB
-c 
-? d
-? e
```

```sh
# 执行
./test.sh -a -b -c -d -e EEE
# 输出
-a 
-b -c
-? d
-? e
```

```sh
# 执行
./test.sh -a AAA -b -c -d -e EEE
# 输出
-a
```

### 2. 类型声明

| 选项 | 含义 |
| :-: | :-- |
| -a | 数组变量 |
| -f | 函数名 |
| -F | 函数名（无定义） |
| -i | 整形变量 |
| -r | 只读 |
| -x | Marks the variables for export via the environment |

```sh
a=2
b=3
c=a*b
echo $c				# 输出：a*b
```

```sh
declare -i a=2
declare -i b=3
declare -i c=a*b
echo $c				# 输出：6
```

```sh
a=2
b=3
declare -i c=a*b
echo $c				# 输出：6
```

### 3. 数学运算

```sh
a=2
b=$((a + 1))			
# 或
b=`expr $a + 1`
# 或
let b=2+1
```

### 4. 关系运算符

| 测试符 | 比较 |
| :-: | :-- |
| `<` | 小于 |
| `>` | 大于 |
| `<=` | 小于等于 |
| `>=` | 大于等于 |
| `=` | 等于 |
| `!=` | 不等于 |
| `&&` | 逻辑与 |
| `||` | 逻辑或 |

### 5. 数组

```sh
# 方式1
array[0]=AAA
array[1]=BBB
array[2]=CCC

# 方式2
array=([2]=EEE [1]=FFF [0]=GGG)

# 方式3
array=(HHH III JJJ)                 # 0, 1, 2

# 方式4
array=(AAA [10]=XXX YYY)            # 0, 10, 11

echo ${array}                       # 0
echo ${array[0]}
echo ${array[1]}
echo ${array[2]}
echo ${array[10]}
echo ${array[11]}

echo "-------------------"

for i in ${array[@]}
do
    echo $i                         # 只输出有值的
done

echo ${!array[@]}                   # 输出有值的索引位置
echo ${#array}                      # 数组长度
echo ${#array[10]}                  # 数组长度（同上）

unset array                         # 将array置为null
unset array[10]                     # 将位置10的元素置为null
```

## 输入/输出、命令行处理

| 重定向符 | 作用 |
| :-: | :-- |
| `cmd1 | cmd2` | 将cmd1的输出作为cmd2的输入 |
| `> file` | 将标准输出定向到file文件 |
| `< file` | 读取file的内容作为标准输入 |
| `>> file` | 将标准输出定向到file文件，如果文件存在则为追加 |
| `>| file` | 强制将标准输出定向到file文件，即使`noclobber`被设置 |
| `n>| file` | 强制将文件描述符n输出定向到file文件，即使`noclobber`被设置 |
| `<> file` | 使用file作为标准输入和输出 |
| `n<> file` | 使用文件描述符n作为标准输入和输出 |
| `<< label` | Here-document |
| `n > file` | Here-document |