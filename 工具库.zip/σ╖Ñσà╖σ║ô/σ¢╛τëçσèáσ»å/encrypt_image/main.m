//
//  main.m
//  encrypt_image
//
//  Created by mac on 2020/3/17.
//  Copyright © 2020 mac. All rights reserved.
//

#import <Foundation/Foundation.h>

/// 加解密
NSData *encryptData(NSString *key, NSData *data) {
    if (data.length < 100) {
        return data;
    }
    //  密钥
    NSData *keyData = [key dataUsingEncoding:NSUTF8StringEncoding];
    
    NSMutableData *mData = [NSMutableData dataWithData:data];
    for (uint i = 0; i < 100; i++) {
        uint idx = i % keyData.length;
        const char c1 = ((const char *)keyData.bytes)[idx];
        const char c2 = ((const char *)data.bytes)[i];
        const char c3 = c1 ^ c2;
        [mData replaceBytesInRange:NSMakeRange(i, 1) withBytes:&c3];
    }
    return mData;
}

/// 加密图片
void encryptImage(NSString *key, NSString *path) {
    NSData *data = [NSData dataWithContentsOfFile:path];
    NSData *data2 = encryptData(key, data);
    NSString *path2 = [NSString stringWithFormat:@"%@.enc", path];
    [data2 writeToFile:path2 atomically:YES];
}

/// 加密目录下的图片
void encryptDir(NSString *key, NSString *dir) {
    BOOL isDir = NO;
    BOOL exist = [[NSFileManager defaultManager] fileExistsAtPath:dir isDirectory:&isDir];
    if (!exist) {
        printf("目录不存在: %s\n", dir.UTF8String);
        return;
    }
    if (!isDir) {
        printf("非目录: %s\n", dir.UTF8String);
        return;
    }
    NSError *error = nil;
    NSArray *array = [[NSFileManager defaultManager] contentsOfDirectoryAtPath:dir error:&error];
    array = [[NSFileManager defaultManager] contentsOfDirectoryAtPath:dir error:&error];
    for (NSString *fileName in array) {
        NSString *path = [dir stringByAppendingPathComponent:fileName];
        if ([@[@"png", @"jpg", @"jpeg"] containsObject:path.pathExtension.lowercaseString]) {
            encryptImage(key, path);
        }
    }
}

/// 获取图片目录
NSString *getImagesDir(NSString *dir) {
    if (![dir hasPrefix:@"/"]) {
        const char *cwd = getcwd(NULL, 0);
        NSString *relativeDir = [NSString stringWithCString:cwd encoding:NSUTF8StringEncoding];
        dir = [relativeDir stringByAppendingPathComponent:dir];
        dir = [dir stringByStandardizingPath];
    }
    return dir;
}

int main(int argc, const char * argv[]) {
    if (argc == 1) {
        printf("用法: encrypt_image [密钥] [目录]\n");
        return 1;
    }
    if (argc != 3) {
        printf("参数错误: encrypt_image [密钥] [目录]\n");
        return 3;
    }
    NSString *key = [NSString stringWithCString:argv[1] encoding:NSUTF8StringEncoding];
    NSString *dir = [NSString stringWithCString:argv[2] encoding:NSUTF8StringEncoding];
    dir = getImagesDir(dir);
    encryptDir(key, dir);
    return 0;
}


