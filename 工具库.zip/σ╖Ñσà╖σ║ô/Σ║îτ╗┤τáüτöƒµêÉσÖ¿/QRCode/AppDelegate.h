//
//  AppDelegate.h
//  QRCode
//
//  Created by mac on 2020/10/21.
//

#import <Cocoa/Cocoa.h>

@interface AppDelegate : NSObject <NSApplicationDelegate>


@end

