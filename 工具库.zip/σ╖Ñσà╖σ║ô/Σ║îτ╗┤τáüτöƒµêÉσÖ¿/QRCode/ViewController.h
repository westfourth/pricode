//
//  ViewController.h
//  QRCode
//
//  Created by mac on 2020/10/21.
//

#import <Cocoa/Cocoa.h>

@interface ViewController : NSViewController


@end

