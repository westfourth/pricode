//
//  ViewController.m
//  QRCode
//
//  Created by mac on 2020/10/21.
//

#import "ViewController.h"
#import <CoreImage/CIFilter.h>

@interface ViewController ()
@property (weak) IBOutlet NSImageView *imageView;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
}

- (void)setRepresentedObject:(id)representedObject {
    [super setRepresentedObject:representedObject];
}

- (IBAction)generateQRCode:(NSTextField *)sender {
    NSString *text = [sender stringValue];
    CGFloat width = self.imageView.frame.size.width;
    if (text.length == 0) {
        return;
    }
    CIImage *ciImage = [[self class] qrCode:text];
    CIImage *ciImage2 = [[self class] scaleUp:ciImage width:width];
    NSImage *image = [[self class] convert:ciImage2];
    self.imageView.image = image;
}

///  生成二维码，返回矢量图形
+ (CIImage *)qrCode:(NSString *)text {
    NSData *data = [text dataUsingEncoding:NSUTF8StringEncoding];
    CIFilter *filter = [CIFilter filterWithName:@"CIQRCodeGenerator"];
    [filter setValue:data forKey:@"inputMessage"];
    CIImage *ciImage = filter.outputImage;
    return ciImage;
}

/// 放大
+ (CIImage *)scaleUp:(CIImage *)ciImage width:(CGFloat)width {
    CGFloat scale = width / ciImage.extent.size.width;
    CIImage *ciImage2 = [ciImage imageByApplyingTransform:CGAffineTransformMakeScale(scale, scale)];
    return ciImage2;
}

/// 转换
+ (NSImage *)convert:(CIImage *)ciImage {
    NSCIImageRep *rep = [NSCIImageRep imageRepWithCIImage:ciImage];
    NSImage *image = [[NSImage alloc] initWithSize:rep.size];
    [image addRepresentation:rep];
    return image;
}

@end
