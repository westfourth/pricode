//
//  main.m
//  IconMaker
//
//  Created by mac on 2020/10/5.
//

#import <Foundation/Foundation.h>
#import "Config.h"

const NSString *kFileNameKey = @"filename";
const NSString *kIdiomKey = @"idiom";
const NSString *kScaleKey = @"scale";
const NSString *kSizeKey = @"size";

//MARK:-    path

/// 获取图片路径
NSString *getIconPath(NSString *path) {
    if (![path hasPrefix:@"/"]) {
        const char *cwd = getcwd(NULL, 0);
        NSString *relativeDir = [NSString stringWithCString:cwd encoding:NSUTF8StringEncoding];
        path = [relativeDir stringByAppendingPathComponent:path];
        path = [path stringByStandardizingPath];
    }
    return path;
}

/// 资源目录
NSString *assetDir() {
    NSString *path = NSSearchPathForDirectoriesInDomains(NSDesktopDirectory, NSUserDomainMask, YES).firstObject;
    path = [path stringByAppendingPathComponent:@"AppIcon.appiconset"];
    return path;
}

/// 删除目录，重新创建
void recreateDir(NSString *dir) {
    NSError *error = nil;
    [[NSFileManager defaultManager] removeItemAtPath:dir error:&error];
    [[NSFileManager defaultManager] createDirectoryAtPath:dir withIntermediateDirectories:YES attributes:nil error:&error];
}

//MARK:-    CGImageRef

/// 读取
CGImageRef readImage(NSString *path) {
    CGDataProviderRef dataProvider = CGDataProviderCreateWithFilename(path.UTF8String);
    CGImageRef image = CGImageCreateWithPNGDataProvider(dataProvider, NULL, YES, kCGRenderingIntentDefault);
    return image;
}

/// 调整大小
CGImageRef resizeImage(CGImageRef image, CGSize size) {
    CGContextRef context = CGBitmapContextCreate(NULL, size.width, size.height, CGImageGetBitsPerComponent(image), CGImageGetBytesPerRow(image), CGImageGetColorSpace(image), kCGImageAlphaNoneSkipFirst);
    const CGFloat color[] = {1, 1, 1, 1};
    CGContextSetFillColor(context, color);
    CGContextFillRect(context, (CGRect){.size = size});
    CGContextDrawImage(context, CGContextGetClipBoundingBox(context), image);
    CGImageRef image2 = CGBitmapContextCreateImage(context);
    return image2;
}

/// 写入
void writeImage(CGImageRef image, NSString *path) {
    CFURLRef url = (__bridge CFURLRef)[NSURL fileURLWithPath:path];
    CGImageDestinationRef destination = CGImageDestinationCreateWithURL(url, kUTTypePNG, 1, NULL);
    CGImageDestinationAddImage(destination, image, NULL);
    CGImageDestinationFinalize(destination);
}

//MARK:-    DICT

/// 根据字典确定icon大小
CGSize imageSizeFromDict(NSDictionary *dict) {
    NSString *scaleStr = dict[kScaleKey];
    NSString *sizeStr = dict[kSizeKey];
    
    scaleStr = [scaleStr componentsSeparatedByString:@"x"].firstObject;
    int scale = [scaleStr intValue];
    
    sizeStr = [sizeStr componentsSeparatedByString:@"x"].firstObject;
    CGFloat width = [sizeStr floatValue];
    
    return CGSizeMake(width * scale, width * scale);
}

/// 根据字典确定文件名
NSString *fileNameFromDict(NSDictionary *dict) {
    NSString *idiom = dict[kIdiomKey];
    NSString *scaleStr = dict[kScaleKey];
    NSString *sizeStr = dict[kSizeKey];
    
    sizeStr = [sizeStr componentsSeparatedByString:@"x"].firstObject;
    
    NSString *fileName = [NSString stringWithFormat:@"icon-%@", sizeStr];
    
    //  倍数
    if ([scaleStr isEqualToString:@"2x"]) {
        fileName = [NSString stringWithFormat:@"%@@2x", fileName];
    } else if ([scaleStr isEqualToString:@"3x"]) {
        fileName = [NSString stringWithFormat:@"%@@3x", fileName];
    }
    
    //  ipad
    if ([idiom isEqualToString:@"ipad"]) {
        fileName = [NSString stringWithFormat:@"%@~ipad", fileName];
    }
    
    fileName = [NSString stringWithFormat:@"%@.png", fileName];
    return fileName;
}

//MARK:-    MAIN

int main(int argc, const char * argv[]) {
    const char *exe = argv[0];
    NSString *exePath = [NSString stringWithCString:exe encoding:NSUTF8StringEncoding];
    NSString *exeName = exePath.lastPathComponent;
    if (argc != 2) {
        printf("用法: %s [1024图标路径]\n", exeName.UTF8String);
        return 1;
    }
    
    //  icon
    NSString *iconPath = [NSString stringWithCString:argv[1] encoding:NSUTF8StringEncoding];
    iconPath = getIconPath(iconPath);

    //  资源目录
    NSString *path = assetDir();
    //  删除目录，重新创建
    recreateDir(path);
    //  读取图标
    CGImageRef image = readImage(iconPath);
    
    //  配置
    NSMutableDictionary *config = [Config config];
    NSArray<NSMutableDictionary *> *images = config[@"images"];
    //  转换
    for (NSMutableDictionary *dict in images) {
        CGSize size = imageSizeFromDict(dict);
        NSString *fileName = fileNameFromDict(dict);
        NSString *path2 = [path stringByAppendingPathComponent:fileName];
        CGImageRef image2 = resizeImage(image, size);
        writeImage(image2, path2);
        
        //  改写
        dict[kFileNameKey] = fileName;
    }
    
    NSString *jsonPath = [path stringByAppendingPathComponent:@"Contents.json"];
    NSError *error = nil;
    NSData *data = [NSJSONSerialization dataWithJSONObject:config options:NSJSONWritingPrettyPrinted error:&error];
    [data writeToFile:jsonPath atomically:YES];
    
    return 0;
}
