//
//  Config.h
//  IconMaker
//
//  Created by mac on 2020/10/5.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface Config : NSObject

+ (NSMutableDictionary *)config;

@end

NS_ASSUME_NONNULL_END
