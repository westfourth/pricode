//
//  Config.m
//  IconMaker
//
//  Created by mac on 2020/10/5.
//

#import "Config.h"

@implementation Config

NSString *JSON = @"{\
\"images\" : [\
  {\
    \"idiom\" : \"iphone\",\
    \"scale\" : \"2x\",\
    \"size\" : \"20x20\"\
  },\
  {\
    \"idiom\" : \"iphone\",\
    \"scale\" : \"3x\",\
    \"size\" : \"20x20\"\
  },\
  {\
    \"idiom\" : \"iphone\",\
    \"scale\" : \"2x\",\
    \"size\" : \"29x29\"\
  },\
  {\
    \"idiom\" : \"iphone\",\
    \"scale\" : \"3x\",\
    \"size\" : \"29x29\"\
  },\
  {\
    \"idiom\" : \"iphone\",\
    \"scale\" : \"2x\",\
    \"size\" : \"40x40\"\
  },\
  {\
    \"idiom\" : \"iphone\",\
    \"scale\" : \"3x\",\
    \"size\" : \"40x40\"\
  },\
  {\
    \"idiom\" : \"iphone\",\
    \"scale\" : \"2x\",\
    \"size\" : \"60x60\"\
  },\
  {\
    \"idiom\" : \"iphone\",\
    \"scale\" : \"3x\",\
    \"size\" : \"60x60\"\
  },\
  {\
    \"idiom\" : \"ipad\",\
    \"scale\" : \"1x\",\
    \"size\" : \"20x20\"\
  },\
  {\
    \"idiom\" : \"ipad\",\
    \"scale\" : \"2x\",\
    \"size\" : \"20x20\"\
  },\
  {\
    \"idiom\" : \"ipad\",\
    \"scale\" : \"1x\",\
    \"size\" : \"29x29\"\
  },\
  {\
    \"idiom\" : \"ipad\",\
    \"scale\" : \"2x\",\
    \"size\" : \"29x29\"\
  },\
  {\
    \"idiom\" : \"ipad\",\
    \"scale\" : \"1x\",\
    \"size\" : \"40x40\"\
  },\
  {\
    \"idiom\" : \"ipad\",\
    \"scale\" : \"2x\",\
    \"size\" : \"40x40\"\
  },\
  {\
    \"idiom\" : \"ipad\",\
    \"scale\" : \"1x\",\
    \"size\" : \"76x76\"\
  },\
  {\
    \"idiom\" : \"ipad\",\
    \"scale\" : \"2x\",\
    \"size\" : \"76x76\"\
  },\
  {\
    \"idiom\" : \"ipad\",\
    \"scale\" : \"2x\",\
    \"size\" : \"83.5x83.5\"\
  },\
  {\
    \"idiom\" : \"ios-marketing\",\
    \"scale\" : \"1x\",\
    \"size\" : \"1024x1024\"\
  }\
],\
\"info\" : {\
  \"author\" : \"xcode\",\
  \"version\" : 1\
}\
}\
";

+ (NSMutableDictionary *)config {
    NSData *data = [JSON dataUsingEncoding:NSUTF8StringEncoding];
    NSError *error = nil;
    NSMutableDictionary *dict = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers | NSJSONReadingMutableLeaves error:&error];
    return dict;
}

@end
