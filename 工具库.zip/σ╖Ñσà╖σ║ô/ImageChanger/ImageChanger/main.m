//
//  main.m
//  ImageChanger
//
//  Created by mac on 2020/10/6.
//

#import <Foundation/Foundation.h>

/// 获取图片路径
NSString *getImagesDir(NSString *path) {
    if (![path hasPrefix:@"/"]) {
        const char *cwd = getcwd(NULL, 0);
        NSString *relativeDir = [NSString stringWithCString:cwd encoding:NSUTF8StringEncoding];
        path = [relativeDir stringByAppendingPathComponent:path];
        path = [path stringByStandardizingPath];
    }
    return path;
}

//MARK:-    CGImageRef

/// 读取
CGImageRef readImage(NSString *path) {
    CGDataProviderRef dataProvider = CGDataProviderCreateWithFilename(path.UTF8String);
    CGImageRef image = nil;
    if ([path.pathExtension.lowercaseString isEqualToString:@"png"]) {
        image = CGImageCreateWithPNGDataProvider(dataProvider, NULL, YES, kCGRenderingIntentDefault);
    } else {
        image = CGImageCreateWithJPEGDataProvider(dataProvider, NULL, YES, kCGRenderingIntentDefault);
    }
    return image;
}

/// 调整大小
CGImageRef resizeImage(CGImageRef image, CGSize size) {
    CGContextRef context = CGBitmapContextCreate(NULL, size.width, size.height, CGImageGetBitsPerComponent(image), 0, CGImageGetColorSpace(image), kCGImageAlphaPremultipliedFirst);
    CGRect rect = (CGRect){.size = size};
    CGContextDrawImage(context, CGContextGetClipBoundingBox(context), image);
    CGImageRef image2 = CGBitmapContextCreateImage(context);
    return image2;
}

/// 写入
void writeImage(CGImageRef image, NSString *path) {
    CFURLRef url = (__bridge CFURLRef)[NSURL fileURLWithPath:path];
    CGImageDestinationRef destination = CGImageDestinationCreateWithURL(url, kUTTypePNG, 1, NULL);
    CGImageDestinationAddImage(destination, image, NULL);
    CGImageDestinationFinalize(destination);
}


//  递归改变图片的大小
//  exe +[n] [图片目录]
//  exe -[n] [图片目录]
int main(int argc, const char * argv[]) {
    const char *exe = argv[0];
    NSString *exePath = [NSString stringWithCString:exe encoding:NSUTF8StringEncoding];
    NSString *exeName = exePath.lastPathComponent;
    if (argc != 3) {
        printf("用法1: %s +[n] [图片目录]\n", exeName.UTF8String);
        printf("用法2: %s -[n] [图片目录]\n", exeName.UTF8String);
        return 3;
    }
    
    int change = atoi(argv[1]);
    
    //  图片目录
    NSString *imagesDir = [NSString stringWithCString:argv[2] encoding:NSUTF8StringEncoding];
    imagesDir = getImagesDir(imagesDir);
    
    //
    NSArray *array = [[NSFileManager defaultManager] subpathsAtPath:imagesDir];
    for (int i = 0; i < array.count; i++) {
        NSString *path = array[i];
        if ([@[@"png", @"jpg", @"jpeg"] containsObject:path.pathExtension.lowercaseString]) {
            NSString *fullPath = [imagesDir stringByAppendingPathComponent:path];
            //
            CGImageRef image = readImage(fullPath);
            CGSize size = CGSizeMake(CGImageGetWidth(image) + change, CGImageGetHeight(image) + change);
            CGImageRef image2 = resizeImage(image, size);
            writeImage(image2, fullPath);
        }
    }
    
    return 0;
}
