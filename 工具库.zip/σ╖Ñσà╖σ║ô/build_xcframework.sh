#!/bin/bash

# 配置
scheme="FrameTT"
# 配置：Release、Debug
configuration="Release"


################################################################
work_dir=`pwd`
rm -rf archives/*
xcodebuild clean

# 真机
xcodebuild archive \
    -scheme $scheme \
    -configuration $configuration \
    -sdk iphoneos \
    -archivePath archives/iphoneos.xcarchive \
    BUILD_LIBRARY_FOR_DISTRIBUTION=YES \
    SKIP_INSTALL=NO

# 模拟器
xcodebuild archive \
    -scheme $scheme \
    -configuration $configuration \
    -sdk iphonesimulator \
    -archivePath archives/iphonesimulator.xcarchive \
    BUILD_LIBRARY_FOR_DISTRIBUTION=YES \
    SKIP_INSTALL=NO

# 匹配uuid
uuid_pattern="[0-9A-F]{8}-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{12}"

# 拼接多个 -debug-symbols *.bcsymbolmap
function debug_symbols() {
    work_dir=`pwd`
    
    dsym_path=${work_dir}/dSYMs/$scheme.framework.dSYM
    if [ -d "$dsym_path" ];then
        echo " -debug-symbols $dsym_path "
        array_str=`dwarfdump -u $dsym_path`
        array=($array_str)
        count=${#array[@]}
        
        for ((i=0; i<$count; i++))
        do
            if [[ ${array[$i]} =~ $uuid_pattern ]];then
                bcsymbolmap_path=${work_dir}/BCSymbolMaps/${array[$i]}.bcsymbolmap
                if [ -f "$bcsymbolmap_path" ];then
                    echo " -debug-symbols $bcsymbolmap_path "
                fi
            fi
        done
    fi
    
    echo ""
}

cd $work_dir/archives/iphoneos.xcarchive
iphoneos_debug_symbols=`debug_symbols`

cd $work_dir/archives/iphonesimulator.xcarchive
iphonesimulator_debug_symbols=`debug_symbols`


######## xcframework ########
cd $work_dir
xcodebuild -create-xcframework \
    -framework archives/iphoneos.xcarchive/Products/Library/Frameworks/$scheme.framework \
    ${iphoneos_debug_symbols} \
    -framework archives/iphonesimulator.xcarchive/Products/Library/Frameworks/$scheme.framework \
    ${iphonesimulator_debug_symbols} \
    -output archives/$scheme.xcframework
