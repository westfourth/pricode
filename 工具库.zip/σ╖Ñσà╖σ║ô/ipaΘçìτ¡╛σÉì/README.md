# ipa重签名

## 用法

#### 将`ipa`、`resign.sh`、`config.plist`三个文件放在用一个目录下，执行

``` bash
./resign.sh
```
`config.plist`是配置文件，可配置名称、版本号、构建号。

如果不想改变程序名称，不填写`CFBundleName`值，或者删掉`CFBundleName`。

## 核心实现

#### 从`mobileprovision`中提取`TeamIdentifier`、`TeamName`、`application-identifier`，还有`Entitlements`。

``` bash
security cms -D -i embedded.mobileprovision > mobileprovision.plist
/usr/libexec/PlistBuddy -x -c 'Print:Entitlements' mobileprovision.plist > entitlements.plist
```

#### 使用`TeamIdentifier`、`TeamName`、`application-identifier`生成`signing_identity`

``` bash
signing_identity="Apple Distribution: $team_name ($team_id)"
```

#### 签名Frameworks

``` bash
codesign -fs "$signing_identity" Frameworks/*
```

#### 签名app

``` bash
codesign -fs "$signing_identity" --entitlements entitlements.plist ../*.app
```

## 遇到的问题

#### 1. Missing Code Signing Entitlements. No entitlements found in bundle 'com.sel.idiom' for executable

签名的时候要使用`--entitlements entitlements.plist`。

#### 2. The IPA is invalid. It does not include a Payload directory.

打包的时候，`Payload`目录上一级还有个目录，可使用`unzip -l *.ipa`查看。

#### 3. Apple: ambiguous (matches "Apple Distribution: xiaohong peng (5299K4LQD9)" and "Apple Distribution: xiaohong peng (5299K4LQD9)" in /Users/mac/Library/Keychains/login.keychain-db)

`codesign -fs $signing_identity`中`signing_identity`没有作为一个整体。
