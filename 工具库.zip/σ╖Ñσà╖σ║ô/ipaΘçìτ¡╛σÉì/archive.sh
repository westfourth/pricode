#!/bin/bash

# 配置
scheme="KuaiBo"
project_dir="$HOME/kb"
plist_path="$HOME/Desktop/重签名/ExportOptions.plist"

cd $project_dir
xcodebuild clean

# 打包
xcodebuild archive \
-workspace *.xcworkspace \
-scheme $scheme \
-archivePath ~/Desktop/$scheme.xcarchive

# 导出ipa
xcodebuild -exportArchive -allowProvisioningUpdates \
-exportOptionsPlist $plist_path \
-archivePath ~/Desktop/$scheme.xcarchive \
-exportPath ~/Desktop/
