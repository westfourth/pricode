#!/bin/bash
xcrun altool --upload-app \
-f *.ipa \
-u sqpa426@163.com \
-p zlrx-xfhd-yxgq-yzwd
