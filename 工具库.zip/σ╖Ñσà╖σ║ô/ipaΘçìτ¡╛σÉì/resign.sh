#!/bin/bash

# 将ipa、resign.sh、config.plist三个文件放在用一个目录下
# 执行：./resign.sh
# 如果不想改变程序名称，删掉config.plist的CFBundleName；或者不填

# 配置
app_name=`/usr/libexec/PlistBuddy -c 'Print :CFBundleName' config.plist`
app_version=`/usr/libexec/PlistBuddy -c 'Print :CFBundleShortVersionString' config.plist`
app_build=`/usr/libexec/PlistBuddy -c 'Print :CFBundleVersion' config.plist`

################ 主程序 ################

# 解压ipa
ipa_name=`ls *.ipa`
extract_dir=${ipa_name%.ipa}
rm -r $extract_dir
mkdir $extract_dir
echo ">>> 解压缩中..."
unzip -q $ipa_name -d $extract_dir

# 拷贝证书
app_dir=`find . -name *.app`
rm $app_dir/embedded.mobileprovision
cp *.mobileprovision $app_dir/embedded.mobileprovision

# 进入app目录
app_dir=`find . -name *.app`
echo ">>> 进入目录：$app_dir"
cd $app_dir

# 生成entitlements
provision_plist="embedded.mobileprovision.plist"
security cms -D -i embedded.mobileprovision > $provision_plist
/usr/libexec/PlistBuddy -x -c 'Print:Entitlements' $provision_plist > entitlements.plist

# 提取 team_id、team_name、bundle_id
team_id=`/usr/libexec/PlistBuddy -c 'Print :TeamIdentifier:0' $provision_plist`
team_name=`/usr/libexec/PlistBuddy -c 'Print :TeamName' $provision_plist`
app_id=`/usr/libexec/PlistBuddy -c 'Print :Entitlements:application-identifier' $provision_plist`
bundle_id=${app_id#$team_id.}

# 移除embedded.mobileprovision.plist
rm $provision_plist

# 拼接signing_identity
signing_identity="Apple Distribution: $team_name ($team_id)"
echo ">>> 使用证书：$signing_identity"

# 修改Info.plist
/usr/libexec/PlistBuddy -c "Set :CFBundleIdentifier $bundle_id" Info.plist
/usr/libexec/PlistBuddy -c "Set :CFBundleShortVersionString $app_version" Info.plist
/usr/libexec/PlistBuddy -c "Set :CFBundleVersion $app_build" Info.plist
if [ -z $app_name ]
then
    echo ">>> 不改变app名称"
else
    /usr/libexec/PlistBuddy -c "Set :CFBundleName $app_name" Info.plist
fi

# 签名
echo ">>> 签名中..."
codesign -fs "$signing_identity" Frameworks/*
codesign -fs "$signing_identity" --entitlements entitlements.plist ../*.app

# 打包
cd ../..
echo ">>> 压缩中..."
zip -r -q -o $extract_dir.ipa *
mv *.ipa ../
cd ..
rm -r $extract_dir
echo ">>> 签名成功"
