//
//  main.m
//  LaunchImageMaker
//
//  Created by mac on 2020/10/10.
//

#import <Foundation/Foundation.h>

/// 获取icon路径
NSString *getIconPath(NSString *path) {
    if (![path hasPrefix:@"/"]) {
        const char *cwd = getcwd(NULL, 0);
        NSString *relativeDir = [NSString stringWithCString:cwd encoding:NSUTF8StringEncoding];
        path = [relativeDir stringByAppendingPathComponent:path];
        path = [path stringByStandardizingPath];
    }
    return path;
}

/// 启动图路径
NSString *getLaunchImagePath() {
    NSString *path = NSSearchPathForDirectoriesInDomains(NSDesktopDirectory, NSUserDomainMask, YES).firstObject;
    path = [path stringByAppendingPathComponent:@"LaunchImage.jpg"];
    return path;
}

//MARK:-    CGImageRef

/// 读取
CGImageRef readImage(NSString *path) {
    CGDataProviderRef dataProvider = CGDataProviderCreateWithFilename(path.UTF8String);
    CGImageRef image = nil;
    if ([path.pathExtension.lowercaseString isEqualToString:@"png"]) {
        image = CGImageCreateWithPNGDataProvider(dataProvider, NULL, YES, kCGRenderingIntentDefault);
    } else {
        image = CGImageCreateWithJPEGDataProvider(dataProvider, NULL, YES, kCGRenderingIntentDefault);
    }
    return image;
}

/// 绘制logo
CGImageRef drawImage(CGImageRef image) {
    CGSize size = CGSizeMake(1242, 2688);
    CGContextRef context = CGBitmapContextCreate(NULL, size.width, size.height, 8, 0, CGColorSpaceCreateDeviceRGB(), kCGImageAlphaNoneSkipFirst);
    CGContextSetRGBFillColor(context, 1, 1, 1, 1);
    CGContextFillRect(context, (CGRect){.size = size});
    //  计算icon位置
    CGSize imageSize = CGSizeMake(CGImageGetWidth(image) * 3, CGImageGetHeight(image) * 3);
    CGPoint imageOrigin = CGPointMake((size.width - imageSize.width) / 2, (size.height - imageSize.height) / 2);
    CGRect imageRect = (CGRect){.origin = imageOrigin, .size = imageSize};
    
    CGContextDrawImage(context, imageRect, image);
    CGImageRef image2 = CGBitmapContextCreateImage(context);
    return image2;
}

/// 写入
void writeImage(CGImageRef image, NSString *path) {
    CFURLRef url = (__bridge CFURLRef)[NSURL fileURLWithPath:path];
    CGImageDestinationRef destination = CGImageDestinationCreateWithURL(url, kUTTypePNG, 1, NULL);
    CGImageDestinationAddImage(destination, image, NULL);
    CGImageDestinationFinalize(destination);
}

//  用icon生成启动图。
//  icon放中间，启动图大小为：1242x2688，在桌面上
//  exe [icon路径]
int main(int argc, const char * argv[]) {
    const char *exe = argv[0];
    NSString *exePath = [NSString stringWithCString:exe encoding:NSUTF8StringEncoding];
    NSString *exeName = exePath.lastPathComponent;
    if (argc != 2) {
        printf("用法: %s [icon路径]\n", exeName.UTF8String);
        return 2;
    }
    
    //  图片目录
    NSString *iconPath = [NSString stringWithCString:argv[1] encoding:NSUTF8StringEncoding];
    iconPath = getIconPath(iconPath);
    NSString *destPath = getLaunchImagePath(iconPath);
    
    CGImageRef image = readImage(iconPath);
    CGImageRef image2 = drawImage(image);
    writeImage(image2, destPath);
    
    return 0;
}
