//
//  TableViewCell.swift
//  TF Detector
//
//  Created by mac on 2020/12/10.
//

import UIKit
import Kingfisher

class TableViewCell: UITableViewCell {
    @IBOutlet weak var icon: UIImageView!
    @IBOutlet weak var title: UILabel!
    @IBOutlet weak var status: UIImageView!
    @IBOutlet weak var activity: UIActivityIndicatorView!
    
    var model: Model? {
        didSet {
            guard model != nil else { return }
            icon.kf.setImage(with: model?.icon)
            title.text = model?.alias ?? model?.name
            
            switch model?.status {
            case .requesting:
                status.isHidden = true
                activity.isHidden = false
                activity.startAnimating()
            case .available:
                status.isHidden = false
                status.image = UIImage(named: "success")
                activity.isHidden = true
                activity.stopAnimating()
            case .unavailable:
                status.isHidden = false
                status.image = UIImage(named: "fail")
                activity.isHidden = true
                activity.stopAnimating()
            case .error:
                status.isHidden = false
                status.image = UIImage(named: "error")
                activity.isHidden = true
                activity.stopAnimating()
            default:
                break
            }
        }
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()

    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
}
