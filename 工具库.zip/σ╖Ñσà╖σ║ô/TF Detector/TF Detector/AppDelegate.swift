//
//  AppDelegate.swift
//  TF Detector
//
//  Created by mac on 2020/12/10.
//

import UIKit
import SVProgressHUD

@main
class AppDelegate: UIResponder, UIApplicationDelegate {
    var window: UIWindow?

    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        configHud()
        return true
    }

    func configHud() {
        SVProgressHUD.setDefaultStyle(.dark)
        SVProgressHUD.setDefaultMaskType(.black)
        SVProgressHUD.setMinimumDismissTimeInterval(1)
        SVProgressHUD.setSuccessImage(UIImage(named: "success")!)
        SVProgressHUD.setErrorImage(UIImage(named: "error")!)
    }
}

