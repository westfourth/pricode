//
//  ViewController.swift
//  TF Detector
//
//  Created by mac on 2020/12/10.
//

import UIKit
import SVProgressHUD
import BarcodeScanner

class ViewController: UITableViewController {
    var models = [Model]()

    override func viewDidLoad() {
        super.viewDidLoad()
        //  读取数据
        models = Model.read()
        tableView.tableFooterView = UIView()
        
        //
        NotificationCenter.default.addObserver(self, selector: #selector(willTerminate(notification:)), name: UIApplication.willTerminateNotification, object: nil)
        
        //
        batchQuery()
    }
    
    
    deinit {
        Model.write(models)
    }
    
    @objc func willTerminate(notification: Notification) {
        Model.write(models)
    }
    
    @IBAction func click(add: UIBarButtonItem) {
        let vc = UIAlertController(title: "请输入兑换码", message: "TestFlight的8位字符", preferredStyle: .alert)
        vc.addTextField(configurationHandler: nil)
        let ok = UIAlertAction(title: "确定", style: .default) {[weak self] (action) in
            let code = vc.textFields?.first?.text
            guard code != nil, code?.count == 8 else {
                SVProgressHUD.showError(withStatus: "未能正确输入8位兑换码")
                return
            }
            self?.queryApp(redeem: code!)
        }
        let cancel = UIAlertAction(title: "取消", style: .cancel) { (action) in
        }
        vc.addAction(ok)
        vc.addAction(cancel)
        present(vc, animated: true, completion: nil)
    }
    
    @IBAction func click(scan: UIBarButtonItem) {
        let vc = BarcodeScannerViewController()
        vc.codeDelegate = self
        vc.messageViewController.imageView.image = UIImage(named: "qrcode")
        navigationController?.pushViewController(vc, animated: true)
    }
    
    //
    func batchQuery() {
        for model in models {
            model.status = .requesting
        }
        for model in models {
            Network.share.get(model) {
                self.tableView.reloadData()
            }
        }
    }
    
    //
    func queryApp(redeem code: String) {
        let model = Model()
        model.redeem = code
        
        SVProgressHUD.show(withStatus: "正在查询...")
        Network.share.get(model) {
            switch model.status {
            case .available:
                SVProgressHUD.showSuccess(withStatus: "查询成功")
                let matchItem = self.models.filter { (item) -> Bool in
                    return item.redeem == code
                }
                if matchItem.count == 0 {
                    self.models.append(model)
                    self.tableView.reloadData()
                }
            case .unavailable:
                SVProgressHUD.showError(withStatus: "App不存在")
            case .error:
                SVProgressHUD.showError(withStatus: "网络错误")
            default:
                break
            }
        }
    }
}

extension ViewController {
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ID", for: indexPath) as! TableViewCell
        cell.model = models[indexPath.row]
        return cell
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return models.count
    }
    
    override func tableView(_ tableView: UITableView, editActionsForRowAt indexPath: IndexPath) -> [UITableViewRowAction]? {
        let delete = UITableViewRowAction(style: .destructive, title: "删除") { (action, indexPath) in
            self.models.remove(at: indexPath.row)
            tableView.reloadSections(IndexSet(integer: 0), with: .automatic)
        }
        let edit = UITableViewRowAction(style: .normal, title: "编辑") { (action, indexPath) in
            let model = self.models[indexPath.row]
            self.edit(model: model)
        }
        return [delete, edit]
    }
    
    //  编辑名称
    func edit(model: Model) {
        let vc = UIAlertController(title: "请输入别名", message: nil, preferredStyle: .alert)
        vc.addTextField(configurationHandler: nil)
        let ok = UIAlertAction(title: "确定", style: .default) {[weak self] (action) in
            let text = vc.textFields?.first?.text
            guard text != nil, text?.count != 0 else {
                return
            }
            model.alias = text
            self?.tableView.reloadData()
        }
        let cancel = UIAlertAction(title: "取消", style: .cancel) { (action) in
        }
        vc.addAction(ok)
        vc.addAction(cancel)
        present(vc, animated: true, completion: nil)
    }
}

extension ViewController: BarcodeScannerCodeDelegate {
    func scanner(_ controller: BarcodeScannerViewController, didCaptureCode code: String, type: String) {
        navigationController?.popViewController(animated: true)
        let url = URL(string: code)
        let redeem = url?.lastPathComponent
        guard redeem?.count == 8 else {
            return
        }
        queryApp(redeem: redeem!)
    }
}
