//
//  Model.swift
//  TF Detector
//
//  Created by mac on 2020/12/10.
//

import UIKit

class Model: Codable {
    
    enum Status: Int, Codable {
        case requesting     // 请求中
        case available      // app可用
        case unavailable    // app不可用
        case error          // 网络错误
    }
    
    var redeem: String = ""     //  兑换码
    var name: String?           //  名称
    var alias: String?          //  别名
    var icon: URL?              //  icon
    var status: Status = .requesting
}


extension Model {
    static func fileURL() -> URL {
        var url = FileManager.default.urls(for: .cachesDirectory, in: .userDomainMask).first!
        url.appendPathComponent("model")
        return url
    }
    
    static func write(_ models: [Model]) {
        let data = try? JSONEncoder().encode(models)
        guard data != nil else {
            return
        }
        try? data!.write(to: fileURL())
    }
    
    static func read() -> [Model] {
        let data = try? Data(contentsOf: fileURL())
        guard data != nil else {
            return [Model]()
        }
        let models = try? JSONDecoder().decode([Model].self, from: data!)
        return models ?? [Model]()
    }
}
