//
//  Network.swift
//  TF Detector
//
//  Created by mac on 2020/12/10.
//

import UIKit
import hpple

class Network: NSObject {
    static var share = Network()
    
    /// 请求时，只需要redeem兑换码
    func get(_ model: Model, completion: @escaping () -> Void) {
        let str = "https://testflight.apple.com/join/" + model.redeem
        let url = URL(string: str)!
        let req = URLRequest(url: url, cachePolicy: .reloadIgnoringLocalCacheData, timeoutInterval: 5)
        
        let completion2: () -> Void = {
            DispatchQueue.main.async {
                completion()
            }
        }
        
        let task = URLSession.shared.dataTask(with: req) { (data, resp, error) in
            guard error == nil else {
                model.status = .error
                completion2()
                return
            }
            guard resp is HTTPURLResponse, (resp as! HTTPURLResponse).statusCode == 200 else {
                model.status = .unavailable
                completion2()
                return
            }
            self.parse(model, data: data!)
            model.status = .available
            completion2()
        }
        task.resume()
    }
    
    //
    func parse(_ model: Model, data: Data) {
        let doc = TFHpple(htmlData: data)!
        //  查找title
        var elements = doc.search(withXPathQuery: "//title")
        var node = elements?.first as! TFHppleElement
        var title = node.text()
        let range = title?.range(of: " - TestFlight - Apple")
        if range == nil {
            model.status = .unavailable
            return
        }
        
        title?.removeSubrange(range!)
        model.name = title
        
        //  查找icon
        elements = doc.search(withXPathQuery: "//link[@rel='apple-touch-icon']")
        node = elements?.first as! TFHppleElement
        let href = node.object(forKey: "href")!
        var url = URL(string: href)
        url?.deleteLastPathComponent()
        url?.appendPathComponent("152x152bb-80.png")
        model.icon = url
    }
}
