//
//  main.m
//  ChineseConvert
//
//  Created by mac on 2020/3/27.
//  Copyright © 2020 mac. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        // Setup code that might create autoreleased objects goes here.
    }
    return NSApplicationMain(argc, argv);
}
