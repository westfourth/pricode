//
//  CommendConvert.h
//  ChineseConvert
//
//  Created by mac on 2020/3/31.
//  Copyright © 2020 mac. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "opencc.h"

NS_ASSUME_NONNULL_BEGIN

/**
    上一步将文件中的所有简体转换成繁体
 
    下一步将注释中的繁体转化为简体
 */
@interface CommendConvert : NSObject {
    opencc_t _opencc;
}

+ (instancetype)share;

//  将注释中的繁体转化为简体
- (NSString *)convert:(NSString *)text;

@end

NS_ASSUME_NONNULL_END
