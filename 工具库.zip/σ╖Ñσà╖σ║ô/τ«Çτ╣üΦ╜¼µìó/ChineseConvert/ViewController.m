//
//  ViewController.m
//  ChineseConvert
//
//  Created by mac on 2020/3/27.
//  Copyright © 2020 mac. All rights reserved.
//

#import "ViewController.h"
#import "CommendConvert.h"

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self setDefaultPatterns];
}

//  设置默认转换文件
- (void)setDefaultPatterns {
    NSString *path = [[NSBundle mainBundle] pathForResource:@"Patterns" ofType:@"plist"];
    NSArray *array = [NSArray arrayWithContentsOfFile:path];
    NSString *patterns = [array componentsJoinedByString:@"\n"];
    NSTextView *textView = self.pattersScrollView.documentView;
    textView.string = patterns;
}

//  允许的文件后缀
- (NSArray *)allowFileExtensions {
    NSTextView *textView = self.pattersScrollView.documentView;
    NSString *patterns = textView.string;
    NSArray *array = [patterns componentsSeparatedByString:@"\n"];
    return array;
}

//  忽略的目录
- (NSArray *)ignoreDirectionaries {
    NSTextView *textView = self.ignoreScrollView.documentView;
    NSString *patterns = textView.string;
    NSArray *array = [patterns componentsSeparatedByString:@"\n"];
    return array;
}

//  简体转台湾繁体
- (IBAction)s2twp:(NSButton *)button {
    NSString *config = [[NSBundle mainBundle] pathForResource:@"s2tw" ofType:@"json"];
    _opencc = opencc_open(config.UTF8String);
    [self convert:button];
}

//  台湾繁体转简体
- (IBAction)tw2sp:(NSButton *)button {
    NSString *config = [[NSBundle mainBundle] pathForResource:@"tw2s" ofType:@"json"];
    _opencc = opencc_open(config.UTF8String);
    [self convert:button];
}

- (void)convert:(NSButton *)button {
    NSString *dir = self.dirTextField.stringValue;
    NSArray *allowFileExtensions = [self allowFileExtensions];
    NSArray *ignoreDirectionaries = [self ignoreDirectionaries];
    
    if (dir.length == 0) {
        self.infoLabel.stringValue = @"请输入正确的路径";
        return;
    }
    if (![[NSFileManager defaultManager] fileExistsAtPath:dir]) {
        self.infoLabel.stringValue = @"路径不存在";
        return;
    }
    
    //
    button.enabled = NO;
    //
    dispatch_async(dispatch_get_global_queue(0, 0), ^{
        [self convertDir:dir allowFileExtensions:allowFileExtensions ignoreDirectionaries:ignoreDirectionaries];
        //
        dispatch_async(dispatch_get_main_queue(), ^{
            button.enabled = YES;
            self.infoLabel.stringValue = @"转换结束";
        });
    });
}

- (void)convertDir:(NSString *)dir allowFileExtensions:(NSArray *)fileExtensions ignoreDirectionaries:(NSArray *)ignoreDirectionaries {
    NSError *error = nil;
    NSArray *array = [[NSFileManager defaultManager] subpathsOfDirectoryAtPath:dir error:&error];
    for (NSString *item in array) {
        NSString *path = [dir stringByAppendingPathComponent:item];
        //  忽略目录
        if ([self ignoreDirectionaries:ignoreDirectionaries containsPath:path]) {
            continue;
        }
        
        dispatch_async(dispatch_get_main_queue(), ^{
            self.infoLabel.stringValue = path;
        });
        
        NSString *fe = path.pathExtension;
        //  匹配文件
        if ([fileExtensions containsObject:fe]) {
            NSString *text1 = [NSString stringWithContentsOfFile:path encoding:NSUTF8StringEncoding error:&error];
            const char *s1 = text1.UTF8String;
            const char *s2 = opencc_convert_utf8(_opencc, s1, strlen(s1));
            NSString *text2 = [NSString stringWithCString:s2 encoding:NSUTF8StringEncoding];
            NSString *text3 = [[CommendConvert share] convert:text2];
            [text3 writeToFile:path atomically:YES encoding:NSUTF8StringEncoding error:&error];
        }
    }
}

- (BOOL)ignoreDirectionaries:(NSArray *)ignoreDirectionaries containsPath:(NSString *)path {
    for (NSString *dir in ignoreDirectionaries) {
        if ([path hasPrefix:dir]) {
            return YES;
        }
    }
    return NO;
}

@end
