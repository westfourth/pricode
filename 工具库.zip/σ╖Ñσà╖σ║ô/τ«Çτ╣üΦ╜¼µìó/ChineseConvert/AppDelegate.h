//
//  AppDelegate.h
//  ChineseConvert
//
//  Created by mac on 2020/3/27.
//  Copyright © 2020 mac. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface AppDelegate : NSObject <NSApplicationDelegate>


@end

