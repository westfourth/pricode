//
//  CommendConvert.m
//  ChineseConvert
//
//  Created by mac on 2020/3/31.
//  Copyright © 2020 mac. All rights reserved.
//

#import "CommendConvert.h"

@implementation CommendConvert

+ (instancetype)share {
    static id instance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [[self class] new];
    });
    return instance;
}

- (instancetype)init {
    self = [super init];
    if (self) {
        NSString *config = [[NSBundle mainBundle] pathForResource:@"tw2s" ofType:@"json"];
        _opencc = opencc_open(config.UTF8String);
    }
    return self;
}

- (NSString *)convert:(NSString *)text {
//    NSString *pattern = @"(\n( |\t)*//.*)|(\n( |\t)*/\\*[\\s\\S]*?\\*/)";
    NSString *pattern = @"(( |\t)*//.*)|(\n( |\t)*/\\*[\\s\\S]*?\\*/)";
    NSError *error = nil;
    NSRegularExpression *regexp = [NSRegularExpression regularExpressionWithPattern:pattern options:0 error:&error];
    NSArray<NSTextCheckingResult *> *results = [regexp matchesInString:text options:0 range:NSMakeRange(0, text.length)];
    
    //
    NSMutableString *mText = [NSMutableString stringWithString:text];
    //  倒序
    for (NSInteger i = results.count - 1; i >= 0; i--) {
        NSTextCheckingResult *result = results[i];
        NSString *text1 = [text substringWithRange:result.range];
        const char *s1 = text1.UTF8String;
        const char *s2 = opencc_convert_utf8(_opencc, s1, strlen(s1));
        NSString *text2 = [NSString stringWithCString:s2 encoding:NSUTF8StringEncoding];
        [mText replaceCharactersInRange:result.range withString:text2];
    }
    return mText;
}

@end
