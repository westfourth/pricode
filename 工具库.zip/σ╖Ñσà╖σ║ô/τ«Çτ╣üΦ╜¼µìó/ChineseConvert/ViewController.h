//
//  ViewController.h
//  ChineseConvert
//
//  Created by mac on 2020/3/27.
//  Copyright © 2020 mac. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "opencc.h"

@interface ViewController : NSViewController {
    opencc_t _opencc;
}

@property (weak) IBOutlet NSTextField *dirTextField;

@property (weak) IBOutlet NSScrollView *pattersScrollView;
@property (weak) IBOutlet NSScrollView *ignoreScrollView;

@property (weak) IBOutlet NSButton *s2twpButton;
@property (weak) IBOutlet NSButton *tw2spButton;

@property (weak) IBOutlet NSTextField *infoLabel;


@end

