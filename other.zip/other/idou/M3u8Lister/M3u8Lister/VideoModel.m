//
//  VideoModel.m
//  HTMLParser
//
//  Created by hanxin on 2023/2/16.
//

#import "VideoModel.h"
#import "hpple/TFHpple.h"

//  https://www.imadou.cc
//  https://www.634.tv
const NSString *kBaseURL = @"https://www.634.tv";

@implementation VideoModel

- (NSDictionary *)toDict {
    NSMutableDictionary *dict = [NSMutableDictionary new];
    dict[@"title"] = self.title;
    dict[@"href"] = self.href;
    dict[@"image"] = self.image;
    dict[@"m3u8"] = self.m3u8;
    return dict;
}

+ (VideoModel *)fromDict:(NSDictionary *)dict {
    VideoModel *model = [VideoModel new];
    model.title = dict[@"title"];
    model.href = dict[@"href"];
    model.image = dict[@"image"];
    model.m3u8 = dict[@"m3u8"];
    return model;
}

+ (NSMutableArray<NSDictionary *> *)toDicts:(NSMutableArray<VideoModel *> *)models {
    NSMutableArray<NSDictionary *> *array = [NSMutableArray new];
    for (VideoModel *model in models) {
        NSDictionary *dict = model.toDict;
        [array addObject:dict];
    }
    return array;
}

+ (NSMutableArray<VideoModel *> *)toModels:(NSMutableArray<NSDictionary *> *)dictArray {
    NSMutableArray<VideoModel *> *array = [NSMutableArray new];
    for (NSDictionary *dict in dictArray) {
        VideoModel *model = [self fromDict:dict];
        [array addObject:model];
    }
    return array;
}


+ (NSMutableArray<VideoModel *> *)parseHTMLData:(NSData *)data {
    NSMutableArray<VideoModel *> *array = [NSMutableArray new];
    TFHpple *doc = [TFHpple hppleWithHTMLData:data];
    NSArray<TFHppleElement *> *elements = [doc searchWithXPathQuery:@"//a[@class='stui-vodlist__thumb lazyload']"];
    
    for (TFHppleElement *ele in elements) {
        NSDictionary *attrs = ele.attributes;
        VideoModel *model = [VideoModel new];
        model.title = attrs[@"title"];
        model.href = [kBaseURL stringByAppendingString:attrs[@"href"]];
        model.image = attrs[@"data-original"];
        [array addObject:model];
    }
    return array;
}

@end
