//
//  main.m
//  HTMLParser
//
//  Created by hanxin on 2023/2/16.
//

#import <Foundation/Foundation.h>
#import "VideoModel.h"

int total_downloaded = 0;

void parse(int i, NSString *dir);
void merge(int i, NSMutableArray<NSDictionary *> *array, NSString *dir);
void local_parse(NSString *dir);
NSString* pickup_m3u8(NSString *content);
void read_file(NSString *dir);
void write_file(NSString *dir, NSMutableArray<VideoModel *> *models);
void download_m3u8_file(NSMutableArray<VideoModel *> *models, int i, int step, NSString *dir);

//  https://www.634.tv/index.php/vod/show/id/1/page/1.html
int main(int argc, const char * argv[]) {
    @autoreleasepool {
        if (argc != 2) {
            NSString *program = [NSString stringWithFormat:@"%s", argv[0]].lastPathComponent;
            printf("用法: %s [json目录绝对路径]\n", program.UTF8String);
            exit(0);
            return 0;
        }
        
        NSString *dir = [NSString stringWithFormat:@"%s", argv[1]];
        NSMutableArray<NSDictionary *> *array = [NSMutableArray new];
        
//        parse(1, dir);
        
        merge(1, array, dir);
        
//        pickup_m3u8(nil);
        
//        read_file(dir);
        
    }
    CFRunLoopRun();
    return 0;
}

//  依次下载
void parse(int i, NSString *dir) {
    NSString *urlString = [NSString stringWithFormat:@"https://www.634.tv/index.php/vod/show/id/22/page/%d.html", i];
    NSURL *url = [NSURL URLWithString:urlString];
    NSMutableURLRequest *req = [NSMutableURLRequest requestWithURL:url];
    req.timeoutInterval = 30;
    printf("请求：%s\n", urlString.UTF8String);
    [[NSURLSession.sharedSession dataTaskWithRequest:req completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
        if (error == nil && data.length > 0) {
            NSMutableArray<VideoModel *> *models = [VideoModel parseHTMLData:data];
            if (models.count) {
                
                //  写入
                NSString *fileName = [NSString stringWithFormat:@"madou-%d.json", i];
                NSString *jsonPath = [dir stringByAppendingPathComponent:fileName];
                NSMutableArray<NSDictionary *> *dictArray = [VideoModel toDicts:models];
                
                NSError *error = nil;
                NSData *data = [NSJSONSerialization dataWithJSONObject:dictArray options:NSJSONWritingPrettyPrinted error:&error];
                
                [data writeToFile:jsonPath atomically:YES];
                printf("写入：%s\n", dir.UTF8String);
                
                //  继续
                parse(i + 1, dir);
            } else {
                exit(0);
            }
        } else {
            exit(0);
        }
    }] resume];
}

//  合并
void merge(int i, NSMutableArray<NSDictionary *> *array, NSString *dir) {
    NSString *fileName = [NSString stringWithFormat:@"madou-%d.json", i];
    NSString *jsonPath = [dir stringByAppendingPathComponent:fileName];
    if ([NSFileManager.defaultManager fileExistsAtPath:jsonPath]) {
        //  合并
        NSData *data = [NSData dataWithContentsOfFile:jsonPath];
        NSError *error = nil;
        NSArray<NSDictionary *> *list = [NSJSONSerialization JSONObjectWithData:data options:0 error:&error];
        [array addObjectsFromArray:list];
        
        //  继续
        merge(i +  1, array, dir);
    } else {
        //  写入
        NSString *jsonPath = [dir stringByAppendingPathComponent:@"madou-all.json"];
        NSError *error = nil;
        NSData *data = [NSJSONSerialization dataWithJSONObject:array options:NSJSONWritingPrettyPrinted error:&error];
        [data writeToFile:jsonPath atomically:YES];
        //
        exit(0);
    }
}


//MARK: -   测试

void local_parse(NSString *dir) {
    NSString *htmlPath = @"/Users/xisi/Library/CloudStorage/OneDrive-个人/视频爬虫/M3u8Lister/M3u8Lister/test1.html";
    NSData *htmlData = [NSData dataWithContentsOfFile:htmlPath];
    NSMutableArray<VideoModel *> *models = [VideoModel parseHTMLData:htmlData];
    
    NSString *jsonPath = [dir stringByAppendingPathComponent:@"test.json"];
    NSMutableArray<NSDictionary *> *dictArray = [VideoModel toDicts:models];
    
    NSError *error = nil;
    NSData *data = [NSJSONSerialization dataWithJSONObject:dictArray options:NSJSONWritingPrettyPrinted error:&error];
    
    [data writeToFile:jsonPath atomically:YES];
}

//  从html中提取m3u8地址
//  "url": "https:\/\/t21.cdn2020.com\/video\/m3u8\/2023\/02\/15\/dc1be394\/index.m3u8",
NSString* pickup_m3u8(NSString *content) {
    NSError *error = nil;

//    NSString *htmlPath = @"/Users/xisi/Library/CloudStorage/OneDrive-个人/视频爬虫/M3u8Lister/M3u8Lister/test2.html";
//    content = [NSString stringWithContentsOfFile:htmlPath encoding:NSUTF8StringEncoding error:&error];
    
    __block NSString *urlString = nil;
    NSString *pattern = @"http.+.m3u8";
    NSRegularExpression *regexp = [NSRegularExpression regularExpressionWithPattern:pattern options:0 error:&error];
    [regexp enumerateMatchesInString:content options:0 range:NSMakeRange(0, content.length) usingBlock:^(NSTextCheckingResult * _Nullable result, NSMatchingFlags flags, BOOL * _Nonnull stop) {
        urlString = [content substringWithRange:result.range];
    }];
    return urlString;
}

//  7567
void read_file(NSString *dir) {
    NSString *path = [dir stringByAppendingPathComponent:@"madou-all.json"];
    NSError *error = nil;
    NSData *data = [NSData dataWithContentsOfFile:path];
    NSMutableArray<NSDictionary *> *array = [NSJSONSerialization JSONObjectWithData:data options:0 error:&error];
    NSMutableArray<VideoModel *> *models = [VideoModel toModels:array];
    
    /* 拼接 */
    NSMutableString *text = [NSMutableString new];
    for (VideoModel *model in models) {
        if ([model.m3u8 containsString:@"t21.cdn2020.com"] && ![model.m3u8 containsString:@"url_next"]) {
            NSURL *url = [NSURL URLWithString:model.m3u8];
            [text appendString:model.m3u8];
            [text appendString:@"\n"];
        }
    }
    NSString *textPath = @"/Users/xisi/Desktop/video/pendings.txt";
    [text writeToFile:textPath atomically:YES encoding:NSUTF8StringEncoding error:&error];
    
    
    /* 并行下载 */
//    int step = 10;
//    for (int i = 0; i < step; i++) {
//        if (i >= models.count) continue;
//        download_m3u8_file(models, i, step, dir);
//    }
}

void write_file(NSString *dir, NSMutableArray<VideoModel *> *models) {
    NSString *path = [dir stringByAppendingPathComponent:@"madou-all.json"];
    
    NSMutableArray<NSDictionary *> *dictArray = [VideoModel toDicts:models];
    NSError *error = nil;
    NSData *data = [NSJSONSerialization dataWithJSONObject:dictArray options:NSJSONWritingPrettyPrinted error:&error];
    [data writeToFile:path atomically:YES];
}

void download_m3u8_file(NSMutableArray<VideoModel *> *models, int i, int step, NSString *dir) {
    VideoModel *model = models[i];
    if (model.m3u8.length > 0) {
        //  继续
        int next = i + step;
        if (next < models.count) {
            download_m3u8_file(models, next, step, dir);
        }
        return;
    }
    
    NSURL *href = [NSURL URLWithString:model.href];
    NSMutableURLRequest *req = [NSMutableURLRequest requestWithURL:href];
    printf("请求：%d\t%s\n", i, model.href.UTF8String);
    [[NSURLSession.sharedSession dataTaskWithRequest:req completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
        if (error == nil && data.length > 0) {
            NSString *content = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
            NSString *m3u8 = pickup_m3u8(content);
            model.m3u8 = m3u8;
            
            //  写入
            NSInteger count = 0;
            for (VideoModel *m in models) {
                if (m.m3u8.length > 0) {
                    count++;
                }
            }
            if ((count % step == 0 && count > 0) || count == models.count) {
                write_file(dir, models);
                printf(">>>>>> 已写入 %ld 个\n", count);
                
                if (count == models.count) {
                    printf(">>> 写入完成\n");
                    exit(0);
                }
            }
            
            //  继续
            int next = i + step;
            if (next < models.count) {
                download_m3u8_file(models, next, step, dir);
                return;
            }
        } else {
            //  继续
            int next = i + step;
            if (next < models.count) {
                download_m3u8_file(models, next, step, dir);
                return;
            }
        }
    }] resume];
}
