//
//  VideoModel.h
//  HTMLParser
//
//  Created by hanxin on 2023/2/16.
//

#import <Foundation/Foundation.h>

extern const NSString *kBaseURL;

NS_ASSUME_NONNULL_BEGIN

@interface VideoModel : NSObject

@property (nonatomic) NSString *title;
@property (nonatomic) NSString *href;
@property (nonatomic) NSString *image;
@property (nonatomic) NSString *m3u8;

- (NSDictionary *)toDict;

+ (VideoModel *)fromDict:(NSDictionary *)dict;

+ (NSMutableArray<NSDictionary *> *)toDicts:(NSMutableArray<VideoModel *> *)models;

+ (NSMutableArray<VideoModel *> *)toModels:(NSMutableArray<NSDictionary *> *)dictArray;


+ (NSMutableArray<VideoModel *> *)parseHTMLData:(NSData *)data;

@end

NS_ASSUME_NONNULL_END
