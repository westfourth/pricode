//
//  idouLoading.m
//  idou
//
//  Created by mac on 2023/5/18.
//

#import "idouLoading.h"

NSString const *IDDomain = @"https://www.634.tv";
NSString* const IDouLoadingDidLoadHomeNotification = @"IDouLoadingDidLoadHomeNotification";
NSString* const IDouLoadingDidLoadCategoryNotification = @"IDouLoadingDidLoadCategoryNotification";


@implementation idouLoading

+ (instancetype)share {
    static id instance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [[self class] new];
    });
    return instance;
}

- (instancetype)init
{
    self = [super init];
    if (self) {
        self.categories = [NSMutableArray new];
    }
    return self;
}

- (void)load {
    self.categories = [NSMutableArray new];
    
    [IDHomeModel requestWithCompletion:^(NSError * _Nonnull error, IDHomeModel * _Nonnull model) {
        self.homeModel = model;
        [NSNotificationCenter.defaultCenter postNotificationName:IDouLoadingDidLoadHomeNotification object:self.homeModel];
        
        [self requestCateTag:model completion:^{
            [NSNotificationCenter.defaultCenter postNotificationName:IDouLoadingDidLoadCategoryNotification object:self.categories];
        }];
    }];
}

- (void)requestCateTag:(IDHomeModel *)homeModel completion:(void (^)(void))completion {
    dispatch_group_t group = dispatch_group_create();
    dispatch_queue_t queue = dispatch_get_global_queue(0, 0);
    
    for (IDTagModel *tagModel in homeModel.categories) {
        if ([tagModel.tag isEqualToString:@"首页"]) {
            continue;
        }
        
        IDCateTagModel *cateTagModel = [IDCateTagModel new];
        cateTagModel.category = tagModel;
        [self.categories addObject:cateTagModel];
        
        dispatch_group_async(group, queue, ^{
            dispatch_group_enter(group);
            [IDCategoryModel requestWithID:tagModel.ID page:1 completion:^(NSError * _Nonnull error, IDCategoryModel * _Nonnull model) {
                cateTagModel.tags = model.tags;
                dispatch_group_leave(group);
            }];
        });
    }

    dispatch_group_notify(group, queue, ^{
        if (completion) {
            completion();
        }
    });
}

@end
