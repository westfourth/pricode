//
//  IDCateTagModel.h
//  idou
//
//  Created by mac on 2023/5/18.
//

#import <Foundation/Foundation.h>
#import <idouNetwork/idouNetwork.h>

NS_ASSUME_NONNULL_BEGIN

@interface IDCateTagModel : NSObject

@property (nonatomic) IDTagModel *category;                     //!< 大分类
@property (nonatomic) NSMutableArray<IDTagModel *> *tags;       //!< 大分类下的小分类

@end

NS_ASSUME_NONNULL_END
