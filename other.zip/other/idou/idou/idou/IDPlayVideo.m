//
//  IDPlayVideo.m
//  idou
//
//  Created by mac on 2023/5/26.
//

#import "IDPlayVideo.h"
#import <AVKit/AVKit.h>
#import <MBProgressHUD/MBProgressHUD.h>
#import "IDCollector.h"

@implementation IDPlayVideo

+ (void)handleVideoModel:(IDVideoModel *)videoModel viewController:(UIViewController *)viewController completion:(void (^ _Nullable)(void))completion {
    UIAlertController *alertVC = [UIAlertController alertControllerWithTitle:@"请选择" message:nil preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction *play = [UIAlertAction actionWithTitle:@"播放" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        [self playVideoModel:videoModel viewController:viewController];
    }];
    
    //  判断改该视频是否已收藏
    IDVideoModel *matchedVideo = nil;
    for (IDVideoModel *model in IDCollector.share.vidoes) {
        if ([model.title isEqualToString:videoModel.title]) {
            matchedVideo = model;
        }
    }
    
    NSString *title = matchedVideo ? @"取消收藏" : @"收藏";
    UIAlertAction *collect = [UIAlertAction actionWithTitle:title style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        if (matchedVideo) {
            [IDCollector.share.vidoes removeObject:matchedVideo];
        } else {
            [IDCollector.share.vidoes addObject:videoModel];
        }
        if (completion) {
            completion();
        }
    }];
    
    UIAlertAction *cancel = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil];
    
    [alertVC addAction:play];
    [alertVC addAction:collect];
    [alertVC addAction:cancel];
    [viewController presentViewController:alertVC animated:YES completion:nil];
}

/// 播放
+ (void)playVideoModel:(IDVideoModel *)videoModel viewController:(UIViewController *)viewController {
    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:viewController.view animated:YES];
    hud.contentColor = UIColor.whiteColor;
    hud.bezelView.style = MBProgressHUDBackgroundStyleSolidColor;
    hud.bezelView.backgroundColor = UIColor.blackColor;
    
    __weak typeof(viewController) weakVC = viewController;
    [videoModel resolveM3u8URLWithDomain:IDDomain completion:^(NSError *error, NSString *m3u8) {
        [hud hideAnimated:YES];
        NSURL *url = [NSURL URLWithString:m3u8];
        
        AVPlayer *player = [[AVPlayer alloc] initWithURL:url];
        AVPlayerViewController *vc = [AVPlayerViewController new];
        vc.player = player;
        [weakVC presentViewController:vc animated:YES completion:nil];
    }];
}

@end
