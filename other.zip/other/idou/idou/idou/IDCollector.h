//
//  IDCollector.h
//  idou
//
//  Created by mac on 2023/6/2.
//

#import <Foundation/Foundation.h>
#import <idouNetwork/idouNetwork.h>

NS_ASSUME_NONNULL_BEGIN

/// 我的收藏
@interface IDCollector : NSObject

+ (instancetype)share;

@property (nonatomic, nullable) NSMutableArray<IDVideoModel *> *vidoes;

- (void)read;
- (void)write;

@end

NS_ASSUME_NONNULL_END
