//
//  AppDelegate.h
//  idou
//
//  Created by mac on 2023/5/17.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (nonatomic) UIWindow *window;

@end

