//
//  main.m
//  json_fill_m3u8
//
//  Created by xisi on 2023/2/23.
//

#import <Foundation/Foundation.h>
#import <fnmatch.h>

int ussage(void);
int resolve(int argc, const char * argv[], NSMutableArray *subPaths);
NSMutableArray* read_json(NSString *path);
void write_json(NSString *path, NSMutableArray *array);
void fill_json(NSMutableArray *mainJson, NSMutableArray *subJson);


/// 从主json文件中提取m3u8地址，填充到各个子json文件中
int main(int argc, const char * argv[]) {
    @autoreleasepool {
        if (argc == 1) {
            return ussage();
        }
        
        puts(">>> 传入参数");
        for (int i = 1; i < argc; i++) {
            puts(argv[i]);
        }
        puts("<<< 传入参数");
        
        NSString *mainPath = [[NSString alloc] initWithUTF8String:argv[argc - 1]];
        NSMutableArray *subPaths = [NSMutableArray new];
        
        int code = resolve(argc, argv, subPaths);
        if (code != 0) return code;
        
        NSArray *mainJson = read_json(mainPath);
        if (mainJson == nil) return -1;
        
        for (NSString *subPath in subPaths) {
            NSArray *subJson = read_json(subPath);
            if (subJson == nil) continue;
            
            fill_json(mainJson, subJson);
            printf(">>> 正在写入: %s\n", subPath.UTF8String);
            write_json(subPath, subJson);
        }
    }
    return 0;
}

//  解析参数
int resolve(int argc, const char * argv[], NSMutableArray *subPaths) {
    int ch;
    while ((ch = getopt(argc, argv, "a:p:")) != -1) {
        switch (ch) {
            case 'a': {
                puts(optarg);
                NSString *path = [[NSString alloc] initWithUTF8String:optarg];
                [subPaths addObject:path];
            }
                break;
            case 'p': {
                puts(optarg);
                NSString *path = [[NSString alloc] initWithUTF8String:optarg];
                NSString *dir = path.stringByDeletingLastPathComponent;
                NSString *pattern = path.lastPathComponent;
                if (dir.length == 0) {
                    dir = @".";         //  当前目录
                }
                NSLog(@">>> path = %@", path);
                NSLog(@">>> dir = %@", dir);
                NSLog(@">>> pattern = %@", pattern);
                NSArray *array = [NSFileManager.defaultManager subpathsAtPath:dir];
                for (NSString *item in array) {
                    if (fnmatch(pattern.UTF8String, item.UTF8String, 0) == 0) {
                        NSString *itemPath = [dir stringByAppendingPathComponent:item];
                        [subPaths addObject:itemPath];
                    }
                }
            }
                break;
            case '?': {
                return ussage();
            }
                break;
            default:
                puts(">>> default");
                return -1;
                break;
        }
    }
    return 0;
}

//  从mainJson文件中提取m3u8，填充到对应的subJson
void fill_json(NSMutableArray *mainJson, NSMutableArray *subJson) {
    for (NSMutableDictionary *subDict in subJson) {
        for (NSMutableDictionary *mainDict in mainJson) {
            NSString *subTitle = subDict[@"title"];
            NSString *mainTitle = mainDict[@"title"];
            if ([subTitle isEqualToString:mainTitle]) {
                NSString *m3u8 = mainDict[@"m3u8"];
                subDict[@"m3u8"] = m3u8;
            }
        }
    }
}

//  读取josn
NSMutableArray* read_json(NSString *path) {
    NSData *data = [NSData dataWithContentsOfFile:path];
    NSError *error = nil;
    id obj = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:&error];
    if (error) {
        NSLog(@">>> %@ 不是有效的json文件", path);
        return nil;
    }
    
    if (![obj isKindOfClass:NSArray.class]) {
        NSLog(@">>> %s json文件内容应该为数组", path);
    }
    
    return (NSMutableArray *)obj;
}

//  写入josn
void write_json(NSString *path, NSMutableArray *array) {
    NSError *error = nil;
    NSData *data = [NSJSONSerialization dataWithJSONObject:array options:NSJSONWritingPrettyPrinted error:&error];
    if (error) {
        NSLog(@">>> 不是有效的json数据: \n%@", array);
        return;
    }
    [data writeToFile:path atomically:YES];
}

//  用法
int ussage(void) {
    puts("功能:");
    printf("\t从主json文件中提取m3u8地址，并填充到各个子json文件\n");
    puts("用法:");
    printf("\tjson_fill_m3u8 -a [子json文件] ... -p [匹配模式] [主json文件]\n");
    puts("说明:");
    printf("\t-a\t子json文件。\n\t\t多个子json文件时: -a [子json文件1] -a [子json文件2] -a [子json文件3] ...\n");
    printf("\t-p\t匹配的子json文件\n");
    printf("\t\t匹配模式的通配符需要转义，或者匹配模式用单/双引号\n");
    return -1;
}
