//
//  UIScrollView+XSRefresh.h
//  XSRefresh
//
//  Created by xisi on 2022/1/15.
//

#import <UIKit/UIKit.h>
#import "XSRefresh.h"

/// 类型
typedef NS_ENUM(NSUInteger, XSRefreshViewType) {       
    XSRefreshViewTypeHeader,        //!<  顶部
    XSRefreshViewTypeFooter,        //!<  底部
};

NS_ASSUME_NONNULL_BEGIN

/// 下拉刷新、上拉加载更多
@interface UIScrollView (XSRefresh)

/**
 全局设置
 
 @param classOrNib      类型为 Class 或者 UINib*
 */
+ (void)registerClassOrNib:(id)classOrNib forType:(XSRefreshViewType)type;

@property (nullable, nonatomic) __kindof UIView<XSRefresh> *refreshHeader;
@property (nullable, nonatomic) __kindof UIView<XSRefresh> *refreshFooter;

//  注意循环引用
@property (nullable, nonatomic) void (^refreshHeaderBlock)(void);       //  刷新顶部
@property (nullable, nonatomic) void (^refreshFooterBlock)(void);       //  刷新底部

//  采用动效时，beginRefresh会滑动UIScrollView。默认NO。
@property (nonatomic) BOOL refreshAnimated;

@property (readonly, nonatomic) BOOL headerIsRefreshing;
@property (readonly, nonatomic) BOOL footerIsRefreshing;

/*
 在加载中，直接返回；
 已停止刷新，直接返回；
 beginRefresh会触发refreshBlock回调；
 */

- (void)beginRefreshHeader;
- (void)endRefreshHeader;

- (void)beginRefreshFooter;
- (void)endRefreshFooter;

@end

NS_ASSUME_NONNULL_END
