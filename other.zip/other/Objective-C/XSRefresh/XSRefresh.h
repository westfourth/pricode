//
//  XSRefresh.h
//  XSLinkageScrollView
//
//  Created by xisi on 2022/1/14.
//

#import <Foundation/Foundation.h>


NS_ASSUME_NONNULL_BEGIN

/// 刷新控件协议
@protocol XSRefresh <NSObject>

/// 开始刷新
- (void)beginRefreshing;
/// 结束刷新
- (void)endRefreshing;


/* extent 为 距离最终位置的偏移 */

/// 拖拽开始
- (void)dragDidBeganWithExtent:(CGFloat)extent;
/// 拖拽中
- (void)dragDidChangedWithExtent:(CGFloat)extent;
/// 拖拽结束
- (void)dragDidEndedWithExtent:(CGFloat)extent;

/// 到达这个距离 -beginRefresh
+ (CGFloat)refreshExtent;

/// 自身高度
+ (CGFloat)height;

@end


NS_ASSUME_NONNULL_END
