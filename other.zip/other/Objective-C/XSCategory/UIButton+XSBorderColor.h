//
//  UIButton+XSBorderColor.h
//  TextKit
//
//  Created by hanxin on 2022/2/25.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

/// 仅仅设置 borderColor
@interface UIButton (XSBorderColor)

- (void)setBorderColor:(nullable UIColor *)borderColor forState:(UIControlState)state;
- (nullable UIColor *)borderColorForState:(UIControlState)state;

@end

NS_ASSUME_NONNULL_END
