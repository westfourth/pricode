//
//  UIView+XSEdgeSeparator.m
//  TextKit
//
//  Created by xisi on 2022/6/8.
//

#import "UIView+XSEdgeSeparator.h"
#import <objc/runtime.h>

@interface UIView (_XSEdgeSeparator)

/// 使用CAShapeLayer实现，不应该被使用
@property (nullable, nonatomic) CAShapeLayer *edgeSeparatorLayer;

@end


@implementation UIView (XSEdgeSeparator)

/**
 UIButton.layoutSubviews 没有调用 super.layoutSubviews
 */
+ (void)load {
    SEL sel = @selector(layoutSubviews);
    for (Class cls in @[[UIView class], [UIButton class], [UITableView class], [UIProgressView class]]) {
        Method m = class_getInstanceMethod(cls, sel);
        IMP imp0 = method_getImplementation(m);
        IMP imp1 = imp_implementationWithBlock(^void(UIView *self) {
            ((void (*)(UIView *, SEL))imp0)(self, sel);
            if (self.edgeSeparator) {
                [self edgeSeparator_override_layoutSubviews];
            }
        });
        method_setImplementation(m, imp1);
    }
}

- (void)edgeSeparator_override_layoutSubviews {
    UIRectEdge rectEdge = self.edgeSeparator.rectEdge;
    UIEdgeInsets edgeInsets = self.edgeSeparator.edgeInsets;
    CGFloat lineWidth = self.edgeSeparator.lineWidth;
    CGRect bounds = self.bounds;
    UIBezierPath *path = [UIBezierPath bezierPath];

    //  上边
    if ((rectEdge & UIRectEdgeTop) == UIRectEdgeTop) {
        [path moveToPoint:CGPointMake(edgeInsets.left, lineWidth/2)];
        [path addLineToPoint:CGPointMake(bounds.size.width - edgeInsets.right, lineWidth/2)];
    }
    
    //  下边
    if ((rectEdge & UIRectEdgeBottom) == UIRectEdgeBottom) {
        [path moveToPoint:CGPointMake(edgeInsets.left, bounds.size.height - lineWidth/2)];
        [path addLineToPoint:CGPointMake(bounds.size.width - edgeInsets.right, bounds.size.height - lineWidth/2)];
    }
    
    //  左边
    if ((rectEdge & UIRectEdgeLeft) == UIRectEdgeLeft) {
        [path moveToPoint:CGPointMake(lineWidth/2, edgeInsets.top)];
        [path addLineToPoint:CGPointMake(lineWidth/2, bounds.size.height - edgeInsets.bottom)];
    }
    
    //  右边
    if ((rectEdge & UIRectEdgeRight) == UIRectEdgeRight) {
        [path moveToPoint:CGPointMake(bounds.size.width - lineWidth/2, edgeInsets.top)];
        [path addLineToPoint:CGPointMake(bounds.size.width - lineWidth/2, bounds.size.height - edgeInsets.bottom)];
    }
    
    self.edgeSeparatorLayer.path = path.CGPath;
}


//MARK: -   property

- (CAShapeLayer *)edgeSeparatorLayer {
    return objc_getAssociatedObject(self, @selector(edgeSeparatorLayer));
}

- (void)setEdgeSeparatorLayer:(CAShapeLayer *)edgeSeparatorLayer {
    objc_setAssociatedObject(self, @selector(edgeSeparatorLayer), edgeSeparatorLayer, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
}

- (XSEdgeSeparator *)edgeSeparator {
    return objc_getAssociatedObject(self, @selector(edgeSeparator));
}

- (void)setEdgeSeparator:(XSEdgeSeparator *)edgeSeparator {
    if (edgeSeparator) {
        if (self.edgeSeparatorLayer == nil) {
            self.edgeSeparatorLayer = [CAShapeLayer layer];
        }
        //  设置属性
        self.edgeSeparatorLayer.lineWidth = edgeSeparator.lineWidth;
        self.edgeSeparatorLayer.strokeColor = edgeSeparator.lineColor.CGColor;
        self.edgeSeparatorLayer.fillColor = nil;
        [self.layer addSublayer:self.edgeSeparatorLayer];
    } else {
        [self.edgeSeparatorLayer removeFromSuperlayer];
    }
    
    //  标记
    objc_setAssociatedObject(self, @selector(edgeSeparator), edgeSeparator, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    //  刷新
    [self setNeedsLayout];
}

@end



@implementation XSEdgeSeparator

@end
