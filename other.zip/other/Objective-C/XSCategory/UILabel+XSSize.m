//
//  UILabel+XSSize.m
//  AAA
//
//  Created by xisi on 2021/11/18.
//

#import "UILabel+XSSize.h"

@implementation UILabel (XSSize)

- (CGSize)singleLineSize {
    CGSize size = CGSizeZero;
    NSAttributedString *attrText = self.attributedText;
    if (attrText) {     //  NSAttributedString
        size = attrText.size;
    } else {            //  NSString
        NSDictionary *attrs = @{NSFontAttributeName: self.font};
        size = [self.text sizeWithAttributes:attrs];
    }
    return CGSizeMake(ceil(size.width), ceil(size.height));
}

- (CGSize)multiLineSize:(CGFloat)width {
    CGSize size = CGSizeZero;
    NSAttributedString *attrText = self.attributedText;
    if (attrText) {     //  NSAttributedString
        size = [attrText boundingRectWithSize:CGSizeMake(width, 0) options:NSStringDrawingUsesLineFragmentOrigin context:nil].size;
    } else {            //  NSString
        NSDictionary *attrs = @{NSFontAttributeName: self.font};
        size = [self.text boundingRectWithSize:CGSizeMake(width, 0) options:NSStringDrawingUsesLineFragmentOrigin attributes:attrs context:nil].size;
    }
    return CGSizeMake(ceil(size.width), ceil(size.height));
}

@end

