//
//  UITableViewHeaderFooterView+XSVerticalCenter.h
//  TextKit
//
//  Created by hanxin on 2022/4/15.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UITableViewHeaderFooterView (XSVerticalCenter)

/// textLabel 偏移
@property(nonatomic) UIEdgeInsets titleEdgeInsets;

@end

NS_ASSUME_NONNULL_END
