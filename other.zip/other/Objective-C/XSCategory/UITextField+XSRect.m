//
//  UITextField+XSRect.m
//  WebView
//
//  Created by hanxin on 2023/9/20.
//

#import "UITextField+XSRect.h"
#import <objc/runtime.h>

@implementation UITextField (XSRect)

+ (void)load {
    [self load_textRectForBounds];
    [self load_editingRectForBounds];
}

+ (void)load_textRectForBounds {
    Class cls = self.class;
    SEL sel = @selector(textRectForBounds:);
    Method m = class_getInstanceMethod(cls, sel);
    
    IMP imp0 = method_getImplementation(m);
    IMP imp = imp_implementationWithBlock(^CGRect(UITextField *self, CGRect bounds){
        CGRect rect = ((CGRect (*)(UITextField*, SEL, CGRect))imp0)(self, sel, bounds);
        CGRect rect2 = UIEdgeInsetsInsetRect(rect, self.editingTextInsets);
        return rect2;
    });
    
    method_setImplementation(m, imp);
}

+ (void)load_editingRectForBounds {
    Class cls = self.class;
    SEL sel = @selector(editingRectForBounds:);
    Method m = class_getInstanceMethod(cls, sel);
    
    IMP imp0 = method_getImplementation(m);
    IMP imp = imp_implementationWithBlock(^CGRect(UITextField *self, CGRect bounds){
        CGRect rect = ((CGRect (*)(UITextField*, SEL, CGRect))imp0)(self, sel, bounds);
        CGRect rect2 = UIEdgeInsetsInsetRect(rect, self.editingTextInsets);
        return rect2;
    });
    
    method_setImplementation(m, imp);
}


//MARK: -   property

- (UIEdgeInsets)editingTextInsets {
    NSValue *value = objc_getAssociatedObject(self, @selector(editingTextInsets));
    UIEdgeInsets insets = value.UIEdgeInsetsValue;
    return insets;
}

- (void)setEditingTextInsets:(UIEdgeInsets)editingTextInsets {
    NSValue *value = [NSValue valueWithUIEdgeInsets:editingTextInsets];
    objc_setAssociatedObject(self, @selector(editingTextInsets), value, OBJC_ASSOCIATION_COPY);
    [self setNeedsLayout];
}

@end
