//
//  NSMutableAttributedString+Regexp.m
//  Markdown
//
//  Created by xisi on 2021/12/8.
//

#import "NSMutableAttributedString+Regexp.h"

@implementation NSMutableAttributedString (Regexp)

- (void)addAttributes:(NSDictionary<NSAttributedStringKey, id> *)attrs matchPattern:(NSString *)pattern {
    NSError *error = nil;
    NSRegularExpression *regexp = [NSRegularExpression regularExpressionWithPattern:pattern options:0 error:&error];
    [regexp enumerateMatchesInString:self.string options:0 range:NSMakeRange(0, self.length) usingBlock:^(NSTextCheckingResult * _Nullable result, NSMatchingFlags flags, BOOL * _Nonnull stop) {
        [self addAttributes:attrs range:result.range];
    }];
}

@end
