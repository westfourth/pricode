//
//  UIViewController+XSLifeCircle.h
//  TableView
//
//  Created by xisi on 2023/9/11.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@protocol XSControllerLifeCircle <NSObject>
@optional

+ (void)controllerViewDidLoad:(UIViewController *)viewController;

+ (void)controllerDealloc:(UIViewController *)viewController;

+ (void)controller:(UIViewController *)viewController viewWillAppear:(BOOL)animated;

+ (void)controller:(UIViewController *)viewController viewDidAppear:(BOOL)animated;

+ (void)controller:(UIViewController *)viewController viewWillDisappear:(BOOL)animated;

+ (void)controller:(UIViewController *)viewController viewDidDisappear:(BOOL)animated;

@end


@interface UIViewController (XSLifeCircle)

@property (class, nonatomic, nullable) Class<XSControllerLifeCircle> blockDelegate;

@end

NS_ASSUME_NONNULL_END
