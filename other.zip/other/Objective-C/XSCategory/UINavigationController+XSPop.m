//
//  UINavigationController+XSPop.m
//  TextKit
//
//  Created by hanxin on 2022/4/20.
//

#import "UINavigationController+XSPop.h"

@implementation UINavigationController (XSPop)

/// 弹出指定控制器（不包括）之后的所有控制器
- (nullable NSArray<__kindof UIViewController *> *)popToViewControllerClass:(Class)viewControllerClass animated:(BOOL)animated {
    NSArray *array = self.viewControllers;
    UIViewController *destVC = nil;
    for (int i = 0; i < array.count; i++) {
        if ([array[i] isMemberOfClass:viewControllerClass]) {
            destVC = array[i];
            break;
        }
    }
    if (destVC == nil) {
#if DEBUG
        NSException *exception = [NSException exceptionWithName:NSInternalInconsistencyException reason:@"Tried to pop to a view controller that doesn't exist." userInfo:nil];
        [exception raise];
#endif
        return nil;
    }
    return [self popToViewController:destVC animated:animated];
}

/// 弹出指定控制器（包括）之后的所有控制器
- (nullable NSArray<__kindof UIViewController *> *)popViewController:(UIViewController *)viewController animated:(BOOL)animated {
    NSArray *array = self.viewControllers;
    int index = -1;
    for (int i = 0; i < array.count; i++) {
        if (array[i] == viewController) {
            index = i;
            break;
        }
    }
    //
    if (index == 0) {       //  rootViewController
        return nil;
    }
    if (index == -1) {     //  未找到
#if DEBUG
        NSException *exception = [NSException exceptionWithName:NSInternalInconsistencyException reason:@"Tried to pop to a view controller that doesn't exist." userInfo:nil];
        [exception raise];
#endif
        return nil;
    }
    //  remains
    NSRange range = NSMakeRange(0, index);
    NSArray *remains = [array subarrayWithRange:range];
    [self setViewControllers:remains animated:animated];
    //  returns
    range = NSMakeRange(index, array.count - index);
    NSArray *returns = [array subarrayWithRange:range];
    return returns;
}

/// 弹出指定控制器（包括）之后的所有控制器
- (nullable NSArray<__kindof UIViewController *> *)popViewControllerClass:(Class)viewControllerClass animated:(BOOL)animated {
    NSArray *array = self.viewControllers;
    int index = -1;
    for (int i = 0; i < array.count; i++) {
        if ([array[i] isMemberOfClass:viewControllerClass]) {
            index = i;
            break;
        }
    }
    //
    if (index == 0) {       //  rootViewController
        return nil;
    }
    if (index == -1) {     //  未找到
#if DEBUG
        NSException *exception = [NSException exceptionWithName:NSInternalInconsistencyException reason:@"Tried to pop to a view controller that doesn't exist." userInfo:nil];
        [exception raise];
#endif
        return nil;
    }
    //  remains
    NSRange range = NSMakeRange(0, index);
    NSArray *remains = [array subarrayWithRange:range];
    [self setViewControllers:remains animated:animated];
    //  returns
    range = NSMakeRange(index, array.count - index);
    NSArray *returns = [array subarrayWithRange:range];
    return returns;
}

@end
