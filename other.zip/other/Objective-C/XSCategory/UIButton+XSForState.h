//
//  UIButton+XSForState.h
//  Firefox
//
//  Created by hanxin on 2022/01/15.
//  Copyright © 2021 hanxin. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

/**
    setBackgroundColor:forState: 与 setGradientLayer:forState:  同时使用时，哪个后调用就哪个起作用
 
    优点：
    1. CAGradientLayer占用内存小
    2. GPU绘制渲染快
    3. 设置圆角不会触发离屏渲染。
 
    注意：当使用 setBackgroundImage:forState: 并且cornerRadius>0和masksToBounds=YES时，会触发离屏渲染
 */
@interface UIButton (XSForState)

- (void)setBackgroundColor:(nullable UIColor *)color forState:(UIControlState)state;
- (nullable UIColor *)backgroundColorForState:(UIControlState)state;

// MARK: -  CALayer左下角坐标系

- (void)setGradientLayer:(nullable CAGradientLayer *)layer forState:(UIControlState)state;
- (nullable CAGradientLayer *)gradientLayerForState:(UIControlState)state;

@end

NS_ASSUME_NONNULL_END
