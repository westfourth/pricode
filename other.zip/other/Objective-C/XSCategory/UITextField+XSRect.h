//
//  UITextField+XSRect.h
//  WebView
//
//  Created by hanxin on 2023/9/20.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UITextField (XSRect)

@property (nonatomic) UIEdgeInsets editingTextInsets;

@end

NS_ASSUME_NONNULL_END
