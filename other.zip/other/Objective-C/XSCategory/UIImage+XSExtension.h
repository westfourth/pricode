//
//  UIImage+XSExtension.h
//  Firefox
//
//  Created by hanxin on 2022/2/7.
//  Copyright © 2021 hanxin. All rights reserved.
//

#import <UIKit/UIKit.h>

/// 二维码容错率
typedef NS_ENUM(NSUInteger, QRCodeCorrectionLevel) {
    QRCodeCorrectionLevelL,     //!<    7%
    QRCodeCorrectionLevelM,     //!<    15%
    QRCodeCorrectionLevelQ,     //!<    25%
    QRCodeCorrectionLevelH,     //!<    30%
};

NS_ASSUME_NONNULL_BEGIN

/**
    生成的图片大小与屏幕有关，例如size=(100, 100)，@1x屏上就是(100, 100)，@2x屏上就是(200, 200)，@3x屏上就是(300, 300)
 */
@interface UIImage (XSExtension)

/// 保持图片形状不变，将图片纯色化
- (UIImage *)pureWithColor:(UIColor *)color;

- (UIImage *)scaleToSize:(CGSize)size;

/// 空白部分为透明颜色
- (UIImage *)imageWithScale:(CGFloat)scale;

/**
    空白部分为透明颜色
 
    @param  size    包括insets的大小
 */
- (UIImage *)imageWithSize:(CGSize)size edge:(UIEdgeInsets)insets;

+ (UIImage *)imageWithColor:(UIColor *)color size:(CGSize)size;

/**
    @param  vertical    NO - 水平从左到右；YES - 垂直从上到下。
 */
+ (UIImage *)imageWithStartColor:(UIColor *)startColor
                        endColor:(UIColor *)endColor
                            size:(CGSize)size
                        vertical:(BOOL)vertical;

/**
    @param  layer   需要设置frame.size，忽略frame.origin
 */
+ (UIImage *)imageFromGradientLayer:(CAGradientLayer *)layer;

+ (UIImage *)imageFromString:(NSString *)str attributes:(NSDictionary *)attributes;

+ (UIImage *)imageFromAttributedString:(NSAttributedString *)attrStr;

/// 生成二维码
+ (UIImage *)qrImageWithText:(NSString *)text size:(CGSize)size level:(QRCodeCorrectionLevel)level;


/**
    加模糊效果

    @param  blur        模糊度，[0, 2]之间
 */
- (UIImage *)blur:(CGFloat)blur;

@end

NS_ASSUME_NONNULL_END
