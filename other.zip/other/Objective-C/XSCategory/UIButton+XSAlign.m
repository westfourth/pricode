//
//  UIButton+XSAlign.m
//  Test
//
//  Created by hanxin on 2022/01/15.
//  Copyright © 2020 mac. All rights reserved.
//

#import "UIButton+XSAlign.h"
#import <objc/runtime.h>

@implementation UIButton (XSAlign)

+ (void)load {
    Class cls = [UIButton class];
    SEL sel = @selector(layoutSubviews);
    Method m = class_getInstanceMethod(cls, sel);
    IMP imp0 = method_getImplementation(m);
    IMP imp1 = imp_implementationWithBlock(^void(UIButton *self) {
        [self align_override_layoutSubviews];
        ((void (*)(UIButton *, SEL))imp0)(self, sel);
    });
    method_setImplementation(m, imp1);
}

/// 排列
- (void)align_override_layoutSubviews {
    XSAlign type = self.alignType;
    CGFloat space = self.alignSpacing;
    if (type == XSAlignHorizontal && space == 0) {
        return;
    }
    
    CGSize imageSize = [self imageForState:self.state].size;
    CGFloat maxWidth = self.bounds.size.width - imageSize.width;
    CGSize titleSize = [self titleSizeForState_:self.state maxWidth:maxWidth];
    
    switch (type) {
        case XSAlignHorizontal:
            self.imageEdgeInsets = UIEdgeInsetsMake(0, -space/2.0,
                                                    0, space/2.0);
            self.titleEdgeInsets = UIEdgeInsetsMake(0, space/2.0,
                                                    0, -space/2.0);
            break;
        case XSAlignHorizontalReverse:
            self.imageEdgeInsets = UIEdgeInsetsMake(0, titleSize.width + space/2.0,
                                                    0, -titleSize.width - space/2.0);
            self.titleEdgeInsets = UIEdgeInsetsMake(0, -imageSize.width - space/2.0,
                                                    0, imageSize.width + space/2.0);
            break;
        case XSAlignVertical:
            self.imageEdgeInsets = UIEdgeInsetsMake(-titleSize.height/2.0 - space/2.0, titleSize.width/2.0,
                                                    titleSize.height/2.0 + space/2.0, -titleSize.width/2.0);
            self.titleEdgeInsets = UIEdgeInsetsMake(imageSize.height/2.0 + space/2.0, -imageSize.width/2.0,
                                                    -imageSize.height/2.0 - space/2.0, imageSize.width/2.0);
            break;
        case XSAlignVerticalReverse:
            self.imageEdgeInsets = UIEdgeInsetsMake(titleSize.height/2.0 + space/2.0, titleSize.width/2.0,
                                                    -titleSize.height/2.0 - space/2.0, -titleSize.width/2.0);
            self.titleEdgeInsets = UIEdgeInsetsMake(-imageSize.height/2.0 - space/2.0, -imageSize.width/2.0,
                                                    imageSize.height/2.0 + space/2.0, imageSize.width/2.0);
            break;
        default:
            break;
    }
}

/// 获取文字大小。后缀下划线，防止同名方法。
- (CGSize)titleSizeForState_:(UIControlState)state maxWidth:(CGFloat)maxWidth {
    NSString *title = [self titleForState:state];
    NSAttributedString *attrTitle = nil;
    NSDictionary *fontAttrs = @{NSFontAttributeName:self.titleLabel.font};
    if (title != nil) {             //  正常文字
        attrTitle = [[NSAttributedString alloc] initWithString:title attributes:fontAttrs];
    } else {                        //  属性文字
        attrTitle = [self attributedTitleForState:state];
        if (attrTitle != nil) {         //  属性文字
            __block UIFont *font = nil;
            [attrTitle enumerateAttribute:NSFontAttributeName inRange:NSMakeRange(0, attrTitle.length) options:0 usingBlock:^(id  _Nullable value, NSRange range, BOOL * _Nonnull stop) {
                if (value != nil) {
                    font = value;
                    *stop = YES;
                }
            }];
            if (font == nil) {      //  没有设置字体
                NSMutableAttributedString *attrText = [[NSMutableAttributedString alloc] initWithAttributedString:attrTitle];
                [attrText addAttributes:fontAttrs range:NSMakeRange(0, attrText.length)];
                attrTitle = attrText;
            }
        }
    }
    
    if (attrTitle == nil) {
        return CGSizeZero;
    }
    
    CGRect rect = [attrTitle boundingRectWithSize:CGSizeMake(maxWidth, CGFLOAT_MAX) options:NSStringDrawingUsesLineFragmentOrigin context:nil];
    CGSize size = CGSizeMake(ceil(rect.size.width), ceil(rect.size.height));
    return size;
}


//MARK: -   property

- (XSAlign)alignType {
    return [objc_getAssociatedObject(self, @selector(alignType)) unsignedIntegerValue];
}

- (void)setAlignType:(XSAlign)verticalAlign {
    objc_setAssociatedObject(self, @selector(alignType), @(verticalAlign), OBJC_ASSOCIATION_ASSIGN);
    [self setNeedsLayout];
}

- (CGFloat)alignSpacing {
    return [objc_getAssociatedObject(self, @selector(alignSpacing)) floatValue];
}

- (void)setAlignSpacing:(CGFloat)verticalAlignSpacing {
    objc_setAssociatedObject(self, @selector(alignSpacing), @(verticalAlignSpacing), OBJC_ASSOCIATION_ASSIGN);
    [self setNeedsLayout];
}

@end
