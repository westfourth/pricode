//
//  NSURLComponents+XSQuery.h
//  Landscape
//
//  Created by xisi on 2024/6/2.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSURLComponents (XSQuery)

/// 对URL的查询部分进行增删改操作
- (void)setValue:(NSString * _Nullable)value forName:(NSString *)name;

@end

NS_ASSUME_NONNULL_END
