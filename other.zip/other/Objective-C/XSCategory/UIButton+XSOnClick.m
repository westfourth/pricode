//
//  UIButton+XSOnClick.m
//  TableView
//
//  Created by xisi on 2023/9/26.
//

#import "UIButton+XSOnClick.h"
#import <objc/runtime.h>

@implementation UIButton (XSOnClick)

//MARK: -

- (void (^)(UIButton * _Nonnull))onClick {
    return objc_getAssociatedObject(self, @selector(onClick));
}

- (void)setOnClick:(void (^)(UIButton * _Nonnull))onClick {
    objc_setAssociatedObject(self, @selector(onClick), onClick, OBJC_ASSOCIATION_RETAIN);
    
    id target = UIButton.class;
    SEL sel = @selector(onClickButton:);
    UIControlEvents event = UIControlEventTouchUpInside;
    
    [self removeTarget:target action:sel forControlEvents:event];
    [self addTarget:target action:sel forControlEvents:event];
}

+ (void)onClickButton:(UIButton *)button {
    if (button.onClick) {
        button.onClick(button);
    }
}

@end
