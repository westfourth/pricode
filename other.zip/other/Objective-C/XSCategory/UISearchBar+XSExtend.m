//
//  UISearchBar+XSExtend.m
//  TextKit
//
//  Created by hanxin on 2022/5/24.
//

#import "UISearchBar+XSExtend.h"
#import <objc/runtime.h>

@implementation UISearchBar (XSExtend)

+ (void)load {
    Class cls = [self class];
    SEL sel = @selector(layoutSubviews);
    Method m = class_getInstanceMethod(cls, sel);
    IMP imp0 = method_getImplementation(m);
    IMP imp1 = imp_implementationWithBlock(^void(UISearchBar *self) {
        ((void (*)(UISearchBar *, SEL))imp0)(self, sel);
        if (self.textColor || self.font || self.attributedPlaceholder) {
            [self extend_override_layoutSubviews];
        }
    });
    method_setImplementation(m, imp1);
}

- (void)extend_override_layoutSubviews {
    UITextField * _Nullable textField = nil;
    [[self class] extend_find_UITextField:self textField:&textField];
    if (textField == nil) {
        return;
    }
    
    //
    if (self.textColor) {
        textField.textColor = self.textColor;
    }
    if (self.font) {
        textField.font = self.font;
    }
    if (self.attributedPlaceholder) {
        textField.attributedPlaceholder = self.attributedPlaceholder;
    }
}

//  递归寻找UITextField
+ (void)extend_find_UITextField:(UIView *)view textField:(UITextField * _Nullable *)textField {
    if ([view isKindOfClass:[UITextField class]]) {
        *textField = (UITextField *)view;
        return;
    }
    for (UIView *aView in view.subviews) {
        [self extend_find_UITextField:aView textField:textField];
    }
}

// MARK: -  property

- (UIColor *)textColor {
    return objc_getAssociatedObject(self, @selector(textColor));
}

- (void)setTextColor:(UIColor *)textColor {
    objc_setAssociatedObject(self, @selector(textColor), textColor, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    [self setNeedsLayout];
}

- (UIFont *)font {
    return objc_getAssociatedObject(self, @selector(font));
}

- (void)setFont:(UIFont *)font {
    objc_setAssociatedObject(self, @selector(font), font, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    [self setNeedsLayout];
}

- (NSAttributedString *)attributedPlaceholder {
    return objc_getAssociatedObject(self, @selector(attributedPlaceholder));
}

- (void)setAttributedPlaceholder:(NSAttributedString *)attributedPlaceholder {
    objc_setAssociatedObject(self, @selector(attributedPlaceholder), attributedPlaceholder, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    [self setNeedsLayout];
}

@end
