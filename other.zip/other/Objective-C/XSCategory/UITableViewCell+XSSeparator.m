//
//  UITableViewCell+XSSeparator.m
//  TextKit
//
//  Created by hanxin on 2022/1/29.
//

#import "UITableViewCell+XSSeparator.h"
#import <objc/runtime.h>

@implementation UITableViewCell (XSSeparator)

+ (void)load {
    Class cls = [UITableViewCell class];
    SEL sel = @selector(layoutSubviews);
    Method m = class_getInstanceMethod(cls, sel);
    IMP imp0 = method_getImplementation(m);
    IMP imp1 = imp_implementationWithBlock(^void(UITableViewCell *self) {
        ((void (*)(UITableViewCell *, SEL))imp0)(self, sel);
        if (!UIEdgeInsetsEqualToEdgeInsets(self.separatorInset0, UIEdgeInsetsZero)) {
            [self separator0_override_layoutSubviews];
        }
        if (!UIEdgeInsetsEqualToEdgeInsets(self.separatorInset2, UIEdgeInsetsZero)) {
            [self separator2_override_layoutSubviews];
        }
    });
    method_setImplementation(m, imp1);
}

- (void)separator0_override_layoutSubviews {
    for (UIView *view in self.subviews) {
        if ([view isKindOfClass:NSClassFromString(@"_UITableViewCellSeparatorView")]) {
            if (view.frame.origin.y == 0) {
                CGFloat height = 1 / [UIScreen mainScreen].scale;
                CGRect rect = CGRectMake(0, 0, CGRectGetWidth(self.bounds), height);
                rect = UIEdgeInsetsInsetRect(rect, self.separatorInset0);
                view.frame = rect;
            }
        }
    }
}

- (void)separator2_override_layoutSubviews {
    for (UIView *view in self.subviews) {
        if ([view isKindOfClass:NSClassFromString(@"_UITableViewCellSeparatorView")]) {
            if (view.frame.origin.y == 0) {
                continue;
            }
            CGFloat height = 1 / [UIScreen mainScreen].scale;
            CGRect rect = CGRectMake(0, CGRectGetMaxY(self.bounds) - height, CGRectGetWidth(self.bounds), height);
            rect = UIEdgeInsetsInsetRect(rect, self.separatorInset2);
            view.frame = rect;
        }
    }
}


// MARK: -  property

- (UIEdgeInsets)separatorInset0 {
    NSValue *value = objc_getAssociatedObject(self, @selector(separatorInset0));
    return [value UIEdgeInsetsValue];
}

- (void)setSeparatorInset0:(UIEdgeInsets)separatorInset0 {
    NSValue *value = [NSValue valueWithUIEdgeInsets:separatorInset0];
    objc_setAssociatedObject(self, @selector(separatorInset0), value, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
}

- (UIEdgeInsets)separatorInset2 {
    NSValue *value = objc_getAssociatedObject(self, @selector(separatorInset2));
    return [value UIEdgeInsetsValue];
}

- (void)setSeparatorInset2:(UIEdgeInsets)separatorInset2 {
    NSValue *value = [NSValue valueWithUIEdgeInsets:separatorInset2];
    objc_setAssociatedObject(self, @selector(separatorInset2), value, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
}

@end
