//
//  UIButton+XSBorderColor.m
//  TextKit
//
//  Created by hanxin on 2022/2/25.
//

#import "UIButton+XSBorderColor.h"
#import <objc/runtime.h>

@implementation UIButton (XSBorderColor)

+ (void)load {
    Class cls = [UIButton class];
    SEL sel = @selector(layoutSubviews);
    Method m = class_getInstanceMethod(cls, sel);
    IMP imp0 = method_getImplementation(m);
    IMP imp1 = imp_implementationWithBlock(^void(UIButton *self) {
        UIColor *color = [self borderColorForState:self.state];
        if (color != nil) {
            self.layer.borderColor = color.CGColor;
        }
        ((void (*)(UIButton *, SEL))imp0)(self, sel);
    });
    method_setImplementation(m, imp1);
}

- (void)setBorderColor:(nullable UIColor *)borderColor forState:(UIControlState)state {
    const void *key = [UIButton borderColorKeyForControlState:state];
    objc_setAssociatedObject(self, key, borderColor, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
}

- (nullable UIColor *)borderColorForState:(UIControlState)state {
    const void *key = [UIButton borderColorKeyForControlState:state];
    return objc_getAssociatedObject(self, key);
}

/**
    key 所在的内存地址必须一致。以下就不行：
    @code
        const void *key = [NSString stringWithFormat:@"kUIControlState%ld", state].UTF8String;
    @endcode
    因为每次调用，key的地址不一样。
 */
+ (const void *)borderColorKeyForControlState:(UIControlState)state {
    NSString *key = [NSString stringWithFormat:@"UIButton+XSBorderColor-%ld", (long)state];
    SEL sel = sel_getUid(key.UTF8String);
    return sel;
}

@end
