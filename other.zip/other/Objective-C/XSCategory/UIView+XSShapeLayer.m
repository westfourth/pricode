//
//  UIView+XSShapeLayer.m
//  TextKit
//
//  Created by xisi on 2022/5/12.
//

#import "UIView+XSShapeLayer.h"
#import <objc/runtime.h>

@implementation UIView (XSShapeLayer)

/**
 UIButton.layoutSubviews 没有调用 super.layoutSubviews。同样还有UITableView、UIProgressView
 */
+ (void)load {
    SEL sel = @selector(layoutSubviews);
    for (Class cls in @[[UIView class], [UIButton class], [UITableView class], [UIProgressView class]]) {
        Method m = class_getInstanceMethod(cls, sel);
        IMP imp0 = method_getImplementation(m);
        IMP imp1 = imp_implementationWithBlock(^void(UIView *self) {
            ((void (*)(UIView *, SEL))imp0)(self, sel);
            if (self.shapeLayerBlock) {
                [self shapeLayer_override_layoutSubviews];
            }
        });
        method_setImplementation(m, imp1);
    }
}

- (void)shapeLayer_override_layoutSubviews {
    Class cls = object_getClass(self.layer);
    if (cls != [CAShapeLayer class]) {
        object_setClass(self.layer, [CAShapeLayer class]);
    }
    CAShapeLayer *layer = (CAShapeLayer *)self.layer;
    self.shapeLayerBlock(layer, self.bounds);
}

//MARK: -   property


- (void (^)(CAShapeLayer * _Nonnull, CGRect))shapeLayerBlock {
    return objc_getAssociatedObject(self, @selector(shapeLayerBlock));
}

- (void)setShapeLayerBlock:(void (^)(CAShapeLayer * _Nonnull, CGRect))shapeLayerBlock {
    objc_setAssociatedObject(self, @selector(shapeLayerBlock), shapeLayerBlock, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    [self setNeedsLayout];
}

@end
