//
//  UIButton+XSBlock.h
//  XSMultiSection
//
//  Created by xisi on 2023/7/24.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UIButton (XSBlock)

@property (nullable, nonatomic) void (^onClick)(UIButton *button);

@end

NS_ASSUME_NONNULL_END
