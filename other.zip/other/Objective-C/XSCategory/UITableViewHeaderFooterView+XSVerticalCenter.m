//
//  UITableViewHeaderFooterView+XSVerticalCenter.m
//  TextKit
//
//  Created by hanxin on 2022/4/15.
//

#import "UITableViewHeaderFooterView+XSVerticalCenter.h"
#import <objc/runtime.h>

@implementation UITableViewHeaderFooterView (XSVerticalCenter)

+ (void)load {
    //  iOS 12 会进入死循环
    if (@available(iOS 13, *)) {
        Class cls = [UITableViewHeaderFooterView class];
        SEL sel = @selector(layoutSubviews);
        Method m = class_getInstanceMethod(cls, sel);
        IMP imp0 = method_getImplementation(m);
        IMP imp1 = imp_implementationWithBlock(^void(UITableViewHeaderFooterView *self) {
            ((void (*)(UITableViewHeaderFooterView *, SEL))imp0)(self, sel);
            if (!UIEdgeInsetsEqualToEdgeInsets(self.titleEdgeInsets, UIEdgeInsetsZero)) {
                [self verticalCenter_override_layoutSubviews];
            }
        });
        method_setImplementation(m, imp1);
    }
}

- (void)verticalCenter_override_layoutSubviews {
    NSString *text = self.textLabel.text;
    CGFloat left = 14, right = 14, bottom = 6;
    CGFloat width = self.bounds.size.width - left - right;
    CGRect rect = [text boundingRectWithSize:CGSizeMake(width, 0) options:NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName: self.textLabel.font} context:nil];
    CGFloat height = ceil(rect.size.height);
    CGRect frame = CGRectMake(left, self.bounds.size.height - bottom - height, width, height);
    //
    frame = UIEdgeInsetsInsetRect(frame, self.titleEdgeInsets);
    /* iOS 12 会进入死循环，原因：self.textLabel.frame触发layoutSubviews */
    self.textLabel.frame = frame;
}

// MARK: -  property

- (UIEdgeInsets)titleEdgeInsets {
    NSValue *value = objc_getAssociatedObject(self, @selector(titleEdgeInsets));
    return [value UIEdgeInsetsValue];
}

- (void)setTitleEdgeInsets:(UIEdgeInsets)titleEdgeInsets {
    NSValue *value = [NSValue valueWithUIEdgeInsets:titleEdgeInsets];
    objc_setAssociatedObject(self, @selector(titleEdgeInsets), value, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
}

@end
