//
//  UIImage+XSExtension.m
//  Firefox
//
//  Created by hanxin on 2022/2/7.
//  Copyright © 2021 hanxin. All rights reserved.
//

#import "UIImage+XSExtension.h"
#import <Accelerate/Accelerate.h>

@implementation UIImage (XSExtension)

/// 保持图片形状不变，将图片纯色化
- (UIImage *)pureWithColor:(UIColor *)color {
    CALayer *layer = [CALayer layer];
    layer.frame = CGRectMake(0, 0, self.size.width, self.size.height);
    layer.backgroundColor = color.CGColor;
    
    //  mask
    CALayer *maskLayer = [CALayer layer];
    maskLayer.frame = layer.bounds;
    maskLayer.contents = (__bridge id)self.CGImage;
    layer.mask = maskLayer;
    
    UIGraphicsBeginImageContextWithOptions(layer.bounds.size, NO, 0.0);
    CGContextRef context = UIGraphicsGetCurrentContext();
    [layer renderInContext:context];
    UIImage *pureImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    return pureImage;
}

- (UIImage *)scaleToSize:(CGSize)size {
    UIGraphicsBeginImageContextWithOptions(size, NO, 0);
    [self drawInRect:(CGRect){.size = size}];
    UIImage *scaleImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return scaleImage;
}

- (UIImage *)imageWithScale:(CGFloat)scale {
    CGSize size = self.size;
    UIGraphicsBeginImageContextWithOptions(size, NO, 0);
    
    CGSize size2 = CGSizeMake(size.width * scale, size.height * scale);
    CGPoint point2 = CGPointMake((size.width - size2.width) / 2,
                                 (size.height - size2.height) / 2);
    
    [self drawInRect:(CGRect){.origin = point2, .size = size2}];
    UIImage *scaleImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return scaleImage;
}

- (UIImage *)imageWithSize:(CGSize)size edge:(UIEdgeInsets)insets {
    UIGraphicsBeginImageContextWithOptions(size, NO, 0);
    
    CGSize size2 = CGSizeMake(size.width - insets.left - insets.right, size.height - insets.top - insets.bottom);
    CGPoint point2 = CGPointMake(insets.left, insets.top);
    
    [self drawInRect:(CGRect){.origin = point2, .size = size2}];
    UIImage *scaleImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return scaleImage;
}

+ (UIImage *)imageWithColor:(UIColor *)color size:(CGSize)size {
    UIGraphicsBeginImageContextWithOptions(size, NO, 0);
    UIBezierPath *bezierPath = [UIBezierPath bezierPathWithRect:(CGRect){.size = size}];
    [color set];
    [bezierPath fill];
    UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return image;
}

+ (UIImage *)imageWithStartColor:(UIColor *)startColor
                        endColor:(UIColor *)endColor
                            size:(CGSize)size
                        vertical:(BOOL)vertical {
    CAGradientLayer *layer = [CAGradientLayer layer];
    layer.frame = (CGRect){.size = size};
    layer.colors = @[(__bridge id)startColor.CGColor, (__bridge id)endColor.CGColor];
    if (vertical) {     //  layer左下角坐标系
//        layer.startPoint = CGPointMake(0.5, 1);
//        layer.endPoint = CGPointMake(0.5, 0);
    } else {
        layer.startPoint = CGPointMake(0, 0.5);
        layer.endPoint = CGPointMake(1, 0.5);
    }
    UIImage *image = [self imageFromGradientLayer:layer];
    return image;
}

+ (UIImage *)imageFromGradientLayer:(CAGradientLayer *)layer {
    UIGraphicsBeginImageContextWithOptions(layer.frame.size, NO, 0);
    CGContextRef context = UIGraphicsGetCurrentContext();
    [layer renderInContext:context];
    UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return image;
}

+ (UIImage *)imageFromString:(NSString *)str attributes:(NSDictionary *)attributes {
    NSAttributedString *attrStr = [[NSAttributedString alloc] initWithString:str attributes:attributes];
    return [self imageFromAttributedString:attrStr];
}

+ (UIImage *)imageFromAttributedString:(NSAttributedString *)attrStr {
    CGSize size = attrStr.size;
    size = CGSizeMake(ceil(size.width), ceil(size.height));
    UIGraphicsBeginImageContextWithOptions(size, NO, 0);
    [attrStr drawInRect:(CGRect){.size = size}];
    UIImage *scaleImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return scaleImage;
}


//MARK: -   二维码

/// 生成二维码
+ (UIImage *)qrImageWithText:(NSString *)text size:(CGSize)size level:(QRCodeCorrectionLevel)level {
    CIFilter *filter = [CIFilter filterWithName:@"CIQRCodeGenerator"];
    [filter setDefaults];
    
    NSData *data = [text dataUsingEncoding:NSISOLatin1StringEncoding];
    [filter setValue:data forKey:@"inputMessage"];
    NSString *levelText = [self qrCodeCorrectionLevelText:level];
    [filter setValue:levelText forKey:@"inputCorrectionLevel"];
    
    CIImage *ciImage = filter.outputImage;
    UIImage *image = [self nonInterpolatedImage:ciImage size:size];
    return image;
}

+ (UIImage *)nonInterpolatedImage:(CIImage *)ciImage size:(CGSize)size {
    CGRect extent = CGRectIntegral(ciImage.extent);
    CGFloat scale = MIN(size.width / extent.size.width,
                        size.height / extent.size.height);
    scale = scale * [UIScreen mainScreen].scale;
    CGFloat width = extent.size.width * scale;
    CGFloat height = extent.size.height * scale;
    //
    CGColorSpaceRef colorSpace = CGColorSpaceCreateDeviceGray();
    CGContextRef bitmapContext = CGBitmapContextCreate(NULL, (int)width, (int)height, 8, 0, colorSpace, kCGImageAlphaNone);
    
    CIContext *ciContext = [CIContext contextWithOptions:nil];
    CGImageRef cgImage = [ciContext createCGImage:ciImage fromRect:extent];
    
    CGContextSetInterpolationQuality(bitmapContext, kCGInterpolationNone);
    CGContextScaleCTM(bitmapContext, scale, scale);
    CGContextDrawImage(bitmapContext, extent, cgImage);
    
    CGImageRef scaledCGImage = CGBitmapContextCreateImage(bitmapContext);
    UIImage *uiImage = [UIImage imageWithCGImage:scaledCGImage];
    
    CGColorSpaceRelease(colorSpace);
    CGContextRelease(bitmapContext);
    CGImageRelease(cgImage);
    CGImageRelease(scaledCGImage);
    
    return uiImage;
}

+ (NSString *)qrCodeCorrectionLevelText:(QRCodeCorrectionLevel)level {
    switch (level) {
        case QRCodeCorrectionLevelL:
            return @"L";
            break;
        case QRCodeCorrectionLevelQ:
            return @"Q";
            break;
        case QRCodeCorrectionLevelH:
            return @"H";
            break;
        default:
            return @"M";
            break;
    }
}


/**
    加模糊效果

    @param  blur        模糊度，[0, 2]之间
 */
- (UIImage *)blur:(CGFloat)blur {
    //模糊度,
    if ((blur < 0) || (blur > 2)) {
        blur = 1;
    }
    
    //boxSize必须大于0
    int boxSize = (int)(blur * 100);
    boxSize -= (boxSize % 2) + 1;
    NSLog(@"boxSize:%i",boxSize);
    //图像处理
    CGImageRef img = self.CGImage;
    
    //图像缓存,输入缓存，输出缓存
    vImage_Buffer inBuffer, outBuffer;
    vImage_Error error;
    //像素缓存
    void *pixelBuffer;
    
    //数据源提供者，Defines an opaque type that supplies Quartz with data.
    CGDataProviderRef inProvider = CGImageGetDataProvider(img);
    // provider’s data.
    CFDataRef inBitmapData = CGDataProviderCopyData(inProvider);
    
    //宽，高，字节/行，data
    inBuffer.width = CGImageGetWidth(img);
    inBuffer.height = CGImageGetHeight(img);
    inBuffer.rowBytes = CGImageGetBytesPerRow(img);
    inBuffer.data = (void*)CFDataGetBytePtr(inBitmapData);
    
    //像数缓存，字节行*图片高
    pixelBuffer = malloc(CGImageGetBytesPerRow(img) * CGImageGetHeight(img));
    
    outBuffer.data = pixelBuffer;
    outBuffer.width = CGImageGetWidth(img);
    outBuffer.height = CGImageGetHeight(img);
    outBuffer.rowBytes = CGImageGetBytesPerRow(img);
    
    // 第三个中间的缓存区,抗锯齿的效果
    void *pixelBuffer2 = malloc(CGImageGetBytesPerRow(img) * CGImageGetHeight(img));
    vImage_Buffer outBuffer2;
    outBuffer2.data = pixelBuffer2;
    outBuffer2.width = CGImageGetWidth(img);
    outBuffer2.height = CGImageGetHeight(img);
    outBuffer2.rowBytes = CGImageGetBytesPerRow(img);
    
    //将一个隐式的M×N区域颗粒和具有箱式滤波器的效果的ARGB8888源图像进行卷积运算得到作用区域。
    error = vImageBoxConvolve_ARGB8888(&inBuffer, &outBuffer2, NULL, 0, 0, boxSize, boxSize, NULL, kvImageEdgeExtend);
    error = vImageBoxConvolve_ARGB8888(&outBuffer2, &inBuffer, NULL, 0, 0, boxSize, boxSize, NULL, kvImageEdgeExtend);
    error = vImageBoxConvolve_ARGB8888(&inBuffer, &outBuffer, NULL, 0, 0, boxSize, boxSize, NULL, kvImageEdgeExtend);
    
    
    if (error) {
        NSLog(@"error from convolution %ld", error);
    }
    
    //    NSLog(@"字节组成部分：%zu",CGImageGetBitsPerComponent(img));
    //颜色空间DeviceRGB
    CGColorSpaceRef colorSpace = CGColorSpaceCreateDeviceRGB();
    //用图片创建上下文,CGImageGetBitsPerComponent(img),7,8
    CGContextRef ctx = CGBitmapContextCreate(outBuffer.data,
                                             outBuffer.width,
                                             outBuffer.height,
                                             8,
                                             outBuffer.rowBytes,
                                             colorSpace,
                                             CGImageGetBitmapInfo(self.CGImage));
    
    //根据上下文，处理过的图片，重新组件
    CGImageRef imageRef = CGBitmapContextCreateImage (ctx);
    UIImage *returnImage = [UIImage imageWithCGImage:imageRef];
    
    //clean up
    CGContextRelease(ctx);
    CGColorSpaceRelease(colorSpace);
    
    free(pixelBuffer);
    free(pixelBuffer2);
    CFRelease(inBitmapData);
    
    CGImageRelease(imageRef);
    
    return returnImage;
}

@end
