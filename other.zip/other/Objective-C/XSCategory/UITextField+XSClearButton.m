//
//  UITextField+XSClearButton.m
//  TextKit
//
//  Created by hanxin on 2022/1/28.
//

#import "UITextField+XSClearButton.h"
#import <objc/runtime.h>

@implementation UITextField (XSClearButton)

+ (void)load {
    [self load_clearButton_layoutSubviews];
    [self load_clearButton_clearButtonRectForBounds];
}


//MARK: -   layoutSubviews

+ (void)load_clearButton_layoutSubviews {
    Class cls = self.class;
    SEL sel = @selector(layoutSubviews);
    Method m = class_getInstanceMethod(cls, sel);
    IMP imp0 = method_getImplementation(m);
    IMP imp1 = imp_implementationWithBlock(^void(UITextField *self) {
        ((void (*)(UITextField *, SEL))imp0)(self, sel);
        if (self.clearButtonImage) {
            [self clearButton_override_layoutSubviews];
        }
    });
    method_setImplementation(m, imp1);
}

- (void)clearButton_override_layoutSubviews {
    for (UIView *view in self.subviews) {
        if ([view isKindOfClass:NSClassFromString(@"_UITextFieldClearButton")]) {
            UIButton *button = (UIButton *)view;
            [button setImage:self.clearButtonImage forState:UIControlStateNormal];
            break;
        }
    }
}


//MARK: -   clearButtonRectForBounds:

+ (void)load_clearButton_clearButtonRectForBounds {
    Class cls = self.class;
    SEL sel = @selector(clearButtonRectForBounds:);
    Method m = class_getInstanceMethod(cls, sel);
    IMP imp0 = method_getImplementation(m);
    IMP imp1 = imp_implementationWithBlock(^CGRect(UITextField *self, CGRect bounds) {
        CGRect rect = ((CGRect (*)(UITextField *, SEL, CGRect))imp0)(self, sel, bounds);
        if (self.clearButtonRectForBounds) {
            rect = self.clearButtonRectForBounds(bounds);
        }
        return rect;
    });
    method_setImplementation(m, imp1);
}


// MARK: -  property

- (UIImage *)clearButtonImage {
    return objc_getAssociatedObject(self, @selector(clearButtonImage));
}

- (void)setClearButtonImage:(UIImage *)clearImage {
    objc_setAssociatedObject(self, @selector(clearButtonImage), clearImage, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
}

- (CGRect (^)(CGRect))clearButtonRectForBounds {
    return objc_getAssociatedObject(self, @selector(clearButtonRectForBounds));
}

- (void)setClearButtonRectForBounds:(CGRect (^)(CGRect))clearButtonRectForBounds {
    objc_setAssociatedObject(self, @selector(clearButtonRectForBounds), clearButtonRectForBounds, OBJC_ASSOCIATION_RETAIN);
}

@end
