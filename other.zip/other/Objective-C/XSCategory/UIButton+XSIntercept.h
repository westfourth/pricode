//
//  UIButton+XSIntercept.h
//  TableView
//
//  Created by xisi on 2023/9/6.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

/**
    @warning    不能识别具体的UIControlEvents
    @warning    如果一个UIButton被添加多个事件，那么会回调多次
 */
@interface UIButton (XSIntercept)

@property (class, nullable, nonatomic) NSMutableArray<void (^)(UIButton *)> *intercepters;

+ (void)addIntercepter:(void (^)(UIButton *))block;
+ (void)removeIntercepter:(void (^)(UIButton *))block;

@end

NS_ASSUME_NONNULL_END
