//
//  UITextView+XSBlock.h
//  XSMultiSection
//
//  Created by xisi on 2023/7/24.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

/**
    如果实现了对应的`delegate`方法，那么对应的`block`回调将不再生效。
 */
@interface UITextView (XSBlock) <UITextViewDelegate>

//@property(nullable, nonatomic, weak) id<UITextViewDelegate> originDelegate;

//  - textViewShouldBeginEditing:
@property (nullable, nonatomic) BOOL (^shouldBeginEditing)(UITextView *textView);
//  - textViewDidBeginEditing:
@property (nullable, nonatomic) void (^didBeginEditing)(UITextView *textView);
//  - textViewShouldEndEditing:
@property (nullable, nonatomic) BOOL (^shouldEndEditing)(UITextView *textView);
//  - textViewDidEndEditing:
@property (nullable, nonatomic) void (^didEndEditing)(UITextView *textView);

//  - textView:shouldChangeTextInRange:replacementText:
@property (nullable, nonatomic) BOOL (^shouldChangeText)(UITextView *textView, NSRange range, NSString *replacement);
//  - textViewDidChange:
@property (nullable, nonatomic) void (^didChangeText)(UITextView *textView);

@end

NS_ASSUME_NONNULL_END
