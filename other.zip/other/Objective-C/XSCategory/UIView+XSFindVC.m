//
//  UIView+XSFindVC.m
//  PromiseKit
//
//  Created by xisi on 2022/9/17.
//

#import "UIView+XSFindVC.h"


UIViewController * _Nullable current_view_controller(void) {
    return UIApplication.sharedApplication.keyWindow.viewController;
}

UIViewController * _Nullable topmost_presented_view_controller(void) {
    UIViewController *currentVC = UIApplication.sharedApplication.keyWindow.rootViewController;
    while (currentVC.presentedViewController) {
        currentVC = currentVC.presentedViewController;
    }
    return currentVC;
}



//MARK: -   UIView+XSFindVC

@implementation UIView (XSFindVC)

- (UIViewController * _Nullable)viewController {
    UIResponder *next = self.nextResponder;
    while (next) {
        if ([next isKindOfClass:UIViewController.class]) {
            break;
        }
        next = next.nextResponder;
    }
    return (UIViewController *)next;
}

- (UINavigationController * _Nullable)navigationController {
    UIResponder *next = self.nextResponder;
    while (next) {
        if ([next isKindOfClass:UINavigationController.class]) {
            break;
        }
        next = next.nextResponder;
    }
    return (UINavigationController *)next;
}

- (UITabBarController * _Nullable)tabBarController {
    UIResponder *next = self.nextResponder;
    while (next) {
        if ([next isKindOfClass:UITabBarController.class]) {
            break;
        }
        next = next.nextResponder;
    }
    return (UITabBarController *)next;
}

@end



//MARK: -   UIWindow+XSFindVC

@implementation UIWindow (XSFindVC)

- (UIViewController * _Nullable)viewController {
    UIViewController *curVC = self.rootViewController;
    while (YES) {
        if (curVC.presentedViewController) {
            curVC = curVC.presentedViewController;
        } else {
            if ([curVC isKindOfClass:UITabBarController.class]) {
                curVC = ((UITabBarController *)curVC).selectedViewController;
            } else if ([curVC isKindOfClass:UINavigationController.class]) {
                curVC = ((UINavigationController *)curVC).topViewController;
            } else {
                break;
            }
        }
    }
    return curVC;
}

- (UINavigationController * _Nullable)navigationController {
    UIViewController *curVC = self.rootViewController;
    while (YES) {
        if (curVC.presentedViewController) {
            curVC = curVC.presentedViewController;
        } else {
            if ([curVC isKindOfClass:UITabBarController.class]) {
                curVC = ((UITabBarController *)curVC).selectedViewController;
            } else if ([curVC isKindOfClass:UINavigationController.class]) {
                break;
            } else {
                curVC = nil;
            }
        }
    }
    return (UINavigationController *)curVC;
}

- (UITabBarController * _Nullable)tabBarController {
    UIViewController *curVC = self.rootViewController;
    while (YES) {
        if (curVC.presentedViewController) {
            curVC = curVC.presentedViewController;
        } else {
            if ([curVC isKindOfClass:UITabBarController.class]) {
                break;
            } else if ([curVC isKindOfClass:UINavigationController.class]) {
                curVC = ((UINavigationController *)curVC).topViewController;
            } else {
                curVC = nil;
            }
        }
    }
    return (UITabBarController *)curVC;
}

@end
