//
//  UIButton+XSOnClick.h
//  TableView
//
//  Created by xisi on 2023/9/26.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UIButton (XSOnClick)

@property (nullable, nonatomic) void (^onClick)(UIButton *button);

@end

NS_ASSUME_NONNULL_END
