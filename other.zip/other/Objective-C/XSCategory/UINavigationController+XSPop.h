//
//  UINavigationController+XSPop.h
//  TextKit
//
//  Created by hanxin on 2022/4/20.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

/**
    导航栏控制器中不能存在同一个控制器实例对象。
    
    当同一个控制器实例对象被push第二次时，运行报错：
    <UINavigationController: 0x15c014400> is pushing the same view controller instance (<AViewController: 0x15cd04080>) more than once which is not supported and is most likely an error in the application
 */
@interface UINavigationController (XSPop)

/**
    弹出指定控制器（不包括）之后的所有控制器

    例如：A -> B -> C1 -> D1 -> C2 -> D2，传入C，结果为：A -> B -> C1。（C1、C2表示同一个控制器类的不同的实例对象）
 
    @return 被弹出的控制器列表。上述举例结果为：D1 -> C2 -> D2
 
    @note   如果导航列表中不存在viewControllerClass，Debug模式报错，Release模式则不做处理
 */
- (nullable NSArray<__kindof UIViewController *> *)popToViewControllerClass:(Class)viewControllerClass animated:(BOOL)animated;

/**
    弹出指定控制器（包括）之后的所有控制器

    例如：A -> B -> C1 -> D1 -> C2 -> D2，传入C1，结果为：A -> B。（C1、C2表示同一个控制器类的不同的实例对象）
 
    @return 被弹出的控制器列表。上述举例结果为：C1 -> D1 -> C2 -> D2
 
    @note   如果导航列表中不存在viewController，Debug模式报错，Release模式则不做处理。如果是rootViewController则不做处理。
 */
- (nullable NSArray<__kindof UIViewController *> *)popViewController:(UIViewController *)viewController animated:(BOOL)animated;

/**
    弹出指定控制器（包括）之后的所有控制器

    例如：A -> B -> C1 -> D1 -> C2 -> D2，传入C，结果为：A -> B。（C1、C2表示同一个控制器类的不同的实例对象）

    @return 被弹出的控制器列表。上述举例结果为：C1 -> D1 -> C2 -> D2
 
    @note   如果导航列表中不存在viewControllerClass，Debug模式报错，Release模式则不做处理。如果是rootViewController则不做处理。
 */
- (nullable NSArray<__kindof UIViewController *> *)popViewControllerClass:(Class)viewControllerClass animated:(BOOL)animated;

@end

NS_ASSUME_NONNULL_END
