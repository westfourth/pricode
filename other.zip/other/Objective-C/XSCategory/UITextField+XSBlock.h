//
//  UITextField+XSBlock.h
//  XSMultiSection
//
//  Created by xisi on 2023/7/22.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

/**
    如果实现了对应的`delegate`方法，那么对应的`block`回调将不再生效。
 */
@interface UITextField (XSBlock)

//  - textFieldShouldBeginEditing:
@property (nullable, nonatomic) BOOL (^shouldBeginEditing)(UITextField *textField);
//  - textFieldDidBeginEditing:
@property (nullable, nonatomic) void (^didBeginEditing)(UITextField *textField);
//  - textFieldShouldEndEditing:
@property (nullable, nonatomic) BOOL (^shouldEndEditing)(UITextField *textField);
//  - textFieldDidEndEditing:
@property (nullable, nonatomic) void (^didEndEditing)(UITextField *textField);

//  - textField:shouldChangeCharactersInRange:replacementString:
@property (nullable, nonatomic) BOOL (^shouldChangeText)(UITextField *textField, NSRange range, NSString *replacement);
//  - textFieldDidChange:
@property (nullable, nonatomic) void (^didChangeText)(UITextField *textField);

@end



//MARK: -   XSBlock2

/**
    如果实现了对应的`delegate`方法，那么对应的`block`回调将不再生效。
 */
@interface UITextField (XSBlock2)

//  - textFieldShouldClear:
@property (nullable, nonatomic) BOOL (^shouldClear)(UITextField *textField);

@end



//MARK: -   UITextFieldDelegate2

@protocol UITextFieldDelegate2 <NSObject>
@optional
/// 文本变化
- (void)textFieldDidChange:(UITextField *)textField;
@end

NS_ASSUME_NONNULL_END
