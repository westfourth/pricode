//
//  UITextField+XSInput.h
//  TextKit
//
//  Created by hanxin on 2022/1/30.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

/**
    @note 当委托实现了这个协议（-textField: shouldChangeCharactersInRange: replacementString:）时，这个类别的所有属性都会失效
 
    @warning iPhone6以及之前的机型没有"_delegateShouldChangeCharactersInTextStorageRange:replacementString:delegateCares:"，导致此分类无效
 */
@interface UITextField (XSInput)

/// 允许输入的字符集合。
@property (nullable, nonatomic) NSCharacterSet *allowedCharacterSet;

/// 最大允许的长度；超过时，不能继续输入。默认0，>0时才有效。
@property (nonatomic) NSUInteger maxLength;

@end




@interface NSCharacterSet (XSInput)
/// 九宫格拼音
@property (readonly, class) NSCharacterSet *pinyin9CharacterSet;
/// 笔画
@property (readonly, class) NSCharacterSet *bihuaCharacterSet;
@end

NS_ASSUME_NONNULL_END
