//
//  NSBundle+Extension.m
//  ITBook
//
//  Created by xisi on 2025/3/7.
//  Copyright © 2025 mac. All rights reserved.
//

#import "NSBundle+Extension.h"
#include <execinfo.h>

//  从调用栈中解析调用者的类名
static Class _Nullable resolve_symbols(char **symbols, int count);
//  从符号中解析调用者的类名
static Class _Nullable resolve_class_with_symbol(NSString *symbol);
//  获取类名所在的xxx.framework下的xxx.bundle
static NSBundle *getBundleForClass(Class cls);



//  从调用者所在的Bundle中，找到名称为name的json文件，并转换为对象
id _Nullable json_named(NSString *name) {
    int size = 4;               //  最多4层
    void *buffer[size];
    int nptrs = backtrace(buffer, size);
    char **symbols = backtrace_symbols(buffer, nptrs);
    
    Class cls = resolve_symbols(symbols, nptrs);
    free(symbols);
    NSBundle *bundle = getBundleForClass(cls);
    
    NSString *path = [bundle pathForResource:name ofType:nil];
    NSData *data = [NSData dataWithContentsOfFile:path];
    NSError *error = nil;
    id object = [NSJSONSerialization JSONObjectWithData:data options:0 error:&error];
    if (error) {
        NSLog(@">>> %s: %@", __func__, error);
    }
    
    return object;
}

//  从调用者所在的Bundle中，找到名称为name的plist文件，并转换为对象
id _Nullable plist_named(NSString *name) {
    int size = 4;               //  最多4层
    void *buffer[size];
    int nptrs = backtrace(buffer, size);
    char **symbols = backtrace_symbols(buffer, nptrs);
    
    Class cls = resolve_symbols(symbols, nptrs);
    free(symbols);
    NSBundle *bundle = getBundleForClass(cls);
    
    NSString *path = [bundle pathForResource:name ofType:nil];
    NSData *data = [NSData dataWithContentsOfFile:path];
    NSError *error = nil;
    NSPropertyListFormat format = 0;
    id object = [NSPropertyListSerialization propertyListWithData:data options:0 format:&format error:&error];
    if (error) {
        NSLog(@">>> %s: %@", __func__, error);
    }
    
    return object;
}



//MARK: -   NSBundle+Extension

@implementation NSBundle (Extension)

/**
    使用`callStackSymbols`，      1千次时间代价为4秒。
    使用`backtrace_symbols()`，1万次时间代价为2秒。
 */
+ (NSBundle *)currentResourceBundle {
    int size = 4;               //  最多4层
    void *buffer[size];
    int nptrs = backtrace(buffer, size);
    char **symbols = backtrace_symbols(buffer, nptrs);
    
    Class cls = resolve_symbols(symbols, nptrs);
    free(symbols);
    NSBundle *bundle = getBundleForClass(cls);
    
    return bundle;
}

@end



//MARK: -   UIImage+Bundle

@implementation UIImage (Bundle)

/**
    使用`callStackSymbols`，      1千次时间代价为4秒。
    使用`backtrace_symbols()`，1万次时间代价为2秒。
 */
+ (nullable UIImage *)bundleImageNamed:(NSString *)name {
    int size = 4;               //  最多4层
    void *buffer[size];
    int nptrs = backtrace(buffer, size);
    char **symbols = backtrace_symbols(buffer, nptrs);
    
    Class cls = resolve_symbols(symbols, nptrs);
    free(symbols);
    NSBundle *bundle = getBundleForClass(cls);
    
    UIImage *image = [UIImage imageNamed:name inBundle:bundle withConfiguration:nil];
    return image;
}

@end



//MARK: -   static method

//  从调用栈中解析调用者的类名
static Class _Nullable resolve_symbols(char **symbols, int count) {
    if (symbols == NULL) {
        return NULL;
    }
    
    //  0表示自身，>0表示后续调用者。
    for (int i = 1; i < count; i++) {
        NSString *symbol = [NSString stringWithCString:symbols[i] encoding:NSUTF8StringEncoding];
        Class cls = resolve_class_with_symbol(symbol);
        if (cls) {
            return cls;
        }
    }
    return NULL;
}

//  从符号中解析调用者的类名
static Class _Nullable resolve_class_with_symbol(NSString *symbol) {
    NSError *error = nil;
    NSString *pattern = @"(?<=[-+]\\[)\\w+(?=(\\(\\w+\\))?\\ )";
    NSRegularExpression *regexp = [NSRegularExpression regularExpressionWithPattern:pattern options:0 error:&error];
    NSRange range = NSMakeRange(0, symbol.length);
    NSTextCheckingResult *result = [regexp firstMatchInString:symbol options:0 range:range];
    NSString *matchText = [symbol substringWithRange:result.range];
    Class cls = NSClassFromString(matchText);
    return cls;
}

//  获取类名所在的xxx.framework下的xxx.bundle
static NSBundle *getBundleForClass(Class cls) {
    NSBundle *bundle = [NSBundle bundleForClass:cls];           //  xxx.framework
    NSString *resourceName = [bundle.bundlePath.lastPathComponent stringByDeletingPathExtension];
    //  获取 xxx.framework 下的 xxx.bundle
    NSURL *url = [bundle URLForResource:resourceName withExtension:@"bundle"];
    if (url) {              //  非mainBundle
        bundle = [NSBundle bundleWithURL:url];
    } else {
        bundle = [NSBundle mainBundle];
    }
    return bundle;
}
