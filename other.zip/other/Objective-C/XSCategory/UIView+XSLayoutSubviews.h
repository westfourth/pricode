//
//  UIView+XSLayoutSubviews.h
//  TextKit
//
//  Created by hanxin on 2022/7/12.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UIView (XSLayoutSubviews)

/// layoutSubviews事件
@property (nullable, nonatomic) void (^layoutSubviewsBlock)(__kindof UIView *);

@end

NS_ASSUME_NONNULL_END
