//
//  UIButton+XSAlign.h
//  Test
//
//  Created by hanxin on 2022/01/15.
//  Copyright © 2020 mac. All rights reserved.
//

#import <UIKit/UIKit.h>

/// 排列方式
typedef NS_ENUM(NSUInteger, XSAlign) {
    XSAlignHorizontal,          //!<    图片在左，文字在右
    XSAlignHorizontalReverse,   //!<    文字在左，图片在右
    XSAlignVertical,            //!<    图片在上，文字在下
    XSAlignVerticalReverse,     //!<    文字在上，图片在下
};

NS_ASSUME_NONNULL_BEGIN

@interface UIButton (XSAlign)

/// 排列方式
@property (nonatomic) XSAlign alignType;

/// 图片与文字之间的距离
@property (nonatomic) CGFloat alignSpacing;

@end

NS_ASSUME_NONNULL_END
