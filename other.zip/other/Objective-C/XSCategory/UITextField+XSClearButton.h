//
//  UITextField+XSClearButton.h
//  TextKit
//
//  Created by hanxin on 2022/1/28.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN


@interface UITextField (XSClearButton)

/// 替换默认 clearButton的图片
@property (nullable, nonatomic) UIImage *clearButtonImage;

/// 调整默认 clearButton的位置、大小
@property (nullable, nonatomic) CGRect (^clearButtonRectForBounds)(CGRect bounds);

@end

NS_ASSUME_NONNULL_END
