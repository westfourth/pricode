//
//  UIStackView+XSReplace.h
//  TextKit
//
//  Created by hanxin on 2022/6/22.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UIStackView (XSReplace)

- (void)replaceArrangedSubviews:(NSArray<__kindof UIView *> *)views;

@end

NS_ASSUME_NONNULL_END
