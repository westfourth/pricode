//
//  UITextField+XSTextInsets.h
//  TextKit
//
//  Created by hanxin on 2024/3/1.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UITextField (XSTextInsets)

@property (nonatomic) UIEdgeInsets textInsets;

@end

NS_ASSUME_NONNULL_END
