//
//  UISearchBar+XSExtend.h
//  TextKit
//
//  Created by hanxin on 2022/5/24.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

/**
    原理：找到UITextField，并设置对应的属性
 */
@interface UISearchBar (XSExtend)

@property(nullable, nonatomic) UIColor *textColor;

/**
    @bug    可能引起输入框高度增加
 */
@property(nullable, nonatomic) UIFont *font;

@property(nullable, nonatomic) NSAttributedString *attributedPlaceholder;

@end

NS_ASSUME_NONNULL_END
