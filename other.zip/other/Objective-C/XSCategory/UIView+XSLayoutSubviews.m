//
//  UIView+XSLayoutSubviews.m
//  TextKit
//
//  Created by hanxin on 2022/7/12.
//

#import "UIView+XSLayoutSubviews.h"
#import <objc/runtime.h>

@implementation UIView (XSLayoutSubviews)

/**
 UIButton.layoutSubviews 没有调用 super.layoutSubviews。同样还有UITableView、UIProgressView
 */
+ (void)load {
    SEL sel = @selector(layoutSubviews);
    for (Class cls in @[[UIView class], [UIButton class], [UITableView class], [UIProgressView class]]) {
        Method m = class_getInstanceMethod(cls, sel);
        IMP imp0 = method_getImplementation(m);
        IMP imp1 = imp_implementationWithBlock(^void(UIView *self) {
            ((void (*)(UIView *, SEL))imp0)(self, sel);
            if (self.layoutSubviewsBlock) {
                self.layoutSubviewsBlock(self);
            }
        });
        method_setImplementation(m, imp1);
    }
}


//MARK: -   property

- (void (^)(__kindof UIView *))layoutSubviewsBlock {
    return objc_getAssociatedObject(self, @selector(layoutSubviewsBlock));
}

- (void)setLayoutSubviewsBlock:(void (^)(__kindof UIView *))layoutSubviewsBlock {
    objc_setAssociatedObject(self, @selector(layoutSubviewsBlock), layoutSubviewsBlock, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
}

@end
