//
//  UILabel+XSClick.h
//  TextKit
//
//  Created by hanxin on 2021/11/27.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

/// 因为UILabel的NSLinkAttributeName属性颜色只能为蓝色，因此新增此key
UIKIT_EXTERN NSAttributedStringKey const NSLink2AttributeName;                // NSURL (preferred) or NSString

/**
    点击属性文字。
 
    @note   开启 userInteractionEnabled 才有效
    
    @warning    超链接文字颜色改不了、下划线去不了
 */
@interface UILabel (XSClick)

/// 点击手势。调用了 setClickURL: 或 setClickAttributes: 后才有值
@property (readonly, nullable, nonatomic) UITapGestureRecognizer *tapGesture;

/// 点击字符链接
@property (nullable, nonatomic) void (^clickURL)(NSURL *url);

/// 点击字符属性
@property (nullable, nonatomic) void (^clickAttributes)(NSDictionary *attrs);

@end

NS_ASSUME_NONNULL_END
