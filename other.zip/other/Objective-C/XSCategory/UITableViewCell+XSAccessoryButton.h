//
//  UITableViewCell+XSAccessoryButton.h
//  TextKit
//
//  Created by hanxin on 2022/4/15.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

/*------------------------------------------------------------------------------------------------
 |  accessoryType类型                                | subViews
 |
 |  UITableViewCellAccessoryNone                    | 无
 |
 |  UITableViewCellAccessoryDisclosureIndicator     | _UITableCellAccessoryButton
 |
 |  UITableViewCellAccessoryDetailDisclosureButton  | UIButton  +  _UITableCellAccessoryButton
 |
 |  UITableViewCellAccessoryCheckmark               | _UITableCellAccessoryButton
 |
 |  UITableViewCellAccessoryDetailButton            | UIButton
 ------------------------------------------------------------------------------------------------*/

/**
 下面的分类只有在 UITableViewCellAccessoryDisclosureIndicator、UITableViewCellAccessoryCheckmark时生效
 */
@interface UITableViewCell (XSAccessoryButton)

/// 图片
@property (nullable, nonatomic) UIImage *accessoryButtonImage;

/// 指定button大小。如果不指定，则为图片的大小
@property (nonatomic) CGSize accessoryButtonSize;

/// 默认位置为：垂直居中，右侧20px
@property (nonatomic) UIEdgeInsets accessoryButtonInsets;

@end

NS_ASSUME_NONNULL_END
