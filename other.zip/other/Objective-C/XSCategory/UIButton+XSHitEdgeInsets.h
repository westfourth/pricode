//
//  UIButton+XSHitEdgeInsets.h
//  TextKit
//
//  Created by hanxin on 2022/8/4.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UIButton (XSHitEdgeInsets)

/// 点击范围。负值扩大点击范围；正值缩小点击范围。
@property(nonatomic) UIEdgeInsets hitEdgeInsets;

@end

NS_ASSUME_NONNULL_END
