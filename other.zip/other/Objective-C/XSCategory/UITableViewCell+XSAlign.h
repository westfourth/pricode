//
//  UITableViewCell+XSAlign.h
//  TextKit
//
//  Created by xisi on 2022/5/12.
//

#import <UIKit/UIKit.h>
@class XSCellAlignModel;

NS_ASSUME_NONNULL_BEGIN

@interface UITableViewCell (XSAlign)

@property (nullable, nonatomic) XSCellAlignModel *alignModel;

@end



// MARK: - XSCellAlignModel

@interface XSCellAlignModel : NSObject

/**
    top        -   imageView距离cell上边界的距离
    left        -   imageView距离cell左边界的距离
    bottom -   imageView距离cell下边界的距离
    right     -   无效
 */
@property(nonatomic) UIEdgeInsets imageEdgeInsets;

/**
    imageView宽高比，默认：1
 */
@property(nonatomic) CGFloat imageRatio;

/**
    top        -   imageView距离cell上边界的距离
    left        -   imageView与imageView水平距离
    bottom -   imageView距离cell下边界的距离
    right     -   imageView距离cell右边界的距离
 */
@property(nonatomic) UIEdgeInsets titleEdgeInsets;

@end

NS_ASSUME_NONNULL_END
