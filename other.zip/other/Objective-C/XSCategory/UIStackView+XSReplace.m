//
//  UIStackView+XSReplace.m
//  TextKit
//
//  Created by hanxin on 2022/6/22.
//

#import "UIStackView+XSReplace.h"

@implementation UIStackView (XSReplace)

- (void)replaceArrangedSubviews:(NSArray<__kindof UIView *> *)views {
    NSArray *array = self.arrangedSubviews;
    //  移除
    for (UIView *view in array) {
        //  使用removeArrangedSubview:结果不确定
        [view removeFromSuperview];
    }
    //  添加
    for (UIView *view in views) {
        [self addArrangedSubview:view];
    }
}

@end
