//
//  NSURLComponents+XSQuery.m
//  Landscape
//
//  Created by xisi on 2024/6/2.
//

#import "NSURLComponents+XSQuery.h"

@implementation NSURLComponents (XSQuery)

- (void)setValue:(NSString * _Nullable)value forName:(NSString *)name {
    NSURLQueryItem *newItem = [[NSURLQueryItem alloc] initWithName:name value:value];
    NSMutableArray<NSURLQueryItem *> *array = [NSMutableArray arrayWithArray:self.queryItems];
    
    //  匹配
    NSURLQueryItem *matchItem = nil;
    for (NSURLQueryItem *item in array) {
        if ([item.name isEqualToString:name]) {
            matchItem = item;
            break;
        }
    }
    
    if (value == nil) {
        if (matchItem) {
            [array removeObject:matchItem];
        }
    } else {
        if (matchItem) {
            [array removeObject:matchItem];
        }
        [array addObject:newItem];
    }
    self.queryItems = array;
}

@end
