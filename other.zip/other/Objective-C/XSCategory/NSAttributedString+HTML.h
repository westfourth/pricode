//
//  NSAttributedString+HTML.h
//  TextKit
//
//  Created by hanxin on 2021/11/27.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

/**
    从html、css内容生成属性文字。
 
    知识点：当以NSURL的方式读取时，自动解析html中引用的css文件、image文件；html中可以使用css、image的相对路径。
 
    @warning    以html方式解析 的 直接生成/更改属性文字 慢400倍
 */
@interface NSAttributedString (HTML)

/**
    从mainBundle的文件中生成属性文字。会调用 attributedTextWithHtmlText: cssText:

    @param  htmlFilename        mainBundle中的文件名
    @param  cssFilename          mainBundle中的文件名
 */
+ (nullable instancetype)attributedTextWithHtmlFilename:(NSString *)htmlFilename cssFilename:(nullable NSString *)cssFilename;


/**
    生成属性文字。会调用 attributedTextWithHtmlText: cssText:

    @param  htmlFilename        html文件名
    @param  cssFilename          css文件名
    @param  bundle                     bundle
 */
+ (nullable instancetype)attributedTextWithHtmlFilename:(NSString *)htmlFilename cssFilename:(nullable NSString *)cssFilename bundle:(nullable NSBundle *)bundle;

/**
    从html、css内容生成属性文字

    @param  htmlText        html内容
    @param  cssText          css内容
 */
+ (nullable instancetype)attributedTextWithHtmlText:(NSString *)htmlText cssText:(nullable NSString *)cssText;


+ (nullable NSString *)textWithFilename:(NSString *)fileName bundle:(nullable NSBundle *)bundle;


@end

NS_ASSUME_NONNULL_END
