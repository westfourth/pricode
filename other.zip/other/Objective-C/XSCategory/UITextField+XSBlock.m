//
//  UITextField+XSBlock.m
//  XSMultiSection
//
//  Created by xisi on 2023/7/22.
//

#import "UITextField+XSBlock.h"
#import <objc/runtime.h>
@class UIFieldEditor;

@implementation UITextField (XSBlock)

+ (void)load {
    [self load_shouldBeginEditing];
    [self load_didBeginEditing];
    [self load_shouldEndEditing];
    [self load_didEndEditing];
    
    [self load_shouldChangeText];
    [self load_didChangeText];
}

+ (void)load_shouldBeginEditing {
    Class cls = [self class];
    //  B16@0:8
    SEL sel = sel_registerName("_delegateShouldBeginEditing");
    Method m = class_getInstanceMethod(cls, sel);
    IMP imp0 = method_getImplementation(m);
    IMP imp1 = imp_implementationWithBlock(^BOOL(UITextField *self) {
        BOOL should = ((BOOL (*)(UITextField*, SEL))imp0)(self, sel);
        //  高优先级
        if ([self.delegate respondsToSelector:@selector(textFieldShouldBeginEditing:)]) {
            return should;
        }
        //  低优先级
        if (self.shouldBeginEditing) {
            return self.shouldBeginEditing(self);
        }
        return should;
    });
    method_setImplementation(m, imp1);
}

+ (void)load_didBeginEditing {
    Class cls = [self class];
    //  v16@0:8
    SEL sel = sel_registerName("_notifyDidBeginEditing");
    Method m = class_getInstanceMethod(cls, sel);
    IMP imp0 = method_getImplementation(m);
    IMP imp1 = imp_implementationWithBlock(^void(UITextField *self) {
        ((void (*)(UITextField*, SEL))imp0)(self, sel);
        //  高优先级
        if ([self.delegate respondsToSelector:@selector(textFieldDidBeginEditing:)]) {
            return;
        }
        //  低优先级
        if (self.didBeginEditing) {
            self.didBeginEditing(self);
        }
    });
    method_setImplementation(m, imp1);
}

+ (void)load_shouldEndEditing {
    Class cls = [self class];
    //  B16@0:8
    SEL sel = sel_registerName("_delegateShouldEndEditing");
    Method m = class_getInstanceMethod(cls, sel);
    IMP imp0 = method_getImplementation(m);
    IMP imp1 = imp_implementationWithBlock(^BOOL(UITextField *self) {
        BOOL should = ((BOOL (*)(UITextField*, SEL))imp0)(self, sel);
        //  高优先级
        if ([self.delegate respondsToSelector:@selector(textFieldShouldEndEditing:)]) {
            return should;
        }
        //  低优先级
        if (self.shouldEndEditing) {
            return self.shouldEndEditing(self);
        }
        return should;
    });
    method_setImplementation(m, imp1);
}

+ (void)load_didEndEditing {
    Class cls = [self class];
    //  v16@0:8
    SEL sel = sel_registerName("_notifyDidEndEditing");
    Method m = class_getInstanceMethod(cls, sel);
    IMP imp0 = method_getImplementation(m);
    IMP imp1 = imp_implementationWithBlock(^void(UITextField *self) {
        ((void (*)(UITextField*, SEL))imp0)(self, sel);
        //  高优先级
        if ([self.delegate respondsToSelector:@selector(textFieldDidEndEditing:)]) {
            return;
        }
        //  低优先级
        if (self.didEndEditing) {
            self.didEndEditing(self);
        }
    });
    method_setImplementation(m, imp1);
}

+ (void)load_shouldChangeText {
    Class cls = [self class];
    //  B48@0:8{_NSRange=QQ}16@32^B40
    SEL sel = sel_registerName("_delegateShouldChangeCharactersInTextStorageRange:replacementString:delegateCares:");
    Method m = class_getInstanceMethod(cls, sel);
    IMP imp0 = method_getImplementation(m);
    IMP imp1 = imp_implementationWithBlock(^BOOL(UITextField *self, NSRange range, NSString *replacement, BOOL *cares) {
        BOOL should = ((BOOL (*)(UITextField*, SEL, NSRange, NSString*, BOOL*))imp0)(self, sel, range, replacement, cares);
        //  高优先级
        if ([self.delegate respondsToSelector:@selector(textField:shouldChangeCharactersInRange:replacementString:)]) {
            return should;
        }
        //  低优先级
        if (self.shouldChangeText) {
            return self.shouldChangeText(self, range, replacement);
        }
        return should;
    });
    method_setImplementation(m, imp1);
}

+ (void)load_didChangeText {
    Class cls = [self class];
    //  v24@0:8@16
    SEL sel = sel_registerName("fieldEditorDidChange:");
    Method m = class_getInstanceMethod(cls, sel);
    IMP imp0 = method_getImplementation(m);
    IMP imp1 = imp_implementationWithBlock(^void(UITextField *self, UIFieldEditor *editor) {
        ((void (*)(UITextField *, SEL, UIFieldEditor *))imp0)(self, sel, editor);
        //  高优先级
        if ([self.delegate respondsToSelector:@selector(textFieldDidChange:)]) {
            [(id<UITextFieldDelegate2>)self.delegate textFieldDidChange:self];
            return;
        }
        //  低优先级
        if (self.didChangeText) {
            self.didChangeText(self);
        }
    });
    method_setImplementation(m, imp1);
}


//MARK: -   property

- (BOOL (^)(UITextField * _Nonnull))shouldBeginEditing {
    return objc_getAssociatedObject(self, @selector(shouldBeginEditing));
}
- (void)setShouldBeginEditing:(BOOL (^)(UITextField * _Nonnull))shouldBeginEditing {
    objc_setAssociatedObject(self, @selector(shouldBeginEditing), shouldBeginEditing, OBJC_ASSOCIATION_COPY_NONATOMIC);
}

- (void (^)(UITextField * _Nonnull))didBeginEditing {
    return objc_getAssociatedObject(self, @selector(didBeginEditing));
}
- (void)setDidBeginEditing:(void (^)(UITextField * _Nonnull))didBeginEditing {
    objc_setAssociatedObject(self, @selector(didBeginEditing), didBeginEditing, OBJC_ASSOCIATION_COPY_NONATOMIC);
}

- (BOOL (^)(UITextField * _Nonnull))shouldEndEditing {
    return objc_getAssociatedObject(self, @selector(shouldEndEditing));
}
- (void)setShouldEndEditing:(BOOL (^)(UITextField * _Nonnull))shouldEndEditing {
    objc_setAssociatedObject(self, @selector(shouldEndEditing), shouldEndEditing, OBJC_ASSOCIATION_COPY_NONATOMIC);
}

- (void (^)(UITextField * _Nonnull))didEndEditing {
    return objc_getAssociatedObject(self, @selector(didEndEditing));
}
- (void)setDidEndEditing:(void (^)(UITextField * _Nonnull))didEndEditing {
    objc_setAssociatedObject(self, @selector(didEndEditing), didEndEditing, OBJC_ASSOCIATION_COPY_NONATOMIC);
}

- (BOOL (^)(UITextField * _Nonnull, NSRange, NSString * _Nonnull))shouldChangeText {
    return objc_getAssociatedObject(self, @selector(shouldChangeText));
}
- (void)setShouldChangeText:(BOOL (^)(UITextField * _Nonnull, NSRange, NSString * _Nonnull))shouldChangeText {
    objc_setAssociatedObject(self, @selector(shouldChangeText), shouldChangeText, OBJC_ASSOCIATION_COPY_NONATOMIC);
}

- (void (^)(UITextField * _Nonnull))didChangeText {
    return objc_getAssociatedObject(self, @selector(didChangeText));
}
- (void)setDidChangeText:(void (^)(UITextField * _Nonnull))didChangeText {
    objc_setAssociatedObject(self, @selector(didChangeText), didChangeText, OBJC_ASSOCIATION_COPY_NONATOMIC);
}

@end



//MARK: -   XSBlock2

@implementation UITextField (XSBlock2)

+ (void)load {
    [self load_shouldClear];
}

+ (void)load_shouldClear {
    Class cls = self.class;
    //  B16@0:8
    SEL sel = sel_registerName("_delegateShouldClear");
    Method m = class_getInstanceMethod(cls, sel);
    const char *types = method_getTypeEncoding(m);
    IMP imp0 = method_getImplementation(m);
    IMP imp = imp_implementationWithBlock(^BOOL(UITextField *self){
        BOOL should = ((BOOL (*)(UITextField *, SEL))imp0)(self, sel);
        if ([self.delegate respondsToSelector:@selector(textFieldShouldClear:)]) {
            return should;
        }
        if (self.shouldClear) {
            return self.shouldClear(self);
        }
        return should;
    });
    BOOL success = class_addMethod(cls, sel, imp, types);
    if (!success) {
        method_setImplementation(m, imp);
    }
}

- (BOOL (^)(UITextField * _Nonnull))shouldClear {
    return objc_getAssociatedObject(self, @selector(shouldClear));
}

- (void)setShouldClear:(BOOL (^)(UITextField * _Nonnull))shouldClear {
    objc_setAssociatedObject(self, @selector(shouldClear), shouldClear, OBJC_ASSOCIATION_RETAIN);
}

@end
