//
//  UIView+XSEdgeSeparator.h
//  TextKit
//
//  Created by xisi on 2022/6/8.
//

#import <UIKit/UIKit.h>
@class XSEdgeSeparator;

NS_ASSUME_NONNULL_BEGIN

@interface UIView (XSEdgeSeparator)

/// 分割线
@property (nullable, nonatomic) XSEdgeSeparator *edgeSeparator;

@end



@interface XSEdgeSeparator: NSObject

/// 分割线粗细，默认0
@property CGFloat lineWidth;

/// 分割线颜色，默认nil
@property (nullable) UIColor *lineColor;

/// 控制哪条边有分割线，默认None
@property UIRectEdge rectEdge;

/// 控制距离边界距离，默认Zero
/// top             -   左、右分割线距离上边间隔
/// left             -   上、下分割线距离左边间隔
/// bottom      -   左、右分割线距离下边间隔
/// right          -   上、下分割线距离右边间隔
@property UIEdgeInsets edgeInsets;

@end

NS_ASSUME_NONNULL_END
