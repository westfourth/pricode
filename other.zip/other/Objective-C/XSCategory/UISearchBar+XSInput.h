//
//  UISearchBar+XSInput.h
//  TextKit
//
//  Created by xisi on 2022/5/26.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

/**
    @note 当委托实现了这个协议（-searchBar: shouldChangeTextInRange: replacementText:）时，这个类别的所有属性都会失效
 */
@interface UISearchBar (XSInput)

/// 允许输入的字符集合。
@property (nullable, nonatomic) NSCharacterSet *allowedCharacterSet;

/// 最大允许的长度；超过时，不能继续输入。默认0，>0时才有效。
@property (nonatomic) NSUInteger maxLength;

@end

NS_ASSUME_NONNULL_END
