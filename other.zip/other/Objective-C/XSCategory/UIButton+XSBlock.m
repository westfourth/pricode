//
//  UIButton+XSBlock.m
//  XSMultiSection
//
//  Created by xisi on 2023/7/24.
//

#import "UIButton+XSBlock.h"
#import <objc/runtime.h>

@implementation UIButton (XSBlock)

- (void (^)(UIButton * _Nonnull))onClick {
    return objc_getAssociatedObject(self, @selector(onClick));
}

- (void)setOnClick:(void (^)(UIButton * _Nonnull))onClick {
    objc_setAssociatedObject(self, @selector(onClick), onClick, OBJC_ASSOCIATION_COPY_NONATOMIC);
    //  添加多次，只会触发一次
    [self addTarget:self.class action:@selector(clickButton:) forControlEvents:UIControlEventTouchUpInside];
}

+ (void)clickButton:(UIButton *)button {
    if (button.onClick) {
        button.onClick(button);
    }
}

@end
