//
//  UITextField+XSDisallowsEditing.m
//  Animation
//
//  Created by hanxin on 2022/8/23.
//

#import "UITextField+XSDisallowsEditing.h"
#import <objc/runtime.h>

@implementation UITextField (XSDisallowsEditing)

+ (void)load {
    Class cls = [self class];
    //  B16@0:8
    SEL sel = sel_registerName("_delegateShouldBeginEditing");
    Method m = class_getInstanceMethod(cls, sel);
    IMP imp0 = method_getImplementation(m);
    IMP imp1 = imp_implementationWithBlock(^BOOL(UITextField *self) {
        BOOL shouldBegin = ((BOOL (*)(UITextField*, SEL))imp0)(self, sel);
        //  高优先级
        if ([self.delegate respondsToSelector:@selector(textFieldShouldBeginEditing:)]) {
            return shouldBegin;
        }
        //  低优先级
        return self.disallowsEditing == NO;
    });
    method_setImplementation(m, imp1);
}



// MARK: -  property

- (BOOL)disallowsEditing {
    return [objc_getAssociatedObject(self, @selector(disallowsEditing)) boolValue];
}

- (void)setDisallowsEditing:(BOOL)disallowsEditing {
    objc_setAssociatedObject(self, @selector(disallowsEditing), @(disallowsEditing), OBJC_ASSOCIATION_ASSIGN);
}

@end
