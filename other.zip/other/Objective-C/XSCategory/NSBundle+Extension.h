//
//  NSBundle+Extension.h
//  ITBook
//
//  Created by xisi on 2025/3/7.
//  Copyright © 2025 mac. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

//  从调用者所在的Bundle中，找到名称为name的json文件，并转换为对象
id _Nullable json_named(NSString *name);

//  从调用者所在的Bundle中，找到名称为name的plist文件，并转换为对象
id _Nullable plist_named(NSString *name);



//MARK: -   NSBundle+Extension

@interface NSBundle (Extension)

/**
    找到调用者所在的bundle。
 
    例如：
    1. 从 minBundle 中调用，返回的就是 minBundle；
    2. 从 A.framework 中调用，返回的就是 A.framework 下的 A.bundle；
    3. 从 B.framework 中调用，返回的就是 B.framework 下的 B.bundle；
 
    注意：pod组件化时，使用 spec.resource_bundles 方式，bundle 与 framework 名称须一致。
 */
+ (NSBundle *)currentResourceBundle;

@end



//MARK: -   UIImage+Bundle

@interface UIImage (Bundle)

/** 找到调用者所在的Bundle中指定的图片。
 
    例如：
    1. mainBundle中 有图片logo.png，类名：ViewController；
    2. BundleA中      有图片logo.png，类名：AViewController；
    3. BundleB中      有图片logo.png，类名：BViewController；
    
    那么在 AViewController 中调用此方法，得到的就是 BundleA 中的图片logo.png。
 */
+ (nullable UIImage *)bundleImageNamed:(NSString *)name;

@end

NS_ASSUME_NONNULL_END
