//
//  NSMutableAttributedString+Regexp.h
//  Markdown
//
//  Created by xisi on 2021/12/8.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSMutableAttributedString (Regexp)

/// 给正则表达式匹配到的字符串添加属性
- (void)addAttributes:(NSDictionary<NSAttributedStringKey, id> *)attrs matchPattern:(NSString *)pattern;

@end

NS_ASSUME_NONNULL_END
