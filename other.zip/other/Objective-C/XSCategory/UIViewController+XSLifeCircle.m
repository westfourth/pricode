//
//  UIViewController+XSLifeCircle.m
//  TableView
//
//  Created by xisi on 2023/9/11.
//

#import "UIViewController+XSLifeCircle.h"
#import <objc/runtime.h>

@implementation UIViewController (XSLifeCircle)

+ (void)load {
    [self XSLifeCircle_load_viewDidLoad];
    [self XSLifeCircle_load_dealloc];
    
    [self XSLifeCircle_load_viewWillAppear];
    [self XSLifeCircle_load_viewDidAppear];
    [self XSLifeCircle_load_viewWillDisappear];
    [self XSLifeCircle_load_viewDidDisappear];
}


//MARK: - load

//  - viewDidLoad
+ (void)XSLifeCircle_load_viewDidLoad {
    Class cls = self.class;
    SEL sel = @selector(viewDidLoad);
    Method m = class_getInstanceMethod(cls, sel);
    const char *types = method_getTypeEncoding(m);
    IMP imp0 = method_getImplementation(m);
    
    IMP imp = imp_implementationWithBlock(^void(UIViewController *viewController){
        ((void (*)(UIViewController *, SEL))imp0)(viewController, sel);
        if ([self.blockDelegate respondsToSelector:@selector(controllerViewDidLoad:)]) {
            [self.blockDelegate controllerViewDidLoad:viewController];
        }
    });
    BOOL success = class_addMethod(cls, sel, imp, types);
    if (!success) {
        method_setImplementation(m, imp);
    }
}

//  - dealloc
+ (void)XSLifeCircle_load_dealloc {
    Class cls = self.class;
    SEL sel = sel_registerName("dealloc");
    Method m = class_getInstanceMethod(cls, sel);
    const char *types = method_getTypeEncoding(m);
    IMP imp0 = method_getImplementation(m);
    
    //  必须标记为：__unsafe_unretained
    IMP imp = imp_implementationWithBlock(^void(__unsafe_unretained UIViewController *viewController){
        if ([self.blockDelegate respondsToSelector:@selector(controllerDealloc:)]) {
            [self.blockDelegate controllerDealloc:viewController];
        }
        ((void (*)(UIViewController *, SEL))imp0)(viewController, sel);
    });
    BOOL success = class_addMethod(cls, sel, imp, types);
    if (!success) {
        method_setImplementation(m, imp);
    }
}

//  - viewWillAppear:
+ (void)XSLifeCircle_load_viewWillAppear {
    Class cls = self.class;
    SEL sel = @selector(viewWillAppear:);
    Method m = class_getInstanceMethod(cls, sel);
    const char *types = method_getTypeEncoding(m);
    IMP imp0 = method_getImplementation(m);
    
    IMP imp = imp_implementationWithBlock(^void(UIViewController *viewController, BOOL animated){
        ((void (*)(UIViewController *, SEL, BOOL))imp0)(viewController, sel, animated);
        if ([self.blockDelegate respondsToSelector:@selector(controller:viewWillAppear:)]) {
            [self.blockDelegate controller:viewController viewWillAppear:animated];
        }
    });
    BOOL success = class_addMethod(cls, sel, imp, types);
    if (!success) {
        method_setImplementation(m, imp);
    }
}

//  - viewDidAppear:
+ (void)XSLifeCircle_load_viewDidAppear {
    Class cls = self.class;
    SEL sel = @selector(viewDidAppear:);
    Method m = class_getInstanceMethod(cls, sel);
    const char *types = method_getTypeEncoding(m);
    IMP imp0 = method_getImplementation(m);
    
    IMP imp = imp_implementationWithBlock(^void(UIViewController *viewController, BOOL animated){
        ((void (*)(UIViewController *, SEL, BOOL))imp0)(viewController, sel, animated);
        if ([self.blockDelegate respondsToSelector:@selector(controller:viewDidAppear:)]) {
            [self.blockDelegate controller:viewController viewDidAppear:animated];
        }
    });
    BOOL success = class_addMethod(cls, sel, imp, types);
    if (!success) {
        method_setImplementation(m, imp);
    }
}

//  - viewWillDisappear:
+ (void)XSLifeCircle_load_viewWillDisappear {
    Class cls = self.class;
    SEL sel = @selector(viewWillDisappear:);
    Method m = class_getInstanceMethod(cls, sel);
    const char *types = method_getTypeEncoding(m);
    IMP imp0 = method_getImplementation(m);
    
    IMP imp = imp_implementationWithBlock(^void(UIViewController *viewController, BOOL animated){
        ((void (*)(UIViewController *, SEL, BOOL))imp0)(viewController, sel, animated);
        if ([self.blockDelegate respondsToSelector:@selector(controller:viewWillDisappear:)]) {
            [self.blockDelegate controller:viewController viewWillDisappear:animated];
        }
    });
    BOOL success = class_addMethod(cls, sel, imp, types);
    if (!success) {
        method_setImplementation(m, imp);
    }
}

//  - viewDidDisappear:
+ (void)XSLifeCircle_load_viewDidDisappear {
    Class cls = self.class;
    SEL sel = @selector(viewDidDisappear:);
    Method m = class_getInstanceMethod(cls, sel);
    const char *types = method_getTypeEncoding(m);
    IMP imp0 = method_getImplementation(m);
    
    IMP imp = imp_implementationWithBlock(^void(UIViewController *viewController, BOOL animated){
        ((void (*)(UIViewController *, SEL, BOOL))imp0)(viewController, sel, animated);
        if ([self.blockDelegate respondsToSelector:@selector(controller:viewDidDisappear:)]) {
            [self.blockDelegate controller:viewController viewDidDisappear:animated];
        }
    });
    BOOL success = class_addMethod(cls, sel, imp, types);
    if (!success) {
        method_setImplementation(m, imp);
    }
}


//MARK: -   property

+ (id<XSControllerLifeCircle>)blockDelegate {
    return objc_getAssociatedObject(self, @selector(blockDelegate));
}

+ (void)setBlockDelegate:(id<XSControllerLifeCircle>)blockDelegate {
    objc_setAssociatedObject(self, @selector(blockDelegate), blockDelegate, OBJC_ASSOCIATION_RETAIN);
}

@end
