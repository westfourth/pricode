//
//  UIView+XSShapeLayer.h
//  TextKit
//
//  Created by xisi on 2022/5/12.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

/**
    @note   fillColor在backgroundColor上面。
    @note   UILabel的layer为_UILabelLayer，不适用。
 */
@interface UIView (XSShapeLayer)

/**
 setter方法会把这个View的layer由CALayer改为CAShapeLayer。
 这个block在layoutSubviews插入一段代码，bounds为此view.bounds
 */
@property (nullable, nonatomic) void (^shapeLayerBlock)(CAShapeLayer *layer, CGRect bounds);

@end

NS_ASSUME_NONNULL_END
