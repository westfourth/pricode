//
//  UITextField+XSInput.m
//  TextKit
//
//  Created by hanxin on 2022/1/30.
//

#import "UITextField+XSInput.h"
#import <objc/runtime.h>

@implementation UITextField (XSInput)

+ (void)load {
    Class cls = [self class];
    //  B48@0:8{_NSRange=QQ}16@32^B40
    SEL sel = sel_registerName("_delegateShouldChangeCharactersInTextStorageRange:replacementString:delegateCares:");
    Method m = class_getInstanceMethod(cls, sel);
    IMP imp0 = method_getImplementation(m);
    IMP imp1 = imp_implementationWithBlock(^BOOL(UITextField *self, NSRange range, NSString *string, BOOL *cares) {
        BOOL shouldChange = ((BOOL (*)(UITextField*, SEL, NSRange, NSString*, BOOL*))imp0)(self, sel, range, string, cares);
        if ([self.delegate respondsToSelector:@selector(textField:shouldChangeCharactersInRange:replacementString:)]) {
            return shouldChange;
        }
        return [self input_override_delegateShouldChangeCharactersInTextStorageRange:range replacementString:string delegateCares:cares];
    });
    method_setImplementation(m, imp1);
}

- (BOOL)input_override_delegateShouldChangeCharactersInTextStorageRange:(NSRange)range replacementString:(NSString *)string delegateCares:(BOOL *)cares {
    /**
     当 range.length == 0 时，表示添加；
     当 range.length != 0 时，表示删除；
     */
    BOOL allow = YES, max = YES;
    if (string.length > 0) {        //  添加字符
        if (self.allowedCharacterSet) {
            NSCharacterSet *set = [NSCharacterSet characterSetWithCharactersInString:string];
            allow = [self.allowedCharacterSet isSupersetOfSet:set];
        }
        if (self.maxLength > 0) {
            NSString *destString = [NSString stringWithFormat:@"%@%@", self.text, string];
            max = destString.length <= self.maxLength;
        }
    }
    return allow && max;
}


// MARK: -  property

- (NSCharacterSet *)allowedCharacterSet {
    return objc_getAssociatedObject(self, @selector(allowedCharacterSet));
}

- (void)setAllowedCharacterSet:(NSCharacterSet *)allowedCharacterSet {
    objc_setAssociatedObject(self, @selector(allowedCharacterSet), allowedCharacterSet, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
}

- (NSUInteger)maxLength {
    return [objc_getAssociatedObject(self, @selector(maxLength)) unsignedIntegerValue];
}

- (void)setMaxLength:(NSUInteger)maxLength {
    objc_setAssociatedObject(self, @selector(maxLength), @(maxLength), OBJC_ASSOCIATION_ASSIGN);
}

@end




@implementation NSCharacterSet (XSInput)

+ (NSCharacterSet *)pinyin9CharacterSet {
    return [NSCharacterSet characterSetWithCharactersInString:@"➋➌➍➎➏➐➑➒"];
}

+ (NSCharacterSet *)bihuaCharacterSet {
    return [NSCharacterSet characterSetWithCharactersInString:@"⼀⼁⼃⼂乛問"];
}

@end
