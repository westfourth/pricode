//
//  UIImage+XSPDF.m
//  WebView
//
//  Created by xisi on 2024/6/13.
//

#import "UIImage+XSPDF.h"

@implementation UIImage (XSPDF)

/**
    从PDF指定page生成图片
 
    @param  page 从1开始
 
    @param  bundle      bundle = nil时为mainBundle。
 */
+ (nullable UIImage *)pdfImageNamed:(NSString *)name inBundle:(nullable NSBundle *)bundle page:(NSInteger)page {
    NSBundle *bundle2 = bundle ? bundle : [NSBundle mainBundle];
    NSString *path = [bundle2 pathForResource:name ofType:nil];
    return [self pdfImageWithContentsOfFile:path page:page];
}

+ (nullable UIImage *)pdfImageWithContentsOfFile:(NSString *)path page:(NSInteger)page {
    NSData *data = [NSData dataWithContentsOfFile:path];
    return [self pdfImageWithData:data page:page];
}

+ (nullable UIImage *)pdfImageWithData:(NSData *)pdfData page:(NSInteger)page {
    UIImage *image = nil;
    CFDataRef data = CFBridgingRetain(pdfData);
    CGDataProviderRef provider = CGDataProviderCreateWithCFData(data);
    CGPDFDocumentRef doc = CGPDFDocumentCreateWithProvider(provider);
    
    size_t count = CGPDFDocumentGetNumberOfPages(doc);
    if (page > 0 && page <= count) {
        CGPDFPageRef pageRef = CGPDFDocumentGetPage(doc, page);
        CGPDFPageRetain(pageRef);
        CGRect rect = CGPDFPageGetBoxRect(pageRef, kCGPDFMediaBox);
        
        UIGraphicsBeginImageContextWithOptions(rect.size, NO, 0);
        CGContextRef context = UIGraphicsGetCurrentContext();
        
        //  左下角坐标系 转为 左上角坐标系
        CGContextTranslateCTM(context, 0, rect.size.height);
        CGContextScaleCTM(context, 1, -1);
        
        CGContextDrawPDFPage(context, pageRef);
        CGPDFPageRelease(pageRef);
        
        image = UIGraphicsGetImageFromCurrentImageContext();
        UIGraphicsEndImageContext();
    }
    
    CGPDFDocumentRelease(doc);
    CGDataProviderRelease(provider);
    CFRelease(data);
    return image;
}

@end
