//
//  UITextView+XSBlock.m
//  XSMultiSection
//
//  Created by xisi on 2023/7/24.
//

#import "UITextView+XSBlock.h"
#import <objc/runtime.h>

@implementation UITextView (XSBlock)

//MARK: -   updateDelegates

- (void)updateDelegates {
    if (self.delegate != (id<UITextViewDelegate>)self.class) {
        self.originDelegate = self.delegate;
        self.delegate = (id<UITextViewDelegate>)self.class;
    }
}

- (id<UITextViewDelegate>)originDelegate {
    return objc_getAssociatedObject(self, @selector(originDelegate));
}
- (void)setOriginDelegate:(id<UITextViewDelegate>)originDelegate {
    objc_setAssociatedObject(self, @selector(originDelegate), originDelegate, OBJC_ASSOCIATION_ASSIGN);
}


//MARK: -   delegate

+ (BOOL)textViewShouldBeginEditing:(UITextView *)textView {
    if ([textView.originDelegate respondsToSelector:@selector(textViewShouldBeginEditing:)]) {
        return [textView.originDelegate textViewShouldBeginEditing:textView];
    }
    if (textView.shouldBeginEditing) {
        textView.shouldBeginEditing(textView);
    }
    return YES;
}

+ (void)textViewDidBeginEditing:(UITextView *)textView {
    if ([textView.originDelegate respondsToSelector:@selector(textViewDidBeginEditing:)]) {
        return [textView.originDelegate textViewDidBeginEditing:textView];
    }
    if (textView.didBeginEditing) {
        textView.didBeginEditing(textView);
    }
}

+ (BOOL)textViewShouldEndEditing:(UITextView *)textView {
    if ([textView.originDelegate respondsToSelector:@selector(textViewShouldEndEditing:)]) {
        return [textView.originDelegate textViewShouldEndEditing:textView];
    }
    if (textView.shouldEndEditing) {
        textView.shouldEndEditing(textView);
    }
    return YES;
}

+ (void)textViewDidEndEditing:(UITextView *)textView {
    if ([textView.originDelegate respondsToSelector:@selector(textViewDidEndEditing:)]) {
        return [textView.originDelegate textViewDidEndEditing:textView];
    }
    if (textView.didEndEditing) {
        textView.didEndEditing(textView);
    }
}

+ (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text {
    if ([textView.originDelegate respondsToSelector:@selector(textView:shouldChangeTextInRange:replacementText:)]) {
        return [textView.originDelegate textView:textView shouldChangeTextInRange:range replacementText:text];
    }
    if (textView.shouldChangeText) {
        textView.shouldChangeText(textView, range, text);
    }
    return YES;
}

+ (void)textViewDidChange:(UITextView *)textView {
    if ([textView.originDelegate respondsToSelector:@selector(textViewDidChange:)]) {
        return [textView.originDelegate textViewDidChange:textView];
    }
    if (textView.didChangeText) {
        textView.didChangeText(textView);
    }
}


//MARK: -   other delegate

+ (void)textViewDidChangeSelection:(UITextView *)textView {
    if ([textView.originDelegate respondsToSelector:@selector(textViewDidChangeSelection:)]) {
        return [textView.originDelegate textViewDidChangeSelection:textView];
    }
}

+ (BOOL)textView:(UITextView *)textView shouldInteractWithURL:(NSURL *)URL inRange:(NSRange)characterRange interaction:(UITextItemInteraction)interaction {
    if ([textView.originDelegate respondsToSelector:@selector(textView:shouldInteractWithURL:inRange:interaction:)]) {
        return [textView.originDelegate textView:textView shouldInteractWithURL:URL inRange:characterRange interaction:interaction];
    }
    return YES;
}

+ (BOOL)textView:(UITextView *)textView shouldInteractWithTextAttachment:(NSTextAttachment *)textAttachment inRange:(NSRange)characterRange interaction:(UITextItemInteraction)interaction {
    if ([textView.originDelegate respondsToSelector:@selector(textView:shouldInteractWithTextAttachment:inRange:interaction:)]) {
        return [textView.originDelegate textView:textView shouldInteractWithTextAttachment:textAttachment inRange:characterRange interaction:interaction];
    }
    return YES;
}

+ (BOOL)textView:(UITextView *)textView shouldInteractWithURL:(NSURL *)URL inRange:(NSRange)characterRange {
    if ([textView.originDelegate respondsToSelector:@selector(textView:shouldInteractWithURL:inRange:)]) {
        return [textView.originDelegate textView:textView shouldInteractWithURL:URL inRange:characterRange];
    }
    return YES;
}

+ (BOOL)textView:(UITextView *)textView shouldInteractWithTextAttachment:(NSTextAttachment *)textAttachment inRange:(NSRange)characterRange {
    if ([textView.originDelegate respondsToSelector:@selector(textView:shouldInteractWithTextAttachment:inRange:)]) {
        return [textView.originDelegate textView:textView shouldInteractWithTextAttachment:textAttachment inRange:characterRange];
    }
    return YES;
}


//MARK: -   property

- (BOOL (^)(UITextView * _Nonnull))shouldBeginEditing {
    return objc_getAssociatedObject(self, @selector(shouldBeginEditing));
}
- (void)setShouldBeginEditing:(BOOL (^)(UITextView * _Nonnull))shouldBeginEditing {
    [self updateDelegates];
    objc_setAssociatedObject(self, @selector(shouldBeginEditing), shouldBeginEditing, OBJC_ASSOCIATION_COPY_NONATOMIC);
}

- (void (^)(UITextView * _Nonnull))didBeginEditing {
    return objc_getAssociatedObject(self, @selector(didBeginEditing));
}
- (void)setDidBeginEditing:(void (^)(UITextView * _Nonnull))didBeginEditing {
    [self updateDelegates];
    objc_setAssociatedObject(self, @selector(didBeginEditing), didBeginEditing, OBJC_ASSOCIATION_COPY_NONATOMIC);
}

- (BOOL (^)(UITextView * _Nonnull))shouldEndEditing {
    return objc_getAssociatedObject(self, @selector(shouldEndEditing));
}
- (void)setShouldEndEditing:(BOOL (^)(UITextView * _Nonnull))shouldEndEditing {
    [self updateDelegates];
    objc_setAssociatedObject(self, @selector(shouldEndEditing), shouldEndEditing, OBJC_ASSOCIATION_COPY_NONATOMIC);
}

- (void (^)(UITextView * _Nonnull))didEndEditing {
    return objc_getAssociatedObject(self, @selector(didEndEditing));
}
- (void)setDidEndEditing:(void (^)(UITextView * _Nonnull))didEndEditing {
    [self updateDelegates];
    objc_setAssociatedObject(self, @selector(didEndEditing), didEndEditing, OBJC_ASSOCIATION_COPY_NONATOMIC);
}

- (BOOL (^)(UITextView * _Nonnull, NSRange, NSString * _Nonnull))shouldChangeText {
    return objc_getAssociatedObject(self, @selector(shouldChangeText));
}
- (void)setShouldChangeText:(BOOL (^)(UITextView * _Nonnull, NSRange, NSString * _Nonnull))shouldChangeText {
    [self updateDelegates];
    objc_setAssociatedObject(self, @selector(shouldChangeText), shouldChangeText, OBJC_ASSOCIATION_COPY_NONATOMIC);
}

- (void (^)(UITextView * _Nonnull))didChangeText {
    return objc_getAssociatedObject(self, @selector(didChangeText));
}
- (void)setDidChangeText:(void (^)(UITextView * _Nonnull))didChangeText {
    [self updateDelegates];
    objc_setAssociatedObject(self, @selector(didChangeText), didChangeText, OBJC_ASSOCIATION_COPY_NONATOMIC);
}

@end
