//
//  UIImage+XSPDF.h
//  WebView
//
//  Created by xisi on 2024/6/13.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UIImage (XSPDF)

/**
    从PDF指定page生成图片
 
    @param  page 从1开始
 
    @param  bundle      bundle = nil时为mainBundle。
 */
+ (nullable UIImage *)pdfImageNamed:(NSString *)name inBundle:(nullable NSBundle *)bundle page:(NSInteger)page;

+ (nullable UIImage *)pdfImageWithContentsOfFile:(NSString *)path page:(NSInteger)page;

+ (nullable UIImage *)pdfImageWithData:(NSData *)pdfData page:(NSInteger)page;

@end

NS_ASSUME_NONNULL_END
