//
//  UITextField+XSTextInsets.m
//  TextKit
//
//  Created by hanxin on 2024/3/1.
//

#import "UITextField+XSTextInsets.h"
#import <objc/runtime.h>

@implementation UITextField (XSTextInsets)

+ (void)load {
    [self load_textInsets_textRectForBounds];
    [self load_textInsets_editingRectForBounds];
}

+ (void)load_textInsets_textRectForBounds {
    Class cls = [self class];
    SEL sel = @selector(textRectForBounds:);
    Method m = class_getInstanceMethod(cls, sel);
    IMP imp0 = method_getImplementation(m);
    
    IMP imp1 = imp_implementationWithBlock(^CGRect(UITextField *self, CGRect bounds) {
        CGRect rect = ((CGRect (*)(UITextField*, SEL, CGRect))imp0)(self, sel, bounds);
        CGRect rect2 = UIEdgeInsetsInsetRect(rect, self.textInsets);
        return rect2;
    });
    method_setImplementation(m, imp1);
}

+ (void)load_textInsets_editingRectForBounds {
    Class cls = [self class];
    SEL sel = @selector(editingRectForBounds:);
    Method m = class_getInstanceMethod(cls, sel);
    IMP imp0 = method_getImplementation(m);
    
    IMP imp1 = imp_implementationWithBlock(^CGRect(UITextField *self, CGRect bounds) {
        CGRect rect = ((CGRect (*)(UITextField*, SEL, CGRect))imp0)(self, sel, bounds);
        CGRect rect2 = UIEdgeInsetsInsetRect(rect, self.textInsets);
        return rect2;
    });
    method_setImplementation(m, imp1);
}


- (UIEdgeInsets)textInsets {
    NSValue *value = objc_getAssociatedObject(self, @selector(textInsets));
    return [value UIEdgeInsetsValue];
}

- (void)setTextInsets:(UIEdgeInsets)textInsets {
    NSValue *value = [NSValue valueWithUIEdgeInsets:textInsets];
    objc_setAssociatedObject(self, @selector(textInsets), value, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    [self setNeedsLayout];
}

@end
