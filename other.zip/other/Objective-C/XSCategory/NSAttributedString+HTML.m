//
//  NSAttributedString+HTML.m
//  TextKit
//
//  Created by hanxin on 2021/11/27.
//

#import "NSAttributedString+HTML.h"

@implementation NSAttributedString (HTML)

/// 从mainBundle的文件中生成属性文字。
+ (nullable instancetype)attributedTextWithHtmlFilename:(NSString *)htmlFilename cssFilename:(nullable NSString *)cssFilename {
    return [self attributedTextWithHtmlFilename:htmlFilename cssFilename:cssFilename bundle:[NSBundle mainBundle]];
}

/// 生成属性文字。会调用 attributedTextWithHtmlText: cssText:
+ (nullable instancetype)attributedTextWithHtmlFilename:(NSString *)htmlFilename cssFilename:(nullable NSString *)cssFilename bundle:(nullable NSBundle *)bundle {
    NSString *htmlText = [self textWithFilename:htmlFilename bundle:bundle];
    NSString *cssText = cssFilename ? [self textWithFilename:cssFilename bundle:bundle] : nil;
    return [self attributedTextWithHtmlText:htmlText cssText:cssText];
}

/// 从html、css内容生成属性文字
+ (nullable instancetype)attributedTextWithHtmlText:(NSString *)htmlText cssText:(nullable NSString *)cssText {
    if (htmlText == nil) {
        return nil;
    }
    
    NSMutableString *mutableText = [NSMutableString new];
    if (cssText) {
        [mutableText appendString:@"<style type=\"text/css\">"];
        [mutableText appendString:@"\n"];
        [mutableText appendString:cssText];
        [mutableText appendString:@"</style>"];
        [mutableText appendString:@"\n"];
    }
    [mutableText appendString:htmlText];
    
    NSData *data = [mutableText dataUsingEncoding:NSUnicodeStringEncoding];
    NSError *error = nil;
    NSAttributedString *attrText = [[NSAttributedString alloc] initWithData:data options:@{NSDocumentTypeDocumentAttribute: NSHTMLTextDocumentType} documentAttributes:nil error:&error];
    return attrText;
}

+ (nullable NSString *)textWithFilename:(NSString *)fileName bundle:(nullable NSBundle *)bundle {
    if (bundle == nil) {
        bundle = [NSBundle mainBundle];
    }
    NSString *path = [bundle pathForResource:fileName ofType:nil];
    NSError *error = nil;
    return [NSString stringWithContentsOfFile:path encoding:NSUTF8StringEncoding error:&error];
}

@end
