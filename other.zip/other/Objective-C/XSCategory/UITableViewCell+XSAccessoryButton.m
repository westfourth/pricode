//
//  UITableViewCell+XSAccessoryButton.m
//  TextKit
//
//  Created by hanxin on 2022/4/15.
//

#import "UITableViewCell+XSAccessoryButton.h"
#import <objc/runtime.h>

@implementation UITableViewCell (XSAccessoryButton)

+ (void)load {
    Class cls = [UITableViewCell class];
    SEL sel = @selector(layoutSubviews);
    Method m = class_getInstanceMethod(cls, sel);
    IMP imp0 = method_getImplementation(m);
    IMP imp1 = imp_implementationWithBlock(^void(UITableViewCell *self) {
        ((void (*)(UITableViewCell *, SEL))imp0)(self, sel);
        if (self.accessoryType == UITableViewCellAccessoryDisclosureIndicator ||
            self.accessoryType == UITableViewCellAccessoryCheckmark) {
            [self accessoryButton_override_layoutSubviews];
        }
    });
    method_setImplementation(m, imp1);
}

- (void)accessoryButton_override_layoutSubviews {
    if (self.accessoryButtonImage == nil &&
        CGSizeEqualToSize(self.accessoryButtonSize, CGSizeZero) &&
        UIEdgeInsetsEqualToEdgeInsets(self.accessoryButtonInsets, UIEdgeInsetsZero)) {
        return;
    }
    
    for (UIView *view in self.subviews) {
        if ([view isKindOfClass:NSClassFromString(@"_UITableCellAccessoryButton")]) {
            UIButton *button = (UIButton *)view;
            CGSize imageSize = CGSizeZero;
            if (self.accessoryType == UITableViewCellAccessoryDisclosureIndicator) {
                imageSize = CGSizeMake(10.33, 14);       //  默认大小
            } else if (self.accessoryType == UITableViewCellAccessoryCheckmark) {
                imageSize = CGSizeMake(19, 17.33);       //  默认大小
            }
            UIImage *image = self.accessoryButtonImage;
            if (image) {
                [button setBackgroundImage:image forState:UIControlStateNormal];
                imageSize = image.size;
            }
            if (!CGSizeEqualToSize(self.accessoryButtonSize, CGSizeZero)) {
                imageSize = self.accessoryButtonSize;
            }
            CGRect rect = CGRectMake(self.bounds.size.width - imageSize.width - 20,
                                     (self.bounds.size.height - imageSize.height) / 2.0,
                                     imageSize.width, imageSize.height);
            rect = UIEdgeInsetsInsetRect(rect, self.accessoryButtonInsets);
            button.frame = rect;
        }
    }
}


// MARK: -  property

- (UIImage *)accessoryButtonImage {
    return objc_getAssociatedObject(self, @selector(accessoryButtonImage));
}

- (void)setAccessoryButtonImage:(UIImage *)accessoryButtonImage {
    objc_setAssociatedObject(self, @selector(accessoryButtonImage), accessoryButtonImage, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
}

- (CGSize)accessoryButtonSize {
    NSValue *value = objc_getAssociatedObject(self, @selector(accessoryButtonSize));
    return [value CGSizeValue];
}

- (void)setAccessoryButtonSize:(CGSize)accessoryButtonSize {
    NSValue *value = [NSValue valueWithCGSize:accessoryButtonSize];
    objc_setAssociatedObject(self, @selector(accessoryButtonSize), value, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
}

- (UIEdgeInsets)accessoryButtonInsets {
    NSValue *value = objc_getAssociatedObject(self, @selector(accessoryButtonInsets));
    return [value UIEdgeInsetsValue];
}

- (void)setAccessoryButtonInsets:(UIEdgeInsets)accessoryButtonInsets {
    NSValue *value = [NSValue valueWithUIEdgeInsets:accessoryButtonInsets];
    objc_setAssociatedObject(self, @selector(accessoryButtonInsets), value, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
}

@end
