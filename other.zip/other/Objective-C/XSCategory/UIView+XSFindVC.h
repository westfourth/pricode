//
//  UIView+XSFindVC.h
//  PromiseKit
//
//  Created by xisi on 2022/9/17.
//

#import <UIKit/UIKit.h>

UIViewController * _Nullable current_view_controller(void);
UIViewController * _Nullable topmost_presented_view_controller(void);


/**
    重要：关于present的流程
    1. A --> B --> C，这是正常流程。
    2. A --> B，再 A --> C，不会弹出C，且程序不会崩溃。
 
 1. 如果是FullScreen模式
 
 @code
 Attempt to present <CViewController: 0x10a205710> on <AViewController: 0x10420f050> (from <AViewController: 0x10420f050>) whose view is not in the window hierarchy.
 @endcode
 
 2. 如果是Automatic模式
 
 @code
 Attempt to present <CViewController: 0x103f140e0> on <AViewController: 0x104906c70> (from <AViewController: 0x104906c70>) which is already presenting <BViewController: 0x103f0e540>.
 @endcode
 */

NS_ASSUME_NONNULL_BEGIN

@interface UIView (XSFindVC)

@property (readonly, nullable, nonatomic) UIViewController *viewController;

@property (readonly, nullable, nonatomic) UINavigationController *navigationController;

@property (readonly, nullable, nonatomic) UITabBarController *tabBarController;

@end

NS_ASSUME_NONNULL_END
