//
//  UILabel+XSClick.m
//  TextKit
//
//  Created by hanxin on 2021/11/27.
//

#import "UILabel+XSClick.h"
#import <objc/runtime.h>

NSAttributedStringKey const NSLink2AttributeName = @"NSLink2";

@implementation UILabel (XSClick)

//MARK: - 属性

- (UITapGestureRecognizer *)tapGesture {
    return objc_getAssociatedObject(self, @selector(tapGesture));
}

- (void)setTapGesture:(UITapGestureRecognizer *)tapGesture {
    objc_setAssociatedObject(self, @selector(tapGesture), tapGesture, OBJC_ASSOCIATION_RETAIN);
}

- (void (^)(NSURL * _Nonnull))clickURL {
    return objc_getAssociatedObject(self, @selector(clickURL));
}

- (void)setClickURL:(void (^)(NSURL * _Nonnull))clickURL {
    objc_setAssociatedObject(self, @selector(clickURL), clickURL, OBJC_ASSOCIATION_RETAIN);
    [self addTapGestureIfNeeded];
}

- (void (^)(NSDictionary * _Nonnull))clickAttributes {
    return objc_getAssociatedObject(self, @selector(clickAttributes));
}

- (void)setClickAttributes:(void (^)(NSDictionary * _Nonnull))clickAttributes {
    objc_setAssociatedObject(self, @selector(clickAttributes), clickAttributes, OBJC_ASSOCIATION_RETAIN);
    [self addTapGestureIfNeeded];
}


//MARK: - 手势处理

/// 添加tap手势
- (void)addTapGestureIfNeeded {
    //  已添加手势
    if (self.tapGesture) {
        return;
    }
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(handleTapGesture:)];
    [self addGestureRecognizer:tap];
    self.tapGesture = tap;
}

/// 处理tap手势
- (void)handleTapGesture:(UITapGestureRecognizer *)tap {
    NSTextStorage *textStorage = [NSTextStorage new];
    NSLayoutManager *layoutManager = [NSLayoutManager new];
    NSTextContainer *textContainer = [NSTextContainer new];

    [textStorage addLayoutManager:layoutManager];
    [layoutManager addTextContainer:textContainer];

    NSMutableAttributedString *attrText = [[NSMutableAttributedString alloc] initWithAttributedString:self.attributedText];
    [self addParagraphStyleIfNeed:attrText];
    [self addFontIfNeed:attrText];
    
    [textStorage setAttributedString:attrText];
    CGSize size = self.bounds.size;
    textContainer.size = CGSizeMake(size.width, ceil(size.height));
    textContainer.lineFragmentPadding = 0;
    textContainer.maximumNumberOfLines = self.numberOfLines;
    
    //  查找点击位置的字符在字符串中的位置
    CGRect usedRect = [layoutManager usedRectForTextContainer:textContainer];
    CGPoint point = [tap locationInView:tap.view];
    point.y -= (self.bounds.size.height - usedRect.size.height) / 2.0;
    NSUInteger index = [layoutManager glyphIndexForPoint:point inTextContainer:textContainer];
    NSLog(@">>> point = %@, index = %ld", NSStringFromCGPoint(point), index);
    
    //  该字符所在行的所有文字的CGRect
    NSRange range;
    CGRect rect = [layoutManager lineFragmentUsedRectForGlyphAtIndex:index effectiveRange:&range];
    if (CGRectContainsPoint(rect, point)) {
        //  查找该字符所在的属性
        NSDictionary *attrs = [self.attributedText attributesAtIndex:index effectiveRange:&range];
        if (attrs) {
            if (self.clickAttributes) {
                self.clickAttributes(attrs);
            }
            //  查找该字符所在的链接
            NSURL *url = attrs[NSLinkAttributeName];
            if (url && self.clickURL) {
                self.clickURL(url);
            }
            //  查找该字符所在的链接-2
            url = attrs[NSLink2AttributeName];
            if (url && self.clickURL) {
                self.clickURL(url);
            }
        }
    }
}


//MARK: - 添加必要的属性

/**
    UILabel的第一个文字的 NSMutableParagraphStyle.alignment 优先级比 UILabel.textAlignment 优先级更高
 */
- (void)addParagraphStyleIfNeed:(NSMutableAttributedString *)attrText {
    NSRange range;
    NSParagraphStyle *style0 = [attrText attribute:NSParagraphStyleAttributeName atIndex:0 effectiveRange:&range];
    if (style0) {
        return;
    }
    
    NSMutableParagraphStyle *style = [NSMutableParagraphStyle new];
    style.alignment = self.textAlignment;
    [attrText addAttributes:@{NSParagraphStyleAttributeName: style} range:NSMakeRange(0, attrText.length)];
}

/**
    如果没有检测到字体，则设置为 UILabel.font
 */
- (void)addFontIfNeed:(NSMutableAttributedString *)attrText {
    NSRange range;
    UIFont *font0 = [attrText attribute:NSFontAttributeName atIndex:0 effectiveRange:&range];
    if (font0) {
        return;
    }
    
    UIFont *font = self.font;
    [attrText addAttributes:@{NSFontAttributeName: font} range:NSMakeRange(0, attrText.length)];
}

@end
