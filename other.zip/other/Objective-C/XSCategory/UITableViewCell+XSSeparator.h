//
//  UITableViewCell+XSSeparator.h
//  TextKit
//
//  Created by hanxin on 2022/1/29.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UITableViewCell (XSSeparator)

/**
 只改变section-0、row-0的分割线
 
 正值缩小，负值变大。top为负值时，为高出cell底部的高度；bottom为负值时，为超出cell底部的高度。
 top、bottom都为0时，height = 1 / [UIScreen mainScreen].scale。
 */
@property (nonatomic) UIEdgeInsets separatorInset0;

/**
 当使用这个属性时，separatorInset属性失效。
 
 正值缩小，负值变大。top为负值时，为高出cell底部的高度；bottom为负值时，为超出cell底部的高度。
 top、bottom都为0时，height = 1 / [UIScreen mainScreen].scale。
 */
@property (nonatomic) UIEdgeInsets separatorInset2;

@end

NS_ASSUME_NONNULL_END
