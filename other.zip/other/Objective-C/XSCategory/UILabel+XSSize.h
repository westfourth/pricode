//
//  UILabel+XSSize.h
//  AAA
//
//  Created by xisi on 2021/11/18.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

/**
 NSString                  -  有文本、字体，才能确定大小
 NSAttributedString  -  有属性文字，才能确定大小
 */
@interface UILabel (XSSize)

/// 单行文字大小
- (CGSize)singleLineSize;

/// 多行文字大小
- (CGSize)multiLineSize:(CGFloat)width;

@end

NS_ASSUME_NONNULL_END
