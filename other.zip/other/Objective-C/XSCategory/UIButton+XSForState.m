//
//  UIButton+XSForState.m
//  Firefox
//
//  Created by hanxin on 2022/01/15.
//  Copyright © 2021 hanxin. All rights reserved.
//

#import "UIButton+XSForState.h"
#import <objc/runtime.h>

@implementation UIButton (XSForState)

+ (void)load {
    Class cls = [UIButton class];
    SEL sel = @selector(layoutSubviews);
    Method m = class_getInstanceMethod(cls, sel);
    IMP imp0 = method_getImplementation(m);
    IMP imp1 = imp_implementationWithBlock(^void(UIButton *self) {
        CAGradientLayer *layer = [self gradientLayerForState:self.state];
        if (layer != nil) {
            CAGradientLayer *buttonLayer = (CAGradientLayer *)self.layer;
            buttonLayer.colors = layer.colors;
            buttonLayer.locations = layer.locations;
            buttonLayer.startPoint = layer.startPoint;
            buttonLayer.endPoint = layer.endPoint;
            buttonLayer.type = layer.type;
        }
        ((void (*)(UIButton *, SEL))imp0)(self, sel);
    });
    method_setImplementation(m, imp1);
}

- (void)setBackgroundColor:(nullable UIColor *)color forState:(UIControlState)state {
    CAGradientLayer *layer = [CAGradientLayer new];
    layer.colors = @[(__bridge id)color.CGColor, (__bridge id)color.CGColor];
    [self setGradientLayer:layer forState:state];
}

- (nullable UIColor *)backgroundColorForState:(UIControlState)state {
    CAGradientLayer *layer = [self gradientLayerForState:state];
    CGColorRef cgColor = (__bridge CGColorRef)(layer.colors.firstObject);
    return [UIColor colorWithCGColor:cgColor];
}

// MARK: -  CALayer左下角坐标系

- (void)setGradientLayer:(nullable CAGradientLayer *)layer forState:(UIControlState)state {
    [self changeLayerToGradientLayer];
    const void *key = [UIButton gradientLayerKeyForControlState:state];
    objc_setAssociatedObject(self, key, layer, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
}

- (nullable CAGradientLayer *)gradientLayerForState:(UIControlState)state {
    const void *key = [UIButton gradientLayerKeyForControlState:state];
    return objc_getAssociatedObject(self, key);
}

- (void)changeLayerToGradientLayer {
    Class cls1 = object_getClass(self.layer);
    Class cls2 = [CAGradientLayer class];
    if (cls1 != cls2) {
        object_setClass(self.layer, cls2);
    }
}

/**
    key 所在的内存地址必须一致。以下就不行：
    @code
        const void *key = [NSString stringWithFormat:@"kUIControlState%ld", state].UTF8String;
    @endcode
    因为每次调用，key的地址不一样。
 */
+ (const void *)gradientLayerKeyForControlState:(UIControlState)state {
    NSString *key = [NSString stringWithFormat:@"kGradientLayerControlState%ld", (long)state];
    SEL sel = sel_getUid(key.UTF8String);
    return sel;
}

@end
