//
//  UIColor+XSExtension.h
//  TextKit
//
//  Created by xisi on 2022/10/3.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UIColor (XSExtension)

@property(class, nonatomic, readonly) UIColor *randomColor;

@end

NS_ASSUME_NONNULL_END
