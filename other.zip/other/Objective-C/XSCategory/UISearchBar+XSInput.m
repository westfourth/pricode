//
//  UISearchBar+XSInput.m
//  TextKit
//
//  Created by xisi on 2022/5/26.
//

#import "UISearchBar+XSInput.h"
#import <objc/runtime.h>

@implementation UISearchBar (XSInput)

+ (void)load {
    Class cls = [self class];
    //  B40@0:8{_NSRange=QQ}16@32
    SEL sel = sel_registerName("_searchBarTextFieldShouldChangeCharactersInRange:replacementString:");
    Method m = class_getInstanceMethod(cls, sel);
    IMP imp0 = method_getImplementation(m);
    IMP imp1 = imp_implementationWithBlock(^BOOL(UISearchBar *self, NSRange range, NSString *string) {
        BOOL shouldChange = ((BOOL (*)(UISearchBar*, SEL, NSRange, NSString*))imp0)(self, sel, range, string);
        if ([self.delegate respondsToSelector:@selector(searchBar:shouldChangeTextInRange:replacementText:)]) {
            return shouldChange;
        }
        return [self input_override_searchBarTextFieldShouldChangeCharactersInRange:range replacementString:string];
    });
    method_setImplementation(m, imp1);
}

- (BOOL)input_override_searchBarTextFieldShouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
    /**
     当 range.length == 0 时，表示添加；
     当 range.length != 0 时，表示删除；
     */
    BOOL allow = YES, max = YES;
    if (range.length == 0) {        //  添加字符
        if (self.allowedCharacterSet) {
            NSCharacterSet *set = [NSCharacterSet characterSetWithCharactersInString:string];
            allow = [self.allowedCharacterSet isSupersetOfSet:set];
        }
        if (self.maxLength > 0) {
            NSString *destString = [NSString stringWithFormat:@"%@%@", self.text, string];
            max = destString.length <= self.maxLength;
        }
    }
    return allow && max;
}


// MARK: -  property

- (NSCharacterSet *)allowedCharacterSet {
    return objc_getAssociatedObject(self, @selector(allowedCharacterSet));
}

- (void)setAllowedCharacterSet:(NSCharacterSet *)allowedCharacterSet {
    objc_setAssociatedObject(self, @selector(allowedCharacterSet), allowedCharacterSet, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
}

- (NSUInteger)maxLength {
    return [objc_getAssociatedObject(self, @selector(maxLength)) unsignedIntegerValue];
}

- (void)setMaxLength:(NSUInteger)maxLength {
    objc_setAssociatedObject(self, @selector(maxLength), @(maxLength), OBJC_ASSOCIATION_ASSIGN);
}

@end
