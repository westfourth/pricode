//
//  UIButton+XSIntercept.m
//  TableView
//
//  Created by xisi on 2023/9/6.
//

#import "UIButton+XSIntercept.h"
#import <objc/runtime.h>

@implementation UIButton (XSIntercept)

+ (void)load {
    Class cls = self.class;
    SEL sel = @selector(sendAction:to:forEvent:);
    Method m = class_getInstanceMethod(cls, sel);
    const char *types = method_getTypeEncoding(m);
    IMP imp0 = method_getImplementation(m);
    IMP imp = imp_implementationWithBlock(^void(UIButton *button, SEL action, id target, UIEvent *event){
        ((void (*)(UIButton *, SEL, SEL, id, UIEvent *))imp0)(button, sel, action, target, event);
        NSArray *array = UIButton.intercepters;
        for (int i = 0; i < array.count; i++) {
            void (^block)(UIButton *) = array[i];
            block(button);
        }
    });
    BOOL success = class_addMethod(cls, sel, imp, types);
    if (!success) {
        method_setImplementation(m, imp);
    }
}

+ (void)addIntercepter:(void (^)(UIButton *))block {
    NSMutableArray *array = self.intercepters;
    if (array == nil) {
        array = [NSMutableArray new];
        self.intercepters = array;
    }
    [array addObject:block];
}

+ (void)removeIntercepter:(void (^)(UIButton *))block {
    [self.intercepters removeObject:block];
}

+ (NSMutableArray<void (^)(UIButton * _Nonnull)> *)intercepters {
    return objc_getAssociatedObject(self, @selector(intercepters));
}

+ (void)setIntercepters:(NSMutableArray<void (^)(UIButton * _Nonnull)> *)intercepters {
    objc_setAssociatedObject(self, @selector(intercepters), intercepters, OBJC_ASSOCIATION_RETAIN);
}

@end
