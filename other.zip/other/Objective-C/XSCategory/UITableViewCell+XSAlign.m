//
//  UITableViewCell+XSAlign.m
//  TextKit
//
//  Created by xisi on 2022/5/12.
//

#import "UITableViewCell+XSAlign.h"
#import <objc/runtime.h>

@implementation UITableViewCell (XSAlign)

+ (void)load {
    Class cls = [UITableViewCell class];
    SEL sel = @selector(layoutSubviews);
    Method m = class_getInstanceMethod(cls, sel);
    IMP imp0 = method_getImplementation(m);
    IMP imp1 = imp_implementationWithBlock(^void(UITableViewCell *self) {
        ((void (*)(UITableViewCell *, SEL))imp0)(self, sel);
        if (self.alignModel) {
            [self cell_align_override_layoutSubviews];
        }
    });
    method_setImplementation(m, imp1);
}

- (void)cell_align_override_layoutSubviews {
    //  imageView
    UIEdgeInsets imageEdgeInsets = self.alignModel.imageEdgeInsets;
    CGFloat imageHeight = self.bounds.size.height - imageEdgeInsets.top - imageEdgeInsets.bottom;
    CGFloat imageWidth = imageHeight * self.alignModel.imageRatio;
    CGRect imageRect = CGRectMake(imageEdgeInsets.left, imageEdgeInsets.top, imageWidth, imageHeight);
    self.imageView.frame = imageRect;
    
    //  textLabel
    UIEdgeInsets titleEdgeInsets = self.alignModel.titleEdgeInsets;
    CGFloat titleLeft = CGRectGetMaxX(imageRect) + titleEdgeInsets.left;
    CGFloat titleWidth = self.bounds.size.width - titleLeft - titleEdgeInsets.right;
    CGFloat titleHeight = self.bounds.size.height - titleEdgeInsets.top - titleEdgeInsets.bottom;
    CGRect titleRect = CGRectMake(titleLeft, titleEdgeInsets.top, titleWidth, titleHeight);
    self.textLabel.frame = titleRect;
}


//MARK: -   property

- (XSCellAlignModel *)alignModel {
    return objc_getAssociatedObject(self, @selector(alignModel));
}

- (void)setAlignModel:(XSCellAlignModel *)alignModel {
    objc_setAssociatedObject(self, @selector(alignModel), alignModel, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    [self setNeedsLayout];
}

@end



// MARK: - XSCellAlignModel

@implementation XSCellAlignModel

- (instancetype)init
{
    self = [super init];
    if (self) {
        self.imageRatio = 1;
    }
    return self;
}

@end
