//
//  UITextField+XSDisallowsEditing.h
//  Animation
//
//  Created by hanxin on 2022/8/23.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

/**
    @note 当delegate实现了这个方法（-textField: textFieldShouldBeginEditing:）时，这个类别的属性会失效
 */
@interface UITextField (XSDisallowsEditing)

//  默认为NO，也就是可以编辑
@property (nonatomic) BOOL disallowsEditing;

@end

NS_ASSUME_NONNULL_END
