//
//  UIButton+XSHitEdgeInsets.m
//  TextKit
//
//  Created by hanxin on 2022/8/4.
//

#import "UIButton+XSHitEdgeInsets.h"
#import <objc/runtime.h>

@implementation UIButton (XSHitEdgeInsets)

/**
 @note  如果这个类没有实现 pointInside:withEvent:，那么会找到 UIWindow.pointInside:withEvent:，
     因此需先增加，如果增加失败，说明已经实现了pointInside:withEvent:，这时候只需要插入代码即可
 */
+ (void)load {
    Class cls = [UIButton class];
    SEL sel = @selector(pointInside:withEvent:);
    Method m = class_getInstanceMethod(cls, sel);
    const char *types = method_getTypeEncoding(m);
    IMP imp0 = method_getImplementation(m);
    IMP imp1 = imp_implementationWithBlock(^BOOL(UIButton *self, CGPoint point, UIEvent *event) {
        if (UIEdgeInsetsEqualToEdgeInsets(self.hitEdgeInsets, UIEdgeInsetsZero)) {
            //  UIWindow.pointInside:withEvent:
            return ((BOOL (*)(UIButton *, SEL, CGPoint, UIEvent *))imp0)(self, sel, point, event);
        } else {
            //  UIButton.hitEdgeInsets_override_pointInside:withEvent:
            return [self hitEdgeInsets_override_pointInside:point withEvent:event];
        }
    });
    BOOL success = class_addMethod(cls, sel, imp1, types);
    if (!success) {
        method_setImplementation(m, imp1);
    }
}

- (BOOL)hitEdgeInsets_override_pointInside:(CGPoint)point withEvent:(nullable UIEvent *)event {
    CGRect rect = UIEdgeInsetsInsetRect(self.bounds, self.hitEdgeInsets);
    return CGRectContainsPoint(rect, point);
}


//MARK: -   property

- (UIEdgeInsets)hitEdgeInsets {
    NSValue *value = objc_getAssociatedObject(self, @selector(hitEdgeInsets));
    return [value UIEdgeInsetsValue];
}

- (void)setHitEdgeInsets:(UIEdgeInsets)hitEdgeInsets {
    NSValue *value = [NSValue valueWithUIEdgeInsets:hitEdgeInsets];
    objc_setAssociatedObject(self, @selector(hitEdgeInsets), value, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
}

@end
