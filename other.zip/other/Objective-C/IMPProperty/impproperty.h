//
//  impproperty.h
//  Markdown
//
//  Created by xisi on 2022/3/26.
//

#import <Foundation/Foundation.h>

/* UserDefaults方式优先级 > 内存方式优先级 */

// 用户身份，可选实现
NSString *impproperty_get_user_identifier(void);
void impproperty_set_user_identifier(NSString *identifier);

/**
 采用了此协议的 Class Property 将会被提供默认的getter、setter方法。
 
 支持：
 1. C语言基础类型（即NSNumber衍生类型）
 2. OC对象类型
 
 @note  如果已经提供了getter或setter方法，则默认的getter或setter方法就添加失败，也就没有了默认的getter、setter方法。
 @note  readonly 属性被忽略，请自行提供 \c readonly 属性的方法
 */
@protocol IMPClassProp <NSObject>
@end


/**
 参考 \c IMPClassProp，存储方式不同，区别
 
 IMPClassProp   -   内存
 IMPUserDefaultsClassProp   -   UserDefaults
 
 @note  \c IMPUserDefaultsClassProp 优先级比 \c IMPClassProp 更高
 */
@protocol IMPUserDefaultsClassProp <NSObject>
@end

/**
 采用了此协议的 Instance Property 将会被提供默认的getter、setter方法。
 
 支持：
 1. C语言基础类型（即NSNumber衍生类型）
 2. OC对象类型
 
 @note  如果已经提供了getter或setter方法，则默认的getter或setter方法就添加失败，也就没有了默认的getter、setter方法。
 */
@protocol IMPInstanceProp <NSObject>
@end


/**
 参考 \c IMPInstanceProp，存储方式不同，区别
 
 IMPInstanceProp   -   内存
 IMPUserDefaultsInstanceProp   -   UserDefaults
 
 @note  \c IMPUserDefaultsInstanceProp 优先级比 \c IMPInstanceProp 更高
 */
@protocol IMPUserDefaultsInstanceProp <NSObject>
@end
