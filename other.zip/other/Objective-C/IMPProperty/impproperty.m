//
//  impproperty.m
//  Markdown
//
//  Created by xisi on 2022/3/26.
//

#import "impproperty.h"
#import <objc/runtime.h>
#import <sys/time.h>
#import "property.h"

NSString *impproperty_get_user_identifier(void) {
    NSString *key = @"impproperty_get_user_identifier";
    return [NSUserDefaults.standardUserDefaults stringForKey:key];
}

void impproperty_set_user_identifier(NSString *identifier) {
    NSString *key = @"impproperty_get_user_identifier";
    [NSUserDefaults.standardUserDefaults setObject:identifier forKey:key];
}

/**
 imp getter 构建
 
 @param type    属性申明的类型
 @param sel     getter方法
 */
id impproperty_getter_block(char type, SEL sel) {
    id block = nil;
    switch (type) {
        case _C_CHR:
            block = ^char(id self) {
                return [objc_getAssociatedObject(self, sel) charValue];
            };
            break;
        case _C_UCHR:
            block = ^unsigned char(id self) {
                return [objc_getAssociatedObject(self, sel) unsignedCharValue];
            };
            break;
        case _C_SHT:
            block = ^short(id self) {
                return [objc_getAssociatedObject(self, sel) shortValue];
            };
            break;
        case _C_USHT:
            block = ^unsigned short(id self) {
                return [objc_getAssociatedObject(self, sel) unsignedShortValue];
            };
            break;
        case _C_INT:
            block = ^int(id self) {
                return [objc_getAssociatedObject(self, sel) intValue];
            };
            break;
        case _C_UINT:
            block = ^unsigned int(id self) {
                return [objc_getAssociatedObject(self, sel) unsignedIntValue];
            };
            break;
        case _C_LNG:
            block = ^long(id self) {
                return [objc_getAssociatedObject(self, sel) longValue];
            };
            break;
        case _C_ULNG:
            block = ^unsigned long(id self) {
                return [objc_getAssociatedObject(self, sel) unsignedLongValue];
            };
            break;
        case _C_LNG_LNG:
            block = ^long long(id self) {
                return [objc_getAssociatedObject(self, sel) longLongValue];
            };
            break;
        case _C_ULNG_LNG:
            block = ^unsigned long long(id self) {
                return [objc_getAssociatedObject(self, sel) unsignedLongLongValue];
            };
            break;
        case _C_FLT:
            block = ^float(id self) {
                return [objc_getAssociatedObject(self, sel) floatValue];
            };
            break;
        case _C_DBL:
            block = ^double(id self) {
                return [objc_getAssociatedObject(self, sel) doubleValue];
            };
            break;
        case _C_BOOL:
            block = ^BOOL(id self) {
                return [objc_getAssociatedObject(self, sel) boolValue];
            };
            break;
        default:
            block = ^id(id self) {
                return objc_getAssociatedObject(self, sel);
            };
            break;
    }
    return block;
}

/**
 imp setter 构建
 
 @param type    属性申明的类型
 @param sel     getter方法
 */
id impproperty_setter_block(char type, SEL sel) {
    id block = nil;
    switch (type) {
        case _C_CHR:
            block = ^void(id self, char value) {
                objc_setAssociatedObject(self, sel, @(value), OBJC_ASSOCIATION_ASSIGN);
            };
            break;
        case _C_UCHR:
            block = ^void(id self, unsigned char value) {
                objc_setAssociatedObject(self, sel, @(value), OBJC_ASSOCIATION_ASSIGN);
            };
            break;
        case _C_SHT:
            block = ^void(id self, short value) {
                objc_setAssociatedObject(self, sel, @(value), OBJC_ASSOCIATION_ASSIGN);
            };
            break;
        case _C_USHT:
            block = ^void(id self, unsigned short value) {
                objc_setAssociatedObject(self, sel, @(value), OBJC_ASSOCIATION_ASSIGN);
            };
            break;
        case _C_INT:
            block = ^void(id self, int value) {
                objc_setAssociatedObject(self, sel, @(value), OBJC_ASSOCIATION_ASSIGN);
            };
            break;
        case _C_UINT:
            block = ^void(id self, unsigned int value) {
                objc_setAssociatedObject(self, sel, @(value), OBJC_ASSOCIATION_ASSIGN);
            };
            break;
        case _C_LNG:
            block = ^void(id self, long value) {
                objc_setAssociatedObject(self, sel, @(value), OBJC_ASSOCIATION_ASSIGN);
            };
            break;
        case _C_ULNG:
            block = ^void(id self, unsigned long value) {
                objc_setAssociatedObject(self, sel, @(value), OBJC_ASSOCIATION_ASSIGN);
            };
            break;
        case _C_LNG_LNG:
            block = ^void(id self, long long value) {
                objc_setAssociatedObject(self, sel, @(value), OBJC_ASSOCIATION_ASSIGN);
            };
            break;
        case _C_ULNG_LNG:
            block = ^void(id self, unsigned long long value) {
                objc_setAssociatedObject(self, sel, @(value), OBJC_ASSOCIATION_ASSIGN);
            };
            break;
        case _C_FLT:
            block = ^void(id self, float value) {
                objc_setAssociatedObject(self, sel, @(value), OBJC_ASSOCIATION_ASSIGN);
            };
            break;
        case _C_DBL:
            block = ^void(id self, double value) {
                objc_setAssociatedObject(self, sel, @(value), OBJC_ASSOCIATION_ASSIGN);
            };
            break;
        case _C_BOOL:
            block = ^void(id self, BOOL value) {
                objc_setAssociatedObject(self, sel, @(value), OBJC_ASSOCIATION_ASSIGN);
            };
            break;
        default:
            block = ^void(id self, id value) {
                objc_setAssociatedObject(self, sel, value, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
            };
            break;
    }
    return block;
}

id impproperty_user_defaults_getter_block(char type, SEL sel, Class cls) {
    const char sign = class_isMetaClass(cls) ? '+' : '-';
    NSString *key = [NSString stringWithFormat:@"%c[%s %s] %@", sign, class_getName(cls), sel_getName(sel), impproperty_get_user_identifier()];
    id block = nil;
    switch (type) {
        case _C_CHR: {
            block = ^char(id self) {
                return [[[NSUserDefaults standardUserDefaults] objectForKey:key] charValue];
            };
            break;
        }
        case _C_UCHR: {
            block = ^unsigned char(id self) {
                return [[[NSUserDefaults standardUserDefaults] objectForKey:key] unsignedCharValue];
            };
            break;
        }
        case _C_SHT: {
            block = ^short(id self) {
                return [[[NSUserDefaults standardUserDefaults] objectForKey:key] shortValue];
            };
            break;
        }
        case _C_USHT: {
            block = ^unsigned short(id self) {
                return [[[NSUserDefaults standardUserDefaults] objectForKey:key] unsignedShortValue];
            };
            break;
        }
        case _C_INT: {
            block = ^int(id self) {
                return [[[NSUserDefaults standardUserDefaults] objectForKey:key] intValue];
            };
            break;
        }
        case _C_UINT: {
            block = ^unsigned int(id self) {
                return [[[NSUserDefaults standardUserDefaults] objectForKey:key] unsignedIntValue];
            };
            break;
        }
        case _C_LNG: {
            block = ^long(id self) {
                return [[[NSUserDefaults standardUserDefaults] objectForKey:key] longValue];
            };
            break;
        }
        case _C_ULNG: {
            block = ^unsigned long(id self) {
                return [[[NSUserDefaults standardUserDefaults] objectForKey:key] unsignedLongValue];
            };
            break;
        }
        case _C_LNG_LNG: {
            block = ^long long(id self) {
                return [[[NSUserDefaults standardUserDefaults] objectForKey:key] longLongValue];
            };
            break;
        }
        case _C_ULNG_LNG: {
            block = ^unsigned long long(id self) {
                return [[[NSUserDefaults standardUserDefaults] objectForKey:key] unsignedLongLongValue];
            };
            break;
        }
        case _C_FLT: {
            block = ^float(id self) {
                return [[[NSUserDefaults standardUserDefaults] objectForKey:key] floatValue];
            };
            break;
        }
        case _C_DBL: {
            block = ^double(id self) {
                return [[[NSUserDefaults standardUserDefaults] objectForKey:key] doubleValue];
            };
            break;
        }
        case _C_BOOL: {
            block = ^BOOL(id self) {
                return [[[NSUserDefaults standardUserDefaults] objectForKey:key] boolValue];
            };
            break;
        }
        default:
            block = ^id(id self) {
                return [[NSUserDefaults standardUserDefaults] objectForKey:key];
            };
            break;
    }
    return block;
}

id impproperty_user_defaults_setter_block(char type, SEL sel, Class cls) {
    const char sign = class_isMetaClass(cls) ? '+' : '-';
    NSString *key = [NSString stringWithFormat:@"%c[%s %s] %@", sign, class_getName(cls), sel_getName(sel), impproperty_get_user_identifier()];
    id block = nil;
    switch (type) {
        case _C_CHR: {
            block = ^void(id self, char value) {
                [[NSUserDefaults standardUserDefaults] setObject:@(value) forKey:key];
            };
            break;
        }
        case _C_UCHR: {
            block = ^void(id self, unsigned char value) {
                [[NSUserDefaults standardUserDefaults] setObject:@(value) forKey:key];
            };
            break;
        }
        case _C_SHT: {
            block = ^void(id self, short value) {
                [[NSUserDefaults standardUserDefaults] setObject:@(value) forKey:key];
            };
            break;
        }
        case _C_USHT: {
            block = ^void(id self, unsigned short value) {
                [[NSUserDefaults standardUserDefaults] setObject:@(value) forKey:key];
            };
            break;
        }
        case _C_INT: {
            block = ^void(id self, int value) {
                [[NSUserDefaults standardUserDefaults] setObject:@(value) forKey:key];
            };
            break;
        }
        case _C_UINT: {
            block = ^void(id self, unsigned int value) {
                [[NSUserDefaults standardUserDefaults] setObject:@(value) forKey:key];
            };
            break;
        }
        case _C_LNG: {
            block = ^void(id self, long value) {
                [[NSUserDefaults standardUserDefaults] setObject:@(value) forKey:key];
            };
            break;
        }
        case _C_ULNG: {
            block = ^void(id self, unsigned long value) {
                [[NSUserDefaults standardUserDefaults] setObject:@(value) forKey:key];
            };
            break;
        }
        case _C_LNG_LNG: {
            block = ^void(id self, long long value) {
                [[NSUserDefaults standardUserDefaults] setObject:@(value) forKey:key];
            };
            break;
        }
        case _C_ULNG_LNG: {
            block = ^void(id self, unsigned long long value) {
                [[NSUserDefaults standardUserDefaults] setObject:@(value) forKey:key];
            };
            break;
        }
        case _C_FLT: {
            block = ^void(id self, float value) {
                [[NSUserDefaults standardUserDefaults] setObject:@(value) forKey:key];
            };
            break;
        }
        case _C_DBL: {
            block = ^void(id self, double value) {
                [[NSUserDefaults standardUserDefaults] setObject:@(value) forKey:key];
            };
            break;
        }
        case _C_BOOL: {
            block = ^void(id self, BOOL value) {
                [[NSUserDefaults standardUserDefaults] setObject:@(value) forKey:key];
            };
            break;
        }
        default:
            block = ^void(id self, id value) {
                [[NSUserDefaults standardUserDefaults] setObject:value forKey:key];
            };
            break;
    }
    return block;
}

/**
 给指定类的属性添加getter方法
 
 @param cls     要添加方法的类
 @param prop    要添加方法的属性
 @param userDefaults    是否是 \c IMPUserDefaults* 系列协议
 */
void impproperty_add_getter_method(Class cls, objc_property_t prop, BOOL userDefaults) {
    SEL sel = property_getter_sel(prop);
    const char *types = property_getter_types(prop);
    SEL getSel = sel;
    const char *getTypes = types;
    id block = nil;
    if (userDefaults) {
        block = impproperty_user_defaults_getter_block(getTypes[0], getSel, cls);
    } else {
        block = impproperty_getter_block(getTypes[0], getSel);
    }
    IMP imp = imp_implementationWithBlock(block);
    BOOL success = class_addMethod(cls, sel, imp, types);
    free((void *)types);
}

/**
 给指定类的属性添加setter方法
 
 @param cls     要添加方法的类
 @param prop    要添加方法的属性
 @param userDefaults    是否是 \c IMPUserDefaults* 系列协议
 */
void impproperty_add_setter_method(Class cls, objc_property_t prop, BOOL userDefaults) {
    SEL sel = property_setter_sel(prop);
    const char *types = property_setter_types(prop);
    SEL getSel = property_getter_sel(prop);
    const char *getTypes = property_getter_types(prop);
    id block = nil;
    if (userDefaults) {
        block = impproperty_user_defaults_setter_block(getTypes[0], getSel, cls);
    } else {
        block = impproperty_setter_block(getTypes[0], getSel);
    }
    IMP imp = imp_implementationWithBlock(block);
    BOOL success = class_addMethod(cls, sel, imp, types);
    free((void *)getTypes);
    free((void *)types);
}

/**
 列举指定类（类或元类）的所有属性
 
 @param cls     类或元类
 @param userDefaults    是否是 \c IMPUserDefaults* 系列协议
 */
void impproperty_class_list_property(Class cls, BOOL userDefaults) {
    unsigned int count = 0;
    objc_property_t *props = class_copyPropertyList(cls, &count);
    for (int i = 0; i < count; i++) {
        objc_property_t prop = props[i];
        if (property_is_readonly(prop)) {
            continue;
        }
        impproperty_add_getter_method(cls, prop, userDefaults);
        impproperty_add_setter_method(cls, prop, userDefaults);
    }
    free(props);
}


/**
 找出所有使用 \c IMPClassProp、IMPInstanceProp 协议的类。
 
 constructor 在 load 方法之后、main 方法之前执行
 */
__attribute__((constructor))
void impproperty(void) {
    struct timeval t1;
    gettimeofday(&t1, NULL);
    
    unsigned int count = 0;
    Class *classes = objc_copyClassList(&count);
    for (int i = 0; i < count; i++) {
        Class cls = classes[i];
        //  类属性
        if (class_conformsToProtocol(cls, @protocol(IMPUserDefaultsClassProp))) {
            impproperty_class_list_property(cls, YES);
        } else if (class_conformsToProtocol(cls, @protocol(IMPClassProp))) {
            impproperty_class_list_property(cls, NO);
        }
        //  实例属性
        if (class_conformsToProtocol(cls, @protocol(IMPUserDefaultsInstanceProp))) {
            const char *name = class_getName(cls);
            Class metaCls = objc_getMetaClass(name);
            impproperty_class_list_property(metaCls, YES);
        } else if (class_conformsToProtocol(cls, @protocol(IMPInstanceProp))) {
            const char *name = class_getName(cls);
            Class metaCls = objc_getMetaClass(name);
            impproperty_class_list_property(metaCls, NO);
        }
    }
    free(classes);
    
    struct timeval t2;
    gettimeofday(&t2, NULL);
    long sec = t2.tv_sec - t1.tv_sec;
    long usec = t2.tv_usec - t1.tv_usec;
    double cost =  sec + usec * 1e-6;
    printf(">>> impproperty time cost: %f\n", cost);
}
