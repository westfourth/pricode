//
//  UIScrollView+XSState.h
//  XSState
//
//  Created by xisi on 2019/11/1.
//  Copyright © 2019 mac. All rights reserved.
//

#import <UIKit/UIKit.h>
@protocol UIScrollViewAnimate;

NS_ASSUME_NONNULL_BEGIN

/**
    状态显示。
 
    @note   setView:forState: 会持有view
 */
@interface UIScrollView (XSState)

//  全局设置
+ (void)setClass:(nullable Class)cls forState:(NSInteger)state;
+ (nullable Class)classForState:(NSInteger)state;

+ (void)setNib:(nullable UINib *)nib forState:(NSInteger)state;
+ (nullable UINib *)nibForState:(NSInteger)state;


//  局部设置。改变view后，需要调用setState:方法刷新显示。局部设置的优先级大于全局设置。
- (void)setView:(nullable UIView<UIScrollViewAnimate> *)view forState:(NSInteger)state;
- (nullable UIView<UIScrollViewAnimate> *)viewForState:(NSInteger)state;

//  更新状态
@property (nonatomic) NSInteger state;

@end


/// 如果需要动画，实现该协议即可
@protocol UIScrollViewAnimate <NSObject>
@optional
- (void)startAnimating;
- (void)stopAnimating;
@end

NS_ASSUME_NONNULL_END
