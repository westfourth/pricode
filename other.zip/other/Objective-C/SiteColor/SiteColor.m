//
//  SiteColor.m
//  TextKit
//
//  Created by hanxin on 2022/1/4.
//

#import "SiteColor.h"
#import <objc/runtime.h>

#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wobjc-property-implementation"

static UIColor* rgb(UInt32 hex) {
    return [UIColor colorWithRed:((hex & 0xFF0000) >> 16)/255.0
                           green:((hex & 0xFF00) >> 8)/255.0
                            blue:((hex & 0xFF))/255.0
                           alpha:1.0];
}

@implementation SiteColor

+ (NSDictionary *)dict {
    static NSDictionary *dict = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        NSString *path = [[NSBundle mainBundle] pathForResource:@"SiteColor" ofType:@"plist"];
        dict = [NSDictionary dictionaryWithContentsOfFile:path];
    });
    return dict;
}

+ (NSString *)stringWithDict:(NSDictionary *)dict {
    NSInteger condition = 0;
    if (condition == 0) return dict[@"k"];
    if (condition == 1) return dict[@"yb"];
    if (condition == 2) return dict[@"kok"];
    if (condition == 3) return dict[@"hh"];
    if (condition == 4) return dict[@"fh"];
    if (condition == 5) return dict[@"hq"];
    if (condition == 6) return dict[@"ob"];
    if (condition == 7) return dict[@"aoa"];
    return dict[@"kok"];
}

+ (UIColor *)colorWithString:(NSString *)string {
    NSScanner *scanner = [NSScanner scannerWithString:string];
    unsigned int hex = 0;
    [scanner scanHexInt:&hex];
    char ch = 0;
    if (scanner.scanLocation < string.length) {
        do {
            ch = [string characterAtIndex:scanner.scanLocation];
            scanner.scanLocation++;
        } while (ch != ',' && scanner.scanLocation < string.length);
    }
    float alpha = 0;
    [scanner scanFloat:&alpha];
    UIColor *color = rgb(hex);
    if (alpha != 0) {
        color = [color colorWithAlphaComponent:alpha];
    }
    return color;
}

+ (void)load {
    Class cls = objc_getMetaClass("SiteColor");
    unsigned int count = 0;
    objc_property_t *props = class_copyPropertyList(cls, &count);
    for (int i = 0; i < count; i++) {
        objc_property_t prop = props[i];
        const char *name = property_getName(prop);
        SEL sel = sel_registerName(name);
        IMP imp = imp_implementationWithBlock(^UIColor*(id obj) {
            NSDictionary *dict = [SiteColor dict];
            NSDictionary *subDict = dict[@(name)];
            NSString *string = [SiteColor stringWithDict:subDict];
            UIColor *color = [SiteColor colorWithString:string];
            return color;
        });
        class_addMethod(cls, sel, imp, "@16@0:8");
    }
    free(props);
}

@end

#pragma clang diagnostic pop
