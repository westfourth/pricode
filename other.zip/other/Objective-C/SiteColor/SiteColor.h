//
//  SiteColor.h
//  TextKit
//
//  Created by hanxin on 2022/1/4.
//

#import <UIKit/UIKit.h>

#define PROPERTY_COLOR      @property (class, readonly, nonatomic) UIColor *


/**
    这里的 class getter 方法都是动态生成的。颜色配置文件为 SiteColor.plist
 */
@interface SiteColor : NSObject

//MARK: -   主题。适用范围：首页、全局主题按钮、选中态、主题图标

PROPERTY_COLOR  theme;              ///< 主题
PROPERTY_COLOR  gradientStart;      ///< 主题渐变左
PROPERTY_COLOR  gradientEnd;        ///< 主题渐变右
PROPERTY_COLOR  success;            ///< 成功
PROPERTY_COLOR  universal;          ///< 通用

//MARK: -   情景。适用范围：次级页面、全局模态控件、全局对话框、跳转文本、标题文本、内容文本

PROPERTY_COLOR  strong;             ///< 强调
PROPERTY_COLOR  normal;             ///< 常规
PROPERTY_COLOR  negative;           ///< 置灰
PROPERTY_COLOR  positive;           ///< 激活
PROPERTY_COLOR  warning;            ///< 警告

//MARK: -   通用。适用范围：背景、分隔线

PROPERTY_COLOR  background;         ///< 背景
PROPERTY_COLOR  cellBackground;     ///< cell背景
PROPERTY_COLOR  divide;             ///< 分割线

//MARK: -   文字颜色

PROPERTY_COLOR  textNormal;         ///< 正常
PROPERTY_COLOR  textHight;          ///< 高亮
PROPERTY_COLOR  textPrompt;         ///< 提示
PROPERTY_COLOR  attrTextNormal;     ///< 正常
PROPERTY_COLOR  attrTextHight;      ///< 高亮

@end
