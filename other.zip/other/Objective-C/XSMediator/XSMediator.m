//
//  XSMediator.m
//  OCTest2
//
//  Created by xisi on 2020/5/27.
//  Copyright © 2020 mac. All rights reserved.
//

#import "XSMediator.h"
#import <objc/runtime.h>

@implementation XSMediator

//  生成控制器（非nib、非storyboard方式）
+ (UIViewController *)vc:(NSString *)className params:(nullable NSDictionary *)params {
    Class cls = NSClassFromString(className);
    NSAssert1(cls != NULL, @"没有此控制器: %@", className);
    UIViewController *vc = [cls new];
    [self assignValueToVC:vc params:params];
    return vc;
}

//  nib方式生成控制器
+ (UIViewController *)nib:(NSString *)className params:(nullable NSDictionary *)params {
    Class cls = NSClassFromString(className);
    NSAssert1(cls != NULL, @"没有此控制器: %@", className);
    NSBundle *bundle = [NSBundle bundleForClass:cls];
    UIViewController *vc = [[cls alloc] initWithNibName:className bundle:bundle];
    [self assignValueToVC:vc params:params];
    return vc;
}

//  storyboard方式生成控制器。
+ (UIViewController *)storyboard:(NSString *)sbName className:(NSString *)className params:(nullable NSDictionary *)params {
    Class cls = NSClassFromString(className);
    NSAssert1(cls != NULL, @"没有此控制器: %@", className);
    NSBundle *bundle = [NSBundle bundleForClass:cls];
    UIStoryboard *s = [UIStoryboard storyboardWithName:sbName bundle:bundle];
    UIViewController *vc = [s instantiateViewControllerWithIdentifier:className];
    [self assignValueToVC:vc params:params];
    return vc;
}

//  为控制器的属性赋值
+ (void)assignValueToVC:(UIViewController *)vc params:(nullable NSDictionary *)params {
    unsigned int count = 0;
    objc_property_t *props = class_copyPropertyList([vc class], &count);
    for (unsigned int i = 0; i < count; i++) {
        objc_property_t prop = props[i];
        const char *name = property_getName(prop);
        NSString *key = [NSString stringWithUTF8String:name];
        //  没有此key，跳过；
        if (![params.allKeys containsObject:key]) {
            continue;
        }
        id value = params[key];
        [vc setValue:value forKey:key];
    }
    free(props);
}

@end
