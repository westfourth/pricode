//
//  XSMediator.h
//  OCTest2
//
//  Created by xisi on 2020/5/27.
//  Copyright © 2020 mac. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

/**
    简单的中介者模式，用于模块解藕。
    
    回调使用block。
 
    @warning    不建议使用，请使用XSCommand
 */
@interface XSMediator : NSObject

/**
    生成控制器（非nib、非storyboard方式）
    
    @param  className   控制器类名
    @param  params          控制器参数，params.key与viewController.property有相同名称才会赋值
 */
+ (UIViewController *)vc:(NSString *)className params:(nullable NSDictionary *)params;

/**
    nib方式生成控制器。
    
    @param  className   控制器类名
    @param  params          控制器参数，params.key与viewController.property有相同名称才会赋值
 
    @note   nib的名称与类的名称保持一致
 */
+ (UIViewController *)nib:(NSString *)className params:(nullable NSDictionary *)params;

/**
    storyboard方式生成控制器。
    
    @param  sbName          storyboard名称
    @param  className   控制器类名
    @param  params          控制器参数，params.key与viewController.property有相同名称才会赋值
 
    @note   storyboard ID 与类的名称保持一致
 */
+ (UIViewController *)storyboard:(NSString *)sbName className:(NSString *)className params:(nullable NSDictionary *)params;

@end

NS_ASSUME_NONNULL_END
