//
//  XSSegmentedControl.h
//  iOS-OC
//
//  Created by mac on 2020/11/12.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

/// 带有指示器的SegmentedControl
@interface XSSegmentedControl : UISegmentedControl

/// 底部选中指示器，默认：白色，显示
@property (readonly, nonatomic) UIView *indicatorLine;

/// 底部选中指示器尺寸，默认：{40, 3}
@property (nonatomic) CGSize indicatorLineSize;

/// 底部选中指示器位置调节，默认：{0, 0}
@property (nonatomic) UIOffset indicatorLineOffset;

/// 选中的视图的图片，默认：nil
@property(nullable, nonatomic) UIImage *selectedSegmentImage;

/// 调整选中的视图位置大小，默认：{0, 0, 0, 0}
@property(nonatomic) UIEdgeInsets selectedSegmentEdgeInsets;

/* 当设置 setBackgroundImage:forState:barMetrics: 后，不会生成选中视图，因此需要手动生成 */
@property (readonly, nonatomic) UIImageView *lazySelectionIndicatorImageView;
@property (nonatomic) UIEdgeInsets lazySelectionIndicatorEdgeInsets;


@property(nonatomic) BOOL adjustsFontSizeToFitWidth;        // default is NO
@property(nonatomic) CGFloat minimumScaleFactor;            // default is 0.0


@property (nullable, nonatomic) NSArray<NSString *> *segmentTitles;

- (void)animatedSetSelectedSegmentIndex:(NSInteger)index;

@end

NS_ASSUME_NONNULL_END
