//
//  XSSerialization.h
//  PromiseKit
//
//  Created by xisi on 2022/9/20.
//

#import <Foundation/Foundation.h>


#define JSON(s)     [XSJson objectWithFilename:@#s bundle:nil]
#define PLIST(s)    [XSPlist objectWithFilename:@#s bundle:nil]


/// 错误日志是否打开，默认：YES
static BOOL XSSerializationErrorLogEnabled;


NS_ASSUME_NONNULL_BEGIN

@protocol XSSerialization

+ (nullable NSData *)dataWithObject:(id)object;

+ (nullable id)objectWithData:(NSData *)data;

+ (nullable id)objectWithFilename:(NSString *)filename bundle:(nullable NSBundle *)bundle;

@end



@interface XSJson : NSObject <XSSerialization>
@end

@interface XSPlist : NSObject <XSSerialization>
@end

NS_ASSUME_NONNULL_END
