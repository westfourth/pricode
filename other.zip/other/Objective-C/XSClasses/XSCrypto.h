//
//  XSCrypto.h
//  OCCommand
//
//  Created by mac on 2021/2/4.
//  Copyright © 2021 mac. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CommonCrypto/CommonCrypto.h>

NS_ASSUME_NONNULL_BEGIN

@interface XSCrypto : NSObject

/**
    aes加解密
 
    @param  key     应该为16、24、32字节
 */
+ (nullable NSData *)aesCrypt:(NSData *)data opt:(CCOperation)opt key:(NSData *)key iv:(nullable NSData *)iv status:(CCCryptorStatus *)status;

@end

NS_ASSUME_NONNULL_END
