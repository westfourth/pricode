//
//  XSWebViewDefaultJSPanel.m
//  WebView
//
//  Created by xisi on 2024/6/14.
//

#import "XSWebViewDefaultJSPanel.h"
#import <objc/runtime.h>

@implementation XSWebViewDefaultJSPanel

/// 为所有的WKWebView提供默认的弹窗
+ (void)enable {
    Class cls = WKWebView.class;
    SEL sel = @selector(setUIDelegate:);
    
    Method m = class_getInstanceMethod(cls, sel);
    const char *types = method_getTypeEncoding(m);
    IMP imp0 = method_getImplementation(m);
    IMP imp = imp_implementationWithBlock(^void(WKWebView *webView, id<WKUIDelegate> delegate) {
        //  这里顺序不能反
        [XSWebViewDefaultJSPanel enableOn:delegate];
        ((void (*)(WKWebView *, SEL, id))imp0)(webView, sel, delegate);
    });
    BOOL success = class_addMethod(cls, sel, imp, types);
    if (!success) {
        method_setImplementation(m, imp);
    }
}

/// 为指定的WKWebView提供默认的弹窗
+ (void)enableOn:(id <WKUIDelegate>)delegate {
    NSAssert(delegate != nil, @"delegate不应该为nil");
    
    SEL sel1 = @selector(webView:runJavaScriptAlertPanelWithMessage:initiatedByFrame:completionHandler:);
    SEL sel2 = @selector(webView:runJavaScriptConfirmPanelWithMessage:initiatedByFrame:completionHandler:);
    SEL sel3 = @selector(webView:runJavaScriptTextInputPanelWithPrompt:defaultText:initiatedByFrame:completionHandler:);
    
    [self addMethodOn:delegate sel:sel1];
    [self addMethodOn:delegate sel:sel2];
    [self addMethodOn:delegate sel:sel3];
}

+ (void)addMethodOn:(id <WKUIDelegate>)delegate sel:(SEL)sel {
    Class cls = delegate.class;
    BOOL has = [delegate respondsToSelector:sel];
    if (has) {
        return;
    }
    
    Method m = class_getInstanceMethod(self.class, sel);
    const char *types = method_getTypeEncoding(m);
    IMP imp = method_getImplementation(m);
    __unused BOOL success = class_addMethod(cls, sel, imp, types);
    __unused BOOL has2 = [delegate respondsToSelector:sel];
}


//MARK: -   WKUIDelegate

//  alert弹窗
- (void)webView:(WKWebView *)webView runJavaScriptAlertPanelWithMessage:(NSString *)message initiatedByFrame:(WKFrameInfo *)frame completionHandler:(void (^)(void))completionHandler {
    puts(__func__);
    
    UIAlertController *alertVC = [UIAlertController alertControllerWithTitle:nil message:message preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction *action = [UIAlertAction actionWithTitle:@"关闭" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        completionHandler();
    }];
    
    [alertVC addAction:action];
    [topmost_presented_view_controller() presentViewController:alertVC animated:YES completion:nil];
}

//  confirm弹窗
- (void)webView:(WKWebView *)webView runJavaScriptConfirmPanelWithMessage:(NSString *)message initiatedByFrame:(WKFrameInfo *)frame completionHandler:(void (^)(BOOL))completionHandler {
    puts(__func__);
    
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:nil message:message preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction *okAction = [UIAlertAction actionWithTitle:@"好" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        completionHandler(YES);
    }];
    
    UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
        completionHandler(NO);
    }];

    [alertController addAction:okAction];
    [alertController addAction:cancelAction];
    [topmost_presented_view_controller() presentViewController:alertController animated:YES completion:nil];
}

//  prompt弹窗
- (void)webView:(WKWebView *)webView runJavaScriptTextInputPanelWithPrompt:(NSString *)prompt defaultText:(NSString *)defaultText initiatedByFrame:(WKFrameInfo *)frame completionHandler:(void (^)(NSString * _Nullable))completionHandler {
    puts(__func__);
    
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:nil message:prompt preferredStyle:UIAlertControllerStyleAlert];
    [alertController addTextFieldWithConfigurationHandler:^(UITextField * _Nonnull textField) {
        textField.placeholder = defaultText;
    }];
    
    UIAlertAction *okAction = [UIAlertAction actionWithTitle:@"好" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        UITextField *textField = alertController.textFields.firstObject;
        NSString *text = textField.text;
        completionHandler(text);
    }];
    UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
        completionHandler(nil);
    }];

    [alertController addAction:okAction];
    [alertController addAction:cancelAction];
    
    [topmost_presented_view_controller() presentViewController:alertController animated:YES completion:nil];
}

static UIViewController * _Nullable topmost_presented_view_controller(void) {
    UIViewController *currentVC = UIApplication.sharedApplication.keyWindow.rootViewController;
    while (currentVC.presentedViewController) {
        currentVC = currentVC.presentedViewController;
    }
    return currentVC;
}

@end
