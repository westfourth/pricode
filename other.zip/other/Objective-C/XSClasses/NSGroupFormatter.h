//
//  NSGroupFormatter.h
//  OCCommand
//
//  Created by hanxin on 2022/5/9.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSGroupFormatter : NSFormatter

/// 是否反序。举例，正序：1234-5678-9，反序：1-2345-6789
@property BOOL groupingReverse;
/// 每组多少个元素。默认：1
@property NSUInteger groupingSize;
/// 组与组之间的分隔符。默认：@""
@property NSString *groupingSeparator;

/// 是否使用星号代替
@property BOOL secureTextEnabled;
/// secureTextEntry开启时，左边明文个数
@property NSUInteger plainTextLeftCount;
/// secureTextEntry开启时，右边明文个数
@property NSUInteger plainTextRightCount;
///密文（星号）个数。密文个数不够时，补*；密文个数超出时，删*；
@property NSUInteger secureTextCount;

/// 格式化
- (nullable NSString *)format:(NSString *)string;

@end



//MARK: -   现成格式化工具

typedef NS_ENUM(NSUInteger, NSGroupFormatterBankCardType) {
    /// 明文，空格分割。例如：6214 8726 4917 4964
    NSGroupFormatterBankCardTypePlainAll,
    /// 左4位右4位明文，中间8位密文，空格分割。例如：6214 **** **** 4964
    NSGroupFormatterBankCardTypePlainLeftRight,
    /// 左12位密文，右4位明文，空格分割。例如：**** **** **** 4964
    NSGroupFormatterBankCardTypePlainRight,
};

@interface NSGroupFormatter (Convenience)

/// 手机号格式化。输出：138****1234
+ (instancetype)securePhoneFormatter;

/// 银行卡号格式化。
+ (instancetype)bankCardFormatter:(NSGroupFormatterBankCardType)type;

@end

NS_ASSUME_NONNULL_END
