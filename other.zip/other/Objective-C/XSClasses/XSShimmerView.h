//
//  XSShimmerLabel.h
//  Animation
//
//  Created by xisi on 2022/6/10.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface XSShimmerView : UIView

/// 是否使用动效
@property (nonatomic) BOOL shimmering;

/// 使用setter方法设置
@property (nullable, nonatomic) UIView *contentView;

@end

NS_ASSUME_NONNULL_END
