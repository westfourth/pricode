//
//  XSPostForm.m
//  OCCommand
//
//  Created by xisi on 2020/4/25.
//  Copyright © 2020 mac. All rights reserved.
//


/*  POST表上传单个文件格式
    +--------------------------------------------------------------------------+
    |  Content-type: multipart/form-data, boundary=AaB03x                      |
    |                                                                          |
    |  --AaB03x                                                                |
    |  content-disposition: form-data; name="field1"                           |
    |                                                                          |
    |  Joe Blow                                                                |
    |  --AaB03x                                                                |
    |  content-disposition: form-data; name="pics"; filename="file1.txt"       |
    |  Content-Type: text/plain                                                |
    |                                                                          |
    |  ... contents of file1.txt ...                                           |
    |  --AaB03x--                                                              |
    +--------------------------------------------------------------------------+
 */


/*  POST表单上传多个文件格式
    +--------------------------------------------------------------------------+
    |  Content-type: multipart/form-data, boundary=AaB03x                      |
    |                                                                          |
    |  --AaB03x                                                                |
    |  content-disposition: form-data; name="field1"                           |
    |                                                                          |
    |  Joe Blow                                                                |
    |  --AaB03x                                                                |
    |  content-disposition: form-data; name="pics"                             |
    |  Content-type: multipart/mixed, boundary=BbC04y                          |
    |                                                                          |
    |  --BbC04y                                                                |
    |  Content-disposition: attachment; filename="file1.txt"                   |
    |  Content-Type: text/plain                                                |
    |                                                                          |
    |  ... contents of file1.txt ...                                           |
    |  --BbC04y                                                                |
    |  Content-disposition: attachment; filename="file2.gif"                   |
    |  Content-type: image/gif                                                 |
    |  Content-Transfer-Encoding: binary                                       |
    |                                                                          |
    |  ...contents of file2.gif...                                             |
    |  --BbC04y--                                                              |
    |  --AaB03x--                                                              |
    +--------------------------------------------------------------------------+
 */


#import "XSPostForm.h"
#import <objc/runtime.h>
#if TARGET_OS_IOS
#import <CoreServices/UTType.h>
#endif

static inline NSString *XSContentTypeForPathExtension(NSString *extension) {
    NSString *UTI = (__bridge_transfer NSString *)UTTypeCreatePreferredIdentifierForTag(kUTTagClassFilenameExtension, (__bridge CFStringRef)extension, NULL);
    NSString *contentType = (__bridge_transfer NSString *)UTTypeCopyPreferredTagWithClass((__bridge CFStringRef)UTI, kUTTagClassMIMEType);
    return contentType ? contentType : @"application/octet-stream";
}


// MARK: -  XSUrlencodedForm

@implementation XSUrlencodedForm
@synthesize data = _data;

- (instancetype)init
{
    self = [super init];
    if (self) {
        _data = [NSMutableData new];
    }
    return self;
}

+ (nonnull instancetype)formWithDict:(nonnull NSDictionary<NSString *, id> *)dict {
    XSUrlencodedForm *form = [XSUrlencodedForm new];
    [dict enumerateKeysAndObjectsUsingBlock:^(NSString * _Nonnull key, NSString * _Nonnull obj, BOOL * _Nonnull stop) {
        [form appendValue:obj name:key];
    }];
    return form;
}

- (void)appendValue:(nonnull id)value name:(nonnull NSString *)name {
    //  添加连接字符
    if (_data.length) {
        [_data appendData:[@"&" dataUsingEncoding:NSUTF8StringEncoding]];
    }
    //  键值对
    NSString *text = [NSString stringWithFormat:@"%@=%@", name, value];
    [_data appendData:[text dataUsingEncoding:NSUTF8StringEncoding]];
}

- (NSString *)description {
    return [[NSString alloc] initWithData:_data encoding:NSUTF8StringEncoding];
}

@end


// MARK: -  XSMultipartForm

@implementation XSMultipartForm
@synthesize data = _data;

- (instancetype)init
{
    self = [super init];
    if (self) {
        _boundary = [NSUUID UUID].UUIDString;
        //  
        _data = [NSMutableData new];
        [_data appendData:[self beginData]];
        [_data appendData:[self endData]];
    }
    return self;
}

+ (nonnull instancetype)formWithDict:(nonnull NSDictionary<NSString *, id> *)dict {
    XSMultipartForm *form = [XSMultipartForm new];
    [dict enumerateKeysAndObjectsUsingBlock:^(NSString * _Nonnull key, NSString * _Nonnull obj, BOOL * _Nonnull stop) {
        [form appendValue:obj name:key];
    }];
    return form;
}

- (void)appendValue:(nonnull id)value name:(nonnull NSString *)name {
    NSMutableData *mData = [NSMutableData new];
    //  边界
    [mData appendData:[@"--" dataUsingEncoding:NSUTF8StringEncoding]];
    [mData appendData:[_boundary dataUsingEncoding:NSUTF8StringEncoding]];
    [mData appendData:[@"\r\n" dataUsingEncoding:NSUTF8StringEncoding]];
    //  Content-Disposition
    NSString *contentDisposition = [NSString stringWithFormat:@"Content-Disposition: form-data; name=\"%@\"", name];
    [mData appendData:[contentDisposition dataUsingEncoding:NSUTF8StringEncoding]];
    [mData appendData:[@"\r\n" dataUsingEncoding:NSUTF8StringEncoding]];
    //  空行
    [mData appendData:[@"\r\n" dataUsingEncoding:NSUTF8StringEncoding]];
    //  value
    [mData appendData:[[value description] dataUsingEncoding:NSUTF8StringEncoding]];
    [mData appendData:[@"\r\n" dataUsingEncoding:NSUTF8StringEncoding]];
    
    //  插入
    NSRange range = NSMakeRange(_data.length - [self endData].length, 0);
    [_data replaceBytesInRange:range withBytes:mData.bytes length:mData.length];
}

- (void)appendData:(NSData *)data name:(NSString *)name fileName:(NSString *)fileName {
    NSMutableData *mData = [NSMutableData new];
    //  边界
    [mData appendData:[@"--" dataUsingEncoding:NSUTF8StringEncoding]];
    [mData appendData:[_boundary dataUsingEncoding:NSUTF8StringEncoding]];
    [mData appendData:[@"\r\n" dataUsingEncoding:NSUTF8StringEncoding]];
    //  Content-Disposition
    NSString *contentDisposition = [NSString stringWithFormat:@"Content-Disposition: form-data; name=\"%@\"; filename=\"%@\"", name, fileName];
    [mData appendData:[contentDisposition dataUsingEncoding:NSUTF8StringEncoding]];
    [mData appendData:[@"\r\n" dataUsingEncoding:NSUTF8StringEncoding]];
    //  Content-Type
    NSString *type = XSContentTypeForPathExtension(fileName.pathExtension);
    NSString *contentType = [NSString stringWithFormat:@"Content-Type: %@", type];
    [mData appendData:[contentType dataUsingEncoding:NSUTF8StringEncoding]];
    [mData appendData:[@"\r\n" dataUsingEncoding:NSUTF8StringEncoding]];
    //  空行
    [mData appendData:[@"\r\n" dataUsingEncoding:NSUTF8StringEncoding]];
    //  value
    [mData appendData:data];
    [mData appendData:[@"\r\n" dataUsingEncoding:NSUTF8StringEncoding]];
    
    //  插入
    NSRange range = NSMakeRange(_data.length - [self endData].length, 0);
    [_data replaceBytesInRange:range withBytes:mData.bytes length:mData.length];
}

- (NSData *)beginData {
    return [@"\r\n" dataUsingEncoding:NSUTF8StringEncoding];
}

- (NSData *)endData {
    return [[NSString stringWithFormat:@"--%@--\r\n", _boundary] dataUsingEncoding:NSUTF8StringEncoding];
}

- (NSString *)description {
    return [[NSString alloc] initWithData:_data encoding:NSUTF8StringEncoding];
}

@end


// MARK: -  NSMutableURLRequest

@implementation NSMutableURLRequest (XSPostForm)

- (id<XSPostForm>)postForm {
    return objc_getAssociatedObject(self, @selector(postForm));
}

- (void)setPostForm:(id<XSPostForm>)postForm {
    objc_setAssociatedObject(self, @selector(postForm), postForm, OBJC_ASSOCIATION_RETAIN);
    //  如果是multipart/form-data，头部设置boundary
    if ([postForm isKindOfClass:[XSMultipartForm class]]) {
        NSString *contentType = [NSString stringWithFormat:@"multipart/form-data, boundary=%@", ((XSMultipartForm *)postForm).boundary];
        [self setValue:contentType forHTTPHeaderField:@"Content-Type"];
    }
    //  设置HTTPBody
    self.HTTPBody = postForm.data;
}

@end
