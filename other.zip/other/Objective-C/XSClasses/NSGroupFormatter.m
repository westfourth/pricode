//
//  NSGroupFormatter.m
//  OCCommand
//
//  Created by hanxin on 2022/5/9.
//

#import "NSGroupFormatter.h"

@implementation NSGroupFormatter

- (instancetype)init
{
    self = [super init];
    if (self) {
        _groupingSize = 1;
        _groupingSeparator = @"";
    }
    return self;
}

/// 格式化
- (nullable NSString *)format:(NSString *)string {
    if (self.secureTextEnabled) {
        string = [self secureText:string];
    }
    return [self groupingText:string];
}

/// 正序
- (nullable NSString *)groupingText:(NSString *)string {
    NSMutableString *mString = [NSMutableString new];
    for (NSInteger i = 0; i < string.length; i++) {
        NSString *subStr = [string substringWithRange:NSMakeRange(i, 1)];
        [mString appendString:subStr];
        NSInteger offset = self.groupingReverse ? self.groupingSize - string.length % self.groupingSize : 0;
        if ((i + 1 + offset) % self.groupingSize == 0) {
            //  尾不加*
            if (i < string.length - 1) {
                [mString appendString:self.groupingSeparator];
            }
        }
    }
    return [NSString stringWithString:mString];
}

/**
 对字符串加*
 
 举例，123456789  ->  1****6789
 */
- (NSString *)secureText:(NSString *)string {
    if (self.plainTextLeftCount + self.plainTextRightCount >= string.length) {
        return string;
    }
    NSRange range = NSMakeRange(self.plainTextLeftCount, string.length - (self.plainTextLeftCount + self.plainTextRightCount));
    NSUInteger count = self.secureTextCount > 0 ? self.secureTextCount : range.length;
    NSString *asteriskString = [[self class] asteriskWithCount:count];
    string = [string stringByReplacingCharactersInRange:range withString:asteriskString];
    return string;
}

/// 生成N个*符号
+ (NSString *)asteriskWithCount:(NSUInteger)count {
    NSMutableString *mString = [NSMutableString new];
    for (int i = 0; i < count; i++) {
        [mString appendString:@"*"];
    }
    return [NSString stringWithString:mString];
}

@end



//MARK: -   现成格式化工具

@implementation NSGroupFormatter (Convenience)

/// 手机号格式化。输出：138****1234
+ (instancetype)securePhoneFormatter; {
    NSGroupFormatter *f = [NSGroupFormatter new];
    f.secureTextEnabled = YES;
    f.plainTextLeftCount = 3;
    f.plainTextRightCount = 4;
    return f;
}

/// 银行卡号格式化。
+ (instancetype)bankCardFormatter:(NSGroupFormatterBankCardType)type {
    NSGroupFormatter *f = [NSGroupFormatter new];
    f.groupingSeparator = @" ";
    f.groupingSize = 4;
    
    switch (type) {
        case NSGroupFormatterBankCardTypePlainAll:
            break;
        case NSGroupFormatterBankCardTypePlainLeftRight:
            f.secureTextEnabled = YES;
            f.plainTextLeftCount = 4;
            f.plainTextRightCount = 4;
            f.secureTextCount = 8;
            break;
        case NSGroupFormatterBankCardTypePlainRight:
            f.secureTextEnabled = YES;
            f.plainTextRightCount = 4;
            f.secureTextCount = 12;
            break;
        default:
            break;
    }
    return f;
}

@end
