//
//  XSWebViewDefaultJSPanel.h
//  WebView
//
//  Created by xisi on 2024/6/14.
//

#import <UIKit/UIKit.h>
#import <WebKit/WebKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface XSWebViewDefaultJSPanel : NSObject

/**
    为所有的WKWebView提供默认的弹窗
 
    如果delegate实现了下面3个方法，则此类提供的这3个方式不生效。
 
    1. webView:runJavaScriptAlertPanelWithMessage:initiatedByFrame:completionHandler:
    2. webView:runJavaScriptConfirmPanelWithMessage:initiatedByFrame:completionHandler:
    3. webView:runJavaScriptTextInputPanelWithPrompt:defaultText:initiatedByFrame:completionHandler:
 */
+ (void)enable;

/**
    为指定的WKWebView提供默认的弹窗
 
    @warning 调用顺序要在设置UIDelegate之前

    @code
    [XSWebViewDefaultJSPanel enableOn:self];
    self.webView.UIDelegate = self;
    @endcode
 */
+ (void)enableOn:(id <WKUIDelegate>)delegate;

@end

NS_ASSUME_NONNULL_END
