//
//  XSSegmentedControl.m
//  iOS-OC
//
//  Created by mac on 2020/11/12.
//

#import "XSSegmentedControl.h"
#import <objc/runtime.h>
#import <objc/message.h>

//  实际上_selectionIndicatorView、_selectionImageView指向的是同一个地址
static NSString *kSelectionIndicatorViewKey = @"_selectionIndicatorView";       //  KVC
static NSString *kSelectionImageViewKey = @"_selectionImageView";               //  KVC
//  选中的视图比父视图更大
static UIEdgeInsets kSelectionEdgeInsets = {3, 3, 3, 3};


@interface XSSegmentedControl ()

//  选中的视图
@property (readonly, nullable, nonatomic) UIImageView *selectionIndicatorImageView;
//  选中的视图上的imageView
@property(nonatomic) UIImageView *selectedSegmentImageView;

@end


@implementation XSSegmentedControl
@synthesize lazySelectionIndicatorImageView = _lazySelectionIndicatorImageView;

//MARK: -   init

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self initConfig_];
    }
    return self;
}

- (instancetype)initWithCoder:(NSCoder *)coder
{
    self = [super initWithCoder:coder];
    if (self) {
        [self initConfig_];
    }
    return self;
}

- (instancetype)initWithItems:(NSArray *)items {
    self = [super initWithItems:items];
    if (self) {
        [self initConfig_];
    }
    return self;
}

//  下划线结束，防止重名防范覆盖
- (void)initConfig_ {
    [self changeDefaultSetting_];
    
    //
    _indicatorLineSize = CGSizeMake(50, 3);
    _selectedSegmentEdgeInsets = UIEdgeInsetsZero;
    //
    _selectedSegmentImageView = [UIImageView new];
    //
    _indicatorLine = [UIView new];
    _indicatorLine.backgroundColor = [UIColor whiteColor];
}

- (void)changeDefaultSetting_ {
    //  去掉选中颜色
    if (@available(iOS 13, *)) {
        self.selectedSegmentTintColor = [UIColor clearColor];
    }
    //  去掉背景图片后，self.selectionIndicatorImageView为nil
//    [self setBackgroundImage:[UIImage new] forState:UIControlStateNormal barMetrics:UIBarMetricsDefault];
    //  去掉分割线
    [self setDividerImage:[UIImage new] forLeftSegmentState:UIControlStateNormal rightSegmentState:UIControlStateNormal barMetrics:UIBarMetricsDefault];
}


//MARK: -   核心

- (void)layoutSubviews {
    [super layoutSubviews];
    [self getSelectionIndicatorImageView];
    [self updateSelectionIndicatorImageViewFrame:self.selectedSegmentIndex];
    [self adjustSegmentLabelsFont];
    
    CGRect bounds = self.selectionIndicatorImageView.bounds;
    bounds = UIEdgeInsetsInsetRect(bounds, kSelectionEdgeInsets);
    
    //  _selectedSegmentImageView
    CGRect segBounds = UIEdgeInsetsInsetRect(bounds, self.selectedSegmentEdgeInsets);
    self.selectedSegmentImageView.frame = segBounds;
    
    //  _indicatorLine
    CGPoint origin = CGPointMake((bounds.size.width - self.indicatorLineSize.width) / 2.0,
                                 bounds.size.height - self.indicatorLineSize.height);
    origin.x += kSelectionEdgeInsets.left;
//    origin.y -= kSelectionEdgeInsets.bottom;
    CGRect frame = (CGRect){.origin = origin, .size = self.indicatorLineSize};
    frame = CGRectOffset(frame, self.indicatorLineOffset.horizontal, self.indicatorLineOffset.vertical);
    self.indicatorLine.frame = frame;
    self.indicatorLine.layer.cornerRadius = CGRectGetHeight(self.indicatorLine.bounds) / 2;
}

- (void)updateSelectionIndicatorImageViewFrame:(NSInteger)index {
    if (self.selectionIndicatorImageView == self.lazySelectionIndicatorImageView) {
        NSInteger count = self.numberOfSegments;
        if (count == 0) {
            count = 1;
        }
        CGFloat itemWidth = self.bounds.size.width / count;
        CGRect frame = CGRectMake(itemWidth * index, 0, itemWidth, self.bounds.size.height);
        UIEdgeInsets negativeInset = UIEdgeInsetsMake(-kSelectionEdgeInsets.top, -kSelectionEdgeInsets.left, -kSelectionEdgeInsets.bottom, -kSelectionEdgeInsets.right);
        frame = UIEdgeInsetsInsetRect(frame, negativeInset);
        frame = UIEdgeInsetsInsetRect(frame, self.lazySelectionIndicatorEdgeInsets);
        self.selectionIndicatorImageView.frame = frame;
    }
}

//  获取选中的view。初始化的时候，该view为nil
- (void)getSelectionIndicatorImageView {
    //  实际上_selectionIndicatorView、_selectionImageView指向的是同一个地址
    UIImageView *view = [self valueForKey:kSelectionIndicatorViewKey];
    if (view == nil) {
        view = [self valueForKey:kSelectionImageViewKey];
    }
    if (view) {
        _selectionIndicatorImageView = view;
    } else {
        _selectionIndicatorImageView = self.lazySelectionIndicatorImageView;
        NSInteger index = self.subviews.count - self.numberOfSegments - 1;
        if (index < 0) index = 0;
        [self insertSubview:_selectionIndicatorImageView atIndex:index];
    }
    //
    [self.selectionIndicatorImageView addSubview:self.selectedSegmentImageView];
    [self.selectionIndicatorImageView addSubview:self.indicatorLine];
    
    if (self.selectedSegmentImage && self.selectedSegmentImageView.image == nil) {
        //  加载图片、解码图片是耗时操作，布局完再显示图片
        dispatch_async(dispatch_get_main_queue(), ^{
            self.selectedSegmentImageView.image = self.selectedSegmentImage;
        });
    }
}

- (id)valueForUndefinedKey:(NSString *)key {
    BOOL contain = [@[kSelectionIndicatorViewKey, kSelectionImageViewKey] containsObject:key];
    if (contain) return nil;
    return [super valueForUndefinedKey:key];
}


//  方法重载
- (void)_setSelectedSegmentIndex:(NSInteger)index notify:(BOOL)notify animate:(BOOL)animate {
    //  [super _cmd]
    void (^block)(void) = ^{
        struct objc_super s;
        s.receiver = self;
        s.super_class = [UISegmentedControl class];
        SEL sel = _cmd;
        ((void (*)(struct objc_super *, SEL, NSInteger, BOOL, BOOL))objc_msgSendSuper)(&s, sel, index, notify, animate);
    };
    
    if (animate) {     //  动画
        [UIViewPropertyAnimator runningPropertyAnimatorWithDuration:0.25 delay:0 options:UIViewAnimationOptionCurveEaseOut animations:^{
            [self updateSelectionIndicatorImageViewFrame:index];
        } completion:nil];
    }
    //
    block();
}

- (void)adjustSegmentLabelsFont {
    Class cls = objc_getClass("UISegmentLabel");
    for (UIView *a in self.subviews) {
        for (UIView *b in a.subviews) {
            if ([b isKindOfClass:cls]) {
                UILabel *label = (UILabel *)b;
                label.adjustsFontSizeToFitWidth = self.adjustsFontSizeToFitWidth;
                label.minimumScaleFactor = self.minimumScaleFactor;
            }
        }
    }
}


//MARK: -   getter

- (UIImageView *)lazySelectionIndicatorImageView {
    if (_lazySelectionIndicatorImageView == nil) {
        UIImageView *imageView = [UIImageView new];
        _lazySelectionIndicatorImageView = imageView;
    }
    return _lazySelectionIndicatorImageView;
}


//MARK: -   setter

- (void)setIndicatorLineSize:(CGSize)indicatorLineSize {
    _indicatorLineSize = indicatorLineSize;
    [self setNeedsLayout];
}

- (void)setIndicatorLineOffset:(UIOffset)indicatorLineOffset {
    _indicatorLineOffset = indicatorLineOffset;
    [self setNeedsLayout];
}

- (void)setSelectedSegmentImage:(UIImage *)selectedSegmentImage {
    _selectedSegmentImage = selectedSegmentImage;
    self.selectedSegmentImageView.image = selectedSegmentImage;
}

- (void)setSelectedSegmentEdgeInsets:(UIEdgeInsets)selectedSegmentEdgeInsets {
    _selectedSegmentEdgeInsets = selectedSegmentEdgeInsets;
    [self setNeedsLayout];
}

- (void)setLazySelectionIndicatorEdgeInsets:(UIEdgeInsets)lazySelectionIndicatorEdgeInsets {
    _lazySelectionIndicatorEdgeInsets = lazySelectionIndicatorEdgeInsets;
    [self setNeedsLayout];
}


//MARK: -   segmentTitles

- (NSArray<NSString *> *)segmentTitles {
    NSMutableArray *array = [NSMutableArray new];
    for (NSInteger i = 0; i < self.numberOfSegments; i++) {
        NSString *title = [self titleForSegmentAtIndex:i];
        [array addObject:title];
    }
    return array;
}

- (void)setSegmentTitles:(NSArray<NSString *> *)segmentTitles {
    //  移除
    for (NSInteger i = 0; i < self.numberOfSegments; i++) {
        [self removeSegmentAtIndex:i animated:NO];
        i--;
    }
    //  增加
    for (NSInteger i = 0; i < segmentTitles.count; i++) {
        NSString *title = segmentTitles[i];
        [self insertSegmentWithTitle:title atIndex:i animated:NO];
    }
}


//MARK: -   setSelectedSegmentIndex

- (void)animatedSetSelectedSegmentIndex:(NSInteger)index {
    [UIViewPropertyAnimator runningPropertyAnimatorWithDuration:0.25 delay:0 options:UIViewAnimationOptionCurveEaseOut animations:^{
        [self updateSelectionIndicatorImageViewFrame:index];
    } completion:^(UIViewAnimatingPosition finalPosition) {
        self.selectedSegmentIndex = index;
    }];
}

@end

