//
//  XSCrypto.m
//  OCCommand
//
//  Created by mac on 2021/2/4.
//  Copyright © 2021 mac. All rights reserved.
//

#import "XSCrypto.h"

@implementation XSCrypto

+ (nullable NSData *)aesCrypt:(NSData *)data opt:(CCOperation)opt key:(NSData *)key iv:(nullable NSData *)iv status:(CCCryptorStatus *)status {
    
    size_t bufferSize = data.length + kCCBlockSizeAES128;
    void *buffer = malloc(bufferSize);
    
    size_t cryptSize = 0;
    *status = CCCrypt(opt,
                      kCCAlgorithmAES,
                      kCCOptionPKCS7Padding,
                      key.bytes,
                      key.length,
                      iv.bytes,
                      data.bytes,
                      data.length,
                      buffer,
                      bufferSize,
                      &cryptSize);
    
    NSData *cryptData = [NSData dataWithBytes:buffer length:cryptSize];
    free(buffer);
    
    if (*status != kCCSuccess) {
        return nil;
    }
    return cryptData;
}

@end
