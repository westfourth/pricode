//
//  XSSerialization.m
//  PromiseKit
//
//  Created by xisi on 2022/9/20.
//

#import "XSSerialization.h"

static BOOL XSSerializationErrorLogEnabled = YES;

void SRLLog(NSString *format, ...) {
    if (XSSerializationErrorLogEnabled == NO) {
        return;
    }
    NSString *newFormat = [NSString stringWithFormat:@"\nXSSerialization >>> %@", format];
    va_list args;
    va_start(args, format);
    NSLogv(newFormat, args);
    va_end(args);
}


@implementation XSJson

+ (nullable NSData *)dataWithObject:(nonnull id)object {
    NSError *error = nil;
    NSData *data = [NSJSONSerialization dataWithJSONObject:object options:NSJSONWritingPrettyPrinted error:&error];
    if (error) SRLLog(@"%@", object);
    return data;
}

+ (nullable id)objectWithData:(nonnull NSData *)data {
    NSError *error = nil;
    id object = [NSJSONSerialization JSONObjectWithData:data options:0 error:&error];
    if (error) SRLLog(@"%@", object);
    return object;
}

+ (nullable id)objectWithFilename:(nonnull NSString *)filename bundle:(nullable NSBundle *)bundle {
    if (bundle == nil) bundle = [NSBundle mainBundle];
    NSString *path = [bundle pathForResource:filename ofType:nil];
    NSAssert1(path, @"文件：%@ 不存在", filename);
    NSData *data = [NSData dataWithContentsOfFile:path];
    id object = [self objectWithData:data];;
    return object;
}

@end



@implementation XSPlist

+ (nullable NSData *)dataWithObject:(nonnull id)object {
    NSError *error = nil;
    NSData *data = [NSPropertyListSerialization dataWithPropertyList:object format:NSPropertyListXMLFormat_v1_0 options:0 error:&error];
    if (error) SRLLog(@"%@", object);
    return data;
}

+ (nullable id)objectWithData:(nonnull NSData *)data {
    NSError *error = nil;
    NSPropertyListFormat format;
    id object = [NSPropertyListSerialization propertyListWithData:data options:0 format:&format error:&error];
    if (error) SRLLog(@"%@", object);
    return object;
}

+ (nullable id)objectWithFilename:(nonnull NSString *)filename bundle:(nullable NSBundle *)bundle {
    if (bundle == nil) bundle = [NSBundle mainBundle];
    NSString *path = [bundle pathForResource:filename ofType:nil];
    NSAssert1(path, @"文件：%@ 不存在", filename);
    NSData *data = [NSData dataWithContentsOfFile:path];
    id object = [self objectWithData:data];;
    return object;
}

@end
