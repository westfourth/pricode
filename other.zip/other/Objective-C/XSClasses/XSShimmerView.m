//
//  XSShimmerLabel.m
//  Animation
//
//  Created by xisi on 2022/6/10.
//

#import "XSShimmerView.h"

@implementation XSShimmerView

+ (Class)layerClass {
    return [CAGradientLayer class];
}

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        CAGradientLayer *layer = (CAGradientLayer *)self.layer;
        
        layer.startPoint = CGPointMake(0, 0.5);
        layer.endPoint = CGPointMake(1, 0.5);
        layer.locations = @[@-1, @-1, @0];
    }
    return self;
}

- (void)setShimmering:(BOOL)shimmering {
    if (shimmering) {
        CABasicAnimation *anim = [CABasicAnimation animationWithKeyPath:@"locations"];
        anim.fromValue = @[@-1, @-1, @0];
        anim.toValue = @[@1, @2, @2];
        anim.duration = 3;
        anim.repeatCount = INFINITY;
        
        [self.layer addAnimation:anim forKey:@"anim"];
    } else {
        [self.layer removeAllAnimations];
    }
}

- (void)setContentView:(UIView *)contentView {
    _contentView = contentView;
    self.layer.mask = contentView.layer;
    
    if ([contentView isKindOfClass:[UILabel class]]) {
        UILabel *label = (UILabel *)contentView;
        CAGradientLayer *layer = (CAGradientLayer *)self.layer;
        layer.colors = @[(__bridge id)label.textColor.CGColor,
                         (__bridge id)UIColor.yellowColor.CGColor,
                         (__bridge id)label.textColor.CGColor];
    }
}

- (void)layoutSubviews {
    [super layoutSubviews];
    self.contentView.layer.frame = self.bounds;
}

@end
