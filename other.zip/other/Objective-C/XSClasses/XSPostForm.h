//
//  XSPostForm.h
//  OCCommand
//
//  Created by xisi on 2020/4/25.
//  Copyright © 2020 mac. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

/**
    获取文件的Content-Type

    @param  extension       文件的扩展名，例如：png
    @return Content-Type，例如：image/png
 */
static inline NSString *XSContentTypeForPathExtension(NSString *extension);


// MARK: -  XSPostForm

@protocol XSPostForm <NSObject>

@property (readonly) NSMutableData *data;

/**
    直接从字典生成
 
    @param  dict    为<NSString *, NSString *>、<NSString *, NSNumber *>
 */
+ (instancetype)formWithDict:(NSDictionary<NSString *, id> *)dict;

/**
    添加name=field
    
    @param  value   为NSString、NSNumber
 */
- (void)appendValue:(id)value name:(NSString *)name;

@end


// MARK: -  XSUrlencodedForm

/// application/x-www-form-urlencoded
@interface XSUrlencodedForm : NSObject <XSPostForm>

@end


//MARK: -  XSMultipartForm

/// multipart/form-data.    参考：rfc1867
@interface XSMultipartForm : NSObject <XSPostForm>

@property (readonly) NSString *boundary;    //  表单boundary

/// 二进制数据。
- (void)appendData:(NSData *)data name:(NSString *)name fileName:(NSString *)fileName;

@end


// MARK: -  NSMutableURLRequest

@interface NSMutableURLRequest (XSPostForm)

@property (nullable) id<XSPostForm> postForm;

@end

NS_ASSUME_NONNULL_END
