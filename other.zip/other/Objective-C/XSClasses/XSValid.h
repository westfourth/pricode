//
//  XSValid.h
//  NavBar
//
//  Created by xisi on 2024/2/10.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface XSValid : NSObject

/// 有效手机号
+ (BOOL)validPhone:(NSString *)text;

/// 有效身份证
+ (BOOL)validIDCard:(NSString *)text;

/// 有效邮箱
+ (BOOL)validMail:(NSString *)text;

/// 有效URL
+ (BOOL)validURL:(NSString *)text;

@end

NS_ASSUME_NONNULL_END
