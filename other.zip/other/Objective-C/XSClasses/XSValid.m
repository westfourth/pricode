//
//  XSValid.m
//  NavBar
//
//  Created by xisi on 2024/2/10.
//

#import "XSValid.h"

@implementation XSValid

/// 有效手机号
+ (BOOL)validPhone:(NSString *)text {
    NSString *pattern = @"^1\\d{10}$";
    return [self validText:text pattern:pattern];
}

/// 有效身份证
+ (BOOL)validIDCard:(NSString *)text {
    NSString *pattern = @"^(\\d{15}$|^\\d{18}$|^\\d{17}(\\d|X|x))$";
    return [self validText:text pattern:pattern];
}

/// 有效邮箱
+ (BOOL)validMail:(NSString *)text {
    return NO;
}

/// 有效URL
+ (BOOL)validURL:(NSString *)text {
    return NO;
}

+ (BOOL)validText:(NSString *)text pattern:(NSString *)pattern {
    NSError *error = nil;
    NSRegularExpression *regexp = [NSRegularExpression regularExpressionWithPattern:pattern options:0 error:&error];
    NSAssert1(error == nil, @"正则表达式错误: %@", pattern);
    NSArray<NSTextCheckingResult *> *result = [regexp matchesInString:text options:0 range:NSMakeRange(0, text.length)];
    return result.count > 0;
}

@end
