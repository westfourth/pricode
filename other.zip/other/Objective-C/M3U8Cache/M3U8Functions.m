//
//  M3U8Function.m
//  M3U8Cache
//
//  Created by mac on 2020/2/22.
//  Copyright © 2020 mac. All rights reserved.
//

#import "M3U8Functions.h"
#import <GCDWebServer/GCDWebServerFunctions.h>
#import <UIKit/UIKit.h>

/// 将远程地址 转换成 本地地址
NSURL* M3U8LocalForRemote(NSURL* remoteURL, NSInteger port) {
    //  escape转码
    NSString *escapeURLString = GCDWebServerEscapeURLString(remoteURL.absoluteString);
    //  作为路径放在localhost后面
    NSString *localURLString = [NSString stringWithFormat:@"http://localhost:%ld/%@", port, escapeURLString];
    NSURL *localURL = [NSURL URLWithString:localURLString];
    return localURL;
}

/// 将本地地址 转换成 远程地址
NSURL* M3U8RemoteForLocal(NSURL* localURL) {
    NSString *escapeURLString = [localURL.path substringFromIndex:@"/".length];
    NSString *remoteURLString = GCDWebServerUnescapeURLString(escapeURLString);
    NSURL *remoteURL = [NSURL URLWithString:remoteURLString];
    return remoteURL;
}

/// 远程地址 对应 本地文件路径
NSString* M3U8LocalFilePath(NSURL* remoteURL) {
    NSString *fileName = remoteURL.absoluteString.lastPathComponent;
    NSString *localFilePath = [M3U8_CACHE_PATH stringByAppendingPathComponent:fileName];
    return localFilePath;
}


/// 当服务器key与ts不在同一个目录下时，需要用此函数修正到正确的位置。
NSString* M3U8KeyParentPath(NSURL *url, NSString *key) {
    NSString *parentPath = nil;
    //  公司的m3u8文件与ts文件不在同一个目录下
    if ([key isEqualToString:@"/api/m3u8/enc/key"]) {
        if (url.port) {
            parentPath = [NSString stringWithFormat:@"%@://%@:%@", url.scheme, url.host, url.port];
        } else {
            parentPath = [NSString stringWithFormat:@"%@://%@", url.scheme, url.host];
        }
    }
    return parentPath;
}

//  马甲包版本号
NSString* vestBagVersion() {
    NSString *v = [[NSBundle mainBundle] infoDictionary][@"VestBag"];
    NSRange range = [v rangeOfString:@"-"];
    NSString *v1 = [v substringFromIndex:range.location + 1];
    return v1;
}

/// 为网络请求添加额外信息
NSMutableURLRequest* M3U8RequestAddAdditionalInfo(NSMutableURLRequest *request) {
    //  Authorization
    NSString *token = [NSUserDefaults.standardUserDefaults stringForKey:@"token"];
    [request setValue:token forHTTPHeaderField:@"Authorization"];
    //  User-Agent
    NSString *iosVersion = [[UIDevice currentDevice] systemVersion];
    NSString *bagVersion = vestBagVersion();
    NSString *agent = [NSString stringWithFormat:@"Mozilla/5.0 (iPhone; CPU iPhone OS %@ like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15F79;ver=%@", iosVersion, bagVersion];
    [request setValue:agent forHTTPHeaderField:@"User-Agent"];
    return request;
}
