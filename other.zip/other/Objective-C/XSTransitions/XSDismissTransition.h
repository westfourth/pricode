//
//  XSDismissTransition.h
//  Transitions
//
//  Created by xisi on 2022/1/19.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface XSDismissTransition : NSObject <UIViewControllerAnimatedTransitioning>

// MARK: -  对UITabBarController的支持

+ (void)viewController:(UIViewController *)vc pan:(UIPanGestureRecognizer *)pan percentTransition:(UIPercentDrivenInteractiveTransition * __strong _Nullable * _Nullable)percentTransition;

@end

NS_ASSUME_NONNULL_END
