//
//  XSTabBarTransition.m
//  Transitions
//
//  Created by xisi on 2022/1/19.
//

#import "XSTabBarTransition.h"

@implementation XSTabBarTransition

- (NSTimeInterval)transitionDuration:(nullable id<UIViewControllerContextTransitioning>)transitionContext {
    return 0.25;
}

- (void)animateTransition:(nonnull id<UIViewControllerContextTransitioning>)transitionContext {
    UIViewController *fromVC = [transitionContext viewControllerForKey:UITransitionContextFromViewControllerKey];
    UIViewController *toVC = [transitionContext viewControllerForKey:UITransitionContextToViewControllerKey];
    UIView *containerView = [transitionContext containerView];
    
    [containerView addSubview:toVC.view];
    float factor = self.direction == XSTabBarTransitionDirectionRight ? -1.0 : 1.0;
    CGRect rect = containerView.bounds;
    toVC.view.transform = CGAffineTransformMakeTranslation(rect.size.width * factor, 0);
    
    NSTimeInterval duration = [self transitionDuration:transitionContext];
    [UIView animateWithDuration:duration animations:^{
        toVC.view.transform = CGAffineTransformIdentity;
        fromVC.view.transform = CGAffineTransformMakeTranslation(-rect.size.width * factor, 0);
    } completion:^(BOOL finished) {
        toVC.view.transform = CGAffineTransformIdentity;
        fromVC.view.transform = CGAffineTransformIdentity;
        BOOL canceled = [transitionContext transitionWasCancelled];
        [transitionContext completeTransition:!canceled];
    }];
}


// MARK: -  对UITabBarController的支持

+ (void)tabBarController:(UITabBarController *)tabBarVC transition:(XSTabBarTransition *)scrollTransition fromViewController:(UIViewController *)fromVC toViewController:(UIViewController *)toVC {
    NSArray<UIViewController *> *viewControllers = tabBarVC.viewControllers;
    NSUInteger fromIndex = [viewControllers indexOfObject:fromVC];
    NSUInteger toIndex = [viewControllers indexOfObject:toVC];
    if (fromIndex < toIndex) {
        scrollTransition.direction = XSTabBarTransitionDirectionLeft;
    } else {
        scrollTransition.direction = XSTabBarTransitionDirectionRight;
    }
}

+ (void)tabBarController:(UITabBarController *)tabBarVC  pan:(UIPanGestureRecognizer *)pan percentTransition:(UIPercentDrivenInteractiveTransition * __strong _Nullable * _Nullable)percentTransition completion:(void (^_Nullable)(void))completion {
    CGPoint point = [pan translationInView:pan.view];
    float progress = point.x / pan.view.bounds.size.width;
    static BOOL isDirectionLeft = NO;
    
    if (pan.state == UIGestureRecognizerStateBegan) {
        *percentTransition = [UIPercentDrivenInteractiveTransition new];
        NSInteger step = 0;
        if (point.x > 0) {          //  向右滑动
            step = -1;
            isDirectionLeft = NO;
        } else if (point.x < 0) {   //  向左滑动
            step = 1;
            isDirectionLeft = YES;
        }
        NSUInteger index = tabBarVC.selectedIndex + step;
        if (index >= 0 && index < tabBarVC.viewControllers.count) {
            tabBarVC.selectedIndex = index;
        }
    } else if (pan.state == UIGestureRecognizerStateChanged) {
        if (isDirectionLeft) {
            progress = -progress;
        }
        [*percentTransition updateInteractiveTransition:progress];
    } else if (pan.state == UIGestureRecognizerStateEnded ||
               pan.state == UIGestureRecognizerStateCancelled ||
               pan.state == UIGestureRecognizerStateFailed) {
        CGPoint velocity = [pan velocityInView:pan.view];
        const CGFloat velocityX = 500;      //  超过这个值时表示pan是swipe
        BOOL finished = (progress > 0.5 || velocity.x > velocityX) ||       //  向右滑动
                        (progress < -0.5 || -velocity.x > velocityX);       //  向左滑动
        if (finished) {
            [*percentTransition finishInteractiveTransition];
            if (completion) {
                completion();
            }
        } else {
            [*percentTransition cancelInteractiveTransition];
        }
        *percentTransition = nil;
    }
}

@end
