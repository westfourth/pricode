//
//  XSPresentTransition.h
//  Transitions
//
//  Created by xisi on 2022/1/19.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface XSPresentTransition : NSObject <UIViewControllerAnimatedTransitioning, UIGestureRecognizerDelegate>

/// 升起的高度，默认为屏幕高度的一半
@property (nonatomic) CGFloat height;

/// 点击空白区域
@property (nullable, nonatomic) void (^tapBlank)(void);

@end

NS_ASSUME_NONNULL_END
