//
//  property.h
//  Markdown
//
//  Created by hanxin on 2021/12/31.
//

#include <objc/runtime.h>

/*--------------------------------------------------------------------
 |   知识点1
 |
 |   TypeEncoding 合法格式，以 - (void)setName:(NSString *)name 举例说明：
 |   1. v24@0:8@16           指明类型、位置
 |   2. v@:@                 指明类型
 |   3. v@:@"NSString"       指明类型（具体类型NSString）
 |--------------------------------------------------------------------
 |   知识点2
 |
 |   不能获取伪范性指定的类名，但可以获取协议。
 |   @property (nonatomic) NSArray<SubTestObject *> *list;
 |      对应属性：T@"NSArray",&,N,V_list
 |   @property (nonatomic) NSArray<SubTestObject *> <SubTestObject> *list;
 |      对应属性：T@"NSArray<SubTestObject>",&,N,V_list
 |--------------------------------------------------------------------
 |   知识点3
 |
 |   constructor 在 load 方法之后、main 方法之前执行
 --------------------------------------------------------------------*/


/**
    判断property是否只读

    @param  prop    属性
 */
BOOL property_is_readonly(objc_property_t prop);

/**
    判断property是否有对应的ivar

    @param  prop    属性
    @param  cls     类名
 */
BOOL property_has_ivar_in_class(objc_property_t prop, Class cls);

/**
    获取property声明的class

    @example 获取 @property (nonatomic) SubTestObject *sub; 结果为：\c SubTestObject
    
    @example 获取 @property (nonatomic) NSString <NSCopying> *name; 结果为：\c NSString
 */
Class property_get_class(objc_property_t prop);

/**
    获取property声明的protocol同名的class

    @example 获取 @property (nonatomic) NSArray<SubTestObject *> <SubTestObject> *list; 结果为：<SubTestObject>中的 \c SubTestObject
 
    @example 获取 @property (nonatomic) NSString <NSCopying> *name; 结果为：\c NSCopying

    @note   因为声明protocol时，这个protocol可能不存在，所以返回与这个protocol同名的class
 */
Class property_get_protocol_class(objc_property_t prop);


/**
 getter方法名称
 
 @param  prop    属性
 */
SEL property_getter_sel(objc_property_t prop);

/**
 setter方法名称
 
 @param  prop    属性
 */
SEL property_setter_sel(objc_property_t prop);

/**
 getter typeEncoding
 
 @param  prop    属性
 
 @note  调用free()释放
 */
const char* property_getter_types(objc_property_t prop);

/**
 setter typeEncoding
 
 @param  prop    属性
 
 @note  调用free()释放
 */
const char* property_setter_types(objc_property_t prop);
