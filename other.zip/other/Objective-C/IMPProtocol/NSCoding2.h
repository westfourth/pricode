//
//  NSCoding.h
//  Markdown
//
//  Created by hanxin on 2021/12/20.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

/**
    不使用 NSCoding 的原因：防止对系统的采用 NSCoding 协议的类产生影响。
 */
@protocol NSCoding2
- (void)encodeWithCoder:(NSCoder *)coder;
- (nullable instancetype)initWithCoder:(NSCoder *)coder;
@end

NS_ASSUME_NONNULL_END
