//
//  NSPlisting.h
//  Markdown
//
//  Created by hanxin on 2021/12/19.
//

#import <Foundation/Foundation.h>
#import "NSModeling.h"

NS_ASSUME_NONNULL_BEGIN

@protocol NSPlisting <NSModeling>

- (instancetype)fromPlistFilename:(NSString *)filename bundle:(nullable NSBundle *)bundle;

+ (nullable NSArray *)fromPlistFilename:(NSString *)filename bundle:(nullable NSBundle *)bundle;

@end

NS_ASSUME_NONNULL_END
