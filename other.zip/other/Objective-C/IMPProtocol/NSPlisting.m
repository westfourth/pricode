//
//  NSPlisting.m
//  Markdown
//
//  Created by hanxin on 2021/12/19.
//

#import "NSPlisting.h"
#import "impprotocol.h"

//MARK: -   NSPlisting

/*--------------------------------------------------------------------
 |   这里可以调用fromDict:的原因：
 |   1. 因此类采用了NSPlisting协议，会将NSPlisting的方法都添加到此类中。
 |   2. 因NSPlisting继承NSModeling协议，会将NSModeling的方法都添加到此类中。
 --------------------------------------------------------------------*/

@impprotocol(NSPlisting)

- (instancetype)fromPlistFilename:(NSString *)filename bundle:(nullable NSBundle *)bundle {
    bundle = bundle ? bundle : [NSBundle mainBundle];
    NSString *path = [bundle pathForResource:filename ofType:nil];
    NSDictionary *dict = [NSDictionary dictionaryWithContentsOfFile:path];
    [self fromDict:dict];
    return self;
}

+ (nullable NSArray *)fromPlistFilename:(NSString *)filename bundle:(nullable NSBundle *)bundle {
    bundle = bundle ? bundle : [NSBundle mainBundle];
    NSString *path = [bundle pathForResource:filename ofType:nil];
    NSArray *array = [NSArray arrayWithContentsOfFile:path];
    NSArray *models = [self fromDict:array];
    return models;
}

@end
