//
//  NSCopying2.m
//  Markdown
//
//  Created by hanxin on 2021/12/20.
//

#import "NSCopying2.h"
#import "property.h"
#import "impprotocol.h"

static NSObject* NSCopying2_copy_value(NSObject *value);

@impprotocol(NSCopying2)

- (id)copyWithZone:(NSZone *)zone {
    id instance = [[[self class] allocWithZone:zone] init];
    unsigned int count = 0;
    objc_property_t *props = class_copyPropertyList([self class], &count);
    for (int i = 0; i < count; i++) {
        objc_property_t prop = props[i];
        
        //  忽略readonly并且没有ivar的属性
        BOOL isReadonly = property_is_readonly(prop);
        BOOL hasIvar = property_has_ivar_in_class(prop, [self class]);
        if (isReadonly && !hasIvar) {
            continue;
        }
        
        const char *name = property_getName(prop);
        NSString *key = @(name);
        NSObject *value = [self valueForKey:key];
        NSObject *copyValue = NSCopying2_copy_value(value);
        [instance setValue:copyValue forKey:key];
    }
    free(props);
    return instance;
}

@end


//MARK: - static method

static NSObject* NSCopying2_copy_value(NSObject *value) {
    NSObject *copyValue = nil;
    if ([value conformsToProtocol:@protocol(NSCopying)]) {
        if ([value isKindOfClass:[NSArray class]]) {
            Class cls = [value isKindOfClass:[NSMutableArray class]] ? [NSMutableArray class] : [NSArray class];
            copyValue = [[cls alloc] initWithArray:(NSArray *)value copyItems:YES];
        } else if ([value isKindOfClass:[NSDictionary class]]) {
            Class cls = [value isKindOfClass:[NSMutableDictionary class]] ? [NSMutableDictionary class] : [NSDictionary class];
            copyValue = [[cls alloc] initWithDictionary:(NSDictionary *)value copyItems:YES];
        } else {
            copyValue = [value copy];
        }
    } else {
        copyValue = value;
    }
    return copyValue;
}
