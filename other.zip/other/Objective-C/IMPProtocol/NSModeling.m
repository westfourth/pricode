//
//  NSModeling.m
//  Markdown
//
//  Created by hanxin on 2021/12/19.
//

#import "NSModeling.h"
#import "property.h"
#import "impprotocol.h"
#import "NSModelConfig.h"

//! 字典 --> 模型
#define MODEL_SET_SEL(name)     name##ModelSetter:
//! 模型 --> 字典
#define MODEL_GET_SEL(name)     name##ModelGetter:

static id to_dict_value(id self, const char *name, Class cls, id value);
static id from_dict_value(id self, const char *name, Class cls, id value);
static NSString *dict_key(id self, NSString *key);
static SEL model_sel(const char *name, char *type);


//MARK: -   NSModeling

@impprotocol(NSModeling)

//! 模型 --> 字典
- (nullable NSDictionary *)toDict {
    NSMutableDictionary *dict = [NSMutableDictionary new];
    unsigned int count = 0;
    objc_property_t *props = class_copyPropertyList([self class], &count);
    for (int i = 0; i < count; i++) {
        objc_property_t prop = props[i];

        //  忽略readonly并且没有ivar的属性
        BOOL isReadonly = property_is_readonly(prop);
        BOOL hasIvar = property_has_ivar_in_class(prop, [self class]);
        if (isReadonly && !hasIvar) {
            continue;
        }
        
        const char *name = property_getName(prop);
        NSString *key = @(name);
        if ([[self class] respondsToSelector:@selector(ignoreProperties)] &&
            [[[self class] ignoreProperties] containsObject:key]) {
            continue;
        }
        
        NSString *dictKey = dict_key(self, key);
        NSObject *value = [self valueForKey:key];
        Class cls = property_get_class(prop);
        value = to_dict_value(self, name, cls, value);
        
        if ([value isKindOfClass:[NSArray class]]) {
            cls = property_get_protocol_class(prop);
            if (class_conformsToProtocol(cls, @protocol(NSModeling))) {
                value = [cls toDict:(NSArray *)value];
            }
        } else if ([value conformsToProtocol:@protocol(NSModeling)]) {
            value = [(id<NSModeling>)value toDict];
        }
        dict[dictKey] = value;
    }
    free(props);
    return dict;
}

//! 字典 --> 模型
- (instancetype)fromDict:(NSDictionary *)dict {
    unsigned int count = 0;
    objc_property_t *props = class_copyPropertyList([self class], &count);
    for (int i = 0; i < count; i++) {
        objc_property_t prop = props[i];
        
        //  忽略readonly并且没有ivar的属性
        BOOL isReadonly = property_is_readonly(prop);
        BOOL hasIvar = property_has_ivar_in_class(prop, [self class]);
        if (isReadonly && !hasIvar) {
            continue;
        }

        const char *name = property_getName(prop);
        NSString *key = @(name);
        if ([[self class] respondsToSelector:@selector(ignoreProperties)] &&
            [[[self class] ignoreProperties] containsObject:key]) {
            continue;
        }
        
        NSString *dictKey = dict_key(self, key);
        NSObject *value = dict[dictKey];
        Class cls = property_get_class(prop);
        value = from_dict_value(self, name, cls, value);
        
        if ([value isKindOfClass:[NSArray class]]) {
            cls = property_get_protocol_class(prop);
            if (class_conformsToProtocol(cls, @protocol(NSModeling))) {
                value = [cls fromDict:(NSArray *)value];
            }
        } else if ([value isKindOfClass:[NSDictionary class]]) {
            if (class_conformsToProtocol(cls, @protocol(NSModeling))) {
                id instance = [[cls new] fromDict:(NSDictionary *)value];
                value = instance;
            }
        }
        [self setValue:value forKey:key];
    }
    free(props);
    return self;
}

//! 模型 --> 字典
+ (nullable NSArray *)toDict:(NSArray *)array {
    NSMutableArray *list = [NSMutableArray new];
    for (int i = 0; i < array.count; i++) {
        id value = array[i];
        if ([value conformsToProtocol:@protocol(NSModeling)]) {
            value = [(id<NSModeling>)value toDict];
        }
        [list addObject:value];
    }
    return list;
}

//! 字典 --> 模型
+ (nullable NSArray *)fromDict:(NSArray *)array {
    NSMutableArray *list =  [NSMutableArray new];
    for (int i = 0; i < array.count; i++) {
        id object = [self new];
        if (class_conformsToProtocol(self, @protocol(NSModeling))) {
            [object fromDict:(NSDictionary *)array[i]];
        }
        [list addObject:object];
    }
    return list;
}

@end


//MARK: -   基础函数

/**
    字典 --> 模型，对value进行处理
 
    @param  self            实例对象
    @param  name            属性名
    @param  cls              属性类
    @param  value          属性值
 */
static id to_dict_value(id self, const char *name, Class cls, id value) {
    //  调用modelGetter:方法
    SEL sel = model_sel(name, "ModelGetter:");
    if ([self respondsToSelector:sel]) {
        value = [self performSelector:sel withObject:value];
    } else {
        //  NSNull处理
        if (value == [NSNull null]) {
            if ([[self class] respondsToSelector:@selector(automaticNil)]) {
                BOOL flag = [[self class] automaticNil];
                if (flag) {
                    value = nil;
                }
            } else if (NSModelConfig.share.automaticNil) {
                value = nil;
            }
        }
        
        //
        if (cls == [NSURL class]) {             //  NSURL处理
            if ([[self class] respondsToSelector:@selector(automaticURL)]) {
                BOOL flag = [[self class] automaticURL];
                if (flag) {
                    value = [(NSURL *)value absoluteString];
                }
            } else if (NSModelConfig.share.automaticNil) {
                value = [(NSURL *)value absoluteString];
            }
        } else if (cls == [NSDate class]) {     //  NSDate处理
            NSDateFormatter *df = NSModelConfig.share.dateFormatter;
            if ([[self class] respondsToSelector:@selector(dateFormatter)]) {
                df = [[self class] dateFormatter];
            }
            if ([[self class] respondsToSelector:@selector(automaticDate)]) {
                BOOL flag = [[self class] automaticDate];
                if (flag) {
                    value = [df stringFromDate:(NSDate *)value];
                }
            } else if (NSModelConfig.share.automaticDate) {
                value = [df stringFromDate:(NSDate *)value];
            }
        }
    }
    //  当为数字类型时，setNilValueForKey: 崩溃
    if (value == nil && cls == NULL) {
        value = @0;
    }
    return value;
}


/**
    字典 --> 模型，对value进行处理
 
    @param  self            实例对象
    @param  name            属性名
    @param  cls              属性类
    @param  value          属性值
 */
static id from_dict_value(id self, const char *name, Class cls, id value) {
    //  调用modelSetter:方法
    SEL sel = model_sel(name, "ModelSetter:");
    if ([self respondsToSelector:sel]) {
        value = [self performSelector:sel withObject:value];
    } else {
        //  NSNull处理
        if (value == [NSNull null]) {
            if ([[self class] respondsToSelector:@selector(automaticNil)]) {
                BOOL flag = [[self class] automaticNil];
                if (flag) {
                    value = nil;
                }
            } else if (NSModelConfig.share.automaticNil) {
                value = nil;
            }
        }
        //
        if (cls == [NSURL class]) {             //  NSURL处理
            if ([[self class] respondsToSelector:@selector(automaticURL)]) {
                BOOL flag = [[self class] automaticURL];
                if (flag) {
                    value = [NSURL URLWithString:(NSString *)value];
                }
            } else if (NSModelConfig.share.automaticNil) {
                value = [NSURL URLWithString:(NSString *)value];
            }
        } else if (cls == [NSDate class]) {     //  NSDate处理
            NSDateFormatter *df = NSModelConfig.share.dateFormatter;
            if ([[self class] respondsToSelector:@selector(dateFormatter)]) {
                df = [[self class] dateFormatter];
            }
            if ([[self class] respondsToSelector:@selector(automaticDate)]) {
                BOOL flag = [[self class] automaticDate];
                if (flag) {
                    value = [df dateFromString:(NSString *)value];
                }
            } else if (NSModelConfig.share.automaticDate) {
                value = [df dateFromString:(NSString *)value];
            }
        }
    }
    //  当为数字类型时，setNilValueForKey: 崩溃
    if (value == nil && cls == NULL) {
        value = @0;
    }
    return value;
}

static NSString *dict_key(id self, NSString *key) {
    NSString *dictKey = key;
    //  取dictKey
    if ([[self class] respondsToSelector:@selector(propertyMapper)]) {
        NSDictionary *map = [[self class] propertyMapper];
        NSString *tmp = map[key];
        if (tmp) {
            dictKey = tmp;
        }
    }
    return dictKey;
}

/**
    两个字符串连接，生成SEL
 */
static SEL model_sel(const char *name, char *type) {
    size_t len = strlen(name) + strlen(type) + 1;
    char s[len];
    strcpy(s, name);
    strcat(s, type);
    SEL sel = sel_registerName(s);
    return sel;
}
