//
//  CATransformKey.m
//  Animation
//
//  Created by xisi on 2022/6/9.
//

#import "CATransformKey.h"

NSString * const kCATransformRotationX = @"transform.rotation.x";
NSString * const kCATransformRotationY = @"transform.rotation.y";
NSString * const kCATransformRotationZ = @"transform.rotation.z";
NSString * const kCATransformRotation = @"transform.rotation";

NSString * const kCATransformScaleX = @"transform.scale.x";
NSString * const kCATransformScaleY = @"transform.scale.y";
NSString * const kCATransformScaleZ = @"transform.scale.z";
NSString * const kCATransformScale = @"transform.scale";

NSString * const kCATransformTranslationX = @"transform.translation.x";
NSString * const kCATransformTranslationY = @"transform.translation.y";
NSString * const kCATransformTranslationZ = @"transform.translation.z";
NSString * const kCATransformTranslation = @"transform.translation";
