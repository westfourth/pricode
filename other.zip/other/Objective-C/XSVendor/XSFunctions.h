//
//  XSFunctions.h
//  PDF
//
//  Created by xisi on 2020/4/19.
//  Copyright © 2020 mac. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

// MARK: -  define

#define _UltraLight     UIFontWeightUltraLight
#define _Thin           UIFontWeightThin
#define _Light          UIFontWeightLight
#define _Regular        UIFontWeightRegular
#define _Medium         UIFontWeightMedium
#define _Semibold       UIFontWeightSemibold
#define _Bold           UIFontWeightBold
#define _Heavy          UIFontWeightHeavy
#define _Black          UIFontWeightBlack

//  格式: RGB(6eb92b), 不区分大小写
#define RGB(hex)            rgb(0x##hex)
//  格式: RGBA(6eb92b, 0.9), 不区分大小写
#define RGBA(hex, alpha)    rgb(0x##hex, alpha)

//  格式：IMAGE(logo)
#define IMAGE(s)            [UIImage imageNamed:@#s]

//  格式：STRNUM(12)、STRNUM(12.34)、STRNUM(YES)
#define STRNUM(n)           [NSString stringWithFormat:@"%@", @(n)]

#define WEAK(x)             __weak typeof (x) weak_##x = x
#define STRONG(x)           __strong typeof (x) x = weak_##x

//  格式：@weak(self)
#define weak(x)             autoreleasepool{} __weak typeof (x) weak_##x = x
//  格式：@strong(self)
#define strong(x)           autoreleasepool{} __strong typeof (x) x = weak_##x

//  格式1：KEYPATH(self, view)
//  格式2：KEYPATH(self, view.backgroundColor)
#define KEYPATH(x, y)       (NO && x.y, @#y)

//  格式1：KEYPATH(UIViewController, view)
//  格式2：KEYPATH(UIViewController, view.backgroundColor)
#define KEYPATHC(x, y)      (NO && x.new.y, @#y)


// MARK: -  function

NS_ASSUME_NONNULL_BEGIN

/**
 PingFangSC字体（无此类型：Bold、Heavy、Black）
 
 < Ultralight < Thin  < Light < Regular < Medium < Semibold < Bold < Heavy < Black <
 <    极细体   < 纤细体 <  细体  <  常规体  < 中黑体  <  中粗体   < 粗体  < 加粗体 <  黑体  <
 <    -0.8    < -0.6  < -0.4  <   0.0   < 0.23   <   0.3   < 0.4   < 0.56  <  0.62 <
 */
__attribute__((overloadable, weak)) UIFont* font(CGFloat size);   //  Regular
__attribute__((overloadable, weak)) UIFont* font(CGFloat size, UIFontWeight weight);

__attribute__((overloadable)) UIColor* rgb(UInt32 red, UInt32 green, UInt32 blue);
__attribute__((overloadable)) UIColor* rgb(UInt32 red, UInt32 green, UInt32 blue, CGFloat alpha);

//  格式: rgb(0x6eb92b), 不区分大小写
__attribute__((overloadable)) UIColor* rgb(UInt32 hex);
//  格式: rgb(0x6eb92b, 0.9), 不区分大小写
__attribute__((overloadable)) UIColor* rgb(UInt32 hex, CGFloat alpha);

//  格式：rgb("6eb92b"), rgb("0x6eb92b"), 不区分大小写
__attribute__((overloadable)) UIColor* rgb(const char *str);
//  格式：rgb("6eb92b", 0.9), rgb("0x6eb92b", 0.9), 不区分大小写
__attribute__((overloadable)) UIColor* rgb(const char *str, CGFloat alpha);

NS_ASSUME_NONNULL_END
