//
//  CATransformKey.h
//  Animation
//
//  Created by xisi on 2022/6/9.
//

#import <Foundation/Foundation.h>

/// transform.rotation.x
extern NSString * const kCATransformRotationX;
/// transform.rotation.y
extern NSString * const kCATransformRotationY;
/// transform.rotation.z
extern NSString * const kCATransformRotationZ;
/// transform.rotation
extern NSString * const kCATransformRotation;

/// transform.scale.x
extern NSString * const kCATransformScaleX;
/// transform.scale.y
extern NSString * const kCATransformScaleY;
/// transform.scale.z
extern NSString * const kCATransformScaleZ;
/// transform.scale
extern NSString * const kCATransformScale;

/// transform.translation.x
extern NSString * const kCATransformTranslationX;
/// transform.translation.y
extern NSString * const kCATransformTranslationY;
/// transform.translation.z
extern NSString * const kCATransformTranslationZ;
/// transform.translation
extern NSString * const kCATransformTranslation;
