//
//  XSKeyChain.m
//  KeyChain
//
//  Created by xisi on 14-7-9.
//  Copyright (c) 2014年 xisi. All rights reserved.
//

#import "XSKeyChain.h"

@implementation XSKeyChain

#pragma mark -  一般存储字符串即可
//_______________________________________________________________________________________________________________

+ (NSString *)stringForKey:(NSString *)key {
    NSData *data = [self valueForKey:key];
    NSString *string = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
    return string;
}


+ (BOOL)setString:(NSString *)string forKey:(NSString *)key {
    NSData *data = [string dataUsingEncoding:NSUTF8StringEncoding];
    BOOL result = [self setValue:data forKey:key];
    return result;
}


#pragma mark - 通用结构
//_______________________________________________________________________________________________________________

+ (NSData *)valueForKey:(NSString *)key {
    NSDictionary *query = @{(__bridge id)kSecClass: (__bridge id)kSecClassGenericPassword,
                            (__bridge id)kSecAttrService : [[NSBundle mainBundle] bundleIdentifier],
                            (__bridge id)kSecAttrAccount : key,
                            (__bridge id)kSecReturnData : (__bridge id)kCFBooleanTrue};
    CFDataRef cfValue = NULL;
    //  status != errSecSuccess 时，data = nil
    __unused OSStatus status = SecItemCopyMatching((__bridge CFDictionaryRef)query, (CFTypeRef *)&cfValue);
    NSData *data = (__bridge_transfer NSData *)cfValue;
    return data;
}


+ (BOOL)setValue:(NSData *)value forKey:(NSString *)key {
    BOOL result;
    if (value == nil) {
        result = [self deleteValueForKey:key];
    } else if (![self hasValueForKey:key]) {
        result = [self addValue:value forKey:key];
    } else {
        result = [self updateValue:value forKey:key];
    }
    return result;
}


#pragma mark -  底层结构（要根据返回的布尔值判断后再做进一步处理）
//_______________________________________________________________________________________________________________

+ (BOOL)hasValueForKey:(NSString *)key {
    NSDictionary *query = @{(__bridge id)kSecClass : (__bridge id)kSecClassGenericPassword,
                            (__bridge id)kSecAttrService : [[NSBundle mainBundle] bundleIdentifier],
                            (__bridge id)kSecAttrAccount : key};
    OSStatus status = SecItemCopyMatching((__bridge CFDictionaryRef)query, NULL);
    BOOL result = status == errSecSuccess ? YES : NO;
    return result;
}


+ (BOOL)addValue:(NSData *)value forKey:(NSString *)key {
    NSDictionary *secItem = @{(__bridge id)kSecClass: (__bridge id)kSecClassGenericPassword,            //  类别
                              (__bridge id)kSecAttrService: [[NSBundle mainBundle] bundleIdentifier],   //  标识符
                              (__bridge id)kSecAttrAccount: key,                                        //  键
                              (__bridge id)kSecValueData: value};                                       //  值
    //  已存在时，status状态不为0
    OSStatus status = SecItemAdd((__bridge CFDictionaryRef)secItem, NULL);
    BOOL result = status == errSecSuccess ? YES : NO;
    return result;
}


+ (BOOL)updateValue:(NSData *)value forKey:(NSString *)key {
    NSDictionary *query = @{(__bridge id)kSecClass : (__bridge id)kSecClassGenericPassword,
                            (__bridge id)kSecAttrService : [[NSBundle mainBundle] bundleIdentifier],
                            (__bridge id)kSecAttrAccount : key};
    NSDictionary *update = @{(__bridge id)kSecValueData : value};
    /*
     注意更新一个不存在的对象的情况；
     已存在时，更新正常
     */
    OSStatus status = SecItemUpdate((__bridge CFDictionaryRef)query,
                                     (__bridge CFDictionaryRef)update);
    BOOL result = status == errSecSuccess ? YES : NO;
    return result;
}


+ (BOOL)deleteValueForKey:(NSString *)key {
    NSDictionary *query = @{(__bridge id)kSecClass : (__bridge id)kSecClassGenericPassword,
                            (__bridge id)kSecAttrService : [[NSBundle mainBundle] bundleIdentifier],
                            (__bridge id)kSecAttrAccount : key};
    //  注意删除一个不存在的对象的情况
    OSStatus status = SecItemDelete((__bridge CFDictionaryRef)query);
    BOOL result = status == errSecSuccess ? YES : NO;
    return result;
}

@end
