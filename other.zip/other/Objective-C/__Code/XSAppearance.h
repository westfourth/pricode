//
//  XSAppearance.h
//  XSImageCache2
//
//  Created by xisi on 15/4/1.
//  Copyright (c) 2015年 xisi. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

/*!
    @brief  全局外观定制
 */
@interface XSAppearance : NSObject

//! 全局外观设置
+ (void)setGlobalAppearance;

//! UISegmentedControl
+ (void)setSegmentedControlAppearance;

@end
