//
//  MTLModel+JSONKeyPaths.h
//  KWNetwork
//
//  Created by mac on 2020/3/17.
//  Copyright © 2020 mac. All rights reserved.
//

#import <Mantle/Mantle.h>

NS_ASSUME_NONNULL_BEGIN

@interface MTLModel (JSONKeyPaths) <MTLJSONSerializing>

@end



extern NSString * const IntegerValueTransformerName;

@interface NSValueTransformer (IntegerAdditions)

@end

NS_ASSUME_NONNULL_END
