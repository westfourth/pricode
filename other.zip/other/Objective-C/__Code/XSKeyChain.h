//
//  XSKeyChain.h
//  KeyChain
//
//  Created by xisi on 14-7-9.
//  Copyright (c) 2014年 xisi. All rights reserved.
//

#import <Foundation/Foundation.h>

/*!
    @brief  钥匙串访问与设置
 */
@interface XSKeyChain : NSObject


#pragma mark -  一般存储字符串即可
//_______________________________________________________________________________________________________________

/*!
    @brief  读取存储在钥匙串中的值
 
    @param  key 关键字
    @return 关键字对应的字符串值
 */
+ (NSString *)stringForKey:(NSString *)key;

/*!
    @brief  以键值对将数据存储在钥匙串中
 
    @param  string  要设置的字符串值
    @param  key     键
    @return 操作是否成功
 
    @warning    这里的布尔值一般为Yes
                    0 - value为nil时，删除
                    1 - 不存在时，增加
                    2 - 存在时，更新
 */
+ (BOOL)setString:(NSString *)string forKey:(NSString *)key;


#pragma mark -  通用结构
//_______________________________________________________________________________________________________________

//! 读取
+ (NSData *)valueForKey:(NSString *)key;

//! 写入
+ (BOOL)setValue:(NSData *)value forKey:(NSString *)key;


#pragma mark -  底层结构（要根据返回的布尔值判断后再做进一步处理）
//_______________________________________________________________________________________________________________

//! 是否存在指定key对应的secItem
+ (BOOL)hasValueForKey:(NSString *)key;

//! 增加
+ (BOOL)addValue:(NSData *)value forKey:(NSString *)key;

//! 替换
+ (BOOL)updateValue:(NSData *)value forKey:(NSString *)key;

//! 删除
+ (BOOL)deleteValueForKey:(NSString *)key;

@end
