//
//  XSTimeValidtor.m
//  OCCommand
//
//  Created by mac on 2021/2/4.
//  Copyright © 2021 mac. All rights reserved.
//

#import "XSTimeValidtor.h"
#import <CommonCrypto/CommonCrypto.h>

NSString * const time_valid_url = @"https://raw.githubusercontent.com/jaco574093/license/master/timelimit?raw=true";


BOOL time_is_valid(void) {
    
    static BOOL isvalid = YES;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        dispatch_async(dispatch_get_global_queue(0, 0), ^{
            NSURL *url = [NSURL URLWithString:time_valid_url];
            NSData *data = [NSData dataWithContentsOfURL:url];
            NSString *text = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
            text = [text stringByTrimmingCharactersInSet:[NSCharacterSet newlineCharacterSet]];
            
            NSDateFormatter *f = [NSDateFormatter new];
            f.dateFormat = @"yyyy-MM-dd";
            NSDate *date = [f dateFromString:text];
            if ([date earlierDate:[NSDate date]] == date) {
                isvalid = NO;
            }
        });
    });
    
    return isvalid;
}
