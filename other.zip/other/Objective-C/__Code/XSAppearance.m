//
//  XSAppearance.m
//  XSImageCache2
//
//  Created by xisi on 15/4/1.
//  Copyright (c) 2015年 xisi. All rights reserved.
//

#import "XSAppearance.h"

@implementation XSAppearance

//! 全局外观设置
+ (void)setGlobalAppearance {
    UINavigationBar *navigationBar = [UINavigationBar appearance];
    //  导航栏背景颜色
    navigationBar.barTintColor = [UIColor orangeColor];
    //  导航栏左右两边控件的颜色
    navigationBar.tintColor = [UIColor whiteColor];
    //  导航栏中间字体
    NSDictionary *dict = @{NSFontAttributeName: [UIFont boldSystemFontOfSize:18],
                           NSForegroundColorAttributeName: [UIColor whiteColor]};
    navigationBar.titleTextAttributes = dict;
    
    
    //  导航栏返回键（backBarButtonItem）标题偏移 ＋ 图片设置
    [[UIBarButtonItem appearance] setBackButtonTitlePositionAdjustment:UIOffsetMake(0, -64) forBarMetrics:UIBarMetricsDefault];
    UIImage *image = nil;
    UIImage *navImage = [image resizableImageWithCapInsets:UIEdgeInsetsMake(0, image.size.width, 0, 0)];
    [[UIBarButtonItem appearance] setBackButtonBackgroundImage:navImage forState:UIControlStateNormal barMetrics:UIBarMetricsDefault];
}


//! UISegmentedControl
+ (void)setSegmentedControlAppearance {
    UISegmentedControl *segmentedControl = [UISegmentedControl appearance];
    
    //  字体与字体颜色
    UIFont *font = [UIFont boldSystemFontOfSize:16];
    NSDictionary *normalAttrDict = @{NSFontAttributeName: font,
                                     NSForegroundColorAttributeName: [UIColor orangeColor]};
    NSDictionary *highLightAttrDict = @{NSFontAttributeName: font,
                                        NSForegroundColorAttributeName: [UIColor whiteColor]};
    [segmentedControl setTitleTextAttributes:normalAttrDict forState:UIControlStateNormal];
    [segmentedControl setTitleTextAttributes:highLightAttrDict forState:UIControlStateHighlighted];
}

@end
