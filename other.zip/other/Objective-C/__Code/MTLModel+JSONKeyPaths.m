//
//  MTLModel+JSONKeyPaths.m
//  KWNetwork
//
//  Created by mac on 2020/3/17.
//  Copyright © 2020 mac. All rights reserved.
//

#import "MTLModel+JSONKeyPaths.h"
#import <objc/runtime.h>

@implementation MTLModel (JSONKeyPaths)

+ (NSMutableDictionary *)JSONKeyPathsByPropertyKey {
    Class cls = [self class];
    unsigned int count = 0;
    objc_property_t *props = class_copyPropertyList(cls, &count);
    NSMutableDictionary *dict = [NSMutableDictionary new];
    for (int i = 0; i < count; i++) {
        objc_property_t prop = props[i];
        const char *name = property_getName(prop);
        NSString *propName = [NSString stringWithCString:name encoding:NSUTF8StringEncoding];
        dict[propName] = propName;
    }
    free(props);
    return dict;
}

//  为子类添加NSString转NSInteger、NSUInteger方法
+ (void)initialize {
    Class cls = [self class];
    if (cls == [MTLModel class]) {
        return;
    }
    unsigned int count = 0;
    objc_property_t *props = class_copyPropertyList(cls, &count);
    for (int i = 0; i < count; i++) {
        objc_property_t prop = props[i];
        const char *name = property_getName(prop);
        char *type = property_copyAttributeValue(prop, "T");
        if (strcmp(type, @encode(NSUInteger)) == 0 ||
            strcmp(type, @encode(NSInteger)) == 0) {
            [self addClassMethod:name];
        }
        free(type);
    }
    free(props);
}

/**
    添加NSString转NSInteger、NSUInteger方法
 
    typeEncoding = @16@0:8
    
    @code
     + (NSValueTransformer *)<name>JSONTransformer {
         return [NSValueTransformer valueTransformerForName:IntegerValueTransformerName];
     }
    @endcode
 */
+ (void)addClassMethod:(const char *)name {
    NSString *methodName = [NSString stringWithFormat:@"%sJSONTransformer", name];
    Class cls = [self class];
    const char *typeEncoding = "@16@0:8";
    SEL sel = sel_registerName(methodName.UTF8String);
    IMP imp = imp_implementationWithBlock(^NSValueTransformer*(Class cls){
        return [NSValueTransformer valueTransformerForName:IntegerValueTransformerName];
    });
    Class metaClass = objc_getMetaClass(class_getName(cls));
    class_addMethod(metaClass, sel, imp, typeEncoding);
}

@end


NSString * const IntegerValueTransformerName = @"IntegerValueTransformerName";

@implementation NSValueTransformer (IntegerAdditions)

//  NSString转NSInteger、NSUInteger
+ (void)load {
    MTLValueTransformer *integerValueTransformer = [MTLValueTransformer transformerUsingForwardBlock:^id(NSString *value, BOOL *success, NSError *__autoreleasing *error) {
        return @([value integerValue]);
    } reverseBlock:^id(NSNumber *value, BOOL *success, NSError *__autoreleasing *error) {
        return value.description;
    }];
    [NSValueTransformer setValueTransformer:integerValueTransformer forName:IntegerValueTransformerName];
}

@end
