//
//  XSFrame.swift
//  ML2
//
//  Created by mac on 2020/5/14.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

/// 只有get方法
public extension UIView {
    var left: CGFloat       { return frame.minX }
    var right: CGFloat      { return frame.maxX }
    var top: CGFloat        { return frame.minY }
    var bottom: CGFloat     { return frame.maxY }
    
    var width: CGFloat      { return frame.width }
    var height: CGFloat     { return frame.height }
    var centerX: CGFloat    { return frame.midX }
    var centerY: CGFloat    { return frame.midY }
}


public extension CGRect {
    init(left: CGFloat, bottom: CGFloat, width: CGFloat, height: CGFloat) {
        self.init(x: left, y: bottom - height, width: width, height: height)
    }
    
    init(right: CGFloat, bottom: CGFloat, width: CGFloat, height: CGFloat) {
        self.init(x: right - width, y: bottom - height, width: width, height: height)
    }
    
    init(right: CGFloat, top: CGFloat, width: CGFloat, height: CGFloat) {
        self.init(x: right - width, y: top, width: width, height: height)
    }
    
    init(left: CGFloat, top: CGFloat, right: CGFloat, bottom: CGFloat) {
        self.init(x: left, y: top, width: right - left, height: bottom - top)
    }

    init(centerX: CGFloat, centerY: CGFloat, width: CGFloat, height: CGFloat) {
        self.init(x: centerX - width / 2, y: centerY - height / 2, width: width, height: height)
    }
}
