//
//  Functions.swift
//  ML2
//
//  Created by mac on 2020/5/13.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

/*****************************************************************
 *                      此文件请注意精简                                                                *
 *****************************************************************/

/// 修补在UITableViewCell中不能使用font()
public func FONT(_ size: CGFloat, _ weight: UIFont.Weight = .regular) -> UIFont {
    return font(size, weight)
}

/// 字体
public func font(_ size: CGFloat, _ weight: UIFont.Weight = .regular) -> UIFont {
    var fontName: String = ""
    switch weight {
    case .ultraLight:
        fontName = "PingFangSC-Ultralight"
    case .thin:
        fontName = "PingFangSC-Thin"
    case .light:
        fontName = "PingFangSC-Light"
    case .regular:
        fontName = "PingFangSC-Regular"
    case .medium:
        fontName = "PingFangSC-Medium"
    case .semibold:
        fontName = "PingFangSC-Semibold"
    default:
        assert(false, "平方字体不支持：\(weight)")
    }
    let fontDesc = UIFontDescriptor(name: fontName, size: size)
    return UIFont(descriptor: fontDesc, size: 0)
    //    return UIFont.systemFont(ofSize: size, weight: weight)
}

///
public func rgb(_ red: UInt32, _ green: UInt32, _ blue: UInt32, _ alpha: CGFloat = 1.0) -> UIColor {
    return UIColor(red: CGFloat(red) / 255.0,
                   green: CGFloat(green) / 255.0,
                   blue: CGFloat(blue) / 255.0,
                   alpha: alpha)
}

/// 格式: rgb(0x6eb92b), 不区分大小写
public func rgb(_ hex: UInt32) -> UIColor {
    return UIColor(red: CGFloat((hex & 0xFF0000) >> 16) / 255.0,
                   green: CGFloat((hex & 0xFF00) >> 8) / 255.0,
                   blue: CGFloat(hex & 0xFF) / 255.0,
                   alpha: 1)
}

/// 格式：rgb("6eb92b"), rgb("0x6eb92b"), 不区分大小写
public func rgb(_ str: String) -> UIColor {
    return UIColor(red: CGFloat((strtol(str, nil, 16) & 0xFF0000) >> 16) / 255.0,
                   green: CGFloat((strtol(str, nil, 16) & 0xFF00) >> 8) / 255.0,
                   blue: CGFloat(strtol(str, nil, 16) & 0xFF) / 255.0,
                   alpha: 1)
}
