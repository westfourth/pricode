————————	bash_profile 拷贝到文件
/Users/xisi/.bash_profile

————————	sqliterc 拷贝到文件
/Users/xisi/.sqliterc

————————	vimrc 拷贝到文件
/Users/xisi/.vimrc

————————	proto.vim 放在下面的目录下即可
/Users/xisi/.vim/plugin/

————————	CodeSnippets 放在下面的目录
/Users/xisi/Library/Developer/Xcode/UserData


