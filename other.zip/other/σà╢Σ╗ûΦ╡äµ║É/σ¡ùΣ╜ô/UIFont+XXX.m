//
//  UIFont+XXX.m
//  PDF
//
//  Created by mac on 2020/3/28.
//  Copyright © 2020 mac. All rights reserved.
//

#import "UIFont+XXX.h"

@implementation UIFont (XXX)

- (instancetype)initWithCoder:(NSCoder *)coder
{
    UIFontDescriptor *fontDesc = [coder decodeObjectForKey:@"UIFontDescriptor"];
    CGFloat fontSize = [fontDesc.fontAttributes[@"NSFontSizeAttribute"] floatValue];
    return [UIFont fontWithName:@"PingFangSC-Regular" size:fontSize];
}

@end
