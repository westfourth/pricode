# git_submodule 递归操作以及分支变化问题


## git pull

``` sh
git pull
```

默认情况下，git pull 命令会递归地抓取子模块的更改。 然而，它不会更新子模块。

## git pull --recurse-submodules=yes

``` sh
git pull --recurse-submodules=yes
```

这时候HEAD游离

``` sh
* (HEAD detached from refs/heads/master)
  dev
  master
```

## git submodule update --remote

``` sh
git submodule update --remote
```

这时候HEAD游离

``` sh
* (HEAD detached at f8baf2e)
  dev
  master
```

会拉取.gitmodule中配置的分支代码

## git pull --recurse-submodules=yes --rebase

``` sh
git pull --recurse-submodules=yes --rebase
```

虽然分支状态正确，但这时候特别容易冲突

## git submodule update --remote --merge 

``` sh
git submodule update --remote --merge
```

虽然分支状态正确，但这时候有个**严重错误：**，例如别人提交的是dev分支的修改，当前分支为master分支，那么master分支会合并别人刚提交的dev分支的代码。
