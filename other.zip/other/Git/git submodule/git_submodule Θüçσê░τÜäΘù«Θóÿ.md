# git submodule 遇到的问题

## 1. git push 失败，没有Change-Id，需要安装钩子

HEAD方式推送失败

``` sh
$ git push origin HEAD:refs/for/master
Enumerating objects: 8, done.
Counting objects: 100% (8/8), done.
Delta compression using up to 12 threads
Compressing objects: 100% (7/7), done.
Writing objects: 100% (7/7), 3.41 KiB | 3.41 MiB/s, done.
Total 7 (delta 0), reused 0 (delta 0), pack-reused 0
remote: Processing changes: refs: 1, done    
remote: ERROR: [448605e] missing Change-Id in commit message footer
remote: 
remote: Hint: To automatically insert Change-Id, install the hook:
remote:   gitdir=$(git rev-parse --git-dir); scp -p -P 29418 jshanxin@skt.abcmoreonline.com:hooks/commit-msg ${gitdir}/hooks/
remote: And then amend the commit:
remote:   git commit --amend
remote: 
To http://skt.abcmoreonline.com:8088/a/LGDFinanceLib
 ! [remote rejected] HEAD -> refs/for/master ([448605e] missing Change-Id in commit message footer)
error: failed to push some refs to 'http://skt.abcmoreonline.com:8088/a/LGDFinanceLib'
```

按照提示安装hook钩子，提示权限被拒

``` sh
$ gitdir=$(git rev-parse --git-dir); scp -p -P 29418 jshanxin@skt.abcmoreonline.com:hooks/commit-msg ${gitdir}/hooks/
jshanxin@skt.abcmoreonline.com: Permission denied (publickey).
```

输出目录

``` sh
$ echo $gitdir
/Users/billie/firefox/.git/modules/FirefoxGames/LGDFinanceLib
```

**方式一：**

``` sh
# 下载钩子
curl -O http://<username>@skt.abcmoreonline.com:8088/tools/hooks/commit-msg
```

把勾子拷贝到`${gitdir}/hooks/`目录下

**方式二：**

拷贝父模块里面的勾子`.git/hooks/commit-msg`到`${gitdir}/hooks/`目录下

**方式一/方式二安装勾子后，这时候最后一次提交的记录还是没有`Change-Id`**

``` sh
# 为最后一次提交添加Change-Id
git commit --amend
```

保存退出后，这时候就可以提交了。





