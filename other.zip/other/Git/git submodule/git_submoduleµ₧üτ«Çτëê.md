## git submodule 极简版

### 1. init

``` sh
# 初始化
$ git submodule init
```

### 2. update

``` sh
# 拉取各子模块（如果配置了分支，则会拉取指定的分支代码，但head游离）
$ git submodule update --remote
```


### 3. pull

先拉取父模块，再执行**`步骤2. update`**

### 4. commit

先提交子模块，再提交父模块。（子模块被当作特殊的文件处理，关联子模块的commit-id，请提交）


### 5. push

先推送子模块，再推送父模块。

### 5. checkout

先切换到父模块分支，再执行**`步骤2. update`**

