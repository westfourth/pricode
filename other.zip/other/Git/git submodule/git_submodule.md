# git submodule

## 1. add

``` sh
$ git submodule add https://gitee.com/westfourth/child.git
```

``` sh
$ git status
On branch master
Your branch is up to date with 'origin/master'.

Changes to be committed:
  (use "git restore --staged <file>..." to unstage)
	new file:   .gitmodules
	new file:   child
```

``` sh
# 只查看父模块的状态，忽略所有子模块的所有信息
$ git status --ignore-submodules=all
```

``` sh
$ cat .gitmodules
[submodule "child"]
	path = child
	url = https://gitee.com/westfourth/child.git
```

当同时在父模块、子模块中修改文件后，假设当前目录为父模块

``` sh
git add .
git commit -m '-'
git push
```

只能把父模块修改的代码push上去，子模块修改的代码未推上去。

**add原理**

``` sh
$ cat .git/config 
# config文件中多了submodule
[submodule "child"]
	url = https://gitee.com/westfourth/child
	active = true
```

``` sh
$ cat .gitmodules 
[submodule "child"]
	path = child
	url = https://gitee.com/westfourth/child
```

## 2. deinit

取消注册子模块，并删除该子模块中的所有文件（但保留此目录），同时删除`.git/config`中该子模块的记录。

``` sh
# 取消注册child子模块
$ git submodule deinit child
Cleared directory 'child'
Submodule 'child' (https://gitee.com/westfourth/child) unregistered for path 'child'
```

``` sh
$ cat .git/config 
# 结果：没有 [submodule "child"] 这条记录
```

## 3. init

注册子模块：从`.gitmodules`获取子模块信息，注册到`.git/config`文件中。但此时并不会拉取这个子模块的文件

``` sh
$ git submodule init
Submodule 'child' (https://gitee.com/westfourth/child) registered for path 'child'
```

``` sh
$ cat .git/config 
# [submodule "child"] 这条记录又有了
[submodule "child"]
	active = true
	url = https://gitee.com/westfourth/child
```


## 4. update

拉取注册的子模块（通过clone、或者fetch并merge）。

``` sh
$ git submodule update
Submodule path 'child': checked out 'd1698f6e22f82a69af0fba742d79212add16fdbb'
```

可以看到child项目被拉取下来了

## 5. set-branch

设置子模块的分支

``` sh
# 设置为dev分支
$ git submodule set-branch -b dev child
```

``` sh
$ cat .gitmodules 
[submodule "child"]
	path = child
	url = https://gitee.com/westfourth/child
	branch = dev
```

``` sh
# 更新
$ git submodule update --remote
```

## 6. set-url

设置/更新子模块的url

``` sh
$ git submodule set-url child https://gitee.com/westfourth/child2
Synchronizing submodule url for 'child'
```

``` sh
$ cat .git/config 
# ... 省略
[submodule "child"]
	active = true
	url = https://gitee.com/westfourth/child2
```

``` sh
$ cat .gitmodules 
[submodule "child"]
	path = child
	url = https://gitee.com/westfourth/child2
	branch = dev
```

## 7. foreach

对所有的子模块执行某个命令

``` sh
# 将所有的子模块切换到master分支
$ git submodule foreach 'git checkout master'
Entering 'child'
Switched to branch 'master'
Your branch and 'origin/master' have diverged,
and have 2 and 2 different commits each, respectively.
  (use "git pull" to merge the remote branch into yours)
```


## 8. clone

``` sh
git clone https://gitee.com/westfourth/one.git
```
默认会包含子模块目录；但子模块目录是个空目录，里面没有任何文件。

``` sh
# 初始化所有子模块
git submodule init
# 克隆所有的子模块（非递归模式）
git submodule update
```
这时候子模块里面就有内容了

``` sh
# 递归克隆所有的子模块
git submodule update --init --recursive
```

下面是更简单的方式

``` sh
# 递归克隆
git clone --recurse-submodules https://gitee.com/westfourth/one.git
```

## 9. pull

### git submodule update

``` sh
# 抓取指定子模块
git submodule update --remote child
```

``` sh
# 抓取所有子模块
git submodule update --remote
```

``` sh
# 递归抓取所有子模块
git submodule update --remote --recursive
```

区别：

``` sh
# HEAD游离：拉取将子模块的预先设定的分支
git submodule update --remote
# rebase方式：拉取将子模块的预先设定的分支，并以--rebase形式合并代码
git submodule update --remote --rebase
# merge方式：拉取将子模块的预先设定的分支，并以--merge形式合并代码
git submodule update --remote --merge
```

## 10. push

``` sh
# 如果子模块的提交没有被推送，那么主模块推送会失败
git push --recurse-submodules=check
# 依次推送各子模块、主模块；如果子模块推送失败，那么主模块也会推送失败
git push --recurse-submodules=on-demand
```

## 11. checkout

``` sh
# 切换分支时，让子模块处于正确的状态
git checkout --recurse-submodules master
```
如果`checkout`时忘了传`--recurse-submodules`选项，使用下面的命令，让子模块处于正确的状态

``` sh
git submodule update --init --recursive
```

