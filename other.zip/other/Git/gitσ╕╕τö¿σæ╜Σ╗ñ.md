# git常用命令

## 工作区、暂存区、仓库


```sh
# 撤销最后一次提交到暂存区
git reset --soft HEAD^

# 撤销暂存区到工作区
git restore --staged <fileName>

# 撤销工作区改动
git restore <fileName>
```

## 删除远程tag

```sh
git tag -d 0.1.29
git push origin :refs/tags/0.1.29
```

## 批量删除分支

```sh
git branch | grep 'dev' | xargs git branch -d
```

## 指定提交日期

```sh
git commit --date='2022-07-18 20:00:00' -m '注释'
```

## 过滤作者

```sh
git log --author=jshanxin
```

## 过滤日期

```sh
# 查看2022-04-22的提交
git log --since="2022-04-22" --until="2022-04-23"
```

## 查看某次提交对应的修改文件列表

```sh
git show --raw e4d41125aa70e6935621f0a099f3aa6f1551df6f
```

## 查看分支创建者（需要进一步确认）

```sh
git for-each-ref --format='%(committerdate) %09 %(authorname) %09 %(refname)' | sort -k5n -k2M -k3n -k4n | grep <branchname>
```

## 查看分支基于哪个分支创建

```sh
git reflog show <branchname>
```

![查找父分支](Images/git_branch_from.png)

## git冲突处理

```sh
CONFLICT (content): Merge conflict in .gitmodules

# 冲突内容 
<<<<<<< HEAD
	branch = release_0831
=======
	branch = release_0907
>>>>>>> release_0907
```

**处理：**

```sh
git checkout --theirs .gitmodules

结果：
	branch = release_0907
```

**策略说明：**

* `--ours`：保留当前分支内容
* `--theirs`：保留其他分支内容