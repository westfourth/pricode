# git常见问题


## 1. [remote rejected] head-> refs (change closed)

``` sh
$ git push origin head:refs/for/feature_finance_revision
Enumerating objects: 28, done.
Counting objects: 100% (28/28), done.
Delta compression using up to 12 threads
Compressing objects: 100% (17/17), done.
Writing objects: 100% (18/18), 3.14 KiB | 1.57 MiB/s, done.
Total 18 (delta 10), reused 0 (delta 0), pack-reused 0
remote: Resolving deltas: 100% (10/10)
remote: Counting objects: 183919, done
remote: Processing changes: refs: 1, done    
To http://skt.abcmoreonline.com:8088/a/kk-ios-app/firefox
 ! [remote rejected]       head -> refs/for/feature_finance_revision (change http://skt.abcmoreonline.com:8088/124079 closed)
error: failed to push some refs to 'http://skt.abcmoreonline.com:8088/a/kk-ios-app/firefox'
```

**原因：**

刚刚提交的Change-Id与被Abandon掉的Change-Id一致，导致不能推送

**处理：**

找到最近最先被Abandon掉的Commit-Id的前一条Commit-Id，执行

``` sh
# 将最后一次正常提交的记录到最后一次提交的记录合并为一条记录
git reset --soft $pre_commit_id
git add .
git commit -m '<comment>'
# 提交
git push origin HEAD:refs/for/<branch>
```


## 2. Your branch and 'origin/feature_finance_revision' have diverged

``` sh
On branch feature_finance_revision
Your branch and 'origin/feature_finance_revision' have diverged,
and have 4 and 150 different commits each, respectively.
  (use "git pull" to merge the remote branch into yours)

nothing to commit, working tree clean
```

### 方式一

**查看哪些冲突了**

``` sh
$ git cherry
+ aacdbc72b0adf668367787330372497877fcefdf
+ 93ab735bbb32b69f121361961f26d3689c843a7b
+ 7a2b18ea258854b0293733ed3f10533704f82652
+ fc9ba5e32abd504cd579e0904f68557bf1204a78
```

**找到这4个冲突的最近前一个提交**

``` sh
git reset --hard <上一个提交>
```

``` sh
git pull
```

### 方式二

``` sh
git pull --allow-unrelated-histories
```

## 3. fatal: fetch-pack: invalid index-pack output

``` sh
$ git clone http://jshanxin@skt.abcmoreonline.com:8088/a/kk-ios-app/firefox && (cd firefox && curl -Lo 'git rev-parse --git-dir*/hooks/commi t-msghttp://jshanxin@skt.abcmoreonline.com:8088/tools/hooks/commit-msg;chmod + × 'git rev-parse --git-dir'/hooks/commit-msg)
Cloning into 'firefox'...
remote: Counting objects: 11684, done remote: Finding sources: 100% (723211/723211)
error: RPC failed; curl 18 transfer closed with outstanding read data remaining fetch-pack: unexpected disconnect while reading sideband packet fatal: early EOF
fatal: fetch-pack: invalid index-pack output
```

**原因：**

有个别文件太大

**第一步：拉取仓库：**

``` sh
# 关闭压缩
$ git config --global core.compression 0
# 部分克隆
$ git clone --depth 1 <URI>
# 全部获取
$ git fetch --depth=2147483647
# 正常拉取
$ git pull --all
```

**第二步：配置config：**

将`master`改为`*`

``` sh
$ cat .git/config
[remote "origin"]
	url = http://jshanxin@skt.abcmoreonline.com:8088/a/kk-ios-app/firefox
	fetch = +refs/heads/master:refs/remotes/origin/master
```

``` sh
$ cat .git/config
[remote "origin"]
	url = http://jshanxin@skt.abcmoreonline.com:8088/a/kk-ios-app/firefox
	fetch = +refs/heads/*:refs/remotes/origin/*
```


## 4. git submodule 拉不下来

**处理：**

``` sh
# 如果子模块设置正确，deinit不需要
$ git submodule deinit
$ git submodule init
$ git submodule update
```

## 5. git push 不了

```sh
 ! [remote rejected] HEAD -> refs/for/master (change 14823 closed)
error: failed to push some refs to 'ssh://xxxxx@gerrit.dev.xxxxx.net:29418/xxxxxx'
```

**原因：**远程仓库已经有这个Change-Id

**处理：**

```sh
# 进入日志，删掉Change-Id，保存并退出
$ git commit --amend
# 再次进入日志，自动生成Change-Id，保存并退出
$ git commit --amend
```



