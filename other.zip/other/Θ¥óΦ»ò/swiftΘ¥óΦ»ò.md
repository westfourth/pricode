##

## 命名空间 ？

```swift
//  AA.framework
public class Test {
    public class hello() {
        print("helloA");
    }
}
```

```swift
//  BB.framework
public class Test {
    public class hello() {
        print("helloB");
    }
}
```

**调用**

```swift
AA.Test.hello();
BB.Test.hello();
```