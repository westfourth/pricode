//
//  KVCollectController.m
//  KuwoVideo
//
//  Created by mac on 2020/6/5.
//  Copyright © 2020 mac. All rights reserved.
//

#import "KVCollectController.h"
#import "KVHomeCell.h"
#import <XSVendor/UIScrollView+XSRefresh.h>
#import <AVKit/AVKit.h>
#import "KVStore.h"

@interface KVCollectController () <UICollectionViewDataSource, UICollectionViewDelegate, UIScrollViewDelegate, KVHomeCellDelegate> {
    UICollectionView *_collectionView;
    NSMutableArray<KWMVModel *> *_models;
    
    AVPlayer *_player;
    NSIndexPath *_playingIndexPath;
}

@end

@implementation KVCollectController

- (void)viewDidLoad {
    [super viewDidLoad];
    _player = [AVPlayer playerWithPlayerItem:nil];
    _playingIndexPath = [NSIndexPath indexPathForRow:0 inSection:0];
    
    _models = KVStore.models;
    
    [self setupCollectionView];
    [self startPlayItem:_playingIndexPath];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [_collectionView reloadData];
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    
    NSUInteger row = [self targetRow:_collectionView.contentOffset.y];
    NSIndexPath *indexPath = [NSIndexPath indexPathForRow:row inSection:0];
    if (row != _playingIndexPath.row) {
        [self startPlayItem:indexPath];
    } else {
        KVHomeCell *cell = (KVHomeCell *)[_collectionView cellForItemAtIndexPath:indexPath];
        ((AVPlayerLayer *)cell.playerView.layer).player = _player;
        [_player play];
    }
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    [_player pause];
}

- (void)viewDidLayoutSubviews {
    [super viewDidLayoutSubviews];
    _collectionView.frame = self.view.bounds;
}

- (void)setupCollectionView {
    UICollectionViewFlowLayout *layout = [KVHomeCell flowLayout];
    _collectionView = [[UICollectionView alloc] initWithFrame:CGRectZero collectionViewLayout:layout];
    [self.view addSubview:_collectionView];
    _collectionView.dataSource = self;
    _collectionView.delegate = self;
    
    [_collectionView registerClass:[KVHomeCell class] forCellWithReuseIdentifier:@"ID"];
    _collectionView.backgroundColor = [UIColor whiteColor];
    _collectionView.scrollsToTop = NO;
}

//_______________________________________________________________________________________________________________
// MARK: -

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return _models.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    KWMVModel *model = _models[indexPath.row];
    KVHomeCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"ID" forIndexPath:indexPath];
    ((AVPlayerLayer *)cell.playerView.layer).player = nil;
    cell.model = model;
    cell.delegate = self;
    return cell;
}


//_______________________________________________________________________________________________________________
// MARK: -  核心

- (void)scrollViewWillEndDragging:(UIScrollView *)scrollView withVelocity:(CGPoint)velocity targetContentOffset:(inout CGPoint *)targetContentOffset {
    NSUInteger row = [self targetRow:(*targetContentOffset).y];
    if (row != _playingIndexPath.row) {
        [self endPlayItem:_playingIndexPath];
    }
    //  不会触发scrollViewDidEndDecelerating
    if (velocity.y == 0) {
        [self scrollViewDidEndDecelerating:scrollView];
    }
}

- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView {
    NSUInteger row = [self targetRow:scrollView.contentOffset.y];
    if (row != _playingIndexPath.row) {
        NSIndexPath *nextPlayIndexPath = [NSIndexPath indexPathForRow:row inSection:0];
        [self startPlayItem:nextPlayIndexPath];
    } else {
        if (_player.timeControlStatus != AVPlayerTimeControlStatusPlaying) {
            [_player play];
        }
    }
}

- (void)startPlayItem:(NSIndexPath *)indexPath {
    if (_models.count == 0 || indexPath.row >= _models.count) {
        return;
    }
    KWMVModel *model = _models[indexPath.row];
    [KWMP3MP4 requestMP4:model.id completion:^(NSError * _Nonnull error, NSURL * _Nonnull url) {
        if (error) {
            return;
        }
        model.playerItem = [AVPlayerItem playerItemWithURL:url];
        //
        NSIndexPath *preIndexPath = _playingIndexPath;
        [_player replaceCurrentItemWithPlayerItem:model.playerItem];
        _playingIndexPath = indexPath;
        if (indexPath == preIndexPath) {
            [_collectionView reloadItemsAtIndexPaths:@[indexPath]];
        } else {
            [_collectionView reloadItemsAtIndexPaths:@[preIndexPath, indexPath]];
        }
        KVHomeCell *cell = (KVHomeCell *)[_collectionView cellForItemAtIndexPath:indexPath];
        ((AVPlayerLayer *)cell.playerView.layer).player = _player;
        [_player play];
    }];
    

}

- (void)endPlayItem:(NSIndexPath *)indexPath {
    if (_models.count == 0 || indexPath.row >= _models.count) {
        return;
    }
    KVHomeCell *cell = (KVHomeCell *)[_collectionView cellForItemAtIndexPath:indexPath];
    ((AVPlayerLayer *)cell.playerView.layer).player = nil;
    [_player pause];
}

- (NSUInteger)targetRow:(CGFloat)targetOffsetY {
    UICollectionViewFlowLayout *flow = (UICollectionViewFlowLayout *)_collectionView.collectionViewLayout;
    CGFloat flowLayoutHeight = flow.itemSize.height + flow.minimumLineSpacing;
    NSUInteger row = ceil((targetOffsetY + _collectionView.adjustedContentInset.top) / flowLayoutHeight);
    return row;
}

//MARK:-    KVHomeCellDelegate

- (void)cell:(KVHomeCell *)cell didClickCollectButton:(UIButton *)button {
    KWMVModel *model = cell.model;
    model.selected = !model.selected;
    cell.model = model;
    
    //  存储
    [KVStore.models addObject:model];
    [KVStore write];
}

@end
