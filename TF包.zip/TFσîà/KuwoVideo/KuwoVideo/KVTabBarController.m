//
//  ITTabBarController.m
//  ITBook
//
//  Created by mac on 2020/3/11.
//  Copyright © 2020 mac. All rights reserved.
//

#import "KVTabBarController.h"
#import "KVBundle.h"
#import <XSVendor/UIView+XSFrame.h>
#import "KVStore.h"

@interface KVTabBarController ()

@end

@implementation KVTabBarController

- (void)viewDidLoad {
    [super viewDidLoad];
    //  读取
    [KVStore read];
    
    NSString *path = [[KVBundle main] pathForResource:@"Tabbar" ofType:@"plist"];
    NSArray *array = [NSArray arrayWithContentsOfFile:path];
    
    NSMutableArray<UINavigationController *> *controllers = [NSMutableArray new];
    
    for (NSDictionary *dict in array) {
        Class cls = NSClassFromString(dict[@"controller"]);
        //  vc
        UIViewController *vc = [cls new];
        vc.navigationItem.title = dict[@"title"];
        
        //  TabBarItem
        UIImage *image = [UIImage imageNamed:dict[@"image"] inBundle:[KVBundle main] compatibleWithTraitCollection:nil];
        UITabBarItem *item = [[UITabBarItem alloc] initWithTitle:dict[@"title"] image:image selectedImage:nil];
        
        //  navVC
        UINavigationController *navVC = [[UINavigationController alloc] initWithRootViewController:vc];
        navVC.tabBarItem = item;

        [controllers addObject:navVC];
    }
    self.viewControllers = controllers;
}


@end
