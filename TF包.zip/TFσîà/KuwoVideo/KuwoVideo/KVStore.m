//
//  KVStore.m
//  KuwoVideo
//
//  Created by mac on 2020/6/5.
//  Copyright © 2020 mac. All rights reserved.
//

#import "KVStore.h"

@implementation KVStore
static NSMutableArray<KWMVModel *> *_models = nil;

+ (NSMutableArray<KWMVModel *> *)models {
    return _models;
}

+ (void)setModels:(NSMutableArray<KWMVModel *> *)models {
    _models = models;
}

+ (void)read {
    NSData *data = [NSData dataWithContentsOfFile:[self path]];
    NSMutableArray *models = [NSKeyedUnarchiver unarchiveObjectWithData:data];
    if (models == nil) {
        models = [NSMutableArray new];
    }
    [self setModels:models];
}

+ (void)write {
    NSData *data = [NSKeyedArchiver archivedDataWithRootObject:[self models]];
    [data writeToFile:[self path] atomically:YES];
}

+ (NSString *)path {
    NSString *cacheDir = NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES).firstObject;
    NSString *path = [cacheDir stringByAppendingPathComponent:@"KWMVModel.arch"];
    return path;
}

@end
