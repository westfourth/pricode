//
//  KVStore.h
//  KuwoVideo
//
//  Created by mac on 2020/6/5.
//  Copyright © 2020 mac. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <KWNetwork/KWNetwork.h>

NS_ASSUME_NONNULL_BEGIN

@interface KVStore : NSObject

@property (class, nullable) NSMutableArray<KWMVModel *> *models;

+ (void)read;

+ (void)write;

@end

NS_ASSUME_NONNULL_END
