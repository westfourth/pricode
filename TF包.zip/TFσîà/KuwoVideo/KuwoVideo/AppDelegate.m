//
//  AppDelegate.m
//  KuwoVideo
//
//  Created by mac on 2020/6/5.
//  Copyright © 2020 mac. All rights reserved.
//

#import "AppDelegate.h"
#import "KVTabBarController.h"

@interface AppDelegate ()

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    puts(NSTemporaryDirectory().UTF8String);
    //
    UIWindow *window = [UIWindow new];
    window.frame = [UIScreen mainScreen].bounds;
    [window makeKeyAndVisible];
    self.window = window;
    self.window.rootViewController = [KVTabBarController new];
    return YES;
}

@end
