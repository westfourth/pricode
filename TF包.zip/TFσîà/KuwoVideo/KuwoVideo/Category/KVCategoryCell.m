//
//  KVCategoryCell.m
//  KuwoVideo
//
//  Created by mac on 2020/6/5.
//  Copyright © 2020 mac. All rights reserved.
//

#import "KVCategoryCell.h"
#import <SDWebImage/SDWebImage.h>
#import "KVTool.h"
#import "KVBundle.h"
#import <objc/runtime.h>

@interface KVCategoryCell () {
    UILabel *_label;
}

@end

@implementation KVCategoryCell

float const KVCategoryCellRatio = 1;   //  宽高比
float const KVCategoryCellLineSpacing = 8;
float const KVCategoryCellInteritemSpacing = 8;
float const KVCategoryCellEdge = 8;                //  两边间距

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        _label = [UILabel new];
        [self.contentView addSubview:_label];
        _label.textAlignment = NSTextAlignmentCenter;
        _label.textColor = [UIColor whiteColor];
        _label.font = [UIFont boldSystemFontOfSize:28];
        
        //
        object_setClass(self.layer, [CAGradientLayer class]);
        CAGradientLayer *layer = (CAGradientLayer *)self.layer;
        layer.colors = @[
            (__bridge id)[UIColor colorWithRed:16/255.0 green:159/255.0 blue:210/255.0 alpha:1].CGColor,
            (__bridge id)[UIColor colorWithRed:0/255.0 green:132/255.0 blue:250/255.0 alpha:1].CGColor
        ];
    }
    return self;
}

- (void)layoutSubviews {
    _label.frame = self.bounds;
}

-(void)setModel:(KVCategoryModel *)model {
    _model = model;
    _label.text = model.title;
    [self setNeedsLayout];
}


// MARK: -

+ (UICollectionViewFlowLayout *)flowLayout {
    UICollectionViewFlowLayout *layout = [UICollectionViewFlowLayout new];
    layout.minimumLineSpacing = KVCategoryCellLineSpacing;
    layout.minimumInteritemSpacing = KVCategoryCellInteritemSpacing;
    layout.itemSize = [KVCategoryCell itemSize];
    layout.sectionInset = UIEdgeInsetsMake(KVCategoryCellEdge, KVCategoryCellEdge, KVCategoryCellEdge, KVCategoryCellEdge);
    return layout;
}

+ (CGFloat)itemWidth {
    int count = 3;          //  每行多少个
    return ([UIScreen mainScreen].bounds.size.width - 2 * KVCategoryCellEdge - KVCategoryCellInteritemSpacing * (count - 1)) / count;
}

+ (CGSize)itemSize {
    CGFloat width = [KVCategoryCell itemWidth];
    CGFloat height = width / KVCategoryCellRatio;
    return CGSizeMake(width, height);
}

@end
