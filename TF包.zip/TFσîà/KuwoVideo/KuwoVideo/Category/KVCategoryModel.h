//
//  KVCategoryModel.h
//  KuwoVideo
//
//  Created by mac on 2020/6/5.
//  Copyright © 2020 mac. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface KVCategoryModel : NSObject

@property (nonatomic) NSString *title;

@end

NS_ASSUME_NONNULL_END
