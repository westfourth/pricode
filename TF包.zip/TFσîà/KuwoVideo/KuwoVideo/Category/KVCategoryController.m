//
//  KVCategoryController.m
//  KuwoVideo
//
//  Created by mac on 2020/6/5.
//  Copyright © 2020 mac. All rights reserved.
//

#import "KVCategoryController.h"
#import "KVSubCategoryController.h"
#import "KVHomeController.h"
#import "KVCategoryCell.h"
#import <XSVendor/UIScrollView+XSRefresh.h>
#import <AVKit/AVKit.h>
#import "KVBundle.h"

@interface KVCategoryController () <UICollectionViewDataSource, UICollectionViewDelegate> {
    UICollectionView *_collectionView;
    NSMutableArray<KVCategoryModel *> *_models;
}

@end

@implementation KVCategoryController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self setupData];
    [self setupCollectionView];
}

- (void)viewDidLayoutSubviews {
    [super viewDidLayoutSubviews];
    _collectionView.frame = self.view.bounds;
}

- (void)setupData {
    NSString *path = [[KVBundle main] pathForResource:@"KVCategory" ofType:@"plist"];
    NSArray *array = [NSArray arrayWithContentsOfFile:path];
    
    _models = [NSMutableArray new];
    for (NSDictionary *dict in array) {
        KVCategoryModel *model = [KVCategoryModel new];
        model.title = dict[@"title"];
        [_models addObject:model];
    }
}

- (void)setupCollectionView {
    UICollectionViewFlowLayout *layout = [KVCategoryCell flowLayout];
    _collectionView = [[UICollectionView alloc] initWithFrame:CGRectZero collectionViewLayout:layout];
    [self.view addSubview:_collectionView];
    _collectionView.dataSource = self;
    _collectionView.delegate = self;
    
    [_collectionView registerClass:[KVCategoryCell class] forCellWithReuseIdentifier:@"ID"];
    _collectionView.backgroundColor = [UIColor whiteColor];
}

//_______________________________________________________________________________________________________________
// MARK: -

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return _models.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    KVCategoryModel *model = _models[indexPath.row];
    KVCategoryCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"ID" forIndexPath:indexPath];
    cell.model = model;
    return cell;
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    KVCategoryModel *model = _models[indexPath.row];
    KVHomeController *vc = [KVHomeController new];
    vc.type = indexPath.row + 1;
    vc.title = model.title;
    vc.hidesBottomBarWhenPushed = YES;
    [self.navigationController pushViewController:vc animated:YES];
}

@end
