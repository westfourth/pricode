//
//  FYSettingController.m
//  Translator
//
//  Created by mac on 2020/6/2.
//  Copyright © 2020 mac. All rights reserved.
//

#import <SafariServices/SafariServices.h>
#import "KVSettingController.h"
#import <MBProgressHUD/MBProgressHUD.h>

@interface KVSettingController () <UITableViewDataSource, UITableViewDelegate> {
    NSArray *_titles;
}
@property (weak, nonatomic) IBOutlet UITableView *tableView;

@end

@implementation KVSettingController

- (void)viewDidLoad {
    [super viewDidLoad];
    _titles = @[@"官网", @"服务条款", @"隐私政策", @"清理缓存", @"联系我们"];
    self.tableView.tableFooterView = [UIView new];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return _titles.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"ID"];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:@"ID"];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    NSString *text = _titles[indexPath.row];
    cell.textLabel.text = text;
    if ([text isEqualToString:@"联系我们"]) {
        cell.accessoryType = UITableViewCellAccessoryNone;
        cell.detailTextLabel.text = @"jaco574093@gmail.com";
    } else {
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
        cell.detailTextLabel.text = nil;
    }
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    NSString *text = _titles[indexPath.row];
    if ([text isEqualToString:@"官网"]) {
        NSURL *url = [NSURL URLWithString:@"https://www.bing.com"];
        SFSafariViewController *vc = [[SFSafariViewController alloc] initWithURL:url];
        [self presentViewController:vc animated:YES completion:nil];
    } else if ([text isEqualToString:@"服务条款"]) {
        NSURL *url = [NSURL URLWithString:@"https://www.baidu.com"];
        SFSafariViewController *vc = [[SFSafariViewController alloc] initWithURL:url];
        [self presentViewController:vc animated:YES completion:nil];
    } else if ([text isEqualToString:@"隐私政策"]) {
        NSURL *url = [NSURL URLWithString:@"https://www.google.com"];
        SFSafariViewController *vc = [[SFSafariViewController alloc] initWithURL:url];
        [self presentViewController:vc animated:YES completion:nil];
    } else if ([text isEqualToString:@"清理缓存"]) {
        MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
        hud.mode = MBProgressHUDModeText;
        hud.label.text = @"清理成功";
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [hud hideAnimated:YES];
        });
    }
}

@end
