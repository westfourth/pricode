//
//  KVSubCategoryController.m
//  KuwoVideo
//
//  Created by mac on 2020/6/5.
//  Copyright © 2020 mac. All rights reserved.
//

#import "KVSubCategoryController.h"
#import "KVSubCategoryCell.h"
#import <XSVendor/UIScrollView+XSRefresh.h>
#import <AVKit/AVKit.h>
#import <MBProgressHUD/MBProgressHUD.h>

@interface KVSubCategoryController () <UICollectionViewDataSource, UICollectionViewDelegate> {
    UICollectionView *_collectionView;
    NSMutableArray<KWMVModel *> *_models;
    
    NSUInteger _page;
    BOOL _isRequesting;     //  是否在请求数据
}

@end

@implementation KVSubCategoryController

- (instancetype)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.hidesBottomBarWhenPushed = YES;
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    _models = [NSMutableArray new];
    _page = 1;
    
    [self setupCollectionView];
    [self loadData];
    //
    __weak typeof (self) weak_self = self;
    _collectionView.loadMoreBlock = ^{
        [weak_self loadData];
    };
}

- (void)viewDidLayoutSubviews {
    [super viewDidLayoutSubviews];
    _collectionView.frame = self.view.bounds;
}

- (void)loadData {
    if (_isRequesting) {
        return;
    }
    _isRequesting = YES;
    [KWMVModel request:_type pageNum:_page completion:^(NSError * _Nonnull error, NSArray<KWMVModel *> * _Nonnull models) {
        _isRequesting = NO;
        _page++;
        if (error) {
            return;
        }
        [_models addObjectsFromArray:models];
        [_collectionView reloadData];
    }];
}

- (void)setupCollectionView {
    UICollectionViewFlowLayout *layout = [KVSubCategoryCell flowLayout];
    _collectionView = [[UICollectionView alloc] initWithFrame:CGRectZero collectionViewLayout:layout];
    [self.view addSubview:_collectionView];
    _collectionView.dataSource = self;
    _collectionView.delegate = self;
    
    [_collectionView registerClass:[KVSubCategoryCell class] forCellWithReuseIdentifier:@"ID"];
    _collectionView.backgroundColor = [UIColor whiteColor];
}

//_______________________________________________________________________________________________________________
// MARK: -

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return _models.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    KWMVModel *model = _models[indexPath.row];
    KVSubCategoryCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"ID" forIndexPath:indexPath];
    cell.model = model;
    return cell;
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    KWMVModel *model = _models[indexPath.row];
    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    hud.mode = MBProgressHUDModeIndeterminate;
    hud.label.text = @"正在获取视频地址...";
    [KWMP3MP4 requestMP4:model.id completion:^(NSError * _Nonnull error, NSURL * _Nonnull url) {
        [hud hideAnimated:YES];
        if (error) {
            return;
        }
        AVPlayer *player = [[AVPlayer alloc] initWithURL:url];
        AVPlayerViewController *controller =[[AVPlayerViewController alloc] init];
        controller.player = player;
        [player play];
        [self presentViewController:controller animated:YES completion:nil];
    }];
}

@end
