//
//  KVSubCategoryCell.m
//  KuwoVideo
//
//  Created by mac on 2020/6/5.
//  Copyright © 2020 mac. All rights reserved.
//

#import "KVSubCategoryCell.h"
#import <SDWebImage/SDWebImage.h>
#import "KVTool.h"
#import "KVBundle.h"

@interface KVSubCategoryCell () {
    UIImageView *_imageView;        //  阴影
    UIImageView *_upImageView;      //  图片显示
    UILabel *_titleLabel;
    UIButton *_timesButton;         //  播放次数
    UILabel *_durationLabel;        //  时长
}

@end

@implementation KVSubCategoryCell

float const KVSubCategoryCellRatio = 324.0 / 182.0;   //  宽高比
float const KVSubCategoryCellLineSpacing = 8;
float const KVSubCategoryCellInteritemSpacing = 8;
float const KVSubCategoryCellEdge = 8;                //  两边间距

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        //  _imageView
        _imageView = [UIImageView new];
        [self.contentView addSubview:_imageView];
        [KVTool addShadow:_imageView];
        
        //  _upImageView
        _upImageView = [UIImageView new];
        [_imageView addSubview:_upImageView];
        
        //  _titleLabel
        _titleLabel = [UILabel new];
        [self.contentView addSubview:_titleLabel];
        _titleLabel.font = [UIFont systemFontOfSize:15];
        _titleLabel.textColor = [UIColor darkTextColor];
        
        //  _timesButton
        UIImage *timesImage = [UIImage imageNamed:@"cell_play" inBundle:[KVBundle main] compatibleWithTraitCollection:nil];
        _timesButton = [UIButton new];
        [_imageView addSubview:_timesButton];
        _timesButton.titleLabel.font = [UIFont systemFontOfSize:12];
        [_timesButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [_timesButton setImage:timesImage forState:UIControlStateNormal];
        _timesButton.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
        [KVTool addShadow:_timesButton];
        
        //  _durationLabel
        _durationLabel = [UILabel new];
        [_imageView addSubview:_durationLabel];
        _durationLabel.font = [UIFont systemFontOfSize:12];
        _durationLabel.textColor = [UIColor whiteColor];
        _durationLabel.textAlignment = NSTextAlignmentRight;
        [KVTool addShadow:_durationLabel];
    }
    return self;
}

- (void)layoutSubviews {
    [super layoutSubviews];
    CGFloat imageHeight = [KVSubCategoryCell itemWidth] / KVSubCategoryCellRatio;
    _imageView.frame = CGRectMake(0, 0, self.bounds.size.width, imageHeight);
    _upImageView.frame = _imageView.frame;
    
    //  _titleLabel
    CGSize size = [_titleLabel.text sizeWithAttributes:@{NSFontAttributeName: _titleLabel.font}];
    _titleLabel.frame = CGRectMake(0, CGRectGetMaxY(_imageView.frame) + 6, self.bounds.size.width, size.height);
    
    //  _timesButton
    NSString *playTimesText = [_timesButton titleForState:UIControlStateNormal];
    size = [playTimesText sizeWithAttributes:@{NSFontAttributeName: _timesButton.titleLabel.font}];
    size.width += size.height * 1.25;
    _timesButton.frame = CGRectMake(4, CGRectGetHeight(_imageView.frame) - size.height - 4, size.width, size.height);
    
    //  _durationLabel
    size = [_durationLabel.text sizeWithAttributes:@{NSFontAttributeName: _durationLabel.font}];
    _durationLabel.frame = CGRectMake(CGRectGetWidth(_imageView.frame) - size.width - 4, CGRectGetMinY(_timesButton.frame), size.width, size.height);
}

//_______________________________________________________________________________________________________________
// MARK: -

-(void)setModel:(KWMVModel *)model {
    _model = model;
    [_upImageView sd_setImageWithURL:model.pic];
    _titleLabel.text = model.name;
    NSString *playTimesText = [KVTool playTimesText:model.mvPlayCnt];
    [_timesButton setTitle:playTimesText forState:UIControlStateNormal];
    _durationLabel.text = model.songTimeMinutes;
    [self setNeedsLayout];
}

//_______________________________________________________________________________________________________________
// MARK: -

+ (UICollectionViewFlowLayout *)flowLayout {
    UICollectionViewFlowLayout *layout = [UICollectionViewFlowLayout new];
    layout.minimumLineSpacing = KVSubCategoryCellLineSpacing;
    layout.minimumInteritemSpacing = KVSubCategoryCellInteritemSpacing;
    layout.itemSize = [KVSubCategoryCell itemSize];
    layout.sectionInset = UIEdgeInsetsMake(KVSubCategoryCellEdge, KVSubCategoryCellEdge, KVSubCategoryCellEdge, KVSubCategoryCellEdge);
    return layout;
}

+ (CGFloat)itemWidth {
    int count = 2;          //  每行多少个
    return ([UIScreen mainScreen].bounds.size.width - 2 * KVSubCategoryCellEdge - KVSubCategoryCellInteritemSpacing * (count - 1)) / count;
}

+ (CGSize)itemSize {
    CGFloat width = [KVSubCategoryCell itemWidth];
    CGFloat height = width / KVSubCategoryCellRatio + 28;
    return CGSizeMake(width, height);
}

@end
