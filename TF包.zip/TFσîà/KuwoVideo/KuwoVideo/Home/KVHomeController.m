//
//  KVHomeController.m
//  KuwoVideo
//
//  Created by mac on 2020/6/5.
//  Copyright © 2020 mac. All rights reserved.
//

#import "KVHomeController.h"
#import "KVHomeCell.h"
#import <XSVendor/UIScrollView+XSRefresh.h>
#import <AVKit/AVKit.h>
#import "KVStore.h"

@interface KVHomeController () <UICollectionViewDataSource, UICollectionViewDelegate, UIScrollViewDelegate, KVHomeCellDelegate> {
    UICollectionView *_collectionView;
    NSMutableArray<KWMVModel *> *_models;
    
    AVPlayer *_player;
    NSIndexPath *_playingIndexPath;
    
    NSUInteger _page;
    BOOL _isRequesting;     //  是否在请求数据
}

@end

@implementation KVHomeController

- (void)viewDidLoad {
    [super viewDidLoad];
    _player = [AVPlayer playerWithPlayerItem:nil];
    _playingIndexPath = [NSIndexPath indexPathForRow:0 inSection:0];
    
    _models = [NSMutableArray new];
    _page = 1;
    
    [self setupCollectionView];
    [self loadData];
    //
    __weak typeof (self) weak_self = self;
    _collectionView.loadMoreBlock = ^{
        [weak_self loadData];
    };
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    NSUInteger row = [self targetRow:_collectionView.contentOffset.y];
    NSIndexPath *indexPath = [NSIndexPath indexPathForRow:row inSection:0];
    if (row != _playingIndexPath.row) {
        [self startPlayItem:indexPath];
    } else {
        KVHomeCell *cell = (KVHomeCell *)[_collectionView cellForItemAtIndexPath:indexPath];
        cell.threeLayer.hidden = NO;
        [_player play];
    }
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    [_player pause];
}

- (void)viewDidLayoutSubviews {
    [super viewDidLayoutSubviews];
    _collectionView.frame = self.view.bounds;
}

- (void)loadData {
    if (_isRequesting) {
        return;
    }
    _isRequesting = YES;
    [KWMVModel request:_type pageNum:_page completion:^(NSError * _Nonnull error, NSArray<KWMVModel *> * _Nonnull models) {
        _isRequesting = NO;
        _page++;
        if (error) {
            return;
        }
        [_models addObjectsFromArray:models];
        [_collectionView reloadData];
        [self startPlayItem:_playingIndexPath];
    }];
}

- (void)setupCollectionView {
    UICollectionViewFlowLayout *layout = [KVHomeCell flowLayout];
    _collectionView = [[UICollectionView alloc] initWithFrame:CGRectZero collectionViewLayout:layout];
    [self.view addSubview:_collectionView];
    _collectionView.dataSource = self;
    _collectionView.delegate = self;
    
    [_collectionView registerClass:[KVHomeCell class] forCellWithReuseIdentifier:@"ID"];
    _collectionView.backgroundColor = [UIColor whiteColor];
    _collectionView.scrollsToTop = NO;
}

//_______________________________________________________________________________________________________________
// MARK: -

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return _models.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    KWMVModel *model = _models[indexPath.row];
    KVHomeCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"ID" forIndexPath:indexPath];
    ((AVPlayerLayer *)cell.playerView.layer).player = nil;
    cell.model = model;
    cell.delegate = self;
    return cell;
}

- (void)collectionView:(UICollectionView *)collectionView willDisplayCell:(UICollectionViewCell *)cell forItemAtIndexPath:(NSIndexPath *)indexPath {
    printf(">>> willDisplayCell - %ld\n", indexPath.row);
}

- (void)collectionView:(UICollectionView *)collectionView didEndDisplayingCell:(UICollectionViewCell *)cell forItemAtIndexPath:(NSIndexPath *)indexPath {
    printf(">>> didEndDisplayingCell - %ld\n", indexPath.row);
}

//_______________________________________________________________________________________________________________
// MARK: -  核心

/**
    此方法中，scrollView.dragging = NO，不会触发"scrollViewDidEndDecelerating:"
 */
- (void)scrollViewWillEndDragging:(UIScrollView *)scrollView withVelocity:(CGPoint)velocity targetContentOffset:(inout CGPoint *)targetContentOffset {
    puts("WillEndDragging");
    NSUInteger row = [self targetRow:(*targetContentOffset).y];
    if (row != _playingIndexPath.row) {
        [self endPlayItem:_playingIndexPath];
    }
    //  不会触发scrollViewDidEndDecelerating
    if (scrollView.dragging == NO) {
        [self scrollViewDidEndDecelerating:scrollView];
    }
}

- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView {
    puts("DidEndDecelerating");
    NSUInteger row = [self targetRow:scrollView.contentOffset.y];
    if (_models.count == 0 || row >= _models.count || row < 0) {
        return;
    }
    if (row != _playingIndexPath.row) {
        NSIndexPath *nextPlayIndexPath = [NSIndexPath indexPathForRow:row inSection:0];
        [self startPlayItem:nextPlayIndexPath];
    } else {
        if (_player.timeControlStatus != AVPlayerTimeControlStatusPlaying) {
            KWMVModel *model = _models[row];
            model.isPlaying = YES;
            KVHomeCell *cell = (KVHomeCell *)[_collectionView cellForItemAtIndexPath:_playingIndexPath];
            ((AVPlayerLayer *)cell.playerView.layer).player = _player;
            cell.model = model;
            [_player play];
        }
    }
}

- (void)startPlayItem:(NSIndexPath *)indexPath {
    printf(">>> startPlayItem: %ld\n", indexPath.row);
    if (_models.count == 0 || indexPath.row >= _models.count) {
        return;
    }
    KWMVModel *model = _models[indexPath.row];
    [KWMP3MP4 requestMP4:model.id completion:^(NSError * _Nonnull error, NSURL * _Nonnull url) {
        if (error) {
            return;
        }
        model.playerItem = [AVPlayerItem playerItemWithURL:url];
        model.isPlaying = YES;
        //
        NSIndexPath *preIndexPath = _playingIndexPath;
        [_player replaceCurrentItemWithPlayerItem:model.playerItem];
        _playingIndexPath = indexPath;
        if (indexPath == preIndexPath) {
            [_collectionView reloadItemsAtIndexPaths:@[indexPath]];
        } else {
            [_collectionView reloadItemsAtIndexPaths:@[preIndexPath, indexPath]];
        }
        KVHomeCell *cell = (KVHomeCell *)[_collectionView cellForItemAtIndexPath:indexPath];
        ((AVPlayerLayer *)cell.playerView.layer).player = _player;
        [_player play];
    }];
}

- (void)endPlayItem:(NSIndexPath *)indexPath {
    printf(">>> endPlayItem: %ld\n", indexPath.row);
    if (_models.count == 0 || indexPath.row >= _models.count) {
        return;
    }
    KWMVModel *model = _models[indexPath.row];
    model.isPlaying = NO;
    KVHomeCell *cell = (KVHomeCell *)[_collectionView cellForItemAtIndexPath:indexPath];
    ((AVPlayerLayer *)cell.playerView.layer).player = nil;
    cell.model = model;
    [_player pause];
}

- (NSUInteger)targetRow:(CGFloat)targetOffsetY {
    UICollectionViewFlowLayout *flow = (UICollectionViewFlowLayout *)_collectionView.collectionViewLayout;
    CGFloat flowLayoutHeight = flow.itemSize.height + flow.minimumLineSpacing;
    NSUInteger row = ceil((targetOffsetY + _collectionView.adjustedContentInset.top) / flowLayoutHeight);
    return row;
}

//MARK:-    KVHomeCellDelegate

- (void)cell:(KVHomeCell *)cell didClickCollectButton:(UIButton *)button {
    KWMVModel *model = cell.model;
    model.selected = !model.selected;
    cell.model = model;
    
    //  存储
    [KVStore.models addObject:model];
    [KVStore write];
}

@end
