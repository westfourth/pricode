//
//  KVHomeCell.h
//  KuwoVideo
//
//  Created by mac on 2020/6/5.
//  Copyright © 2020 mac. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <KWNetwork/KWNetwork.h>
@protocol KVHomeCellDelegate;

NS_ASSUME_NONNULL_BEGIN

@interface PlayerImageView : UIImageView
@end


@interface KVHomeCell : UICollectionViewCell

@property (weak, nonatomic) id<KVHomeCellDelegate> delegate;

@property (nonatomic) PlayerImageView *playerView;
@property (nonatomic) CALayer *threeLayer;

+ (UICollectionViewFlowLayout *)flowLayout;

+ (CGSize)itemSize;

@property (nonatomic) KWMVModel *model;

@end


@protocol KVHomeCellDelegate <NSObject>

- (void)cell:(KVHomeCell *)cell didClickCollectButton:(UIButton *)button;

@end

NS_ASSUME_NONNULL_END
