//
//  KVHomeCell.m
//  KuwoVideo
//
//  Created by mac on 2020/6/5.
//  Copyright © 2020 mac. All rights reserved.
//

#import "KVHomeCell.h"
#import <SDWebImage/SDWebImage.h>
#import <AVFoundation/AVFoundation.h>
#import "KVTool.h"
#import "KVBundle.h"

@implementation PlayerImageView
+ (Class)layerClass {
    return [AVPlayerLayer class];
}
@end


@interface KVHomeCell () {
    UIImageView *_imageView;        //  阴影
    UILabel *_titleLabel;
    UIButton *_timesButton;         //  播放次数
    UILabel *_durationLabel;        //  时长
    UIButton *_collectButton;       //  收藏
}

@end

@implementation KVHomeCell

float const KVHomeCellRatio = 324.0 / 182.0;   //  宽高比
float const KVHomeCellLineSpacing = 8;
float const KVHomeCellInteritemSpacing = 8;
float const KVHomeCellEdge = 8;                //  两边间距

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        //  _imageView
        _imageView = [UIImageView new];
        [self.contentView addSubview:_imageView];
        [KVTool addShadow:_imageView];
        _imageView.userInteractionEnabled = YES;
        
        //  _upImageView
        _playerView = [PlayerImageView new];
        [_imageView addSubview:_playerView];
        
        //  _titleLabel
        _titleLabel = [UILabel new];
        [self.contentView addSubview:_titleLabel];
        _titleLabel.font = [UIFont systemFontOfSize:16];
        _titleLabel.textColor = [UIColor darkTextColor];
        
        //  _timesButton
        UIImage *timesImage = [UIImage imageNamed:@"cell_play" inBundle:[KVBundle main] compatibleWithTraitCollection:nil];
        _timesButton = [UIButton new];
        [_imageView addSubview:_timesButton];
        _timesButton.titleLabel.font = [UIFont systemFontOfSize:13];
        [_timesButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [_timesButton setImage:timesImage forState:UIControlStateNormal];
        _timesButton.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
        [KVTool addShadow:_timesButton];
        
        //  _collectButton
        UIImage *collectImage0 = [UIImage imageNamed:@"collect_0" inBundle:[KVBundle main] compatibleWithTraitCollection:nil];
        UIImage *collectImage1 = [UIImage imageNamed:@"collect_1" inBundle:[KVBundle main] compatibleWithTraitCollection:nil];
        _collectButton = [UIButton new];
        [_imageView addSubview:_collectButton];
        [_collectButton setImage:collectImage0 forState:UIControlStateNormal];
        [_collectButton setImage:collectImage1 forState:UIControlStateSelected];
        [_collectButton addTarget:self action:@selector(clickCollectButton:) forControlEvents:UIControlEventTouchUpInside];
        [KVTool addShadow:_collectButton];
        
        //  _durationLabel
        _durationLabel = [UILabel new];
        [_imageView addSubview:_durationLabel];
        _durationLabel.font = [UIFont systemFontOfSize:13];
        _durationLabel.textColor = [UIColor whiteColor];
        _durationLabel.textAlignment = NSTextAlignmentRight;
        [KVTool addShadow:_durationLabel];
        
        //
        _threeLayer = [CALayer layer];
        [self.contentView.layer addSublayer:_threeLayer];
//        _threeLayer.hidden = YES;
        [self addAnims];
    }
    return self;
}

- (void)layoutSubviews {
    [super layoutSubviews];
    CGFloat imageHeight = [KVHomeCell itemWidth] / KVHomeCellRatio;
    _imageView.frame = CGRectMake(0, 0, self.bounds.size.width, imageHeight);
    _playerView.frame = _imageView.frame;
    
    //  _titleLabel
    CGSize size = [_titleLabel.text sizeWithAttributes:@{NSFontAttributeName: _titleLabel.font}];
    _titleLabel.frame = CGRectMake(0, CGRectGetMaxY(_imageView.frame) + 6, self.bounds.size.width, size.height);
    
    //  _timesButton
    NSString *playTimesText = [_timesButton titleForState:UIControlStateNormal];
    size = [playTimesText sizeWithAttributes:@{NSFontAttributeName: _timesButton.titleLabel.font}];
    size.width += size.height * 1.25;
    _timesButton.frame = CGRectMake(4, CGRectGetHeight(_imageView.frame) - size.height - 4, size.width, size.height);
    
    //  _durationLabel
    size = [_durationLabel.text sizeWithAttributes:@{NSFontAttributeName: _durationLabel.font}];
    _durationLabel.frame = CGRectMake(CGRectGetWidth(_imageView.frame) - size.width - 4, CGRectGetMinY(_timesButton.frame), size.width, size.height);
    
    //  _collectButton
    size = CGSizeMake(44, 44);
    _collectButton.frame = CGRectMake(CGRectGetWidth(_imageView.frame) - size.width, 0,
                                      size.width, size.height);
    
    //
    size = CGSizeMake(20, 20);
    _threeLayer.frame = CGRectMake(CGRectGetMinX(_durationLabel.frame) - size.width - 8,
                                CGRectGetHeight(_imageView.frame) - size.height - 2,
                                size.width, size.height);
}

- (void)addAnims {
    for (int i = 0; i < 3; i++) {
        CAShapeLayer *layer = [CAShapeLayer new];
        [_threeLayer addSublayer:layer];
        CGSize size = CGSizeMake(20, 20);

        UIBezierPath *path = [UIBezierPath bezierPath];
        layer.path = path.CGPath;
        layer.fillColor = [UIColor whiteColor].CGColor;

        CAKeyframeAnimation *anim = [CAKeyframeAnimation new];
        anim.keyPath = @"path";
        CGFloat startX = size.width / 3 * i;
        CGFloat width = size.width / 3 - 2;
        anim.values = @[
            (__bridge id)[UIBezierPath bezierPathWithRect:CGRectMake(startX, 0, width, size.height)].CGPath,
            (__bridge id)[UIBezierPath bezierPathWithRect:CGRectMake(startX, size.height, width, 0)].CGPath,
        ];
        anim.autoreverses = YES;
        anim.duration = 0.4;
        anim.speed = 1 + (i - 2) * 0.25;
//        anim.timeOffset = i + 0.25;
        anim.repeatCount = HUGE_VALF;
        [layer addAnimation:anim forKey:@"a"];
    }
}

//_______________________________________________________________________________________________________________
// MARK: -

-(void)setModel:(KWMVModel *)model {
    _model = model;
    [_playerView sd_setImageWithURL:model.pic];
    _titleLabel.text = model.name;
    NSString *playTimesText = [KVTool playTimesText:model.mvPlayCnt];
    [_timesButton setTitle:playTimesText forState:UIControlStateNormal];
    _durationLabel.text = model.songTimeMinutes;
    _collectButton.selected = model.selected;
    _threeLayer.hidden = !model.isPlaying;
    [self setNeedsLayout];
}

- (void)clickCollectButton:(UIButton *)button {
    [self.delegate cell:self didClickCollectButton:button];
}


//_______________________________________________________________________________________________________________
// MARK: -

+ (UICollectionViewFlowLayout *)flowLayout {
    UICollectionViewFlowLayout *layout = [UICollectionViewFlowLayout new];
    layout.minimumLineSpacing = KVHomeCellLineSpacing;
    layout.minimumInteritemSpacing = KVHomeCellInteritemSpacing;
    layout.itemSize = [KVHomeCell itemSize];
    layout.sectionInset = UIEdgeInsetsMake(KVHomeCellEdge, KVHomeCellEdge, KVHomeCellEdge, KVHomeCellEdge);
    return layout;
}

+ (CGFloat)itemWidth {
    int count = 1;          //  每行多少个
    return ([UIScreen mainScreen].bounds.size.width - 2 * KVHomeCellEdge - KVHomeCellInteritemSpacing * (count - 1)) / count;
}

+ (CGSize)itemSize {
    CGFloat width = [KVHomeCell itemWidth];
    CGFloat height = width / KVHomeCellRatio + 32;
    return CGSizeMake(width, height);
}


@end
