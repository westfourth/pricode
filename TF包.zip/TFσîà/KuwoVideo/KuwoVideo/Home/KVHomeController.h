//
//  KVHomeController.h
//  KuwoVideo
//
//  Created by mac on 2020/6/5.
//  Copyright © 2020 mac. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <KWNetwork/KWNetwork.h>

NS_ASSUME_NONNULL_BEGIN

@interface KVHomeController : UIViewController

@property (nonatomic) KWMVType type;

@end

NS_ASSUME_NONNULL_END
