//
//  FYHomeController.m
//  Translator
//
//  Created by mac on 2020/6/2.
//  Copyright © 2020 mac. All rights reserved.
//

#import <AVFoundation/AVSpeechSynthesis.h>
#import "FYHomeController.h"
#import "FYConvert.h"
#import "FYListController.h"
#import "FYStore.h"
#import "FYBundle.h"

@interface FYHomeController () <UITextViewDelegate> {
    //  zh-CN、zh-HK、zh-TW
    AVSpeechSynthesizer *_synthesizer;
}
@property (weak, nonatomic) IBOutlet UIButton *leftButton;
@property (weak, nonatomic) IBOutlet UIButton *rightButton;

@property (weak, nonatomic) IBOutlet UITextView *textView0;
@property (weak, nonatomic) IBOutlet UITextView *textView1;

@property (weak, nonatomic) IBOutlet UIButton *collectButton;

@end

@implementation FYHomeController

- (instancetype)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:NSStringFromClass([self class]) bundle:[FYBundle main]];
    if (self) {
        
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = @"简繁体转换";
    self.type = FYConvertType_s2twp;
    _synthesizer = [AVSpeechSynthesizer new];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(listenNotification:) name:FYNotificationName object:nil];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    if ([[FYStore share].texts containsObject:self.textView0.text]) {
        self.collectButton.selected = YES;
    } else {
        self.collectButton.selected = NO;
    }
}

- (void)setType:(FYConvertType)type {
    _type = type;
    [FYConvert share].type = type;
    //  更新显示
    NSString *allText = [FYConvert zhMap][@(type)];
    NSArray *texts = [allText componentsSeparatedByString:@" <-> "];
    [self.leftButton setTitle:texts.firstObject forState:UIControlStateNormal];
    [self.rightButton setTitle:texts.lastObject forState:UIControlStateNormal];
    //  更新转换
    NSString *text1 = [[FYConvert share] convert:self.textView0.text];
    self.textView1.text = text1;
}

//MARK:-    事件

- (IBAction)clickExchange:(UIButton *)sender {
    [self gotoFYListController];
}

- (IBAction)clickSpeak0Button:(id)sender {
    AVSpeechUtterance *utterance = [AVSpeechUtterance speechUtteranceWithString:self.textView0.text];
    utterance.voice = [AVSpeechSynthesisVoice voiceWithLanguage:@"zh-CN"];
    [_synthesizer speakUtterance:utterance];
}

- (IBAction)clickSpeak1Button:(UIButton *)sender {
    AVSpeechUtterance *utterance = [AVSpeechUtterance speechUtteranceWithString:self.textView1.text];
    utterance.voice = [AVSpeechSynthesisVoice voiceWithLanguage:@"zh-TW"];
    [_synthesizer speakUtterance:utterance];
}

- (IBAction)clickCloseButton:(UIButton *)sender {
    self.textView0.text = @"";
    self.textView1.text = @"";
}

- (IBAction)clickCollectButton:(UIButton *)sender {
    if (self.textView0.text.length == 0) {
        return;
    }
    if ([[FYStore share].texts containsObject:self.textView0.text]) {
        self.collectButton.selected = NO;
        [[FYStore share].texts removeObject:self.textView0.text];
    } else {
        [[FYStore share].texts addObject:self.textView0.text];
        self.collectButton.selected = YES;
    }
    //  保存
    [FYStore share].texts = [FYStore share].texts;
}

- (IBAction)clickCopyButton:(UIButton *)sender {
    [UIPasteboard generalPasteboard].string = self.textView1.text;
}

- (void)listenNotification:(NSNotification *)noti {
    self.tabBarController.selectedIndex = 0;
    NSString *text0 = noti.object;
    NSString *text1 = [[FYConvert share] convert:text0];
    self.textView0.text = text0;
    self.textView1.text = text1;
}

- (void)gotoFYListController {
    FYListController *vc = [FYListController new];
    vc.type = self.type;
    __weak typeof(self) weak_self = self;
    vc.didChooseType = ^(FYConvertType type) {
        weak_self.type = type;
    };
    UINavigationController *navVC = [[UINavigationController alloc] initWithRootViewController:vc];
    navVC.modalPresentationStyle = UIModalPresentationFullScreen;
    [self presentViewController:navVC animated:YES completion:nil];
}

//MARK:-    UITextViewDelegate

- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text {
    if ([text isEqualToString:@"\n"]) {
        [textView resignFirstResponder];
    }
    return YES;
}

- (void)textViewDidChange:(UITextView *)textView {
    NSString *text1 = [[FYConvert share] convert:textView.text];
    self.textView1.text = text1;
    //
    if ([[FYStore share].texts containsObject:textView.text]) {
        self.collectButton.selected = YES;
    } else {
        self.collectButton.selected = NO;
    }
}

@end
