//
//  FYSaveCell.h
//  Translator
//
//  Created by mac on 2020/6/3.
//  Copyright © 2020 mac. All rights reserved.
//

#import <UIKit/UIKit.h>
@protocol FYSaveCellDelegate;

NS_ASSUME_NONNULL_BEGIN

@interface FYSaveCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *label;
@property (weak, nonatomic) IBOutlet UIButton *button;

@property (nonatomic) id<FYSaveCellDelegate> delegate;

@end

@protocol FYSaveCellDelegate <NSObject>

- (void)cell:(FYSaveCell *)cell didClickButton:(UIButton *)buton;

@end

NS_ASSUME_NONNULL_END
