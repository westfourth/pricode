//
//  FYSaveCell.m
//  Translator
//
//  Created by mac on 2020/6/3.
//  Copyright © 2020 mac. All rights reserved.
//

#import "FYSaveCell.h"

@implementation FYSaveCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
- (IBAction)clickButton:(id)sender {
    [self.delegate cell:self didClickButton:sender];
}

@end
