//
//  FYWebViewController.m
//  Translator
//
//  Created by mac on 2020/6/3.
//  Copyright © 2020 mac. All rights reserved.
//

#import "FYWebViewController.h"
#import <WebKit/WebKit.h>
#import "FYBundle.h"

@interface FYWebViewController ()
@property (nonatomic) WKWebView *webVeiw;

@end

@implementation FYWebViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.webVeiw = [WKWebView new];
    [self.view addSubview:self.webVeiw];
    self.webVeiw.frame = self.view.frame;
    
    NSString *path = [[FYBundle main] pathForResource:self.htmlName ofType:@"html"];
    NSURL *url = [NSURL fileURLWithPath:path];
    [self.webVeiw loadFileURL:url allowingReadAccessToURL:url];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
