//
//  FYStore.m
//  Translator
//
//  Created by mac on 2020/6/3.
//  Copyright © 2020 mac. All rights reserved.
//

#import "FYStore.h"
#import "FYBundle.h"

static NSString *kFYStoreKey = @"kFYStoreKey";
static NSString *kFYStoreDidAddKey = @"kFYStoreDidAddKey";
NSString *const FYNotificationName = @"FYNotificationName";

@implementation FYStore
@synthesize texts = _texts;

+ (instancetype)share {
    static FYStore *instance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [FYStore new];
    });
    return instance;
}

- (instancetype)init
{
    self = [super init];
    if (self) {
        if (self.didAddInit == NO) {
            NSString *path = [[FYBundle main] pathForResource:@"InitSave" ofType:@"plist"];
            NSArray *array = [NSArray arrayWithContentsOfFile:path];
            self.texts = [NSMutableArray arrayWithArray:array];
            self.didAddInit = YES;
        }
    }
    return self;
}

- (BOOL)didAddInit {
    return [[NSUserDefaults standardUserDefaults] boolForKey:kFYStoreDidAddKey];
}

- (void)setDidAddInit:(BOOL)didAddInit {
    [[NSUserDefaults standardUserDefaults] setBool:didAddInit forKey:kFYStoreDidAddKey];
}

- (NSMutableArray<NSString *> *)texts {
    if (_texts) {
        return _texts;
    }
    NSArray *array = [[NSUserDefaults standardUserDefaults] arrayForKey:kFYStoreKey];
    _texts = [NSMutableArray arrayWithArray:array];
    if (!_texts) {
        _texts = [NSMutableArray array];
    }
    return _texts;
}

- (void)setTexts:(NSMutableArray<NSString *> *)texts {
    _texts = texts;
    [[NSUserDefaults standardUserDefaults] setObject:texts forKey:kFYStoreKey];
}

@end
