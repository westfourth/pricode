//
//  FYSaveController.m
//  Translator
//
//  Created by mac on 2020/6/2.
//  Copyright © 2020 mac. All rights reserved.
//

#import "FYSaveController.h"
#import "FYBundle.h"
#import "FYStore.h"
#import "FYSaveCell.h"

@interface FYSaveController () <UITableViewDataSource, UITableViewDelegate, FYSaveCellDelegate>
@property (weak, nonatomic) IBOutlet UITableView *tableView;

@end

@implementation FYSaveController

- (instancetype)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:NSStringFromClass([self class]) bundle:[FYBundle main]];
    if (self) {
        
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    UINib *nib = [UINib nibWithNibName:@"FYSaveCell" bundle:[FYBundle main]];
    [self.tableView registerNib:nib forCellReuseIdentifier:@"ID"];
    self.tableView.tableFooterView = [UIView new];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [self.tableView reloadData];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [FYStore share].texts.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    FYSaveCell *cell = [tableView dequeueReusableCellWithIdentifier:@"ID" forIndexPath:indexPath];
    NSArray *array = [FYStore share].texts;
    NSString *text = array[indexPath.row];
    cell.label.text = text;
    cell.button.selected = [array containsObject:text];
    cell.delegate = self;
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    NSArray *array = [FYStore share].texts;
    NSString *text = array[indexPath.row];
    [[NSNotificationCenter defaultCenter] postNotificationName:FYNotificationName object:text];
}

//MARK:-    事件

- (void)cell:(FYSaveCell *)cell didClickButton:(UIButton *)buton {
    NSString *text = cell.label.text;
    if ([[FYStore share].texts containsObject:text]) {
        [[FYStore share].texts removeObject:text];
    } else {
        [[FYStore share].texts addObject:text];
    }
    //
    NSInteger row = [[FYStore share].texts indexOfObject:text];
    //  保存
    [FYStore share].texts = [FYStore share].texts;
    [self.tableView reloadRowsAtIndexPaths:@[[NSIndexPath indexPathForRow:row inSection:0]] withRowAnimation:UITableViewRowAnimationAutomatic];
}


@end
