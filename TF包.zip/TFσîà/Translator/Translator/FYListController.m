//
//  FYListController.m
//  Translator
//
//  Created by mac on 2020/6/2.
//  Copyright © 2020 mac. All rights reserved.
//

#import "FYListController.h"
#import "FYConvert.h"
#import "FYBundle.h"
#import "FYListCell.h"

@interface FYListController ()

@end

@implementation FYListController

- (instancetype)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:NSStringFromClass([self class]) bundle:[FYBundle main]];
    if (self) {
        
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    UIImage *image = [UIImage imageNamed:@"close" inBundle:[FYBundle main] compatibleWithTraitCollection:nil];
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithImage:image style:UIBarButtonItemStyleDone target:self action:@selector(clickItem:)];
    //
    UINib *nib = [UINib nibWithNibName:@"FYListCell" bundle:[FYBundle main]];
    [self.tableView registerNib:nib forCellReuseIdentifier:@"ID"];
    self.tableView.tableFooterView = [UIView new];
    self.tableView.rowHeight = 50;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [FYConvert zhMap].count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    FYListCell *cell = [tableView dequeueReusableCellWithIdentifier:@"ID" forIndexPath:indexPath];
    FYConvertType type = indexPath.row;
    NSString *allText = [FYConvert zhMap][@(type)];
    NSArray *texts = [allText componentsSeparatedByString:@" <-> "];
    cell.leftLabel.text = texts.firstObject;
    cell.rightLabel.text = texts.lastObject;
    cell.checkButton.hidden = indexPath.row != self.type;
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    FYConvertType type = indexPath.row;
    self.type = type;
    [tableView reloadSections:[NSIndexSet indexSetWithIndex:0] withRowAnimation:UITableViewRowAnimationAutomatic];
    if (self.didChooseType) self.didChooseType(type);
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [self dismissViewControllerAnimated:YES completion:nil];
    });
}

//MARK:-    事件

- (void)clickItem:(UIBarButtonItem *)item {
    [self dismissViewControllerAnimated:YES completion:nil];
}


@end
