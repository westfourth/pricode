//
//  AppDelegate.m
//  Translator
//
//  Created by mac on 2020/6/2.
//  Copyright © 2020 mac. All rights reserved.
//

#import "AppDelegate.h"
#import "FYTabBarController.h"

@interface AppDelegate ()

@end

@implementation AppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    puts(NSTemporaryDirectory().UTF8String);
    //
    UIWindow *window = [UIWindow new];
    window.frame = [UIScreen mainScreen].bounds;
    [window makeKeyAndVisible];
    self.window = window;
    self.window.rootViewController = [FYTabBarController new];
    
    return YES;
}


@end
