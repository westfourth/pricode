//
//  FYStore.h
//  Translator
//
//  Created by mac on 2020/6/3.
//  Copyright © 2020 mac. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

extern NSString *const FYNotificationName;

@interface FYStore : NSObject

+ (instancetype)share;

@property (nonatomic) BOOL didAddInit;

@property (nonatomic) NSMutableArray<NSString *> *texts;

@end

NS_ASSUME_NONNULL_END
