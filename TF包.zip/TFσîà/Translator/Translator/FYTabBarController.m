//
//  FYTabBarController.m
//  Translator
//
//  Created by mac on 2020/6/2.
//  Copyright © 2020 mac. All rights reserved.
//

#import "FYTabBarController.h"
#import "FYBundle.h"

@interface FYTabBarController ()

@end

@implementation FYTabBarController

- (void)viewDidLoad {
    [super viewDidLoad];
    NSString *path = [[FYBundle main] pathForResource:@"Tabbar" ofType:@"plist"];
    NSArray *array = [NSArray arrayWithContentsOfFile:path];
    
    UIColor *barTintColor = [UIColor colorWithRed:0 / 255.0
                                            green:115 / 255.0
                                             blue:228 / 255.0
                                            alpha:1];
    
    NSMutableArray<UINavigationController *> *controllers = [NSMutableArray new];
    
    for (NSDictionary *dict in array) {
        Class cls = NSClassFromString(dict[@"controller"]);
        //  vc
        UIViewController *vc = [cls new];
        vc.navigationItem.title = dict[@"title"];
        
        
        //  TabBarItem
        UIImage *image = [UIImage imageNamed:dict[@"image"] inBundle:[FYBundle main] compatibleWithTraitCollection:nil];
        UITabBarItem *item = [[UITabBarItem alloc] initWithTitle:dict[@"title"] image:image selectedImage:nil];
        
        //  navVC
        UINavigationController *navVC = [[UINavigationController alloc] initWithRootViewController:vc];
        navVC.tabBarItem = item;
        navVC.navigationBar.barTintColor = barTintColor;
        navVC.navigationBar.tintColor = [UIColor whiteColor];
        navVC.navigationBar.titleTextAttributes = @{NSForegroundColorAttributeName: [UIColor whiteColor]};
        [controllers addObject:navVC];
    }
    self.viewControllers = controllers;
    self.tabBar.tintColor = barTintColor;
}


@end
