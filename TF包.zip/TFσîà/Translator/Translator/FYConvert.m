//
//  FYConvert.m
//  ChineseConvert
//
//  Created by mac on 2020/3/31.
//  Copyright © 2020 mac. All rights reserved.
//

#import "FYConvert.h"
#import "FYBundle.h"

@implementation FYConvert

+ (instancetype)share {
    static id instance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [[self class] new];
    });
    return instance;
}

+ (NSDictionary *)config {
    return @{
        @(FYConvertType_s2t): @"s2t",
        @(FYConvertType_t2s): @"t2s",
        
        @(FYConvertType_s2tw): @"s2tw",
        @(FYConvertType_tw2s): @"tw2s",
        @(FYConvertType_s2hk): @"s2hk",
        @(FYConvertType_hk2s): @"hk2s",
        
        @(FYConvertType_t2tw): @"t2tw",
        @(FYConvertType_t2hk): @"t2hk",
        @(FYConvertType_t2jp): @"t2jp",
        
        @(FYConvertType_s2twp): @"s2twp",
        @(FYConvertType_tw2sp): @"tw2sp",
    };
}

+ (NSDictionary *)zhMap {
    return @{
        @(FYConvertType_s2t): @"简体 <-> 繁体",
        @(FYConvertType_t2s): @"繁体 <-> 简体",
        
        @(FYConvertType_s2tw): @"简体 <-> 台湾繁体",
        @(FYConvertType_tw2s): @"台湾繁体 <-> 简体",
        @(FYConvertType_s2hk): @"简体 <-> 香港繁体",
        @(FYConvertType_hk2s): @"香港繁体 <-> 简体",
        
        @(FYConvertType_t2tw): @"繁体 <-> 台湾繁体",
        @(FYConvertType_t2hk): @"繁体 <-> 香港繁体",
        @(FYConvertType_t2jp): @"繁体 <-> 日文新字体",
        
        @(FYConvertType_s2twp): @"简体 <-> 台湾常用词汇",
        @(FYConvertType_tw2sp): @"台湾繁体 <-> 大陆常用词汇",
    };
}

- (void)setType:(FYConvertType)type {
    _type = type;
    NSString *name = [FYConvert config][@(type)];
    NSString *config = [[FYBundle main] pathForResource:name ofType:@"json"];
    opencc_close(_opencc);
    _opencc = opencc_open(config.UTF8String);
}

- (NSString *)convert:(NSString *)text {
    const char *s = text.UTF8String;
    const char *s2 = opencc_convert_utf8(_opencc, s, strlen(s));
    NSString *text2 = [NSString stringWithCString:s2 encoding:NSUTF8StringEncoding];
    return text2;
}

@end
