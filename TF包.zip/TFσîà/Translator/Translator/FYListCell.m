//
//  FYListCell.m
//  Translator
//
//  Created by mac on 2020/6/3.
//  Copyright © 2020 mac. All rights reserved.
//

#import "FYListCell.h"

@implementation FYListCell

- (void)awakeFromNib {
    [super awakeFromNib];
}


@end
