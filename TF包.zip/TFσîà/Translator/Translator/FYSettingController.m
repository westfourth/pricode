//
//  FYSettingController.m
//  Translator
//
//  Created by mac on 2020/6/2.
//  Copyright © 2020 mac. All rights reserved.
//

#import <SafariServices/SafariServices.h>
#import "FYSettingController.h"
#import "FYWebViewController.h"
#import "FYBundle.h"

@interface FYSettingController () <UITableViewDataSource, UITableViewDelegate> {
    NSArray *_titles;
}
@property (weak, nonatomic) IBOutlet UITableView *tableView;

@end

@implementation FYSettingController

- (instancetype)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:NSStringFromClass([self class]) bundle:[FYBundle main]];
    if (self) {
        
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    _titles = @[@"帮助", @"用户协议", @"隐私政策", @"联系我们"];
    self.tableView.tableFooterView = [UIView new];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return _titles.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"ID"];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:@"ID"];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    NSString *text = _titles[indexPath.row];
    cell.textLabel.text = text;
    if ([text isEqualToString:@"联系我们"]) {
        cell.accessoryType = UITableViewCellAccessoryNone;
        cell.detailTextLabel.text = @"mzhus8@163.com";
    } else {
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
        cell.detailTextLabel.text = nil;
    }
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    NSString *text = _titles[indexPath.row];
    if ([text isEqualToString:@"帮助"]) {
        FYWebViewController *vc = [FYWebViewController new];
        vc.hidesBottomBarWhenPushed = YES;
        vc.title = @"帮助";
        vc.htmlName = @"help";
        [self.navigationController pushViewController:vc animated:YES];
    } else if ([text isEqualToString:@"用户协议"]) {
        FYWebViewController *vc = [FYWebViewController new];
        vc.hidesBottomBarWhenPushed = YES;
        vc.title = @"用户协议";
        vc.htmlName = @"agreement";
        [self.navigationController pushViewController:vc animated:YES];
    } else if ([text isEqualToString:@"隐私政策"]) {
        FYWebViewController *vc = [FYWebViewController new];
        vc.hidesBottomBarWhenPushed = YES;
        vc.title = @"隐私政策";
        vc.htmlName = @"policy";
        [self.navigationController pushViewController:vc animated:YES];
    }
}

@end
