//
//  FYConvert.h
//  ChineseConvert
//
//  Created by mac on 2020/3/31.
//  Copyright © 2020 mac. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "opencc.h"

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger, FYConvertType) {
    FYConvertType_s2t,              //  简体到繁体
    FYConvertType_t2s,              //  繁体到简体
    
    FYConvertType_s2tw,             //  简体到台湾繁体
    FYConvertType_tw2s,             //  台湾繁体到简体
    FYConvertType_s2hk,             //  简体到香港繁体
    FYConvertType_hk2s,             //  香港繁体到简体
    
    FYConvertType_t2tw,             //  繁体到台湾繁体
    FYConvertType_t2hk,             //  繁体到香港繁体
    FYConvertType_t2jp,             //  繁体到日文新字体
    
    FYConvertType_s2twp,            //  简体到台湾常用词汇
    FYConvertType_tw2sp,            //  台湾繁体到大陆常用词汇
};

@interface FYConvert : NSObject {
    opencc_t _opencc;
}

+ (NSDictionary *)zhMap;

+ (instancetype)share;

@property (nonatomic) FYConvertType type;

- (NSString *)convert:(NSString *)text;

@end

NS_ASSUME_NONNULL_END
