//
//  KWNetworkTests.m
//  KWNetworkTests
//
//  Created by mac on 2020/3/17.
//  Copyright © 2020 mac. All rights reserved.
//

#import <XCTest/XCTest.h>
#import "KWRequest.h"
#import "KWRankModel.h"
#import "KWSongModel.h"
#import "KWSingerModel.h"
#import "KWSongListModel.h"
#import "KWSongTagModel.h"
#import "KWMVModel.h"
#import "KWMP3MP4.h"
#import "KWSongListInfoModel.h"

@interface KWNetworkTests : XCTestCase

@end

@implementation KWNetworkTests

- (void)setUp {
    // Put setup code here. This method is called before the invocation of each test method in the class.
}

- (void)tearDown {
    // Put teardown code here. This method is called after the invocation of each test method in the class.
}


- (void)testGetToken {
    NSString *str = @"api/www/rcm/index/playlist?id=rcm&pn=1&rn=5";
    XCTestExpectation *e = [[XCTestExpectation alloc] initWithDescription:@"testRequest"];
    [[KWRequest share] request:str dictCompletion:^(NSError * _Nonnull error, NSDictionary * _Nonnull dict) {
        [e fulfill];
    }];
    [self waitForExpectations:@[e] timeout:5];
}


- (void)testKWRankModel {
    XCTestExpectation *e = [[XCTestExpectation alloc] initWithDescription:@"testRequest"];
    [KWRankModel requestWithCompletion:^(NSError * _Nonnull error, NSArray<KWRankModel *> * _Nonnull models) {
        [e fulfill];
    }];
    [self waitForExpectations:@[e] timeout:5];
}

- (void)testKWSongModel {
    XCTestExpectation *e = [[XCTestExpectation alloc] initWithDescription:@"testRequest"];
    [KWSongModel requestRank:93 pageNum:1 completion:^(NSError * _Nonnull error, NSArray<KWSongModel *> * _Nonnull models) {
        [e fulfill];
    }];
    [self waitForExpectations:@[e] timeout:5];
}

- (void)testSearchKWSongModel {
    XCTestExpectation *e = [[XCTestExpectation alloc] initWithDescription:@"testRequest"];
    [KWSongModel requestSearch:@"bandari" pageNum:1 completion:^(NSError * _Nonnull error, NSArray<KWSongModel *> * _Nonnull models) {
        [e fulfill];
    }];
    [self waitForExpectations:@[e] timeout:5];
}

- (void)testKWSingerModel {
    XCTestExpectation *e = [[XCTestExpectation alloc] initWithDescription:@"testRequest"];
    [KWSingerModel request:0 prefix:@"" pageNum:1 completion:^(NSError * _Nonnull error, NSArray<KWSingerModel *> * _Nonnull models) {
        [e fulfill];
    }];
    [self waitForExpectations:@[e] timeout:5];
}

- (void)testKWSongListModel {
    XCTestExpectation *e = [[XCTestExpectation alloc] initWithDescription:@"testRequest"];
    [KWSongListModel request:KWSongListTypeNew pageNum:1 completion:^(NSError * _Nonnull error, NSArray<KWSongListModel *> * _Nonnull models) {
        [e fulfill];
    }];
    [self waitForExpectations:@[e] timeout:5];
}

- (void)testKWSongTagModel {
    XCTestExpectation *e = [[XCTestExpectation alloc] initWithDescription:@"testRequest"];
    [KWSongTagModel requestWithCompletion:^(NSError * _Nonnull error, NSArray<KWSongTagModel *> * _Nonnull models) {
        [e fulfill];
    }];
    [self waitForExpectations:@[e] timeout:5];
}

- (void)testKWSongListModel2 {
    XCTestExpectation *e = [[XCTestExpectation alloc] initWithDescription:@"testRequest"];
    [KWSongListModel requestWithTag:1848 pageNum:1 completion:^(NSError * _Nonnull error, NSArray<KWSongListModel *> * _Nonnull models) {
        [e fulfill];
    }];
    [self waitForExpectations:@[e] timeout:5];
}

- (void)testKWMVModel {
    XCTestExpectation *e = [[XCTestExpectation alloc] initWithDescription:@"testRequest"];
    [KWMVModel request:KWMVTypePremiere pageNum:1 completion:^(NSError * _Nonnull error, NSArray<KWMVModel *> * _Nonnull models) {
        [e fulfill];
    }];
    [self waitForExpectations:@[e] timeout:5];
}

- (void)testKWSongListInfoModel {
    XCTestExpectation *e = [[XCTestExpectation alloc] initWithDescription:@"testRequest"];
    [KWSongListInfoModel request:2976871742 pageNum:1 completion:^(NSError * _Nonnull error, NSArray<KWSongListInfoModel *> * _Nonnull models) {
        [e fulfill];
    }];
    [self waitForExpectations:@[e] timeout:5];
}

- (void)testKWMP4 {
    XCTestExpectation *e = [[XCTestExpectation alloc] initWithDescription:@"testRequest"];
    [KWMP3MP4 requestMP4:85215065 completion:^(NSError * _Nonnull error, NSURL * _Nonnull url) {
        [e fulfill];
    }];
    [self waitForExpectations:@[e] timeout:5];
}

- (void)testKWMP3 {
    XCTestExpectation *e = [[XCTestExpectation alloc] initWithDescription:@"testRequest"];
    [KWMP3MP4 requestMP3:81135985 completion:^(NSError * _Nonnull error, NSURL * _Nonnull url) {
        [e fulfill];
    }];
    [self waitForExpectations:@[e] timeout:5];
}

- (void)testPerformanceExample {
    // This is an example of a performance test case.
    [self measureBlock:^{
        // Put the code you want to measure the time of here.
    }];
}

@end
