//
//  KWSongListModel.h
//  KWNetwork
//
//  Created by mac on 2020/3/18.
//  Copyright © 2020 mac. All rights reserved.
//

#import <Mantle/Mantle.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSUInteger, KWSongListType) {
    KWSongListTypeNew,      //  最新
    KWSongListTypeHot,      //  最热
};

/// 歌单
@interface KWSongListModel : MTLModel

@property (nonatomic) NSString *uname;
@property (nonatomic) NSString *isnew;
@property (nonatomic) NSString *extend;
@property (nonatomic) NSString *commentcnt;

@property (nonatomic) NSString *imgscript;
@property (nonatomic) NSString *name;           //
@property (nonatomic) NSString *attribute;
@property (nonatomic) NSString *radio_id;

@property (nonatomic) NSString *desc;
@property (nonatomic) NSString *info;

@property (nonatomic) NSInteger lossless_mark;
@property (nonatomic) NSInteger favorcnt;
@property (nonatomic) NSInteger uid;
@property (nonatomic) NSInteger total;

@property (nonatomic) NSInteger digest;
@property (nonatomic) NSInteger listencnt;      //  播放次数
@property (nonatomic) NSInteger id;             //  key

@property (nonatomic) NSURL *img;               //

/// pageNum >= 1
+ (void)request:(KWSongListType)type pageNum:(NSUInteger)pageNum completion:(void (^)(NSError *error, NSArray<KWSongListModel *> *models))completion;

/// pageNum >= 1
+ (void)requestWithTag:(NSUInteger)tag pageNum:(NSUInteger)pageNum completion:(void (^)(NSError *error, NSArray<KWSongListModel *> *models))completion;

@end

NS_ASSUME_NONNULL_END
