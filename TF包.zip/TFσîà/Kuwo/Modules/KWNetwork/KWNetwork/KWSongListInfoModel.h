//
//  KWSongListInfoModel.h
//  KWNetwork
//
//  Created by mac on 2020/3/18.
//  Copyright © 2020 mac. All rights reserved.
//

#import <Mantle/Mantle.h>
@class KWSongModel;

NS_ASSUME_NONNULL_BEGIN

/// 歌单下的歌曲
@interface KWSongListInfoModel : MTLModel

@property (nonatomic) NSString *uname;
@property (nonatomic) NSString *userName;
@property (nonatomic) NSString *name;
@property (nonatomic) NSString *tag;

@property (nonatomic) NSString *desc;
@property (nonatomic) NSString *info;

@property (nonatomic) NSUInteger total;
@property (nonatomic) NSUInteger listencnt;
@property (nonatomic) NSUInteger id;

@property (nonatomic) NSURL *img;
@property (nonatomic) NSURL *img300;
@property (nonatomic) NSURL *img500;
@property (nonatomic) NSURL *img700;
@property (nonatomic) NSURL *uPic;

@property (nonatomic) NSArray<KWSongModel *> *musicList;

/// pageNum >= 1
+ (void)request:(NSUInteger)pid pageNum:(NSUInteger)pageNum completion:(void (^)(NSError *error, KWSongListInfoModel *model))completion;

@end

NS_ASSUME_NONNULL_END
