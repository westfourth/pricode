//
//  KWMP3MP4.m
//  KWNetwork
//
//  Created by mac on 2020/3/18.
//  Copyright © 2020 mac. All rights reserved.
//

#import "KWMP3MP4.h"
#import "KWRequest.h"

@implementation KWMP3MP4

/// 获取mp3地址
+ (void)requestMP3:(NSUInteger)rid completion:(void (^)(NSError *error, NSURL *url))completion {
    NSString *urlPath = [NSString stringWithFormat:@"url?format=mp3&rid=%ld&response=url&type=convert_url3&br=128kmp3&from=web", rid];
    [[KWRequest share] request:urlPath dictCompletion:^(NSError * _Nonnull error, NSDictionary * _Nonnull dict) {
        NSInteger code = [dict[@"code"] integerValue];
        if (code != 200) {
            NSError *error = [NSError errorWithDomain:KWDomain code:code userInfo:dict];
            if (completion) completion(error, nil);
            return;
        }
        NSString *urlString = dict[@"url"];
        NSURL *url = [NSURL URLWithString:urlString];
        if (completion) completion(nil, url);
    }];
}

+ (void)requestMP4:(NSUInteger)pid completion:(void (^)(NSError *error, NSURL *url))completion {
    NSString *urlPath = [NSString stringWithFormat:@"url?rid=%ld&format=mp4|mkv&type=convert_url", pid];
    NSString *urlString = [NSString stringWithFormat:@"%@/%@", KWDomain, urlPath];
    urlString = [urlString stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLQueryAllowedCharacterSet]];
    NSURL *url = [NSURL URLWithString:urlString];
    NSMutableURLRequest *req = [NSMutableURLRequest requestWithURL:url];
    [[KWRequest share] request:req completion:^(NSError * _Nonnull error, NSData * _Nonnull data) {
        if (error) {
            if (completion) completion(error, nil);
            return;
        }
        NSString *urlString = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
        NSURL *url = [NSURL URLWithString:urlString];
        if (completion) completion(nil, url);
    }];
}

@end
