//
//  KWSongTagModel.h
//  KWNetwork
//
//  Created by mac on 2020/3/18.
//  Copyright © 2020 mac. All rights reserved.
//

#import <Mantle/Mantle.h>
@class KWSongSubTagModel;

NS_ASSUME_NONNULL_BEGIN

/// 歌单的主标签
@interface KWSongTagModel : MTLModel

@property (nonatomic) NSString *name;
@property (nonatomic) NSString *type;
@property (nonatomic) NSInteger mdigest;
@property (nonatomic) NSInteger id;

@property (nonatomic) NSURL *img;
@property (nonatomic) NSURL *img1;
@property (nonatomic) NSArray<KWSongSubTagModel *> *data;

+ (void)requestWithCompletion:(void (^)(NSError *error, NSArray<KWSongTagModel *> *models))completion;

@end



/// 歌单的主标签下的子标签
@interface KWSongSubTagModel : MTLModel

@property (nonatomic) NSString *extend;
@property (nonatomic) NSString *name;
@property (nonatomic) NSURL *img;

@property (nonatomic) NSInteger digest;
@property (nonatomic) NSInteger isnew;
@property (nonatomic) NSInteger id;         //  key

@property (nonatomic) BOOL selected;        //  ++

@end

NS_ASSUME_NONNULL_END
