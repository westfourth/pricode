//
//  KWMVModel.m
//  KWNetwork
//
//  Created by mac on 2020/3/18.
//  Copyright © 2020 mac. All rights reserved.
//

#import "KWMVModel.h"
#import "KWRequest.h"

@implementation KWMVModel

/// pageNum >= 1
+ (void)request:(KWMVType)type pageNum:(NSUInteger)pageNum completion:(void (^)(NSError *error, NSArray<KWMVModel *> *models))completion {
    NSUInteger pid = [self pid:type];
    NSString *str = [NSString stringWithFormat:@"api/www/music/mvList?pid=%ld&pn=%ld&rn=30", pid, pageNum];
    [[KWRequest share] request:str dictCompletion:^(NSError * _Nonnull error, NSDictionary * _Nonnull dict) {
        NSInteger code = [dict[@"code"] integerValue];
        if (code != 200) {
            NSError *error = [NSError errorWithDomain:KWDomain code:code userInfo:dict];
            if (completion) completion(error, nil);
            return;
        }
        NSArray *array = dict[@"data"][@"mvlist"];
        NSError *err = nil;
        NSArray *models = [MTLJSONAdapter modelsOfClass:[KWMVModel class] fromJSONArray:array
                                                  error:&err];
        if (err) {
            if (completion) completion(err, nil);
            return;
        }
        if (completion) completion(nil, models);
    }];
}

+ (NSUInteger)pid:(KWMVType)type {
    NSDictionary *dict = @{
        @(KWMVTypePremiere): @(236682871),
        @(KWMVTypeChinese): @(236682731),
        @(KWMVTypeJapan): @(236742444),
        @(KWMVTypeNetwork): @(236682773),
        
        @(KWMVTypeEurope): @(236682735),
        @(KWMVTypeLive): @(236742576),
        @(KWMVTypeHot): @(236682777),
        @(KWMVTypeSad): @(236742508),
        
        @(KWMVTypePlot): @(236742578),
    };
    NSUInteger pid = [dict[@(type)] unsignedIntegerValue];
    return pid;
}

@end
