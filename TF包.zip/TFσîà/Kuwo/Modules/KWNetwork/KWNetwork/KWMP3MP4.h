//
//  KWMP3MP4.h
//  KWNetwork
//
//  Created by mac on 2020/3/18.
//  Copyright © 2020 mac. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface KWMP3MP4 : NSObject

/// 获取mp3地址
+ (void)requestMP3:(NSUInteger)rid completion:(void (^)(NSError *error, NSURL *url))completion;

/// 获取mp4地址
+ (void)requestMP4:(NSUInteger)pid completion:(void (^)(NSError *error, NSURL *url))completion;

@end

NS_ASSUME_NONNULL_END
