//
//  KWSingerModel.h
//  KWNetwork
//
//  Created by mac on 2020/3/18.
//  Copyright © 2020 mac. All rights reserved.
//

#import <Mantle/Mantle.h>

NS_ASSUME_NONNULL_BEGIN

/// 歌手
@interface KWSingerModel : MTLModel

@property (nonatomic) NSInteger artistFans;
@property (nonatomic) NSInteger albumNum;
@property (nonatomic) NSInteger mvNum;
@property (nonatomic) NSInteger musicNum;

@property (nonatomic) NSInteger content_type;
@property (nonatomic) NSInteger id;             //  key

@property (nonatomic) BOOL isStar;

@property (nonatomic) NSString *aartist;
@property (nonatomic) NSString *name;

@property (nonatomic) NSURL *pic;
@property (nonatomic) NSURL *pic70;
@property (nonatomic) NSURL *pic120;
@property (nonatomic) NSURL *pic300;

/**
    获取歌手
 
    @param category         热门-0、A-1、......Z-26、#-27
    @param prefix              全部-、华语男-1、华语女-2、......欧美组合-9、其他-10
    @param pageNum            >= 1
 */
+ (void)request:(NSUInteger)category prefix:(NSString *)prefix pageNum:(NSUInteger)pageNum completion:(void (^)(NSError *error, NSArray<KWSingerModel *> *models))completion;

@end

NS_ASSUME_NONNULL_END
