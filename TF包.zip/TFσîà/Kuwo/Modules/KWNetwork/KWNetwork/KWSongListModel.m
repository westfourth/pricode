//
//  KWSongListModel.m
//  KWNetwork
//
//  Created by mac on 2020/3/18.
//  Copyright © 2020 mac. All rights reserved.
//

#import "KWSongListModel.h"
#import "KWRequest.h"

@implementation KWSongListModel

+ (void)request:(KWSongListType)type pageNum:(NSUInteger)pageNum completion:(void (^)(NSError *error, NSArray<KWSongListModel *> *models))completion {
    NSString *order = type == KWSongListTypeHot ? @"hot" : @"new";
    NSString *str = [NSString stringWithFormat:@"api/pc/classify/playlist/getRcmPlayList?pn=%ld&rn=30&order=%@", pageNum, order];
    [[KWRequest share] request:str dictCompletion:^(NSError * _Nonnull error, NSDictionary * _Nonnull dict) {
        NSInteger code = [dict[@"code"] integerValue];
        if (code != 200) {
            NSError *error = [NSError errorWithDomain:KWDomain code:code userInfo:dict];
            if (completion) completion(error, nil);
            return;
        }
        NSArray *array = dict[@"data"][@"data"];
        NSError *err = nil;
        NSArray *models = [MTLJSONAdapter modelsOfClass:[KWSongListModel class] fromJSONArray:array
                                                  error:&err];
        if (err) {
            if (completion) completion(err, nil);
            return;
        }
        if (completion) completion(nil, models);
    }];
}


/// pageNum >= 1
+ (void)requestWithTag:(NSUInteger)tag pageNum:(NSUInteger)pageNum completion:(void (^)(NSError *error, NSArray<KWSongListModel *> *models))completion {
    NSString *str = [NSString stringWithFormat:@"api/pc/classify/playlist/getTagPlayList?pn=%ld&rn=30&id=%ld", pageNum, tag];
    [[KWRequest share] request:str dictCompletion:^(NSError * _Nonnull error, NSDictionary * _Nonnull dict) {
        NSInteger code = [dict[@"code"] integerValue];
        if (code != 200) {
            NSError *error = [NSError errorWithDomain:KWDomain code:code userInfo:dict];
            if (completion) completion(error, nil);
            return;
        }
        NSArray *array = dict[@"data"][@"data"];
        NSError *err = nil;
        NSArray *models = [MTLJSONAdapter modelsOfClass:[KWSongListModel class] fromJSONArray:array
                                                  error:&err];
        if (err) {
            if (completion) completion(err, nil);
            return;
        }
        if (completion) completion(nil, models);
    }];
}

@end
