//
//  KWSongModel.h
//  KWNetwork
//
//  Created by mac on 2020/3/18.
//  Copyright © 2020 mac. All rights reserved.
//

#import <Mantle/Mantle.h>

NS_ASSUME_NONNULL_BEGIN

/// 小榜下的歌曲排名
@interface KWSongModel : MTLModel

@property (nonatomic) NSString *musicrid;
@property (nonatomic) NSString *artist;
@property (nonatomic) NSString *trend;
@property (nonatomic) NSString *releaseDate;

@property (nonatomic) NSString *album;              //  专辑
@property (nonatomic) NSString *songTimeMinutes;    //  时长
@property (nonatomic) NSString *name;

@property (nonatomic) BOOL isstar;
@property (nonatomic) BOOL hasLossless;             //  无损
@property (nonatomic) BOOL hasmv;                   //  MV
@property (nonatomic) BOOL isListenFee;
@property (nonatomic) BOOL online;

@property (nonatomic) NSUInteger rid;               //  key
@property (nonatomic) NSUInteger duration;
@property (nonatomic) NSUInteger content_type;
@property (nonatomic) NSUInteger rank_change;

@property (nonatomic) NSUInteger track;
@property (nonatomic) NSUInteger albumid;
@property (nonatomic) NSUInteger pay;
@property (nonatomic) NSUInteger artistid;

@property (nonatomic) NSURL *pic;
@property (nonatomic) NSURL *albumpic;
@property (nonatomic) NSURL *pic120;

@property (nonatomic) NSDictionary *payInfo;

/// 排行榜下的歌曲列表
+ (void)requestRank:(NSUInteger)sourceid pageNum:(NSUInteger)pageNum completion:(void (^)(NSError *error, NSArray<KWSongModel *> *models))completion;

/// 歌手的歌曲列表
+ (void)requestArtist:(NSUInteger)artistID pageNum:(NSUInteger)pageNum completion:(void (^)(NSError *error, NSArray<KWSongModel *> *models))completion;

/// 搜索下的歌曲列表
+ (void)requestSearch:(NSString *)key pageNum:(NSUInteger)pageNum completion:(void (^)(NSError *error, NSArray<KWSongModel *> *models))completion;

@end

NS_ASSUME_NONNULL_END
