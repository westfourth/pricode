//
//  KWRequest.m
//  KWNetwork
//
//  Created by mac on 2020/3/17.
//  Copyright © 2020 mac. All rights reserved.
//

#import "KWRequest.h"
#import "KWURLCache.h"

NSString* const KWDomain = @"http://www.kuwo.cn";

@interface KWRequest () {
    NSMutableArray<KWRequestModel *> *_array;
    NSLock *_lock;
}
@property NSString *token;
@end

@implementation KWRequest

+ (instancetype)share {
    static id instance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [[self class] new];
    });
    return instance;
}

- (NSString *)token {
    return [[NSUserDefaults standardUserDefaults] stringForKey:@"KWRequestToken"];
}

- (void)setToken:(NSString *)token {
    [[NSUserDefaults standardUserDefaults] setObject:token forKey:@"KWRequestToken"];
}

- (instancetype)init
{
    self = [super init];
    if (self) {
        _array = [NSMutableArray new];
        _lock = [NSLock new];
    }
    return self;
}

- (void)safeAdd:(KWRequestModel *)model {
    [_lock lock];
    [_array addObject:model];
    [_lock unlock];
}

- (void)safeRemove:(KWRequestModel *)model {
    [_lock lock];
    [_array removeObject:model];
    [_lock unlock];
}

/// 回调Data
- (void)request:(NSMutableURLRequest *)requst completion:(void (^)(NSError *error, NSData *data))completion {
    //  将要请求
    if ([self shouldRequest:requst completion:completion] == NO) {
        return;
    }
    
    //  取缓存
    NSData *data = [[KWURLCache defaultCache] dataForRequest:requst];
    if (data) {
        NSLog(@">>> 缓存: %@", requst.URL);
        if (completion) completion(nil, data);
        return;
    }
    
    NSLog(@">>> 请求: %@", requst.URL);
    NSURLSessionDataTask *task = [[NSURLSession sharedSession] dataTaskWithRequest:requst completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
        NSLog(@">>> 响应 %ld: %@", ((NSHTTPURLResponse *)response).statusCode, response.URL);
        dispatch_async(dispatch_get_main_queue(), ^{
            if (error) {
                if (completion) completion(error, nil);
                return;
            }
            //
            NSHTTPURLResponse *res = (NSHTTPURLResponse *)response;
            if (res.statusCode != 200) {
                NSString *des = [NSHTTPURLResponse localizedStringForStatusCode:res.statusCode];
                NSError *err = [NSError errorWithDomain:@"com.ITRequest" code:res.statusCode userInfo:@{NSLocalizedDescriptionKey: des}];
                if (completion) completion(err, nil);
                return;
            }
            //  已经获取response
            [self didGetResponse:(NSHTTPURLResponse *)response];
            //  存缓存
            [[KWURLCache defaultCache] storeCachedResponse:response data:data forRequest:requst];
            //
            if (completion) completion(nil, data);
        });
    }];
    [task resume];
}

//  将要请求
- (BOOL)shouldRequest:(NSMutableURLRequest *)requst completion:(void (^)(NSError *error, NSData *data))completion {
    [self modifyRequest:requst];
    if (self.token == nil && ![requst.URL.absoluteString isEqualToString:KWDomain]) {
        KWRequestModel *model = [KWRequestModel new];
        model.req = requst;
        model.completion = completion;
        [self safeAdd:model];
        
        //  获取token
        NSMutableURLRequest *req = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:KWDomain]];
        req.HTTPMethod = @"HEAD";
        [self request:req completion:nil];
        return NO;
    }
    return YES;
}

//  已经获取response
- (void)didGetResponse:(NSHTTPURLResponse *)response {
    //  保存token
    if ([response.URL.absoluteString isEqualToString:[NSString stringWithFormat:@"%@/", KWDomain]]) {
        self.token = [KWRequest tokenForResponse:(NSHTTPURLResponse *)response];
        //  将缓存任务发送出去
        for (int i = 0; i < _array.count; i++) {
            KWRequestModel *model = _array[i];
            [self request:model.req completion:model.completion];
            [self safeRemove:model];
            --i;
        }
    }
}

//  修改request
- (void)modifyRequest:(NSMutableURLRequest *)req {
    [req setValue:@"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_1) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Safari/605.1.15" forHTTPHeaderField:@"User-Agent"];
    if (self.token) {
        NSString *kw_token = [NSString stringWithFormat:@"kw_token=%@", self.token];
        [req setValue:kw_token forHTTPHeaderField:@"Cookie"];
        [req setValue:self.token forHTTPHeaderField:@"csrf"];
    }
}

/// 从response取token
+ (NSString *)tokenForResponse:(NSHTTPURLResponse *)response {
    NSString *s = ((NSHTTPURLResponse *)response).allHeaderFields[@"Set-Cookie"];
    NSString *pattern = @"(?<=kw_token=)\\w+(?=;)";
    NSError *error = nil;
    NSRegularExpression *regexp = [NSRegularExpression regularExpressionWithPattern:pattern options:0 error:&error];
    if (error) {
        return nil;
    }
    NSTextCheckingResult *result = [regexp firstMatchInString:s options:0 range:NSMakeRange(0, s.length)];
    if (result == nil) {
        return nil;
    }
    NSString *token = [s substringWithRange:result.range];
    return token;
}

//_______________________________________________________________________________________________________________
// MARK: -

/// 回调Dict
- (void)request:(NSString *)urlPath dictCompletion:(void (^)(NSError *error, NSDictionary *dict))completion {
    NSString *urlString = [NSString stringWithFormat:@"%@/%@", KWDomain, urlPath];
    urlString = [urlString stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLQueryAllowedCharacterSet]];
    NSURL *url = [NSURL URLWithString:urlString];
    NSMutableURLRequest *req = [NSMutableURLRequest requestWithURL:url];
    [self request:req completion:^(NSError * _Nonnull error, NSData * _Nonnull data) {
        if (error) {
            if (completion) completion(error, nil);
            return;
        }
        NSError *jsonError = nil;
        NSDictionary *dict = [NSJSONSerialization JSONObjectWithData:data options:0 error:&jsonError];
        if (jsonError) {
            if (completion) completion(jsonError, nil);
            return;
        }
        if (completion) completion(nil, dict);
    }];
}

@end



@implementation KWRequestModel
@end
