//
//  KWSingerModel.m
//  KWNetwork
//
//  Created by mac on 2020/3/18.
//  Copyright © 2020 mac. All rights reserved.
//

#import "KWSingerModel.h"
#import "KWRequest.h"

@implementation KWSingerModel

+ (void)request:(NSUInteger)category prefix:(NSString *)prefix pageNum:(NSUInteger)pageNum completion:(void (^)(NSError *error, NSArray<KWSingerModel *> *models))completion {
    NSString *str = [NSString stringWithFormat:@"api/www/artist/artistInfo?category=%ld&prefix=%@&pn=%ld&rn=100", category, prefix, pageNum];
    [[KWRequest share] request:str dictCompletion:^(NSError * _Nonnull error, NSDictionary * _Nonnull dict) {
        NSInteger code = [dict[@"code"] integerValue];
        if (code != 200) {
            NSError *error = [NSError errorWithDomain:KWDomain code:code userInfo:dict];
            if (completion) completion(error, nil);
            return;
        }
        NSArray *array = dict[@"data"][@"artistList"];
        NSError *err = nil;
        NSArray *models = [MTLJSONAdapter modelsOfClass:[KWSingerModel class] fromJSONArray:array
                                                  error:&err];
        if (err) {
            if (completion) completion(err, nil);
            return;
        }
        if (completion) completion(nil, models);
    }];
}

@end
