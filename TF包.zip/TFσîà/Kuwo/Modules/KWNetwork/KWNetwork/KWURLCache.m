//
//  KWURLCache.m
//  WLNetwork
//
//  Created by mac on 2020/3/9.
//  Copyright © 2020 mac. All rights reserved.
//

#import "KWURLCache.h"

@implementation KWURLCache

- (instancetype)init
{
    self = [super init];
    if (self) {
        self.maxAge = 24 * 60 * 60;
        self.cache = [NSURLCache sharedURLCache];
        //  _dateFormatter
        _dateFormatter = [NSDateFormatter new];
        _dateFormatter.timeZone = [NSTimeZone timeZoneWithName:@"GMT"];
        _dateFormatter.locale = [NSLocale localeWithLocaleIdentifier:@"en"];
        _dateFormatter.dateFormat = @"EEE, dd MMM yyyy HH:mm:ss 'GMT'";
    }
    return self;
}

/// 默认
+ (instancetype)defaultCache {
    static id instance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [[self class] new];
    });
    return instance;
}

/// 取缓存
- (nullable NSData *)dataForRequest:(NSURLRequest *)req {
    if (![req.HTTPMethod isEqualToString:@"GET"]) {
        return nil;
    }
    NSCachedURLResponse *cachedURLResponse = [self.cache cachedResponseForRequest:req];
    if (cachedURLResponse == nil) {
        return nil;
    }
    NSString *dateStr = [((NSHTTPURLResponse *)cachedURLResponse.response).allHeaderFields objectForKey:@"Date"];
    NSDate *date = [self.dateFormatter dateFromString:dateStr];
    NSTimeInterval interval = [[NSDate date] timeIntervalSinceDate:date];
    NSTimeInterval maxAge = self.maxAge;
    if ([req.URL.path isEqualToString:@"/url"]) {       //  mp3、mp4地址
        maxAge = 1 * 60 * 60;           //  mp3、mp4地址的缓存时长为1个小时
    }
    if (interval < maxAge) {
        return cachedURLResponse.data;
    } else {
        [self.cache removeCachedResponseForRequest:req];
        return nil;
    }
}

/// 存缓存
- (void)storeCachedResponse:(NSURLResponse *)res
                       data:(NSData *)data
                 forRequest:(NSURLRequest *)req {
    if (![req.HTTPMethod isEqualToString:@"GET"]) {
        return;
    }
    NSCachedURLResponse *cachedURLResponse = [[NSCachedURLResponse alloc] initWithResponse:res data:data];
    [self.cache storeCachedResponse:cachedURLResponse forRequest:req];
}

@end
