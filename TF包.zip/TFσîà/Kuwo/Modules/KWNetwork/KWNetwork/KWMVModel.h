//
//  KWMVModel.h
//  KWNetwork
//
//  Created by mac on 2020/3/18.
//  Copyright © 2020 mac. All rights reserved.
//

#import <Mantle/Mantle.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSUInteger, KWMVType) {
    KWMVTypePremiere,       //  首播
    KWMVTypeChinese,        //  华语
    KWMVTypeJapan,          //  日韩
    KWMVTypeNetwork,        //  网络
    
    KWMVTypeEurope,         //  欧美
    KWMVTypeLive,           //  现场
    KWMVTypeHot,            //  热舞
    KWMVTypeSad,            //  伤感
    
    KWMVTypePlot,           //  剧情
};

/// MV
@interface KWMVModel : MTLModel

@property (nonatomic) NSString *artist;
@property (nonatomic) NSString *name;
@property (nonatomic) NSString *songTimeMinutes;

@property (nonatomic) NSInteger duration;
@property (nonatomic) NSInteger mvPlayCnt;
@property (nonatomic) NSInteger artistid;
@property (nonatomic) NSInteger id;             //  key

@property (nonatomic) BOOL online;
@property (nonatomic) NSURL *pic;

/// pageNum >= 1
+ (void)request:(KWMVType)type pageNum:(NSUInteger)pageNum completion:(void (^)(NSError *error, NSArray<KWMVModel *> *models))completion;

@end

NS_ASSUME_NONNULL_END
