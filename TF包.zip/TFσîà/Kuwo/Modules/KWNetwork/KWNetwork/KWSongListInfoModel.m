//
//  KWSongListInfoModel.m
//  KWNetwork
//
//  Created by mac on 2020/3/18.
//  Copyright © 2020 mac. All rights reserved.
//

#import "KWSongListInfoModel.h"
#import "KWSongModel.h"
#import "KWRequest.h"

@implementation KWSongListInfoModel

/// pageNum >= 1
+ (void)request:(NSUInteger)pid pageNum:(NSUInteger)pageNum completion:(void (^)(NSError *error, KWSongListInfoModel *model))completion {
    NSString *str = [NSString stringWithFormat:@"api/www/playlist/playListInfo?pid=%ld&pn=%ld&rn=30", pid, pageNum];
    [[KWRequest share] request:str dictCompletion:^(NSError * _Nonnull error, NSDictionary * _Nonnull dict) {
        NSInteger code = [dict[@"code"] integerValue];
        if (code != 200) {
            NSError *error = [NSError errorWithDomain:KWDomain code:code userInfo:dict];
            if (completion) completion(error, nil);
            return;
        }
        NSError *err = nil;
        KWSongListInfoModel *model = [MTLJSONAdapter modelOfClass:[KWSongListInfoModel class] fromJSONDictionary:dict[@"data"] error:&err];
        if (err) {
            if (completion) completion(err, nil);
            return;
        }
        if (completion) completion(nil, model);
    }];
}

+ (NSValueTransformer *)musicListJSONTransformer {
    return [MTLValueTransformer transformerUsingForwardBlock:^id(NSArray *value, BOOL *success, NSError *__autoreleasing *error) {
        NSError *err = nil;
        NSArray *models = [MTLJSONAdapter modelsOfClass:[KWSongModel class] fromJSONArray:value
                                                  error:&err];
        if (err) {
            return nil;
        }
        return models;
    }];
}

@end
