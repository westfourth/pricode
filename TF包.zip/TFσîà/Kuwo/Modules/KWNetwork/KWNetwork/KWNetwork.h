//
//  KWNetwork.h
//  KWNetwork
//
//  Created by mac on 2020/3/17.
//  Copyright © 2020 mac. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for KWNetwork.
FOUNDATION_EXPORT double KWNetworkVersionNumber;

//! Project version string for KWNetwork.
FOUNDATION_EXPORT const unsigned char KWNetworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <KWNetwork/PublicHeader.h>

#import <KWNetwork/KWRankModel.h>
#import <KWNetwork/KWSongModel.h>
#import <KWNetwork/KWSingerModel.h>
#import <KWNetwork/KWSongListModel.h>

#import <KWNetwork/KWSongListInfoModel.h>
#import <KWNetwork/KWSongTagModel.h>
#import <KWNetwork/KWMVModel.h>
#import <KWNetwork/KWMP3MP4.h>

