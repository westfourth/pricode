//
//  KWRankModel.m
//  KWNetwork
//
//  Created by mac on 2020/3/18.
//  Copyright © 2020 mac. All rights reserved.
//

#import "KWRankModel.h"
#import "KWRequest.h"
#import <objc/runtime.h>

@implementation KWRankModel

+ (void)requestWithCompletion:(void (^)(NSError *error, NSArray<KWRankModel *> *models))completion {
    NSString *str = @"api/www/bang/bang/bangMenu";
    [[KWRequest share] request:str dictCompletion:^(NSError * _Nonnull error, NSDictionary * _Nonnull dict) {
        NSInteger code = [dict[@"code"] integerValue];
        if (code != 200) {
            NSError *error = [NSError errorWithDomain:KWDomain code:code userInfo:dict];
            if (completion) completion(error, nil);
            return;
        }
        NSArray *array = dict[@"data"];
        NSError *err = nil;
        NSArray *models = [MTLJSONAdapter modelsOfClass:[KWRankModel class] fromJSONArray:array
                                                  error:&err];
        if (err) {
            if (completion) completion(err, nil);
            return;
        }
        if (completion) completion(nil, models);
    }];
}

+ (NSValueTransformer *)listJSONTransformer {
    return [MTLValueTransformer transformerUsingForwardBlock:^id(NSArray *value, BOOL *success, NSError *__autoreleasing *error) {
        NSError *err = nil;
        NSArray *models = [MTLJSONAdapter modelsOfClass:[KWSubRankModel class] fromJSONArray:value
                                                  error:&err];
        if (err) {
            return nil;
        }
        return models;
    }];
}

@end



@implementation KWSubRankModel

@end
