//
//  KWRankModel.h
//  KWNetwork
//
//  Created by mac on 2020/3/18.
//  Copyright © 2020 mac. All rights reserved.
//

#import <Mantle/Mantle.h>
@class KWSubRankModel;

NS_ASSUME_NONNULL_BEGIN

/// 大榜
@interface KWRankModel : MTLModel

@property (nonatomic) NSString *name;
@property (nonatomic) NSArray<KWSubRankModel *> *list;

+ (void)requestWithCompletion:(void (^)(NSError *error, NSArray<KWRankModel *> *models))completion;

@end


/// 大榜下的小榜
@interface KWSubRankModel : MTLModel

@property (nonatomic) NSUInteger sourceid;      //  key
@property (nonatomic) NSUInteger id;
@property (nonatomic) NSUInteger source;

@property (nonatomic) NSString *name;
@property (nonatomic) NSString *pub;
@property (nonatomic) NSString *intro;

@property (nonatomic) NSURL *pic;

@property (nonatomic) BOOL selected;        //  ++

@end

NS_ASSUME_NONNULL_END
