//
//  KWSongTagModel.m
//  KWNetwork
//
//  Created by mac on 2020/3/18.
//  Copyright © 2020 mac. All rights reserved.
//

#import "KWSongTagModel.h"
#import "KWRequest.h"

@implementation KWSongTagModel

+ (void)requestWithCompletion:(void (^)(NSError *error, NSArray<KWSongTagModel *> *models))completion {
    NSString *str = @"api/www/playlist/getTagList";
    [[KWRequest share] request:str dictCompletion:^(NSError * _Nonnull error, NSDictionary * _Nonnull dict) {
        NSInteger code = [dict[@"code"] integerValue];
        if (code != 200) {
            NSError *error = [NSError errorWithDomain:KWDomain code:code userInfo:dict];
            if (completion) completion(error, nil);
            return;
        }
        NSArray *array = dict[@"data"];
        NSError *err = nil;
        NSArray *models = [MTLJSONAdapter modelsOfClass:[KWSongTagModel class] fromJSONArray:array
                                                  error:&err];
        if (err) {
            if (completion) completion(err, nil);
            return;
        }
        if (completion) completion(nil, models);
    }];
}

+ (NSValueTransformer *)dataJSONTransformer {
    return [MTLValueTransformer transformerUsingForwardBlock:^id(NSArray *value, BOOL *success, NSError *__autoreleasing *error) {
        NSError *err = nil;
        NSArray *models = [MTLJSONAdapter modelsOfClass:[KWSongSubTagModel class] fromJSONArray:value
                                                  error:&err];
        if (err) {
            return nil;
        }
        return models;
    }];
}

@end



@implementation KWSongSubTagModel

@end
