//
//  KWSongModel.m
//  KWNetwork
//
//  Created by mac on 2020/3/18.
//  Copyright © 2020 mac. All rights reserved.
//

#import "KWSongModel.h"
#import "KWRequest.h"

@implementation KWSongModel

/// pageNum >= 1
+ (void)requestRank:(NSUInteger)sourceid pageNum:(NSUInteger)pageNum completion:(void (^)(NSError *error, NSArray<KWSongModel *> *models))completion {
    NSString *str = [NSString stringWithFormat:@"api/www/bang/bang/musicList?bangId=%ld&pn=%ld&rn=30", sourceid, pageNum];
    [[KWRequest share] request:str dictCompletion:^(NSError * _Nonnull error, NSDictionary * _Nonnull dict) {
        NSInteger code = [dict[@"code"] integerValue];
        if (code != 200) {
            NSError *error = [NSError errorWithDomain:KWDomain code:code userInfo:dict];
            if (completion) completion(error, nil);
            return;
        }
        NSArray *array = dict[@"data"][@"musicList"];
        NSError *err = nil;
        NSArray *models = [MTLJSONAdapter modelsOfClass:[KWSongModel class] fromJSONArray:array
                                                  error:&err];
        if (err) {
            if (completion) completion(err, nil);
            return;
        }
        if (completion) completion(nil, models);
    }];
}

/// 歌手的歌曲列表
+ (void)requestArtist:(NSUInteger)artistID pageNum:(NSUInteger)pageNum completion:(void (^)(NSError *error, NSArray<KWSongModel *> *models))completion {
    NSString *str = [NSString stringWithFormat:@"api/www/artist/artistMusic?artistid=%ld&pn=%ld&rn=30", artistID, pageNum];
    [[KWRequest share] request:str dictCompletion:^(NSError * _Nonnull error, NSDictionary * _Nonnull dict) {
        NSInteger code = [dict[@"code"] integerValue];
        if (code != 200) {
            NSError *error = [NSError errorWithDomain:KWDomain code:code userInfo:dict];
            if (completion) completion(error, nil);
            return;
        }
        NSArray *array = dict[@"data"][@"list"];
        NSError *err = nil;
        NSArray *models = [MTLJSONAdapter modelsOfClass:[KWSongModel class] fromJSONArray:array
                                                  error:&err];
        if (err) {
            if (completion) completion(err, nil);
            return;
        }
        if (completion) completion(nil, models);
    }];
}

/// pageNum >= 1
+ (void)requestSearch:(NSString *)key pageNum:(NSUInteger)pageNum completion:(void (^)(NSError *error, NSArray<KWSongModel *> *models))completion {
    NSString *str = [NSString stringWithFormat:@"api/www/search/searchMusicBykeyWord?key=%@&pn=%ld&rn=30", key, pageNum];
    [[KWRequest share] request:str dictCompletion:^(NSError * _Nonnull error, NSDictionary * _Nonnull dict) {
        NSInteger code = [dict[@"code"] integerValue];
        if (code != 200) {
            NSError *error = [NSError errorWithDomain:KWDomain code:code userInfo:dict];
            if (completion) completion(error, nil);
            return;
        }
        NSArray *array = dict[@"data"][@"musicList"];
        NSError *err = nil;
        NSArray *models = [MTLJSONAdapter modelsOfClass:[KWSongModel class] fromJSONArray:array
                                                  error:&err];
        if (err) {
            if (completion) completion(err, nil);
            return;
        }
        if (completion) completion(nil, models);
    }];
}

@end
