//
//  KWURLCache.h
//  WLNetwork
//
//  Created by mac on 2020/3/9.
//  Copyright © 2020 mac. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

/// 缓存GET请求
@interface KWURLCache : NSObject

/// 默认
+ (instancetype)defaultCache;

/// 设置缓存存储的最大周期，超过这个时间缓存被认为过期(单位秒)。默认：1天。
@property NSTimeInterval maxAge;

/// 默认：[NSURLCache sharedURLCache]。
@property NSURLCache *cache;

/// 一般不需要用到
@property (readonly) NSDateFormatter *dateFormatter;

/**
    取缓存
 
    1. 不存在，返回nil
    2. 没有超过最大缓存时长，返回data
    3. 超过最大缓存时长，移除缓存，返回nil
 */
- (nullable NSData *)dataForRequest:(NSURLRequest *)req;

/// 存缓存
- (void)storeCachedResponse:(NSURLResponse *)res
                       data:(NSData *)data
                 forRequest:(NSURLRequest *)req;

@end

NS_ASSUME_NONNULL_END
