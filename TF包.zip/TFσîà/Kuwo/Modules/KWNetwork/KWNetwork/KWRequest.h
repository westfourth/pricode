//
//  KWRequest.h
//  KWNetwork
//
//  Created by mac on 2020/3/17.
//  Copyright © 2020 mac. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

extern NSString* const KWDomain;

@interface KWRequest : NSObject

+ (instancetype)share;

/// 回调Data
- (void)request:(NSMutableURLRequest *)requst completion:(void (^)(NSError *error, NSData *data))completion;

/// 回调Dict
- (void)request:(NSString *)urlPath dictCompletion:(void (^)(NSError *error, NSDictionary *dict))completion;

@end



@interface KWRequestModel : NSObject
@property NSMutableURLRequest *req;
@property void (^completion)(NSError *error, NSData *data);
@end

NS_ASSUME_NONNULL_END
