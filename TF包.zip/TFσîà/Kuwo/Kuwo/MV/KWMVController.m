//
//  KWMVController.m
//  Kuwo
//
//  Created by mac on 2020/3/19.
//  Copyright © 2020 mac. All rights reserved.
//

#import "KWMVController.h"
#import "KWMVCell.h"
#import <XSVendor/UIScrollView+XSRefresh.h>
#import "KWTagCollection.h"
#import "KWTagModel.h"
#import "KWTagCollectionCell.h"
#import <AVKit/AVKit.h>
#import <MBProgressHUD/MBProgressHUD.h>

@interface KWMVController () <UICollectionViewDataSource, UICollectionViewDelegate, KWTagCollectionDelegate> {
    KWTagCollection *_collection;
    UICollectionView *_collectionView;
    NSMutableArray<KWMVModel *> *_models;
    
    NSUInteger _page;
    KWMVType _type;
    BOOL _isRequesting;     //  是否在请求数据
}

@end

@implementation KWMVController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = nil;
    _models = [NSMutableArray new];
    _page = 1;
    _type = KWMVTypePremiere;
    [self setupCollectionView];
    [self setupTitleView];
    [self loadData];
    __weak typeof (self) weak_self = self;
    _collectionView.loadMoreBlock = ^{
        [weak_self loadData];
    };
}

- (void)viewDidLayoutSubviews {
    [super viewDidLayoutSubviews];
    _collectionView.frame = self.view.bounds;
}

- (void)loadData {
    if (_isRequesting) {
        return;
    }
    _isRequesting = YES;
    [KWMVModel request:_type pageNum:_page completion:^(NSError * _Nonnull error, NSArray<KWMVModel *> * _Nonnull models) {
        _isRequesting = NO;
        _page++;
        if (error) {
            return;
        }
        [_models addObjectsFromArray:models];
        [_collectionView reloadData];
    }];
}

- (void)setupCollectionView {
    UICollectionViewFlowLayout *layout = [KWMVCell flowLayout];
    _collectionView = [[UICollectionView alloc] initWithFrame:CGRectZero collectionViewLayout:layout];
    [self.view addSubview:_collectionView];
    _collectionView.dataSource = self;
    _collectionView.delegate = self;
    
    [_collectionView registerClass:[KWMVCell class] forCellWithReuseIdentifier:@"ID"];
    _collectionView.backgroundColor = [UIColor whiteColor];
}

- (void)setupTitleView {
    _collection = [KWTagCollection new];
    _collection.delegate = self;
    self.navigationItem.titleView = _collection.collectionView;
    _collection.collectionView.frame = CGRectMake(0, 0, CGRectGetWidth(self.view.bounds), 40);
    NSArray *titles = @[@"首播", @"华语", @"日韩", @"网络",
                        @"欧美", @"现场", @"热舞", @"伤感",
                        @"剧情"];
    NSMutableArray<KWTagModel *> *models = [NSMutableArray new];
    for (int i = 0; i < titles.count; i++) {
        KWTagModel *model = [KWTagModel new];
        model.name = titles[i];
        model.type = i;
        [models addObject:model];
    }
    //  选中第一个
    models.firstObject.selected = YES;
    _collection.models = models;
}

//_______________________________________________________________________________________________________________
// MARK: -

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return _models.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    KWMVModel *model = _models[indexPath.row];
    KWMVCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"ID" forIndexPath:indexPath];
    cell.model = model;
    return cell;
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    KWMVModel *model = _models[indexPath.row];
    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    hud.mode = MBProgressHUDModeIndeterminate;
    hud.label.text = @"正在获取视频地址...";
    [KWMP3MP4 requestMP4:model.id completion:^(NSError * _Nonnull error, NSURL * _Nonnull url) {
        [hud hideAnimated:YES];
        if (error) {
            return;
        }
        AVPlayer *player = [[AVPlayer alloc] initWithURL:url];
        AVPlayerViewController *controller =[[AVPlayerViewController alloc] init];
        controller.player = player;
        [player play];
        [self presentViewController:controller animated:YES completion:nil];
    }];
}

- (void)tagCollection:(KWTagCollection *)collection didSelectCell:(KWTagCollectionCell *)cell {
    _models = [NSMutableArray new];
    [_collectionView reloadData];
    _page = 1;
    _type = ((KWTagModel *)cell.model).type;
    _isRequesting = NO;
    [self loadData];
}

@end
