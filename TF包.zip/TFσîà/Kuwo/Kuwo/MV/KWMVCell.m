//
//  KWMVCell.m
//  Kuwo
//
//  Created by mac on 2020/3/19.
//  Copyright © 2020 mac. All rights reserved.
//

#import "KWMVCell.h"
#import <SDWebImage/SDWebImage.h>
#import "KWTool.h"
#import "KWBundle.h"

@interface KWMVCell() {
    UIImageView *_imageView;        //  阴影
    UIImageView *_upImageView;      //  图片显示
    UILabel *_titleLabel;
    UIButton *_timesButton;         //  播放次数
    UILabel *_durationLabel;        //  时长
}

@end

@implementation KWMVCell

float const KWMVCellRatio = 324.0 / 182.0;   //  宽高比
float const KWMVCellLineSpacing = 8;
float const KWMVCellInteritemSpacing = 8;
float const KWMVCellEdge = 8;                //  两边间距

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        //  _imageView
        _imageView = [UIImageView new];
        [self.contentView addSubview:_imageView];
        [KWTool addShadow:_imageView];
        
        //  _upImageView
        _upImageView = [UIImageView new];
        [_imageView addSubview:_upImageView];
        
        //  _titleLabel
        _titleLabel = [UILabel new];
        [self.contentView addSubview:_titleLabel];
        _titleLabel.font = [UIFont systemFontOfSize:15];
        _titleLabel.textColor = [UIColor darkTextColor];
        
        //  _timesButton
        UIImage *timesImage = [UIImage imageNamed:@"cell_play" inBundle:[KWBundle main] compatibleWithTraitCollection:nil];
        _timesButton = [UIButton new];
        [_imageView addSubview:_timesButton];
        _timesButton.titleLabel.font = [UIFont systemFontOfSize:12];
        [_timesButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [_timesButton setImage:timesImage forState:UIControlStateNormal];
        _timesButton.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
        [KWTool addShadow:_timesButton];
        
        //  _durationLabel
        _durationLabel = [UILabel new];
        [_imageView addSubview:_durationLabel];
        _durationLabel.font = [UIFont systemFontOfSize:12];
        _durationLabel.textColor = [UIColor whiteColor];
        _durationLabel.textAlignment = NSTextAlignmentRight;
        [KWTool addShadow:_durationLabel];
    }
    return self;
}

- (void)layoutSubviews {
    [super layoutSubviews];
    CGFloat imageHeight = [KWMVCell itemWidth] / KWMVCellRatio;
    _imageView.frame = CGRectMake(0, 0, self.bounds.size.width, imageHeight);
    _upImageView.frame = _imageView.frame;
    
    //  _titleLabel
    CGSize size = [_titleLabel.text sizeWithAttributes:@{NSFontAttributeName: _titleLabel.font}];
    _titleLabel.frame = CGRectMake(0, CGRectGetMaxY(_imageView.frame) + 6, self.bounds.size.width, size.height);
    
    //  _timesButton
    NSString *playTimesText = [_timesButton titleForState:UIControlStateNormal];
    size = [playTimesText sizeWithAttributes:@{NSFontAttributeName: _timesButton.titleLabel.font}];
    size.width += size.height * 1.25;
    _timesButton.frame = CGRectMake(4, CGRectGetHeight(_imageView.frame) - size.height - 4, size.width, size.height);
    
    //  _durationLabel
    size = [_durationLabel.text sizeWithAttributes:@{NSFontAttributeName: _durationLabel.font}];
    _durationLabel.frame = CGRectMake(CGRectGetWidth(_imageView.frame) - size.width - 4, CGRectGetMinY(_timesButton.frame), size.width, size.height);
}

//_______________________________________________________________________________________________________________
// MARK: -

-(void)setModel:(KWMVModel *)model {
    _model = model;
    [_upImageView sd_setImageWithURL:model.pic];
    _titleLabel.text = model.name;
    NSString *playTimesText = [KWTool playTimesText:model.mvPlayCnt];
    [_timesButton setTitle:playTimesText forState:UIControlStateNormal];
    _durationLabel.text = model.songTimeMinutes;
    [self setNeedsLayout];
}

//_______________________________________________________________________________________________________________
// MARK: -

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    [super touchesBegan:touches withEvent:event];
    [UIView animateWithDuration:0.25 animations:^{
        self.transform = CGAffineTransformMakeScale(1.05, 1.05);
    }];
}

- (void)touchesEnded:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    [super touchesEnded:touches withEvent:event];
    [UIView animateWithDuration:0.25 animations:^{
        self.transform = CGAffineTransformIdentity;
    }];
}

- (void)touchesCancelled:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    [super touchesCancelled:touches withEvent:event];
    [UIView animateWithDuration:0.25 animations:^{
        self.transform = CGAffineTransformIdentity;
    }];
}

//_______________________________________________________________________________________________________________
// MARK: -

+ (UICollectionViewFlowLayout *)flowLayout {
    UICollectionViewFlowLayout *layout = [UICollectionViewFlowLayout new];
    layout.minimumLineSpacing = KWMVCellLineSpacing;
    layout.minimumInteritemSpacing = KWMVCellInteritemSpacing;
    layout.itemSize = [KWMVCell itemSize];
    layout.sectionInset = UIEdgeInsetsMake(KWMVCellEdge, KWMVCellEdge, KWMVCellEdge, KWMVCellEdge);
    return layout;
}

+ (CGFloat)itemWidth {
    int count = 2;          //  每行多少个
    return ([UIScreen mainScreen].bounds.size.width - 2 * KWMVCellEdge - KWMVCellInteritemSpacing * (count - 1)) / count;
}

+ (CGSize)itemSize {
    CGFloat width = [KWMVCell itemWidth];
    CGFloat height = width / KWMVCellRatio + 28;
    return CGSizeMake(width, height);
}

@end
