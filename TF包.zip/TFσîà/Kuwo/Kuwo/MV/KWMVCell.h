//
//  KWMVCell.h
//  Kuwo
//
//  Created by mac on 2020/3/19.
//  Copyright © 2020 mac. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <KWNetwork/KWNetwork.h>

NS_ASSUME_NONNULL_BEGIN

@interface KWMVCell : UICollectionViewCell

+ (UICollectionViewFlowLayout *)flowLayout;

+ (CGSize)itemSize;

@property (nonatomic) KWMVModel *model;

@end

NS_ASSUME_NONNULL_END
