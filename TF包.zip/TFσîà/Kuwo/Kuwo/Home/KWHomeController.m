//
//  KWHomeController.m
//  Kuwo
//
//  Created by mac on 2020/3/19.
//  Copyright © 2020 mac. All rights reserved.
//

#import "KWHomeController.h"
#import "KWSongListController.h"
#import "KWBundle.h"
#import "KWCategoryController.h"

@interface KWHomeController () {
    KWSongListController *_newController;
    KWSongListController *_hotController;
    KWSongListController *_currentController;
}

@end

@implementation KWHomeController

- (void)viewDidLoad {
    [super viewDidLoad];
    UIImage *image = [[UIImage imageNamed:@"nav_category" inBundle:[KWBundle main] compatibleWithTraitCollection:nil] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithImage:image style:UIBarButtonItemStyleDone target:self action:@selector(clickCategory:)];
    [self setupSegment];
    
    //  设置默认
    _newController = [KWSongListController new];
    _newController.type = KWSongListTypeNew;
    [self addChildViewController:_newController];
    [self.view addSubview:_newController.view];
    //  设置当前
    _currentController = _newController;
}

- (void)viewDidLayoutSubviews {
    [super viewDidLayoutSubviews];
}

- (void)setupSegment {
    NSArray *titles = @[@"最新", @"最热"];
    UISegmentedControl *segment = [[UISegmentedControl alloc] initWithItems:titles];
    segment.selectedSegmentIndex = 0;
    [segment addTarget:self action:@selector(clickSegment:) forControlEvents:UIControlEventValueChanged];
    for (int i = 0; i < segment.numberOfSegments; i++) {
        [segment setWidth:60 forSegmentAtIndex:i];
    }
    if (@available(iOS 13, *)) {
        segment.selectedSegmentTintColor = [UIColor clearColor];
    }
    UIImage *image = [KWHomeController segmentBackgroundImage];
    [segment setBackgroundImage:image forState:UIControlStateNormal barMetrics:UIBarMetricsDefault];
    [segment setTitleTextAttributes:@{NSFontAttributeName: [UIFont systemFontOfSize:13]} forState:UIControlStateNormal];
    [segment setTitleTextAttributes:@{NSFontAttributeName: [UIFont boldSystemFontOfSize:14]} forState:UIControlStateSelected];
    self.navigationItem.titleView = segment;
}

+ (UIImage *)segmentBackgroundImage {
    CGSize size = CGSizeMake(31, 31);
    UIGraphicsBeginImageContextWithOptions(size, NO, [UIScreen mainScreen].scale);
    
    UIBezierPath *path = [UIBezierPath bezierPathWithRect:(CGRect){.size = size}];
    [[UIColor colorWithRed:255/255.0 green:228/255.0 blue:87/255.0 alpha:1] setFill];
    [path fill];
    
    UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return image;
}

- (void)clickSegment:(UISegmentedControl *)segment {
    NSString *title = [segment titleForSegmentAtIndex:segment.selectedSegmentIndex];
    KWSongListController *toController = nil;
    if ([title isEqualToString:@"最新"]) {
        if (_newController == nil) {
            _newController = [KWSongListController new];
            _newController.type = KWSongListTypeNew;
            [self addChildViewController:_newController];
        }
        toController = _newController;
    } else if ([title isEqualToString:@"最热"]) {
        if (_hotController == nil) {
            _hotController = [KWSongListController new];
            _hotController.type = KWSongListTypeHot;
            [self addChildViewController:_hotController];
        }
        toController = _hotController;
    }
    if (toController != nil) {
        [self transitionFromViewController:_currentController toViewController:toController duration:0 options:0 animations:nil completion:^(BOOL finished) {
            _currentController = toController;
        }];
    }
}

/// 点击分类
- (void)clickCategory:(UIBarButtonItem *)item {
    KWCategoryController *vc = [KWCategoryController new];
    [self.navigationController pushViewController:vc animated:YES];
}

@end
