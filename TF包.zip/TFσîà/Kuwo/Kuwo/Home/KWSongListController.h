//
//  KWHomeNewHotController.h
//  Kuwo
//
//  Created by mac on 2020/3/19.
//  Copyright © 2020 mac. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <KWNetwork/KWNetwork.h>

NS_ASSUME_NONNULL_BEGIN

/// 最新、最热
@interface KWSongListController : UIViewController

@property (nonatomic) KWSongListType type;
@property (nonatomic) NSUInteger tagID;

@end

NS_ASSUME_NONNULL_END
