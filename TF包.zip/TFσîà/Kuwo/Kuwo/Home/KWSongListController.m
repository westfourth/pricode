//
//  KWHomeNewHotController.m
//  Kuwo
//
//  Created by mac on 2020/3/19.
//  Copyright © 2020 mac. All rights reserved.
//

#import "KWSongListController.h"
#import "KWSongListCell.h"
#import <XSVendor/UIScrollView+XSRefresh.h>
#import "KWSongController.h"

@interface KWSongListController () <UICollectionViewDataSource, UICollectionViewDelegate> {
    UICollectionView *_collectionView;
    NSMutableArray<KWSongListModel *> *_models;
    NSUInteger _page;
    BOOL _isRequesting;     //  是否在请求数据
}

@end

@implementation KWSongListController

- (void)viewDidLoad {
    [super viewDidLoad];
    _models = [NSMutableArray new];
    _page = 1;
    [self setupCollectionView];
    [self loadData];
    __weak typeof (self) weak_self = self;
    _collectionView.loadMoreBlock = ^{
        [weak_self loadData];
    };
}

- (void)viewDidLayoutSubviews {
    [super viewDidLayoutSubviews];
    _collectionView.frame = self.view.bounds;
}

- (void)loadData {
    if (_isRequesting) {
        return;
    }
    _isRequesting = YES;
    void (^completion)(NSError *, NSArray<KWSongListModel *> *) = ^(NSError * _Nonnull error, NSArray<KWSongListModel *> * _Nonnull models) {
        _isRequesting = NO;
        _page++;
        if (error) {
            return;
        }
        [_models addObjectsFromArray:models];
        [_collectionView reloadData];
    };
    if (self.tagID == 0) {
        [KWSongListModel request:self.type pageNum:_page completion:completion];
    } else {
        [KWSongListModel requestWithTag:self.tagID pageNum:_page completion:completion];
    }
}

- (void)setupCollectionView {
    UICollectionViewFlowLayout *layout = [KWSongListCell flowLayout];
    _collectionView = [[UICollectionView alloc] initWithFrame:CGRectZero collectionViewLayout:layout];
    [self.view addSubview:_collectionView];
    _collectionView.dataSource = self;
    _collectionView.delegate = self;
    
    [_collectionView registerClass:[KWSongListCell class] forCellWithReuseIdentifier:@"ID"];
    _collectionView.backgroundColor = [UIColor whiteColor];
}

//_______________________________________________________________________________________________________________
// MARK: -

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return _models.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    KWSongListModel *model = _models[indexPath.row];
    KWSongListCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"ID" forIndexPath:indexPath];
    cell.model = model;
    return cell;
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    KWSongListModel *model = _models[indexPath.row];
    KWSongController *vc = [KWSongController new];
    vc.model = model;
    [self.navigationController pushViewController:vc animated:YES];
}

@end
