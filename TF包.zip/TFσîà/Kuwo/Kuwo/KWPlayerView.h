//
//  KWPlayerView.h
//  Kuwo
//
//  Created by mac on 2020/3/25.
//  Copyright © 2020 mac. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <KWNetwork/KWNetwork.h>

NS_ASSUME_NONNULL_BEGIN

@interface KWPlayerView : UIVisualEffectView

+ (instancetype)share;

//  正在播放
@property (nullable, nonatomic) KWSongModel *model;

@end

NS_ASSUME_NONNULL_END
