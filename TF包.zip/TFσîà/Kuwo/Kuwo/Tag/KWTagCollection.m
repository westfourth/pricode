//
//  KWTagCollection.m
//  Kuwo
//
//  Created by mac on 2020/3/19.
//  Copyright © 2020 mac. All rights reserved.
//

#import "KWTagCollection.h"
#import "KWTagCollectionCell.h"

@interface KWTagCollection () <UICollectionViewDataSource, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout>
@end

@implementation KWTagCollection

- (instancetype)init {
    self = [super init];
    if (self) {
        //
        UICollectionViewFlowLayout *layout = [UICollectionViewFlowLayout new];
        layout.minimumLineSpacing = 8;
        layout.minimumInteritemSpacing = 8;
        layout.scrollDirection = UICollectionViewScrollDirectionHorizontal;
        //
        _collectionView = [[UICollectionView alloc] initWithFrame:CGRectZero collectionViewLayout:layout];
        _collectionView.dataSource = self;
        _collectionView.delegate = self;
        _collectionView.showsHorizontalScrollIndicator = NO;
        
        [_collectionView registerClass:[KWTagCollectionCell class] forCellWithReuseIdentifier:@"ID"];
        _collectionView.backgroundColor = [UIColor clearColor];
    }
    return self;
}

- (void)setModels:(NSArray *)models {
    _models = models;
    [_collectionView reloadData];
}

//_______________________________________________________________________________________________________________
// MARK: -

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return _models.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    id model = _models[indexPath.row];
    KWTagCollectionCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"ID" forIndexPath:indexPath];
    cell.model = model;
    return cell;
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    KWTagCollectionCell *cell = (KWTagCollectionCell *)[collectionView cellForItemAtIndexPath:indexPath];
    if ([cell.model isKindOfClass:[KWTagModel class]]) {
        [self clearSelectedKWMVTagModel:cell.model];
    }
    [_collectionView reloadData];
    [self.delegate tagCollection:self didSelectCell:cell];
}

- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath {
    id model = _models[indexPath.row];
    return [KWTagCollectionCell itemSize:model];
}

//_______________________________________________________________________________________________________________
// MARK: - 重写

- (void)clearSelectedKWMVTagModel:(KWTagModel *)model {
    for (int i = 0; i < _models.count; i++) {
        KWTagModel *model = _models[i];
        model.selected = NO;
    }
    model.selected = YES;
}

@end





