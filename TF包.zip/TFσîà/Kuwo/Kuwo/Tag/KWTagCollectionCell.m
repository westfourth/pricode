//
//  KWTagCollectionCell.m
//  Kuwo
//
//  Created by mac on 2020/3/19.
//  Copyright © 2020 mac. All rights reserved.
//

#import "KWTagCollectionCell.h"

@interface KWTagCollectionCell () {
    UILabel *_label;
}
@end

@implementation KWTagCollectionCell

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        _label = [UILabel new];
        [self.contentView addSubview:_label];
        _label.font = [UIFont systemFontOfSize:16];
        _label.textColor = [UIColor blackColor];
        _label.textAlignment = NSTextAlignmentCenter;
        _label.layer.cornerRadius = 15;
        _label.layer.masksToBounds = YES;
    }
    return self;
}

- (void)layoutSubviews {
    [super layoutSubviews];
    _label.frame = self.bounds;
}

//_______________________________________________________________________________________________________________
// MARK: - setModel:

- (void)setModel:(id)model {
    _model = model;
    if ([model isKindOfClass:[KWTagModel class]]) {
        [self setModelForKWMVTagModel:model];
    } else if ([model isKindOfClass:[KWSongSubTagModel class]]) {
        [self setModelForKWSongSubTagModel:model];
    }
}

- (void)setModelForKWMVTagModel:(KWTagModel *)model {
    _label.text = model.name;
    if (model.selected) {
        _label.font = [UIFont boldSystemFontOfSize:16];
        _label.backgroundColor = [UIColor colorWithRed:255/255.0 green:228/255.0 blue:87/255.0 alpha:1];
    } else {
        _label.font = [UIFont systemFontOfSize:16];
        _label.backgroundColor = [UIColor clearColor];
    }
}

- (void)setModelForKWSongSubTagModel:(KWSongSubTagModel *)model {
    _label.text = model.name;
    if (model.selected) {
        _label.font = [UIFont boldSystemFontOfSize:16];
        _label.backgroundColor = [UIColor colorWithRed:255/255.0 green:228/255.0 blue:87/255.0 alpha:1];
    } else {
        _label.font = [UIFont systemFontOfSize:16];
        _label.backgroundColor = [UIColor colorWithRed:247/255.0 green:247/255.0 blue:247/255.0 alpha:1];
    }
}

//_______________________________________________________________________________________________________________
// MARK: - itemSize:

+ (CGSize)itemSize:(id)model {
    if ([model isKindOfClass:[KWTagModel class]]) {
        return [self itemSizeForKWMVTagModel:model];
    } else if ([model isKindOfClass:[KWSongSubTagModel class]]) {
        return [self itemSizeForKWSongSubTagModel:model];
    }
    return CGSizeMake(60, 30);
}

+ (CGSize)itemSizeForKWMVTagModel:(KWTagModel *)model {
    NSString *text = model.name;
    if (text.length == 1) {
        return CGSizeMake(30, 30);
    }
    CGSize size = [text sizeWithAttributes:@{NSFontAttributeName: [UIFont systemFontOfSize:16]}];
    size.width += 2 * 14;
    size.height = 30;
    return size;
}

+ (CGSize)itemSizeForKWSongSubTagModel:(KWSongSubTagModel *)model {
    NSString *text = model.name;
    if (text.length == 1) {
        return CGSizeMake(30, 30);
    }
    CGSize size = [text sizeWithAttributes:@{NSFontAttributeName: [UIFont systemFontOfSize:16]}];
    size.width += 2 * 14;
    size.height = 30;
    return size;
}

@end
