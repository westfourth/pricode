//
//  KWTagCollectionCell.h
//  Kuwo
//
//  Created by mac on 2020/3/19.
//  Copyright © 2020 mac. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "KWTagModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface KWTagCollectionCell : UICollectionViewCell

@property (nonatomic) id model;

+ (CGSize)itemSize:(id)model;

@end

NS_ASSUME_NONNULL_END
