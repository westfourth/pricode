//
//  KWTagCollection.h
//  Kuwo
//
//  Created by mac on 2020/3/19.
//  Copyright © 2020 mac. All rights reserved.
//

#import <UIKit/UIKit.h>
@class KWTagCollectionCell;
@protocol KWTagCollectionDelegate;
NS_ASSUME_NONNULL_BEGIN

//  标签
@interface KWTagCollection : NSObject

@property (nonatomic) UICollectionView *collectionView;
@property (nonatomic) NSArray *models;
@property (weak, nonatomic) id<KWTagCollectionDelegate> delegate;

@end


@protocol KWTagCollectionDelegate <NSObject>
- (void)tagCollection:(KWTagCollection *)collection didSelectCell:(KWTagCollectionCell *)cell;
@end

NS_ASSUME_NONNULL_END
