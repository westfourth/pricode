//
//  KWMVTagModel.h
//  Kuwo
//
//  Created by mac on 2020/3/19.
//  Copyright © 2020 mac. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <KWNetwork/KWNetwork.h>

NS_ASSUME_NONNULL_BEGIN

@interface KWTagModel : NSObject

@property (nonatomic) NSString *name;
@property (nonatomic) BOOL selected;

@property (nonatomic) KWMVType type;        //  用于MV
@property (nonatomic) NSInteger category;   //  用于歌手 -> 字母AB
@property (nonatomic) NSString *prefix;     //  用于歌手 -> 华语男女

@end

NS_ASSUME_NONNULL_END
