//
//  KWSongCell.m
//  Kuwo
//
//  Created by mac on 2020/3/20.
//  Copyright © 2020 mac. All rights reserved.
//

#import "KWSongCell.h"
#import <XSVendor/UIView+XSFrame.h>
#import <SDWebImage/SDWebImage.h>
#import "KWBundle.h"

@interface KWSongCell () {
    UIButton *_rankButton;          //  排名
    UIButton *_imageButton;
    UILabel *_nameLabel;
    UILabel *_loselessLabel;        //  无损
    
    UILabel *_artistAlbumLabel;     //  歌手 + 专辑
    UIButton *_mvButton;
}

@end


@implementation KWSongCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        
        //  _rankButton
        _rankButton = [UIButton new];
        [self.contentView addSubview:_rankButton];
        [_rankButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        _rankButton.titleLabel.font = [UIFont boldSystemFontOfSize:14];
        _rankButton.userInteractionEnabled = NO;
        
        //  _imageButton
        _imageButton = [UIButton new];
        [self.contentView addSubview:_imageButton];
        CGFloat edge = 3;
        _imageButton.contentEdgeInsets = UIEdgeInsetsMake(edge, edge, edge, edge);
        [_imageButton addTarget:self action:@selector(didClickImageButton:) forControlEvents:UIControlEventTouchUpInside];
        _imageButton.userInteractionEnabled = NO;
        
        //  _nameLabel
        _nameLabel = [UILabel new];
        [self.contentView addSubview:_nameLabel];
        _nameLabel.font = [UIFont systemFontOfSize:14];
        
        //  _loselessLabel
        _loselessLabel = [UILabel new];
        [self.contentView addSubview:_loselessLabel];
        _loselessLabel.font = [UIFont systemFontOfSize:11];
        _loselessLabel.text = @"无损";
        _loselessLabel.textAlignment = NSTextAlignmentCenter;
        _loselessLabel.textColor = [UIColor colorWithRed:237/255.0 green:193/255.0 blue:134/255.0 alpha:1];
        _loselessLabel.layer.borderColor = _loselessLabel.textColor.CGColor;
        _loselessLabel.layer.borderWidth = 1;
        _loselessLabel.layer.cornerRadius = 2;
        
        //  _artistAlbumLabel
        _artistAlbumLabel = [UILabel new];
        [self.contentView addSubview:_artistAlbumLabel];
        _artistAlbumLabel.font = [UIFont systemFontOfSize:11];
        
        //  _mvButton
        _mvButton = [UIButton new];
        [self.contentView addSubview:_mvButton];
        UIImage *image = [UIImage imageNamed:@"cell_mv" inBundle:[KWBundle main] compatibleWithTraitCollection:nil];
        [_mvButton setImage:image forState:UIControlStateNormal];
        [_mvButton addTarget:self action:@selector(didClickMVButton:) forControlEvents:UIControlEventTouchUpInside];
    }
    return self;
}

- (void)layoutSubviews {
    [super layoutSubviews];
    _rankButton.frame = CGRectMake(0, 0, self.height * 0.8, self.height);
    _imageButton.frame = CGRectMake(_rankButton.right, 0, self.height, self.height);
    //  _nameLabel
    CGSize size = [_nameLabel.text sizeWithAttributes:@{NSFontAttributeName: _nameLabel.font}];
    _nameLabel.frame = CGRectMake(_imageButton.right + 8, 12, size.width, size.height);
    //  _loselessLabel
    _loselessLabel.frame = CGRectMake(_nameLabel.right + 4, _nameLabel.top, 30, _nameLabel.height);
    //  _artistAlbumLabel
    size = _artistAlbumLabel.attributedText.size;
    _artistAlbumLabel.frame = CGRectMake(_nameLabel.left, _nameLabel.bottom + 8, size.width, size.height);
    //  _mvButton
    CGFloat edge = 8;
    CGFloat left = self.model.hasLossless ? _loselessLabel.right : _nameLabel.right;
    _mvButton.frame = CGRectMake(left, -2,
                                 self.height - edge * 2, self.height - edge * 2);
}

- (void)setModel:(KWSongModel *)model {
    _model = model;
    [_imageButton sd_setImageWithURL:model.pic forState:UIControlStateNormal];
    _nameLabel.text = model.name;
    _nameLabel.textColor = model.isListenFee ? [UIColor blackColor] :
        [UIColor colorWithRed:154/255.0 green:154/255.0 blue:154/255.0 alpha:1];
    _loselessLabel.hidden = !model.hasLossless;
    
    //  _artistAlbumLabel
    NSAttributedString *attrText1 = [[NSAttributedString alloc] initWithString:model.artist attributes:@{NSForegroundColorAttributeName: [UIColor colorWithRed:113/255.0 green:113/255.0 blue:113/255.0 alpha:1]}];
    NSAttributedString *attrText2 = [[NSAttributedString alloc] initWithString:@" • " attributes:@{NSForegroundColorAttributeName: [UIColor colorWithRed:237/255.0 green:193/255.0 blue:134/255.0 alpha:1]}];
    NSAttributedString *attrText3 = [[NSAttributedString alloc] initWithString:model.album attributes:@{NSForegroundColorAttributeName: [UIColor colorWithRed:154/255.0 green:154/255.0 blue:154/255.0 alpha:1]}];
    NSMutableAttributedString *attrText = [NSMutableAttributedString new];
    [attrText appendAttributedString:attrText1];
    [attrText appendAttributedString:attrText2];
    [attrText appendAttributedString:attrText3];
    _artistAlbumLabel.attributedText = attrText;
    
    //
    _mvButton.hidden = !model.hasmv;
    
    [self setNeedsLayout];
}

//
- (void)setRow:(NSUInteger)row rank:(BOOL)rank {
    self.contentView.backgroundColor = row % 2 ? [UIColor whiteColor] : [UIColor colorWithRed:250/255.0 green:250/255.0 blue:250/255.0 alpha:1];
    if (rank && row < 3) {
        NSString *imageName = [NSString stringWithFormat:@"cell_rank_%ld", row + 1];
        UIImage *image = [UIImage imageNamed:imageName inBundle:[KWBundle main] compatibleWithTraitCollection:nil];
        [_rankButton setImage:image forState:UIControlStateNormal];
        [_rankButton setTitle:nil forState:UIControlStateNormal];
    } else {
        NSString *title = [NSString stringWithFormat:@"%ld", row];
        [_rankButton setImage:nil forState:UIControlStateNormal];
        [_rankButton setTitle:title forState:UIControlStateNormal];
    }
    [self setNeedsLayout];
}

/// 点击头像
- (void)didClickImageButton:(UIButton *)button {
    [self.delegate songCell:self didClickImageButton:button];
}

/// 点击MV
- (void)didClickMVButton:(UIButton *)button {
    [self.delegate songCell:self didClickMVButton:button];
}

+ (CGFloat)height {
    return 60;
}

@end
