//
//  KWSongController.m
//  Kuwo
//
//  Created by mac on 2020/3/20.
//  Copyright © 2020 mac. All rights reserved.
//

#import "KWSongController.h"
#import "KWSongCell.h"
#import <XSVendor/UIScrollView+XSRefresh.h>
#import <AVKit/AVKit.h>
#import "KWPlayerView.h"

@interface KWSongController () <UITableViewDataSource, UITableViewDelegate, KWSongCellDelegate> {
    UITableView *_tableView;
    NSMutableArray<KWSongModel *> *_models;
    NSUInteger _page;
    BOOL _isRequesting;     //  是否在请求数据
}

@end

@implementation KWSongController

- (instancetype)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.hidesBottomBarWhenPushed = YES;
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    _models = [NSMutableArray new];
    _page = 1;
    [self setupTableView];
    //
    [self loadData];
    __weak typeof (self) weak_self = self;
    _tableView.loadMoreBlock = ^{
        [weak_self loadData];
    };
}

/// 设置标题
- (void)setModel:(id)model {
    _model = model;
    if ([model isKindOfClass:[KWSubRankModel class]]) {
        self.title = ((KWSubRankModel *)model).name;
    } else if ([model isKindOfClass:[KWSongListModel class]]) {
        self.title = ((KWSongListModel *)model).name;
    } else if ([model isKindOfClass:[KWSingerModel class]]) {
        self.title = ((KWSingerModel *)model).name;
    }
}

- (void)loadData {
    if (_isRequesting) {
        return;
    }
    _isRequesting = YES;
    void (^completion)(NSError *, NSArray<KWSongModel *> *) = ^(NSError * _Nonnull error, NSArray<KWSongModel *> * _Nonnull models) {
        _isRequesting = NO;
        _page++;
        if (error) {
            return;
        }
        [_models addObjectsFromArray:models];
        [_tableView reloadData];
    };
    if ([self.model isKindOfClass:[KWSubRankModel class]]) {
        NSUInteger sourceid = ((KWSubRankModel *)self.model).sourceid;
        [KWSongModel requestRank:sourceid pageNum:_page completion:completion];
    } else if ([self.model isKindOfClass:[KWSongListModel class]]) {
        NSUInteger pid = ((KWSongListModel *)self.model).id;
        [KWSongListInfoModel request:pid pageNum:_page completion:^(NSError * _Nonnull error, KWSongListInfoModel * _Nonnull model) {
            completion(error, model.musicList);
        }];
    } else if ([self.model isKindOfClass:[KWSingerModel class]]) {
        NSUInteger id = ((KWSingerModel *)self.model).id;
        [KWSongModel requestArtist:id pageNum:_page completion:completion];
    }
}

- (void)setupTableView {
    _tableView = [UITableView new];
    [self.view addSubview:_tableView];
    _tableView.frame = self.view.frame;
    _tableView.dataSource = self;
    _tableView.delegate = self;
    
    _tableView.rowHeight = [KWSongCell height];
    _tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    [_tableView registerClass:[KWSongCell class] forCellReuseIdentifier:@"ID"];
}

//_______________________________________________________________________________________________________________
// MARK: -

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return _models.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    KWSongModel *model = _models[indexPath.row];
    KWSongCell *cell = [tableView dequeueReusableCellWithIdentifier:@"ID" forIndexPath:indexPath];
    cell.delegate = self;
    cell.model = model;
    BOOL rank = [self.model isKindOfClass:[KWSubRankModel class]];
    [cell setRow:indexPath.row rank:YES];
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    KWSongModel *model = _models[indexPath.row];
    if (model.isListenFee) {
        [KWPlayerView share].model = model;
        return;
    }
    //  版权
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"没有版权" message:@"版权限制，不能试听" preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *action = [UIAlertAction actionWithTitle:@"我知道了" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        
    }];
    [alert addAction:action];
    [self presentViewController:alert animated:YES completion:nil];
}

//_______________________________________________________________________________________________________________
// MARK: - KWSongCellDelegate

- (void)songCell:(KWSongCell *)cell didClickImageButton:(UIButton *)button {
    
}

- (void)songCell:(KWSongCell *)cell didClickMVButton:(UIButton *)button {
    KWSongModel *model = cell.model;
    if (!model.isListenFee) {
        return;
    }
    [KWMP3MP4 requestMP4:model.rid completion:^(NSError * _Nonnull error, NSURL * _Nonnull url) {
        if (error) {
            return;
        }
        AVPlayer *player = [[AVPlayer alloc] initWithURL:url];
        AVPlayerViewController *controller =[[AVPlayerViewController alloc] init];
        controller.player = player;
        [player play];
        [self presentViewController:controller animated:YES completion:nil];
    }];
}

@end
