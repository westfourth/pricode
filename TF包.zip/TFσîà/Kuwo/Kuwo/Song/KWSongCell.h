//
//  KWSongCell.h
//  Kuwo
//
//  Created by mac on 2020/3/20.
//  Copyright © 2020 mac. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <KWNetwork/KWNetwork.h>
@protocol KWSongCellDelegate;

NS_ASSUME_NONNULL_BEGIN

@interface KWSongCell : UITableViewCell

@property (weak) id<KWSongCellDelegate> delegate;
@property (nonatomic) KWSongModel *model;

/**
    设置行数，奇偶行背景颜色不一样
 
    @param  rank    YES时，前三名图片显示
 */
- (void)setRow:(NSUInteger)row rank:(BOOL)rank;

+ (CGFloat)height;

@end



@protocol KWSongCellDelegate <NSObject>

/// 点击头像
- (void)songCell:(KWSongCell *)cell didClickImageButton:(UIButton *)button;
/// 点击MV
- (void)songCell:(KWSongCell *)cell didClickMVButton:(UIButton *)button;

@end

NS_ASSUME_NONNULL_END
