//
//  KWTool.h
//  Kuwo
//
//  Created by mac on 2020/3/19.
//  Copyright © 2020 mac. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface KWTool : NSObject

//  播放次数文字显示
+ (NSString *)playTimesText:(NSInteger)times;

//  添加阴影
+ (void)addShadow:(UIView *)view;

@end

NS_ASSUME_NONNULL_END
