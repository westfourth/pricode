//
//  ITTabBarController.m
//  ITBook
//
//  Created by mac on 2020/3/11.
//  Copyright © 2020 mac. All rights reserved.
//

#import "KWTabBarController.h"
#import "KWBundle.h"
#import <XSVendor/UIView+XSFrame.h>
#import "KWPlayerView.h"

@interface KWTabBarController ()

@end

@implementation KWTabBarController



- (void)viewDidLoad {
    [super viewDidLoad];
    [UIApplication sharedApplication].statusBarStyle = UIStatusBarStyleDefault;
    NSString *path = [[KWBundle main] pathForResource:@"Tabbar" ofType:@"plist"];
    NSArray *array = [NSArray arrayWithContentsOfFile:path];
    
    NSMutableArray<UINavigationController *> *controllers = [NSMutableArray new];
    
    for (NSDictionary *dict in array) {
        Class cls = NSClassFromString(dict[@"controller"]);
        //  vc
        UIViewController *vc = [cls new];
        vc.navigationItem.title = dict[@"title"];
        
        
        //  TabBarItem
        UIImage *image = [UIImage imageNamed:dict[@"image"] inBundle:[KWBundle main] compatibleWithTraitCollection:nil];
        UITabBarItem *item = [[UITabBarItem alloc] initWithTitle:dict[@"title"] image:image selectedImage:nil];
        
        //  navVC
        UINavigationController *navVC = [[UINavigationController alloc] initWithRootViewController:vc];
        navVC.tabBarItem = item;
//        navVC.hidesBarsOnSwipe = YES;
        navVC.navigationBar.tintColor = [UIColor colorWithRed:255/255.0 green:228/255.0 blue:87/255.0 alpha:1];
        navVC.navigationBar.translucent = NO;
        [controllers addObject:navVC];
    }
    self.viewControllers = controllers;
//    self.tabBar.tintColor = [UIColor colorWithRed:255/255.0 green:228/255.0 blue:87/255.0 alpha:1];
    
    //  添加播放器
    [self addPlayerView];
}

- (void)addPlayerView {
    KWPlayerView *view = [KWPlayerView share];
    [self.view addSubview:view];
    CGFloat height = 60;
    CGFloat tabBarHeight = [UIApplication sharedApplication].windows.firstObject.safeAreaInsets.bottom > 0 ? 83 : 49;
    [KWPlayerView share].frame = CGRectMake(0, [UIScreen mainScreen].bounds.size.height - height - tabBarHeight, self.view.width, height);
}

@end
