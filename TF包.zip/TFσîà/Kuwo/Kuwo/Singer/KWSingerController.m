//
//  KWSingerController.m
//  Kuwo
//
//  Created by mac on 2020/3/19.
//  Copyright © 2020 mac. All rights reserved.
//

#import "KWSingerController.h"
#import "KWBundle.h"
#import "KWSingerCell.h"
#import <XSVendor/UIScrollView+XSRefresh.h>
#import "KWTagCollection.h"
#import "KWTagModel.h"
#import "KWTagCollectionCell.h"
#import "KWSongController.h"

@interface KWSingerController () <UICollectionViewDataSource, UICollectionViewDelegate, KWTagCollectionDelegate> {
    KWTagCollection *_letterCollection;
    KWTagCollection *_categoryCollection;
    UIView *_lineView;
    UICollectionView *_collectionView;
    NSMutableArray<KWSingerModel *> *_models;
    
    NSUInteger _page;
    NSUInteger _category;
    NSString *_prefix;
    BOOL _isRequesting;     //  是否在请求数据
}

@end

@implementation KWSingerController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = @"全部";
    self.view.backgroundColor = [UIColor whiteColor];

    _models = [NSMutableArray new];
    _page = 1;
    _category = 0;
    _prefix = @"";
    //
    [self addLettersView];
    [self addCategoryView];
    [self setupCollectionView];
    _lineView = [UIView new];
    [self.view addSubview:_lineView];
    _lineView.backgroundColor = [UIColor colorWithRed:178/255.0 green:178/255.0 blue:178/255.0 alpha:1];
    
    [self loadData];
    __weak typeof (self) weak_self = self;
    _collectionView.loadMoreBlock = ^{
        [weak_self loadData];
    };
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    self.navigationController.navigationBarHidden = YES;
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    self.navigationController.navigationBarHidden = NO;
}

- (void)viewDidLayoutSubviews {
    [super viewDidLayoutSubviews];
    float statusBarMaxY = CGRectGetMaxY([UIApplication sharedApplication].statusBarFrame);
    CGFloat spacing = 8;
    CGFloat height = 40;
    _letterCollection.collectionView.frame = CGRectMake(spacing, statusBarMaxY, CGRectGetWidth(self.view.bounds) - spacing * 2, height);
    _categoryCollection.collectionView.frame = CGRectMake(spacing, statusBarMaxY + height, CGRectGetWidth(self.view.bounds) - spacing * 2, height);
    //
    _lineView.frame = CGRectMake(0, statusBarMaxY + height * 2, [UIScreen mainScreen].bounds.size.width, 1.0/[UIScreen mainScreen].scale);
    //
    float tabbarH = self.tabBarController.tabBar.frame.size.height;
    _collectionView.frame = CGRectMake(0, statusBarMaxY + height * 2, [UIScreen mainScreen].bounds.size.width,
                                       [UIScreen mainScreen].bounds.size.height - statusBarMaxY - tabbarH - height * 2);
}

- (void)loadData {
    if (_isRequesting) {
        return;
    }
    _isRequesting = YES;
    [KWSingerModel request:_category prefix:_prefix pageNum:_page completion:^(NSError * _Nonnull error, NSArray<KWSingerModel *> * _Nonnull models) {
        _isRequesting = NO;
        _page++;
        if (error) {
            return;
        }
        [_models addObjectsFromArray:models];
        [_collectionView reloadData];
    }];
}

- (void)setupCollectionView {
    UICollectionViewFlowLayout *layout = [KWSingerCell flowLayout];
    _collectionView = [[UICollectionView alloc] initWithFrame:CGRectZero collectionViewLayout:layout];
    [self.view addSubview:_collectionView];
    _collectionView.dataSource = self;
    _collectionView.delegate = self;
    
    [_collectionView registerClass:[KWSingerCell class] forCellWithReuseIdentifier:@"ID"];
    _collectionView.backgroundColor = [UIColor whiteColor];
}

- (void)addLettersView {
    _letterCollection = [KWTagCollection new];
    _letterCollection.delegate = self;
    [self.view addSubview:_letterCollection.collectionView];
    NSMutableArray *titles = [NSMutableArray new];
    for (char i = 'A'; i <= 'Z'; i++) {
        NSString *aChar = [NSString stringWithFormat:@"%c", i];
        [titles addObject:aChar];
    }
    NSMutableArray<KWTagModel *> *models = [NSMutableArray new];
    for (int i = 0; i < titles.count; i++) {
        KWTagModel *model = [KWTagModel new];
        model.name = titles[i];
        model.prefix = titles[i];
        [models addObject:model];
    }
    //  第一个:热门
    KWTagModel *model = [KWTagModel new];
    model.name = @"热门";
    model.prefix = @"";
    [models insertObject:model atIndex:0];
    //  最后一个:#
    model = [KWTagModel new];
    model.name = @"#";
    model.prefix = @"#";
    [models addObject:model];
    //  选中第一个
    models.firstObject.selected = YES;
    _letterCollection.models = models;
}

- (void)addCategoryView {
    _categoryCollection = [KWTagCollection new];
    _categoryCollection.delegate = self;
    [self.view addSubview:_categoryCollection.collectionView];
    NSArray *titles = @[@"全部", @"华语男", @"华语女", @"华语组合",
                        @"日韩男", @"日韩女", @"日韩组合", @"欧美男",
                        @"欧美女", @"欧美组合", @"其他"];
    NSMutableArray<KWTagModel *> *models = [NSMutableArray new];
    for (int i = 0; i < titles.count; i++) {
        KWTagModel *model = [KWTagModel new];
        model.name = titles[i];
        model.category = i;
        [models addObject:model];
    }
    //  选中第一个
    models.firstObject.selected = YES;
    _categoryCollection.models = models;
}

//_______________________________________________________________________________________________________________
// MARK: -

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return _models.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    KWSingerModel *model = _models[indexPath.row];
    KWSingerCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"ID" forIndexPath:indexPath];
    cell.model = model;
    return cell;
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    KWSingerModel *model = _models[indexPath.row];
    KWSongController *vc = [KWSongController new];
    vc.model = model;
    [self.navigationController pushViewController:vc animated:YES];
}

- (void)tagCollection:(KWTagCollection *)collection didSelectCell:(KWTagCollectionCell *)cell {
    _models = [NSMutableArray new];
    [_collectionView reloadData];
    _page = 1;
    _isRequesting = NO;
    if (collection == _letterCollection) {
        _prefix = ((KWTagModel *)cell.model).prefix;
    } else if (collection == _categoryCollection) {
        _category = ((KWTagModel *)cell.model).category;
    }
    [self loadData];
}

- (void)clickFilter:(UIBarButtonItem *)item {
    
}

@end
