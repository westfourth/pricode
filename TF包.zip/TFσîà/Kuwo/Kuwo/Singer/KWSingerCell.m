//
//  KWSingerCell.m
//  Kuwo
//
//  Created by mac on 2020/3/19.
//  Copyright © 2020 mac. All rights reserved.
//

#import "KWSingerCell.h"
#import <SDWebImage/SDWebImage.h>
#import "KWTool.h"
#import "KWBundle.h"

@interface KWSingerCell () {
    UIImageView *_imageView;        //  阴影
    UIImageView *_upImageView;      //  图片显示
    UILabel *_titleLabel;
}

@end


@implementation KWSingerCell

float const KWSingerCellRatio = 1.0 / 1.0;      //  宽高比
float const KWSingerCellLineSpacing = 12;
float const KWSingerCellInteritemSpacing = 12;
float const KWSingerCellEdge = 12;                //  两边间距

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        //  _imageView
        _imageView = [UIImageView new];
        [self.contentView addSubview:_imageView];
        [KWTool addShadow:_imageView];
        
        //  _upImageView
        _upImageView = [UIImageView new];
        [_imageView addSubview:_upImageView];
        _upImageView.layer.cornerRadius = [[self class] itemWidth] / 2.0;
        _upImageView.layer.masksToBounds = YES;
        
        //  _titleLabel
        _titleLabel = [UILabel new];
        [self.contentView addSubview:_titleLabel];
        _titleLabel.font = [UIFont systemFontOfSize:15];
        _titleLabel.textColor = [UIColor darkTextColor];
        _titleLabel.textAlignment = NSTextAlignmentCenter;
    }
    return self;
}

- (void)layoutSubviews {
    [super layoutSubviews];
    CGFloat imageHeight = [KWSingerCell itemWidth] / KWSingerCellRatio;
    _imageView.frame = CGRectMake(0, 0, self.bounds.size.width, imageHeight);
    _upImageView.frame = _imageView.frame;
    
    //  _titleLabel
    CGSize size = [_titleLabel.text sizeWithAttributes:@{NSFontAttributeName: _titleLabel.font}];
    _titleLabel.frame = CGRectMake(0, CGRectGetMaxY(_imageView.frame) + 6, self.bounds.size.width, size.height);
}

//_______________________________________________________________________________________________________________
// MARK: -

-(void)setModel:(KWSingerModel *)model {
    _model = model;
    [_upImageView sd_setImageWithURL:model.pic];
    _titleLabel.text = model.name;
    [self setNeedsLayout];
}

//_______________________________________________________________________________________________________________
// MARK: -

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    [super touchesBegan:touches withEvent:event];
    [UIView animateWithDuration:0.25 animations:^{
        self.transform = CGAffineTransformMakeScale(1.05, 1.05);
    }];
}

- (void)touchesEnded:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    [super touchesEnded:touches withEvent:event];
    [UIView animateWithDuration:0.25 animations:^{
        self.transform = CGAffineTransformIdentity;
    }];
}

- (void)touchesCancelled:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    [super touchesCancelled:touches withEvent:event];
    [UIView animateWithDuration:0.25 animations:^{
        self.transform = CGAffineTransformIdentity;
    }];
}

//_______________________________________________________________________________________________________________
// MARK: -

+ (UICollectionViewFlowLayout *)flowLayout {
    UICollectionViewFlowLayout *layout = [UICollectionViewFlowLayout new];
    layout.minimumLineSpacing = KWSingerCellLineSpacing;
    layout.minimumInteritemSpacing = KWSingerCellInteritemSpacing;
    layout.itemSize = [KWSingerCell itemSize];
    layout.sectionInset = UIEdgeInsetsMake(KWSingerCellEdge, KWSingerCellEdge, KWSingerCellEdge, KWSingerCellEdge);
    return layout;
}

+ (CGFloat)itemWidth {
    int count = 3;          //  每行多少个
    return ([UIScreen mainScreen].bounds.size.width - 2 * KWSingerCellEdge - KWSingerCellInteritemSpacing * (count - 1)) / count;
}

+ (CGSize)itemSize {
    CGFloat width = [KWSingerCell itemWidth];
    CGFloat height = width / KWSingerCellRatio + 28;
    return CGSizeMake(width, height);
}


@end
