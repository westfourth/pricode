//
//  KWRankCell.m
//  Kuwo
//
//  Created by mac on 2020/3/20.
//  Copyright © 2020 mac. All rights reserved.
//

#import "KWRankCell.h"
#import <SDWebImage/SDWebImage.h>
#import "KWTool.h"
#import "KWBundle.h"

@interface KWRankCell () {
    UIImageView *_imageView;        //  阴影
    UIImageView *_upImageView;      //  图片显示
}

@end

@implementation KWRankCell

float const KWRankCellRatio = 500.0 / 500.0;   //  宽高比
float const KWRankCellLineSpacing = 4;
float const KWRankCellInteritemSpacing = 4;
float const KWRankCellEdge = 4;                //  两边间距

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        //  _imageView
        _imageView = [UIImageView new];
        [self.contentView addSubview:_imageView];
        [KWTool addShadow:_imageView];
        
        //  _upImageView
        _upImageView = [UIImageView new];
        [_imageView addSubview:_upImageView];
    }
    return self;
}

- (void)layoutSubviews {
    [super layoutSubviews];
    CGFloat imageHeight = [KWRankCell itemWidth] / KWRankCellRatio;
    _imageView.frame = CGRectMake(0, 0, self.bounds.size.width, imageHeight);
    _upImageView.frame = _imageView.frame;
}

//_______________________________________________________________________________________________________________
// MARK: -

-(void)setModel:(KWSubRankModel *)model {
    _model = model;
    UIImage *image = [UIImage imageNamed:model.name inBundle:[KWBundle main] compatibleWithTraitCollection:nil];
    if (image) {
        _upImageView.image = image;
    } else {
        [_upImageView sd_setImageWithURL:model.pic];
    }
    [self setNeedsLayout];
}

//_______________________________________________________________________________________________________________
// MARK: -

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    [super touchesBegan:touches withEvent:event];
    [UIView animateWithDuration:0.25 animations:^{
        self.transform = CGAffineTransformMakeScale(1.05, 1.05);
    }];
}

- (void)touchesEnded:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    [super touchesEnded:touches withEvent:event];
    [UIView animateWithDuration:0.25 animations:^{
        self.transform = CGAffineTransformIdentity;
    }];
}

- (void)touchesCancelled:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    [super touchesCancelled:touches withEvent:event];
    [UIView animateWithDuration:0.25 animations:^{
        self.transform = CGAffineTransformIdentity;
    }];
}

//_______________________________________________________________________________________________________________
// MARK: -

+ (UICollectionViewFlowLayout *)flowLayout {
    UICollectionViewFlowLayout *layout = [UICollectionViewFlowLayout new];
    layout.minimumLineSpacing = KWRankCellLineSpacing;
    layout.minimumInteritemSpacing = KWRankCellInteritemSpacing;
    layout.itemSize = [KWRankCell itemSize];
    layout.sectionInset = UIEdgeInsetsMake(KWRankCellEdge, KWRankCellEdge, KWRankCellEdge, KWRankCellEdge);
    layout.headerReferenceSize = CGSizeMake(30, 30);
    return layout;
}

+ (CGFloat)itemWidth {
    int count = 3;          //  每行多少个
    return ([UIScreen mainScreen].bounds.size.width - 2 * KWRankCellEdge - KWRankCellInteritemSpacing * (count - 1)) / count;
}

+ (CGSize)itemSize {
    CGFloat width = [KWRankCell itemWidth];
    CGFloat height = width / KWRankCellRatio;
    return CGSizeMake(width, height);
}


@end
