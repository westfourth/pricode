//
//  KWRankCell.h
//  Kuwo
//
//  Created by mac on 2020/3/20.
//  Copyright © 2020 mac. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <KWNetwork/KWNetwork.h>

NS_ASSUME_NONNULL_BEGIN

@interface KWRankCell : UICollectionViewCell

+ (UICollectionViewFlowLayout *)flowLayout;

+ (CGSize)itemSize;

@property (nonatomic) KWSubRankModel *model;

@end

NS_ASSUME_NONNULL_END
