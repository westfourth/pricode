//
//  KWRankController.m
//  Kuwo
//
//  Created by mac on 2020/3/19.
//  Copyright © 2020 mac. All rights reserved.
//

#import "KWRankController.h"
#import "KWRankCell.h"
#import "KWCategoryHeader.h"
#import "KWSongListController.h"
#import "KWSongController.h"

@interface KWRankController () <UICollectionViewDataSource, UICollectionViewDelegate> {
    UICollectionView *_collectionView;
    NSMutableArray<KWRankModel *> *_models;
}

@end

@implementation KWRankController

- (void)viewDidLoad {
    [super viewDidLoad];
    _models = [NSMutableArray new];
    [self setupCollectionView];
    [self loadData];
}

- (void)viewDidLayoutSubviews {
    [super viewDidLayoutSubviews];
    _collectionView.frame = self.view.bounds;
}

- (void)loadData {
    [KWRankModel requestWithCompletion:^(NSError * _Nonnull error, NSArray<KWRankModel *> * _Nonnull models) {
        [_models addObjectsFromArray:models];
        [_collectionView reloadData];
    }];
}

- (void)setupCollectionView {
    UICollectionViewFlowLayout *layout = [KWRankCell flowLayout];
    _collectionView = [[UICollectionView alloc] initWithFrame:CGRectZero collectionViewLayout:layout];
    [self.view addSubview:_collectionView];
    _collectionView.dataSource = self;
    _collectionView.delegate = self;
    
    [_collectionView registerClass:[KWRankCell class] forCellWithReuseIdentifier:@"ID"];
    [_collectionView registerClass:[KWCategoryHeader class] forSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:@"HEAD"];
    _collectionView.backgroundColor = [UIColor whiteColor];
}

//_______________________________________________________________________________________________________________
// MARK: -

- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView {
    return _models.count;
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    KWRankModel *model = _models[section];
    return model.list.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    KWRankModel *model = _models[indexPath.section];
    KWSubRankModel *subModel = model.list[indexPath.row];
    KWRankCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"ID" forIndexPath:indexPath];
    cell.model = subModel;
    return cell;
}

- (UICollectionReusableView *)collectionView:(UICollectionView *)collectionView viewForSupplementaryElementOfKind:(NSString *)kind atIndexPath:(NSIndexPath *)indexPath {
    KWRankModel *model = _models[indexPath.section];
    KWCategoryHeader *header = [_collectionView dequeueReusableSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:@"HEAD" forIndexPath:indexPath];
    header.model = model;
    return header;
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    KWRankModel *model = _models[indexPath.section];
    KWSubRankModel *subModel = model.list[indexPath.row];
    //
    KWSongController *vc = [KWSongController new];
    vc.model = subModel;
    [self.navigationController pushViewController:vc animated:YES];
}

@end
