//
//  KWTool.m
//  Kuwo
//
//  Created by mac on 2020/3/19.
//  Copyright © 2020 mac. All rights reserved.
//

#import "KWTool.h"

@implementation KWTool

//  播放次数文字显示
+ (NSString *)playTimesText:(NSInteger)times {
    if (times > 1e4) {
        return [NSString stringWithFormat:@"%.1f万", times * 1.0 / 1e4];
    } else if (times > 1e3) {
        return [NSString stringWithFormat:@"%.1f千", times * 1.0 / 1e3];
    }
    return [NSString stringWithFormat:@"%ld", times];
}

//  添加阴影
+ (void)addShadow:(UIView *)view {
    view.layer.shadowColor = [UIColor blackColor].CGColor;
    view.layer.shadowOffset = CGSizeZero;
    view.layer.shadowRadius = 2;
    view.layer.shadowOpacity = 1;
}

@end
