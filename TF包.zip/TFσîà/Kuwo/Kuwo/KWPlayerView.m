//
//  KWPlayerView.m
//  Kuwo
//
//  Created by mac on 2020/3/25.
//  Copyright © 2020 mac. All rights reserved.
//

#import "KWPlayerView.h"
#import <XSVendor/UIView+XSFrame.h>
#import <SDWebImage/SDWebImage.h>
#import "KWBundle.h"
#import <AVFoundation/AVFoundation.h>

@interface KWPlayerView () {
    UIButton *_imageButton;
    UILabel *_titleLabel;
    UILabel *_timeLabel;
    UIProgressView *_progressView;
    UIButton *_playButton;
    AVPlayer *_player;
    id _periodicTimeObserver;
}

@end

@implementation KWPlayerView

+ (instancetype)share {
    static id instance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [[self class] new];
    });
    return instance;
}

- (instancetype)init {
    UIBlurEffect *effect = [UIBlurEffect effectWithStyle:UIBlurEffectStyleDark];
    self = [super initWithEffect:effect];
    if (self) {
        self.hidden = YES;
        
        //  _imageButton
        _imageButton = [UIButton new];
        [self.contentView addSubview:_imageButton];
        
        //  _titleLabel
        _titleLabel = [UILabel new];
        [self.contentView addSubview:_titleLabel];
        _titleLabel.textColor = [UIColor whiteColor];
        _titleLabel.font = [UIFont systemFontOfSize:14];
        
        //  _timeLabel
        _timeLabel = [UILabel new];
        [self.contentView addSubview:_timeLabel];
        _timeLabel.textColor = [[UIColor whiteColor] colorWithAlphaComponent:0.6];
        _timeLabel.font = [UIFont systemFontOfSize:12];
        
        //  _playButton
        _playButton = [UIButton new];
        [self.contentView addSubview:_playButton];
        _playButton.contentMode = UIViewContentModeScaleAspectFit;
        UIImage *image = [UIImage imageNamed:@"music_play" inBundle:[KWBundle main] compatibleWithTraitCollection:nil];
        [_playButton setImage:image forState:UIControlStateNormal];
        image = [UIImage imageNamed:@"music_pause" inBundle:[KWBundle main] compatibleWithTraitCollection:nil];
        [_playButton setImage:image forState:UIControlStateSelected];
        [_playButton addTarget:self action:@selector(clickPlayButton:) forControlEvents:UIControlEventTouchUpInside];
        
        //  _progressView
        _progressView = [UIProgressView new];
        [self.contentView addSubview:_progressView];
        _progressView.progressTintColor = [UIColor colorWithRed:255/255.0 green:228/255.0 blue:87/255.0 alpha:1];
        
        //
        UIPanGestureRecognizer *pan = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(handlePan:)];
        [self.contentView addGestureRecognizer:pan];
        
        //
        _player = [AVPlayer playerWithPlayerItem:nil];
        [_player addObserver:self forKeyPath:@"timeControlStatus" options:NSKeyValueObservingOptionNew context:nil];
        __weak typeof (self) weak_self = self;
        _periodicTimeObserver = [_player addPeriodicTimeObserverForInterval:CMTimeMake(1, 2) queue:dispatch_get_main_queue() usingBlock:^(CMTime time) {
            [weak_self didChangeCurrentTime];
        }];
    }
    return self;
}

- (void)dealloc {
    [_player removeTimeObserver:_periodicTimeObserver];
    [_player removeObserver:self forKeyPath:@"timeControlStatus"];
}

- (void)layoutSubviews {
    [super layoutSubviews];
    _imageButton.frame = CGRectMake(0, 0, self.height, self.height);
    //  _titleLabel
    CGSize size = _titleLabel.attributedText.size;
    _titleLabel.frame = CGRectMake(_imageButton.right + 8, 8, size.width, size.height);
    //  _timeLabel
    size = [_timeLabel.text sizeWithAttributes:@{NSFontAttributeName: _timeLabel.font}];
    _timeLabel.frame = CGRectMake(_titleLabel.left, _titleLabel.bottom + 8, size.width, size.height);
    //  _playButton
    CGRect rect = CGRectMake(self.width - self.height, 0, self.height, self.height);
    _playButton.frame = CGRectInset(rect, 12, 12);
    CGFloat height = 2;
    _progressView.frame = CGRectMake(0, self.height - height, self.width, height);
}

- (void)setModel:(KWSongModel *)model {
    _model = model;
    self.hidden = model ? NO : YES;
    [_imageButton sd_setImageWithURL:model.pic forState:UIControlStateNormal];
    _titleLabel.text = model.name;
    //  请求mp3
    [KWMP3MP4 requestMP3:model.rid completion:^(NSError * _Nonnull error, NSURL * _Nonnull url) {
        AVPlayerItem *item = [AVPlayerItem playerItemWithURL:url];
        [_player replaceCurrentItemWithPlayerItem:item];
        [_player play];
    }];
    [self setNeedsLayout];
}

//  播放进度变化
- (void)didChangeCurrentTime {
    if (_player.currentItem == nil) {
        return;
    }
    Float64 currentTime = CMTimeGetSeconds(_player.currentItem.currentTime);
    Float64 duration = CMTimeGetSeconds(_player.currentItem.duration);
    float progress = 0;
    if (duration != 0) {
        progress = currentTime / duration;
    }
    _progressView.progress = progress;
    //  文字
    NSString *currentTimeText = [KWPlayerView timeText:currentTime];
    NSString *durationText = [KWPlayerView timeText:duration];
    _timeLabel.text = [NSString stringWithFormat:@"%@/%@", currentTimeText, durationText];
    [self setNeedsLayout];
}

//  监听播放状态
- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary<NSKeyValueChangeKey,id> *)change context:(void *)context {
    if ([keyPath isEqualToString:@"timeControlStatus"]) {
        if (_player.timeControlStatus == AVPlayerTimeControlStatusPaused) {
            _playButton.selected = NO;
        } else {
            _playButton.selected = YES;
        }
    }
}

//  点击播放按钮
- (void)clickPlayButton:(UIButton *)button {
    if (_player.timeControlStatus == AVPlayerTimeControlStatusPaused) {
        CMTime t = CMTimeSubtract(_player.currentItem.duration, _player.currentItem.currentTime);
        if (CMTimeGetSeconds(t) < 1.0) {    //  重播
            [_player.currentItem seekToTime:kCMTimeZero completionHandler:^(BOOL finished) {
                [_player play];
            }];
        } else {                            //  继续播放
            [_player play];
        }
    } else {                                //  暂停
        [_player pause];
    }
}

//  滑动手势
- (void)handlePan:(UIPanGestureRecognizer *)pan {
    CGFloat x = [pan translationInView:pan.view].x;
    if (pan.state == UIGestureRecognizerStateBegan) {
        
    } else if (pan.state == UIGestureRecognizerStateChanged) {
        self.transform = CGAffineTransformMakeTranslation(x, 0);
    } else if (pan.state == UIGestureRecognizerStateEnded ||
               pan.state == UIGestureRecognizerStateCancelled) {
        CGAffineTransform t = CGAffineTransformIdentity;
        if (x < -self.bounds.size.width / 2) {
            t = CGAffineTransformMakeTranslation(-self.bounds.size.width, 0);
        } else if (x > self.bounds.size.width / 2) {
            t = CGAffineTransformMakeTranslation(self.bounds.size.width, 0);
        }
        [UIView animateWithDuration:0.25 animations:^{
            self.transform = t;
        } completion:^(BOOL finished) {
            if (!CGAffineTransformEqualToTransform(t, CGAffineTransformIdentity)) {
                self.model = nil;
                self.transform = CGAffineTransformIdentity;
            }
        }];
    }
}

//  生成时间字符串
+ (NSString *)timeText:(NSTimeInterval)interval {
    if (isnan(interval)) {
        interval = 0;
    }
    NSInteger secs = interval;
    NSInteger minute = secs / 60;
    NSInteger second = secs % 60;
    
    NSString *text = [NSString stringWithFormat:@"%02ld:%02ld", minute, second];
    return text;
}

@end
