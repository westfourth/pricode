//
//  KWCategoryController.m
//  Kuwo
//
//  Created by mac on 2020/3/20.
//  Copyright © 2020 mac. All rights reserved.
//

#import "KWCategoryController.h"
#import "KWTagCollectionCell.h"
#import "KWCategoryHeader.h"
#import "KWSongListController.h"

@interface KWCategoryController () <UICollectionViewDataSource, UICollectionViewDelegate> {
    UICollectionView *_collectionView;
    NSMutableArray<KWSongTagModel *> *_models;
}

@end

@implementation KWCategoryController

- (instancetype)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.hidesBottomBarWhenPushed = YES;
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"歌单分类";
    _models = [NSMutableArray new];
    [self setupCollectionView];
    [self loadData];
}

- (void)viewDidLayoutSubviews {
    [super viewDidLayoutSubviews];
    _collectionView.frame = self.view.bounds;
}

- (void)loadData {
    [KWSongTagModel requestWithCompletion:^(NSError * _Nonnull error, NSArray<KWSongTagModel *> * _Nonnull models) {
        [_models addObjectsFromArray:models];
        [_collectionView reloadData];
    }];
}

- (void)setupCollectionView {
    UICollectionViewFlowLayout *layout = [UICollectionViewFlowLayout new];
    layout.minimumLineSpacing = 8;
    layout.minimumInteritemSpacing = 8;
    layout.sectionInset = UIEdgeInsetsMake(12, 12, 12, 12);
    layout.headerReferenceSize = CGSizeMake(40, 40);
    
    _collectionView = [[UICollectionView alloc] initWithFrame:CGRectZero collectionViewLayout:layout];
    [self.view addSubview:_collectionView];
    _collectionView.dataSource = self;
    _collectionView.delegate = self;
    
    [_collectionView registerClass:[KWTagCollectionCell class] forCellWithReuseIdentifier:@"ID"];
    [_collectionView registerClass:[KWCategoryHeader class] forSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:@"HEAD"];
    _collectionView.backgroundColor = [UIColor whiteColor];
}

//_______________________________________________________________________________________________________________
// MARK: -

- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView {
    return _models.count;
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    KWSongTagModel *model = _models[section];
    return model.data.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    KWSongTagModel *model = _models[indexPath.section];
    KWSongSubTagModel *subModel = model.data[indexPath.row];
    KWTagCollectionCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"ID" forIndexPath:indexPath];
    cell.model = subModel;
    return cell;
}

- (UICollectionReusableView *)collectionView:(UICollectionView *)collectionView viewForSupplementaryElementOfKind:(NSString *)kind atIndexPath:(NSIndexPath *)indexPath {
    KWSongTagModel *model = _models[indexPath.section];
    KWCategoryHeader *header = [_collectionView dequeueReusableSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:@"HEAD" forIndexPath:indexPath];
    header.model = model;
    return header;
}

- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath {
    KWSongTagModel *model = _models[indexPath.section];
    KWSongSubTagModel *subModel = model.data[indexPath.row];
    return [KWTagCollectionCell itemSize:subModel];
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    KWSongTagModel *model = _models[indexPath.section];
    KWSongSubTagModel *subModel = model.data[indexPath.row];
    //
    KWTagCollectionCell *cell = (KWTagCollectionCell *)[collectionView cellForItemAtIndexPath:indexPath];
    if ([cell.model isKindOfClass:[KWSongSubTagModel class]]) {
        [self clearSelectedKWSongSubTagModel:subModel];
    }
    [_collectionView reloadData];
    
    //  跳转
    KWSongListController *vc = [KWSongListController new];
    vc.tagID = subModel.id;
    vc.title = subModel.name;
    [self.navigationController pushViewController:vc animated:YES];
}

- (void)clearSelectedKWSongSubTagModel:(KWSongSubTagModel *)subModel {
    for (int i = 0; i < _models.count; i++) {
        KWSongTagModel *model = _models[i];
        for (int j = 0; j < model.data.count; j++) {
            KWSongSubTagModel *subModel = model.data[j];
            subModel.selected = NO;
        }
    }
    subModel.selected = YES;
}

@end
