//
//  KWCategoryHeaderView.m
//  Kuwo
//
//  Created by mac on 2020/3/20.
//  Copyright © 2020 mac. All rights reserved.
//

#import "KWCategoryHeader.h"
#import <SDWebImage/SDWebImage.h>

@interface KWCategoryHeader () {
    UILabel *_label;
}

@end

@implementation KWCategoryHeader

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        _label = [UILabel new];
        [self addSubview:_label];
        _label.font = [UIFont boldSystemFontOfSize:18];
    }
    return self;
}

- (void)layoutSubviews {
    [super layoutSubviews];
    _label.frame = CGRectMake(12, 0, self.bounds.size.width - 12 * 2, self.bounds.size.height);
}

- (void)setModel:(id)model {
    _model = model;
    if ([model isKindOfClass:[KWSongTagModel class]]) {
        [self setModelForKWSongTagModel:model];
    } else if ([model isKindOfClass:[KWRankModel class]]) {
        [self setModelForKWRankModel:model];
    }
}

- (void)setModelForKWSongTagModel:(KWSongTagModel *)model {
    _label.text = model.name;
}

- (void)setModelForKWRankModel:(KWRankModel *)model {
    _label.text = model.name;
}

@end
