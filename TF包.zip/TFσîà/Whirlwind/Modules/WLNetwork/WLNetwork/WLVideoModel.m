//
//  WLVideoModel.m
//  WLNetwork
//
//  Created by mac on 2020/3/3.
//  Copyright © 2020 mac. All rights reserved.
//

#import "WLVideoModel.h"

@implementation WLVideoModel

/// 获取视频列表。
+ (void)request:(NSString *)urlPath page:(NSUInteger)page completion:(void (^)(NSError *error, NSMutableArray<WLVideoModel *> *models))completion {
    NSString *urlPath2 = [NSString stringWithFormat:@"%@/%ld", urlPath, page];
    [[WLRequest share] request:urlPath2 completion:^(NSError * _Nonnull error, TFHpple * _Nonnull doc) {
        if (error) {
            if (completion) completion(error, nil);
            return;
        }
        NSMutableArray<WLVideoModel *> *models = [WLVideoModel convertToModels:doc];
        if (completion) completion(nil, models);
    }];
}

/// 搜索
+ (void)search:(NSString *)key page:(NSUInteger)page completion:(void (^)(NSError *error, NSMutableArray<WLVideoModel *> *models))completion {
    NSString *urlPath2 = [NSString stringWithFormat:@"/search?q=%@&p=%ld", key, page];
    [[WLRequest share] request:urlPath2 completion:^(NSError * _Nonnull error, TFHpple * _Nonnull doc) {
        if (error) {
            if (completion) completion(error, nil);
            return;
        }
        NSMutableArray<WLVideoModel *> *models = [WLVideoModel convertToModels:doc];
        if (completion) completion(nil, models);
    }];
}

/// 转换html数据
+ (NSMutableArray<WLVideoModel *> *)convertToModels:(TFHpple *)doc {
    NSMutableArray<WLVideoModel *> *models = [NSMutableArray new];
    
    //  取得视频
    NSArray<TFHppleElement *> *elements = [doc searchWithXPathQuery:@"//div[@class='col-md-2 col-4 pic pr-0']"];
    for (int i = 0; i < elements.count; i++) {
        WLVideoModel *model = [WLVideoModel new];
        [model convert:elements[i]];
        [models addObject:model];
    }
    return models;
}

/**
    转换
 
    @code
        <div class="col-md-2 col-4 pic">
        <a href="/video/nb9TPoFLHE9Uod6YrxetWf" target="_blank" class="position-relative d-block">

        <img src="https://cdn.imgupio.com/eyJ1cmwiOiAiaHR0cHM6Ly9pbWczLmRvdWJhbmlvLmNvbS92aWV3L3Bob3RvL3NfcmF0aW9fcG9zdGVyL3B1YmxpYy9wMjU1MTM5MzgzMi5qcGciLCAicmVmZXJlciI6ICJodHRwczovL3d3dy5kb3ViYW4uY29tLyJ9" class="w-100" height="0" alt=""><span class="score">7.8</span>
        <span class="badge badge-pill badge-warning in-tag position-absolute">动作片</span>
        </a>
        <p class="text-dark mt-1 mb-2"><a href="/video/nb9TPoFLHE9Uod6YrxetWf" target="_blank" class="text-dark">疾速备战</a></p>
        </div>
    @endcode
 */
- (void)convert:(TFHppleElement *)element {
    NSData *data = [element.raw dataUsingEncoding:NSUTF8StringEncoding];
    TFHpple *doc = [TFHpple hppleWithXMLData:data];
    
    NSArray<TFHppleElement *> *elements = [doc searchWithXPathQuery:@"//a[@class='text-dark']"];
    //  名称
    self.name = elements.firstObject.firstChild.content;
    //  ID
    self.videoID = [elements.firstObject objectForKey:@"href"];
    //  封面
    elements = [doc searchWithXPathQuery:@"//img"];
    NSString *coverURLStr = [elements.firstObject objectForKey:@"src"];
    if (coverURLStr == nil) {
        coverURLStr = [elements.firstObject objectForKey:@"data-src"];
    }
    self.coverURL = [NSURL URLWithString:coverURLStr];
    //  评分
    elements = [doc searchWithXPathQuery:@"//span[@class='score']"];
    self.score = [elements.firstObject.firstChild.content floatValue];
    //  分类
    elements = [doc searchWithXPathQuery:@"//span[@class='badge badge-pill badge-warning in-tag position-absolute']"];
    self.category = elements.firstObject.firstChild.content;
}

- (instancetype)initWithCoder:(NSCoder *)coder {
    self = [super init];
    if (self) {
        self.name = [coder decodeObjectForKey:@"name"];
        self.videoID = [coder decodeObjectForKey:@"videoID"];
        self.coverURL = [coder decodeObjectForKey:@"coverURL"];
        self.score = [coder decodeFloatForKey:@"score"];
        self.category = [coder decodeObjectForKey:@"category"];
    }
    return self;
}

- (void)encodeWithCoder:(NSCoder *)coder {
    [coder encodeObject:self.name forKey:@"name"];
    [coder encodeObject:self.videoID forKey:@"videoID"];
    [coder encodeObject:self.coverURL forKey:@"coverURL"];
    [coder encodeFloat:self.score forKey:@"score"];
    [coder encodeObject:self.category forKey:@"category"];
}

@end
