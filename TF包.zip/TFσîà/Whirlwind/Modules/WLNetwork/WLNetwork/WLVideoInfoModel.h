//
//  WLVideoInfoModel.h
//  WLNetwork
//
//  Created by mac on 2020/3/5.
//  Copyright © 2020 mac. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <hpple/TFHpple.h>
#import "WLRequest.h"
#import "WLLineModel.h"
#import "WLEpisodeModel.h"
#import "WLVideoModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface WLVideoInfoModel : NSObject

@property (nonatomic) NSString *alias;          //  别名
@property (nonatomic) NSString *director;       //  导演
@property (nonatomic) NSString *lead;           //  主演
@property (nonatomic) NSString *category;       //  类型

@property (nonatomic) NSString *area;           //  地区
@property (nonatomic) NSString *language;       //  语言
@property (nonatomic) NSUInteger year;          //  上映
@property (nonatomic) NSUInteger duration;      //  片长

@property (nonatomic) NSString *updateTime;     //  更新
@property (nonatomic) NSString *brief;          //  简介

@property (nonatomic) NSMutableArray<WLLineModel *> *lines;         //  选线
@property (nonatomic) NSMutableArray<WLVideoModel *> *recommands;   //  推荐

/**
    获取视频详情。
    
    @param  urlPath         /video/39wcvmb5RjaXmVywLj7cFb
 */
+ (void)request:(NSString *)urlPath completion:(void (^)(NSError *error, WLVideoInfoModel *model))completion;

/// 转换html数据
+ (WLVideoInfoModel *)convertToModels:(TFHpple *)doc;

@end

NS_ASSUME_NONNULL_END
