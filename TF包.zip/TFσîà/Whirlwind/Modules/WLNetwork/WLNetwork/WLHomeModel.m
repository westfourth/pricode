//
//  WLHomeModel.m
//  WLNetwork
//
//  Created by mac on 2020/3/3.
//  Copyright © 2020 mac. All rights reserved.
//

#import "WLHomeModel.h"

@implementation WLHomeModel

//  获取首页数据。page>=1
+ (void)request:(NSUInteger)page completion:(void (^)(NSError *error, NSMutableArray<WLHomeModel *> *models))completion {
    NSString *urlPath = [NSString stringWithFormat:@"/page/%ld", page];
    [[WLRequest share] request:urlPath completion:^(NSError * _Nonnull error, TFHpple * _Nonnull doc) {
        if (error) {
            if (completion) completion(error, nil);
            return;
        }
        NSMutableArray<WLHomeModel *> *models = [WLHomeModel convertToModels:doc];
        if (completion) completion(nil, models);
    }];
}

/// 转换html数据
+ (NSMutableArray<WLHomeModel *> *)convertToModels:(TFHpple *)doc {
    NSMutableArray<WLHomeModel *> *models = [NSMutableArray new];
    
    //  取category
    NSArray<TFHppleElement *> *elements = [doc searchWithXPathQuery:@"//a[@class='badge badge-danger badge-pill mb-2']"];
    for (int i = 0; i < elements.count; i++) {
        WLHomeModel *model = [WLHomeModel new];
        [model convert:elements[i]];
        
        //  查找该分类下的视频列表
        model.lists = [NSMutableArray new];
        NSString *query = [NSString stringWithFormat:@"//div[@class='col-md-2 col-4 pic pr-0'][../preceding-sibling::*[1][@href='%@']]", model.urlPath];
        NSArray<TFHppleElement *> *videoElements = [doc searchWithXPathQuery:query];
        for (int i = 0; i < videoElements.count; i++) {
            WLVideoModel *videoModel = [WLVideoModel new];
            [videoModel convert:videoElements[i]];
            [model.lists addObject:videoModel];
        }
        [models addObject:model];
    }
    return models;
}

/**
    转换category、url
 
    @code
        <a href="/tag/电视剧" class="badge badge-danger badge-pill">电视剧</a>
    @endcode
 */
- (void)convert:(TFHppleElement *)element {
    self.urlPath = [element objectForKey:@"href"];
    self.category = element.firstChild.content;
}

@end
