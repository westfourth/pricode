//
//  WLEpisodeModel.m
//  WLNetwork
//
//  Created by mac on 2020/3/5.
//  Copyright © 2020 mac. All rights reserved.
//

#import "WLEpisodeModel.h"

@implementation WLEpisodeModel

/// 转换html数据
+ (NSMutableArray<WLEpisodeModel *> *)convertToModels:(TFHpple *)doc line:(NSString *)line {
    NSMutableArray<WLEpisodeModel *> *models = [NSMutableArray new];
    
    //  取category
    NSString *query = [NSString stringWithFormat:@"//a[../@id='%@']", line];
    NSArray<TFHppleElement *> *elements = [doc searchWithXPathQuery:query];
    for (int i = 0; i < elements.count; i++) {
        WLEpisodeModel *model = [WLEpisodeModel new];
        [model convert:elements[i]];
        [models addObject:model];
    }
    return models;
}

- (void)convert:(TFHppleElement *)element {
    self.videoID = [element objectForKey:@"href"];
    self.episode = element.firstChild.content;
}

@end
