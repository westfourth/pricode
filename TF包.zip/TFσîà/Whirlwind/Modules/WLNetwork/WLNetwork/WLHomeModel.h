//
//  WLHomeModel.h
//  WLNetwork
//
//  Created by mac on 2020/3/3.
//  Copyright © 2020 mac. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <hpple/TFHpple.h>
#import "WLRequest.h"
#import "WLVideoModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface WLHomeModel : NSObject

@property (nonatomic) NSString *category;           //  分类
//  地址。格式：/tag/电视剧。 WLDomain + urlPath，即是该分类网址
@property (nonatomic) NSString *urlPath;
@property (nonatomic) NSMutableArray<WLVideoModel *> *lists;

//  获取首页数据。page>=1
+ (void)request:(NSUInteger)page completion:(void (^)(NSError *error, NSMutableArray<WLHomeModel *> *models))completion;

/// 转换html数据
+ (NSMutableArray<WLHomeModel *> *)convertToModels:(TFHpple *)doc;

/// 转换category、url
- (void)convert:(TFHppleElement *)element;

@end

NS_ASSUME_NONNULL_END
