//
//  WLRequest.h
//  WLNetwork
//
//  Created by mac on 2020/3/3.
//  Copyright © 2020 mac. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <hpple/TFHpple.h>

NS_ASSUME_NONNULL_BEGIN

/// 域名
extern NSString* const WLDomain;

/// 网络请求
@interface WLRequest : NSObject

+ (instancetype)share;

/**
    请求
 
    @param  urlPath             例如：/video/39wcvmb5RjaXmVywLj7cFb
    @param  completion      出错时，error != nil
 */
- (void)request:(NSString *)urlPath completion:(void (^)(NSError *error, TFHpple *doc))completion;

@end

NS_ASSUME_NONNULL_END
