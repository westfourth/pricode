//
//  WLVideoInfoModel.m
//  WLNetwork
//
//  Created by mac on 2020/3/5.
//  Copyright © 2020 mac. All rights reserved.
//

#import "WLVideoInfoModel.h"

@implementation WLVideoInfoModel

/**
    获取视频详情。
    
    @param  urlPath         /video/39wcvmb5RjaXmVywLj7cFb
 */
+ (void)request:(NSString *)urlPath completion:(void (^)(NSError *error, WLVideoInfoModel *model))completion {
    [[WLRequest share] request:urlPath completion:^(NSError * _Nonnull error, TFHpple * _Nonnull doc) {
        if (error) {
            if (completion) completion(error, nil);
            return;
        }
        WLVideoInfoModel *model = [WLVideoInfoModel convertToModels:doc];
        if (completion) completion(nil, model);
    }];
}

/// 转换html数据
+ (WLVideoInfoModel *)convertToModels:(TFHpple *)doc {
    WLVideoInfoModel *model = [WLVideoInfoModel new];
    
    //  别名
    NSArray<TFHppleElement *> *elements = [doc searchWithXPathQuery:@"//div[@class='media-body']/ul/li[text()='别名：']/span/text()"];
    model.alias = [elements.firstObject content];
    //  导演
    elements = [doc searchWithXPathQuery:@"//div[@class='media-body']/ul/li[text()='导演：']/span/text()"];
    model.director = [elements.firstObject content];
    //  主演
    elements = [doc searchWithXPathQuery:@"//div[@class='media-body']/ul/li[text()='主演：']/span/text()"];
    model.lead = [elements.firstObject content];
    //  类型
    elements = [doc searchWithXPathQuery:@"//div[@class='media-body']/ul/li[text()='类型：']/span/text()"];
    model.category = [elements.firstObject content];
    
    //  地区
    elements = [doc searchWithXPathQuery:@"//div[@class='media-body']/ul/li[text()='地区：']/span/text()"];
    model.area = [elements.firstObject content];
    //  语言
    elements = [doc searchWithXPathQuery:@"//div[@class='media-body']/ul/li[text()='语言：']/span/text()"];
    model.language = [elements.firstObject content];
    //  上映
    elements = [doc searchWithXPathQuery:@"//div[@class='media-body']/ul/li[text()='上映：']/span/text()"];
    model.year = [[elements.firstObject content] integerValue];
    //  片长
    elements = [doc searchWithXPathQuery:@"//div[@class='media-body']/ul/li[text()='片长：']/span/text()"];
    model.duration = [[elements.firstObject content] integerValue];
    
    //  更新
    elements = [doc searchWithXPathQuery:@"//div[@class='media-body']/ul/li[text()='更新：']/span/text()"];
    model.updateTime = [elements.firstObject content];
    
    //  简介
    elements = [doc searchWithXPathQuery:@"//div[@class='media-body']/p/text()"];
    NSString *brief = [elements.firstObject content];
    if (brief == nil) {
        elements = [doc searchWithXPathQuery:@"//span[@class='more']"];
        brief = [elements.firstObject objectForKey:@"txt"];
    }
    model.brief = brief;
    
    //  选线
    model.lines = [WLLineModel convertToModels:doc];
    //  推荐
    model.recommands = [WLVideoModel convertToModels:doc];
    
    return model;
}

@end
