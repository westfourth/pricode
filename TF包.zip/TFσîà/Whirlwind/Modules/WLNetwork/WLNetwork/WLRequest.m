//
//  WLRequest.m
//  WLNetwork
//
//  Created by mac on 2020/3/3.
//  Copyright © 2020 mac. All rights reserved.
//

#import "WLRequest.h"
#import "WLURLCache.h"

NSString* const WLDomain = @"https://miao101.com";

@implementation WLRequest

+ (instancetype)share {
    static id instance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [[self class] new];
    });
    return instance;
}

- (void)request:(NSString *)urlPath completion:(void (^)(NSError *error, TFHpple *doc))completion {
    NSString *urlString = [WLDomain stringByAppendingString:urlPath];
    NSURL *url = [NSURL URLWithString:[urlString stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLQueryAllowedCharacterSet]]];
    NSURLRequest *req = [NSURLRequest requestWithURL:url];
    
    //  取缓存
    NSData *data = [WLURLCache dataForRequest:req];
    if (data) {
        NSLog(@">>> 缓存: %@", url);
        TFHpple *doc = [TFHpple hppleWithHTMLData:data];
        if (completion) completion(nil, doc);
        return;
    }
    
    NSLog(@">>> 请求: %@", url);
    NSURLSessionDataTask *task = [[NSURLSession sharedSession] dataTaskWithRequest:req completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
        NSLog(@">>> 响应 %ld: %@", ((NSHTTPURLResponse *)response).statusCode, url);
//        puts([[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding].UTF8String);
        
        dispatch_async(dispatch_get_main_queue(), ^{
            if (error) {
                if (completion) completion(error, nil);
                return;
            }
            //
            NSHTTPURLResponse *res = (NSHTTPURLResponse *)response;
            if (res.statusCode != 200) {
                NSString *des = [NSHTTPURLResponse localizedStringForStatusCode:res.statusCode];
                NSError *err = [NSError errorWithDomain:@"com.WLRequest" code:res.statusCode userInfo:@{NSLocalizedDescriptionKey: des}];
                if (completion) completion(err, nil);
                return;
            }
            
            //  存缓存
            [WLURLCache storeCachedResponse:response data:data forRequest:req];
            //
            TFHpple *doc = [TFHpple hppleWithHTMLData:data];
            if (completion) completion(nil, doc);
        });
    }];
    [task resume];
}

@end
