//
//  WLLineModel.h
//  WLNetwork
//
//  Created by mac on 2020/3/6.
//  Copyright © 2020 mac. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <hpple/TFHpple.h>
#import "WLEpisodeModel.h"

NS_ASSUME_NONNULL_BEGIN

/// 线路
@interface WLLineModel : NSObject

@property (nonatomic) NSString *line;       //  线路名称
@property (nonatomic) NSString *lineID;     //  线路ID
@property (nonatomic) NSMutableArray<WLEpisodeModel *> *list;      //  集数

/// 转换html数据
+ (NSMutableArray<WLLineModel *> *)convertToModels:(TFHpple *)doc;

/**
   转换

   @code
       <a class="nav-link active" id="home-tab" data-toggle="tab" href="#line1" role="tab" aria-controls="home" aria-selected="true">线路A</a>
   @endcode
*/
- (void)convert:(TFHppleElement *)element;

@end

NS_ASSUME_NONNULL_END
