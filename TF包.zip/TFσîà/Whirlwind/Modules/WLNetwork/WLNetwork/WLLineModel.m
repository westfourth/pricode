//
//  WLLineModel.m
//  WLNetwork
//
//  Created by mac on 2020/3/6.
//  Copyright © 2020 mac. All rights reserved.
//

#import "WLLineModel.h"
#import "WLEpisodeModel.h"

@implementation WLLineModel

/// 转换html数据
+ (NSMutableArray<WLLineModel *> *)convertToModels:(TFHpple *)doc {
    NSMutableArray<WLLineModel *> *models = [NSMutableArray new];
    
    //  取category
    NSString *query = [NSString stringWithFormat:@"//a[@id='home-tab']"];
    NSArray<TFHppleElement *> *elements = [doc searchWithXPathQuery:query];
    for (int i = 0; i < elements.count; i++) {
        WLLineModel *model = [WLLineModel new];
        [model convert:elements[i]];
        model.list = [WLEpisodeModel convertToModels:doc line:model.lineID];
        [models addObject:model];
    }
    return models;
}

- (void)convert:(TFHppleElement *)element {
    self.lineID = [[element objectForKey:@"href"] stringByReplacingOccurrencesOfString:@"#" withString:@""];
    self.line = element.firstChild.content;
}

@end
