//
//  WLVideoModel.h
//  WLNetwork
//
//  Created by mac on 2020/3/3.
//  Copyright © 2020 mac. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <hpple/TFHpple.h>
#import "WLRequest.h"

NS_ASSUME_NONNULL_BEGIN

@interface WLVideoModel : NSObject <NSCoding>

@property (nonatomic) NSString *name;       //  名称
//  ID。格式：/video/PbiuECi5Qs7tTszNZ3Xna9。WLDomain + videoID，即是该视频网址
@property (nonatomic) NSString *videoID;
@property (nonatomic) NSURL *coverURL;      //  封面
@property (nonatomic) float score;          //  评分
@property (nonatomic) NSString *category;   //  分类

/**
    获取视频列表。
    
    @param  urlPath         /tag/综艺
    @param  page                >=1
 */
+ (void)request:(NSString *)urlPath page:(NSUInteger)page completion:(void (^)(NSError *error, NSMutableArray<WLVideoModel *> *models))completion;

/**
    搜索。
    
    @param  page                >=1
 */
+ (void)search:(NSString *)key page:(NSUInteger)page completion:(void (^)(NSError *error, NSMutableArray<WLVideoModel *> *models))completion;

/// 转换html数据
+ (NSMutableArray<WLVideoModel *> *)convertToModels:(TFHpple *)doc;

- (void)convert:(TFHppleElement *)element;

@end

NS_ASSUME_NONNULL_END
