//
//  WLURLCache.m
//  WLNetwork
//
//  Created by mac on 2020/3/9.
//  Copyright © 2020 mac. All rights reserved.
//

#import "WLURLCache.h"

/// 最大缓存时长，超过该时长就会从缓存中移除。（1天）
NSTimeInterval const WLURLCacheMaxDuration = (24 * 60 * 60);

@implementation WLURLCache

/// 格式化
+ (NSDateFormatter *)httpDateFormatter {
    static NSDateFormatter *f = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        f = [NSDateFormatter new];
        f.timeZone = [NSTimeZone timeZoneWithName:@"GMT"];
        f.locale = [NSLocale localeWithLocaleIdentifier:@"en"];
        f.dateFormat = @"EEE, dd MMM yyyy HH:mm:ss 'GMT'";
    });
    return f;
}

/// 取缓存
+ (nullable NSData *)dataForRequest:(NSURLRequest *)req {
    if (![req.HTTPMethod isEqualToString:@"GET"]) {
        return nil;
    }
    NSCachedURLResponse *cachedURLResponse = [[NSURLCache sharedURLCache] cachedResponseForRequest:req];
    if (cachedURLResponse == nil) {
        return nil;
    }
    NSString *dateStr = [((NSHTTPURLResponse *)cachedURLResponse.response).allHeaderFields objectForKey:@"Date"];
    NSDate *date = [[WLURLCache httpDateFormatter] dateFromString:dateStr];
    NSTimeInterval interval = [[NSDate date] timeIntervalSinceDate:date];
    if (interval < WLURLCacheMaxDuration) {
        return cachedURLResponse.data;
    } else {
        [[NSURLCache sharedURLCache] removeCachedResponseForRequest:req];
        return nil;
    }
}

/// 存缓存
+ (void)storeCachedResponse:(NSURLResponse *)res
                       data:(NSData *)data
                 forRequest:(NSURLRequest *)req {
    if (![req.HTTPMethod isEqualToString:@"GET"]) {
        return;
    }
    NSCachedURLResponse *cachedURLResponse = [[NSCachedURLResponse alloc] initWithResponse:res data:data];
    [[NSURLCache sharedURLCache] storeCachedResponse:cachedURLResponse forRequest:req];
}

@end
