//
//  WLEpisodeModel.h
//  WLNetwork
//
//  Created by mac on 2020/3/5.
//  Copyright © 2020 mac. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <hpple/TFHpple.h>

NS_ASSUME_NONNULL_BEGIN

/// 第几集
@interface WLEpisodeModel : NSObject

@property (nonatomic) NSString *episode;       //  名称
//  ID。格式：/video/PbiuECi5Qs7tTszNZ3Xna9。WLDomain + videoID，即是该视频网址
@property (nonatomic) NSString *videoID;

/// 转换html数据
+ (NSMutableArray<WLEpisodeModel *> *)convertToModels:(TFHpple *)doc line:(NSString *)line;


/**
   转换

   @code
       <a href="/video/39wcvmb5RjaXmVywLj7cFb-A-1" class="mb-1 btn btn-danger played">第01集</a>
   @endcode
*/
- (void)convert:(TFHppleElement *)element;

@end

NS_ASSUME_NONNULL_END
