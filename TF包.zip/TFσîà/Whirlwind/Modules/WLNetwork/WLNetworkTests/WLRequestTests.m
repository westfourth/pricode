//
//  WLRequestTests.m
//  WLNetworkTests
//
//  Created by mac on 2020/3/6.
//  Copyright © 2020 mac. All rights reserved.
//

#import <XCTest/XCTest.h>
#import "WLRequest.h"
#import "WLHomeModel.h"
#import "WLVideoInfoModel.h"

@interface WLRequestTests : XCTestCase

@end

@implementation WLRequestTests

- (void)setUp {
    // Put setup code here. This method is called before the invocation of each test method in the class.
}

- (void)tearDown {
    // Put teardown code here. This method is called after the invocation of each test method in the class.
}

- (void)testWLHomeModel {
    XCTestExpectation *e = [[XCTestExpectation alloc] initWithDescription:@"testRequest"];
    [WLHomeModel request:0 completion:^(NSError * _Nonnull error, NSMutableArray<WLHomeModel *> * _Nonnull models) {
        puts(__func__);
    }];
    [self waitForExpectations:@[e] timeout:5];
}

- (void)testWLVideoModel {
    XCTestExpectation *e = [[XCTestExpectation alloc] initWithDescription:@"testRequest"];
    [WLVideoModel request:@"/tag/综艺" page:2 completion:^(NSError * _Nonnull error, NSMutableArray<WLVideoModel *> * _Nonnull models) {
        puts(__func__);
    }];
    [self waitForExpectations:@[e] timeout:5];
}

- (void)testSearchWLVideoModel {
    XCTestExpectation *e = [[XCTestExpectation alloc] initWithDescription:@"testRequest"];
    [WLVideoModel search:@"情" page:1 completion:^(NSError * _Nonnull error, NSMutableArray<WLVideoModel *> * _Nonnull models) {
        puts(__func__);
    }];
    [self waitForExpectations:@[e] timeout:5];
}

- (void)testWLVideoInfoModel {
    XCTestExpectation *e = [[XCTestExpectation alloc] initWithDescription:@"testRequest"];
    [WLVideoInfoModel request:@"/video/39wcvmb5RjaXmVywLj7cFb" completion:^(NSError * _Nonnull error, WLVideoInfoModel * _Nonnull model) {
        puts(__func__);
    }];
    [self waitForExpectations:@[e] timeout:5];
}

- (void)testPerformanceExample {
    // This is an example of a performance test case.
    [self measureBlock:^{
        // Put the code you want to measure the time of here.
    }];
}

@end
