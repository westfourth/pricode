//
//  WLInfoTests.m
//  WLNetworkTests
//
//  Created by mac on 2020/3/5.
//  Copyright © 2020 mac. All rights reserved.
//

#import <XCTest/XCTest.h>
#import <hpple/TFHpple.h>
#import "WLHomeModel.h"
#import "WLVideoInfoModel.h"
#import "WLEpisodeModel.h"
#import "WLLineModel.h"

@interface WLInfoTests : XCTestCase

@property (nonatomic, strong) NSData *data;
@property (nonatomic, strong) TFHpple *doc;

@end

@implementation WLInfoTests

- (void)setUp {
    NSBundle *testBundle = [NSBundle bundleForClass:[self class]];
    NSURL *testFileUrl = [testBundle URLForResource:@"videoInfo" withExtension:@"html"];
    self.data = [NSData dataWithContentsOfURL:testFileUrl];
    self.doc = [TFHpple hppleWithHTMLData:self.data];
}

- (void)tearDown {
    // Put teardown code here. This method is called after the invocation of each test method in the class.
}

- (void)testHomeModel {
//    NSArray<TFHppleElement *> *elements = [self.doc searchWithXPathQuery:@"//a[../@id='line1']"];
//    NSArray *array = [WLEpisodeModel convertToModels:self.doc line:@"line1"];
//    NSArray *array = [WLLineModel convertToModels:self.doc];
    WLVideoInfoModel *infoModel = [WLVideoInfoModel convertToModels:self.doc];
    XCTAssertNil(infoModel);
}

- (void)testPerformanceExample {
    // This is an example of a performance test case.
    [self measureBlock:^{
        // Put the code you want to measure the time of here.
    }];
}

@end
