//
//  WLNetworkTests.m
//  WLNetworkTests
//
//  Created by mac on 2020/3/3.
//  Copyright © 2020 mac. All rights reserved.
//

#import <XCTest/XCTest.h>
#import <hpple/TFHpple.h>
#import "WLHomeModel.h"


@interface WLNetworkTests : XCTestCase

@property (nonatomic, strong) NSData *data;
@property (nonatomic, strong) TFHpple *doc;

@end

@implementation WLNetworkTests

- (void)setUp {
    NSBundle *testBundle = [NSBundle bundleForClass:[self class]];
    NSURL *testFileUrl = [testBundle URLForResource:@"index" withExtension:@"html"];
    self.data = [NSData dataWithContentsOfURL:testFileUrl];
    self.doc = [TFHpple hppleWithHTMLData:self.data];
}

- (void)tearDown {
    // Put teardown code here. This method is called after the invocation of each test method in the class.
}

- (void)testInitializesWithHTMLData {
    XCTAssertNotNil(self.doc.data);
    XCTAssertTrue([self.doc isMemberOfClass:[TFHpple class]]);
}

- (void)testHomeModel {
    //[preceding-sibling::*[1][a/@href='/tag/电影']]
//    NSArray<TFHppleElement *> *elements = [self.doc searchWithXPathQuery:@"//div[@class='col-md-2 col-6 pic'][../preceding-sibling::*[1]/a[@href='/tag/电影']]"];
//    NSArray<TFHppleElement *> *elements = [self.doc searchWithXPathQuery:@"//div[@class='col-md-2 col-6 pic']/../preceding-sibling::*[1]/a[@href='/tag/电影']"];
    NSArray *a = [WLHomeModel convertToModels:self.doc];
    XCTAssertNil(a);
}

- (void)testVideoModel {
    NSDate *date = [NSDate date];
    NSArray *a = [WLVideoModel convertToModels:self.doc];
    NSTimeInterval interval = [[NSDate date] timeIntervalSinceDate:date];
    XCTAssertNil(a);
}

- (void)testSearchesWithXPath {
    
    NSArray *a = [self.doc searchWithXPathQuery:@"//h5/a"];
    
    TFHppleElement * e = [a objectAtIndex:0];
    XCTAssertTrue([e isMemberOfClass:[TFHppleElement class]]);
}

- (void)testPerformanceExample {
    // This is an example of a performance test case.
    [self measureBlock:^{
        // Put the code you want to measure the time of here.
        NSArray *a = [WLVideoModel convertToModels:self.doc];
    }];
}

@end
