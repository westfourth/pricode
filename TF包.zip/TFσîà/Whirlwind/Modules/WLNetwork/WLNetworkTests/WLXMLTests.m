//
//  WLXMLTests.m
//  WLNetworkTests
//
//  Created by mac on 2020/3/3.
//  Copyright © 2020 mac. All rights reserved.
//

#import <XCTest/XCTest.h>
#import <hpple/TFHpple.h>

@interface WLXMLTests : XCTestCase

@property (nonatomic, strong) TFHpple *doc;

@end

@implementation WLXMLTests

- (void)setUp {
    NSBundle *testBundle = [NSBundle bundleForClass:[self class]];
    NSURL *testFileUrl = [testBundle URLForResource:@"book" withExtension:@"xml"];
    NSData * data = [NSData dataWithContentsOfURL:testFileUrl];
    self.doc = [[TFHpple alloc] initWithXMLData:data];
}

- (void)tearDown {
    // Put teardown code here. This method is called after the invocation of each test method in the class.
}

- (void)testInitializesWithXMLData {
    XCTAssertNotNil(self.doc.data);
    XCTAssertTrue([self.doc isMemberOfClass:[TFHpple class]]);
}

- (void)testSearchesWithXPath {
    NSArray *items = [self.doc searchWithXPathQuery:@"//child[.=111]"];
    
    TFHppleElement * e = [items objectAtIndex:0];
    XCTAssertTrue([e isMemberOfClass:[TFHppleElement class]]);
}

- (void)testPerformanceExample {
    // This is an example of a performance test case.
    [self measureBlock:^{
        // Put the code you want to measure the time of here.
    }];
}

@end
