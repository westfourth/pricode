//
//  WLVideoInfoController.m
//  Whirlwind
//
//  Created by mac on 2020/3/6.
//  Copyright © 2020 mac. All rights reserved.
//

#import "WLVideoInfoController.h"
#import <SDWebImage/SDWebImage.h>
#import <XSVendor/UILabel+XSPadding.h>
#import "WLBundle.h"
#import "WLLocalStore.h"
#import "WLEpisodeController.h"
#import "WLRecommandController.h"

@interface WLVideoInfoController () <UITableViewDataSource, UITableViewDelegate> {
    UITableView *_tableView;
    UIImageView *_headerView;
    UILabel *_footerView;
    WLVideoInfoModel *_infoModel;
    NSArray *_fixedTitles;
    NSArray *_lineTitles;
}

@end

@implementation WLVideoInfoController

- (instancetype)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.hidesBottomBarWhenPushed = YES;
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    _fixedTitles = @[@"别名", @"导演", @"主演", @"类型",
                     @"地区", @"语言", @"上映", @"片长",
                     @"更新"];
    self.title = self.videoModel.name;
    
    NSString *imageName = [WLLocalStore has:self.videoModel] ? @"nav_collect2" : @"nav_collect1";
    UIImage *image = [UIImage imageNamed:imageName inBundle:[WLBundle main] compatibleWithTraitCollection:nil];
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithImage:image style:UIBarButtonItemStyleDone target:self action:@selector(collect:)];
    
    [self setupTableView];
    [self setupHeaderView];
    [self setupFooterView];
    [self loadData];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [self.navigationController setNavigationBarHidden:NO animated:YES];
}

- (void)loadData {
    [WLVideoInfoModel request:self.videoModel.videoID completion:^(NSError * _Nonnull error, WLVideoInfoModel * _Nonnull model) {
        if (error) {
            return;
        }
        _infoModel = model;
        
        //  添加线路
//        _lineTitles = [model.lines valueForKey:@"line"];
        
        _footerView.text = model.brief;
        //  计算大小
        CGRect rect = [model.brief boundingRectWithSize:CGSizeMake([UIScreen mainScreen].bounds.size.width - 20 * 2, 0) options:NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName: _footerView.font} context:nil];
        _footerView.frame = CGRectMake(0, 0, 0, rect.size.height + 10);
        //
        [_tableView reloadData];
    }];
}

- (void)setupTableView {
    _tableView = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStyleGrouped];
    [self.view addSubview:_tableView];
    _tableView.frame = self.view.frame;
    _tableView.dataSource = self;
    _tableView.delegate = self;
    _tableView.sectionHeaderHeight = 8;
    _tableView.sectionFooterHeight = 8;
}

- (void)setupHeaderView {
    _headerView = [UIImageView new];
    _tableView.tableHeaderView = _headerView;
    _headerView.frame = CGRectMake(0, 0, 0, 300);
    _headerView.contentMode = UIViewContentModeScaleAspectFit;
    [_headerView sd_setImageWithURL:self.videoModel.coverURL];
    
    _headerView.layer.shadowColor = [UIColor blackColor].CGColor;
    _headerView.layer.shadowOffset = CGSizeZero;
    _headerView.layer.shadowRadius = 4;
    _headerView.layer.shadowOpacity = 1;
}

- (void)setupFooterView {
    _footerView = [UILabel new];
    _tableView.tableFooterView = _footerView;
    _footerView.frame = CGRectMake(0, 0, 0, 100);
    _footerView.numberOfLines = 0;
    _footerView.padding = UIEdgeInsetsMake(0, 20, 0, 20);
    _footerView.font = [UIFont systemFontOfSize:16];
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
//    return _lineTitles ? 2 : 1;
    return 2;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (section == 0) {
        return _fixedTitles.count;
    }
//    else if (section == 1) {
//        return _lineTitles.count;
//    }
    else {
        return 1;
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"ID"];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:@"ID"];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        cell.textLabel.font = [UIFont systemFontOfSize:18];
    }
    if (indexPath.section == 0) {
        NSString *title = _fixedTitles[indexPath.row];
        cell.textLabel.attributedText = [self attrText:title];
        cell.accessoryType = UITableViewCellAccessoryNone;
    }
//    else if (indexPath.section == 1) {
//        NSString *title = _lineTitles[indexPath.row];
//        NSDictionary *a1 = @{NSForegroundColorAttributeName: [UIColor blueColor]};
//        cell.textLabel.attributedText = [[NSAttributedString alloc] initWithString:title attributes:a1];
//        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
//    }
    else {
        NSString *title = @"相关推荐";
        NSDictionary *a1 = @{NSForegroundColorAttributeName: [UIColor blueColor]};
        cell.textLabel.attributedText = [[NSAttributedString alloc] initWithString:title attributes:a1];
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    }
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section == 0) {
        
    }
//    else if (indexPath.section == 1) {
//        WLEpisodeController *vc = [WLEpisodeController new];
//        vc.lineModel = _infoModel.lines[indexPath.row];
//        [self.navigationController pushViewController:vc animated:YES];
//    }
    else {
        WLRecommandController *vc = [WLRecommandController new];
        vc.recommands = _infoModel.recommands;
        [self.navigationController pushViewController:vc animated:YES];
    }
}

- (NSMutableAttributedString *)attrText:(NSString *)title {
    NSString *detail = @"";
    if ([title isEqualToString:@"别名"]) {
        detail = _infoModel.alias;
    } else if ([title isEqualToString:@"导演"]) {
        detail = _infoModel.director;
    } else if ([title isEqualToString:@"主演"]) {
        detail = _infoModel.lead;
    } else if ([title isEqualToString:@"类型"]) {
        detail = _infoModel.category;
    } else if ([title isEqualToString:@"地区"]) {
        detail = _infoModel.area;
    } else if ([title isEqualToString:@"语言"]) {
        detail = _infoModel.language;
    } else if ([title isEqualToString:@"上映"]) {
        detail = [NSString stringWithFormat:@"%ld年", _infoModel.year];
    } else if ([title isEqualToString:@"片长"]) {
        detail = [NSString stringWithFormat:@"%ld分钟", _infoModel.duration];
    } else if ([title isEqualToString:@"更新"]) {
        detail = _infoModel.updateTime;
    }
    if (detail == nil) {
        detail = @"";
    }
    NSDictionary *a1 = @{NSForegroundColorAttributeName: [UIColor grayColor]};
    NSDictionary *a2 = @{NSForegroundColorAttributeName: [UIColor blackColor]};
    NSAttributedString *attrTitle = [[NSAttributedString alloc] initWithString:[NSString stringWithFormat:@"%@：", title] attributes:a1];
    NSAttributedString *attrDetail = [[NSAttributedString alloc] initWithString:detail attributes:a2];
    NSMutableAttributedString *result = [NSMutableAttributedString new];
    [result appendAttributedString:attrTitle];
    [result appendAttributedString:attrDetail];
    return result;
}

// 收藏
- (void)collect:(UIBarButtonItem *)item {
    if ([WLLocalStore has:self.videoModel]) {
        [WLLocalStore remove:self.videoModel];
    } else {
        [WLLocalStore add:self.videoModel];
    }
    //  更新图片
    NSString *imageName = [WLLocalStore has:self.videoModel] ? @"nav_collect2" : @"nav_collect1";
    UIImage *image = [UIImage imageNamed:imageName inBundle:[WLBundle main] compatibleWithTraitCollection:nil];
    item.image = image;
    //  存储到本地
    [WLLocalStore save];
}

@end
