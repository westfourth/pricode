//
//  WLHomeController.m
//  Whirlwind
//
//  Created by mac on 2020/3/6.
//  Copyright © 2020 mac. All rights reserved.
//

#import "WLHomeController.h"
#import "WLVideoCell.h"
#import "WLHomeSectionHeaderView.h"
#import <XSVendor/UIScrollView+XSRefresh.h>
#import "WLVideoInfoController.h"
#import "WLSearchController.h"

@interface WLHomeController () <UICollectionViewDataSource, UICollectionViewDelegate> {
    UICollectionView *_collectionView;
    NSMutableArray<WLHomeModel *> *_models;
    NSUInteger _page;
    BOOL _isRequesting;     //  是否在请求数据
}

@end

@implementation WLHomeController

- (void)viewDidLoad {
    [super viewDidLoad];
    _page = 1;
    _models = [NSMutableArray new];
    [self setupCollectionView];
    [self setupSearchController];
    [self loadData];
    __weak typeof (self) weak_self = self;
    _collectionView.loadMoreBlock = ^{
        [weak_self loadData];
    };
}

- (void)viewDidLayoutSubviews {
    [super viewDidLayoutSubviews];
    _collectionView.frame = self.view.bounds;
}

- (void)loadData {
    if (_isRequesting) {
        return;
    }
    _isRequesting = YES;
    [WLHomeModel request:_page completion:^(NSError * _Nonnull error, NSMutableArray<WLHomeModel *> * _Nonnull models) {
        _isRequesting = NO;
        _page++;
        if (error) {
            return;
        }
        [_models addObjectsFromArray:models];
        [_collectionView reloadData];
    }];
}

- (void)setupCollectionView {
    UICollectionViewFlowLayout *layout = [WLVideoCell flowLayout];
    layout.headerReferenceSize = CGSizeMake(0, 40);
    _collectionView = [[UICollectionView alloc] initWithFrame:CGRectZero collectionViewLayout:layout];
    [self.view addSubview:_collectionView];
    _collectionView.dataSource = self;
    _collectionView.delegate = self;
    
    [_collectionView registerClass:[WLVideoCell class] forCellWithReuseIdentifier:@"ID"];
    [_collectionView registerClass:[WLHomeSectionHeaderView class] forSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:@"HEAD"];
    _collectionView.backgroundColor = [UIColor whiteColor];
}

- (void)setupSearchController {
    WLSearchController *resultsVC = [WLSearchController new];
    UISearchController *searchController = [[UISearchController alloc] initWithSearchResultsController:resultsVC];
    self.navigationItem.searchController = searchController;
    searchController.searchBar.delegate = resultsVC;
}

//_______________________________________________________________________________________________________________
// MARK: -

- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView {
    return _models.count;
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return _models[section].lists.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    WLVideoModel *videoModel = _models[indexPath.section].lists[indexPath.row];
    WLVideoCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"ID" forIndexPath:indexPath];
    cell.videoModel = videoModel;
    return cell;
}

- (UICollectionReusableView *)collectionView:(UICollectionView *)collectionView viewForSupplementaryElementOfKind:(NSString *)kind atIndexPath:(NSIndexPath *)indexPath {
    WLHomeSectionHeaderView *header = [collectionView dequeueReusableSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:@"HEAD" forIndexPath:indexPath];
    header.homeModel = _models[indexPath.section];
    return header;
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    WLVideoModel *videoModel = _models[indexPath.section].lists[indexPath.row];
    WLVideoInfoController *vc = [WLVideoInfoController new];
    vc.videoModel = videoModel;
    [self.navigationController pushViewController:vc animated:YES];
}

@end
