//
//  WLBundle.m
//  Whirlwind
//
//  Created by mac on 2020/3/6.
//  Copyright © 2020 mac. All rights reserved.
//

#import "WLBundle.h"

@implementation WLBundle

+ (NSBundle *)main {
    NSBundle *b = [NSBundle bundleForClass:[self class]];
    NSString *resourceName = b.bundleIdentifier.pathExtension;
    NSURL *url = [b URLForResource:resourceName withExtension:@"bundle"];
    if (url != nil) {
        b = [NSBundle bundleWithURL:url];
    }
    return b;
}

@end
