//
//  WLChooseCategoryController.h
//  Whirlwind
//
//  Created by mac on 2020/3/7.
//  Copyright © 2020 mac. All rights reserved.
//

#import <UIKit/UIKit.h>
@protocol WLChooseCategoryControllerDelegate;

NS_ASSUME_NONNULL_BEGIN

/// 选择分类
@interface WLChooseCategoryController : UIViewController

@property (weak, nonatomic) id<WLChooseCategoryControllerDelegate> delegate;
@property (nonatomic) NSString *selectedTag;

@end


@protocol WLChooseCategoryControllerDelegate <NSObject>

- (void)chooseCategoryController:(WLChooseCategoryController *)controller didSelectTag:(NSString *)tag;

@end

NS_ASSUME_NONNULL_END
