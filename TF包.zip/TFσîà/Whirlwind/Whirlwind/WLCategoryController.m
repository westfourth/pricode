//
//  WLCategoryController.m
//  Whirlwind
//
//  Created by mac on 2020/3/6.
//  Copyright © 2020 mac. All rights reserved.
//

#import "WLCategoryController.h"
#import "WLVideoCell.h"
#import "WLHomeSectionHeaderView.h"
#import <XSVendor/UIScrollView+XSRefresh.h>
#import "WLVideoInfoController.h"
#import "WLBundle.h"
#import "WLChooseCategoryController.h"

@interface WLCategoryController () <UICollectionViewDataSource, UICollectionViewDelegate, WLChooseCategoryControllerDelegate> {
    UICollectionView *_collectionView;
    NSUInteger _page;
    NSMutableArray<WLVideoModel *> *_models;
    BOOL _isRequesting;     //  是否在请求数据
    NSString *_selectedTag;
}

@end

@implementation WLCategoryController

- (void)viewDidLoad {
    [super viewDidLoad];
    _page = 1;
    _models = [NSMutableArray new];
    _selectedTag = @"/tag/电影";
    self.navigationItem.title = _selectedTag.lastPathComponent;
    
    UIImage *image = [UIImage imageNamed:@"nav_more" inBundle:[WLBundle main] compatibleWithTraitCollection:nil];
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithImage:image style:UIBarButtonItemStyleDone target:self action:@selector(more:)];
    
    [self setupCollectionView];
    [self loadData];
    __weak typeof (self) weak_self = self;
    _collectionView.loadMoreBlock = ^{
        [weak_self loadData];
    };
}

- (void)viewDidLayoutSubviews {
    [super viewDidLayoutSubviews];
    _collectionView.frame = self.view.bounds;
}

- (void)loadData {
    if (_isRequesting) {
        return;
    }
    _isRequesting = YES;
    [WLVideoModel request:_selectedTag page:_page completion:^(NSError * _Nonnull error, NSMutableArray<WLVideoModel *> * _Nonnull models) {
        _isRequesting = NO;
        _page++;
        if (error) {
            return;
        }
        [_models addObjectsFromArray:models];
        [_collectionView reloadData];
    }];
}

- (void)setupCollectionView {
    UICollectionViewFlowLayout *layout = [WLVideoCell flowLayout];
    _collectionView = [[UICollectionView alloc] initWithFrame:CGRectZero collectionViewLayout:layout];
    [self.view addSubview:_collectionView];
    _collectionView.dataSource = self;
    _collectionView.delegate = self;
    
    [_collectionView registerClass:[WLVideoCell class] forCellWithReuseIdentifier:@"ID"];
    _collectionView.backgroundColor = [UIColor whiteColor];
}

//_______________________________________________________________________________________________________________
// MARK: -

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return _models.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    WLVideoModel *videoModel = _models[indexPath.row];
    WLVideoCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"ID" forIndexPath:indexPath];
    cell.videoModel = videoModel;
    return cell;
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    WLVideoModel *videoModel = _models[indexPath.row];
    WLVideoInfoController *vc = [WLVideoInfoController new];
    vc.videoModel = videoModel;
    [self.navigationController pushViewController:vc animated:YES];
}

// 更多
- (void)more:(UIBarButtonItem *)item {
    WLChooseCategoryController *vc = [WLChooseCategoryController new];
    vc.selectedTag = _selectedTag;
    vc.delegate = self;
    [self.navigationController pushViewController:vc animated:YES];
}


//_______________________________________________________________________________________________________________
// MARK: - WLChooseCategoryControllerDelegate
- (void)chooseCategoryController:(WLChooseCategoryController *)controller didSelectTag:(NSString *)tag {
    if ([_selectedTag isEqualToString:tag]) {
        return;
    }
    _selectedTag = tag;
    _page = 1;
    _isRequesting = NO;
    self.navigationItem.title = _selectedTag.lastPathComponent;
    _models = [NSMutableArray new];
    [_collectionView reloadData];
    [self loadData];
}

@end
