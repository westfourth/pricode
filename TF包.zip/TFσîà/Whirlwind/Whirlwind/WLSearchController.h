//
//  WLSearchController.h
//  Whirlwind
//
//  Created by mac on 2020/3/7.
//  Copyright © 2020 mac. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

/// 搜索
@interface WLSearchController : UIViewController <UISearchBarDelegate>

@end

NS_ASSUME_NONNULL_END
