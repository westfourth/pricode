//
//  WLVideoInfoController.h
//  Whirlwind
//
//  Created by mac on 2020/3/6.
//  Copyright © 2020 mac. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <WLNetwork/WLNetwork.h>

NS_ASSUME_NONNULL_BEGIN

/// 视频详情
@interface WLVideoInfoController : UIViewController

@property (nonatomic) WLVideoModel *videoModel;

@end

NS_ASSUME_NONNULL_END
