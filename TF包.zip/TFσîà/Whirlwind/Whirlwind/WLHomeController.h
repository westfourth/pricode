//
//  WLHomeController.h
//  Whirlwind
//
//  Created by mac on 2020/3/6.
//  Copyright © 2020 mac. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

/// 首页
@interface WLHomeController : UIViewController

@end

NS_ASSUME_NONNULL_END
