//
//  WLEpisodeController.m
//  Whirlwind
//
//  Created by mac on 2020/3/7.
//  Copyright © 2020 mac. All rights reserved.
//

#import "WLEpisodeController.h"
#import "WLEpisodeCell.h"

@interface WLEpisodeController () <UICollectionViewDataSource, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout> {
    UICollectionView *_collectionView;
}

@end

@implementation WLEpisodeController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = self.lineModel.line;
    [self setupCollectionView];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [self.navigationController setNavigationBarHidden:NO animated:YES];
}

- (void)viewDidLayoutSubviews {
    [super viewDidLayoutSubviews];
    _collectionView.frame = self.view.bounds;
}

- (void)setupCollectionView {
    UICollectionViewFlowLayout *layout = [UICollectionViewFlowLayout new];
    layout.minimumLineSpacing = 8;
    layout.minimumInteritemSpacing = 8;
    layout.sectionInset = UIEdgeInsetsMake(8, 8, 8, 8);
    
    _collectionView = [[UICollectionView alloc] initWithFrame:CGRectZero collectionViewLayout:layout];
    [self.view addSubview:_collectionView];
    _collectionView.dataSource = self;
    _collectionView.delegate = self;

    [_collectionView registerClass:[WLEpisodeCell class] forCellWithReuseIdentifier:@"ID"];
    _collectionView.backgroundColor = [UIColor whiteColor];
}

//_______________________________________________________________________________________________________________
// MARK: -

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return self.lineModel.list.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    WLEpisodeModel *model = self.lineModel.list[indexPath.row];
    WLEpisodeCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"ID" forIndexPath:indexPath];
    cell.episodeModel = model;
    return cell;
}

- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath {
    WLEpisodeModel *model = self.lineModel.list[indexPath.row];
    return [WLEpisodeCell itemSize:model];
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {

}

@end
