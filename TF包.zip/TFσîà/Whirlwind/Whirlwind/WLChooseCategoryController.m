//
//  WLChooseCategoryController.m
//  Whirlwind
//
//  Created by mac on 2020/3/7.
//  Copyright © 2020 mac. All rights reserved.
//

#import "WLChooseCategoryController.h"
#import "WLChooseCategoryModel.h"

@interface WLChooseCategoryController () <UITableViewDataSource, UITableViewDelegate> {
    UITableView *_tableView;
    NSArray<WLChooseCategoryModel *> *_array;
}

@end

@implementation WLChooseCategoryController

- (instancetype)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.hidesBottomBarWhenPushed = YES;
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"选择类型";
    _array = [WLChooseCategoryModel loadModels];
    [self setupTableView];
}

- (void)setupTableView {
    _tableView = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStyleGrouped];
    [self.view addSubview:_tableView];
    _tableView.frame = self.view.frame;
    _tableView.dataSource = self;
    _tableView.delegate = self;
    _tableView.sectionHeaderHeight = 8;
    _tableView.sectionFooterHeight = 8;
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    NSIndexPath *indexPath = [self indexPathForSelectedTag];
    [_tableView scrollToRowAtIndexPath:indexPath atScrollPosition:UITableViewScrollPositionMiddle animated:NO];
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    [self.delegate chooseCategoryController:self didSelectTag:self.selectedTag];
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return _array.count;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    WLChooseCategoryModel *model = _array[section];
    return model.subModels.count + 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"ID"];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:@"ID"];
        cell.textLabel.font = [UIFont systemFontOfSize:18];
    }
    WLChooseCategoryModel *model = _array[indexPath.section];
    if (indexPath.row == 0) {
        cell.textLabel.text = model.official;
    } else {
        model = model.subModels[indexPath.row - 1];
        cell.textLabel.text = [NSString stringWithFormat:@"\t%@", model.official];
    }
    if ([model.tag isEqualToString:self.selectedTag]) {
        cell.backgroundColor = [UIColor redColor];
    } else {
        cell.backgroundColor = [UIColor whiteColor];
    }
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    WLChooseCategoryModel *model = _array[indexPath.section];
    if (indexPath.row != 0) {
        model = model.subModels[indexPath.row - 1];
    }
    NSIndexPath *preIndexPath = [self indexPathForSelectedTag];
    self.selectedTag = model.tag;
    [tableView reloadRowsAtIndexPaths:@[preIndexPath, indexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
    [self.navigationController popViewControllerAnimated:YES];
}

//  找到selectedTag对应的IndexPath
- (NSIndexPath *)indexPathForSelectedTag {
    for (int i = 0; i < _array.count; i++) {
        WLChooseCategoryModel *model = _array[i];
        if ([model.tag isEqualToString:self.selectedTag]) {
            return [NSIndexPath indexPathForRow:0 inSection:i];
            break;
        } else {
            if (model.subModels.count) {
                for (int j = 0; j < model.subModels.count; j++) {
                    WLChooseCategoryModel *subModel = model.subModels[j];
                    if ([subModel.tag isEqualToString:self.selectedTag]) {
                        return [NSIndexPath indexPathForRow:j + 1 inSection:i];
                        break;
                    }
                }
            }
        }
    }
    return [NSIndexPath indexPathForRow:0 inSection:0];
}

@end
