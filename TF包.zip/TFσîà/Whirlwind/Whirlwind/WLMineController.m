//
//  WLMineController.m
//  Whirlwind
//
//  Created by mac on 2020/3/6.
//  Copyright © 2020 mac. All rights reserved.
//

#import "WLMineController.h"

@interface WLMineController ()

@end

@implementation WLMineController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
