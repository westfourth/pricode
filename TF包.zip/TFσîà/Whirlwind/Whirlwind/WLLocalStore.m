//
//  WLLocalStore.m
//  Whirlwind
//
//  Created by mac on 2020/3/6.
//  Copyright © 2020 mac. All rights reserved.
//

#import "WLLocalStore.h"

#define WL_LOCAL_STORE_DIR  NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES).firstObject

@implementation WLLocalStore
static NSMutableArray *_videoModels = nil;

+ (void)initialize
{
    if (self == [WLLocalStore class]) {
        [WLLocalStore read];
    }
}

+ (NSMutableArray<WLVideoModel *> *)videoModels {
    return _videoModels;
}

//  videoID作为唯一值
+ (void)add:(WLVideoModel *)model {
    WLVideoModel *find = nil;
    for (WLVideoModel *m in _videoModels) {
        if ([m.videoID isEqualToString:model.videoID]) {
            find = m;
            break;
        }
    }
    if (find == nil) {
        [_videoModels addObject:model];
    }
}

+ (void)remove:(WLVideoModel *)model {
    WLVideoModel *find = nil;
    for (WLVideoModel *m in _videoModels) {
        if ([m.videoID isEqualToString:model.videoID]) {
            find = m;
            break;
        }
    }
    [_videoModels removeObject:find];
}

+ (BOOL)has:(WLVideoModel *)model {
    WLVideoModel *find = nil;
    for (WLVideoModel *m in _videoModels) {
        if ([m.videoID isEqualToString:model.videoID]) {
            find = m;
            break;
        }
    }
    return find == nil ? NO : YES;
}

+ (void)read {
    NSString *path = [WL_LOCAL_STORE_DIR stringByAppendingPathComponent:@"video_collect"];
    NSData *data = [NSData dataWithContentsOfFile:path];
    NSArray<WLVideoModel *> *videoModels = [NSKeyedUnarchiver unarchiveObjectWithData:data];
    _videoModels = [NSMutableArray arrayWithArray:videoModels];
}

+ (void)save {
    NSData *data = [NSKeyedArchiver archivedDataWithRootObject:_videoModels];
    NSString *path = [WL_LOCAL_STORE_DIR stringByAppendingPathComponent:@"video_collect"];
    [data writeToFile:path atomically:YES];
}

@end
