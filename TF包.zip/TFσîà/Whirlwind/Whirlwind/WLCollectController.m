//
//  WLCollectController.m
//  Whirlwind
//
//  Created by mac on 2020/3/6.
//  Copyright © 2020 mac. All rights reserved.
//

#import "WLCollectController.h"
#import "WLVideoCell.h"
#import "WLVideoInfoController.h"
#import "WLLocalStore.h"

@interface WLCollectController () <UICollectionViewDataSource, UICollectionViewDelegate> {
    UICollectionView *_collectionView;
    NSMutableArray<WLVideoModel *> *_models;
}

@end

@implementation WLCollectController

- (void)viewDidLoad {
    [super viewDidLoad];
    _models = [NSMutableArray new];
    [self setupCollectionView];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [self loadData];
    self.navigationItem.rightBarButtonItem = nil;
}

- (void)viewDidLayoutSubviews {
    [super viewDidLayoutSubviews];
    _collectionView.frame = self.view.bounds;
}

- (void)loadData {
    _models = [WLLocalStore videoModels];
    [_collectionView reloadData];
}

- (void)setupCollectionView {
    UICollectionViewFlowLayout *layout = [WLVideoCell flowLayout];
    _collectionView = [[UICollectionView alloc] initWithFrame:CGRectZero collectionViewLayout:layout];
    [self.view addSubview:_collectionView];
    _collectionView.dataSource = self;
    _collectionView.delegate = self;
    
    [_collectionView registerClass:[WLVideoCell class] forCellWithReuseIdentifier:@"ID"];
    _collectionView.backgroundColor = [UIColor whiteColor];
}

- (void)bubble {

}

//_______________________________________________________________________________________________________________
// MARK: -

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return _models.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    WLVideoModel *videoModel = _models[indexPath.row];
    WLVideoCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"ID" forIndexPath:indexPath];
    cell.videoModel = videoModel;
    return cell;
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    WLVideoModel *videoModel = _models[indexPath.row];
    WLVideoInfoController *vc = [WLVideoInfoController new];
    vc.videoModel = videoModel;
    [self.navigationController pushViewController:vc animated:YES];
}

@end
