//
//  WLRecommandController.m
//  Whirlwind
//
//  Created by mac on 2020/3/7.
//  Copyright © 2020 mac. All rights reserved.
//

#import "WLRecommandController.h"
#import "WLVideoCell.h"
#import "WLVideoInfoController.h"

@interface WLRecommandController () <UICollectionViewDataSource, UICollectionViewDelegate> {
    UICollectionView *_collectionView;
}

@end

@implementation WLRecommandController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = @"相关推荐";
    [self setupCollectionView];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [self.navigationController setNavigationBarHidden:NO animated:YES];
}

- (void)viewDidLayoutSubviews {
    [super viewDidLayoutSubviews];
    _collectionView.frame = self.view.bounds;
}

- (void)setupCollectionView {
    UICollectionViewFlowLayout *layout = [WLVideoCell flowLayout];
    _collectionView = [[UICollectionView alloc] initWithFrame:CGRectZero collectionViewLayout:layout];
    [self.view addSubview:_collectionView];
    _collectionView.dataSource = self;
    _collectionView.delegate = self;
    
    [_collectionView registerClass:[WLVideoCell class] forCellWithReuseIdentifier:@"ID"];
    _collectionView.backgroundColor = [UIColor whiteColor];
}

- (void)setRecommands:(NSMutableArray<WLVideoModel *> *)recommands {
    _recommands = recommands;
    [_collectionView reloadData];
}

//_______________________________________________________________________________________________________________
// MARK: -

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return self.recommands.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    WLVideoModel *videoModel = self.recommands[indexPath.row];
    WLVideoCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"ID" forIndexPath:indexPath];
    cell.videoModel = videoModel;
    return cell;
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    WLVideoModel *videoModel = self.recommands[indexPath.row];
    WLVideoInfoController *vc = [WLVideoInfoController new];
    vc.videoModel = videoModel;
    [self.navigationController pushViewController:vc animated:YES];
}

@end
