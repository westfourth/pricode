//
//  WLRecommandController.h
//  Whirlwind
//
//  Created by mac on 2020/3/7.
//  Copyright © 2020 mac. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <WLNetwork/WLNetwork.h>

NS_ASSUME_NONNULL_BEGIN

/// 推荐
@interface WLRecommandController : UIViewController

@property (nonatomic) NSMutableArray<WLVideoModel *> *recommands;   //  推荐

@end

NS_ASSUME_NONNULL_END
