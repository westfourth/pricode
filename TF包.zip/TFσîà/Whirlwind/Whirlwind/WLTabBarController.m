//
//  WLTabBarController.m
//  Whirlwind
//
//  Created by mac on 2020/3/6.
//  Copyright © 2020 mac. All rights reserved.
//

#import "WLTabBarController.h"
#import "WLBundle.h"
#import <SDWebImage/SDWebImage.h>

@interface WLTabBarController ()

@end

@implementation WLTabBarController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [[SDWebImageDownloader sharedDownloader] setValue:@"https://miao101.com/" forHTTPHeaderField:@"Referer"];
    
    NSString *path = [[WLBundle main] pathForResource:@"Tabbar" ofType:@"plist"];
    NSArray *array = [NSArray arrayWithContentsOfFile:path];
    
    NSMutableArray<UINavigationController *> *controllers = [NSMutableArray new];
    
    for (NSDictionary *dict in array) {
        Class cls = NSClassFromString(dict[@"controller"]);
        //  vc
        UIViewController *vc = [cls new];
        vc.navigationItem.title = dict[@"title"];
        
        //  leftBarButtonItem
//        UIImage *logoImage = [[UIImage imageNamed:@"logo_small" inBundle:[WLBundle main] compatibleWithTraitCollection:nil] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
//        vc.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithImage:logoImage style:UIBarButtonItemStyleDone target:nil action:nil];
//        vc.navigationItem.leftBarButtonItem.enabled = NO;
        
        //  TabBarItem
        UIImage *image = [UIImage imageNamed:dict[@"image"] inBundle:[WLBundle main] compatibleWithTraitCollection:nil];
        UITabBarItem *item = [[UITabBarItem alloc] initWithTitle:dict[@"title"] image:image selectedImage:nil];
        
        //  navVC
        UINavigationController *navVC = [[UINavigationController alloc] initWithRootViewController:vc];
        navVC.tabBarItem = item;
//        navVC.hidesBarsOnSwipe = YES;
        navVC.navigationBar.tintColor = [UIColor redColor];
        [controllers addObject:navVC];
    }
    self.viewControllers = controllers;
    self.tabBar.tintColor = [UIColor redColor];
}


@end
