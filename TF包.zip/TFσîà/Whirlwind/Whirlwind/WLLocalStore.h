//
//  WLLocalStore.h
//  Whirlwind
//
//  Created by mac on 2020/3/6.
//  Copyright © 2020 mac. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <WLNetwork/WLNetwork.h>

NS_ASSUME_NONNULL_BEGIN

//  保存收藏的视频
@interface WLLocalStore : NSObject

//
@property (class, readonly, nonatomic) NSMutableArray<WLVideoModel *> *videoModels;

//  videoID作为唯一值
+ (void)add:(WLVideoModel *)model;
+ (void)remove:(WLVideoModel *)model;
+ (BOOL)has:(WLVideoModel *)model;

+ (void)read;
+ (void)save;

@end

NS_ASSUME_NONNULL_END
