//
//  WLVideoCell.m
//  Whirlwind
//
//  Created by mac on 2020/3/6.
//  Copyright © 2020 mac. All rights reserved.
//

#import "WLVideoCell.h"
#import <SDWebImage/SDWebImage.h>

float const WLVideoCellRatio = 618.0 / 842.0;   //  宽高比
float const WLVideoCellLineSpacing = 4;
float const WLVideoCellInteritemSpacing = 4;
float const WLVideoCellEdge = 4;                //  两边间距


@interface WLVideoCell () {
    UIImageView *_imageView;
    UILabel *_titleLabel;
    UILabel *_categoryLabel;
    UILabel *_scoreLabel;
}

@end

@implementation WLVideoCell

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        //  _imageView
        _imageView = [UIImageView new];
        [self.contentView addSubview:_imageView];
        _imageView.backgroundColor = [UIColor cyanColor];
        
        _imageView.layer.shadowColor = [UIColor blackColor].CGColor;
        _imageView.layer.shadowOffset = CGSizeZero;
        _imageView.layer.shadowRadius = 1;
        _imageView.layer.shadowOpacity = 1;
        
        //  _titleLabel
        _titleLabel = [UILabel new];
        [self.contentView addSubview:_titleLabel];
        _titleLabel.font = [UIFont systemFontOfSize:16];
        _titleLabel.textColor = [UIColor darkTextColor];
        
        //  _categoryLabel
        _categoryLabel = [UILabel new];
        [_imageView addSubview:_categoryLabel];
        _categoryLabel.font = [UIFont systemFontOfSize:12];
        _categoryLabel.textColor = [UIColor blackColor];
        _categoryLabel.backgroundColor = [UIColor colorWithRed:255/255.0 green:193/255.0 blue:52/255.0 alpha:1];
        _categoryLabel.layer.masksToBounds = YES;
        _categoryLabel.layer.cornerRadius = 10;
        _categoryLabel.textAlignment = NSTextAlignmentCenter;
        
        //  _scoreLabel
        _scoreLabel = [UILabel new];
        [_imageView addSubview:_scoreLabel];
        _scoreLabel.font = [UIFont boldSystemFontOfSize:12];
        _scoreLabel.textColor = [UIColor whiteColor];
        _scoreLabel.backgroundColor = [UIColor redColor];
        _scoreLabel.layer.masksToBounds = YES;
        _scoreLabel.layer.cornerRadius = 4;
        _scoreLabel.textAlignment = NSTextAlignmentCenter;
    }
    return self;
}

- (void)layoutSubviews {
    [super layoutSubviews];
    CGFloat imageHeight = [WLVideoCell itemWidth] / WLVideoCellRatio;
    _imageView.frame = CGRectMake(0, 0, self.bounds.size.width, imageHeight);
    _titleLabel.frame = CGRectMake(0, CGRectGetMaxY(_imageView.frame) + 6, self.bounds.size.width, 20);
    //  _categoryLabel
    CGRect rect = [_categoryLabel.text boundingRectWithSize:CGSizeZero options:NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName: _categoryLabel.font} context:nil];
    _categoryLabel.frame = CGRectMake(4, CGRectGetHeight(_imageView.frame) - 20 - 4,
                                      rect.size.width + 8 * 2, 20);
    //  _scoreLabel
    _scoreLabel.frame = CGRectMake(self.bounds.size.width - 28 - 4, CGRectGetMinY(_categoryLabel.frame),
                                   28, CGRectGetHeight(_categoryLabel.frame));
    
}

- (void)setVideoModel:(WLVideoModel *)videoModel {
    _videoModel = videoModel;
    [_imageView sd_setImageWithURL:videoModel.coverURL];
    _titleLabel.text = videoModel.name;
    _categoryLabel.text = videoModel.category;
    _scoreLabel.text = [NSString stringWithFormat:@"%.1f", videoModel.score];
    [self setNeedsLayout];
}

//- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
//    [super touchesBegan:touches withEvent:event];
//    [UIView animateWithDuration:0.25 animations:^{
//        self.transform = CGAffineTransformMakeScale(1.05, 1.05);
//    }];
//}
//
//- (void)touchesEnded:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
//    [super touchesEnded:touches withEvent:event];
//    [UIView animateWithDuration:0.25 animations:^{
//        self.transform = CGAffineTransformIdentity;
//    }];
//}
//
//- (void)touchesCancelled:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
//    [super touchesCancelled:touches withEvent:event];
//    [UIView animateWithDuration:0.25 animations:^{
//        self.transform = CGAffineTransformIdentity;
//    }];
//}

//_______________________________________________________________________________________________________________
// MARK: -

+ (UICollectionViewFlowLayout *)flowLayout {
    UICollectionViewFlowLayout *layout = [UICollectionViewFlowLayout new];
    layout.minimumLineSpacing = WLVideoCellLineSpacing;
    layout.minimumInteritemSpacing = WLVideoCellInteritemSpacing;
    layout.itemSize = [WLVideoCell itemSize];
    layout.sectionInset = UIEdgeInsetsMake(WLVideoCellEdge, WLVideoCellEdge, WLVideoCellEdge, WLVideoCellEdge);
    return layout;
}

+ (CGFloat)itemWidth {
    return ([UIScreen mainScreen].bounds.size.width - 2 * WLVideoCellEdge - WLVideoCellInteritemSpacing) / 2.0;
}

+ (CGSize)itemSize {
    CGFloat width = [WLVideoCell itemWidth];
    CGFloat height = width / WLVideoCellRatio + 30;
    return CGSizeMake(width, height);
}

@end
