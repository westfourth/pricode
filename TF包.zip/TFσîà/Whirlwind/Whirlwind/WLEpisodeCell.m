//
//  WLEpisodeCell.m
//  Whirlwind
//
//  Created by mac on 2020/3/7.
//  Copyright © 2020 mac. All rights reserved.
//

#import "WLEpisodeCell.h"

@interface WLEpisodeCell () {
    UILabel *_label;
}

@end

@implementation WLEpisodeCell

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.layer.cornerRadius = 6;
        self.layer.borderColor = [UIColor redColor].CGColor;
        self.layer.borderWidth = 1;
        
        _label = [UILabel new];
        [self.contentView addSubview:_label];
        _label.textAlignment = NSTextAlignmentCenter;
        _label.textColor = [UIColor redColor];
        _label.font = [UIFont systemFontOfSize:18];
    }
    return self;
}

- (void)layoutSubviews {
    [super layoutSubviews];
    _label.frame = self.bounds;
}

- (void)setEpisodeModel:(WLEpisodeModel *)episodeModel {
    _episodeModel = episodeModel;
    _label.text = episodeModel.episode;
}

+ (CGSize)itemSize:(WLEpisodeModel *)model {
    CGRect rect = [model.episode boundingRectWithSize:CGSizeZero options:NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName: [UIFont systemFontOfSize:18]} context:nil];
    return CGSizeMake(rect.size.width + 16 * 2, 40);
}

@end
