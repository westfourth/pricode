//
//  WLChooseCategoryModel.m
//  Whirlwind
//
//  Created by mac on 2020/3/7.
//  Copyright © 2020 mac. All rights reserved.
//

#import "WLChooseCategoryModel.h"
#import "WLBundle.h"

@implementation WLChooseCategoryModel

+ (NSArray<WLChooseCategoryModel *> *)loadModels {
    NSString *path = [[WLBundle main] pathForResource:@"VideoCategory" ofType:@"plist"];
    NSArray<NSDictionary *> *array = [NSArray arrayWithContentsOfFile:path];
    return [WLChooseCategoryModel convertArray:array];
}

+ (NSArray<WLChooseCategoryModel *> *)convertArray:(NSArray<NSDictionary *> *)array {
    NSMutableArray<WLChooseCategoryModel *> *models = [NSMutableArray new];
    for (NSDictionary *dict in array) {
        WLChooseCategoryModel *model = [WLChooseCategoryModel new];
        model.official = dict[@"official"];
        model.local = dict[@"local"];
        model.tag = dict[@"tag"];
        NSArray *sub = dict[@"sub"];
        if (sub.count) {
            model.subModels = [WLChooseCategoryModel convertArray:sub];
        }
        [models addObject:model];
    }
    return models;
}

@end
