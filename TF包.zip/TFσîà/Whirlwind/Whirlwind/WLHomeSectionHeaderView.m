//
//  WLHomeSectionHeaderView.m
//  Whirlwind
//
//  Created by mac on 2020/3/6.
//  Copyright © 2020 mac. All rights reserved.
//

#import "WLHomeSectionHeaderView.h"

@interface WLHomeSectionHeaderView () {
    UILabel *_label;
}

@end

@implementation WLHomeSectionHeaderView

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        _label = [UILabel new];
        [self addSubview:_label];
        _label.textColor = [UIColor whiteColor];
        _label.font = [UIFont boldSystemFontOfSize:18];
        _label.backgroundColor = [UIColor redColor];
        _label.layer.masksToBounds = YES;
        _label.layer.cornerRadius = 14;
        _label.textAlignment = NSTextAlignmentCenter;
    }
    return self;
}

- (void)layoutSubviews {
    [super layoutSubviews];
    CGRect rect = [_label.text boundingRectWithSize:CGSizeZero options:NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName: _label.font} context:nil];
    _label.frame = CGRectMake(4, 8, rect.size.width + 12 * 2, 28);
    
}

- (void)setHomeModel:(WLHomeModel *)homeModel {
    _homeModel = homeModel;
    _label.text = homeModel.category;
    [self setNeedsLayout];
}

@end
