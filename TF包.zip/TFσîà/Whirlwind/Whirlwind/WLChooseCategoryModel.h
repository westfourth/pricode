//
//  WLChooseCategoryModel.h
//  Whirlwind
//
//  Created by mac on 2020/3/7.
//  Copyright © 2020 mac. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface WLChooseCategoryModel : NSObject

@property (nonatomic) NSString *official;
@property (nonatomic) NSString *local;
@property (nonatomic) NSString *tag;
@property (nonatomic) BOOL open;        //  是否处于打开状态

@property (nullable, nonatomic) NSArray<WLChooseCategoryModel *> *subModels;

+ (NSArray<WLChooseCategoryModel *> *)loadModels;

@end

NS_ASSUME_NONNULL_END
