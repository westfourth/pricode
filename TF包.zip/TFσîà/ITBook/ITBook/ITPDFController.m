//
//  ITPDFController.m
//  ITBook
//
//  Created by mac on 2020/3/12.
//  Copyright © 2020 mac. All rights reserved.
//

#import "ITPDFController.h"
#import <PDFKit/PDFKit.h>
#import "ITPDFStore.h"

@interface ITPDFController ()

@end

@implementation ITPDFController

- (void)loadView {
    self.view = [PDFView new];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [ITPDFStore get:self.url completion:^(NSError * _Nonnull error, NSData * _Nonnull data) {
        if (error) {
            return;
        }
        PDFDocument *doc = [[PDFDocument alloc] initWithData:data];
        ((PDFView *)self.view).document = doc;
    }];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [self.navigationController setNavigationBarHidden:NO animated:YES];
}


@end
