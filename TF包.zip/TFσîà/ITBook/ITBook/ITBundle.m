//
//  ITBundle.m
//  ITBook
//
//  Created by mac on 2020/3/11.
//  Copyright © 2020 mac. All rights reserved.
//

#import "ITBundle.h"

@implementation ITBundle

+ (NSBundle *)main {
    NSBundle *b = [NSBundle bundleForClass:[self class]];
    NSString *resourceName = b.bundleIdentifier.pathExtension;
    NSURL *url = [b URLForResource:resourceName withExtension:@"bundle"];
    if (url != nil) {
        b = [NSBundle bundleWithURL:url];
    }
    return b;
}

@end
