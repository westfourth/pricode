//
//  ITAppDelegate.m
//  ITBook
//
//  Created by mac on 2020/3/10.
//  Copyright © 2020 mac. All rights reserved.
//

#import "ITAppDelegate.h"
#import "ITTabBarController.h"

@interface ITAppDelegate ()

@end

@implementation ITAppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    puts(NSTemporaryDirectory().UTF8String);
    //
    UIWindow *window = [UIWindow new];
    window.frame = [UIScreen mainScreen].bounds;
    [window makeKeyAndVisible];
    self.window = window;
    self.window.rootViewController = [ITTabBarController new];
    return YES;
}


@end
