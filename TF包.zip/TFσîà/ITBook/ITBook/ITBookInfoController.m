//
//  ITBookInfoController.m
//  ITBook
//
//  Created by mac on 2020/3/11.
//  Copyright © 2020 mac. All rights reserved.
//

#import "ITBookInfoController.h"
#import <SDWebImage/SDWebImage.h>
#import <XSVendor/UILabel+XSPadding.h>
#import "ITBundle.h"
#import "ITLocalStore.h"
#import <ITNetwork/ITNetwork.h>
#import "ITPDFController.h"

@interface ITBookInfoController () <UITableViewDataSource, UITableViewDelegate> {
    UITableView *_tableView;
    UIImageView *_headerView;
    UILabel *_footerView;
    ITBookDetailModel *_detailModel;
    NSArray *_fixedTitles;
    NSDictionary *_samplePDF;
}

@end

@implementation ITBookInfoController

- (instancetype)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.hidesBottomBarWhenPushed = YES;
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    _fixedTitles = @[@"Price", @"Title", @"Author", @"Publisher", @"Year",
                     @"Pages", @"Language", @"Rating", @"ISBN-10", @"ISBN-13"];
    
    NSString *imageName = [ITLocalStore hasISBN:self.isbn13] ? @"nav_collect2" : @"nav_collect1";
    UIImage *image = [UIImage imageNamed:imageName inBundle:[ITBundle main] compatibleWithTraitCollection:nil];
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithImage:image style:UIBarButtonItemStyleDone target:self action:@selector(collect:)];
    
    [self setupTableView];
    [self setupHeaderView];
    [self setupFooterView];
    [self loadData];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [self.navigationController setNavigationBarHidden:NO animated:YES];
}

- (void)loadData {
    [ITBookDetailModel getBookDetailByIsbn13:self.isbn13 completion:^(NSError * _Nonnull error, ITBookDetailModel * _Nonnull model) {
        if (error) {
            return;
        }
        _detailModel = model;
        
        //  样本
        _samplePDF = model.pdf;
        
        _footerView.text = model.desc;
        //  计算大小
        CGRect rect = [model.desc boundingRectWithSize:CGSizeMake([UIScreen mainScreen].bounds.size.width - 20 * 2, 0) options:NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName: _footerView.font} context:nil];
        _footerView.frame = CGRectMake(0, 0, 0, rect.size.height + 10);
        //
        [_tableView reloadData];
    }];
}

- (void)setupTableView {
    _tableView = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStyleGrouped];
    [self.view addSubview:_tableView];
    _tableView.frame = self.view.frame;
    _tableView.dataSource = self;
    _tableView.delegate = self;
    _tableView.sectionHeaderHeight = 8;
    _tableView.sectionFooterHeight = 8;
}

- (void)setupHeaderView {
    _headerView = [UIImageView new];
    _tableView.tableHeaderView = _headerView;
    _headerView.frame = CGRectMake(0, 0, 0, 300);
    _headerView.contentMode = UIViewContentModeScaleAspectFit;
    [_headerView sd_setImageWithURL:self.imageURL];
    
    _headerView.layer.shadowColor = [UIColor blackColor].CGColor;
    _headerView.layer.shadowOffset = CGSizeZero;
    _headerView.layer.shadowRadius = 4;
    _headerView.layer.shadowOpacity = 1;
}

- (void)setupFooterView {
    _footerView = [UILabel new];
    _tableView.tableFooterView = _footerView;
    _footerView.frame = CGRectMake(0, 0, 0, 100);
    _footerView.numberOfLines = 0;
    _footerView.padding = UIEdgeInsetsMake(0, 20, 0, 20);
    _footerView.font = [UIFont systemFontOfSize:16];
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return _samplePDF.allKeys.count ? 2 : 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (section == 0) {
        return _fixedTitles.count;
    } else {
        return _samplePDF.allKeys.count;
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"ID"];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:@"ID"];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        cell.textLabel.font = [UIFont systemFontOfSize:18];
    }
    if (indexPath.section == 0) {
        NSString *title = _fixedTitles[indexPath.row];
        cell.textLabel.attributedText = [self attrText:title];
        cell.accessoryType = UITableViewCellAccessoryNone;
    } else {
        NSString *title = _samplePDF.allKeys[indexPath.row];
        NSDictionary *a1 = @{NSForegroundColorAttributeName: [UIColor blueColor]};
        cell.textLabel.attributedText = [[NSAttributedString alloc] initWithString:title attributes:a1];
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    }
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section == 0) {
        
    } else {
        NSString *pdfURLString = _samplePDF.allValues[indexPath.row];
        ITPDFController *vc = [ITPDFController new];
        vc.url = [NSURL URLWithString:pdfURLString];
        vc.title = _detailModel.title;
        [self.navigationController pushViewController:vc animated:YES];
    }
}

- (NSMutableAttributedString *)attrText:(NSString *)title {
    NSString *detail = @"";
    if ([title isEqualToString:@"Price"]) {
        detail = _detailModel.price;
    } else if ([title isEqualToString:@"Title"]) {
        detail = _detailModel.title;
    } else if ([title isEqualToString:@"Author"]) {
        detail = _detailModel.authors;
    } else if ([title isEqualToString:@"Publisher"]) {
        detail = _detailModel.publisher;
    } else if ([title isEqualToString:@"Year"]) {
        detail = [NSString stringWithFormat:@"%ld", _detailModel.year];
    } else if ([title isEqualToString:@"Pages"]) {
        detail = [NSString stringWithFormat:@"%ld", _detailModel.pages];
    } else if ([title isEqualToString:@"Language"]) {
        detail = _detailModel.language;
    } else if ([title isEqualToString:@"Rating"]) {
        detail = [NSString stringWithFormat:@"%.1f", _detailModel.rating];
    } else if ([title isEqualToString:@"ISBN-10"]) {
        detail = _detailModel.isbn10;
    } else if ([title isEqualToString:@"ISBN-13"]) {
        detail = _detailModel.isbn13;
    }
    if (detail == nil) {
        detail = @"";
    }
    NSDictionary *a1 = @{NSForegroundColorAttributeName: [UIColor grayColor]};
    NSDictionary *a2 = @{NSForegroundColorAttributeName: [UIColor blackColor]};
    NSAttributedString *attrTitle = [[NSAttributedString alloc] initWithString:[NSString stringWithFormat:@"%@：", title] attributes:a1];
    NSAttributedString *attrDetail = [[NSAttributedString alloc] initWithString:detail attributes:a2];
    NSMutableAttributedString *result = [NSMutableAttributedString new];
    [result appendAttributedString:attrTitle];
    [result appendAttributedString:attrDetail];
    return result;
}

// 收藏
- (void)collect:(UIBarButtonItem *)item {
    if ([ITLocalStore has:_detailModel]) {
        [ITLocalStore remove:_detailModel];
    } else {
        [ITLocalStore add:_detailModel];
    }
    //  更新图片
    NSString *imageName = [ITLocalStore has:_detailModel] ? @"nav_collect2" : @"nav_collect1";
    UIImage *image = [UIImage imageNamed:imageName inBundle:[ITBundle main] compatibleWithTraitCollection:nil];
    item.image = image;
    //  存储到本地
    [ITLocalStore save];
}

@end
