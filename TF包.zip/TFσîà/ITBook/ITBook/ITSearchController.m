//
//  ITSearchController.m
//  ITBook
//
//  Created by mac on 2020/3/11.
//  Copyright © 2020 mac. All rights reserved.
//

#import "ITSearchController.h"
#import <XSVendor/UIScrollView+XSRefresh.h>
#import "ITBookCell.h"
#import "ITBookInfoController.h"

@interface ITSearchController () <UICollectionViewDataSource, UICollectionViewDelegate, UISearchBarDelegate> {
    UICollectionView *_collectionView;
    NSMutableArray<ITBookModel *> *_models;
    BOOL _isRequesting;     //  是否在请求数据
    NSUInteger _page;
}

@end

@implementation ITSearchController

- (instancetype)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.hidesBottomBarWhenPushed = YES;
    }
    return self;
}


- (void)viewDidLoad {
    [super viewDidLoad];
    _page = 1;
    _models = [NSMutableArray new];
    self.title = _selectedKey;
    
    [self setupCollectionView];
    [self loadData];
    __weak typeof (self) weak_self = self;
    _collectionView.loadMoreBlock = ^{
        [weak_self loadData];
    };
}

- (void)viewDidLayoutSubviews {
    [super viewDidLayoutSubviews];
    _collectionView.frame = self.view.bounds;
}

- (void)loadData {
    if (_isRequesting) {
        return;
    }
    _isRequesting = YES;
    [ITBookModel search:_selectedKey page:_page completion:^(NSError * _Nonnull error, NSArray<ITBookModel *> * _Nonnull models) {
        _isRequesting = NO;
        _page++;
        if (error) {
            return;
        }
        [_models addObjectsFromArray:models];
        [_collectionView reloadData];
    }];
}

- (void)setupCollectionView {
    UICollectionViewFlowLayout *layout = [ITBookCell flowLayout];
    _collectionView = [[UICollectionView alloc] initWithFrame:CGRectZero collectionViewLayout:layout];
    [self.view addSubview:_collectionView];
    _collectionView.dataSource = self;
    _collectionView.delegate = self;
    
    [_collectionView registerClass:[ITBookCell class] forCellWithReuseIdentifier:@"ID"];
    _collectionView.backgroundColor = [UIColor whiteColor];
}

//_______________________________________________________________________________________________________________
// MARK: -

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return _models.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    ITBookModel *model = _models[indexPath.row];
    ITBookCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"ID" forIndexPath:indexPath];
    cell.model = model;
    return cell;
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    ITBookModel *model = _models[indexPath.row];
    ITBookInfoController *vc = [ITBookInfoController new];
    vc.imageURL = model.image;
    vc.isbn13 = model.isbn13;
    vc.title = model.title;
    UINavigationController *navVC = self.navigationController;
    if (navVC == nil) {
        navVC = self.presentingViewController.navigationController;
    }
    [navVC pushViewController:vc animated:YES];
}

//_______________________________________________________________________________________________________________
// MARK: -  UISearchBarDelegate

- (void)searchBarTextDidBeginEditing:(UISearchBar *)searchBar {
    [self reset];
}

- (void)searchBarTextDidEndEditing:(UISearchBar *)searchBar {
    if ([_selectedKey isEqualToString:searchBar.text]) {
        return;
    }
    [self reset];
    _selectedKey = searchBar.text;
    [self loadData];
}

- (void)reset {
    _page = 1;
    _isRequesting = NO;
    _models = [NSMutableArray new];
    [_collectionView reloadData];
}

@end
