//
//  ITTabBarController.m
//  ITBook
//
//  Created by mac on 2020/3/11.
//  Copyright © 2020 mac. All rights reserved.
//

#import "ITTabBarController.h"
#import "ITBundle.h"

@interface ITTabBarController ()

@end

@implementation ITTabBarController

- (void)viewDidLoad {
    [super viewDidLoad];
    NSString *path = [[ITBundle main] pathForResource:@"Tabbar" ofType:@"plist"];
    NSArray *array = [NSArray arrayWithContentsOfFile:path];
    
    NSMutableArray<UINavigationController *> *controllers = [NSMutableArray new];
    
    for (NSDictionary *dict in array) {
        Class cls = NSClassFromString(dict[@"controller"]);
        //  vc
        UIViewController *vc = [cls new];
        vc.navigationItem.title = dict[@"title"];
        
        
        //  TabBarItem
        UIImage *image = [UIImage imageNamed:dict[@"image"] inBundle:[ITBundle main] compatibleWithTraitCollection:nil];
        UITabBarItem *item = [[UITabBarItem alloc] initWithTitle:dict[@"title"] image:image selectedImage:nil];
        
        //  navVC
        UINavigationController *navVC = [[UINavigationController alloc] initWithRootViewController:vc];
        navVC.tabBarItem = item;
        navVC.navigationBar.tintColor = [UIColor redColor];
        [controllers addObject:navVC];
    }
    self.viewControllers = controllers;
    self.tabBar.tintColor = [UIColor redColor];
}

@end
