//
//  ITCategoryController.m
//  ITBook
//
//  Created by mac on 2020/3/11.
//  Copyright © 2020 mac. All rights reserved.
//

#import "ITCategoryController.h"
#import <ITNetwork/ITNetwork.h>
#import "ITSearchController.h"

@interface ITCategoryController () <UITableViewDataSource, UITableViewDelegate> {
    UITableView *_tableView;
    NSMutableArray<ITBookCategoryModel *> *_models;
}

@end

@implementation ITCategoryController

- (void)viewDidLoad {
    [super viewDidLoad];
    _models = [NSMutableArray new];
    [self setupTableView];
    [self loadData];
}

- (void)setupTableView {
    _tableView = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStyleGrouped];
    [self.view addSubview:_tableView];
    _tableView.frame = self.view.frame;
    _tableView.dataSource = self;
    _tableView.delegate = self;
    _tableView.sectionHeaderHeight = 40;
    _tableView.sectionFooterHeight = 0.001;
}

- (void)loadData {
    [ITBookCategoryModel requestWithCompletion:^(NSError * _Nonnull error, NSMutableArray<ITBookCategoryModel *> * _Nonnull models) {
        if (error) {
            return;
        }
        [_models addObjectsFromArray:models];
        [_tableView reloadData];
    }];
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return _models.count;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return _models[section].lists.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    ITBookCategoryItemModel *model = _models[indexPath.section].lists[indexPath.row];
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"ID"];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"ID"];
    }
    cell.textLabel.text = model.title;
    return cell;
}

-(NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
    return _models[section].name;
}

- (nullable NSArray<NSString *> *)sectionIndexTitlesForTableView:(UITableView *)tableView {
    return [_models valueForKey:@"name"];
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    ITBookCategoryItemModel *model = _models[indexPath.section].lists[indexPath.row];
    ITSearchController *vc = [ITSearchController new];
    vc.selectedKey = model.title;
    [self.navigationController pushViewController:vc animated:YES];
}

@end
