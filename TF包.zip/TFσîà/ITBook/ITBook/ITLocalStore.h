//
//  ITLocalStore.h
//  ITBook
//
//  Created by mac on 2020/3/11.
//  Copyright © 2020 mac. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <ITNetwork/ITNetwork.h>

NS_ASSUME_NONNULL_BEGIN

//  保存收藏的书
@interface ITLocalStore : NSObject

//
@property (class, readonly, nonatomic) NSMutableArray<ITBookDetailModel *> *models;

//  isbn13作为唯一值
+ (void)add:(ITBookDetailModel *)model;
+ (void)remove:(ITBookDetailModel *)model;
+ (BOOL)has:(ITBookDetailModel *)model;

+ (BOOL)hasISBN:(NSString *)isbn13;

+ (void)read;
+ (void)save;

@end

NS_ASSUME_NONNULL_END
