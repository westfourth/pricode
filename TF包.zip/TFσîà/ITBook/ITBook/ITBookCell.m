//
//  ITBookCell.m
//  ITBook
//
//  Created by mac on 2020/3/11.
//  Copyright © 2020 mac. All rights reserved.
//

#import "ITBookCell.h"
#import <SDWebImage/SDWebImage.h>

float const ITVideoCellRatio = 595.0 / 842.0;   //  宽高比
float const ITVideoCellLineSpacing = 4;
float const ITVideoCellInteritemSpacing = 4;
float const ITVideoCellEdge = 4;                //  两边间距


@interface ITBookCell () {
    UIImageView *_imageView;        //  阴影
    UIImageView *_downImageView;    //  裁剪
    UIImageView *_upImageView;      //  图片显示，放大
    UILabel *_titleLabel;
}

@end

@implementation ITBookCell

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        //  _imageView
        _imageView = [UIImageView new];
        [self.contentView addSubview:_imageView];
        
        _imageView.layer.shadowColor = [UIColor blackColor].CGColor;
        _imageView.layer.shadowOffset = CGSizeZero;
        _imageView.layer.shadowRadius = 4;
        _imageView.layer.shadowOpacity = 1;
        
        //  _downImageView
        _downImageView = [UIImageView new];
        [_imageView addSubview:_downImageView];
        _downImageView.clipsToBounds = YES;
        
        //  _upImageView
        _upImageView = [UIImageView new];
        [_downImageView addSubview:_upImageView];
        
        //  _titleLabel
        _titleLabel = [UILabel new];
        [self.contentView addSubview:_titleLabel];
        _titleLabel.font = [UIFont systemFontOfSize:14];
        _titleLabel.textColor = [UIColor darkTextColor];
    }
    return self;
}

- (void)layoutSubviews {
    [super layoutSubviews];
    CGFloat imageHeight = [ITBookCell itemWidth] / ITVideoCellRatio;
    _imageView.frame = CGRectMake(0, 0, self.bounds.size.width, imageHeight);
    _downImageView.frame = _imageView.frame;
    _upImageView.transform = CGAffineTransformIdentity;
    _upImageView.frame = _imageView.frame;
    _upImageView.transform = CGAffineTransformMakeScale(1.5, 1.5);
    _titleLabel.frame = CGRectMake(0, CGRectGetMaxY(_imageView.frame) + 6, self.bounds.size.width, 20);
}

//_______________________________________________________________________________________________________________
// MARK: -

-(void)setModel:(id)model {
    _model = model;
    if ([model isKindOfClass:[ITBookModel class]]) {
        [self setBookModel:model];
    } else if ([model isKindOfClass:[ITBookHotModel class]]) {
        [self setBookHotModel:model];
    } else if ([model isKindOfClass:[ITBookFreeModel class]]) {
        [self setBookFreeModel:model];
    } else if ([model isKindOfClass:[ITBookDetailModel class]]) {
       [self setBookDetailModel:model];
    }
}

- (void)setBookModel:(ITBookModel *)model {
    [_upImageView sd_setImageWithURL:model.image];
    _titleLabel.text = model.title;
}

- (void)setBookHotModel:(ITBookHotModel *)model {
    [_upImageView sd_setImageWithURL:model.image];
    _titleLabel.text = model.title;
}

- (void)setBookFreeModel:(ITBookFreeModel *)model {
    [_upImageView sd_setImageWithURL:model.image];
    _titleLabel.text = model.title;
}

- (void)setBookDetailModel:(ITBookDetailModel *)model {
    [_upImageView sd_setImageWithURL:model.image];
    _titleLabel.text = model.title;
}

//_______________________________________________________________________________________________________________
// MARK: -

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    [super touchesBegan:touches withEvent:event];
    [UIView animateWithDuration:0.25 animations:^{
        self.transform = CGAffineTransformMakeScale(1.05, 1.05);
    }];
}

- (void)touchesEnded:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    [super touchesEnded:touches withEvent:event];
    [UIView animateWithDuration:0.25 animations:^{
        self.transform = CGAffineTransformIdentity;
    }];
}

- (void)touchesCancelled:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    [super touchesCancelled:touches withEvent:event];
    [UIView animateWithDuration:0.25 animations:^{
        self.transform = CGAffineTransformIdentity;
    }];
}

//_______________________________________________________________________________________________________________
// MARK: -

+ (UICollectionViewFlowLayout *)flowLayout {
    UICollectionViewFlowLayout *layout = [UICollectionViewFlowLayout new];
    layout.minimumLineSpacing = ITVideoCellLineSpacing;
    layout.minimumInteritemSpacing = ITVideoCellInteritemSpacing;
    layout.itemSize = [ITBookCell itemSize];
    layout.sectionInset = UIEdgeInsetsMake(ITVideoCellEdge, ITVideoCellEdge, ITVideoCellEdge, ITVideoCellEdge);
    return layout;
}

+ (CGFloat)itemWidth {
    return ([UIScreen mainScreen].bounds.size.width - 2 * ITVideoCellEdge - ITVideoCellInteritemSpacing) / 2.0;
}

+ (CGSize)itemSize {
    CGFloat width = [ITBookCell itemWidth];
    CGFloat height = width / ITVideoCellRatio + 30;
    return CGSizeMake(width, height);
}

@end
