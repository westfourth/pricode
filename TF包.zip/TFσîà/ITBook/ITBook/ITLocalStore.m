//
//  ITLocalStore.m
//  ITBook
//
//  Created by mac on 2020/3/11.
//  Copyright © 2020 mac. All rights reserved.
//

#import "ITLocalStore.h"

#define IT_LOCAL_STORE_DIR  NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES).firstObject

@implementation ITLocalStore
static NSMutableArray *_models = nil;

+ (void)initialize
{
    if (self == [ITLocalStore class]) {
        [ITLocalStore read];
    }
}

+ (NSMutableArray<ITBookDetailModel *> *)models {
    return _models;
}

//  videoID作为唯一值
+ (void)add:(ITBookDetailModel *)model {
    ITBookDetailModel *find = nil;
    for (ITBookDetailModel *m in _models) {
        if ([m.isbn13 isEqualToString:model.isbn13]) {
            find = m;
            break;
        }
    }
    if (find == nil) {
        [_models addObject:model];
    }
}

+ (void)remove:(ITBookDetailModel *)model {
    ITBookDetailModel *find = nil;
    for (ITBookDetailModel *m in _models) {
        if ([m.isbn13 isEqualToString:model.isbn13]) {
            find = m;
            break;
        }
    }
    [_models removeObject:find];
}

+ (BOOL)has:(ITBookDetailModel *)model {
    ITBookDetailModel *find = nil;
    for (ITBookDetailModel *m in _models) {
        if ([m.isbn13 isEqualToString:model.isbn13]) {
            find = m;
            break;
        }
    }
    return find == nil ? NO : YES;
}

+ (BOOL)hasISBN:(NSString *)isbn13 {
    ITBookDetailModel *find = nil;
    for (ITBookDetailModel *m in _models) {
        if ([m.isbn13 isEqualToString:isbn13]) {
            find = m;
            break;
        }
    }
    return find == nil ? NO : YES;
}

+ (void)read {
    NSString *path = [IT_LOCAL_STORE_DIR stringByAppendingPathComponent:@"book_collect"];
    NSData *data = [NSData dataWithContentsOfFile:path];
    NSArray<ITBookDetailModel *> *models = [NSKeyedUnarchiver unarchiveObjectWithData:data];
    _models = [NSMutableArray arrayWithArray:models];
}

+ (void)save {
    NSData *data = [NSKeyedArchiver archivedDataWithRootObject:_models];
    NSString *path = [IT_LOCAL_STORE_DIR stringByAppendingPathComponent:@"book_collect"];
    [data writeToFile:path atomically:YES];
}

@end
