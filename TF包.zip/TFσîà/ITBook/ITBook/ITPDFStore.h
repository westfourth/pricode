//
//  ITPDFStore.h
//  ITBook
//
//  Created by mac on 2020/3/12.
//  Copyright © 2020 mac. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface ITPDFStore : NSObject

+ (void)get:(NSURL *)url completion:(void (^)(NSError *error, NSData *data))completion;

@end

NS_ASSUME_NONNULL_END
