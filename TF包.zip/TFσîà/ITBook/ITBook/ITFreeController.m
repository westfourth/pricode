//
//  ITFreeController.m
//  ITBook
//
//  Created by mac on 2020/3/11.
//  Copyright © 2020 mac. All rights reserved.
//

#import "ITFreeController.h"
#import "ITBookCell.h"
#import <XSVendor/UIScrollView+XSRefresh.h>
#import "ITBookInfoController.h"

@interface ITFreeController () <UICollectionViewDataSource, UICollectionViewDelegate, UIScrollViewDelegate> {
    UICollectionView *_collectionView;
    NSMutableArray<ITBookFreeModel *> *_models;
    NSUInteger _page;
    BOOL _isRequesting;     //  是否在请求数据
}

@end

@implementation ITFreeController

- (void)viewDidLoad {
    [super viewDidLoad];
    _models = [NSMutableArray new];
    _page = 1;
    [self setupCollectionView];
    [self loadData];
    __weak typeof (self) weak_self = self;
    _collectionView.loadMoreBlock = ^{
        [weak_self loadData];
    };
}

- (void)viewDidLayoutSubviews {
    [super viewDidLayoutSubviews];
    _collectionView.frame = self.view.bounds;
}

- (void)loadData {
    if (_isRequesting) {
        return;
    }
    _isRequesting = YES;
    [ITBookFreeModel request:_page completion:^(NSError * _Nonnull error, NSMutableArray<ITBookFreeModel *> * _Nonnull models) {
        _isRequesting = NO;
        _page++;
        if (error) {
            return;
        }
        [_models addObjectsFromArray:models];
        [_collectionView reloadData];
    }];
}

- (void)setupCollectionView {
    UICollectionViewFlowLayout *layout = [ITBookCell flowLayout];
    _collectionView = [[UICollectionView alloc] initWithFrame:CGRectZero collectionViewLayout:layout];
    [self.view addSubview:_collectionView];
    _collectionView.dataSource = self;
    _collectionView.delegate = self;
    
    [_collectionView registerClass:[ITBookCell class] forCellWithReuseIdentifier:@"ID"];
    _collectionView.backgroundColor = [UIColor whiteColor];
}

//_______________________________________________________________________________________________________________
// MARK: -

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return _models.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    ITBookFreeModel *model = _models[indexPath.row];
    ITBookCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"ID" forIndexPath:indexPath];
    cell.model = model;
    return cell;
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    ITBookFreeModel *model = _models[indexPath.row];
    ITBookInfoController *vc = [ITBookInfoController new];
    vc.imageURL = model.image;
    vc.isbn13 = model.isbn13;
    vc.title = model.title;
    [self.navigationController pushViewController:vc animated:YES];
}

@end
