//
//  ITPDFStore.m
//  ITBook
//
//  Created by mac on 2020/3/12.
//  Copyright © 2020 mac. All rights reserved.
//

#import "ITPDFStore.h"

@implementation ITPDFStore

+ (void)get:(NSURL *)url completion:(void (^)(NSError *error, NSData *data))completion {
    NSData *data = [self read:url];
    if (data) {
        NSLog(@">>> 缓存: %@", url);
        if (completion) completion(nil, data);
        return;
    }
    dispatch_async(dispatch_get_main_queue(), ^{
        NSError *error = nil;
        NSLog(@">>> 请求: %@", url);
        NSData *data = [NSData dataWithContentsOfURL:url options:0 error:&error];
        NSLog(@">>> 响应: %@", url);
        if (error) {
            if (completion) completion(error, nil);
            return;
        }
        [self save:url data:data];
        if (completion) completion(nil, data);
    });
}

+ (nullable NSData *)read:(NSURL *)url {
    NSString *path = [self path:url];
    NSData *data = [NSData dataWithContentsOfFile:path];
    return data;
}

+ (void)save:(NSURL *)url data:(NSData *)data {
    NSString *path = [self path:url];
    [data writeToFile:path atomically:YES];
}

+ (NSString *)path:(NSURL *)url {
    NSString *docPath = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES).firstObject;
    NSString *fileName = url.lastPathComponent;
    NSString *path = [docPath stringByAppendingPathComponent:fileName];
    return path;
}

@end
