//
//  ITCollectController.m
//  ITBook
//
//  Created by mac on 2020/3/11.
//  Copyright © 2020 mac. All rights reserved.
//

#import "ITCollectController.h"
#import "ITBookCell.h"
#import "ITBookInfoController.h"
#import "ITLocalStore.h"

@interface ITCollectController () <UICollectionViewDataSource, UICollectionViewDelegate> {
    UICollectionView *_collectionView;
    NSMutableArray<ITBookDetailModel *> *_models;
}

@end

@implementation ITCollectController

- (void)viewDidLoad {
    [super viewDidLoad];
    _models = [NSMutableArray new];
    [self setupCollectionView];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [self loadData];
}

- (void)viewDidLayoutSubviews {
    [super viewDidLayoutSubviews];
    _collectionView.frame = self.view.bounds;
}

- (void)loadData {
    _models = [ITLocalStore models];
    [_collectionView reloadData];
}

- (void)setupCollectionView {
    UICollectionViewFlowLayout *layout = [ITBookCell flowLayout];
    _collectionView = [[UICollectionView alloc] initWithFrame:CGRectZero collectionViewLayout:layout];
    [self.view addSubview:_collectionView];
    _collectionView.dataSource = self;
    _collectionView.delegate = self;
    
    [_collectionView registerClass:[ITBookCell class] forCellWithReuseIdentifier:@"ID"];
    _collectionView.backgroundColor = [UIColor whiteColor];
}

//_______________________________________________________________________________________________________________
// MARK: -

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return _models.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    ITBookDetailModel *model = _models[indexPath.row];
    ITBookCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"ID" forIndexPath:indexPath];
    cell.model = model;
    return cell;
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    ITBookDetailModel *model = _models[indexPath.row];
    ITBookInfoController *vc = [ITBookInfoController new];
    vc.imageURL = model.image;
    vc.isbn13 = model.isbn13;
    vc.title = model.title;
    [self.navigationController pushViewController:vc animated:YES];
}


@end
