//
//  ITNetworkTests.m
//  ITNetworkTests
//
//  Created by mac on 2020/3/10.
//  Copyright © 2020 mac. All rights reserved.
//

#import <XCTest/XCTest.h>
#import "ITRequest.h"
#import "ITBookModel.h"
#import "ITBookDetailModel.h"

@interface ITNetworkTests : XCTestCase

@end

@implementation ITNetworkTests

- (void)setUp {
    // Put setup code here. This method is called before the invocation of each test method in the class.
}

- (void)tearDown {
    // Put teardown code here. This method is called after the invocation of each test method in the class.
}

- (void)testRequest {
    NSURL *url = [NSURL URLWithString:@"https://api.itbook.store/1.0/new"];
    NSMutableURLRequest *req = [NSMutableURLRequest requestWithURL:url];
    
    XCTestExpectation *e = [[XCTestExpectation alloc] initWithDescription:@"testRequest"];
    [[ITRequest share] request:req completion:^(NSError * _Nonnull error, NSData * _Nonnull data) {
        [e fulfill];
    }];
    [self waitForExpectations:@[e] timeout:5];
}

- (void)testLatest {
    XCTestExpectation *e = [[XCTestExpectation alloc] initWithDescription:@"testRequest"];
    [ITBookModel getLatest:^(NSError * _Nonnull error, NSArray<ITBookModel *> * _Nonnull models) {
        [e fulfill];
    }];
    [self waitForExpectations:@[e] timeout:5];
}

- (void)testSearch {
    XCTestExpectation *e = [[XCTestExpectation alloc] initWithDescription:@"testRequest"];
    [ITBookModel search:@".NET Framework" page:1 completion:^(NSError * _Nonnull error, NSArray<ITBookModel *> * _Nonnull models) {
        [e fulfill];
    }];
    [self waitForExpectations:@[e] timeout:5];
}

- (void)testBookDetail {
    XCTestExpectation *e = [[XCTestExpectation alloc] initWithDescription:@"testRequest"];
    [ITBookDetailModel getBookDetailByIsbn13:@"9781617294136" completion:^(NSError * _Nonnull error, ITBookDetailModel * _Nonnull model) {
        [e fulfill];
    }];
    [self waitForExpectations:@[e] timeout:5];
}

- (void)testPerformanceExample {
    // This is an example of a performance test case.
    [self measureBlock:^{
        // Put the code you want to measure the time of here.
    }];
}

@end
