//
//  ITDocTests.m
//  ITNetworkTests
//
//  Created by mac on 2020/3/10.
//  Copyright © 2020 mac. All rights reserved.
//

#import <XCTest/XCTest.h>
#import "ITRequest.h"
#import "ITBookHotModel.h"
#import "ITBookFreeModel.h"
#import "ITBookCategoryModel.h"

@interface ITDocTests : XCTestCase

@end

@implementation ITDocTests

- (void)setUp {
    // Put setup code here. This method is called before the invocation of each test method in the class.
}

- (void)tearDown {
    // Put teardown code here. This method is called after the invocation of each test method in the class.
}

- (void)testRequest {
    NSURL *url = [NSURL URLWithString:@"https://api.itbook.store/1.0/new"];
    NSMutableURLRequest *req = [NSMutableURLRequest requestWithURL:url];
    
    XCTestExpectation *e = [[XCTestExpectation alloc] initWithDescription:@"testRequest"];
    [[ITRequest share] request:@"" docCompletion:^(NSError * _Nonnull error, TFHpple * _Nonnull doc) {
        [e fulfill];
    }];
    [self waitForExpectations:@[e] timeout:5];
}

- (void)testITBookHotModel {
    XCTestExpectation *e = [[XCTestExpectation alloc] initWithDescription:@"testRequest"];
    [ITBookHotModel requestWithCompletion:^(NSError * _Nonnull error, NSMutableArray<ITBookHotModel *> * _Nonnull models) {
        [e fulfill];
    }];
    [self waitForExpectations:@[e] timeout:5];
}

- (void)testITBookFreeModel {
    XCTestExpectation *e = [[XCTestExpectation alloc] initWithDescription:@"testRequest"];
    [ITBookFreeModel request:1 completion:^(NSError * _Nonnull error, NSMutableArray<ITBookFreeModel *> * _Nonnull models) {
        [e fulfill];
    }];
    [self waitForExpectations:@[e] timeout:5];
}

- (void)testITBookCategoryModel {
    XCTestExpectation *e = [[XCTestExpectation alloc] initWithDescription:@"testRequest"];
    [ITBookCategoryModel requestWithCompletion:^(NSError * _Nonnull error, NSMutableArray<ITBookCategoryModel *> * _Nonnull models) {
        [e fulfill];
    }];
    [self waitForExpectations:@[e] timeout:5];
}

- (void)testPerformanceExample {
    // This is an example of a performance test case.
    [self measureBlock:^{
        // Put the code you want to measure the time of here.
    }];
}

@end
