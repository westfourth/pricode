//
//  ITBookHotModel.m
//  ITNetwork
//
//  Created by mac on 2020/3/10.
//  Copyright © 2020 mac. All rights reserved.
//

#import "ITBookHotModel.h"
#import "ITRequest.h"

@implementation ITBookHotModel

/// 获取最受欢迎的书
+ (void)requestWithCompletion:(void (^)(NSError *error, NSMutableArray<ITBookHotModel *> *models))completion {
    NSString *urlPath = @"";
    [[ITRequest share] request:urlPath docCompletion:^(NSError * _Nonnull error, TFHpple * _Nonnull doc) {
        if (error) {
            if (completion) completion(error, nil);
            return;
        }
        NSMutableArray<ITBookHotModel *> *models = [ITBookHotModel convertToModels:doc];
        if (completion) completion(nil, models);
    }];
}

/// 转换html数据
+ (NSMutableArray<ITBookHotModel *> *)convertToModels:(TFHpple *)doc {
    NSArray<TFHppleElement *> *elements = [doc searchWithXPathQuery:@"//a[@class='bb-title'][../../div[@class='bt']]"];
    
    NSMutableArray<ITBookHotModel *> *models = [NSMutableArray new];
    for (int i = 0; i < elements.count; i++) {
        ITBookHotModel *model = [ITBookHotModel new];
        [model convert:elements[i]];
        [models addObject:model];
    }
    return models;
}

/// 转换category、url
- (void)convert:(TFHppleElement *)element {
    self.title = [element objectForKey:@"title"];
    self.isbn13 = [[element objectForKey:@"href"] stringByReplacingOccurrencesOfString:@"/books/" withString:@""];
    NSString *imageURLPath = [element.firstChild objectForKey:@"data-src"];
    self.image = [NSURL URLWithString:[NSString stringWithFormat:@"%@%@", ITDomain, imageURLPath]];
}

@end
