//
//  ITRequest.m
//  ITNetwork
//
//  Created by mac on 2020/3/10.
//  Copyright © 2020 mac. All rights reserved.
//

#import "ITRequest.h"
#import "ITURLCache.h"

NSString* const ITDomain = @"https://itbook.store";

@implementation ITRequest

+ (instancetype)share {
    static id instance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [[self class] new];
    });
    return instance;
}

- (void)request:(NSURLRequest *)requst completion:(void (^)(NSError *error, NSData *data))completion {
    //  取缓存
    NSData *data = [ITURLCache dataForRequest:requst];
    if (data) {
        NSLog(@">>> 缓存: %@", requst.URL);
        if (completion) completion(nil, data);
        return;
    }
    
    NSLog(@">>> 请求: %@", requst.URL);
    NSURLSessionDataTask *task = [[NSURLSession sharedSession] dataTaskWithRequest:requst completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
        NSLog(@">>> 响应 %ld: %@", ((NSHTTPURLResponse *)response).statusCode, response.URL);
        dispatch_async(dispatch_get_main_queue(), ^{
            if (error) {
                if (completion) completion(error, nil);
                return;
            }
            //
            NSHTTPURLResponse *res = (NSHTTPURLResponse *)response;
            if (res.statusCode != 200) {
                NSString *des = [NSHTTPURLResponse localizedStringForStatusCode:res.statusCode];
                NSError *err = [NSError errorWithDomain:@"com.ITRequest" code:res.statusCode userInfo:@{NSLocalizedDescriptionKey: des}];
                if (completion) completion(err, nil);
                return;
            }
            
            //  存缓存
            [ITURLCache storeCachedResponse:response data:data forRequest:requst];
            //
            if (completion) completion(nil, data);
        });
    }];
    [task resume];
}

/// 回调Dict
- (void)request:(NSString *)urlString dictCompletion:(void (^)(NSError *error, NSDictionary *dict))completion {
    NSURL *url = [NSURL URLWithString:urlString];
    NSURLRequest *req = [NSURLRequest requestWithURL:url];
    [self request:req completion:^(NSError * _Nonnull error, NSData * _Nonnull data) {
        if (error) {
            if (completion) completion(error, nil);
            return;
        }
        NSError *jsonError = nil;
        NSDictionary *dict = [NSJSONSerialization JSONObjectWithData:data options:0 error:&jsonError];
        if (jsonError) {
            if (completion) completion(jsonError, nil);
            return;
        }
        int errorCode = [dict[@"error"] intValue];
        if (errorCode) {
            NSString *des = dict[@"error"];
            NSError *err = [NSError errorWithDomain:@"com.ITURLCache" code:errorCode userInfo:@{NSLocalizedDescriptionKey: des}];
            if (completion) completion(err, nil);
            return;
        }
        if (completion) completion(nil, dict);
    }];
}

/// 回调Doc
- (void)request:(NSString *)urlPath docCompletion:(void (^)(NSError *error, TFHpple *doc))completion {
    NSString *urlString = [NSString stringWithFormat:@"%@%@", ITDomain, urlPath];
    NSURL *url = [NSURL URLWithString:urlString];
    NSURLRequest *req = [NSURLRequest requestWithURL:url];
    [self request:req completion:^(NSError * _Nonnull error, NSData * _Nonnull data) {
        if (error) {
            if (completion) completion(error, nil);
            return;
        }
        TFHpple *doc = [TFHpple hppleWithHTMLData:data];
        if (completion) completion(nil, doc);
    }];
}

@end
