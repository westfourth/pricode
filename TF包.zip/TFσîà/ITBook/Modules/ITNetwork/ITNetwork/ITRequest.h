//
//  ITRequest.h
//  ITNetwork
//
//  Created by mac on 2020/3/10.
//  Copyright © 2020 mac. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <hpple/TFHpple.h>

NS_ASSUME_NONNULL_BEGIN

extern NSString* const ITDomain;

@interface ITRequest : NSObject

+ (instancetype)share;

/// 回调Data
- (void)request:(NSURLRequest *)requst completion:(void (^)(NSError *error, NSData *data))completion;

/// 回调Dict
- (void)request:(NSString *)urlString dictCompletion:(void (^)(NSError *error, NSDictionary *dict))completion;

/**
    回调Doc
 
    @param  urlPath             例如：/books/free
    @param  completion      出错时，error != nil
 */
- (void)request:(NSString *)urlPath docCompletion:(void (^)(NSError *error, TFHpple *doc))completion;

@end

NS_ASSUME_NONNULL_END
