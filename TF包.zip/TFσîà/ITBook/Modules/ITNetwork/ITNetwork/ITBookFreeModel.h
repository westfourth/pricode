//
//  ITBookFreeModel.h
//  ITNetwork
//
//  Created by mac on 2020/3/11.
//  Copyright © 2020 mac. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <hpple/TFHpple.h>

NS_ASSUME_NONNULL_BEGIN

//  免费书籍
@interface ITBookFreeModel : NSObject

@property (nonatomic) NSString *title;
@property (nonatomic) NSString *isbn13;
@property (nonatomic) NSURL *image;
@property (nonatomic) NSString *desc;

/// 获取最受欢迎的书。page>=1
+ (void)request:(NSUInteger)page completion:(void (^)(NSError *error, NSMutableArray<ITBookFreeModel *> *models))completion;

/// 转换html数据
+ (NSMutableArray<ITBookFreeModel *> *)convertToModels:(TFHpple *)doc;

/// 转换
- (void)convert:(TFHppleElement *)element;

@end

NS_ASSUME_NONNULL_END
