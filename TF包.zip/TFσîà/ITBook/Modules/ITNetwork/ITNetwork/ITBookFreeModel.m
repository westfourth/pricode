//
//  ITBookFreeModel.m
//  ITNetwork
//
//  Created by mac on 2020/3/11.
//  Copyright © 2020 mac. All rights reserved.
//

#import "ITBookFreeModel.h"
#import "ITRequest.h"

@implementation ITBookFreeModel

/// 获取最受欢迎的书。page>=1
+ (void)request:(NSUInteger)page completion:(void (^)(NSError *error, NSMutableArray<ITBookFreeModel *> *models))completion {
    NSString *urlPath = [NSString stringWithFormat:@"/books/free?page=%ld", page];
    [[ITRequest share] request:urlPath docCompletion:^(NSError * _Nonnull error, TFHpple * _Nonnull doc) {
        if (error) {
            if (completion) completion(error, nil);
            return;
        }
        NSMutableArray<ITBookFreeModel *> *models = [ITBookFreeModel convertToModels:doc];
        if (completion) completion(nil, models);
    }];
}

/// 转换html数据
+ (NSMutableArray<ITBookFreeModel *> *)convertToModels:(TFHpple *)doc {
    NSArray<TFHppleElement *> *elements = [doc searchWithXPathQuery:@"//div[@class='col-md-6 mb10']"];
    
    NSMutableArray<ITBookFreeModel *> *models = [NSMutableArray new];
    for (int i = 0; i < elements.count; i++) {
        ITBookFreeModel *model = [ITBookFreeModel new];
        [model convert:elements[i]];
        [models addObject:model];
    }
    return models;
}

/// 转换
- (void)convert:(TFHppleElement *)element {
    NSData *data = [element.raw dataUsingEncoding:NSUTF8StringEncoding];
    TFHpple *doc = [TFHpple hppleWithXMLData:data];
    
    NSArray<TFHppleElement *> *elements = [doc searchWithXPathQuery:@"/div/div/div/a"];
    TFHppleElement *e = elements.firstObject;
    
    self.title = [e objectForKey:@"title"];
    self.isbn13 = [[e objectForKey:@"href"] stringByReplacingOccurrencesOfString:@"/books/" withString:@""];
    NSString *imageURLPath = [e.firstChild objectForKey:@"src"];
    self.image = [NSURL URLWithString:[NSString stringWithFormat:@"%@%@", ITDomain, imageURLPath]];
    
    elements = [doc searchWithXPathQuery:@"/div/div/div[@class='col-md-8 justify']"];
    e = elements.firstObject.children.lastObject;
    self.desc = e.content;
}

@end
