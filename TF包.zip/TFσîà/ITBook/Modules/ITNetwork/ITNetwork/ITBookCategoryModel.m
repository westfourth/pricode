//
//  ITBookCategoryModel.m
//  ITNetwork
//
//  Created by mac on 2020/3/11.
//  Copyright © 2020 mac. All rights reserved.
//

#import "ITBookCategoryModel.h"
#import "ITRequest.h"

@implementation ITBookCategoryModel

//  获取
+ (void)requestWithCompletion:(void (^)(NSError *error, NSMutableArray<ITBookCategoryModel *> *models))completion {
    NSString *urlPath = @"/books";
    [[ITRequest share] request:urlPath docCompletion:^(NSError * _Nonnull error, TFHpple * _Nonnull doc) {
        if (error) {
            if (completion) completion(error, nil);
            return;
        }
        NSMutableArray<ITBookCategoryModel *> *models = [ITBookCategoryModel convertToModels:doc];
        if (completion) completion(nil, models);
    }];
}

/// 转换html数据
+ (NSMutableArray<ITBookCategoryModel *> *)convertToModels:(TFHpple *)doc {
    NSArray<TFHppleElement *> *elements = [doc searchWithXPathQuery:@"//h4[@class='par']"];
    
    NSMutableArray<ITBookCategoryModel *> *models = [NSMutableArray new];
    for (int i = 0; i < elements.count; i++) {
        ITBookCategoryModel *model = [ITBookCategoryModel new];
        [model convert:elements[i]];
        
        //  查找该分类下的item
        model.lists = [NSMutableArray new];
        NSString *query = [NSString stringWithFormat:@"//div[@class='col-md-3'][preceding-sibling::h4[@class='par'][1]/span[text()='%@']]", model.name];
        NSArray<TFHppleElement *> *itemElements = [doc searchWithXPathQuery:query];
        for (int i = 0; i < itemElements.count; i++) {
            ITBookCategoryItemModel *itemModel = [ITBookCategoryItemModel new];
            [itemModel convert:itemElements[i]];
            [model.lists addObject:itemModel];
        }
        
        [models addObject:model];
    }
    return models;
}

/// 转换
- (void)convert:(TFHppleElement *)element {
    self.name = element.firstChild.firstChild.content;
}

@end



//_______________________________________________________________________________________________________________
// MARK: -  ITBookCategoryItemModel

@implementation ITBookCategoryItemModel

/// 转换
- (void)convert:(TFHppleElement *)element {
    self.title = element.firstChild.firstChild.content;
    NSString *href = [element.firstChild objectForKey:@"href"];
    self.url = [NSURL URLWithString:[NSString stringWithFormat:@"%@%@", ITDomain, href]];
}

@end
