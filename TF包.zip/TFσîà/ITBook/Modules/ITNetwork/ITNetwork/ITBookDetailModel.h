//
//  ITBookDetailModel.h
//  ITNetwork
//
//  Created by mac on 2020/3/10.
//  Copyright © 2020 mac. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <Mantle/Mantle.h>

NS_ASSUME_NONNULL_BEGIN

@interface ITBookDetailModel : MTLModel <MTLJSONSerializing>

@property (nonatomic) NSString *title;
@property (nonatomic) NSString *subtitle;
@property (nonatomic) NSString *authors;
@property (nonatomic) NSString *publisher;

@property (nonatomic) NSString *language;
@property (nonatomic) NSString *isbn10;
@property (nonatomic) NSString *isbn13;
@property (nonatomic) NSUInteger pages;

@property (nonatomic) NSUInteger year;
@property (nonatomic) float rating;
@property (nonatomic) NSString *desc;
@property (nonatomic) NSString *price;

@property (nonatomic) NSURL *image;
@property (nonatomic) NSURL *url;               //  详情
@property (nonatomic) NSDictionary *pdf;        //  样本


+ (void)getBookDetailByIsbn13:(NSString *)isbn13 completion:(void (^)(NSError *error, ITBookDetailModel *model))completion;

@end

NS_ASSUME_NONNULL_END
