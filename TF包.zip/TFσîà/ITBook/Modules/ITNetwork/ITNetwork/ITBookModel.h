//
//  ITBookModel.h
//  ITNetwork
//
//  Created by mac on 2020/3/10.
//  Copyright © 2020 mac. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <Mantle/Mantle.h>

NS_ASSUME_NONNULL_BEGIN

@interface ITBookModel : MTLModel <MTLJSONSerializing>

@property (nonatomic) NSString *title;
@property (nonatomic) NSString *subtitle;
@property (nonatomic) NSString *isbn13;
@property (nonatomic) NSString *price;

@property (nonatomic) NSURL *image;
@property (nonatomic) NSURL *url;               //  详情


/// 获取最新书籍
+ (void)getLatest:(void (^)(NSError *error, NSArray<ITBookModel *> *models))completion;

/**
    搜索
    
    @param  query           关键字
    @param  page            页码>=1
 */
+ (void)search:(NSString *)query page:(NSUInteger)page completion:(void (^)(NSError *error, NSArray<ITBookModel *> *models))completion;

@end

NS_ASSUME_NONNULL_END
