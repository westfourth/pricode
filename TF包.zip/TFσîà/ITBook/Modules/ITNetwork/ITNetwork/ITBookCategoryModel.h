//
//  ITBookCategoryModel.h
//  ITNetwork
//
//  Created by mac on 2020/3/11.
//  Copyright © 2020 mac. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <hpple/TFHpple.h>
@class ITBookCategoryItemModel;

NS_ASSUME_NONNULL_BEGIN

/// 分类
@interface ITBookCategoryModel : NSObject

@property (nonatomic) NSString *name;
@property (nonatomic) NSMutableArray<ITBookCategoryItemModel *> *lists;

//  获取
+ (void)requestWithCompletion:(void (^)(NSError *error, NSMutableArray<ITBookCategoryModel *> *models))completion;

/// 转换html数据
+ (NSMutableArray<ITBookCategoryModel *> *)convertToModels:(TFHpple *)doc;

/// 转换
- (void)convert:(TFHppleElement *)element;

@end



//_______________________________________________________________________________________________________________
// MARK: -  ITBookCategoryItemModel

/// 分类item
@interface ITBookCategoryItemModel : NSObject

@property (nonatomic) NSString *title;
@property (nonatomic) NSURL *url;

/// 转换
- (void)convert:(TFHppleElement *)element;

@end

NS_ASSUME_NONNULL_END
