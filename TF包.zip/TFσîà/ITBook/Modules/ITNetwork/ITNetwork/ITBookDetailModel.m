//
//  ITBookDetailModel.m
//  ITNetwork
//
//  Created by mac on 2020/3/10.
//  Copyright © 2020 mac. All rights reserved.
//

#import "ITBookDetailModel.h"
#import "ITRequest.h"

@implementation ITBookDetailModel

+ (NSDictionary *)JSONKeyPathsByPropertyKey {
    return @{
        @"title": @"title",
        @"subtitle": @"subtitle",
        @"authors": @"authors",
        @"publisher": @"publisher",
        
        @"language": @"language",
        @"isbn10": @"isbn10",
        @"isbn13": @"isbn13",
        @"pages": @"pages",
        
        @"year": @"year",
        @"rating": @"rating",
        @"desc": @"desc",
        @"price": @"price",
        
        @"image": @"image",
        @"url": @"url",
        @"pdf": @"pdf",
    };
}

+ (NSValueTransformer *)pagesJSONTransformer {
    return [MTLValueTransformer transformerUsingForwardBlock:^id(NSString *value, BOOL *success, NSError *__autoreleasing *error) {
        return @([value integerValue]);
    }];
}

+ (NSValueTransformer *)yearJSONTransformer {
    return [MTLValueTransformer transformerUsingForwardBlock:^id(NSString *value, BOOL *success, NSError *__autoreleasing *error) {
        return @([value integerValue]);
    }];
}

+ (NSValueTransformer *)ratingJSONTransformer {
    return [MTLValueTransformer transformerUsingForwardBlock:^id(NSString *value, BOOL *success, NSError *__autoreleasing *error) {
        return @([value floatValue]);
    }];
}

+ (void)getBookDetailByIsbn13:(NSString *)isbn13 completion:(void (^)(NSError *error, ITBookDetailModel *model))completion {
    NSString *urlString = [NSString stringWithFormat:@"https://api.itbook.store/1.0/books/%@", isbn13];
    [[ITRequest share] request:urlString dictCompletion:^(NSError * _Nonnull error, NSDictionary * _Nonnull dict) {
        if (error) {
            if (completion) completion(error, nil);
            return;
        }
        NSError *err = nil;
        ITBookDetailModel *model = [MTLJSONAdapter modelOfClass:[ITBookDetailModel class] fromJSONDictionary:dict error:&err];
        if (err) {
            if (completion) completion(err, nil);
            return;
        }
        if (completion) completion(nil, model);
    }];
}

@end
