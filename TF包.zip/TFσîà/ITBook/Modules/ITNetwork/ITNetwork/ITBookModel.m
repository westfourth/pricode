//
//  ITBookModel.m
//  ITNetwork
//
//  Created by mac on 2020/3/10.
//  Copyright © 2020 mac. All rights reserved.
//

#import "ITBookModel.h"
#import "ITRequest.h"

@implementation ITBookModel

+ (NSDictionary *)JSONKeyPathsByPropertyKey {
    return @{
        @"title": @"title",
        @"subtitle": @"subtitle",
        @"isbn13": @"isbn13",
        @"price": @"price",
        @"image": @"image",
        @"url": @"url",
    };
}

/// 获取最新书籍
+ (void)getLatest:(void (^)(NSError *error, NSArray<ITBookModel *> *models))completion {
    NSString *urlString = @"https://api.itbook.store/1.0/new";
    [[ITRequest share] request:urlString dictCompletion:^(NSError * _Nonnull error, NSDictionary * _Nonnull dict) {
        if (error) {
            if (completion) completion(error, nil);
            return;
        }
        NSError *err = nil;
        NSArray *models = [MTLJSONAdapter modelsOfClass:[ITBookModel class] fromJSONArray:dict[@"books"] error:&err];
        if (err) {
            if (completion) completion(err, nil);
            return;
        }
        if (completion) completion(nil, models);
    }];
}

/// 搜索
+ (void)search:(NSString *)query page:(NSUInteger)page completion:(void (^)(NSError *error, NSArray<ITBookModel *> *models))completion {
    NSString *urlString = [NSString stringWithFormat:@"https://api.itbook.store/1.0/search/%@/%ld", query, page];
    urlString = [urlString stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLQueryAllowedCharacterSet]];
    [[ITRequest share] request:urlString dictCompletion:^(NSError * _Nonnull error, NSDictionary * _Nonnull dict) {
        if (error) {
            if (completion) completion(error, nil);
            return;
        }
        NSError *err = nil;
        NSArray *models = [MTLJSONAdapter modelsOfClass:[ITBookModel class] fromJSONArray:dict[@"books"] error:&err];
        if (err) {
            if (completion) completion(err, nil);
            return;
        }
        if (completion) completion(nil, models);
    }];
}

@end
