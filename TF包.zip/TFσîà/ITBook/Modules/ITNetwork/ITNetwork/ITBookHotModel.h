//
//  ITBookHotModel.h
//  ITNetwork
//
//  Created by mac on 2020/3/10.
//  Copyright © 2020 mac. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <hpple/TFHpple.h>

NS_ASSUME_NONNULL_BEGIN

/// 最受欢迎的书
@interface ITBookHotModel : NSObject

@property (nonatomic) NSString *isbn13;
@property (nonatomic) NSString *title;
@property (nonatomic) NSURL *image;          //  封面

/// 获取最受欢迎的书
+ (void)requestWithCompletion:(void (^)(NSError *error, NSMutableArray<ITBookHotModel *> *models))completion;

/// 转换html数据
+ (NSMutableArray<ITBookHotModel *> *)convertToModels:(TFHpple *)doc;

/// 转换
- (void)convert:(TFHppleElement *)element;

@end

NS_ASSUME_NONNULL_END
