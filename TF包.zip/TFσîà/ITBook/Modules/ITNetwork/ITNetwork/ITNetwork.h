//
//  ITNetwork.h
//  ITNetwork
//
//  Created by mac on 2020/3/10.
//  Copyright © 2020 mac. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for ITNetwork.
FOUNDATION_EXPORT double ITNetworkVersionNumber;

//! Project version string for ITNetwork.
FOUNDATION_EXPORT const unsigned char ITNetworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ITNetwork/PublicHeader.h>

#import <ITNetwork/ITRequest.h>
#import <ITNetwork/ITBookModel.h>
#import <ITNetwork/ITBookDetailModel.h>
#import <ITNetwork/ITBookHotModel.h>

#import <ITNetwork/ITBookFreeModel.h>
#import <ITNetwork/ITBookCategoryModel.h>
