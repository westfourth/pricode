## 1. 没有声明变量却可以直接使用 ？？

```swift
var s: String = "abcde"
for index in s.indices {
    print(s[index])
}
```

## 2. String 与 Any 互转 ？？

```swift
@dynamicMemberLookup
struct People {
    var name: String = "ABC"
    var age: Int = 123
    private var map = ["name": "drbox", "job": "developer"]
    
    subscript(dynamicMember key: String) -> KeyPath<Self, Any> {
        return Self.name as KeyPath<Self, Any>
    }
}
```
