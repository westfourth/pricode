# Extension

## Extension

- `Extension` 可以向`class`中添加 便利初始化，但不能添加 指定初始化。

