# Generic

## 范型

```swift
struct Stack<Element> {
    var items: [Element] = []
    mutating func push(_ item: Element) {
        items.append(item)
    }
    mutating func pop() -> Element {
        return items.removeLast()
    }
}
```

## 范型扩展

`extension` 可直接使用已定义的范型类型。

```swift
extension Stack {
    var topItem: Element? {
        return items.isEmpty ? nil : items[items.count - 1]
    }
}
```

## 类型限制

可将范型限制为继承某个类，或采用某个协议。

```swift
func someFunction<T: SomeClass, U: SomeProtocol>(someT: T, someU: U) {
    // function body goes here
}
```

`T` 必须为 `SomeClass` 的子类，`U` 必须采用 `SomeProtocol` 协议

```swift
func findIndex<T: Equatable>(of valueToFind: T, in array:[T]) -> Int? {
    for (index, value) in array.enumerated() {
        if value == valueToFind {
            return index
        }
    }
    return nil
}
```

```swift
//  错误：Cannot explicitly specialize a generic function
var index = findIndex<Int>(of: 3, in: [1, 2, 3])
//  正确
var index = findIndex(of: 3, in: [1, 2, 3])
```

## 关联类型

```swift
protocol Container {
    associatedtype Item
    mutating func append(_ item: Item)
    var count: Int { get }
    subscript(i: Int) -> Item { get }
}
```

```swift
struct IntStack: Container {
    var items: [Int] = []
    
    typealias Item = Int
    mutating func append(_ item: Int) {
        items.append(item)
    }
    var count: Int {
        return items.count
    }
    subscript(i: Int) -> Int {
        return items[i]
    }
}
```

### 关联类型限制

```swift
protocol Container {
    associatedtype Item: Equatable
    mutating func append(_ item: Item)
    var count: Int { get }
    subscript(i: Int) -> Item { get }
}
```

```swift
extension Container {
    func has(_ item: Item) -> Bool {
        for i in 0..<count {
            if self[i] == item {
                return true
            }
        }
        return false
    }
}
```

```swift
protocol SuffixableContainer: Container {
    associatedtype Suffix: SuffixableContainer where Suffix.Item == Item
    func suffix() -> Suffix
}
```

```swift
extension IntStack: SuffixableContainer {
    typealias Suffix = IntStack
    
    func suffix() -> IntStack {
        var s = IntStack()
        if count > 0 {
            let last = self[count - 1]
            s.append(last)
        }
        return s
    }
}
```

>更多参考：[Associated Types](https://docs.swift.org/swift-book/documentation/the-swift-programming-language/generics/#Associated-Types)


## Where

```swift
protocol Container {
    associatedtype Item
    mutating func append(_ item: Item)
    var count: Int { get }
    subscript(i: Int) -> Item { get }
}

func allItemsMatch<C1: Container, C2: Container>
        (_ someContainer: C1, _ anotherContainer: C2) -> Bool
        where C1.Item == C2.Item, C1.Item: Equatable {

    if someContainer.count != anotherContainer.count {
        return false
    }

    for i in 0..<someContainer.count {
        if someContainer[i] != anotherContainer[i] {
            return false
        }
    }

    return true
}
```

解读：

1. C1采用Container协议（`C1: Container`）
1. C2采用Container协议（`C2: Container`）
1. C1的关联类型与C2的关联类型相同（`C1.Item == C2.Item`）
1. C1的关联类型采用Equatable协议（`C1.Item: Equatable`）

## Where扩展

### 采用协议

```swift
extension Container where Item: Equatable {
    func startsWith(_ item: Item) -> Bool {
        return count >= 1 && self[0] == item
    }
}
```

### 指定类型

```swift
extension Container where Item == Double {
    func average() -> Double {
        var sum = 0.0
        for index in 0..<count {
            sum += self[index]
        }
        return sum / Double(count)
    }
}
```

### 上下文

```swift
extension Container  {
    func average() -> Double where Item == Double {
        var sum = 0.0
        for index in 0..<count {
            sum += self[index]
        }
        return sum / Double(count)
    }
    
    func average() -> Double where Item == Int {
        var sum = 0
        for index in 0..<count {
            sum += self[index]
        }
        return Double(sum) / Double(count) + 100
    }
}
```

### 关联类型

```swift
protocol Container {
    associatedtype Item
    mutating func append(_ item: Item)
    var count: Int { get }
    subscript(i: Int) -> Item { get }


    associatedtype Iterator: IteratorProtocol where Iterator.Element == Item
    func makeIterator() -> Iterator
}
```

```swift
protocol ComparableContainer: Container where Item: Comparable { }
```

### 下标

```swift
extension Container {
    subscript<Indices: Sequence>(indices: Indices) -> [Item]
            where Indices.Iterator.Element == Int {
        var result: [Item] = []
        for index in indices {
            result.append(self[index])
        }
        return result
    }
}
```


>更多参考：[Generic Where Clauses](https://docs.swift.org/swift-book/documentation/the-swift-programming-language/generics/#Generic-Where-Clauses)