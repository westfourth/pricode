# Closure

## Syntax

```swift
var names = ["BB", "AA", "CC"]

//  标准
var names1 = names.sorted(by: { (s1: String, s2: String) -> Bool in
    return s1 < s2
})

//  省略类型
var names2 = names.sorted(by: {(s1, s2) in
    return s1 < s2
})

//  省略括号
var names2 = names.sorted(by: { s1, s2 in
    return s1 < s2
})

//  省略return
var names3 = names.sorted(by: { s1, s2 in
    s1 < s2
})

//  速记参数名称
var names4 = names.sorted(by: { $0 < $1 })

//  运算符方法
var names5 = names.sorted(by: <)
```

## 尾随闭包

函数的最后一个参数为闭包时，可写为尾随闭包。第一个尾随闭包的参数名称不能有

```swift
var names6 = names.sorted() { s1, s2 in
    s1 > s2
}
```

当闭包作为函数的唯一参数时，如果写为尾随闭包，函数可省略括号

```swift
var names7 = names.sorted { s1, s2 in
    s1 > s2
}
```

### 多个尾随闭包

多个尾随闭包时，第一个尾随闭包的参数名称不能有，但其他尾随闭包的参数名称必须有

```swift
func operate(a:Int, b: Int,
             add: (Int, Int) -> Int,
             multiply: (Int, Int) -> Int) -> Int {
    return add(a, b) + multiply(a, b)
}

//  标准
var result1 = operate(a: 2, b: 3, add: {x, y in
    x + y
}, multiply: {x, y in
    x * y
})

//  尾随闭包
var result2 = operate(a: 2, b: 3, add: {x, y in
    x + y
}) { x, y in
    x * y
}

//  多个尾随闭包
var result3 = operate(a: 2, b: 3) { x, y in
    x + y
} multiply: { x, y in
    x * y
}
```


## 逃逸闭包

闭包作为函数的参数，但这个闭包在这个函数返回后才被调用。

```swift
var completions: [() -> Void] = []
func someFunctionWithEscapingClosure(completion: @escaping () -> Void) {
    completions.append(completion)
}
```

## 自动闭包

闭包作为函数的参数，且这个闭包只有一个表达式，并且闭包没有参数，但可以有返回值。

```swift
var customersInLine = ["Chris", "Alex", "Ewa", "Barry", "Daniella"]
func serve(customer customerProvider: @autoclosure () -> String) {
    print("Now serving \(customerProvider())!")
}
serve(customer: customersInLine.remove(at: 0))
```
