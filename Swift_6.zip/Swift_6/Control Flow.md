# Control Flow

## 步幅

```swift
//  区间：[from, end)
for i in stride(from: 0, to: 20, by: 5) {
    print(i)                    //  0   5   10  15
}

//  区间：[from, end]
for i in stride(from: 0, through: 20, by: 5) {
    print(i)                    //  0   5   10  15  20
}
```

## if赋值

```swift
enum MyError: Error {
    case anError
}

let temperature = -1

let message1: String? = if temperature <= 0 {
    "It's below freezing. Watch for ice!"
} else {
    nil
}

let message2 = if temperature <= 0 {
    "It's below freezing. Watch for ice!"
} else {
    nil as String?
}

let message3 = if temperature <= 0 {
    throw MyError.anError
} else {
    "It's a reasonable temperature."
}
```

> **注意：if赋值，if-else必须成对出现**

## switch

### switch语法

```swift
let count = 5
let message: String

switch count {
case 0:
    message = "no"
case 1, 2, 3:
    fallthrough
case 4..<10:
    message = "a few"
default:
    message = "many"
}
```

### switch赋值

```swift
let ch: Character = "a"

let message = switch ch {
case "a":
    "The first character"
case "z":
    "The last character"
default:
    "Other character"
}
```

> **注意：switch赋值，不能有fallthrough**

### switch高级语法

```swift
let somePoint = (10, 10)
switch somePoint {
case (0, 0):                                    //  tuple
    print("\(somePoint) is at the origin")
case (_, 0):
    print("\(somePoint) is on the x-axis")
case (-2...2, -2...2):
    print("\(somePoint) is inside the box")
case (0, let y):                                //  value binding
    print("on the y-axis with a y value of \(y)")
case (let x, let y) where x == y:               //  where
    print("(\(x), \(y)) is on the line x == y")
case let (x, y) where x < 100 && y < 100:
    print("< 100")
case let (x, y):
    print("somewhere else at (\(x), \(y))")
}
```