# Collections

## 空初始化

```swift
var array1: Array<Int> = []
var array2 = Array<Int>()
var array3: [Int] = []
var array4 = [Int]()

var set1: Set<Int> = []
var set2 = Set<Int>()

var dict1: Dictionary<Int, String> = [:]
var dict2 = Dictionary<Int, String>()
var dict3: [Int: String] = [:]
var dict4 = [Int: String]()
```

## Array

```swift
var a: Array<Int> = [1, 2, 3]
var b = [7, 8, 9]
var c = a + b               //  [1, 2, 3, 7, 8, 9]

let count = c.count         //  6
let empty = c.isEmpty       //  false
let contain = c.contains(2) //  true

var a0 = c[0]               //  1
c[0] = 11                   //  [11, 2, 3, 7, 8, 9]
c[1...4] = [30, 40]         //  [11, 30, 40, 9]

c.append(10)                //  [11, 30, 40, 9, 10]
c.insert(20, at: 1)         //  [11, 20, 30, 40, 9, 10]
c.remove(at: 0)             //  [20, 30, 40, 9, 10]
c.removeLast()              //  [20, 30, 40, 9]

// c[c.count] = 100            //  Runtime error: Index out of range

//  遍历
for val in c {
    print(val)
}

//  遍历索引、值
for (idx, val) in c.enumerated() {
    print("Index: \(idx), Value: \(val)")
}
```

## Set

```swift
var a: Set<String> = ["A", "B", "C"]

let count = a.count             //  3
let empty = a.isEmpty           //  false
let contain = a.contains("B")   //  true

a.insert("D")                   //  ["B", "D", "C", "A"]
a.remove("A")                   //  ["B", "C", "D"]

//  遍历
for val in a {
    print(val)
}

//  有序遍历
for val in a.sorted() {
    print(val)
}
```

### Set Operations

![](Images/setVennDiagram@2x.png)

```swift
let oddDigits: Set = [1, 3, 5, 7, 9]
let evenDigits: Set = [0, 2, 4, 6, 8]
let singleDigitPrimeNumbers: Set = [2, 3, 5, 7]


oddDigits.union(evenDigits).sorted()
// [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
oddDigits.intersection(evenDigits).sorted()
// []
oddDigits.subtracting(singleDigitPrimeNumbers).sorted()
// [1, 9]
oddDigits.symmetricDifference(singleDigitPrimeNumbers).sorted()
// [1, 2, 9]
```

### Set Membership

![](Images/setEulerDiagram@2x.png)

```swift
a.isSuperset(of: b)             //  true
b.isSubset(of: a)               //  true

a.isStrictSuperset(of: b)       //  true
b.isStrictSubset(of: a)         //  true

b.isDisjoint(with: c)           //  true
```

## Dictionary

```swift
var a: Dictionary<Int, String> = [1: "AA", 2: "BB"]

let count = a.count         //  2
let empty = a.isEmpty       //  false

//  返回旧值
if let oldValue = a.updateValue("BBB", forKey: 2) {
    print(oldValue)         //  BB
}

//  等同于
a[2] = "BBB"               //  区别：不会返回旧值

if let oldValue = a.removeValue(forKey: 1) {
    print(oldValue)
}

//  等同于
a[1] = nil                  //  区别：不会返回旧值

//  遍历
for (key, val) in a {
    print("\(key) : \(val)")
}
```