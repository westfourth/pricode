# Protocol

## 属性要求

```swift
protocol SomeProtocol {
    var mustBeSettable: Int { get set }
    var doesNotNeedToBeSettable: Int { get }
}
```

## 初始化要求

```swift
protocol InitProto {
    init(age: Int)
}

class MediaItem: InitProto {
    var age: Int
    required init(age: Int) {       //  必须有
        self.age = age
    }
}
```

## 范型

```swift
protocol DesProto {
    var textDesc: String { get }
}

class MediaItem: DesProto {
    var textDesc: String {
        return " == "
    }
}

extension Array: DesProto where Element: DesProto {
    var textDesc: String {
        var text = String()
        for item in self {
            text.append(item.textDesc)
        }
        return text
    }
}

let array = [MediaItem(), MediaItem(), MediaItem()]
print(array.textDesc)
// ==  ==  == 
```

## 类专用协议

`AnyObject` 将协议指定为`class`专用，不能被 `structure` 和 `enumeration` 采用

```swift
protocol DesProto: AnyObject {
    var textDesc: String { get }
}
```

## 复合协议

```swift
protocol Named {
    var name: String { get }
}
protocol Aged {
    var age: Int { get }
}
struct Person: Named, Aged {
    var name: String
    var age: Int
}
func wishHappyBirthday(to celebrator: Named & Aged) {
    print("Happy birthday, \(celebrator.name), you're \(celebrator.age)!")
}
```

## 可选协议

```swift
@objc protocol DesProto {
    @objc optional var textDesc: String { get }
}
```

## 默认实现

- 实现 比 默认实现 有更高的优先级
- 默认实现 不适用于 可选协议

```swift
protocol DesProto {
    var textDesc: String { get }
}
extension DesProto {
    var textDesc: String {          //  默认实现
        return "---"
    }
}
class MediaItem: DesProto {
    var textDesc: String {
        return "==="
    }
}

var a = MediaItem()
print(a.textDesc)
//  ===
```
