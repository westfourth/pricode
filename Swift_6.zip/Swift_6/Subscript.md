# Subscript

## 语法

```swift
//  单个参数
subscript(param: Type) -> ReturnType {
    get {
        // Return an appropriate subscript value here.
    }
    set {
        // Perform a suitable setting action here.
    }
}

//  多个参数
subscript(paramA: TypeA, paramB: TypeB) -> ReturnType {
    get {
        // Return an appropriate subscript value here.
    }
    set {
        // Perform a suitable setting action here.
    }
}
```

## Demo

```swift
class Person {
    var dict: [Int: Int] = [:]
    
    subscript(index: Int) -> Int {
        get {
            return dict[index] ?? 0
        }
        set {
            dict[index] = newValue
        }
    }

    subscript(index: Int, addition: Int) -> Int {
        get {
            return (dict[index] ?? 0) + addition
        }
        set {
            dict[index] = newValue - addition
        }
    }
}

var p = Person()

p[5] = 50
var b1 = p[5]                       //    50

p[1, 10]     = 100
var b2 = p[1]                       //    90
var b3 = p[1, 10]                   //    100
var b4 = p[1, 100]                  //    190
```