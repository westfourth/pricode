# Statements

## defer

在`defer`所在的范围结束之前（参考局部变量），执行`defer`里面的代码。

如果有多个`defer`，那么将按照出现的顺序倒序执行。

```swift
func f(x: Int) {
    defer { print("First defer") }

    if x < 10 {
        defer { print("Second defer") }
        print("End of if")
    }

    defer { print("Third defer") }

    print("End of function")
}

f(x: 5)
```

输出

```sh
End of if
Second defer
End of function
Third defer
First defer
```


## 编译器控制语句

语法：

```swift
#if <#compilation condition#>
    <#statements#>
#endif
```

![](Images/compilation_condition.png)

