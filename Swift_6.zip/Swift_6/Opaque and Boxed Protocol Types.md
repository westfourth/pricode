# Opaque and Boxed Protocol Types

## Opaque Type

不透明类型 可以认为是实现某个协议的具体类型，语法：`some Protocol`。

```swift
protocol Shape {
    func draw() -> String
}

struct Triangle: Shape {
    func draw() -> String {
       return "Triangle"
    }
}

struct Square: Shape {
    func draw() -> String {
       return "Square"
    }
}
```

**错误1：**

```swift
func makeTrapezoid(shape: Shape) -> some Shape {
    if true {
        return Square()
    }
    return Triangle()
}
```

如果有多个返回位置，那么所有返回位置的返回都必须为相同的类型。

**错误2：**

```swift
func makeTrapezoid(shape: Shape) -> some Shape {
    return shape
}
```

必须返回实现某个协议的具体类型。

**正确：**

```swift
func makeTrapezoid(shape: Shape) -> some Shape {
    return Triangle()
}
```



## Boxed Protocol Type

`Boxed Protocol Type` 也被称作 存在类型：有某个类型，并且这个类型采用了某个协议，语法：`any Protocol`。

```swift
struct VerticalShapes: Shape {
    var shapes: [any Shape]
    func draw() -> String {
        return shapes.map { $0.draw() }.joined(separator: "\n\n")
    }
}

let largeTriangle = Triangle()
let largeSquare = Square()
let vertical = VerticalShapes(shapes: [largeTriangle, largeSquare])
print(vertical.draw())
```


## 问题

这两个有啥区别？

```swift
func makeTrapezoid2(shape: Shape) -> Shape {
    return shape
}

func makeTrapezoid3(shape: Shape) -> any Shape {
    return shape
}
```

## 解答

1. 如果协议有关联类型，那么不能将此协议作为函数的返回类型。
1. 如果协议有关联类型，那么不能将此协议作为范型返回类型的约束，因为没有足够的信息推断范型类型需要什么。


```swift
protocol Container {
    associatedtype Item
    var count: Int { get }
    subscript(i: Int) -> Item { get }
}

extension Array: Container { }

// Error: Protocol with associated types can't be used as a return type.
func makeProtocolContainer<T>(item: T) -> Container {
    return [item]
}

// Error: Not enough information to infer C.
func makeProtocolContainer<T, C: Container>(item: T) -> C {
    return [item]
}
//  Generic parameter 'C' could not be inferred
var s = makeProtocolContainer(item: 123)
```