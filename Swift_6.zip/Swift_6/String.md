# String

## Extended String Delimiters

在首尾使用`#`禁用转义；在`\`后跟`#`开启转义。


```swift
let str1 = "Line 1\nLine 2"                 //  两行
let str2 = #"Line 1\nLine 2"#               //  Line 1\nLine 2
let str3 = #"Line 1\#nLine 2"#              //  两行
```

## Index

```swift
let greeting = "Guten Tag!"

var a0 = greeting[greeting.startIndex]                                  //  G
var a1 = greeting[greeting.index(after: greeting.startIndex)]           //  u
var a9 = greeting[greeting.index(before: greeting.endIndex)]            //  !
var a3 = greeting[greeting.index(greeting.startIndex, offsetBy: 3)]     //  e

//  遍历
for index in greeting.indices {
    print(greeting[index])
}
```

## Insert & Remove

1. `insert(_:at:)`
1. `insert(contentsOf:at:)`
1. `remove(at:)`
1. `removeSubrange(_:)`

```swift
var welcome = "hello"

welcome.insert("!", at: welcome.endIndex)                   //  hello!

let index = welcome.index(before: welcome.endIndex)
welcome.insert(contentsOf: " there", at: index)             //  hello there!

welcome.remove(at: welcome.index(before: welcome.endIndex)) //  hello there

let range = welcome.index(welcome.endIndex, offsetBy: -6)..<welcome.endIndex
welcome.removeSubrange(range)                               //  hello
```

## Substring

substring复用string的内存

```swift
let greeting = "Hello, world!"
let index = greeting.firstIndex(of: ",") ?? greeting.endIndex
let beginning = greeting[..<index]          //  Hello

// let beginning = greeting[..<6]           //  Error

// Convert the result to a String for long-term storage.
let newString = String(beginning)
```

![](Images/stringSubstring@2x.png)

