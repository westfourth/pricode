# Types

有两种类型：**命名类型**和**复合类型**。
- **命名类型**是一种在定义时可以赋予特定名称的类型。包括类、结构、枚举和协议。
- **复合类型**是没有名称的类型。包括函数类型、元组类型。

> `Int`、`Double`、`Bool`、`String`、`Array`、`Dictionary` 都是结构类型。


## 元组

```swift
var someTuple = (top: 10, bottom: 12)  // someTuple is of type (top: Int, bottom: Int)
someTuple = (top: 4, bottom: 42) // OK: names match
someTuple = (9, 99)              // OK: names are inferred
someTuple = (left: 5, right: 5)  // Error: names don't match
```


## 函数

- `((Int, Int)) -> Void` 接收一个元组参数。
- `(Int, Int) -> Void` 接收两个整形参数。

`Void` 是 `()` 的别名。

```swift
public typealias Void = ()
```

### 函数类型

函数类型与参数标签无关系。

```swift
func test1(left: Int, right: Int) {}
func test2(_ left: Int, _ right: Int) {}
func test3(top: Int, bottom: Int) {}

func test6(top: Int, bottom: String) {}
func test7(top: Int, bottom: Int, center: Int) {}

var f = test1               //  类型为：(Int, Int) -> ()
f = test2                   //  OK
f = test3                   //  OK

f = test6                   //  Error
f = test7                   //  Error
```

再如：

```swift
var f1: (lhs: Int, rhs: Int) -> Int         // Error
var f2: (_ lhs: Int, _ rhs: Int) -> Int     // OK
var f3: (Int, Int) -> Int                   // OK
```

### 函数返回

如果函数类型包含多个箭头 `->`，则函数类型从右到左分组。
例如：`(Int) -> (Int) -> Int`被理解为`(Int) -> ((Int) -> Int)`，函数接受一个`Int`并返回另一个函数。

### throws

省略`throws`与写入`throws(Never)`相同。


### 高阶函数

```swift
func takesFunctions(first: (() -> Void) -> Void) {
    first({ () -> Void in
        print("===")
    })
}

takesFunctions { (f: () -> Void) -> Void in
    print("AAA")
}

//  输出："AAA"
```

结果并没有输出："==="，原因：内部函数没有被调用

```swift
func takesFunctions(first: (() -> Void) -> Void) {
    first({ () -> Void in
        print("===")
    })
}

takesFunctions { (f: () -> Void) -> Void in
    print("AAA")
    f()
}

//  输出："AAA"
//  输出："==="
```

### 逃逸参数

非逃逸函数的参数不能作为参数传递给另一个非逃逸函数的参数。

```swift
let external: (() -> Void) -> Void = { _ in () }
func takesTwoFunctions(first: @escaping (() -> Void) -> Void, second: (() -> Void) -> Void) {
    first { first {} }       // OK
    second { second {}  }    // Error

    first { second {} }      // OK
    second { first {} }      // OK

    first { external {} }    // OK
    external { first {} }    // OK
}
```

`second`参数没有被标记为`@escaping`，所以`second`参数是`nonescaping`


## 数组

### 多维数组

```swift
var array3D: [[[Int]]] = [[[1, 2], [3, 4]], [[5, 6], [7, 8]]]
var a = array3D[0]                  //  [[1, 2], [3, 4]]
var b = array3D[0][1]               //  [3, 4]
```


## 可选类型

```swift
var a: Int?
var a: Optional<Int>
```

上面2个是相同的写法


## 元类型

**元类型**是指任何类型的类型，包括类类型、结构类型、枚举类型和协议类型。

- 类、结构或枚举类型的元类型是该类型的名称后跟`.Type`。
- 协议类型的元类型（不是运行时符合协议的具体类型）是该协议的名称后跟`.Protocol`。

```swift
struct Person {
    var name: String = "Tom"
    var age: Int = 23
}

class Dog {
    var nick: String = "Tom"
    var age: Int = 23
}

enum Direction {
    case east, west, south, north
}

protocol Bark {
    var desc: String { get }
}

print("------------------------------------------------")
    
print(Person())                     //  Person(name: "Tom", age: 23)
print(Person.self)                  //  Person
print(type(of: Person()))           //  Person
print(type(of: Person.self))        //  Person.Type

print("------------------------------------------------")

print(Dog())                        //  SwiftCommand.Dog
print(Dog.self)                     //  Dog
print(type(of: Dog()))              //  Dog
print(type(of: Dog.self))           //  Dog.Type

print("------------------------------------------------")

print(Direction.east)               //  east
print(Direction.self)               //  Direction
print(type(of: Direction.east))     //  Direction
print(type(of: Direction.self))     //  Direction.Type

print("------------------------------------------------")

print(Bark.self)                    //  Bark
print(type(of: Bark.self))          //  Bark.Protocol

print("------------------------------------------------")
```

### 初始化

使用初始化表达式从该类型的元类型值构造类型的实例。对于类实例，调用的初始化表达式必须用`required`关键字标记，或整个类用`final`关键字标记。

```swift
class Dog {
    var nick: String = "Tom"
    var age: Int = 23
    
    required init(nick: String, age: Int) {
        self.nick = nick
        self.age = age
    }
}
```

或

```swift
final class Dog {
    var nick: String = "Tom"
    var age: Int = 23
    
    init(nick: String, age: Int) {
        self.nick = nick
        self.age = age
    }
}
```


举例：

```swift
let t1: Person.Type = Person.self
let a = t1.init()

let t2: Dog.Type = Dog.self
let b = t2.init(nick: "XYZ", age: 321)

let t3: Direction.Type = Direction.self
let c = t3.east

print(a)                //  Person(name: "Tom", age: 23)
print(b)                //  SwiftCommand.Dog
print(c)                //  east
```


## Self

`Self`类型不是一种特定的类型，而是让你可以方便地引用当前类型，而无需重复或知道该类型的名称。
- 在协议声明或协议成员声明中，`Self`类型指的是符合协议的最终类型。
- 在结构、类或枚举声明中，`Self`类型指的是声明引入的类型。


```swift
class Superclass {
    func f() -> Self { return self }
}
let x = Superclass()
print(type(of: x.f()))                  //  Superclass

class Subclass: Superclass { }
let y = Subclass()
print(type(of: y.f()))                  //  Subclass

let z: Superclass = Subclass()
print(type(of: z.f()))                  //  Subclass
```

`Self`类型指的是与Swift标准库中的`type(of:)`函数相同的类型。
编写`Self.someStaticMember`来访问当前类型的成员与编写`type(of: self).someStaticMember`相同。

### 范型使用

```swift
struct Person {
    var name: String = "Tom"
    var age: Int = 23
    
    var stride: Int {
        return MemoryLayout<Self>.stride
    }
}
```