# Initialization

## 问题

1. 指定初始化 与 便利初始化 有啥不同？

## 初始化规则

1. 指定初始化 必须调用 直接父类 的 指定初始化.
1. 便利初始化 必须调用 同类 的 初始化。
1. 便利初始化 最终必须调用 同类的 指定初始化。

![](./Images/initializerDelegation01@2x.png)

同类的 指定初始化 不可以相互调用

## 安全检查

1. 指定初始化 在调用父类初始化之前 必须初始化 自身属性。
1. 指定初始化 在给继承属性赋值之前 必须调用 父类初始化。
1. 便利初始化 在给属性赋值之前 必须调用 另一个初始化。
1. 在初始化自身（自身属性、继承属性）之前，不能调用实例方法、不能读取实例属性值、不能访问self。

## 自动初始化继承

1. 如果子类没有任何 指定初始化，那么子类自动继承父类的 指定初始化。
1. 如果子类没有任何 指定初始化，或者子类的 重写了父类的所有 指定初始化，那么子类自动继承父类的 便利初始化。

```swift
class Food {
    var name: String
    var age: Int = 0
    
    init(name: String) {
        self.name = name
    }
    init(name: String, age: Int) {
        self.name = name
        self.age = age
    }
    
    convenience init() {
        self.init(name: "[Unnamed]")
    }
}

class RecipeIngredient: Food {
    var quantity: Int
    
    override convenience init(name: String) {           //  重写指定初始化
        self.init(name: name, quantity: 1)
    }
    override init(name: String, age: Int) {             //  重写指定初始化
        self.quantity = 100
        super.init(name: name, age: age)
    }
    
    init(name: String, quantity: Int) {
        self.quantity = quantity
        super.init(name: name)
    }
    init(quantity: Int) {
        self.quantity = quantity
        super.init(name: "AAA")
    }
}

var r = RecipeIngredient()                              //  自动继承父类的指定初始化
```

调用顺序。<mark>请思考其原因<mark>

```
1. init()                              //  Food
2. init(name:)                         //  RecipeIngredient
3. init(name:quantity:)                //  RecipeIngredient
4. init(name:)                         //  Food
```

如果父类的 指定初始化 被子类重写为 便利初始化，那么也满足“子类的 重写了父类的 指定初始化”。

> 便利初始化不可以被重载

## Failable Initializer

```swift
struct Animal {
    let species: String
    init?(species: String) {
        if species.isEmpty { return nil }
        self.species = species
    }
}
```

failable initializer 可被重写为 nonfailable initializer，反之则不行。

## Required Initializer

所有子类都必须实现 Required Initializer。

```swift
class SomeClass {
    required init() {
        
    }
}

class SomeSubclass: SomeClass {
    required init() {               //  不需要 override
        
    }
}
```

## 使用闭包设置默认值

```swift
class SomeClass {
    let someProperty: SomeType = {
        return someValue
    }()
}
```

闭包后有小括号，表示立即执行闭包。闭包里面不能使用self、不能访问属性、不能调用实例方法。

**错误举例：**

```swift
class SomeClass {
    var price = 10
    var count = 5
    
    var total: Int = {
        description()                   //  Error 1
        var a = price                   //  Error 2
        var b = self.count              //  Error 3
        return a * b
    }()
    
    func description() {
        print("====")
    }
}
```

- `Error 1` Cannot use instance member 'description' within property initializer; property initializers run before 'self' is available
- `Error 2` Cannot use instance member 'price' within property initializer; property initializers run before 'self' is available
- `Error 3` Cannot find 'self' in scope; did you mean to use it in a type or extension context?


