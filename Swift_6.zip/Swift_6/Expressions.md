# Expressions


## try

当中缀运算符左侧的表达式标有 try、try? 或 try! 时，该运算符将应用于整个中缀表达式。

```swift
// try applies to both function calls
sum = try someThrowingFunction() + anotherThrowingFunction()

// try applies to both function calls
sum = try (someThrowingFunction() + anotherThrowingFunction())

// Error: try applies only to the first function call
sum = (try someThrowingFunction()) + anotherThrowingFunction()
```


## await

当中缀运算符左侧的表达式标有 await 运算符时，该运算符将应用于整个中缀表达式。


```swift
// await applies to both function calls
sum = await someAsyncFunction() + anotherAsyncFunction()

// await applies to both function calls
sum = await (someAsyncFunction() + anotherAsyncFunction())

// Error: await applies only to the first function call
sum = (await someAsyncFunction()) + anotherAsyncFunction()
```


## =

赋值运算符不返回任何值。

```swift
(a, _, (b, c)) = ("test", 9.45, (12, 3))
```


## is、as

共4种：`is`、`as`、`as?`、`as!`。

- `is` 在运行时是否可以转换为指定类型。
- `as` 在编译时转换为指定类型。


## 捕获列表

默认情况下，闭包表达式会从其周围范围捕获常量和变量，并对这些值进行强引用。

捕获列表中的条目在创建闭包时初始化。对于捕获列表中的每个条目，将一个常量初始化为周围范围内同名的常量或变量的值。

- 当捕获的变量是值类型，则内部与外部的变量不是同一个变量。
- 当捕获的变量是引用类型，则内部与外部的变量是同一个变量。

```swift
var a = 1
var b = 1
let closure = { [a] in
    print(a, b)
}

a = 10
b = 10
closure()                       //  1 10
```

闭包内部中的a是常量，闭包外部的a是变量。内部a与外部a地址不同，不是同一个常量/变量。



```swift
class SimpleClass {
    var value: Int = 0
}
var x = SimpleClass()
var y = SimpleClass()
let closure = { [x] in
    print(x.value, y.value)
}


x.value = 10
y.value = 10
closure()                       //  10 10
```

闭包内部中的a是常量，闭包外部的a是变量。内部a与外部a地址相同，是同一个常量/变量。


## Key-Path

`Key-Path`指的是类型的属性或下标。

语法：`\<#type name#>.<#path#>`

### 举例

```swift
struct SomeStructure {
    var someValue: Int
}

let s = SomeStructure(someValue: 12)
let pathToProperty = \SomeStructure.someValue

let value = s[keyPath: pathToProperty]              //  12
```

### 类型推断

在类型推断可以确定隐含类型的上下文中，可以省略类型名称

```swift
class SomeClass: NSObject {
    @objc dynamic var someProperty: Int
    init(someProperty: Int) {
        self.someProperty = someProperty
    }
}


let c = SomeClass(someProperty: 10)
c.observe(\.someProperty) { object, change in
    // ...
}
```

### \\.self

使用`\.self`改变自身值。

```swift
var compoundValue = (a: 1, b: 2)
// Equivalent to compoundValue = (a: 10, b: 20)
compoundValue[keyPath: \.self] = (a: 10, b: 20)
```

### 键路径

```swift
struct SomeStructure {
    var someValue: Int
}

struct OuterStructure {
    var outer: SomeStructure
    init(someValue: Int) {
        self.outer = SomeStructure(someValue: someValue)
    }
}

let nested = OuterStructure(someValue: 24)
let nestedKeyPath = \OuterStructure.outer.someValue
let nestedValue = nested[keyPath: nestedKeyPath]        //  24
```

### 下标

```swift
let array = ["AA", "BB", "CC", "DD"]
let a1 = array[keyPath: \[String].[1]]                  //  "BB"
```

### 键路径2

```swift
let interestingNumbers = ["prime": [2, 3, 5, 7, 11, 13, 17],
                          "triangular": [1, 3, 6, 10, 15, 21, 28],
                          "hexagonal": [1, 6, 15, 28, 45, 66, 91]]
print(interestingNumbers[keyPath: \[String: [Int]].["prime"]] as Any)
// Prints "Optional([2, 3, 5, 7, 11, 13, 17])"
print(interestingNumbers[keyPath: \[String: [Int]].["prime"]![0]])
// Prints "2"
print(interestingNumbers[keyPath: \[String: [Int]].["hexagonal"]!.count])
// Prints "7"
print(interestingNumbers[keyPath: \[String: [Int]].["hexagonal"]!.count.bitWidth])
// Prints "64"
```

### 键路径3

```swift
struct Task {
    var description: String
    var completed: Bool
}

var toDoList = [
    Task(description: "Practice ping-pong.", completed: false),
    Task(description: "Buy a pirate costume.", completed: true),
    Task(description: "Visit Boston in the Fall.", completed: false),
]

// Both approaches below are equivalent.
let descriptions = toDoList.filter(\.completed).map(\.description)
let descriptions2 = toDoList.filter { $0.completed }.map { $0.description }
```


## Selector

选择器表达式可让你访问用于引用 Objective-C 中的方法或属性的 getter 或 setter 的选择器。

语法：

```swift
#selector(<#method name#>)
#selector(getter: <#property name#>)
#selector(setter: <#property name#>)
```

### 举例

```swift
class SomeClass: NSObject {
    @objc var property: String

    @objc(doSomethingWithInt:)
    func doSomething(_ x: Int) { }

    init(property: String) {
        self.property = property
    }
}

let selectorForMethod = #selector(SomeClass.doSomething(_:))
let selectorForPropertyGetter = #selector(getter: SomeClass.property)
let selectorForPropertySetter = #selector(setter: SomeClass.property)

let anotherSelector = #selector(SomeClass.doSomething(_:) as (SomeClass) -> (Int) -> Void)
```

因为选择器是在编译时而不是运行时创建的，所以编译器可以检查方法或属性是否存在以及它们是否暴露给 Objective-C 运行时。


## #keyPath

作用：用于访问Objective-C的属性

语法：`#keyPath(<#property name#>)`

```swift
class SomeClass: NSObject {
    @objc var someProperty: Int
    init(someProperty: Int) {
       self.someProperty = someProperty
    }
}

let c = SomeClass(someProperty: 12)
let keyPath = #keyPath(SomeClass.someProperty)

if let value = c.value(forKey: keyPath) {
    print(value)
}
// Prints "12"
```

```swift
extension SomeClass {
    func getSomeKeyPath() -> String {
        return #keyPath(someProperty)
    }
}
print(keyPath == c.getSomeKeyPath())
// Prints "true"
```

由于键路径字符串是在编译时而不是运行时创建的，因此编译器可以检查该属性是否存在以及该属性是否暴露给 Objective-C 运行时


## 函数调用

```swift
// someFunction takes an integer and a closure as its arguments
someFunction(x: x, f: { $0 == 13 })
someFunction(x: x) { $0 == 13 }

// anotherFunction takes an integer and two closures as its arguments
anotherFunction(x: x, f: { $0 == 13 }, g: { print(99) })
anotherFunction(x: x) { $0 == 13 } g: { print(99) }
```


## 隐式转换为指针类型

In a function call expression, if the argument and parameter have a different type, the compiler tries to make their types match by applying one of the implicit conversions in the following list:
- inout SomeType can become `UnsafePointer<SomeType>` or `UnsafeMutablePointer<SomeType>`
- inout `Array<SomeType>` can become `UnsafePointer<SomeType>` or `UnsafeMutablePointer<SomeType>`
- `Array<SomeType>` can become `UnsafePointer<SomeType>`
- String can become `UnsafePointer<CChar>`

The following two function calls are equivalent:

```swift
func unsafeFunction(pointer: UnsafePointer<Int>) {
    // ...
}
var myNumber = 1234

unsafeFunction(pointer: &myNumber)
withUnsafePointer(to: myNumber) { unsafeFunction(pointer: $0) }
```


## 初始化

```swift
let s1 = SomeType.init(data: 3)  // Valid
let s2 = SomeType(data: 1)       // Also valid

let s3 = type(of: someValue).init(data: 7)  // Valid
let s4 = type(of: someValue)(data: 5)       // Error
```


## .self

语法：

```swift
<#expression#>.self
<#type#>.self                   //  使用此形式将类型作为值
```