# Access Control

## 访问等级

| 等级 | 说明 |
| :-: | :-: |
| open | 仅限类和类成员，可被外部代码继承和重写（最高） |
| public | |
| package | package内使用 |
| internal | module内使用 |
| fileprivate | file内使用 |
| private | 仅限实体申明和同一文件的实体扩展（最低） |


## 原则

**实体的访问等级不能比相关实体的更高。**

1. **元组** 的访问等级为其 **元素** 中访问等级最低的那一个。
1. **函数** 的访问等级为其 **参数、返回** 中访问等级最低的那一个。
1. **枚举** 的各case的访问等级与枚举相同，不能为case指定单独的访问等级。
1. **子类** 的访问等级不能比父类的更 **高**。
1. **子类方法** 的访问等级不能比父类的更 **低**。
1. **常量、变量、属性** 的访问等级不能比类型的更 **高**。
1. **getter、setter** 的访问等级与 **常量、变量、属性、下标** 的一致；**setter** 的访问等级可低于 **getter**。
1. **初始化** 的访问等级不能比类型的更 **高**；**必需初始化** 的访问等级与类型的一致。
1. **成员初始化（结构体）** 的访问等级为其 **存储属性** 中访问等级最低的那一个。
1. **子协议** 的访问等级不能比父协议的更 **高**。
1. **类型** 的访问等级不能比其采用的协议的更 **低**。
1. **范型** 的访问等级为 访问等级最低的那一个。
1. **别名** 的访问等级不能比真实类型的更 **高**。


## 默认等级

**重要：`public`类型的成员的默认访问等级为`internal`。**

```swift
public class SomePublicClass {                   // explicitly public class
    public var somePublicProperty = 0            // explicitly public class member
    var someInternalProperty = 0                 // implicitly internal class member
    fileprivate func someFilePrivateMethod() {}  // explicitly file-private class member
    private func somePrivateMethod() {}          // explicitly private class member
}


class SomeInternalClass {                        // implicitly internal class
    var someInternalProperty = 0                 // implicitly internal class member
    fileprivate func someFilePrivateMethod() {}  // explicitly file-private class member
    private func somePrivateMethod() {}          // explicitly private class member
}


fileprivate class SomeFilePrivateClass {         // explicitly file-private class
    func someFilePrivateMethod() {}              // implicitly file-private class member
    private func somePrivateMethod() {}          // explicitly private class member
}


private class SomePrivateClass {                 // explicitly private class
    func somePrivateMethod() {}                  // implicitly private class member
}
```


## 示例

```swift
private struct PrivateStruct {}

internal struct InternalStruct {}
```

**错误1:**

```swift
func balance(x: PrivateStruct, y: InternalStruct) {
    print(#function)
}
```

不会编译，需要将函数访问权限改为`private`或`fileprivate`

**错误2:**

```swift
var a = PrivateStruct()
```

不会编译，需要将变量访问权限改为`private`或`fileprivate`

## getter & setter

```swift
struct TrackedString {
    private(set) var numberOfEdits = 0              //  internal get, private set
    var value: String = "" {
        didSet {
            numberOfEdits += 1
        }
    }
}
```

```swift
public struct TrackedString {
    public private(set) var numberOfEdits = 0       //  public get, private set
    public var value: String = "" {
        didSet {
            numberOfEdits += 1
        }
    }
    public init() {}
}
```


