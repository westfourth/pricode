# Attributes


## available

```swift
@available(iOS 10.0, macOS 10.12, *)
```

```swift
@available(swift 3.0.2)
@available(macOS 10.12, *)
```


## discardableResult

用于函数或方法声明，函数或方法的返回值没有被使用时，抑制编译器警告。

```swift
@discardableResult
func add(_ a: Int, _ b: Int) -> Int {
    return a + b
}

add(3, 4)
```


## dynamicCallable

将此特性应用于类、结构、枚举或协议，以将类型的实例视为可调用函数。该类型必须实现`dynamicCall(withArguments:)`方法、`dynamicCall(withKeywordArguments:)`方法或两者。

### withArguments

```swift
@dynamicCallable
struct TelephoneExchange {
    func dynamicallyCall(withArguments phoneNumber: [Int]) {
        if phoneNumber == [4, 1, 1] {
            print("Get Swift help on forums.swift.org")
        } else {
            print("Unrecognized number")
        }
    }
}

let dial = TelephoneExchange()

// Use a dynamic method call.
dial(4, 1, 1)
// Prints "Get Swift help on forums.swift.org"

dial(8, 6, 7, 5, 3, 0, 9)
// Prints "Unrecognized number"

// Call the underlying method directly.
dial.dynamicallyCall(withArguments: [4, 1, 1])
```

`dynamicCall(withArguments:)`方法的声明必须有一个符合`ExpressibleByArrayLiteral`协议的参数。返回类型可以是任何类型。

### withKeywordArguments

```swift
@dynamicCallable
struct Repeater {
    func dynamicallyCall(withKeywordArguments pairs: KeyValuePairs<String, Int>) -> String {
        return pairs
            .map { label, count in
                repeatElement(label, count: count).joined(separator: " ")
            }
            .joined(separator: "\n")
    }
}


let repeatLabels = Repeater()
print(repeatLabels(a: 1, b: 2, c: 3, b: 2, a: 1))
// a
// b b
// c c c
// b b
// a

//  等同于
let repeatLabels2 = repeatLabels.dynamicallyCall(withKeywordArguments: ["a": 1, "b": 2, "c": 3, "b": 2, "a": 1])
print(repeatLabels2)
```

`dynamicCall(withKeywordArguments:)`方法的声明必须有一个符合`ExpressibleByDictionaryLiteral`协议的参数，返回类型可以是任意类型。参数的`Key`必须是 `ExpressibleByStringLiteral`。


## dynamicMemberLookup

将此属性应用于类、结构、枚举或协议，以便在运行时按名称查找成员。该类型必须实现`subscript(dynamicMember:)`下标。

```swift
@dynamicMemberLookup
struct DynamicStruct {
    let dictionary = ["someDynamicMember": 325,
                      "someOtherMember": 787]
    subscript(dynamicMember member: String) -> Int {
        return dictionary[member] ?? 1054
    }
}
let s = DynamicStruct()

// Use dynamic member lookup.
let dynamic = s.someDynamicMember
print(dynamic)
// Prints "325"

// Call the underlying subscript directly.
let equivalent = s[dynamicMember: "someDynamicMember"]
print(dynamic == equivalent)
// Prints "true"
```


## main

将此属性应用于结构、类或枚举声明，以指示它包含程序流的顶级入口点。该类型必须提供一个不接受任何参数并返回`Void`的主类型函数

```swift
@main
struct MyTopLevel {
    static func main() {
        // Top-level code goes here
    }
}
```


## propertyWrapper ??


## resultBuilder ??


## 

```swift
```


## 

```swift
```
