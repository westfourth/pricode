//
//  VideoTestModel.swift
//  ShortVideo
//
//  Created by mac on 2019/12/7.
//  Copyright © 2019 mac. All rights reserved.
//

import UIKit
import AVFoundation

class ShortVideoModel: NSObject {
    var videoURL: URL?
    var playerItem: AVPlayerItem?
}



