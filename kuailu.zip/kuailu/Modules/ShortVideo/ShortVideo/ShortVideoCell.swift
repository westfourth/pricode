//
//  ShortVideoCell.swift
//  ShortVideo
//
//  Created by mac on 2019/12/7.
//  Copyright © 2019 mac. All rights reserved.
//

import UIKit
import AVFoundation

class PlayerImageView: UIImageView {
    override class var layerClass: AnyClass {
        return AVPlayerLayer.self
    }
}

class ShortVideoCell: UICollectionViewCell {
    private var currentTime: CMTime = CMTime.zero
    private var duration: CMTime = CMTime.zero
    private var isSliding = false   //  正在滑动
    
    weak var delegate: ShortVideoCellDelegate?
    
    //  更新播放状态
    var timeControlStatus: AVPlayer.TimeControlStatus? {
        didSet {
            playImageView.image = timeControlStatus == .paused ? UIImage(named: "短视频-播放") : nil
        }
    }
    
    //  更新进度
    func updateProgress(currentTime: CMTime, duration: CMTime) {
        if isSliding {      //  正在滑动不需要设置
            return;
        }
        self.currentTime = currentTime
        self.duration = duration
        if duration == .zero || duration.isIndefinite  {
            slider.value = 0
            slider.maximumValue = 1;
        } else {
            slider.value = Float(CMTimeGetSeconds(currentTime))
            slider.maximumValue = Float(CMTimeGetSeconds(duration))
        }
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        contentView.addSubview(bgImageView)
        contentView.addSubview(blurView)
        
        blurView.contentView.addSubview(fgImageView)
        blurView.contentView.addSubview(playImageView)
        blurView.contentView.addSubview(slider)
        blurView.contentView.addSubview(progressLabel)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        blurView.frame = bounds
        bgImageView.frame = bounds
        fgImageView.frame = calculateFrameForFgImageView(ratio: 999.0 / 562.0)
        
        //  playImageView
        let size = CGSize(width: 40, height: 40)
        playImageView.frame = CGRect(x: (bounds.width - size.width) / 2.0,
                                  y: (bounds.height - size.height) / 2.0,
                                  width: size.width, height: size.height)
        
        let tabbarFrame = ShortVideoCell.getTabbarFrame()
        
        //  slider
        let sliderHeight:CGFloat = 20;
        let sliderOffsetY: CGFloat = 2;
        slider.frame = CGRect(x: 0, y: tabbarFrame.minY - sliderHeight / 2 - sliderOffsetY,
                              width: bounds.width, height: sliderHeight)
        
        //  progressLabel
        let progressLabelOffsetY: CGFloat = 80;
        progressLabel.frame = CGRect(x: 0, y: tabbarFrame.minY - progressLabelOffsetY,
                                     width: bounds.width, height: 30)
    }
    
    //  ratio：宽高比
    func calculateFrameForFgImageView(ratio: CGFloat) -> CGRect {
        var fgImageViewFrame = CGRect.zero
        let height: CGFloat = frame.width * (1 / ratio)
        let minY: CGFloat = (frame.height - height) / 2.0
        fgImageViewFrame = CGRect(x: 0, y: minY, width: frame.width, height: height)
        return fgImageViewFrame
    }
    
    //  获取Tabbar高度
    class func getTabbarFrame() -> CGRect {
        let vc = (UIApplication.shared.delegate as! AppDelegate).window!.rootViewController
        let tabVC = vc as! UITabBarController
        return tabVC.tabBar.frame
    }
    
    //_______________________________________________________________________________________________________________
    // MARK: -
    
    lazy var blurView: UIVisualEffectView = {
        let effect = UIBlurEffect(style: .light)
        var view = UIVisualEffectView(effect: effect)
        return view
    }()
    
    lazy var bgImageView: PlayerImageView = {
        let effect = UIBlurEffect()
//        let image = ShortVideoBundle.imageNamed(imageName: "beauty2")
        var view = PlayerImageView()
//        view.image = image
        view.contentMode = .scaleAspectFill
        (view.layer as! AVPlayerLayer).videoGravity = .resizeAspectFill
        view.layer.backgroundColor = UIColor.black.cgColor
        return view
    }()
    
    lazy var fgImageView: PlayerImageView = {
        let effect = UIBlurEffect()
//        let image = ShortVideoBundle.imageNamed(imageName: "beauty2")
        var view = PlayerImageView()
//        view.image = image
        view.contentMode = .scaleAspectFit
        view.layer.backgroundColor = UIColor.black.cgColor
        return view
    }()
    
    //  播放、暂停、加载显示
    lazy var playImageView: UIImageView = {
        let view = UIImageView()
        view.contentMode = .scaleAspectFit
//        view.image = UIImage(named: "短视频-播放")
//        view.image = ShortVideoCell.loadingImages()
        return view
    }()
    
    //  进度条
    lazy var slider: UISlider = {
        let view = UISlider()
        view.minimumTrackTintColor = UIColor.white.withAlphaComponent(0.4)
        view.maximumTrackTintColor = UIColor.clear
        view.setThumbImage(nil, for: .normal)
        view.setThumbImage(UIImage(named: "slider3"), for: .highlighted)
        
        view.addTarget(self, action: #selector(sliderTouchBegin), for: .touchDown)
        view.addTarget(self, action: #selector(sliderTouchChange), for: .valueChanged)
        view.addTarget(self, action: #selector(sliderTouchEnd), for: .touchUpInside)
        view.addTarget(self, action: #selector(sliderTouchCancel), for: .touchUpOutside)
        return view
    }()
    
    lazy var progressLabel: UILabel = {
        let view = UILabel()
        view.text = "00:00"
        view.textColor = UIColor.white
        view.textAlignment = .center
        view.font = UIFont.systemFont(ofSize: 24)
        view.isHidden = true
        return view
    }()
    
    //_______________________________________________________________________________________________________________
    // MARK: -
    
    @objc func sliderTouchBegin() {
        isSliding = true
        if duration != .zero && !duration.isIndefinite {
            progressLabel.isHidden = false
        }
    }
    
    @objc func sliderTouchChange() {
        if duration != .zero && !duration.isIndefinite {
            let currentTimeText = ShortVideoCell.durationText(TimeInterval(slider.value))
            progressLabel.text = currentTimeText
        }
    }
    
    @objc func sliderTouchEnd() {
        let destTime = CMTimeMake(value: Int64(slider.value), timescale: 1)
        delegate?.shortVideoCell(self, seekToTime: destTime, completion: {
            self.isSliding = false
            self.progressLabel.isHidden = true
        })
    }
    
    @objc func sliderTouchCancel() {
        isSliding = false
        progressLabel.isHidden = true
    }
    
    //_______________________________________________________________________________________________________________
    // MARK: -
    
    //  生成时间字符串，格式：00:00
    static func durationText(_ duration: TimeInterval) -> String {
        let minute: Int = Int(duration / 60)
        let second: Int = Int(duration) % 60
        let string = String(format: "%02d:%02d", minute, second)
        return string
    }

    static func itemSize() -> CGSize {
        return UIScreen.main.bounds.size
    }
}


protocol ShortVideoCellDelegate: NSObjectProtocol {
    func shortVideoCell(_ shortVideoCell: ShortVideoCell, seekToTime time: CMTime, completion: @escaping () -> Void)
}
