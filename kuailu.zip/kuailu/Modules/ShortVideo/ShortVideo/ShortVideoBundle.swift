//
//  ShortVideoBundle.swift
//  ShortVideo
//
//  Created by mac on 2019/12/7.
//  Copyright © 2019 mac. All rights reserved.
//

import UIKit

/// 颜色，例如：RGB(0xF7B500)
public func RGB(_ hex: UInt) -> UIColor {
    return UIColor(red: CGFloat((hex & 0xFF0000) >> 16) / 255.0,
                   green: CGFloat((hex & 0xFF00) >> 8) / 255.0,
                   blue: CGFloat(hex & 0xFF) / 255.0,
                   alpha: 1)
}

class ShortVideoBundle: NSObject {
    public static func bundle() -> Bundle {
        var bundle = Bundle(for: self)
        let array = bundle.bundleIdentifier?.components(separatedBy: ".")
        let resourceName = array?.last
        let url = bundle.url(forResource: resourceName, withExtension: "bundle")
        if url != nil {
            bundle = Bundle(url: url!)!
        }
        return bundle
    }
    
    public static func imageNamed(imageName: String) -> UIImage? {
        let image = UIImage(named: imageName, in: self.bundle(), compatibleWith: nil)
        return image;
    }
}
