//
//  ShortVideoController.swift
//  ShortVideo
//
//  Created by mac on 2019/12/7.
//  Copyright © 2019 mac. All rights reserved.
//

import UIKit
import AVFoundation

class ShortVideoController: UIViewController, UICollectionViewDataSource, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout, ShortVideoCellDelegate {
    //  只有一个播放器（不是每个cell都有自己的播放器）
    var player: AVPlayer = AVPlayer(playerItem: nil)
    var periodicTimeObserver: Any?
    
    //  当前播放的indexPath
    var currentPlayIndexPath: IndexPath = IndexPath(item: 0, section: 0)
    var models = [ShortVideoModel]()

    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupData()
        
        view.addSubview(collectionView)
        collectionView.frame = view.bounds
        if #available(iOS 11.0, *) {
            collectionView.contentInsetAdjustmentBehavior = .never
        } else {
            automaticallyAdjustsScrollViewInsets = false
        }
                
        //  监听播放器状态
        player.addObserver(self, forKeyPath: "timeControlStatus", options: .new, context: nil)
        //  监听播放进度
        periodicTimeObserver = player.addPeriodicTimeObserver(forInterval: CMTimeMake(value: 1, timescale: 2), queue: DispatchQueue.main, using: {[weak self] (currentTime) in
            self?.observeCurrentTime(currentTime: currentTime)
        });
        
        //  播放
//        currentPlayIndexPath = IndexPath(item: 45, section: 0)
//        collectionView.scrollToItem(at: currentPlayIndexPath, at: .centeredVertically, animated: false)
        self.startPlayItem(indexPath: currentPlayIndexPath)
    }
    
    deinit {
        player.removeObserver(self, forKeyPath: "timeControlStatus")
        player.removeTimeObserver(periodicTimeObserver!)
        print(#function)
    }
    
    override func observeValue(forKeyPath keyPath: String?, of object: Any?, change: [NSKeyValueChangeKey : Any]?, context: UnsafeMutableRawPointer?) {
        if object is AVPlayer {
            //  监听播放器状态
            if keyPath == "timeControlStatus" {
                let timeControlStatus = (object as! AVPlayer).timeControlStatus
                let row = currentRow(collectionView: collectionView)
                let indexPath = IndexPath(item: row, section: 0)
                let cell = collectionView.cellForItem(at: indexPath) as? ShortVideoCell
                if cell != nil {
                    cell!.timeControlStatus = timeControlStatus
                }
            }
        }
    }
    
    //  监听播放进度
    func observeCurrentTime(currentTime: CMTime) {
        let row = currentRow(collectionView: collectionView)
        let indexPath = IndexPath(item: row, section: 0)
        let cell = collectionView.cellForItem(at: indexPath) as? ShortVideoCell
        let playerItem = player.currentItem
        if cell != nil && playerItem != nil {
            cell!.updateProgress(currentTime: playerItem!.currentTime(), duration: playerItem!.duration)
        }
    }

    func setupData() {
        let path = ShortVideoBundle.bundle().path(forResource: "Video", ofType: "json")
        let data = NSData(contentsOfFile: path!)! as Data
        
        let array = try! JSONSerialization.jsonObject(with: data, options: .mutableContainers) as! Array<[String: Any]>
        for dict: [String: Any] in array {
            let model = ShortVideoModel()
            model.videoURL = URL(string: dict["url"] as! String)
            model.playerItem = AVPlayerItem(url: model.videoURL!)
            models.append(model)
        }
    }

    lazy var collectionView: UICollectionView = {
        let layout = UICollectionViewFlowLayout()
        layout.minimumLineSpacing = 0
        layout.minimumInteritemSpacing = 0
        layout.itemSize = ShortVideoCell.itemSize()
        
        let collectionView = UICollectionView(frame: .zero, collectionViewLayout: layout)
        collectionView.dataSource = self
        collectionView.delegate = self

        collectionView.register(ShortVideoCell.self, forCellWithReuseIdentifier: "CELL")
        collectionView.backgroundColor = .black
        collectionView.isPagingEnabled = true
        collectionView.showsVerticalScrollIndicator = false
        collectionView.scrollsToTop = false
        return collectionView
    }()
    
    
    //_______________________________________________________________________________________________________________
    // MARK: - 数据源
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return models.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CELL", for: indexPath) as! ShortVideoCell
        //  播放器
        let aPlayer: AVPlayer? = indexPath == currentPlayIndexPath ? player : nil
        let playerItem: AVPlayerItem? = aPlayer?.currentItem
        print("====== cellForItemAt indexPath: \(indexPath), player: \(aPlayer), visibleItems: \(collectionView.indexPathsForVisibleItems)")
        
        cell.delegate = self
        (cell.fgImageView.layer as! AVPlayerLayer).player = aPlayer
        (cell.bgImageView.layer as! AVPlayerLayer).player = aPlayer
        if playerItem != nil {
            cell.updateProgress(currentTime: playerItem!.currentTime(), duration: playerItem!.duration)
        } else {
            cell.updateProgress(currentTime: .zero, duration: .zero)
        }
        
//        var imageName = indexPath.item % 2 == 0 ? "beauty" : "beauty2";
//        let image: UIImage? = ShortVideoBundle.imageNamed(imageName: imageName)
//        cell.fgImageView.image = image
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        guard let currentItem = player.currentItem else {
            return
        }
        if player.timeControlStatus == .paused {
            let t = CMTimeSubtract(currentItem.duration, currentItem.currentTime())
            if CMTimeGetSeconds(t) < 1.0 {
                currentItem.seek(to: .zero) {[weak self] (finished) in
                    self?.player.play()
                }
            } else {
                player.play()
            }
        } else {
            player.pause()
        }
    }
    
    
    func scrollViewWillEndDragging(_ scrollView: UIScrollView, withVelocity velocity: CGPoint, targetContentOffset: UnsafeMutablePointer<CGPoint>) {
        puts(#function)
        let row: Int = Int(round(targetContentOffset.pointee.y / ShortVideoCell.itemSize().height))
        if row != currentPlayIndexPath.item {
            endPlayItem(indexPath: currentPlayIndexPath)
        }
    }
    
    /// 不可以通过willDisplayCell、didEndDisplayingCell来计算，在快速滑动时会出问题
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        puts(#function)
        //  计算当前是第几个
        let row = currentRow(collectionView: scrollView as! UICollectionView)
        if row != currentPlayIndexPath.item {
            let nextPlayIndexPath = IndexPath(item: row, section: 0)
            startPlayItem(indexPath: nextPlayIndexPath)
        }
    }
    
    //_______________________________________________________________________________________________________________
    // MARK: -
    
    //  计算当前UICollectionView展示第几行
    func currentRow(collectionView: UICollectionView) -> Int {
        return Int(round(collectionView.contentOffset.y / ShortVideoCell.itemSize().height))
    }
    
    func shortVideoCell(_ shortVideoCell: ShortVideoCell, seekToTime time: CMTime, completion: @escaping () -> Void) {
        player.currentItem?.cancelPendingSeeks()
        player.currentItem?.seek(to: time, completionHandler: { (finished) in
            completion()
        })
    }
    
    func startPlayItem(indexPath: IndexPath) {
        print(">>> startPlayItem \(indexPath)")
        currentPlayIndexPath = indexPath
        
        let model = models[indexPath.item]
        player.replaceCurrentItem(with: model.playerItem)   //  加载视频
        if player.timeControlStatus == .paused {
            player.play()
        }
        collectionView.reloadData()
    }
    
    func endPlayItem(indexPath: IndexPath) {
        print(">>> endPlayItem \(indexPath)")
        player.replaceCurrentItem(with: nil)
    }
    
}
