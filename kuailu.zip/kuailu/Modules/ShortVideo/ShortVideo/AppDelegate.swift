//
//  AppDelegate.swift
//  ShortVideo
//
//  Created by mac on 2019/12/7.
//  Copyright © 2019 mac. All rights reserved.
//

import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {
    var window: UIWindow?
    
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        AppDelegate.setupAppearance()
        
        window = UIWindow()
        window?.frame = UIScreen.main.bounds
        window?.makeKeyAndVisible()
        
        let tabVC = UITabBarController()
        for i in 0..<5 {
            var vc = UIViewController()
            if i == 0 {
                vc = ShortVideoController()
            }
            let navVC = UINavigationController(rootViewController: vc)
            navVC.tabBarItem = UITabBarItem(title: "首页", image: UIImage(named: "tabbar_home"), selectedImage: UIImage(named: "tabbar_home_selected"))
            tabVC.addChild(navVC)
        }
        window?.rootViewController = tabVC
        
        return true
    }


    class func setupAppearance() {
        //  UINavigationBar
        let navBar = UINavigationBar.appearance()
        navBar.setBackgroundImage(UIImage(), for: .default)
        navBar.tintColor = UIColor.blue
        navBar.barTintColor = UIColor.white

        let tabBar = UITabBar.appearance()
        tabBar.backgroundImage = UIImage()
        tabBar.tintColor = UIColor.blue
        tabBar.barTintColor = UIColor.white
    }

}

