//
//  StringExtension.swift
//  CocoaSecurity
//
//  Created by mac on 2020/2/25.
//

import Foundation
import UIKit

public extension String {
    
    //MARK:- 正则表达式
    struct Regex {
        let regex: NSRegularExpression?
        
        public init(_ pattern: String) {
            regex = try? NSRegularExpression(pattern: pattern, options: .caseInsensitive)
        }
        
        public func match(input: String) -> Bool {
            
            if let matches = regex?.matches(in: input, options: [], range: NSRange(location: 0, length: input.count)) {
                return matches.count > 0
            }
            return false
        }
    }
    
    //判断是否为邮箱
    func isEmail() -> Bool {
        let mailPattern = "^[A-Za-z]+([-_.][A-Za-z]+)*@([A-Za-z]+[-.])+[A-Za-z]{2,4}$"
        let matcher = Regex(mailPattern)
        return matcher.match(input: self)
    }
    /// 计算字符串的尺寸
    ///
    /// - Parameters:
    ///   - text: 字符串
    ///   - rectSize: 容器的尺寸
    ///   - fontSize: 字体
    /// - Returns: 尺寸
    ///
    func getStringSize(rectSize: CGSize,font: UIFont) -> CGSize {
        let str: NSString = self as NSString
        let rect = str.boundingRect(with: rectSize, options: NSStringDrawingOptions.usesLineFragmentOrigin, attributes: [NSAttributedString.Key.font: font], context: nil)
        return CGSize(width: ceil(rect.width), height: ceil(rect.height))
    }
    
    /// 给文字添加阴影
    func addShadow() -> NSMutableAttributedString {
        let shadow = NSShadow()
        shadow.shadowColor = UIColor.black.withAlphaComponent(0.35)
        shadow.shadowOffset = CGSize(width: 0, height: 1)
        shadow.shadowBlurRadius = 2;
        
        let attr = [NSAttributedString.Key.shadow: shadow]
        let attrText = NSMutableAttributedString(string: self, attributes: attr)
        return attrText;
    }
}
