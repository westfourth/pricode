//
//  UIViewExtension.swift
//  Public
//
//  Created by mac on 2019/8/29.
//  Copyright © 2019 mac. All rights reserved.
//

import UIKit

//MARK:- 判断是否是异形屏
public let IS_IPHONEX: Bool = UIScreen.main.bounds.height >= 812

//MARK:- 顶部导航条高度
public let MARGIN_TOP: CGFloat = IS_IPHONEX ? 88 : 64

//MARK:- 底部tabBar条高度
public let MARGIN_BOTTOM: CGFloat = IS_IPHONEX ? 83 : 49

 //MARK:- cellIdentifier
public extension UICollectionViewCell  {
    static func cellIdentifier()->String {
        return NSStringFromClass(self.classForCoder())
    }
}

public extension UITableViewCell {
    static func cellIdentifier ()->String {
         return NSStringFromClass(self.classForCoder())
    }
}


public extension UIDevice {
     func isIPhoneX() ->Bool {
        let H = UIScreen.main.nativeBounds.size.height
        if H == 2436 || H == 1792 || H == 2688 || H == 1624 {
            return true
        }
        return false
    }
}

public let kTop:CGFloat = {
    return IS_IPHONEX ? 88 : 64
}()


public let kBottom:CGFloat = {
    return IS_IPHONEX ? 83 : 49
}()


//public extension UIView {
//    /// 安全区域
//    var safeInsets: UIEdgeInsets {
//        get {
//            if #available(iOS 11, *) {
//                return self.safeAreaInsets
//            }
//            return .zero
//        }
//    }
//}

public extension UIView {
    
    //MARK:- 绘制圆角
    func drawRadius(withRectCorner rectCorner: UIRectCorner, withCornerRedius cornerRedius: CGFloat, withEdge edge: CGFloat = 0){
        let roundedRect = CGRect(x: edge, y: edge, width: bounds.width - edge * 2, height: bounds.height - edge * 2)
        let cornerRadii = CGSize(width: cornerRedius, height: cornerRedius)
        let path = UIBezierPath(roundedRect: roundedRect, byRoundingCorners: rectCorner, cornerRadii: cornerRadii)
        let maskLayer = CAShapeLayer()
        maskLayer.path = path.cgPath
        layer.mask = maskLayer
    }
    
}
