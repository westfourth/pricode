//
//  DateExtension.swift
//  CocoaSecurity
//
//  Created by mac on 2020/2/25.
//

public extension Date {
    /// - 转换为字符串
    func formatString(with dateFormat: String) -> String{
        let format = DateFormatter()
        format.dateFormat = dateFormat
        return format.string(from: self)
    }
    
    /// - 秒转换成00:00:00格式
    /// - Parameter secounds: secounds description
    /// - Returns: return value description
    static func getFormatPlayTime(secounds: TimeInterval) -> String {
        if secounds.isNaN { return "00:00" }
        var Min = Int(secounds / 60)
        let Sec = Int(secounds.truncatingRemainder(dividingBy: 60))
        if Min >= 60 {
            let Hour = Int(Min / 60)
            Min = Min - Hour * 60
            return String(format: "%02d:%02d:%02d", Hour, Min, Sec)
        }
        return String(format: "00:%02d:%02d", Min, Sec)
    }
    
    static func updateStringFor(date: Date) -> String {
        let t = Date().timeIntervalSince(date)
        if t < 60 {
            return "刚刚"
        }
        if t < 60 * 60 {
            let minute: Int = Int(t / 60)
            return "\(minute)分钟前"
        }
        if t < 60 * 60 * 24 {
            let hour: Int = Int(t / (60 * 60))
            return "\(hour)小时前"
        }
        if t < 60 * 60 * 24 * 30 {
            let day: Int = Int(t / (60 * 60 * 24))
            return "\(day)天前"
        }
        return "30天前"
    }
    
    /// 根据时间戳与当前时间的比较
    static func getCompareCurrntTime(timeStamp: String) -> String {
        //计算出时间戳距离现在时间的一个秒数(..s)
        let interval: TimeInterval = TimeInterval(timeStamp)!
        let date = Date(timeIntervalSince1970: interval)
        var timeInterval = date.timeIntervalSinceNow
        //得到的是一个负值 (加' - ' 得正以便后面计算)
        timeInterval = -timeInterval
        //根据时间差 做所对应的文字描述 (作为返回文字描述)
        //一分钟以内
        if interval < 60 || Int(timeInterval / 60) < 1 {
            return "刚刚"
        } else if Int(timeInterval / 60) < 60 {
            //一小时以内
            return String(format:"%@分钟前",String(Int(timeInterval / 60)))
        } else if Int((timeInterval / 60) / 60) < 24 {
            //一天以内
            return String(format:"%@小时前",String(Int((timeInterval / 60) / 60)))
        } else if Int((timeInterval / 60) / 60) < 48 {
            //一天前
            return "1天前"
        } else if Int((timeInterval / 60) / 60) < 72 {
            //两天前
            return "2天前"
        } else {
            //三天前
            //            result = "3天前"
            //            return result
            let dateformatter = DateFormatter()
            //自定义日期格式
            dateformatter.dateFormat = "MM月dd日"
            return dateformatter.string(from: date)
        }
    }
    
    /// AV模块根据时间戳与当前时间的比较
    static func getAVCompareCurrntTime(timeStamp: String) -> String {
        //计算出时间戳距离现在时间的一个秒数(..s)
        let interval: TimeInterval = TimeInterval(timeStamp)!
        let date = Date(timeIntervalSince1970: interval)
        var timeInterval = date.timeIntervalSinceNow
        //得到的是一个负值 (加' - ' 得正以便后面计算)
        timeInterval = -timeInterval
        //根据时间差 做所对应的文字描述 (作为返回文字描述)
        if Int((timeInterval / 60) / 60) < 24 {
            //一天以内
            return String(format:"更新时间：%@小时前", String(Int((timeInterval / 60) / 60)))
        } else if Int((timeInterval / 60) / 60) < 48 {
            //一天前
            return "更新时间：1天前"
        } else if Int((timeInterval / 60) / 60) < 72 {
            //两天前
            return "更新时间：2天前"
        } else {
            let dateformatter = DateFormatter()
            //自定义日期格式
            dateformatter.dateFormat = "更新时间：yyyy-MM-dd"
            return dateformatter.string(from: date)
        }
    }
}
