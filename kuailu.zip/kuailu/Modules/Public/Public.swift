//
//  Public.swift
//  Butterfly
//
//  Created by mac on 2019/8/28.
//  Copyright © 2019 mac. All rights reserved.
//

import UIKit

/*****************************************************************
                        此文件请注意精简
*****************************************************************/

/// 粗体字体
public func BFONT(_ size: CGFloat) -> UIFont {
    return UIFont.boldSystemFont(ofSize: size)
}

/// 颜色，例如：RGB(0xF7B500)
public func RGB(_ hex: UInt) -> UIColor {
    return UIColor(red: CGFloat((hex & 0xFF0000) >> 16) / 255.0,
                   green: CGFloat((hex & 0xFF00) >> 8) / 255.0,
                   blue: CGFloat(hex & 0xFF) / 255.0,
                   alpha: 1)
}

/// RGB；不需要RGBA，很少用到，withAlphaComponent
public func RGB(_ red: UInt, _ green: UInt, _ blue: UInt) -> UIColor {
    return UIColor(red: CGFloat(red) / 255.0,
                   green: CGFloat(green) / 255.0,
                   blue: CGFloat(blue) / 255.0, alpha: 1)
}

/// 异形屏判断
public func IsScreenX() -> Bool {
    if #available(iOS 11, *), UIApplication.shared.windows.first!.safeAreaInsets.bottom > 0 {
        return true
    }
    return false
}
