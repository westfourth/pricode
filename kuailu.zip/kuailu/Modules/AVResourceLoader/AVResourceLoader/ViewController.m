//
//  ViewController.m
//  AVResourceLoader
//
//  Created by mac on 2021/1/5.
//

#import "ViewController.h"
#import <AVKit/AVKit.h>
#import "PlayerView.h"
#import <MobileCoreServices/MobileCoreServices.h>
#import "XSNetwork.h"
#import "XSCacheExtension.h"
#import "XSCacheLoader.h"
#import "XSDiskCache.h"
#import "XSLengthCache.h"
#import "XSPtthScheme.h"

#if TARGET_OS_IOS
#import <CoreServices/UTType.h>
#endif

//  每次请求64k，苹果的为16k
#define MAX_REQUEST_BYTES   1<<16

//  public.mpeg-4、public.mp3
static inline NSString *ContentTypeForPathExtension(NSString *extension) {
    NSString *UTI = (__bridge_transfer NSString *)UTTypeCreatePreferredIdentifierForTag(kUTTagClassFilenameExtension, (__bridge CFStringRef)extension, NULL);
    UTI = UTI ? UTI : @"public.data";
    return UTI;
}

@interface ViewController () <AVAssetResourceLoaderDelegate> {
    XSLengthCache *_cache;
    AVPlayer *_player;
}
@property (weak, nonatomic) IBOutlet PlayerView *playerView;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    puts(NSTemporaryDirectory().UTF8String);

    [self loaderTest];
    return;

    //  https://api.itbook.store/1.0/search/mongodb
    //  http://vfx.mtime.cn/Video/2019/02/04/mp4/190204084208765161.mp4
    NSURL *url = [NSURL URLWithString:@"http://vfx.mtime.cn/Video/2019/02/04/mp4/190204084208765161.mp4"];
    NSURLRequest *req = [NSURLRequest requestWithURL:url];
    XSNetworkItem *item = [[XSNetwork default] sendRequest:req];
    item.completion = ^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
        [data writeToFile:[NSTemporaryDirectory() stringByAppendingPathComponent:@"test.mp3"] atomically:YES];
        id object = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
        puts(__func__);
    };
//    item.recvProgress = ^(int64_t a, int64_t b, int64_t c) {
//        printf(">>> %f%%\n", b * 100.0 / c);
//    };
    item.recvData = ^(NSData * _Nonnull data) {
        printf(">>> %d\n", data.length);
    };
}

- (void)fileHandleTest {
    NSString *path = [NSTemporaryDirectory() stringByAppendingPathComponent:@"abcd.txt"];
    [[NSFileManager defaultManager] createFileAtPath:path contents:nil attributes:nil];
    NSFileHandle *h = [NSFileHandle fileHandleForWritingAtPath:path];
    NSData *data = [@"abcd" dataUsingEncoding:NSUTF8StringEncoding];
    NSError *error = nil;
    [h writeData:data error:&error];
    [h closeAndReturnError:&error];
}

- (void)writeTest {
    NSString *path2 = [NSTemporaryDirectory() stringByAppendingPathComponent:@"test.txt"];
    NSData *data = [@"沃达丰" dataUsingEncoding:NSUTF8StringEncoding];
    [data writeToFile:path2 atomically:YES];
}

- (void)loaderTest {
    NSURL *url = [NSURL URLWithString:@"http://clips.vorwaerts-gmbh.de/big_buck_bunny.mp4"];
    
    [XSCacheLoader share].logEnabled = YES;
    AVURLAsset *asset = [[XSCacheLoader share] assetWithURL:url];
    AVPlayerItem *item = [AVPlayerItem playerItemWithAsset:asset];
    _player = [AVPlayer playerWithPlayerItem:item];
    
//    AVPlayerLayer *playerLayer = (AVPlayerLayer *)self.playerView.layer;
//    playerLayer.player = _player;
    [_player play];
    
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        AVPlayerViewController *vc = [AVPlayerViewController new];
        vc.player = _player;
        [self presentViewController:vc animated:YES completion:nil];
    });
    
//    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
//        puts(">>> seekToTime start");
//        [_player seekToTime:CMTimeMake(15, 1) completionHandler:^(BOOL finished) {
//            puts(">>> seekToTime end");
//        }];
//    });
}

//- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
//    puts(__func__);
//    NSURL *url = [NSURL URLWithString:@"http://vfx.mtime.cn/Video/2019/02/04/mp4/190204084208765161.mp4"];
//
//    AVURLAsset *asset = [[XSCacheLoader share] assetWithURL:url];
//    AVPlayerItem *item = [AVPlayerItem playerItemWithAsset:asset];
//    [_player replaceCurrentItemWithPlayerItem:item];
//}

- (void)diskCacheWriteTest {
    NSURL *url = [NSURL URLWithString:@"http://vfx.mtime.cn/Video/2019/02/04/mp4/190204084208765161.mp4"];
    NSString *fileName = @"771c9f07b6a59692b438d35c43e0bd21.mp4";
    NSString *path = [[NSBundle mainBundle] pathForResource:fileName ofType:nil];
    NSData *data = [NSData dataWithContentsOfFile:path];
    
    NSUInteger count = data.length / DISK_CACHE_SIZE;
    if (data.length % DISK_CACHE_SIZE != 0) count++;
    
    for (int i = 0; i < count; i++) {
        NSUInteger len = i < count - 1 ? DISK_CACHE_SIZE : data.length % DISK_CACHE_SIZE;
        NSRange range = NSMakeRange(i * DISK_CACHE_SIZE, len);
        NSData *subData = [data subdataWithRange:range];
        
        [XSDiskCache write:url data:subData offset:i * DISK_CACHE_SIZE contentLength:data.length];
    }
}

- (void)readTest {
    NSURL *url = [NSURL URLWithString:@"http://vfx.mtime.cn/Video/2019/02/04/mp4/190204084208765161.mp4"];
    
    NSData *data = [XSDiskCache read:url offset:1<<20];
    NSString *path = [NSTemporaryDirectory() stringByAppendingPathComponent:@"test.bbb"];
    [data writeToFile:path atomically:YES];
}

//MARK:-

- (BOOL)resourceLoader:(AVAssetResourceLoader *)resourceLoader shouldWaitForLoadingOfRequestedResource:(AVAssetResourceLoadingRequest *)loadingRequest {
//    puts(__func__);
    [self remote:loadingRequest];
    return YES;
}

- (void)resourceLoader:(AVAssetResourceLoader *)resourceLoader didCancelLoadingRequest:(AVAssetResourceLoadingRequest *)loadingRequest {
    puts(__func__);
}

- (void)local:(AVAssetResourceLoadingRequest *)loadingRequest {
    NSString *fileName = @"771c9f07b6a59692b438d35c43e0bd21.mp4";
    NSString *path = [[NSBundle mainBundle] pathForResource:fileName ofType:nil];
    NSData *data = [NSData dataWithContentsOfFile:path];

    //  contentType
    NSString *extension = loadingRequest.request.URL.pathExtension;
    NSString *UTI = (__bridge_transfer NSString *)UTTypeCreatePreferredIdentifierForTag(kUTTagClassFilenameExtension, (__bridge CFStringRef)extension, NULL);
    
    //  contentInformationRequest
    AVAssetResourceLoadingContentInformationRequest *contentInfoRequest = loadingRequest.contentInformationRequest;
    contentInfoRequest.contentLength = data.length;
    contentInfoRequest.contentType = UTI;
    contentInfoRequest.byteRangeAccessSupported = YES;
    
    //  dataRequest
    AVAssetResourceLoadingDataRequest *dataRequest = loadingRequest.dataRequest;
    //  每次最多1M
    NSInteger length = MIN(dataRequest.requestedLength, MAX_REQUEST_BYTES);
    NSRange range = NSMakeRange(dataRequest.requestedOffset, length);
    NSData *subData = [data subdataWithRange:range];
    [dataRequest respondWithData:subData];

    [loadingRequest finishLoading];
}


- (void)remote:(AVAssetResourceLoadingRequest *)loadingRequest {
    NSURLComponents *components = [NSURLComponents componentsWithURL:loadingRequest.request.URL resolvingAgainstBaseURL:YES];
    components.scheme = @"http";
    NSMutableURLRequest *req = [NSMutableURLRequest requestWithURL:components.URL];
    req.cachePolicy = NSURLRequestReloadIgnoringLocalAndRemoteCacheData;
    
    printf(">>> offset = %lld, length = %ld, curOffset = %lld\n", loadingRequest.dataRequest.requestedOffset, loadingRequest.dataRequest.requestedLength, loadingRequest.dataRequest.currentOffset);
    
    NSAssert(loadingRequest.dataRequest.requestedOffset == loadingRequest.dataRequest.currentOffset, @"不想等");
    
    //  每次最多1M
    NSInteger length = MIN(loadingRequest.dataRequest.requestedLength, MAX_REQUEST_BYTES);
    NSString *range = [NSString stringWithFormat:@"bytes=%lld-%lld", loadingRequest.dataRequest.requestedOffset, loadingRequest.dataRequest.requestedOffset + length -1];
    [req setValue:range forHTTPHeaderField:@"Range"];
    
    NSURLSessionDataTask *task = [[NSURLSession sharedSession] dataTaskWithRequest:req completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
            
        //  contentType
        NSString *extension = response.MIMEType;
        NSString *UTI = (__bridge_transfer NSString *)UTTypeCreatePreferredIdentifierForTag(kUTTagClassFilenameExtension, (__bridge CFStringRef)extension, NULL);
        
        //  Content-Range
        NSString *contentRange = [(NSHTTPURLResponse *)response valueForHTTPHeaderField:@"Content-Range"];
        long long start = 0;
        long long end = 0;
        long size = 0;
        [ViewController contentRange:contentRange start:&start end:&end size:&size];
        
        //  contentInformationRequest
        AVAssetResourceLoadingContentInformationRequest *contentInfoRequest = loadingRequest.contentInformationRequest;
        contentInfoRequest.contentLength = size;
        contentInfoRequest.contentType = UTI;
        contentInfoRequest.byteRangeAccessSupported = YES;
        
        //  dataRequest
        AVAssetResourceLoadingDataRequest *dataRequest = loadingRequest.dataRequest;
        [dataRequest respondWithData:data];

        [loadingRequest finishLoading];
    }];
    [task resume];

}

+ (void)contentRange:(NSString *)text start:(long long *)start end:(long long *)end size:(long *)size {
    NSError *error = nil;
    NSString *pattern;
    NSRegularExpression *regexp;
    NSRange firstRange;
    NSString *matchText = nil;
    
    //  start
    pattern = @"(?<=bytes )\\d+(?=-)";
    regexp = [NSRegularExpression regularExpressionWithPattern:pattern options:0 error:&error];
    firstRange = [regexp rangeOfFirstMatchInString:text options:0 range:NSMakeRange(0, text.length)];
    matchText = [text substringWithRange:firstRange];
    *start = [matchText longLongValue];
    
    //  end
    pattern = @"(?<=-)\\d+(?=/)";
    regexp = [NSRegularExpression regularExpressionWithPattern:pattern options:0 error:&error];
    firstRange = [regexp rangeOfFirstMatchInString:text options:0 range:NSMakeRange(0, text.length)];
    matchText = [text substringWithRange:firstRange];
    *end = [matchText longLongValue];
    
    //  end
    pattern = @"(?<=/)\\d+";
    regexp = [NSRegularExpression regularExpressionWithPattern:pattern options:0 error:&error];
    firstRange = [regexp rangeOfFirstMatchInString:text options:0 range:NSMakeRange(0, text.length)];
    matchText = [text substringWithRange:firstRange];
    *size = [matchText longLongValue];
}

@end
