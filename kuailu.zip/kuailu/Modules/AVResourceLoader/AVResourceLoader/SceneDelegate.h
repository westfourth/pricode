//
//  SceneDelegate.h
//  AVResourceLoader
//
//  Created by mac on 2021/1/5.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

