//
//  PlayerView.h
//  AVResourceLoader
//
//  Created by mac on 2021/1/8.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface PlayerView : UIView

@end

@protocol PlayerView <NSObject>

+ (int)add;

@end

NS_ASSUME_NONNULL_END
