//
//  PlayerView.m
//  AVResourceLoader
//
//  Created by mac on 2021/1/8.
//

#import "PlayerView.h"
#import <AVKit/AVKit.h>

@implementation PlayerView

+ (Class)layerClass {
    return [AVPlayerLayer class];
}

@end
