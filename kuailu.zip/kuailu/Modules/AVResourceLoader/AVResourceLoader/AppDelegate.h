//
//  AppDelegate.h
//  AVResourceLoader
//
//  Created by mac on 2021/1/5.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>


@end

