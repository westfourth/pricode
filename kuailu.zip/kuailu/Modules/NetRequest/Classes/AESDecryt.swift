//
//  Decryt.swift
//  NetRequest
//
//  Created by mac on 2020/5/5.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit
import CryptoSwift

 class AESDecryt: NSObject {
 
    //MARK:- 获取解密key
      private static func decrKey()->String? {
           guard let token = NetDefaults.token else {
               return nil
           }
           let index =  token.index(token.startIndex, offsetBy: 2)
           let endIndex  = token.index(token.startIndex, offsetBy: 18)
           let keyStr = token[index ..< endIndex]
           let key = String(keyStr)
           return key
       }
       
         //MARK:- AES解密接口
         /// - Parameters:
         ///   - content: 内容
       static func decry( _ content:String)->Any? {
           guard let key = decrKey() else {
               return nil
           }
           // decode AES
           var decrypted:[UInt8] = [UInt8]()
           var encrypted: [UInt8] = [UInt8]()
           
           let data = NSData(base64Encoded: content, options: NSData.Base64DecodingOptions.init(rawValue: 0))
           let count = data?.length
           for i in 0..<count! {
               var temp:UInt8 = 0
               data?.getBytes(&temp, range: NSRange(location: i,length:1 ))
               encrypted.append(temp)
           }
           do {
               decrypted = try AES(key:key.bytes,blockMode: CBC(iv: key.bytes),padding: .pkcs7).decrypt(encrypted)
           } catch {}
           let encoded = Data(decrypted)
           do {
               let json = try? JSONSerialization.jsonObject(with: encoded, options: JSONSerialization.ReadingOptions.allowFragments)
               return json
           }
       }
}
