//
//  VipHeaderView.swift
//  Sp
//
//  Created by mac on 2020/9/23.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class VipHeaderView: UIView {
    
    private static let avatarSize: CGFloat = 44
    
    private static let bgImgHeight: CGFloat = VipHeaderView.viewHeight - 35
    
    private static let cardImgWidth: CGFloat = UIScreen.main.bounds.width - 12 * 2
    
    private static let cardImgHeight: CGFloat = VipHeaderView.cardImgWidth / 336 * 150
    
    private static let cardMarginTop: CGFloat = kTop + 10
    
    private static let formatDate:DateFormatter = {
        let dateFormat = DateFormatter()
        dateFormat.dateFormat = "yyyy-MM-dd"
        return dateFormat
    }()
    
    static let viewHeight: CGFloat = VipHeaderView.cardImgHeight + VipHeaderView.cardMarginTop + 16
    
    private static let bgImg: UIImage? = {
        return UIImage(named: "vip_header_bg")
    }()
    
    private static let cardImg: UIImage? = {
        return UIImage(named: "vip_card_bg")
    }()
    
    private static let avatarDefaultImg: UIImage? = {
        return UIImage(named: "vip_default_avatar")
    }()
    
    private static let levelImgList: [UIImage?] = {
        return [UIImage(named: "v1"), UIImage(named: "v2"), UIImage(named: "v3"), UIImage(named: "v4"), UIImage(named: "v5"), UIImage(named: "v6")]
    }()
    
    private static let levelProgressLineImg: UIImage? = {
        return UIImage(named: "vip_level_progress_line")
    }()
    
    private static let levelProgressDotImg: UIImage? = {
        return UIImage(named: "vip_level_progress_dot")
    }()
    
    private static let exchangeImg: UIImage? = {
        return UIImage(named: "vip_exchange_icon")
    }()
    
    private lazy var bgImgView: UIImageView = {
        let imgView = UIImageView(image: VipHeaderView.bgImg)
        imgView.contentMode = .scaleAspectFill
        imgView.layer.masksToBounds = true
        return imgView
    }()
    
    private lazy var cardImgView: UIImageView = {
        let imgView = UIImageView(image: VipHeaderView.cardImg)
        imgView.layer.masksToBounds = true
        imgView.layer.cornerRadius = 6
        imgView.contentMode = .scaleAspectFill
        return imgView
    }()
    
    private lazy var avatarImgView: UIImageView = {
        let imgView = UIImageView(image: VipHeaderView.avatarDefaultImg)
        imgView.contentMode = .scaleAspectFill
        imgView.layer.masksToBounds = true
        imgView.layer.cornerRadius = VipHeaderView.avatarSize / 2
        return imgView
    }()
    
    private lazy var nicknameLabel: UILabel = {
        let label = UILabel()
        label.textColor = .white
        label.font = UIFont.pingFangRegular(12)
        return label
    }()
    
    private lazy var levelImgView: UIImageView = {
        let imgView = UIImageView()
        imgView.layer.masksToBounds = true
        imgView.isHidden = true
        return imgView
    }()
    
    private lazy var generalUserLabel: UILabel = {
        let label = UILabel()
        label.text = "開通\(Sensitive.hui)專享更多特權"
        label.textColor = .white
        label.font = UIFont.pingFangRegular(12)
        return label
    }()
    
    lazy var remainingCoinLabel: UILabel = {
        let label = UILabel()
        label.text = "剩餘\(Sensitive.jin)：\(Int(NetDefaults.accountInfo?.gold ?? WalletVC.coinVal))"
        label.textColor = RGB(0xE5C2AC)
        label.font = UIFont.pingFangRegular(12)
        label.isHidden = true
        return label
    }()
    
    private lazy var vipUserLabel: UILabel = {
        let label = UILabel()
        label.textColor = RGB(0xE5C2AC)
        label.font = UIFont.pingFangRegular(12)
        label.isHidden = true
        return label
    }()
    
    private lazy var levelProgressLineView: UIImageView = {
        let imgView = UIImageView(image: VipHeaderView.levelProgressLineImg)
        imgView.contentMode = .scaleAspectFill
        return imgView
    }()
    
    private lazy var levelProgressDotView: UIImageView = {
        let imgView = UIImageView(image: VipHeaderView.levelProgressDotImg)
        imgView.isHidden = true
        return imgView
    }()
    
    private lazy var previousLevelLabel: UILabel = {
        let label = UILabel()
        label.text = "v"
        label.textColor = .white
        label.font = UIFont.italicSystemFont(ofSize: 15)
        label.isHidden = true
        return label
    }()
    
    private lazy var previousLevelValLabel: UILabel = {
        let label = UILabel()
        label.textColor = .white
        label.font = UIFont.pingFangRegular(9)
        return label
    }()
    
    private lazy var currrentLabel: UILabel = {
        let label = UILabel()
        label.textColor = .white
        label.font = UIFont.pingFangRegular(12)
        return label
    }()
    
    private lazy var nextLevelLabel: UILabel = {
        let label = UILabel()
        label.text = "v"
        label.textColor = .white
        label.font = UIFont.italicSystemFont(ofSize: 15)
        label.isHidden = true
        return label
    }()
    
    private lazy var nextLevelValLabel: UILabel = {
        let label = UILabel()
        label.textColor = .white
        label.font = UIFont.pingFangRegular(9)
        return label
    }()
    
    private lazy var levelProgressLineWrapperView: UIView = {
        let view = UIView()
        view.addSubview(levelProgressLineView)
        view.addSubview(levelProgressDotView)
        view.addSubview(previousLevelLabel)
        view.addSubview(previousLevelValLabel)
        view.addSubview(nextLevelValLabel)
        view.addSubview(nextLevelLabel)
        view.addSubview(currrentLabel)
        
        levelProgressLineView.snp.makeConstraints { (make) in
            make.centerY.left.right.equalToSuperview()
            make.height.equalTo(2)
        }
        
        levelProgressDotView.snp.makeConstraints { (make) in
            make.centerY.equalTo(levelProgressLineView)
            make.centerX.equalToSuperview()
            make.size.equalTo(13)
        }
        
        currrentLabel.snp.makeConstraints { (make) in
            make.centerX.equalTo(levelProgressDotView)
            make.bottom.equalTo(levelProgressLineView.snp.top).offset(-5)
        }
        
        previousLevelLabel.snp.makeConstraints { (make) in
            make.left.equalToSuperview()
            make.top.equalTo(levelProgressLineView.snp.bottom).offset(5)
        }
        
        previousLevelValLabel.snp.makeConstraints { (make) in
            make.left.equalTo(previousLevelLabel.snp.right)
            make.bottom.equalTo(previousLevelLabel)
        }
        
        nextLevelValLabel.snp.makeConstraints { (make) in
            make.right.equalToSuperview()
            make.centerY.equalTo(previousLevelValLabel)
        }
        
        nextLevelLabel.snp.makeConstraints { (make) in
            make.right.equalTo(nextLevelValLabel.snp.left)
            make.centerY.equalTo(previousLevelLabel)
        }
        
        return view
    }()
    
    private lazy var exchangeBtn: UIButton = {
        let btn = UIButton()
        btn.setBackgroundImage(VipHeaderView.exchangeImg, for: .normal)
        btn.addTarget(self, action: #selector(onExchangeBtn), for: .touchUpInside)
        return btn
    }()
    
    var userinfo: UserBase? {
        didSet {
            guard let item = userinfo else { return }
            avatarImgView.kf.setImage(with: item.logo, placeholder: VipHeaderView.avatarDefaultImg, options: SearchResultVideoCell.animationOption)
            nicknameLabel.text = item.nickName
            if item.level > 0, item.level <= VipHeaderView.levelImgList.count {
                levelImgView.image = VipHeaderView.levelImgList[item.level - 1]
                levelImgView.isHidden = false
            } else {
                levelImgView.isHidden = true
            }
            if item.freeWatches == -1 {
                generalUserLabel.isHidden = true
                remainingCoinLabel.isHidden = true
                vipUserLabel.text = "會員有效期：\(VipHeaderView.formatDate.string(from: item.expiredVip ?? Date()))（使用中）"
                vipUserLabel.isHidden = false
            } else if VipCardType(rawValue: activePageIndex) == .coin {
                generalUserLabel.isHidden = true
                vipUserLabel.isHidden = true
                remainingCoinLabel.isHidden = false
            } else {
                vipUserLabel.isHidden = true
                remainingCoinLabel.isHidden = true
                generalUserLabel.isHidden = false
            }
        }
    }
    
    var userGrade: UserGradeResp? {
        didSet {
            guard let item = userGrade, !item.gradeList.isEmpty, item.level <= item.gradeList.count, item.level > 0 else { return }
            previousLevelLabel.isHidden = false
            previousLevelValLabel.text = "\(item.level)"
            let currentLevelGrade = item.gradeList[item.level - 1]
            let previousLevelVal = currentLevelGrade.startScore
            let nextLevelVal = currentLevelGrade.endScore
            currrentLabel.text = "\(item.rechargeTotal < 0 ? 0 : item.rechargeTotal)/\(nextLevelVal)"
            nextLevelValLabel.isHidden = item.level >= item.gradeList.count
            nextLevelLabel.isHidden = nextLevelValLabel.isHidden
            nextLevelValLabel.text = "\(nextLevelValLabel.isHidden ? 6 : item.level + 1)"
            let rawRate = CGFloat(item.rechargeTotal - previousLevelVal) * 2 / CGFloat(nextLevelVal - previousLevelVal)
            let rate = rawRate <= 0.01 ? 0.01 : rawRate > 2 ? 2 : rawRate
            levelProgressDotView.snp.remakeConstraints { (make) in
                make.centerY.equalTo(levelProgressLineView)
                make.centerX.equalToSuperview().multipliedBy(rate)
                make.size.equalTo(13)
            }
            levelProgressDotView.isHidden = false
        }
    }
    
    var activePageIndex: Int = 0 {
        didSet {
            if VipCardType(rawValue: activePageIndex) == .coin {
                generalUserLabel.isHidden = true
                vipUserLabel.isHidden = true
                remainingCoinLabel.isHidden = false
            } else if let userinfo = NetDefaults.userInfo, userinfo.freeWatches == -1 {
                generalUserLabel.isHidden = true
                remainingCoinLabel.isHidden = true
                vipUserLabel.text = "會員有效期：\(VipHeaderView.formatDate.string(from: userinfo.expiredVip ?? Date()))（使用中）"
                vipUserLabel.isHidden = false
            } else {
                vipUserLabel.isHidden = true
                remainingCoinLabel.isHidden = true
                generalUserLabel.isHidden = false
            }
        }
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        renderView()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func renderView() {
        addSubview(bgImgView)
        addSubview(cardImgView)
        addSubview(avatarImgView)
        addSubview(nicknameLabel)
        addSubview(levelImgView)
        addSubview(generalUserLabel)
        addSubview(vipUserLabel)
        addSubview(remainingCoinLabel)
        addSubview(levelProgressLineWrapperView)
        addSubview(exchangeBtn)
        
        bgImgView.snp.makeConstraints { (make) in
            make.top.left.right.equalToSuperview()
            make.height.equalTo(VipHeaderView.bgImgHeight)
        }
        
        cardImgView.snp.makeConstraints { (make) in
            make.top.equalToSuperview().inset(VipHeaderView.cardMarginTop)
            make.centerX.equalToSuperview()
            make.width.equalTo(VipHeaderView.cardImgWidth)
            make.height.equalTo(VipHeaderView.cardImgHeight)
        }
        
        avatarImgView.snp.makeConstraints { (make) in
            make.left.equalTo(cardImgView).offset(19)
            make.top.equalTo(cardImgView).offset(16)
            make.size.equalTo(VipHeaderView.avatarSize)
        }
        
        nicknameLabel.snp.makeConstraints { (make) in
            make.top.equalTo(avatarImgView).offset(3)
            make.left.equalTo(avatarImgView.snp.right).offset(16)
            make.height.equalTo(18)
        }
        
        levelImgView.snp.makeConstraints { (make) in
            make.centerY.equalTo(nicknameLabel)
            make.left.equalTo(nicknameLabel.snp.right).offset(4)
            make.width.equalTo(39)
            make.height.equalTo(14)
        }
        
        generalUserLabel.snp.makeConstraints { (make) in
            make.left.equalTo(nicknameLabel)
            make.top.equalTo(nicknameLabel.snp.bottom).offset(4)
        }
        
        vipUserLabel.snp.makeConstraints { (make) in
            make.left.equalTo(nicknameLabel)
            make.top.equalTo(nicknameLabel.snp.bottom).offset(4)
        }
        
        remainingCoinLabel.snp.makeConstraints { (make) in
            make.left.equalTo(nicknameLabel)
            make.top.equalTo(nicknameLabel.snp.bottom).offset(4)
        }
        
        levelProgressLineWrapperView.snp.makeConstraints { (make) in
            make.top.equalTo(avatarImgView.snp.bottom).offset(16)
            make.left.equalTo(cardImgView).offset(19)
            make.right.equalTo(cardImgView).offset(-19)
            make.height.equalTo(42)
        }
        
        exchangeBtn.snp.makeConstraints { (make) in
            make.bottom.equalTo(cardImgView).offset(-6)
            make.right.equalToSuperview().inset(19)
            make.width.equalTo(112)
            make.height.equalTo(25)
        }
    }
    
    @objc private func onExchangeBtn() {
        guard let navigationController = (UIApplication.shared.delegate as? AppDelegate)?.currentNavigationController else { return }
        navigationController.show(ExchangeVC(), sender: nil)
    }
    
}
