//
//  VipPayBtn.swift
//  Sp
//
//  Created by mac on 2020/9/23.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

enum VipPayBtnType {
    case fixed
    case float
}

protocol VipPayBtnDelegate: NSObjectProtocol {
    
    func onVipPayBtnTap()
    
}

class VipPayBtn: UIView {
    
    static let viewHeight: CGFloat = 60 + 20
    
    private static let barHeight: CGFloat = 60
    
    private static let btnWidth: CGFloat = 137
    
    private lazy var tipLabel: UILabel = {
        let label = UILabel()
        label.text = "（每日\(Sensitive.chong)額度庫存有限,\(Sensitive.chong)失敗時請嘗試其他額度,或稍後再試）"
        label.textColor = RGB(0x212121)
        label.font = UIFont.pingFangRegular(11)
        label.textAlignment = .center
        return label
    }()
    
    private lazy var payPrefixLabel: UILabel = {
        let label = UILabel()
        label.text = "應付"
        label.textColor = .white
        label.font = UIFont.pingFangRegular(14)
        return label
    }()
    
    private lazy var paySuffixLabel: UILabel = {
        let label = UILabel()
        label.text = "元"
        label.textColor = .white
        label.font = UIFont.pingFangRegular(14)
        return label
    }()
    
    private lazy var valLabel: UILabel = {
        let label = UILabel()
        label.text = "0"
        label.textColor = RGB(0xFA6400)
        label.font = UIFont.pingFangMedium(24)
        label.textAlignment = .center
        return label
    }()
    
    private lazy var valWrapperView: UIView = {
        let view = UIView()
        view.addSubview(valLabel)
        view.addSubview(payPrefixLabel)
        view.addSubview(paySuffixLabel)
        
        valLabel.snp.makeConstraints { (make) in
            make.center.equalToSuperview()
        }
        
        payPrefixLabel.snp.makeConstraints { (make) in
            make.right.equalTo(valLabel.snp.left).offset(-8)
            make.centerY.equalTo(valLabel).offset(2)
        }
        
        paySuffixLabel.snp.makeConstraints { (make) in
            make.left.equalTo(valLabel.snp.right).offset(5)
            make.bottom.equalTo(payPrefixLabel)
        }
        view.backgroundColor = RGB(0x212121)
        return view
    }()
    
    private lazy var confirmGradientLayer: CAGradientLayer = {
        let gradientColors = [RGB(0xF86104).cgColor, RGB(0xFA9C18).cgColor]
        let gradientLocations:[NSNumber] = [0, 1]
        let gradientLayer = CAGradientLayer()
        gradientLayer.colors = gradientColors
        gradientLayer.locations = gradientLocations
        gradientLayer.startPoint = CGPoint(x: 0, y: 1)
        gradientLayer.endPoint  = CGPoint(x: 1, y: 1)
        gradientLayer.frame = CGRect(x: 0, y: 0, width: VipPayBtn.btnWidth, height: VipPayBtn.barHeight)
        return gradientLayer
    }()
    
    private lazy var payBtn: UIButton = {
        let btn = UIButton()
        btn.setTitleColor(.white, for: .normal)
        btn.addTarget(self, action: #selector(onPayBtnTap), for: .touchUpInside)
        btn.layer.insertSublayer(confirmGradientLayer, at: 0)
        return btn
    }()
    
    weak var delegate: VipPayBtnDelegate?
    
    var type: VipPayBtnType = .fixed
    
    var price: Double = 0 {
        didSet {
            valLabel.text = numberZeroTruncationFormat(price)
            payBtn.setTitle("\(type == .fixed ? "確認\(Sensitive.kuan)" : "立即\(Sensitive.kuan)")", for: .normal)
        }
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        renderView()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func renderView() {
        addSubview(tipLabel)
        addSubview(payBtn)
        addSubview(valWrapperView)
        
        payBtn.snp.makeConstraints { (make) in
            make.right.bottom.equalToSuperview()
            make.width.equalTo(VipPayBtn.btnWidth)
            make.height.equalTo(VipPayBtn.barHeight)
        }
        
        tipLabel.snp.makeConstraints { (make) in
            make.top.left.right.equalToSuperview()
        }
        
        valWrapperView.snp.makeConstraints { (make) in
            make.left.bottom.equalToSuperview()
            make.height.equalTo(VipPayBtn.barHeight)
            make.right.equalTo(payBtn.snp.left)
        }
        
    }
    
    @objc private func onPayBtnTap() {
        delegate?.onVipPayBtnTap()
    }
    
}
