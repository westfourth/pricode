
//
//  VipChargeTipVC.swift
//  Sp
//
//  Created by mac on 2020/3/12.
//  Copyright © 2020 mac. All rights reserved.
//


class VipChargeTipVC: UIViewController {
    
    static var isFromVideoPlayList: Bool = false
    
    private lazy var leftImgView: UIImageView = {
        let imgView = UIImageView(image: UIImage(named: "vip_tip_bg"))
        return imgView
    }()
    
    private lazy var rightImgView: UIImageView = {
        let imgView = UIImageView(image: UIImage(named: "vip_tip_coin"))
        return imgView
    }()
    
    private lazy var tipIconImgView: UIImageView = {
        let imgView = UIImageView(image: UIImage(named: "vip_tip_icon"))
        return imgView
    }()
    
    private lazy var titleLabel: UILabel = {
        let label = UILabel()
        label.text = "\(Sensitive.zhi)確認中..."
        label.font = UIFont.pingFangMedium(18)
        label.textColor = .white
        return label
    }()
    
    private lazy var tipTitleLabel: UILabel = {
        let label = UILabel()
        label.text = "溫馨提示"
        label.font = UIFont.pingFangMedium(14)
        label.textColor = .white
        return label
    }()
    
    private lazy var tipLabel: UILabel = {
        let label = UILabel()
        label.numberOfLines = 0
        let ruleTipText = """
        \(Sensitive.zhi)後，若30分鐘後未到賬，請點擊【消息】
        聯繫在線客服，發送\(Sensitive.zhi)截圖憑證為您處理。
        """
        let paraph = NSMutableParagraphStyle()
        paraph.lineSpacing = 4 // 字型的行間距
        let attributes = [NSAttributedString.Key.font: UIFont.pingFangRegular(12),
                          NSAttributedString.Key.foregroundColor: UIColor.white,
                          NSAttributedString.Key.paragraphStyle: paraph]
        label.attributedText = NSAttributedString(string: ruleTipText, attributes: attributes)
        return label
    }()
    
    private lazy var gradientLayer: CAGradientLayer = {
        let gradientColors = [RGB(0xF86104).cgColor, RGB(0xFA9C18).cgColor]
        let gradientLocations:[NSNumber] = [0, 1]
        let gradientLayer = CAGradientLayer()
        gradientLayer.colors = gradientColors
        gradientLayer.locations = gradientLocations
        gradientLayer.startPoint = CGPoint(x: 0, y: 1)
        gradientLayer.endPoint  = CGPoint(x: 1.0, y: 1)
        gradientLayer.frame = CGRect(x: 0, y: 0, width: 240, height: 42)
        return gradientLayer
    }()
    
    private lazy var comfirmBtn: UIButton = {
        let btn = UIButton()
        btn.setTitle("繼續觀看視頻", for: .normal)
        btn.setTitleColor(.white, for: .normal)
        btn.titleLabel?.font = UIFont.pingFangRegular(18)
        btn.backgroundColor = RGB(0xF86104)
        btn.layer.cornerRadius = 21
        btn.clipsToBounds = true
        btn.addTarget(self, action: #selector(onBtnClick), for: .touchUpInside)
        btn.layer.insertSublayer(gradientLayer, at: 0)
        return btn
    }()
    
    override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: Bundle?) {
        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
        hidesBottomBarWhenPushed = true
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = RGB(0x141516)
        navigationItem.title = "\(Sensitive.chong)流程提示"
        navigationController?.navigationBar.barTintColor = RGB(0x141516)
        renderView()
    }
    
    deinit {
        VipChargeTipVC.isFromVideoPlayList = false
    }
    
    private func renderView() {
        view.addSubview(leftImgView)
        view.addSubview(rightImgView)
        view.addSubview(titleLabel)
        view.addSubview(tipIconImgView)
        view.addSubview(tipLabel)
        view.addSubview(tipTitleLabel)
        
        leftImgView.snp.makeConstraints { (make) in
            make.top.equalTo(88)
            make.centerX.equalToSuperview().offset(-10)
            make.width.equalTo(179)
            make.height.equalTo(184)
        }
        
        rightImgView.snp.makeConstraints { (make) in
            make.centerY.equalTo(leftImgView).offset(10)
            make.centerX.equalToSuperview().offset(100)
            make.width.equalTo(78)
            make.height.equalTo(71)
        }
        
        titleLabel.snp.makeConstraints { (make) in
            make.top.equalTo(leftImgView.snp.bottom).offset(6)
            make.centerX.equalToSuperview()
        }
        
        tipTitleLabel.snp.makeConstraints { (make) in
            make.top.equalTo(titleLabel.snp.bottom).offset(48)
            make.centerX.equalToSuperview().offset(10)
        }
        
        tipIconImgView.snp.makeConstraints { (make) in
            make.centerY.equalTo(tipTitleLabel)
            make.centerX.equalToSuperview().offset(-30)
            make.size.equalTo(16)
        }
        
        tipLabel.snp.makeConstraints { (make) in
            make.top.equalTo(titleLabel.snp.bottom).offset(77)
            make.centerX.equalToSuperview()
        }
        
        if VipChargeTipVC.isFromVideoPlayList {
            view.addSubview(comfirmBtn)
            comfirmBtn.snp.makeConstraints { (make) in
                make.bottom.equalToSuperview().inset(60)
                make.centerX.equalToSuperview()
                make.width.equalTo(240)
                make.height.equalTo(42)
            }
        }
    }
    
    @objc private func onBtnClick() {
        let viewControllers = navigationController!.viewControllers
        guard viewControllers.count > 2 else {
            navigationController?.popViewController(animated: true)
            return
        }
        navigationController?.popToViewController(viewControllers[viewControllers.count - 3], animated: true)
    }
}
