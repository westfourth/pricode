

import UIKit

class VipChargeDetailsBtn: UIButton {
    
    static let viewHeight: CGFloat = 45
    
    private static let iconImg: UIImage? = {
        return UIImage(named: "vip_charge_details_icon")
    }()
    
    private static let arrowImg: UIImage? = {
        return UIImage(named: "mine_arrow_right")
    }()
    
    private lazy var iconImgView: UIImageView = {
        let imgView = UIImageView(image: VipChargeDetailsBtn.iconImg)
        return imgView
    }()
    
    private lazy var subjectLabel: UILabel = {
        let label = UILabel()
        label.text = "\(Sensitive.chong)記錄"
        label.textColor = RGB(0x555555)
        label.font = UIFont.pingFangLight(15)
        return label
    }()
    
    private lazy var arrowImgView: UIImageView = {
        let imgView = UIImageView(image: VipChargeDetailsBtn.arrowImg)
        return imgView
    }()
    
    private lazy var bottomLine: UIView = {
        let view = UIView()
        view.backgroundColor = RGB(0xF5F6F7)
        return view
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        addTarget(self, action: #selector(onTap), for: .touchUpInside)
        renderView()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func renderView() {
        addSubview(iconImgView)
        addSubview(subjectLabel)
        addSubview(arrowImgView)
        addSubview(bottomLine)
        
        iconImgView.snp.makeConstraints { (make) in
            make.left.equalToSuperview().inset(12)
            make.centerY.equalToSuperview()
            make.width.equalTo(20)
            make.height.equalTo(15)
        }
        
        subjectLabel.snp.makeConstraints { (make) in
            make.left.equalTo(iconImgView.snp.right).offset(5)
            make.centerY.equalToSuperview()
        }
        
        arrowImgView.snp.makeConstraints { (make) in
            make.centerY.equalToSuperview()
            make.right.equalToSuperview().inset(18)
            make.width.equalTo(6)
            make.height.equalTo(10)
        }
        
        bottomLine.snp.makeConstraints { (make) in
            make.left.right.bottom.equalToSuperview()
            make.height.equalTo(1)
        }
    }
    
    @objc private func onTap() {
        guard let navigationController = (UIApplication.shared.delegate as? AppDelegate)?.currentNavigationController else { return }
        navigationController.show(VipRecordListVC(), sender: nil)
    }
    
}
