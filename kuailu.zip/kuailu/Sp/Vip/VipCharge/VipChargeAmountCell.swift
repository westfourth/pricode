//
//  VipChargeAmountCell.swift
//  Sp
//
//  Created by mac on 2020/2/29.
//  Copyright © 2020 mac. All rights reserved.
//


class VipChargeAmountCell: UICollectionViewCell {
    
    static let itemWidth: CGFloat = 104
    
    static let itemHeight: CGFloat = 135
    
    private static let chosenImg: UIImage? = {
        return UIImage(named: "vip_card_chosen_icon")
    }()
    
    private static let newcomerImg: UIImage? = {
        return UIImage(named: "vip_newcomer_discount_icon")
    }()
    
    private static let disPriceAttributes: [NSAttributedString.Key : Any] = {
        return [NSAttributedString.Key.font:  UIFont.pingFangRegular(33),
                NSAttributedString.Key.foregroundColor: RGB(0xFAB954)]
    }()
    
    private static let disPriceAddAttributes: [NSAttributedString.Key : Any] = {
        return [NSAttributedString.Key.font: UIFont.pingFangRegular(16)]
    }()
    
    private static let priceAttributes: [NSAttributedString.Key : Any] = {
        return [NSAttributedString.Key.font:  UIFont.pingFangRegular(13),
                NSAttributedString.Key.foregroundColor: RGB(0x7B8184),
                NSAttributedString.Key.strikethroughStyle: NSNumber(1)]
    }()
    
    private static let vipDayAttributes: [NSAttributedString.Key : Any] = {
        return [NSAttributedString.Key.font:  UIFont.pingFangMedium(10),
                NSAttributedString.Key.foregroundColor: UIColor.white]
    }()
    
    private static let vipDayAddAttributes: [NSAttributedString.Key : Any] = {
        return [NSAttributedString.Key.font: UIFont.pingFangMedium(12), NSAttributedString.Key.foregroundColor: RGB(0xFFCA5F)]
    }()
    
    private lazy var newcomerImgView: UIImageView = {
        let imgView = UIImageView(image: VipChargeAmountCell.newcomerImg)
        imgView.isHidden = true
        return imgView
    }()
    
    private lazy var vipLabel: UILabel = {
        let label = UILabel()
        label.textColor = RGB(0x505253)
        label.font = UIFont.pingFangMedium(16)
        label.textAlignment = .center
        return label
    }()
    
    private lazy var disPriceLabel: UILabel = {
        let label = UILabel()
        return label
    }()
    
    private lazy var priceLabel: UILabel = {
        let label = UILabel()
        return label
    }()
    
    private lazy var vipDayLabel: UILabel = {
        let label = UILabel()
        label.textAlignment = .center
        label.layer.backgroundColor = RGB(0xFA6400).cgColor
        label.numberOfLines = 1
        return label
    }()
    
    private lazy var chosenImgView: UIImageView = {
        let imgView = UIImageView(image: VipChargeAmountCell.chosenImg)
        imgView.isHidden = true
        return imgView
    }()
    
    private lazy var wrapperView: UIView = {
        let view = UIView()
        view.addSubview(vipLabel)
        view.addSubview(disPriceLabel)
        view.addSubview(priceLabel)
        view.addSubview(vipDayLabel)
        view.addSubview(chosenImgView)
        view.layer.cornerRadius = 4
        view.layer.masksToBounds = true
        view.layer.borderWidth = 1
        view.layer.borderColor = RGB(0xE9E9E9).cgColor
        
        vipLabel.snp.makeConstraints { (make) in
            make.top.equalToSuperview().inset(20)
            make.left.right.equalToSuperview()
        }
        
        disPriceLabel.snp.makeConstraints { (make) in
            make.top.equalTo(vipLabel.snp.bottom)
            make.centerX.equalToSuperview()
        }
        
        priceLabel.snp.makeConstraints { (make) in
            make.top.equalTo(disPriceLabel.snp.bottom).offset(-6)
            make.centerX.equalToSuperview()
        }
        
        vipDayLabel.snp.makeConstraints { (make) in
            make.left.right.bottom.equalToSuperview()
            make.height.equalTo(22)
        }
        
        chosenImgView.snp.makeConstraints { (make) in
            make.left.top.equalToSuperview()
            make.width.equalTo(26)
            make.height.equalTo(16)
        }
        return view
    }()
    
    var isChosen: Bool = true {
        didSet{
            wrapperView.layer.borderColor = isChosen ? RGB(0xFF9346).cgColor : RGB(0xE9E9E9).cgColor
            chosenImgView.isHidden = !isChosen
        }
    }
    
    var dataModel: VipCardItem? {
        didSet{
            guard let item = dataModel else { return }
            vipLabel.text = item.cardName
            let disPriceAttributedString = NSMutableAttributedString(string: "¥\(numberZeroTruncationFormat(item.disPrice))", attributes: VipChargeAmountCell.disPriceAttributes)
            disPriceAttributedString.addAttributes(VipChargeAmountCell.disPriceAddAttributes,range: NSRange(location: 0, length: 1))
            disPriceLabel.attributedText = disPriceAttributedString
            
            let priceString = NSMutableAttributedString(string: "原價\(numberZeroTruncationFormat(item.price))", attributes: VipChargeAmountCell.priceAttributes)
            priceLabel.attributedText = priceString
            
            let vipDayString = NSMutableAttributedString(string: "\(item.vipNumber)天暢享觀看", attributes: VipChargeAmountCell.vipDayAttributes)
            vipDayString.addAttributes(VipChargeAmountCell.vipDayAddAttributes,range: NSRange(location: 0, length: "\(item.vipNumber)".count))
            vipDayLabel.attributedText = vipDayString
            newcomerImgView.isHidden = !item.isDeduct
        }
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        renderView()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func renderView() {
        addSubview(wrapperView)
        addSubview(newcomerImgView)
        
        wrapperView.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
        
        newcomerImgView.snp.makeConstraints { (make) in
            make.top.equalToSuperview().offset(-2)
            make.right.equalToSuperview()
            make.width.equalTo(70)
            make.height.equalTo(21)
        }
    }
}
