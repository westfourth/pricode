//
//  VipChargeAmountItemCell.swift
//  Sp
//
//  Created by mac on 2020/5/20.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit


class VipChargeAmountItemCell: UICollectionViewCell {
    
    private static let collectionViewMarginTop: CGFloat = 5
    
    private lazy var scrollView: UIScrollView = {
        let scrollView  = UIScrollView()
        scrollView.contentSize = CGSize(width: UIScreen.main.bounds.width, height: 420)
        return scrollView
    }()
    
    private lazy var collectionView: UICollectionView = {
        let layout = UICollectionViewFlowLayout()
        layout.itemSize = CGSize(width: VipChargeAmountCell.itemWidth, height: VipChargeAmountCell.itemHeight)
        layout.minimumLineSpacing = 6
        layout.minimumInteritemSpacing = 0
        layout.scrollDirection = .horizontal
        layout.sectionInset = UIEdgeInsets(top: VipChargeAmountItemCell.collectionViewMarginTop, left: 12, bottom: 0, right: 12)
        let cv = UICollectionView(frame: .zero, collectionViewLayout: layout)
        cv.register(VipChargeAmountCell.self, forCellWithReuseIdentifier: "VipChargeAmountCell")
        cv.backgroundColor = .none
        cv.delegate = self
        cv.dataSource = self
        cv.showsHorizontalScrollIndicator = false
        return cv
    }()
    
    private lazy var splitLine: UIView = {
        let view = UIView()
        view.backgroundColor = RGB(0xF5F6F7)
        return view
    }()
    
    private lazy var vipChargeDetailsBtn: VipChargeDetailsBtn = {
        let btn = VipChargeDetailsBtn()
        return btn
    }()
    
    private lazy var vipPayWayView: VipPayWayView = {
        let view = VipPayWayView()
        view.vipCardType = .vip
        return view
    }()
    
    private var isInitState: Bool = true
    
    private var activeItemIndex: Int = 0
    
    weak var delegate: VipChargeItemCellDelegate?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        addSubview(scrollView)
        scrollView.addSubview(collectionView)
        scrollView.addSubview(splitLine)
        scrollView.addSubview(vipChargeDetailsBtn)
        scrollView.addSubview(vipPayWayView)
        
        scrollView.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
        
        let clientWidth = UIScreen.main.bounds.width
        
        collectionView.snp.makeConstraints { (make) in
            make.top.left.equalToSuperview()
            make.width.equalTo(clientWidth)
            make.height.equalTo(VipChargeAmountCell.itemHeight + VipChargeAmountItemCell.collectionViewMarginTop)
        }
        
        splitLine.snp.makeConstraints { (make) in
            make.top.equalTo(collectionView.snp.bottom).offset(20)
            make.left.equalToSuperview()
            make.width.equalTo(clientWidth)
            make.height.equalTo(5)
        }
        
        vipChargeDetailsBtn.snp.makeConstraints { (make) in
            make.top.equalTo(splitLine.snp.bottom)
            make.left.equalToSuperview()
            make.width.equalTo(clientWidth)
            make.height.equalTo(VipChargeDetailsBtn.viewHeight)
        }
        
        vipPayWayView.snp.makeConstraints { (make) in
            make.top.equalTo(vipChargeDetailsBtn.snp.bottom).offset(10)
            make.left.equalToSuperview()
            make.width.equalTo(clientWidth)
            make.height.equalTo(VipPayWayCell.viewHeight * CGFloat(VipPayWayView.payWayLabelArr.count))
        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func refreshCollectionView() {
        guard isInitState, !VipVC.vipCardList.isEmpty else { return }
        isInitState = false
        collectionView.reloadData()
        vipPayWayView.switchDefaultPayWayActiveType()
        VipVC.payWayActiveTypeArr[VipCardType.vip.rawValue] = vipPayWayView.payWayActiveType
        vipPayWayView.refreshTableView()
    }
    
}

extension VipChargeAmountItemCell: UICollectionViewDelegate, UICollectionViewDataSource {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return VipVC.vipCardList.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let row = indexPath.row
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "VipChargeAmountCell", for: indexPath) as! VipChargeAmountCell
        cell.isChosen = row == activeItemIndex
        cell.dataModel = VipVC.vipCardList[row]
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let row = indexPath.row
        guard activeItemIndex != row else { return }
        activeItemIndex = row
        vipPayWayView.activeIndex = row
        vipPayWayView.switchDefaultPayWayActiveType()
        VipVC.cardActiveIndexArr[VipCardType.vip.rawValue] = row
        VipVC.payWayActiveTypeArr[VipCardType.vip.rawValue] = vipPayWayView.payWayActiveType
        collectionView.scrollToItem(at: indexPath, at: .centeredHorizontally, animated: true)
        collectionView.reloadData()
        vipPayWayView.refreshTableView()
        delegate?.refreshPayBtnPrice()
    }
}
