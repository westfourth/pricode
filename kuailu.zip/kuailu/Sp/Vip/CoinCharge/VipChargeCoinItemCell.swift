
//
//  VipChargeCoinItemCell.swift
//  Sp
//
//  Created by mac on 2020/5/20.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class VipChargeCoinItemCell: UICollectionViewCell {
    
    private lazy var scrollView: UIScrollView = {
        let scrollView  = UIScrollView()
        scrollView.contentSize = CGSize(width: UIScreen.main.bounds.width, height: 420)
        return scrollView
    }()
    
    private lazy var collectionView: UICollectionView = {
        let layout = UICollectionViewFlowLayout()
        layout.itemSize = CGSize(width: VipChargeCoinCell.itemWidth, height: VipChargeCoinCell.itemHeight)
        layout.minimumLineSpacing = 6
        layout.minimumInteritemSpacing = 0
        layout.scrollDirection = .horizontal
        layout.sectionInset = UIEdgeInsets(top: 0, left: 12, bottom: 0, right: 12)
        let cv = UICollectionView(frame: .zero, collectionViewLayout: layout)
        cv.register(VipChargeCoinCell.self, forCellWithReuseIdentifier: "VipChargeCoinCell")
        cv.backgroundColor = .none
        cv.delegate = self
        cv.dataSource = self
        cv.showsHorizontalScrollIndicator = false
        return cv
    }()
    
    private lazy var splitLine: UIView = {
        let view = UIView()
        view.backgroundColor = RGB(0xF5F6F7)
        return view
    }()
    
    private lazy var vipChargeDetailsBtn: VipChargeDetailsBtn = {
        let btn = VipChargeDetailsBtn()
        return btn
    }()
    
    private lazy var vipPayWayView: VipPayWayView = {
        let view = VipPayWayView()
        view.vipCardType = .coin
        return view
    }()
    
    weak var delegate: VipChargeItemCellDelegate?
    
    private var isInitState: Bool = true
    
    private var activeItemIndex: Int = 0
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        renderView()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func renderView() {
        addSubview(scrollView)
        scrollView.addSubview(collectionView)
        scrollView.addSubview(splitLine)
        scrollView.addSubview(vipChargeDetailsBtn)
        scrollView.addSubview(vipPayWayView)
        
        scrollView.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
        
        let clientWidth = UIScreen.main.bounds.width
        
        collectionView.snp.makeConstraints { (make) in
            make.top.left.equalToSuperview()
            make.width.equalTo(clientWidth)
            make.height.equalTo(VipChargeAmountCell.itemHeight)
        }
        
        splitLine.snp.makeConstraints { (make) in
            make.top.equalTo(collectionView.snp.bottom).offset(20)
            make.left.equalToSuperview()
            make.width.equalTo(clientWidth)
            make.height.equalTo(5)
        }
        
        vipChargeDetailsBtn.snp.makeConstraints { (make) in
            make.top.equalTo(splitLine.snp.bottom)
            make.left.equalToSuperview()
            make.width.equalTo(clientWidth)
            make.height.equalTo(VipChargeDetailsBtn.viewHeight)
        }
        
        vipPayWayView.snp.makeConstraints { (make) in
            make.top.equalTo(vipChargeDetailsBtn.snp.bottom).offset(10)
            make.left.equalToSuperview()
            make.width.equalTo(clientWidth)
            make.height.equalTo(VipPayWayCell.viewHeight * CGFloat(VipPayWayView.payWayLabelArr.count))
        }
    }
    
    func refreshCollectionView() {
        guard isInitState, !VipVC.vipCardList.isEmpty else { return }
        isInitState = false
        collectionView.reloadData()
        vipPayWayView.switchDefaultPayWayActiveType()
        VipVC.payWayActiveTypeArr[VipCardType.coin.rawValue] = vipPayWayView.payWayActiveType
        vipPayWayView.refreshTableView()
    }
}

extension VipChargeCoinItemCell: UICollectionViewDelegate, UICollectionViewDataSource {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return VipVC.coinCardList.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let row = indexPath.row
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "VipChargeCoinCell", for: indexPath) as! VipChargeCoinCell
        cell.isChosen = row == activeItemIndex
        cell.dataModel = VipVC.coinCardList[row]
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let row = indexPath.row
        guard activeItemIndex != row else { return }
        activeItemIndex = row
        vipPayWayView.activeIndex = row
        vipPayWayView.switchDefaultPayWayActiveType()
        VipVC.cardActiveIndexArr[VipCardType.coin.rawValue] = row
        VipVC.payWayActiveTypeArr[VipCardType.coin.rawValue] = vipPayWayView.payWayActiveType
        collectionView.scrollToItem(at: indexPath, at: .centeredHorizontally, animated: true)
        collectionView.reloadData()
        vipPayWayView.refreshTableView()
        delegate?.refreshPayBtnPrice()
    }
}

