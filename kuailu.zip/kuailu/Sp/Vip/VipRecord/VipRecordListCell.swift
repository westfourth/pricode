//
//  VipRecordCell.swift
//  Sp
//
//  Created by mac on 2020/2/28.
//  Copyright © 2020 mac. All rights reserved.
//


class VipRecordListCell: UITableViewCell {
    
    private static let formatDate: DateFormatter = {
        let f = DateFormatter()
        f.dateFormat = "yyyy.MM.dd HH:mm:ss"
        return f
    }()
    
    private static let orderImg: UIImage? = {
        return UIImage(named: "vip_record_order_copy")
    }()
    
    private lazy var subjectLabel: UILabel = {
        let label = UILabel()
        label.textColor = .white
        label.font = UIFont.pingFangHeavy(17)
        return label
    }()
    
    private lazy var orderBtn: UIButton = {
        let btn = UIButton()
        btn.setTitle("複製單號", for: .normal)
        btn.setTitleColor(.white, for: .normal)
        btn.titleLabel?.font = UIFont.pingFangRegular(10)
        btn.setBackgroundImage(VipRecordListCell.orderImg, for: .normal)
        btn.addTarget(self, action: #selector(onOrderBtnTap), for: .touchUpInside)
        return btn
    }()
    
    private lazy var payValLabel: UILabel = {
        let label = UILabel()
        label.textColor = .white
        label.font = UIFont.pingFangHeavy(28)
        return label
    }()
    
    private lazy var dayLabel: UILabel = {
        let label = UILabel()
        label.textColor = .white
        label.font = UIFont.pingFangRegular(13)
        return label
    }()
    
    private lazy var orderIDLabel: UILabel = {
        let label = UILabel()
        label.textColor = .white
        label.font = UIFont.pingFangRegular(13)
        return label
    }()
    
    private lazy var timeLabel: UILabel = {
        let label = UILabel()
        label.textColor = RGB(0x848484)
        label.font = UIFont.pingFangMedium(13)
        return label
    }()
    
    var dataModel: PurchaseRecordItem? {
        didSet{
            guard let item = dataModel else { return }
            subjectLabel.text = item.title
            dayLabel.text = item.purType == .buyGold ? "贈送\(Sensitive.jin): \(item.freeGoldNum)個" : item.purType == .buyVip ? "使用天數: \(item.vipNumber)天" : "使用天數: \(item.tnumber)天"
            orderIDLabel.text = "訂單編號: \(item.tradeNo)"
            payValLabel.text = "¥\(numberZeroTruncationFormat(item.money))"
            timeLabel.text = "交易時間: \(VipRecordListCell.formatDate.string(from: item.createdAt ?? Date()))"
        }
    }
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        backgroundColor = .none
        selectionStyle = .none
        renderView()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func renderView() {
        contentView.addSubview(subjectLabel)
        contentView.addSubview(payValLabel)
        contentView.addSubview(dayLabel)
        contentView.addSubview(orderIDLabel)
        contentView.addSubview(timeLabel)
        contentView.addSubview(orderBtn)
        
        subjectLabel.snp.makeConstraints { (make) in
            make.top.left.equalToSuperview().inset(12)
        }
        
        payValLabel.snp.makeConstraints { (make) in
            make.right.equalToSuperview().inset(12)
            make.top.equalToSuperview().inset(18.5)
        }
        
        dayLabel.snp.makeConstraints { (make) in
            make.top.equalTo(subjectLabel.snp.bottom).offset(10)
            make.left.equalToSuperview().inset(12)
        }
        
        orderIDLabel.snp.makeConstraints { (make) in
            make.top.equalTo(dayLabel.snp.bottom).offset(6)
            make.left.equalToSuperview().inset(12)
        }
        
        timeLabel.snp.makeConstraints { (make) in
            make.top.equalTo(orderIDLabel.snp.bottom).offset(6)
            make.left.equalToSuperview().inset(12)
        }
        
        orderBtn.snp.makeConstraints { (make) in
            make.centerY.equalTo(orderIDLabel)
            make.left.equalTo(orderIDLabel.snp.right).offset(4)
            make.width.equalTo(56)
            make.height.equalTo(19)
        }
    }
    
    @objc private func onOrderBtnTap() {
        guard let item = dataModel else { return }
        UIPasteboard.general.string = item.tradeNo
        mm_showToast("訂單編號已複製到貼上板!", type: .succeed)
    }
}
