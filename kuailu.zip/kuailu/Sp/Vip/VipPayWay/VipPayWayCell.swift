//
//  VipPayWayCell.swift
//  Sp
//
//  Created by mac on 2020/2/29.
//  Copyright © 2020 mac. All rights reserved.
//


class VipPayWayCell: UITableViewCell {
    
    static let viewHeight: CGFloat = 50
    
    private static let chosenImg: UIImage? = {
        return UIImage(named: "chosen_icon")
    }()
    
    lazy var typeLabel: UILabel = {
        let label = UILabel()
        label.textColor = RGB(0x383838)
        label.font = UIFont.pingFangRegular(14)
        return label
    }()
    
    lazy var payWayIcon: UIImageView = {
        return UIImageView()
    }()
    
    lazy var chosenStatusIcon: UIImageView = {
        return UIImageView(image: VipPayWayCell.chosenImg)
    }()
    
    lazy var unchosenStatusView: UIView = {
        let view = UIView()
        view.backgroundColor = RGB(0xd4d4d4)
        view.layer.cornerRadius = 9
        view.layer.masksToBounds = true
        return view
    }()
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        backgroundColor = .none
        selectionStyle = .none
        renderView()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func renderView() {
        addSubview(payWayIcon)
        addSubview(typeLabel)
        addSubview(unchosenStatusView)
        addSubview(chosenStatusIcon)
        
        payWayIcon.snp.makeConstraints { (make) in
            make.centerY.equalToSuperview()
            make.left.equalToSuperview().inset(12)
            make.size.equalTo(38)
        }
        
        typeLabel.snp.makeConstraints { (make) in
            make.left.equalTo(payWayIcon.snp.right).offset(10)
            make.centerY.equalToSuperview()
        }
        
        unchosenStatusView.snp.makeConstraints { (make) in
            make.right.equalToSuperview().inset(19)
            make.centerY.equalToSuperview()
            make.size.equalTo(18)
        }
        
        chosenStatusIcon.snp.makeConstraints { (make) in
            make.edges.equalTo(unchosenStatusView)
        }
    }
}
