//
//  VipPayWayView.swift
//  Sp
//
//  Created by mac on 2020/5/20.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class VipPayWayView: UIView {
    
    static let payWayLabelArr: [String] = {
        return ["\(Sensitive.qian)", "\u{652f}\u{4ed8}\u{5bf6}", "\u{5fae}\u{4fe1}", "\u{96f2}\u{9583}\u{4ed8}"]
    }()
    
    private static let payWayIconArr: [UIImage?] = {
        return [UIImage(named: "vip_balance_icon"), UIImage.decrypt("ap.png.enc"), UIImage.decrypt("wc.png.enc"), UIImage.decrypt("cf.png.enc")]
    }()
    
    private lazy var tableView: UITableView = {
        let tableView = UITableView(frame: .zero, style: .plain)
        tableView.delegate = self
        tableView.dataSource = self
        tableView.isScrollEnabled = false
        tableView.backgroundColor = .none
        tableView.sectionHeaderHeight = .leastNormalMagnitude
        tableView.sectionFooterHeight = .leastNormalMagnitude
        tableView.tableHeaderView = nil
        tableView.tableFooterView = nil
        tableView.estimatedRowHeight = VipPayWayCell.viewHeight
        tableView.estimatedSectionFooterHeight = 0
        tableView.estimatedSectionHeaderHeight = 0
        tableView.separatorStyle = .none
        tableView.rowHeight = VipPayWayCell.viewHeight
        tableView.register(VipPayWayCell.self, forCellReuseIdentifier: "VipPayWayCell")
        return tableView
    }()
    
    var activeIndex: Int = 0
    
    var payWayActiveType: PayTypeEnum = .none
    
    var vipCardType: VipCardType = .vip
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        addSubview(tableView)
        
        tableView.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
        
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    static func getPayTypeByPayTypeEnum(payWayEnum: PayTypeEnum)-> Int {
        switch payWayEnum {
        case .alipay:
            return 1
        case .wechat:
            return 2
        case .union:
            return 3
        default:
            return 0
        }
    }
    
    private func getCurrentPayWayActiveType(row: Int)-> PayTypeEnum {
        guard row != 0 else { return .none }
        switch vipCardType {
        case .vip:
            return VipVC.vipCardList[activeIndex].types[row - 1].payMent
        case .coin:
            return VipVC.coinCardList[activeIndex].types[row - 1].payMent
        case .ticket:
            return VipVC.ticketCardList[activeIndex].types[row - 1].payMent
        case .appointment:
            return VipVC.appointmentCardList[activeIndex].types[row - 1].payMent
        }
    }
    
    func switchDefaultPayWayActiveType() {
        switch vipCardType {
        case .vip:
            guard !VipVC.vipCardList.isEmpty, activeIndex < VipVC.vipCardList.count else {
                payWayActiveType = .none
                return
            }
            let types = VipVC.vipCardList[activeIndex].types
            guard !types.isEmpty else {
                payWayActiveType = .none
                return
            }
            payWayActiveType = types[0].payMent
        case .coin:
            guard !VipVC.coinCardList.isEmpty, activeIndex < VipVC.coinCardList.count else {
                payWayActiveType = .none
                return
            }
            let types = VipVC.coinCardList[activeIndex].types
            guard !types.isEmpty else {
                payWayActiveType = .none
                return
            }
            payWayActiveType = types[0].payMent
        case .ticket:
            guard !VipVC.ticketCardList.isEmpty, activeIndex < VipVC.ticketCardList.count else {
                payWayActiveType = .none
                return
            }
            let types = VipVC.ticketCardList[activeIndex].types
            guard !types.isEmpty else {
                payWayActiveType = .none
                return
            }
            payWayActiveType = types[0].payMent
        case .appointment:
            guard !VipVC.appointmentCardList.isEmpty, activeIndex < VipVC.appointmentCardList.count else {
                payWayActiveType = .none
                return
            }
            let types = VipVC.appointmentCardList[activeIndex].types
            guard !types.isEmpty else {
                payWayActiveType = .none
                return
            }
            payWayActiveType = types[0].payMent
        }
        
    }
    
    func refreshTableView() {
        tableView.reloadData()
    }
    
    func getPayWayCount()-> Int {
        return vipCardType == .vip ? (VipVC.vipCardList.isEmpty ? 0 : VipVC.vipCardList[activeIndex].types.count + 1) : vipCardType == .coin ? (VipVC.coinCardList.isEmpty ? 0 : VipVC.coinCardList[activeIndex].types.count + 1) : vipCardType == .ticket ? (VipVC.ticketCardList.isEmpty ? 0 : VipVC.ticketCardList[activeIndex].types.count) : (VipVC.appointmentCardList.isEmpty ? 0 : VipVC.appointmentCardList[activeIndex].types.count + 1)
    }
}

extension VipPayWayView: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return getPayWayCount()
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell  = tableView.dequeueReusableCell(withIdentifier: "VipPayWayCell", for: indexPath) as! VipPayWayCell
        let currentPayWayActiveType = getCurrentPayWayActiveType(row: vipCardType == .ticket ? indexPath.row + 1 : indexPath.row)
        let index = VipPayWayView.getPayTypeByPayTypeEnum(payWayEnum: currentPayWayActiveType)
        cell.typeLabel.text = index == 0 ? (VipPayWayView.payWayLabelArr[index] + "（\(Sensitive.yu)：\(numberZeroTruncationFormat(WalletVC.balanceVal))元）") : VipPayWayView.payWayLabelArr[index]
        cell.payWayIcon.image = VipPayWayView.payWayIconArr[index]
        cell.unchosenStatusView.isHidden = payWayActiveType == currentPayWayActiveType
        cell.chosenStatusIcon.isHidden = payWayActiveType != currentPayWayActiveType
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let currentPayWayActiveType = getCurrentPayWayActiveType(row: vipCardType == .ticket ? indexPath.row + 1 : indexPath.row)
        guard payWayActiveType != currentPayWayActiveType else { return }
        payWayActiveType = currentPayWayActiveType
        VipVC.payWayActiveTypeArr[vipCardType.rawValue] = currentPayWayActiveType
        tableView.reloadData()
    }
    
}
