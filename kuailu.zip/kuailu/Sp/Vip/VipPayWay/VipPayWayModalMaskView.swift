//
//  VipPayWayModalMaskView.swift
//  Sp
//
//  Created by mac on 2020/9/30.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

protocol VipPayWayModalMaskViewDelegate: NSObjectProtocol {
    
    func submitToPay()
    
}

class VipPayWayModalMaskView: UIView {
    
    private static let wrapperViewHeight: CGFloat = 370
    
    private lazy var titleLabel: UILabel = {
        let label = UILabel()
        label.text = "請選擇\(Sensitive.zhi)方式"
        label.textColor = RGB(0x383838)
        label.font = UIFont.pingFangRegular(16)
        label.textAlignment = .center
        return label
    }()
    
    lazy var payBtn: VipPayBtn = {
        let btn = VipPayBtn()
        btn.delegate = self
        btn.type = .float
        return btn
    }()
    
    private lazy var vipPayWayView: VipPayWayView = {
        let view = VipPayWayView()
        return view
    }()
    
    private lazy var contentWrapperView: UIView = {
        let view = UIView()
        view.backgroundColor = .white
        view.layer.masksToBounds = true
        view.layer.cornerRadius = 18
        view.addSubview(titleLabel)
        view.addSubview(vipPayWayView)
        view.addSubview(payBtn)
        
        titleLabel.snp.makeConstraints { (make) in
            make.top.equalToSuperview().inset(24)
            make.left.right.equalToSuperview()
        }
        
        vipPayWayView.snp.makeConstraints { (make) in
            make.top.equalTo(titleLabel.snp.bottom).offset(16)
            make.left.right.bottom.equalToSuperview()
        }
        
        payBtn.snp.makeConstraints { (make) in
            make.bottom.equalToSuperview().inset((IS_IPHONEX ? 15 : 0) + 20)
            make.left.right.equalToSuperview()
            make.height.equalTo(VipPayBtn.viewHeight)
        }
        return view
    }()
    
    private lazy var maskWrapperView: UIButton = {
        let btn = UIButton()
        btn.backgroundColor = UIColor.black.withAlphaComponent(0.3)
        btn.addTarget(self, action: #selector(onMaskWrapperViewTap), for: .touchUpInside)
        return btn
    }()
    
    weak var delegate: VipPayWayModalMaskViewDelegate?
    
    var activeIndex: Int = 0 {
        didSet {
            vipPayWayView.activeIndex = activeIndex
        }
    }
    
    var vipCardType: VipCardType = .vip {
        didSet {
            vipPayWayView.vipCardType = vipCardType
        }
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        alpha = 0
        addSubview(maskWrapperView)
        addSubview(contentWrapperView)
        
        maskWrapperView.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
        
        contentWrapperView.snp.makeConstraints { (make) in
            make.left.right.equalToSuperview()
            make.bottom.equalToSuperview().offset(VipPayWayModalMaskView.wrapperViewHeight)
            make.height.equalTo(VipPayWayModalMaskView.wrapperViewHeight)
        }
        
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    @objc private func onMaskWrapperViewTap() {
        stopAnimation()
    }
    
    @objc private func onPayBtnTap() {
        guard vipPayWayView.getPayWayCount() != 0 else { return }
        delegate?.submitToPay()
    }
    
    func showAnimation() {
        vipPayWayView.refreshTableView()
        contentWrapperView.snp.updateConstraints { (make) in
            make.bottom.equalToSuperview().offset(20)
        }
        updateConstraint()
        UIView.animate(withDuration: 0.3) { [weak self] in
            self?.alpha = 1
            self?.layoutIfNeeded()
        }
    }
    
    func stopAnimation() {
        vipPayWayView.activeIndex = 0
        vipPayWayView.payWayActiveType = .none
        vipPayWayView.vipCardType = .vip
        VipVC.payWayActiveTypeArr[vipCardType.rawValue] = .none
        contentWrapperView.snp.updateConstraints { (make) in
            make.bottom.equalToSuperview().offset(VipPayWayModalMaskView.wrapperViewHeight)
        }
        updateConstraint()
        UIView.animate(withDuration: 0.3, animations: { [weak self] in
            self?.alpha = 0
            self?.layoutIfNeeded()
        })
        
    }
    
    private func updateConstraint() {
        contentWrapperView.updateConstraintsIfNeeded()
        contentWrapperView.updateFocusIfNeeded()
    }
    
    func switchDefaultPayWayActiveType() {
        vipPayWayView.switchDefaultPayWayActiveType()
    }
    
    func getPayWayActiveType() -> PayTypeEnum {
        return vipPayWayView.payWayActiveType
    }
    
}

extension VipPayWayModalMaskView: VipPayBtnDelegate {
    
    func onVipPayBtnTap() {
        onPayBtnTap()
    }
    
}
