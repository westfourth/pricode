//
//  VipChargeTicketWelfareCell.swift
//  Sp
//
//  Created by mac on 2020/5/21.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class VipChargeTicketWelfareCell: UITableViewCell {

    lazy var indexLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.pingFangMedium(8)
        label.textColor = .white
        label.textAlignment = .center
        label.backgroundColor = RGB(0x0075FA)
        label.layer.masksToBounds = true
        label.layer.cornerRadius = 7.5
        return label
    }()
    
    lazy var titleLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.pingFangMedium(12)
        label.textColor = RGB(0x444444)
        label.numberOfLines = 1
        return label
    }()

    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        backgroundColor = .none
        selectionStyle = .none
        renderView()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func renderView() {
        addSubview(indexLabel)
        addSubview(titleLabel)
        
        indexLabel.snp.makeConstraints { (make) in
            make.left.equalToSuperview().inset(12)
            make.centerY.equalToSuperview()
            make.size.equalTo(15)
        }
        
        titleLabel.snp.makeConstraints { (make) in
            make.left.equalTo(indexLabel.snp.right).offset(5)
            make.centerY.right.equalToSuperview()
        }
    }
}
