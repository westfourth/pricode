//
//  VipChargeTicketCell.swift
//  Sp
//
//  Created by mac on 2020/5/20.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class VipChargeTicketCell: UICollectionViewCell {
    
    static let itemWidth: CGFloat = 104
    
    static let itemHeight: CGFloat = 135
    
    private static let tipList: [String] = {
        return  ["珍惜資源搶先看", "獨家福利每日更新", "高端嫩模1v1服務"]
    }()
    
    private static let priceAttributes: [NSAttributedString.Key : Any] = {
        return [NSAttributedString.Key.font:  UIFont.pingFangRegular(33),
                NSAttributedString.Key.foregroundColor: RGB(0xFAB954)]
    }()
    
    private static let priceAddAttributes: [NSAttributedString.Key : Any] = {
        return [NSAttributedString.Key.font: UIFont.pingFangRegular(16)]
    }()
    
    private static let tipAttributes: [NSAttributedString.Key : Any] = {
        return [NSAttributedString.Key.font:  UIFont.pingFangMedium(10),
                NSAttributedString.Key.foregroundColor: UIColor.white]
    }()
    
    private static let tipAddAttributes: [NSAttributedString.Key : Any] = {
        return [NSAttributedString.Key.font: UIFont.pingFangMedium(12), NSAttributedString.Key.foregroundColor: RGB(0xFFCA5F)]
    }()
    
    private static let chosenImg: UIImage? = {
        return UIImage(named: "vip_card_chosen_icon")
    }()
    
    private lazy var titleLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.pingFangMedium(14)
        label.textColor = RGB(0x505253)
        label.numberOfLines = 1
        label.textAlignment = .center
        return label
    }()
    
    private lazy var priceLabel: UILabel = {
        let label = UILabel()
        label.textAlignment = .center
        return label
    }()
    
    private lazy var tipLabel: UILabel = {
        let label = UILabel()
        label.textAlignment = .center
        label.layer.backgroundColor = RGB(0xFA6400).cgColor
        label.numberOfLines = 1
        return label
    }()
    
    private lazy var chosenImgView: UIImageView = {
        let imgView = UIImageView(image: VipChargeTicketCell.chosenImg)
        imgView.isHidden = true
        return imgView
    }()
    
    var isChosen: Bool = true {
        didSet {
            layer.borderColor = isChosen ? RGB(0xFF9346).cgColor : RGB(0xE9E9E9).cgColor
            chosenImgView.isHidden = !isChosen
        }
    }
    
    var dataModel: VipTicketItem? {
        didSet {
            guard let item = dataModel else { return }
            titleLabel.text = item.tname
            let priceString = NSMutableAttributedString(string: "¥\(numberZeroTruncationFormat(item.price))", attributes: VipChargeTicketCell.priceAttributes)
            priceString.addAttributes(VipChargeTicketCell.priceAddAttributes,range: NSRange(location: 0, length: 1))
            priceLabel.attributedText = priceString
            let tipString = NSMutableAttributedString(string: VipChargeTicketCell.tipList[item.ttype.rawValue - 1], attributes: VipChargeTicketCell.tipAttributes)
            tipString.addAttributes(VipChargeTicketCell.tipAddAttributes,range: NSRange(location: 0, length: 4))
            tipLabel.attributedText = tipString
        }
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        layer.cornerRadius = 4
        layer.masksToBounds = true
        layer.borderWidth = 1
        layer.borderColor = RGB(0xE9E9E9).cgColor
        renderView()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func renderView() {
        addSubview(titleLabel)
        addSubview(priceLabel)
        addSubview(tipLabel)
        addSubview(chosenImgView)
        
        titleLabel.snp.makeConstraints { (make) in
            make.top.equalToSuperview().inset(20)
            make.left.right.equalToSuperview()
        }
        
        priceLabel.snp.makeConstraints { (make) in
            make.top.equalTo(titleLabel.snp.bottom)
            make.centerX.equalToSuperview()
        }
        
        tipLabel.snp.makeConstraints { (make) in
            make.left.right.bottom.equalToSuperview()
            make.height.equalTo(22)
        }
        
        chosenImgView.snp.makeConstraints { (make) in
            make.left.top.equalToSuperview()
            make.width.equalTo(26)
            make.height.equalTo(16)
        }
        
    }
}
