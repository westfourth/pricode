//
//  VipChargeTicketItemCell.swift
//  Sp
//
//  Created by mac on 2020/5/20.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class VipChargeTicketItemCell: UICollectionViewCell {
    
    static var initActiveTicketType: TicketType = .specialExpericen
    
    private static let tipContentList: [String] = {
        return ["溫馨提示：vip專享視頻用戶\(Sensitive.hui)等級達到6級即可無限觀看；專區視頻體驗門票有效期66天，請大家抓緊體驗！", "溫馨提示：\(Sensitive.cao)特別群只能通過參與活動、\(Sensitive.hui)達到6級、\(Sensitive.gou)體驗票這三種形式入群！", "溫馨提示：如您在選定嫩模後，無故失約1次，將會取消您的約炮卡權益哦！"]
    }()
    
    private static let commonTipAttibute: [NSAttributedString.Key : Any] = {
        return [NSAttributedString.Key.font:  UIFont.pingFangMedium(12),
                NSAttributedString.Key.foregroundColor: RGB(0xFF4D4D)]
    }()
    
    private static let commonTipStressAttibute: [NSAttributedString.Key : Any] = {
        return [NSAttributedString.Key.foregroundColor: RGB(0xFF4D4D)]
    }()
    
    private lazy var collectionView: UICollectionView = {
        let layout = UICollectionViewFlowLayout()
        layout.minimumLineSpacing = 6
        layout.minimumInteritemSpacing = 0
        layout.itemSize = CGSize(width: VipChargeTicketCell.itemWidth, height: VipChargeTicketCell.itemHeight)
        layout.scrollDirection = .horizontal
        layout.sectionInset = UIEdgeInsets(top: 0, left: 12, bottom: 0, right: 12)
        let cv = UICollectionView(frame: .zero, collectionViewLayout: layout)
        cv.register(VipChargeTicketCell.self, forCellWithReuseIdentifier: "VipChargeTicketCell")
        cv.backgroundColor = .none
        cv.delegate = self
        cv.dataSource = self
        cv.showsHorizontalScrollIndicator = false
        return cv
    }()
    
    lazy var tableView: UITableView = {
        let tableView = UITableView(frame: CGRect.zero, style: .plain)
        tableView.delegate = self
        tableView.dataSource = self
        tableView.backgroundColor = .none
        tableView.sectionHeaderHeight = .leastNormalMagnitude
        tableView.sectionFooterHeight = .leastNormalMagnitude
        tableView.tableHeaderView = nil
        tableView.tableFooterView = nil
        tableView.separatorStyle = .none
        tableView.rowHeight = tableCellRowHeight
        tableView.showsVerticalScrollIndicator = false
        tableView.showsHorizontalScrollIndicator = false
        tableView.isScrollEnabled = false
        tableView.contentInset = UIEdgeInsets(top: 0, left: 12, bottom: 0, right: 12)
        tableView.register(VipChargeTicketWelfareCell.self, forCellReuseIdentifier: "VipChargeTicketWelfareCell")
        return tableView
    }()
    
    private lazy var  commonTipLabel: UILabel = {
        let label = UILabel()
        label.numberOfLines = 0
        return label
    }()
    
    private lazy var splitLine: UIView = {
        let view = UIView()
        view.backgroundColor = RGB(0xF5F6F7)
        return view
    }()
    
    private lazy var vipChargeDetailsBtn: VipChargeDetailsBtn = {
        let btn = VipChargeDetailsBtn()
        return btn
    }()
    
    private lazy var scrollView: UIScrollView = {
        let scrollView  = UIScrollView()
        scrollView.contentSize = CGSize(width: UIScreen.main.bounds.width, height: 400)
        return scrollView
    }()
    
    weak var delegate: VipChargeItemCellDelegate?
    
    private let tableCellRowHeight: CGFloat = 20
    
    private var activeItemIndex: Int = 0
    
    private var isInitState: Bool = true
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        renderView()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    deinit {
        VipChargeTicketItemCell.initActiveTicketType = .specialExpericen
    }
    
    private func renderView() {
        addSubview(scrollView)
        scrollView.addSubview(collectionView)
        scrollView.addSubview(tableView)
        scrollView.addSubview(commonTipLabel)
        scrollView.addSubview(splitLine)
        scrollView.addSubview(vipChargeDetailsBtn)
        
        scrollView.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
        
        let width = UIScreen.main.bounds.width
        
        collectionView.snp.makeConstraints { (make) in
            make.top.equalToSuperview()
            make.left.equalToSuperview()
            make.width.equalTo(width)
            make.height.equalTo(VipChargeTicketCell.itemHeight)
        }
        
        let tableViewHeight = tableCellRowHeight * CGFloat(VipVC.ticketCardList.isEmpty ? 0 : VipVC.ticketCardList[activeItemIndex].desc.count)
        
        tableView.snp.makeConstraints { (make) in
            make.top.equalTo(collectionView.snp.bottom).offset(15)
            make.left.equalToSuperview()
            make.width.equalTo(width)
            make.height.equalTo(tableViewHeight)
        }
        
        commonTipLabel.snp.makeConstraints { (make) in
            make.top.equalTo(collectionView.snp.bottom).offset(10 + tableViewHeight + 14)
            make.left.equalToSuperview().inset(12)
            make.width.equalTo(width - 12 * 2)
        }
        
        splitLine.snp.makeConstraints { (make) in
            make.top.equalTo(commonTipLabel.snp.bottom).offset(14)
            make.left.equalToSuperview()
            make.width.equalTo(width)
            make.height.equalTo(5)
        }
        
        vipChargeDetailsBtn.snp.makeConstraints { (make) in
            make.top.equalTo(splitLine.snp.bottom)
            make.left.equalToSuperview()
            make.width.equalTo(width)
            make.height.equalTo(VipChargeDetailsBtn.viewHeight)
        }
        
    }
    
    func refreshCollectionView() {
        guard isInitState else { return }
        collectionView.reloadData()
        
        var count = 0
        VipVC.ticketCardList.forEach {
            $0.desc.count > count ? count = $0.desc.count : nil
        }
        
        let tableViewHeight = tableCellRowHeight * CGFloat(count)
        
        tableView.snp.updateConstraints { (make) in
            make.height.equalTo(tableViewHeight)
        }
        
        commonTipLabel.snp.updateConstraints { (make) in
            make.top.equalTo(collectionView.snp.bottom).offset(10 + tableViewHeight + 10)
        }
        
        guard !VipVC.ticketCardList.isEmpty else { return }
        let index = (VipVC.ticketCardList.firstIndex { $0.ttype == VipChargeTicketItemCell.initActiveTicketType }) ?? 0
        isInitState = false
        activeItemIndex = index
        VipVC.cardActiveIndexArr[VipCardType.ticket.rawValue] = index
        VipChargeTicketItemCell.initActiveTicketType = .specialExpericen
        switchTipContent()
        tableView.reloadData()
        
    }
    
    private func switchTipContent() {
        guard activeItemIndex < VipVC.ticketCardList.count else { return }
        let gray = [NSAttributedString.Key.foregroundColor: UIColor.black.withAlphaComponent(0.6)]
        switch VipVC.ticketCardList[activeItemIndex].ttype {
        case .specialExpericen:
            let attributedString = NSMutableAttributedString(string: VipChargeTicketItemCell.tipContentList[0], attributes: VipChargeTicketItemCell.commonTipAttibute)
            attributedString.addAttributes(VipChargeTicketItemCell.commonTipStressAttibute, range: NSRange(location: 0, length: 5))
            attributedString.addAttributes(gray, range: NSRange(location: 5, length: 24))
            commonTipLabel.attributedText = attributedString
        case .wechatGroup:
            let attributedString = NSMutableAttributedString(string: VipChargeTicketItemCell.tipContentList[1], attributes: VipChargeTicketItemCell.commonTipAttibute)
            attributedString.addAttributes(VipChargeTicketItemCell.commonTipStressAttibute, range: NSRange(location: 0, length: 5))
            attributedString.addAttributes(gray, range: NSRange(location: 5, length: 9))
            attributedString.addAttributes(gray, range: NSRange(location: 31, length: 8))
            commonTipLabel.attributedText = attributedString
        default:
            let attributedString = NSMutableAttributedString(string: VipChargeTicketItemCell.tipContentList[2], attributes: VipChargeTicketItemCell.commonTipAttibute)
            attributedString.addAttributes(VipChargeTicketItemCell.commonTipStressAttibute, range: NSRange(location: 0, length: 5))
            attributedString.addAttributes(gray, range: NSRange(location: 5, length: 11))
            commonTipLabel.attributedText = attributedString
            break
        }
    }
}

extension VipChargeTicketItemCell: UICollectionViewDelegate, UICollectionViewDataSource {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return VipVC.ticketCardList.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let row = indexPath.row
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "VipChargeTicketCell", for: indexPath) as! VipChargeTicketCell
        cell.isChosen = row == activeItemIndex
        cell.dataModel = VipVC.ticketCardList[row]
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let row = indexPath.row
        guard activeItemIndex != row else { return }
        activeItemIndex = row
        VipVC.cardActiveIndexArr[VipCardType.ticket.rawValue] = row
        switchTipContent()
        collectionView.scrollToItem(at: indexPath, at: .centeredHorizontally, animated: true)
        collectionView.reloadData()
        tableView.reloadData()
        delegate?.refreshPayBtnPrice()
    }
}

extension VipChargeTicketItemCell: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return VipVC.ticketCardList.isEmpty ? 0 : VipVC.ticketCardList[activeItemIndex].desc.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell  = tableView.dequeueReusableCell(withIdentifier: "VipChargeTicketWelfareCell", for: indexPath) as! VipChargeTicketWelfareCell
        let row = indexPath.row
        cell.indexLabel.text = "\(row + 1)"
        cell.titleLabel.text = VipVC.ticketCardList[activeItemIndex].desc[row]
        return cell
    }
    
}

