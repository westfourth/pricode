

class VipChargeFailedAlert: UIView {
    
    private lazy var payFailedFirstLabel: UILabel = {
        let label = UILabel()
        label.text = "\(Sensitive.gou)失敗，"
        label.textColor = .white
        label.font = UIFont.pingFangMedium(18)
        return label
    }()
    
    private lazy var payFailedSecondLabel: UILabel = {
        let label = UILabel()
        label.text = "請重新\(Sensitive.gou)!"
        label.textColor = .white
        label.font = UIFont.pingFangMedium(18)
        return label
    }()
    
    private lazy var payFailedIcon: UIImageView = {
        return UIImageView(image: UIImage(named: "vip_failed"))
    }()
    
    private lazy var payFailedBtn: UIButton = {
        let btn = UIButton()
        btn.setTitle("確定", for: .normal)
        btn.setTitleColor(RGB(0x4D4D4D), for: .normal)
        btn.titleLabel?.font =  UIFont.pingFangMedium(15)
        btn.backgroundColor = .white
        btn.layer.cornerRadius = 4
        btn.clipsToBounds = true
        btn.addTarget(self, action: #selector(onBtnClick), for: .touchUpInside)
        return btn
    }()
    
    weak var delegate: VipChargeFailedAlertDelegate?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = RGB(0x3F3737)
        layer.cornerRadius = 12
        clipsToBounds = true
        renderView()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func renderView() {
        addSubview(payFailedFirstLabel)
        addSubview(payFailedSecondLabel)
        addSubview(payFailedIcon)
        addSubview(payFailedBtn)
        
        payFailedFirstLabel.snp.makeConstraints { (make) in
            make.top.equalToSuperview().inset(30)
            make.centerX.equalToSuperview()
        }
        
        payFailedSecondLabel.snp.makeConstraints { (make) in
            make.top.equalTo(payFailedFirstLabel.snp.bottom).offset(6)
            make.centerX.equalToSuperview()
        }
        
        payFailedIcon.snp.makeConstraints { (make) in
            make.top.equalTo(payFailedSecondLabel.snp.bottom).offset(16)
            make.width.equalTo(126)
            make.height.equalTo(160)
            make.centerX.equalToSuperview()
        }
        
        payFailedBtn.snp.makeConstraints { (make) in
            make.top.equalTo(payFailedIcon.snp.bottom).offset(10)
            make.width.equalTo(178)
            make.height.equalTo(40)
            make.centerX.equalToSuperview()
        }
    }
    
    @objc private func onBtnClick() {
        delegate?.onPayFailedBtnClick()
    }
}


protocol VipChargeFailedAlertDelegate: NSObjectProtocol {
    
    func onPayFailedBtnClick()
    
}
