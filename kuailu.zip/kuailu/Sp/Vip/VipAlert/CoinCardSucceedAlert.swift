

class CoinCardSucceedAlert: UIView {
    
    private lazy var paySucceedIcon: UIImageView = {
        return UIImageView(image: UIImage(named: "vip_coin_succeed"))
    }()
    
    private lazy var headerView: UIView = {
        let view = UIView()
        view.alpha = 0.7677
        let topColor = RGB(0xFD514B)
        let buttomColor = RGB(0xFC973B)
        let gradientColors = [topColor.cgColor, buttomColor.cgColor]
        let gradientLocations:[NSNumber] = [0.0, 1.0]
        let gradientLayer = CAGradientLayer()
        gradientLayer.colors = gradientColors
        gradientLayer.locations = gradientLocations
        gradientLayer.startPoint = CGPoint(x: 0, y: 0.5)
        gradientLayer.endPoint  = CGPoint(x: 1.0, y: 0.5)
        gradientLayer.frame = CGRect(x: 0, y: 0, width: 240, height: 137)
        view.layer.insertSublayer(gradientLayer, at: 0)
        view.addSubview(paySucceedFirstLabel)
        view.addSubview(paySucceedSecondLabel)
        paySucceedFirstLabel.snp.makeConstraints { (make) in
            make.top.equalToSuperview().inset(34)
            make.centerX.equalToSuperview()
        }
        paySucceedSecondLabel.snp.makeConstraints { (make) in
            make.top.equalTo(paySucceedFirstLabel.snp.bottom).offset(8)
            make.centerX.equalToSuperview()
        }
        return view
    }()
    
    private lazy var paySucceedFirstLabel: UILabel = {
        let label = UILabel()
        label.text = "恭喜您！"
        label.textColor = .white
        label.font = UIFont.pingFangMedium(19)
        return label
    }()
    
    lazy var paySucceedSecondLabel: UILabel = {
        let label = UILabel()
        label.text = "\(Sensitive.jin)\(Sensitive.gou)成功"
        label.textColor = .white
        label.font = UIFont.pingFangHeavy(24)
        return label
    }()
    
    private lazy var paySucceedBtn: UIButton = {
        let btn = UIButton()
        btn.layer.cornerRadius = 4
        btn.clipsToBounds = true
        let topColor = RGB(0xFA4E99)
        let buttomColor = RGB(0xF32660)
        let gradientColors = [topColor.cgColor, buttomColor.cgColor]
        let gradientLocations:[NSNumber] = [0.0, 1.0]
        let gradientLayer = CAGradientLayer()
        gradientLayer.colors = gradientColors
        gradientLayer.locations = gradientLocations
        gradientLayer.startPoint = CGPoint(x: 0, y: 0.5)
        gradientLayer.endPoint  = CGPoint(x: 1.0, y: 0.5)
        gradientLayer.frame = CGRect(x: 0, y: 0, width: 178, height: 40)
        btn.layer.insertSublayer(gradientLayer, at: 0)
        btn.setTitle("確定", for: .normal)
        btn.setTitleColor(.white, for: .normal)
        btn.titleLabel?.font = UIFont.pingFangRegular(15)
        btn.addTarget(self, action: #selector(onBtnClick), for: .touchUpInside)
        return btn
    }()
    
    weak var delegate: CoinCardSucceedAlertDelegate?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        renderView()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func renderView() {
        backgroundColor = .white
        layer.cornerRadius = 12
        clipsToBounds = true
        addSubview(headerView)
        addSubview(paySucceedIcon)
        addSubview(paySucceedBtn)
        
        headerView.snp.makeConstraints { (make) in
            make.top.left.right.equalToSuperview()
            make.height.equalTo(137)
        }
        
        paySucceedIcon.snp.makeConstraints { (make) in
            make.top.equalTo(headerView.snp.bottom).offset(10)
            make.width.equalTo(165)
            make.height.equalTo(127)
            make.centerX.equalToSuperview()
        }
        
        paySucceedBtn.snp.makeConstraints { (make) in
            make.bottom.equalToSuperview().inset(16)
            make.width.equalTo(178)
            make.height.equalTo(40)
            make.centerX.equalToSuperview()
        }
    }
    
    @objc private func onBtnClick() {
        delegate?.onCoinPaySucceedBtnClick()
    }
}

protocol CoinCardSucceedAlertDelegate: NSObjectProtocol {
    
    func onCoinPaySucceedBtnClick()
    
}
