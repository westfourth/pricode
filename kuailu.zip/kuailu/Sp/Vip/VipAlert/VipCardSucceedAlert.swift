

class VipCardSucceedAlert: UIView {
    
    private static let vipSucceedImg: UIImage = {
        return UIImage.decrypt("vip_succeed.png.enc")
    }()
    
    private lazy var paySucceedIcon: UIImageView = {
        return UIImageView(image: VipCardSucceedAlert.vipSucceedImg)
    }()
    
    private lazy var paySucceedFirstLabel: UILabel = {
        let label = UILabel()
        label.text = "恭喜您！"
        label.textColor = RGB(0x35200c)
        label.font = UIFont.pingFangMedium(20)
        return label
    }()
    
    lazy var paySucceedSecondLabel: UILabel = {
        let label = UILabel()
        label.textColor = RGB(0x35200c)
        label.font = UIFont.pingFangMedium(20)
        return label
    }()
    
    private lazy var paySucceedBtn: UIButton = {
        let btn = UIButton()
        btn.addTarget(self, action: #selector(onBtnClick), for: .touchUpInside)
        return btn
    }()
    
    weak var delegate: VipCardSucceedAlertDelegate?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        renderView()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func renderView() {
        addSubview(paySucceedIcon)
        addSubview(paySucceedFirstLabel)
        addSubview(paySucceedSecondLabel)
        addSubview(paySucceedBtn)
        paySucceedIcon.snp.makeConstraints { (make) in
            make.size.equalToSuperview()
            make.centerY.equalToSuperview().offset(-50)
            make.centerX.equalToSuperview()
        }
        paySucceedFirstLabel.snp.makeConstraints { (make) in
            make.top.equalToSuperview().inset(66)
            make.left.equalToSuperview().inset(90)
        }
        paySucceedSecondLabel.snp.makeConstraints { (make) in
            make.top.equalTo(paySucceedFirstLabel.snp.bottom).offset(2)
            make.left.equalTo(paySucceedFirstLabel)
        }
        paySucceedBtn.snp.makeConstraints { (make) in
            make.bottom.equalToSuperview().inset(125)
            make.centerX.equalToSuperview().offset(15)
            make.width.equalTo(206)
            make.height.equalTo(46)
        }
    }
    
    @objc private func onBtnClick() {
        delegate?.onVipPaySucceedBtnClick()
    }
}

protocol VipCardSucceedAlertDelegate: NSObjectProtocol {
    
    func onVipPaySucceedBtnClick()
    
}
