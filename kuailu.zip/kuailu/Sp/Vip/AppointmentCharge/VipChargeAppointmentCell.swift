//
//  VipChargeAppointmentCell.swift
//  Sp
//
//  Created by mac on 2020/9/24.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class VipChargeAppointmentCell: UICollectionViewCell {
    
    static let itemWidth: CGFloat = 104
    
    static let itemHeight: CGFloat = 135
    
    private static let priceAttributes: [NSAttributedString.Key : Any] = {
        return [NSAttributedString.Key.font:  UIFont.pingFangRegular(33),
                NSAttributedString.Key.foregroundColor: RGB(0xFAB954)]
    }()
    
    private static let priceAddAttributes: [NSAttributedString.Key : Any] = {
        return [NSAttributedString.Key.font: UIFont.pingFangRegular(16)]
    }()
    
    private static let chosenImg: UIImage? = {
        return UIImage(named: "vip_card_chosen_icon")
    }()
    
    private lazy var titleLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.pingFangMedium(16)
        label.textColor = RGB(0x505253)
        label.numberOfLines = 1
        label.textAlignment = .center
        return label
    }()
    
    private lazy var priceLabel: UILabel = {
        let label = UILabel()
        label.textAlignment = .center
        return label
    }()
    
    private lazy var tipLabel: UILabel = {
        let label = UILabel()
        label.text = "可發布"
        label.textAlignment = .center
        label.numberOfLines = 1
        label.font = UIFont.pingFangRegular(12)
        label.textColor = RGB(0x7B8184)
        return label
    }()
    
    private lazy var tipDetailsLabel: UILabel = {
        let label = UILabel()
        label.textAlignment = .center
        label.numberOfLines = 1
        label.font = UIFont.pingFangRegular(12)
        label.textColor = RGB(0x7B8184)
        return label
    }()
    private lazy var chosenImgView: UIImageView = {
        let imgView = UIImageView(image: VipChargeAppointmentCell.chosenImg)
        imgView.isHidden = true
        return imgView
    }()
    
    var isChosen: Bool = true {
        didSet {
            layer.borderColor = isChosen ? RGB(0xFF9346).cgColor : RGB(0xE9E9E9).cgColor
            chosenImgView.isHidden = !isChosen
        }
    }
    
    var dataModel: VipAppointmentItem? {
        didSet {
            guard let item = dataModel else { return }
            titleLabel.text = item.cardName
            let priceString = NSMutableAttributedString(string: "¥\(numberZeroTruncationFormat(item.price))", attributes: VipChargeAppointmentCell.priceAttributes)
            priceString.addAttributes(VipChargeAppointmentCell.priceAddAttributes,range: NSRange(location: 0, length: 1))
            priceLabel.attributedText = priceString
            tipDetailsLabel.text = "\(item.cardTotal)條兼職信息"
        }
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        layer.cornerRadius = 4
        layer.masksToBounds = true
        layer.borderWidth = 1
        layer.borderColor = RGB(0xE9E9E9).cgColor
        renderView()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func renderView() {
        addSubview(titleLabel)
        addSubview(priceLabel)
        addSubview(tipLabel)
        addSubview(tipDetailsLabel)
        addSubview(chosenImgView)
        
        titleLabel.snp.makeConstraints { (make) in
            make.top.equalToSuperview().inset(20)
            make.left.right.equalToSuperview()
        }
        
        priceLabel.snp.makeConstraints { (make) in
            make.top.equalTo(titleLabel.snp.bottom)
            make.centerX.equalToSuperview()
        }
        
        tipLabel.snp.makeConstraints { (make) in
            make.top.equalTo(priceLabel.snp.bottom)
            make.left.right.equalToSuperview()
        }
        
        tipDetailsLabel.snp.makeConstraints { (make) in
            make.top.equalTo(tipLabel.snp.bottom).offset(4)
            make.left.right.equalToSuperview()
        }
        
        chosenImgView.snp.makeConstraints { (make) in
            make.left.top.equalToSuperview()
            make.width.equalTo(26)
            make.height.equalTo(16)
        }
        
    }
}

