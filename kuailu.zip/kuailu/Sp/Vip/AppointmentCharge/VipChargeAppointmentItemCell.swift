//
//  VipChargeAppointmentItemCell.swift
//  Sp
//
//  Created by mac on 2020/9/24.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class VipChargeAppointmentItemCell: UICollectionViewCell {
    
    static var initActiveTicketType: AppointmentCardType = .merchantSettled
    
    private static let tipContentList: [String] = {
        return ["溫馨提示：用戶發布的約吧信息如果存在虛假信息，平台將直接取消用戶發布的消息；未在規定時間內續費，平台將把用戶的發布消息下架。"]
    }()
    
    private static let commonTipAttibute: [NSAttributedString.Key : Any] = {
        return [NSAttributedString.Key.foregroundColor: RGB(0xFF4D4D)]
    }()
    
    private static let commonTipStressAttibute: [NSAttributedString.Key : Any] = {
        return [NSAttributedString.Key.foregroundColor: RGB(0xFF4D4D)]
    }()
        
    private lazy var collectionView: UICollectionView = {
        let layout = UICollectionViewFlowLayout()
        layout.minimumLineSpacing = 6
        layout.minimumInteritemSpacing = 0
        layout.itemSize = CGSize(width: VipChargeAppointmentCell.itemWidth, height: VipChargeAppointmentCell.itemHeight)
        layout.scrollDirection = .horizontal
        layout.sectionInset = UIEdgeInsets(top: 0, left: 12, bottom: 0, right: 12)
        let cv = UICollectionView(frame: .zero, collectionViewLayout: layout)
        cv.register(VipChargeAppointmentCell.self, forCellWithReuseIdentifier: "VipChargeAppointmentCell")
        cv.backgroundColor = .none
        cv.delegate = self
        cv.dataSource = self
        cv.showsHorizontalScrollIndicator = false
        return cv
    }()
    
    lazy var tableView: UITableView = {
        let tableView = UITableView(frame: CGRect.zero, style: .plain)
        tableView.delegate = self
        tableView.dataSource = self
        tableView.backgroundColor = .none
        tableView.sectionHeaderHeight = .leastNormalMagnitude
        tableView.sectionFooterHeight = .leastNormalMagnitude
        tableView.tableHeaderView = nil
        tableView.tableFooterView = nil
        tableView.separatorStyle = .none
        tableView.rowHeight = tableCellRowHeight
        tableView.showsVerticalScrollIndicator = false
        tableView.showsHorizontalScrollIndicator = false
        tableView.isScrollEnabled = false
        tableView.contentInset = UIEdgeInsets(top: 0, left: 12, bottom: 0, right: 12)
        tableView.register(VipChargeTicketWelfareCell.self, forCellReuseIdentifier: "VipChargeTicketWelfareCell")
        return tableView
    }()
    
    private lazy var  commonTipLabel: UILabel = {
        let label = UILabel()
        label.numberOfLines = 0
        return label
    }()
    
    private lazy var splitLine: UIView = {
        let view = UIView()
        view.backgroundColor = RGB(0xF5F6F7)
        return view
    }()
    
    private lazy var vipChargeDetailsBtn: VipChargeDetailsBtn = {
        let btn = VipChargeDetailsBtn()
        return btn
    }()
    
    private lazy var scrollView: UIScrollView = {
        let scrollView  = UIScrollView()
        scrollView.contentSize = CGSize(width: UIScreen.main.bounds.width, height: 400)
        return scrollView
    }()
    
    private let tableCellRowHeight: CGFloat = 20
    
    private var activeItemIndex: Int = 0
    
    private var isInitState: Bool = true
    
    weak var delegate: VipChargeItemCellDelegate?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        renderView()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    deinit {
        VipChargeAppointmentItemCell.initActiveTicketType = .merchantSettled
    }
    
    private func renderView() {
        addSubview(scrollView)
        scrollView.addSubview(collectionView)
        scrollView.addSubview(tableView)
        scrollView.addSubview(commonTipLabel)
        scrollView.addSubview(splitLine)
        scrollView.addSubview(vipChargeDetailsBtn)
        
        scrollView.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
        
        let width = UIScreen.main.bounds.width
        
        collectionView.snp.makeConstraints { (make) in
            make.top.equalToSuperview()
            make.left.equalToSuperview()
            make.width.equalTo(width)
            make.height.equalTo(VipChargeTicketCell.itemHeight)
        }
        
        let tableViewHeight = tableCellRowHeight * CGFloat(VipVC.appointmentCardList.isEmpty ? 0 : VipVC.appointmentCardList[activeItemIndex].desc.count)
        
        tableView.snp.makeConstraints { (make) in
            make.top.equalTo(collectionView.snp.bottom).offset(15)
            make.left.equalToSuperview()
            make.width.equalTo(width)
            make.height.equalTo(tableViewHeight)
        }
        
        commonTipLabel.snp.makeConstraints { (make) in
            make.top.equalTo(collectionView.snp.bottom).offset(10 + tableViewHeight + 14)
            make.left.equalToSuperview().inset(12)
            make.width.equalTo(width - 12 * 2)
        }
        
        splitLine.snp.makeConstraints { (make) in
            make.top.equalTo(commonTipLabel.snp.bottom).offset(14)
            make.left.equalToSuperview()
            make.width.equalTo(width)
            make.height.equalTo(5)
        }
        
        vipChargeDetailsBtn.snp.makeConstraints { (make) in
            make.top.equalTo(splitLine.snp.bottom)
            make.left.equalToSuperview()
            make.width.equalTo(width)
            make.height.equalTo(VipChargeDetailsBtn.viewHeight)
        }
        
    }
    
    func refreshCollectionView() {
        guard isInitState else { return }
        collectionView.reloadData()
        var count = 0
        VipVC.appointmentCardList.forEach {
            $0.desc.count > count ? count = $0.desc.count : nil
        }
        
        let tableViewHeight = tableCellRowHeight * CGFloat(count)
        
        tableView.snp.updateConstraints { (make) in
            make.height.equalTo(tableViewHeight)
        }
        
        commonTipLabel.snp.updateConstraints { (make) in
            make.top.equalTo(collectionView.snp.bottom).offset(10 + tableViewHeight + 10)
        }
        
        guard !VipVC.appointmentCardList.isEmpty else { return }
        let index = (VipVC.appointmentCardList.firstIndex { $0.cardType == VipChargeAppointmentItemCell.initActiveTicketType }) ?? 0
        isInitState = false
        activeItemIndex = index
        VipVC.cardActiveIndexArr[VipCardType.appointment.rawValue] = index
        VipChargeAppointmentItemCell.initActiveTicketType = .merchantSettled
        switchTipContent()
        tableView.reloadData()
    }
    
    private func switchTipContent() {
        guard activeItemIndex < VipVC.appointmentCardList.count else { return }
        let gray = [NSAttributedString.Key.font:  UIFont.pingFangMedium(12), NSAttributedString.Key.foregroundColor: UIColor.black.withAlphaComponent(0.6)]
        switch VipVC.appointmentCardList[activeItemIndex].cardType {
        case .merchantSettled:
            let attributedString = NSMutableAttributedString(string: VipChargeAppointmentItemCell.tipContentList[0], attributes: gray)
            attributedString.addAttributes(VipChargeAppointmentItemCell.commonTipAttibute, range: NSRange(location: 0, length: 5))
            attributedString.addAttributes(VipChargeAppointmentItemCell.commonTipAttibute, range: NSRange(location: 18, length: 4))
            attributedString.addAttributes(VipChargeAppointmentItemCell.commonTipAttibute, range: NSRange(location: 40, length: 7))
            commonTipLabel.attributedText = attributedString
        }
    }
}

extension VipChargeAppointmentItemCell: UICollectionViewDelegate, UICollectionViewDataSource {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return VipVC.appointmentCardList.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let row = indexPath.row
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "VipChargeAppointmentCell", for: indexPath) as! VipChargeAppointmentCell
        cell.isChosen = row == activeItemIndex
        cell.dataModel = VipVC.appointmentCardList[row]
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let row = indexPath.row
        guard activeItemIndex != row else { return }
        activeItemIndex = row
        VipVC.cardActiveIndexArr[VipCardType.appointment.rawValue] = row
        switchTipContent()
        collectionView.scrollToItem(at: indexPath, at: .centeredHorizontally, animated: true)
        collectionView.reloadData()
        tableView.reloadData()
        delegate?.refreshPayBtnPrice()
    }
}

extension VipChargeAppointmentItemCell: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return VipVC.appointmentCardList.isEmpty ? 0 : VipVC.appointmentCardList[activeItemIndex].desc.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell  = tableView.dequeueReusableCell(withIdentifier: "VipChargeTicketWelfareCell", for: indexPath) as! VipChargeTicketWelfareCell
        let row = indexPath.row
        cell.indexLabel.text = "\(row + 1)"
        cell.titleLabel.text = VipVC.appointmentCardList[activeItemIndex].desc[row]
        return cell
    }
    
}

