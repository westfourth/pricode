
import UIKit

enum VipCardType: Int {
    case vip = 0
    case coin = 1
    case ticket = 2
    case appointment = 3
}

protocol VipChargeItemCellDelegate: NSObjectProtocol {
    
    func refreshPayBtnPrice()
    
}

class VipVC: UIViewController {
    
    static var vipCardList: [VipCardItem] = []
    
    static var ticketCardList: [VipTicketItem] = []
    
    static var coinCardList: [GoldCardVipItem] = []
    
    static var appointmentCardList: [VipAppointmentItem] = []
    
    static var payWayActiveTypeArr: [PayTypeEnum] = Array(repeating: .none, count: 4)
    
    static var cardActiveIndexArr: [Int] = Array(repeating: 0, count: 4)
    
    private static let categoryTitleList: [String] = [Sensitive.hui, Sensitive.jin, "門票", "約吧"]
    
    private static let categoryBarHeight: CGFloat = 48
    
    private static let categoryBarItemWidth: CGFloat = UIScreen.main.bounds.width / 3
    
    private static let scrollListItemSize: CGSize = CGSize(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height - VipHeaderView.viewHeight - VipPayBtn.viewHeight)
    
    private static let categoryBarIndicatorWidth: CGFloat = 40
    
    private static let categoryBarIndicatorHeight: CGFloat = 3
    
    static let categoryItemSize: CGSize = CGSize(width: VipVC.categoryBarCollectionViewWidth / CGFloat(VipVC.categoryTitleList.count), height: VipVC.categoryBarHeight)
    
    private static let categoryBarCollectionViewWidth: CGFloat = UIScreen.main.bounds.width - 44 * 2
    
    private static let emptyImg: UIImage = {
        return UIImage()
    }()
    
    private static let indicatorImg: UIImage? = {
        return UIImage(named: "vip_indicator_icon")
    }()
    
    private lazy var categoryBarIndicator: UIImageView = {
        let imgView = UIImageView(image: VipVC.indicatorImg)
        imgView.frame = CGRect(x: (VipVC.categoryItemSize.width - VipVC.categoryBarIndicatorWidth) / 2, y: VipVC.categoryBarHeight - VipVC.categoryBarIndicatorHeight - 10, width:  VipVC.categoryBarIndicatorWidth, height: VipVC.categoryBarIndicatorHeight)
        return imgView
    }()
    
    private lazy var headerView: VipHeaderView = {
        let view = VipHeaderView()
        view.activePageIndex = activePageIndex
        return view
    }()
    
    private lazy var categoryBarCollectionView: UICollectionView = {
        let layout = UICollectionViewFlowLayout()
        layout.minimumLineSpacing = 0
        layout.minimumInteritemSpacing = 0
        layout.itemSize = VipVC.categoryItemSize
        layout.scrollDirection = .horizontal
        let cv = UICollectionView(frame: CGRect(x: 0, y: 0, width: VipVC.categoryBarCollectionViewWidth, height: VipVC.categoryBarHeight), collectionViewLayout: layout)
        cv.register(VipCategoryCell.self, forCellWithReuseIdentifier: "VipCategoryCell")
        cv.showsVerticalScrollIndicator = false
        cv.showsHorizontalScrollIndicator = false
        cv.bouncesZoom = false
        cv.backgroundColor = .none
        cv.delegate = self
        cv.dataSource = self
        cv.addSubview(categoryBarIndicator)
        return cv
    }()
    
    private lazy var scrollListCollectionView: UICollectionView = {
        let layout = UICollectionViewFlowLayout()
        layout.minimumLineSpacing = 0
        layout.minimumInteritemSpacing = 0
        layout.itemSize = VipVC.scrollListItemSize
        layout.scrollDirection = .horizontal
        let cv = UICollectionView(frame: .zero, collectionViewLayout: layout)
        cv.register(VipChargeAmountItemCell.self, forCellWithReuseIdentifier: "VipChargeAmountItemCell")
        cv.register(VipChargeCoinItemCell.self, forCellWithReuseIdentifier: "VipChargeCoinItemCell")
        cv.register(VipChargeTicketItemCell.self, forCellWithReuseIdentifier: "VipChargeTicketItemCell")
        cv.register(VipChargeAppointmentItemCell.self, forCellWithReuseIdentifier: "VipChargeAppointmentItemCell")
        cv.showsVerticalScrollIndicator = false
        cv.showsHorizontalScrollIndicator = false
        cv.bounces = false
        cv.bouncesZoom = false
        cv.isPagingEnabled = true
        cv.backgroundColor = .none
        cv.delegate = self
        cv.dataSource = self
        return cv
    }()
    
    private lazy var payBtn: VipPayBtn = {
        let btn = VipPayBtn()
        btn.delegate = self
        btn.type = .fixed
        return btn
    }()
    
    private lazy var vipPayWayModalMaskView: VipPayWayModalMaskView = {
        let view = VipPayWayModalMaskView()
        view.delegate = self
        return view
    }()
    
    private lazy var vipCardSucceedAlert: VipCardSucceedAlert = {
        let vipCardSucceedAlert = VipCardSucceedAlert()
        vipCardSucceedAlert.delegate = self
        return vipCardSucceedAlert
    }()
    
    private lazy var vipSucceedAlert: CustomMBProgressHUD = {
        let hud = CustomMBProgressHUD(view: self.view)
        self.view.addSubview(hud)
        hud.customView = vipCardSucceedAlert
        hud.bezelView.clipsToBounds = false
        vipCardSucceedAlert.snp.makeConstraints { (make) in
            make.width.equalTo(337 * 1.15)
            make.height.equalTo(384.5 * 1.15)
        }
        return hud
    }()
    
    private lazy var coinCardSucceedAlert: CoinCardSucceedAlert = {
        let coinCardSucceedAlert = CoinCardSucceedAlert()
        coinCardSucceedAlert.delegate = self
        return coinCardSucceedAlert
    }()
    
    private lazy var coinSucceedAlert: CustomMBProgressHUD = {
        let hud = CustomMBProgressHUD(view: self.view)
        self.view.addSubview(hud)
        hud.customView = coinCardSucceedAlert
        coinCardSucceedAlert.snp.makeConstraints { (make) in
            make.width.equalTo(240)
            make.height.equalTo(328)
        }
        return hud
    }()
    
    private lazy var vipChargeFailedAlert: VipChargeFailedAlert = {
        let vipChargeFailedAlert = VipChargeFailedAlert()
        vipChargeFailedAlert.delegate = self
        return vipChargeFailedAlert
    }()
    
    private lazy var alertFailed: CustomMBProgressHUD = {
        let hud = CustomMBProgressHUD(view: self.view)
        self.view.addSubview(hud)
        hud.customView = vipChargeFailedAlert
        vipChargeFailedAlert.snp.makeConstraints { (make) in
            make.width.equalTo(240)
            make.height.equalTo(328)
        }
        return hud
    }()
    
    private var isRecharge: Bool = NetDefaults.userInfo?.recharge ?? false
    
    private var isTapCategoryItem: Bool = false
    
    private var activePageIndex: Int = 0 {
        didSet {
            headerView.activePageIndex = activePageIndex
        }
    }
    
    var initVipCardType: VipCardType = .vip
    
    var viewWillDisappearClosure: (()->())?
    
    override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: Bundle?) {
        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
        hidesBottomBarWhenPushed = true
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        if #available(iOS 11.0, *) {
            categoryBarCollectionView.contentInsetAdjustmentBehavior = .never
            scrollListCollectionView.contentInsetAdjustmentBehavior = .never
        } else {
            automaticallyAdjustsScrollViewInsets = false
        }
        navigationItem.titleView = categoryBarCollectionView
        view.backgroundColor = .white
        renderView()
        getCardList()
        Alert.showLoading(parentView: UIApplication.shared.keyWindow!)
        guard initVipCardType.rawValue != activePageIndex else { return }
        DispatchQueue.main.async { [weak self] in
            guard let `self` = self else { return }
            self.scrollListCollectionView.scrollToItem(at: IndexPath(row: self.initVipCardType.rawValue, section: 0), at: .centeredHorizontally, animated: false)
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        renderNavigator()
        getAccountAndUserInfo()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        getAccountAndUserInfo()
        viewWillDisappearClosure?()
    }
    
    deinit {
        vipPayWayModalMaskView.removeFromSuperview()
        VipVC.vipCardList = []
        VipVC.coinCardList = []
        VipVC.ticketCardList = []
        VipVC.payWayActiveTypeArr = Array(repeating: .none, count: 4)
        VipVC.cardActiveIndexArr = Array(repeating: 0, count: 4)
        viewWillDisappearClosure = nil
    }
    
    private func renderNavigator() {
        navigationController?.navigationBar.isTranslucent = true
        navigationController?.navigationBar.setBackgroundImage(VipVC.emptyImg, for: .default)
        navigationController?.navigationBar.shadowImage = VipVC.emptyImg
    }
    
    private func renderView() {
        view.addSubview(headerView)
        view.addSubview(scrollListCollectionView)
        view.addSubview(payBtn)
        
        headerView.snp.makeConstraints { (make) in
            make.top.left.right.equalToSuperview()
            make.height.equalTo(VipHeaderView.viewHeight)
        }
        
        scrollListCollectionView.snp.makeConstraints { (make) in
            make.top.equalTo(headerView.snp.bottom)
            make.left.right.equalToSuperview()
            make.bottom.equalToSuperview().inset(VipPayBtn.viewHeight)
        }
        
        payBtn.snp.makeConstraints { (make) in
            make.left.right.equalToSuperview()
            make.bottom.equalToSuperview().inset(IS_IPHONEX ? 15 : 0)
            make.height.equalTo(VipPayBtn.viewHeight)
        }
        vipPayWayModalMaskView.removeFromSuperview()
        UIApplication.shared.keyWindow!.addSubview(vipPayWayModalMaskView)
        vipPayWayModalMaskView.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
    }
    
    private func getAccountAndUserInfo() {
        getAccountInfo()
        getUserinfo()
        getGradeInfo()
    }
    
    private func getCardList() {
        let req =  VipListReq()
        Session.request(req) { [weak self] (error, resp) in
            Alert.hideLoading()
            guard let `self` = self else { return }
            guard error == nil, let resData = resp as? VipCardListResp  else {
                mm_showToast(error?.localizedDescription ?? "獲取資料失敗！")
                return
            }
            VipVC.vipCardList = resData.vipCardList
            VipVC.ticketCardList = resData.ticketsList
            VipVC.coinCardList = resData.goldVipList
            VipVC.appointmentCardList = resData.meetbarList
            self.refreshListData()
        }
    }
    
    private func getUserinfo() {
        Session.request(FetchUserInfoReq()) { [weak self] (error, resp) in
            guard let `self` = self, error == nil, let resData = resp as? UserBase else { return }
            self.isRecharge = resData.recharge
            self.headerView.userinfo = resData
        }
    }
    
    private func getAccountInfo() {
        Session.request(AccountInfoReq()) { [weak self] (error, resp) in
            guard let `self` = self, error == nil, let resData = resp as? AccountInfo else { return }
            WalletVC.balanceVal = resData.bala
            WalletVC.coinVal = resData.gold
            self.headerView.remainingCoinLabel.text = "剩餘\(Sensitive.jin)：\(Int(resData.gold))"
            if !VipVC.vipCardList.isEmpty || !VipVC.coinCardList.isEmpty || !VipVC.ticketCardList.isEmpty {
                self.refreshListData()
            }
        }
    }
    
    private func getGradeInfo() {
        Session.request(UserGradeReq()) { [weak self] (error, resp) in
            guard let `self` = self, error == nil, let resData = resp as? UserGradeResp else { return }
            self.headerView.userGrade = resData
        }
    }
    
    private func refreshListData() {
        scrollListCollectionView.reloadData()
        handlePayBtnPrice()
    }
    
    private func handlePayBtnPrice() {
        let vipCardType = VipCardType(rawValue: activePageIndex)
        let count = vipCardType == .vip ? VipVC.vipCardList.count : vipCardType == .coin ? VipVC.coinCardList.count : vipCardType == .ticket ? VipVC.ticketCardList.count : VipVC.appointmentCardList.count
        let currentActiveCardIndex = VipVC.cardActiveIndexArr[activePageIndex]
        guard currentActiveCardIndex < count else { return }
        let price = vipCardType == .vip ? VipVC.vipCardList[currentActiveCardIndex].disPrice : vipCardType == .coin ?
            VipVC.coinCardList[currentActiveCardIndex].price : vipCardType == .ticket ?   VipVC.ticketCardList[currentActiveCardIndex].price :  VipVC.appointmentCardList[currentActiveCardIndex].price
        payBtn.type = vipCardType == .vip || vipCardType == .coin ? .float : .fixed
        payBtn.price = price
        vipPayWayModalMaskView.payBtn.price = price
    }
    
    @objc private func onPayBtnTap() {
        switch VipCardType(rawValue: activePageIndex) {
        case .vip, .coin:
            goToPurchase()
        case .ticket, .appointment:
            showVipPayWayModalMaskView()
        case .none:
            break
        }
    }
    
    private func showVipPayWayModalMaskView() {
        vipPayWayModalMaskView.vipCardType = VipCardType(rawValue: activePageIndex) ?? .vip
        let vipCardTypeRawVal = vipPayWayModalMaskView.vipCardType.rawValue
        vipPayWayModalMaskView.activeIndex = VipVC.cardActiveIndexArr[vipCardTypeRawVal]
        vipPayWayModalMaskView.switchDefaultPayWayActiveType()
        VipVC.payWayActiveTypeArr[vipCardTypeRawVal] = vipPayWayModalMaskView.getPayWayActiveType()
        vipPayWayModalMaskView.showAnimation()
    }
    
    private func goToPurchase() {
        guard let vipCardType = VipCardType(rawValue: activePageIndex) else { return }
        let payWayActiveType = VipVC.payWayActiveTypeArr[activePageIndex]
        let currentIndex = VipVC.cardActiveIndexArr[activePageIndex]
        let money = handleMoneyVal(cardType: vipCardType, currentIndex: currentIndex)
        if payWayActiveType == .none, (NetDefaults.accountInfo?.bala ?? WalletVC.balanceVal) < money {
            mm_showToast("\(Sensitive.yu)不足哦！")
            vipPayWayModalMaskView.stopAnimation()
            return
        }
        Alert.showLoading(parentView: UIApplication.shared.keyWindow!)
        let req = PurchaseProductReq()
        req.rechType = VipPayWayView.getPayTypeByPayTypeEnum(payWayEnum: payWayActiveType)
        req.money = numberZeroTruncationFormat(money)
        switch vipCardType {
        case .vip:
            req.purType = 2
            req.targetId = VipVC.vipCardList[currentIndex].cardId
        case .coin:
            req.purType = 3
            req.targetId = VipVC.coinCardList[currentIndex].goldId
        case .ticket:
            req.purType = 12
            req.targetId = VipVC.ticketCardList[currentIndex].tid
        case .appointment:
            req.purType = 18
            req.targetId = VipVC.appointmentCardList[currentIndex].cardId
        }
        vipPayWayModalMaskView.stopAnimation()
        Session.request(req) { [weak self] (error, resp) in
            Alert.hideLoading()
            guard let `self` = self else { return }
            guard error == nil else {
                self.alertFailed.show(animated: true)
                return
            }
            guard payWayActiveType != .none else {
                switch vipCardType {
                case .vip:
                    self.vipCardSucceedAlert.paySucceedSecondLabel.text = "\(VipVC.vipCardList[currentIndex].cardName)\(Sensitive.gou)成功"
                    self.vipSucceedAlert.show(animated: true)
                case .coin:
                    self.coinSucceedAlert.show(animated: true)
                case .ticket, .appointment:
                    mm_showToast("恭喜你，\(Sensitive.gou)成功！", type: .succeed)
                }
                self.getAccountAndUserInfo()
                return
            }
            
            guard let link = resp as? PayLink, let url = link.url, InnerIntercept.canOpenURL(url) else {
                self.alertFailed.show(animated: true)
                return
            }
            
            InnerIntercept.open(url)
            guard !self.checkRechargeAccountInfo() else {
                self.navigationToAccountCerVC()
                return
            }
            self.goToChargeTipVC()
        }
    }
    
    private func handleMoneyVal(cardType: VipCardType, currentIndex: Int) -> Double {
        switch cardType {
        case .vip:
            return VipVC.vipCardList[currentIndex].disPrice
        case .coin:
            return VipVC.coinCardList[currentIndex].price
        case .ticket:
            return VipVC.ticketCardList[currentIndex].price
        case .appointment:
            return VipVC.appointmentCardList[currentIndex].price
        }
    }
    
    private func goToChargeTipVC() {
        self.navigationController?.show(VipChargeTipVC(), sender: nil)
    }
    
    private func navigationToAccountCerVC() {
        navigationController?.show(AccountCerVC(), sender: nil)
    }
    
    private func checkRechargeAccountInfo() -> Bool {
        if isRecharge && !Defaults.accountCerSaved {
            if let timeStamp = Defaults.accountCerDateTimeStamp, Date().timeIntervalSince1970 - timeStamp < 7 * 24 * 3600 {
                return false
            }
            Defaults.accountCerDateTimeStamp = Date().timeIntervalSince1970
            return true
        }
        return false
    }
    
    private func refreshCategoryBarCollectionView(activeIndex: Int) {
        handlePayBtnPrice()
        categoryBarCollectionView.scrollToItem(at: IndexPath(row: activeIndex, section: 0), at: .centeredHorizontally, animated: true)
        UIView.animate(withDuration: 0.15, delay: 0, options: .curveEaseIn, animations: {[weak self] in
            guard let `self` = self else { return }
            guard let cell = self.categoryBarCollectionView.dequeueReusableCell(withReuseIdentifier: "VipCategoryCell", for: IndexPath(row: activeIndex, section: 0)) as? VipCategoryCell else {
                return
            }
            self.categoryBarIndicator.center.x = cell.centerX
        }) { [weak self] _ in
            self?.isTapCategoryItem = false
        }
    }
    
}

extension VipVC: UICollectionViewDataSource, UICollectionViewDelegate {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return VipVC.categoryTitleList.count
    }
    
    func collectionView(_ collectionView: UICollectionView,
                        layout collectionViewLayout: UICollectionViewLayout,
                        sizeForItemAt indexPath: IndexPath) -> CGSize {
        return collectionView == categoryBarCollectionView ? VipVC.categoryItemSize : VipVC.scrollListItemSize
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let row = indexPath.row
        guard collectionView == scrollListCollectionView else {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "VipCategoryCell", for: indexPath) as! VipCategoryCell
            cell.titleLabel.text = VipVC.categoryTitleList[row]
            return cell
        }
        var cell: UICollectionViewCell
        switch VipCardType(rawValue: row) {
        case .vip:
            cell = collectionView.dequeueReusableCell(withReuseIdentifier: "VipChargeAmountItemCell", for: indexPath) as! VipChargeAmountItemCell
            let itemCell = cell as? VipChargeAmountItemCell
            itemCell?.delegate = self
            itemCell?.refreshCollectionView()
        case .coin:
            cell = collectionView.dequeueReusableCell(withReuseIdentifier: "VipChargeCoinItemCell", for: indexPath) as! VipChargeCoinItemCell
            let itemCell = cell as? VipChargeCoinItemCell
            itemCell?.delegate = self
            itemCell?.refreshCollectionView()
        case .ticket:
            cell = collectionView.dequeueReusableCell(withReuseIdentifier: "VipChargeTicketItemCell", for: indexPath) as! VipChargeTicketItemCell
            let itemCell = cell as? VipChargeTicketItemCell
            itemCell?.delegate = self
            itemCell?.refreshCollectionView()
        case .appointment:
            cell = collectionView.dequeueReusableCell(withReuseIdentifier: "VipChargeAppointmentItemCell", for: indexPath) as! VipChargeAppointmentItemCell
            let itemCell = cell as? VipChargeAppointmentItemCell
            itemCell?.delegate = self
            itemCell?.refreshCollectionView()
        case .none:
            cell = UICollectionViewCell()
        }
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let row = indexPath.row
        guard collectionView == categoryBarCollectionView, activePageIndex != row else { return }
        activePageIndex = row
        isTapCategoryItem = true
        scrollListCollectionView.scrollToItem(at: indexPath, at: .centeredHorizontally, animated: true)
    }
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        guard scrollView == scrollListCollectionView else { return }
        let currentActivePageIndex = Int(round(scrollView.contentOffset.x / scrollView.frame.width))
        guard isTapCategoryItem else {
            guard activePageIndex != currentActivePageIndex else { return }
            activePageIndex = currentActivePageIndex
            refreshCategoryBarCollectionView(activeIndex: currentActivePageIndex)
            return
        }
        guard currentActivePageIndex == activePageIndex else { return }
        refreshCategoryBarCollectionView(activeIndex: currentActivePageIndex)
    }
}

extension VipVC: VipCardSucceedAlertDelegate {
    
    func onVipPaySucceedBtnClick() {
        vipSucceedAlert.hide(animated: true)
        guard checkRechargeAccountInfo() else { return }
        navigationToAccountCerVC()
    }
    
}

extension VipVC: CoinCardSucceedAlertDelegate {
    
    func onCoinPaySucceedBtnClick() {
        coinSucceedAlert.hide(animated: true)
        guard checkRechargeAccountInfo() else { return }
        navigationToAccountCerVC()
    }
    
}

extension VipVC: VipChargeFailedAlertDelegate {
    
    func onPayFailedBtnClick() {
        alertFailed.hide(animated: true)
    }
    
}

extension VipVC: VipChargeItemCellDelegate {
    
    func refreshPayBtnPrice() {
        handlePayBtnPrice()
    }
    
}

extension VipVC: VipPayWayModalMaskViewDelegate {
    
    func submitToPay() {
        goToPurchase()
    }
    
}

extension VipVC: VipPayBtnDelegate {
    
    func onVipPayBtnTap() {
        onPayBtnTap()
    }
    
}

