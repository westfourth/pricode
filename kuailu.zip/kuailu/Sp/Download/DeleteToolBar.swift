//
//  DeleteToolBar.swift
//  CaoLong
//
//  Created by mac on 2020/5/14.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class DeleteToolBar: UIView {
    
    weak var delegateController: DeleteToolBarDelegate?
    
    @IBOutlet weak var delete: UILabel!
    @IBOutlet weak var all: UILabel!
    
    override  func awakeFromNib() {
        super.awakeFromNib()
    }
    
    @IBAction func selectAllAction(_ sender: Any) {
        delegateController?.click(toolbar: self, selectAll: all)
    }
    
    @IBAction func deleteAction(_ sender: Any) {
        delegateController?.click(toolbar: self, deleteSome: delete)
    }
}

protocol DeleteToolBarDelegate: NSObjectProtocol {
    
    func click(toolbar: DeleteToolBar, selectAll all: UILabel)
    
    func click(toolbar: DeleteToolBar, deleteSome delete: UILabel)
}
