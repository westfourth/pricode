//
//  Downloader.swift
//  Puff
//
//  Created by mac on 2019/10/10.
//  Copyright © 2019 mac. All rights reserved.
//

import UIKit
import XSFileDownloader

private var M3u8ItemsCache = [M3u8Item]()

extension VideoItem {
    var m3u8Item: M3u8Item {
        get {
            let prefix = videoUrl!.absoluteString.components(separatedBy: "?path=").first
            let urlString = "\(prefix ?? "")/by/id" + "?videoId=\(videoId )"
            let realURL = URL(string: urlString)!
            
            for item in M3u8ItemsCache {
                if item.url == realURL {
                    return item
                }
            }
            let item = M3u8Item(url: realURL)
            M3u8ItemsCache.append(item)
            return item
        }
    }

}

class Downloader: NSObject {
    /// 请通过addVidelModel()添加
    static var videoModels = [VideoItem]()
    
    public class func sameVideo(a: VideoItem, b: VideoItem) -> Bool {
        return a.videoId == b.videoId
    }
    
    /// false表示已经存在，根据videoURL判断唯一性
    public class func hasVidelModel(video: VideoItem) -> Bool {
        for model in videoModels {
            if sameVideo(a: model, b: video) {
                return true
            }
        }
        return false
    }
    
    /// false表示已经存在，根据videoURL判断唯一性
    public class func addVidelModel(video: VideoItem) -> Bool {
        for model in videoModels {
            if sameVideo(a: model, b: video) {
                return false
            }
        }
        //
        videoModels.append(video)
        return true
    }
    
    /// true表示删除成功，根据videoURL判断唯一性
    public class func deleteVideoModel(video: VideoItem) -> Bool {
        for i in 0..<videoModels.count {
            let model = videoModels[i]
            if sameVideo(a: model, b: video) {
                videoModels.remove(at: i)
                return true
            }
        }
        return false
    }
    
    
    /// 缓存文件路径
    class func path() -> String {
        let userID = NetDefaults.userInfo?.userId ?? 0
        let fileName = String(userID) + "Downloader.json"
        let path = NSSearchPathForDirectoriesInDomains(.cachesDirectory, .userDomainMask, true).first! as NSString
        let filePath = path.appendingPathComponent(fileName)
        return filePath
    }
    
    /// 读取
    class func read() {
        var string: String?
        do {
            string = try String(contentsOfFile: path(), encoding: String.Encoding.utf8)
        } catch {
            print(error)
        }
        guard string != nil else {
            return
        }
        let array = [VideoItem].deserialize(from: string)
        videoModels = array! as! [VideoItem]
    }
    
    /// 保存
    class func write() {
        let string = videoModels.toJSONString(prettyPrint: true)
        guard string != nil else {
            return
        }
        do {
            try string!.write(toFile: path(), atomically: true, encoding: String.Encoding.utf8)
        } catch {
            print(error)
        }
    }
}
