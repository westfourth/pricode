//
//  DownloadController.swift
//  CaoLong
//
//  Created by mac on 2020/5/14.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit
import XSFileDownloader
import AVKit

class DownloadController: UIViewController {
    
    var edit:Bool = false
    
    var items:[VideoItem] = [VideoItem]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationItem.title = "離線緩存"
        view.backgroundColor = rgb(23,24,25)
        view.addSubview(tableView)
        view.addSubview(toolbar)
        
        self.navigationItem.rightBarButtonItem = UIBarButtonItem(title: "編輯", style: UIBarButtonItem.Style.plain, target: self, action: #selector(self.editAction(_:)))
        //
        loadData()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        Appearance.transparent(true, navigationBar: navigationController?.navigationBar)
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        let bottom = self.view.safeAreaInsets.bottom +  50
        toolbar.frame = CGRect(x: 0, y:edit ? view.bounds.size.height - bottom : view.bounds.size.height + 100 , width: view.bounds.size.width, height: 70)
        tableView.frame = CGRect(x: 0, y: 0, width: view.bounds.size.width, height:edit ? view.bounds.size.height - bottom - 70 : view.bounds.size.height)
    }
    
    lazy var tableView : UITableView = {
        let tableView = UITableView.init(frame: CGRect.zero, style: .grouped)
        tableView.delegate = self
        tableView.dataSource = self
        tableView.clipsToBounds = true
        tableView.backgroundColor = .clear
        tableView.separatorStyle = UITableViewCell.SeparatorStyle.none
        tableView.tableFooterView = UIView()
        tableView.register(UINib(nibName: "CollectionCell2", bundle: Bundle.main), forCellReuseIdentifier: "ID")
        
        return tableView
    }()
    
    lazy var toolbar:DeleteToolBar = {
        let t = Bundle.main.loadNibNamed("DeleteToolBar", owner: nil, options: [:])?.first as! DeleteToolBar
        t.delegateController = self
        return t
    }()
    
    @objc func editAction(_ item:UIBarButtonItem) {
        guard !self.items.isEmpty else {return}
        edit = !edit
        if !edit {
            reset()
        }
        item.title = edit ?  "取消":"編輯"
        view.setNeedsLayout()
        tableView.reloadData()
    }
    
    func loadData() {
        for model in Downloader.videoModels {
            model.isSelected = false
        }
        items = Downloader.videoModels
        if (items.count == 0) {
            tableView.state = .empty
        }
    }
}

// MARK: -UITableViewDataSource && Delegate
extension DownloadController:UITableViewDataSource,UITableViewDelegate {
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ID") as! CollectionCell2
        cell.isDownload = true
        cell.edit = edit
        cell.item = items[indexPath.section]
        return cell
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        return items.count
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let model = items[indexPath.section]
        if edit {
            model.isSelected = !model.isSelected
            tableView.reloadRows(at: [indexPath], with: UITableView.RowAnimation.none)
            refreshDeleteBar()
        } else {
            if model.m3u8Item.status == .downloading {
                model.m3u8Item.cancel()
            } else if model.m3u8Item.status == .downloaded {
                let prefix = model.videoUrl!.absoluteString.components(separatedBy: "?path=").first
                let urlString = "\(prefix ?? "")/by/id" + "?videoId=\(model.videoId )"
                let realURL = URL(string: urlString)!

                let path = M3u8Item.mp4Path(for: realURL)
                playVideo(path: path)
            } else {
                model.m3u8Item.download()
            }
            tableView.reloadData()
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 130
    }
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return 0
    }
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 10
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        return nil
    }
    
    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        return nil
    }
    
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return !edit
    }
    

}

extension DownloadController:DeleteToolBarDelegate {
    
    // 全选
    func click(toolbar: DeleteToolBar, selectAll all: UILabel) {
        items = items.map({ (item) -> VideoItem in
            item.isSelected = true
            return item
        })
        refreshDeleteBar()
        tableView.reloadData()
    }
    
    ///  删除
    func click(toolbar: DeleteToolBar, deleteSome delete: UILabel) {
        deleteItems()
    }
}

extension DownloadController {
    
    func deleteItems() {
        let selectedModels = items.filter { (model) -> Bool in
            return model.isSelected
        }
        let unSelectedModels = items.filter { (model) -> Bool in
            return !model.isSelected
        }
        items = unSelectedModels
        tableView.reloadData()
        //  删除缓存
        for model in selectedModels {
            Downloader.deleteVideoModel(video: model)
        }
        //  删除mp4文件
        for model in selectedModels {
            let path = M3u8Item.mp4Path(for: model.videoUrl!)
            try? FileManager.default.removeItem(atPath: path)
        }
        
        reset()
    }
    
    func refreshDeleteBar() {
        let count = self.items.filter( {return $0.isSelected == true}).count
        self.toolbar.delete.text = "刪除 (\(count))"
    }
    
    func reset() {
        self.edit = false
        self.items = self.items.map { (item) -> VideoItem in
            item.isSelected = false
            return item
        }
        self.toolbar.delete.text = "刪除"
        self.navigationItem.rightBarButtonItem?.title = "編輯"
        self.view.setNeedsLayout()
        if self.items.isEmpty {
            self.tableView.state = .empty
        }
        self.tableView.reloadData()
    }
    
    func playVideo(path: String) {
        let url = URL(fileURLWithPath: path)
        let player = AVPlayer(url: url)
        let vc = AVPlayerViewController()
        vc.player = player
        player.play()
        present(vc, animated: true, completion: nil)
    }
}


/// 方向支持
extension AVPlayerViewController {
    open override var shouldAutorotate: Bool {
        return true
    }
    
    open override var supportedInterfaceOrientations: UIInterfaceOrientationMask {
        return .allButUpsideDown
    }
}
