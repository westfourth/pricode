//
//  CollectionCell.swift
//  CaoLong
//
//  Created by mac on 2020/5/14.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

@objc protocol CollectionCell2Delegate {
    
}

class CollectionCell2: UITableViewCell {
    
    weak var delegate: CollectionCell2Delegate?
    
    @IBOutlet weak var cover: UIImageView!
    @IBOutlet weak var name: UILabel!
    @IBOutlet weak var progress: UILabel!
    @IBOutlet weak var check: UIButton!
    
    @IBOutlet weak var score: UILabel!
    @IBOutlet weak var duration: UILabel!
    
    @IBOutlet weak var leftPadding: NSLayoutConstraint!
    @IBOutlet weak var leftPadding2: NSLayoutConstraint!
    
    @IBOutlet weak var rightPadding: NSLayoutConstraint!
    @IBOutlet weak var gradientView: UIView!
    
    @IBOutlet weak var vipIcon: UIImageView!
    
    @IBOutlet weak var rentIcon: UILabel!
    
    @IBOutlet weak var bgView: UIView!
    
    @IBOutlet weak var downloadButton: UIButton!
    @IBOutlet weak var downloadLabel: UILabel!
    
    private lazy var priceLabel: UILabel = {
        let label = UILabel()
        label.textColor = .white
        label.font = XSVendor.font(12, .semibold)
        return label
    }()
    
    private lazy var subtitlesImgView: UIImageView = {
        let imgView = UIImageView()
        imgView.contentMode = .scaleAspectFit
        return imgView
    }()
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        selectionStyle = .none
        
        backgroundColor = .clear
        contentView.backgroundColor = .clear
        
        check.setImage(UIImage(named: "selected_n"), for: UIControl.State.normal)
        check.setImage(UIImage(named: "selected_s"), for: UIControl.State.selected)
        
        // 渐变色
        object_setClass(gradientView.layer, CAGradientLayer.self)
        let i = gradientView.layer as! CAGradientLayer
        i.colors = [rgb(0x000000).withAlphaComponent(0.0).cgColor,rgb(0x000000).withAlphaComponent(0.48).cgColor]
        i.startPoint = CGPoint(x: 0, y: 0)
        i.endPoint = CGPoint(x: 1, y: 0)
        isHistory = false
        
        addSubview(priceLabel)
        addSubview(subtitlesImgView)
        
        priceLabel.snp.makeConstraints { (make) in
            make.centerY.equalTo(vipIcon)
            make.centerX.equalTo(vipIcon).offset(6)
        }
        
        subtitlesImgView.snp.makeConstraints { (make) in
            make.left.top.equalTo(cover).offset(4)
            make.size.equalTo(36)
        }
        
    }
    
    var isDownload: Bool = false {
        didSet {
            if (isDownload) {
                progress.isHidden = true
                downloadButton.isHidden = false
                downloadLabel.isHidden = false
            }
        }
    }
    
    var edit:Bool?{
        didSet {
            guard let edit = edit else {return}
            check.isHidden = !edit
            if (isDownload) {
                downloadButton.isHidden = edit
                downloadLabel.isHidden = edit
            }
        }
    }
    
    var isHistory:Bool = false
    
    static var format:DateFormatter {
        let f = DateFormatter()
        f.dateFormat = "yyyy-MM-dd"
        return f
    }
    
    var item:VideoItem? {
        didSet {
            guard  let item = item else {
                return
            }
            cover.kf.setImage(with: item.coverImg,placeholder:Sensitive.default_bg,options: [.transition(.fade(0.25))])
            name.text = item.title
            check.isSelected = item.isSelected
            score.text = "\(item.fakeScoreNum)分"
            duration.text = Date.getFormatPlayTime(secounds: TimeInterval(item.playTime))
            if isHistory {
                // 观看进度信息
                if let url = item.videoUrl {
                    let percent = Defaults.readWatchProgress(url: url) > 1.0 ?1.0:Defaults.readWatchProgress(url: url)
                    progress.text = String(format: "觀看至%.f%@", percent * 100,"%")
                }
            } else {
                progress.font = UIFont.systemFont(ofSize: 12)
                progress.text = "\(num2TenThousandStrFormat(item.fakeWatchTimes))次播放"
            }
            
            vipIcon.isHidden = item.videoPayMark != .vip
            vipIcon.image = item.videoPayMark != .vip ? SearchResultVideoCell.vipDefaultImg : item.videoPayMark == .pay ? SearchResultVideoCell.payDefaultImg : nil
//            subtitlesImgView.image = item.chSubtitle ? SearchResultVideoCell.subtitlesImg : nil
            priceLabel.isHidden = item.videoPayMark != .pay
            priceLabel.text = numberZeroTruncationFormat(Double(item.price))
            
            //
            setupDownloadStatus()
            setupDownloadCallback()
        }
    }
    
    func setupDownloadStatus() {
        var imageName: String?
        var text: String?
        var color: UIColor?
        switch item?.m3u8Item.status {
        case .downloaded:
            imageName = "download_complete"
            text = "下载完成"
            color = rgb(255, 177, 47)
        case .downloading:
            imageName = "download_suspend"
            let progressText = String(format: "%.2f%%", (item?.m3u8Item.percent ?? 0) * 100)
            text = "下载中(\(progressText))"
            color = rgb(255, 177, 47)
        default:
            imageName = "download_resume"
            text = "暂停中"
            color = rgb(255, 3, 28)
        }
        downloadButton.setImage(UIImage(named: imageName!), for: .normal)
        downloadLabel.text = text
        downloadLabel.textColor = color
    }
    
    func setupDownloadCallback() {
        item!.m3u8Item.progress = {[weak self] (received, expectedToReceive) -> Void in
            let progressText = String(format: "%.2f%%", (Float(received) / Float(expectedToReceive)) * 100)
            self?.downloadLabel.text = "下载中(\(progressText))"
        }
        item!.m3u8Item.completion = {[weak self] (error, String) -> Void in
            if let e = error as NSError? {
                self?.downloadLabel.text = e.localizedDescription
                return
            }
            self?.setupDownloadStatus()
        }
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    
}
