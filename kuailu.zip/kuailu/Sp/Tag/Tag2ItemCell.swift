//
//  Tag2ItemCell.swift
//  Sp
//
//  Created by mac on 2021/1/22.
//  Copyright © 2021 mac. All rights reserved.
//

import UIKit

class Tag2ItemCell: UICollectionViewCell {
    
    private lazy var tableView: UITableView = {
        let tableView = UITableView(frame: .zero, style: .grouped)
        tableView.delegate = self
        tableView.dataSource = self
        tableView.backgroundColor = .none
        tableView.separatorStyle = .none
        tableView.rowHeight = FeaturedTopicListItemSubCell.itemHeight
        tableView.estimatedRowHeight = tableView.rowHeight
        tableView.contentInsetAdjustmentBehavior = .never
        tableView.register(FeaturedTopicListItemSubCell.self, forCellReuseIdentifier: "FeaturedTopicListItemSubCell")
        tableView.showsHorizontalScrollIndicator = false
        tableView.bouncesZoom = false
        tableView.contentInset = UIEdgeInsets(top: 0, left: 0, bottom: 10, right: 0)
        tableView.state = .loading
        tableView.mj_header = getCommonMJHeader(refreshingTarget: self, headerRefreshCallback: #selector(onRefresh))
        tableView.mj_footer = getCommonMJFooter(refreshingTarget: self, footerRefreshCallback: #selector(onLoad))
        return tableView
    }()
    
    private var listData: [VideoItem] = []
    
    private var isInitState: Bool = true
    
    var itemType: FeaturedTopicDetailsType = .latest
    
    var tagTitle: String = "" {
        didSet {
            guard isInitState else { return }
            isInitState = false
            initList()
        }
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        addSubview(tableView)
        
        tableView.snp.makeConstraints { (make) in
            make.top.bottom.equalToSuperview()
            make.left.right.equalToSuperview().inset(3)
        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    private func initList() {
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.4) { [weak self] in
            self?.onRefresh()
        }
    }
    
    private func getList(isRefresh: Bool) {
        tableView.state = listData.isEmpty ? .loading : .normal
        if isRefresh {
            tableView.mj_footer?.resetNoMoreData()
        }
        let req = SmallVideoTopicTagsDetailsListReq()
        req.lastId = isRefresh ? 0 : (listData.last?.videoId ?? 0)
        req.choiceSort = itemType.rawValue
        req.tagTitle = tagTitle
        req.videoType = 2
        let tableView = self.tableView
        Session.request(req) { [weak self] (error, resp) in
            isRefresh ? tableView.mj_header?.endRefreshing() : tableView.mj_footer?.endRefreshing()
            guard let `self` = self else { return }
            guard error == nil, let resData = resp as? [VideoItem] else {
                self.handleListException(isRefresh: isRefresh)
                return
            }
            
            self.listData = isRefresh ? resData : self.listData + resData
            let isEmpty = self.listData.isEmpty
            tableView.mj_footer?.isHidden = isEmpty
            tableView.state = isEmpty ? .empty : .normal
            tableView.reloadData()
            if resData.count < req.pageSize {
                tableView.mj_footer?.endRefreshingWithNoMoreData()
            }
            
        }
    }
    
    private func handleListException(isRefresh: Bool) {
        if isRefresh {
            listData = []
            tableView.reloadData()
            tableView.state = .failed
            tableView.mj_footer?.isHidden = true
        } else {
            tableView.mj_footer?.endRefreshingWithNoMoreData()
            tableView.mj_footer?.isHidden = false
        }
    }
    
    @objc private func onRefresh() {
        getList(isRefresh: true)
    }
    
    @objc private func onLoad() {
        getList(isRefresh: false)
    }
}

extension Tag2ItemCell: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return listData.count
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return .leastNonzeroMagnitude
    }
    
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return .leastNonzeroMagnitude
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        return nil
    }
    
    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        return nil
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "FeaturedTopicListItemSubCell", for: indexPath) as! FeaturedTopicListItemSubCell
        cell.dataModel = listData[indexPath.row]
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        guard let navigationController = (UIApplication.shared.delegate as? AppDelegate)?.currentNavigationController else { return }
        let vc = PlayerController()
        vc.videoId = listData[indexPath.row].videoId
        navigationController.pushViewController(vc, animated: true)
    }
    
}

