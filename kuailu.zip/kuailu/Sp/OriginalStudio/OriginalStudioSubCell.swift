//
//  OriginalStudioSubCell.swift
//  Sp
//
//  Created by mac on 2020/11/10.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class OriginalStudioSubCell: UICollectionViewCell {
    
    static let viewHeight: CGFloat = {
        return OriginalStudioSubCell.bgImgViewHeight
    }()
    
    static let viewWidth: CGFloat = {
        return (UIScreen.main.bounds.width - 12 * 2 - 3 - 2 * OriginalStudioCell.itemInteritemSpacing) / 3
    }()
    
    private static let bgImgSizeRatio: CGFloat = 104 / 142
    
    private static let bgImgViewHeight: CGFloat = {
        return OriginalStudioSubCell.viewWidth / OriginalStudioSubCell.bgImgSizeRatio
    }()
    
    private static let avatarSize: CGFloat = 60
    
    private static let bgImg: UIImage? = {
        return UIImage(named: "original_studio_bg")
    }()
    
    private static let avatarImg: UIImage? = {
        return Sensitive.avatar
    }()
    
    private lazy var bgImgView: UIImageView = {
        let imgView = UIImageView(image: OriginalStudioSubCell.bgImg)
        imgView.contentMode = .scaleAspectFill
        imgView.layer.masksToBounds = true
        imgView.layer.cornerRadius = 2
        return imgView
    }()
    
    private lazy var avatarImgView: UIImageView = {
        let imgView = UIImageView()
        imgView.layer.masksToBounds = true
        imgView.contentMode = .scaleAspectFill
        imgView.layer.cornerRadius = OriginalStudioSubCell.avatarSize / 2
        imgView.layer.borderWidth = 1
        imgView.layer.borderColor = rgb(0x9E9E9E).cgColor
        return imgView
    }()
    
    private lazy var nicknameLabel: UILabel = {
        let label = UILabel()
        label.textColor = .white
        label.textAlignment = .center
        label.numberOfLines = 1
        label.lineBreakMode = .byCharWrapping
        label.font = UIFont.pingFangRegular(16)
        return label
    }()
    
    private lazy var worksLabel: UILabel = {
        let label = UILabel()
        label.textColor = rgb(0xC2C2C2)
        label.numberOfLines = 1
        label.textAlignment = .center
        label.font = UIFont.pingFangRegular(14)
        return label
    }()
    
    private lazy var focusLabel: UILabel = {
        let label = UILabel()
        label.textColor = rgb(0xC2C2C2)
        label.numberOfLines = 1
        label.textAlignment = .center
        label.font = UIFont.pingFangRegular(14)
        return label
    }()
    
    var dataModel: ContentItem? {
        didSet {
            guard let item = dataModel else { return }
            avatarImgView.kf.setImage(with: item.headImg?.column3, placeholder: OriginalStudioSubCell.avatarImg, options: ClassyScrollListRecomMoreExcitingSubCell.animationOption)
            nicknameLabel.text = item.contentName
            worksLabel.text = "作品：\(item.videoNum)"
            focusLabel.text = "關注：\(item.fakeAttentionNum)"
        }
    }
    
    weak var delegate: GodnessCellDelegate?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        renderView()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func renderView() {
        addSubview(bgImgView)
        addSubview(avatarImgView)
        addSubview(nicknameLabel)
        addSubview(worksLabel)
        addSubview(focusLabel)
        
        bgImgView.snp.makeConstraints { (make) in
            make.top.left.right.equalToSuperview()
            make.height.equalTo(OriginalStudioSubCell.bgImgViewHeight)
        }
        
        avatarImgView.snp.makeConstraints { (make) in
            make.top.equalToSuperview().inset(8)
            make.centerX.equalToSuperview()
            make.size.equalTo(OriginalStudioSubCell.avatarSize)
        }
        
        nicknameLabel.snp.makeConstraints { (make) in
            make.top.equalTo(avatarImgView.snp.bottom).offset(4)
            make.left.right.equalToSuperview().inset(5)
        }
        
        worksLabel.snp.makeConstraints { (make) in
            make.top.equalTo(nicknameLabel.snp.bottom).offset(4)
            make.left.right.equalToSuperview().inset(4)
        }
        
        focusLabel.snp.makeConstraints { (make) in
            make.top.equalTo(worksLabel.snp.bottom).offset(4)
            make.left.right.equalToSuperview().inset(4)
        }
        
    }
    
}
