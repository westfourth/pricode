//
//  OriginalStudioCommonCell.swift
//  Sp
//
//  Created by mac on 2020/11/10.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class OriginalStudioCell: UITableViewCell {
    
    static let itemLineSpacing: CGFloat = 12
    
    static let itemInteritemSpacing: CGFloat = 12
    
    private static let itemSize: CGSize = {
        return CGSize(width: OriginalStudioSubCell.viewWidth, height: OriginalStudioSubCell.viewHeight)
    }()
    
    private lazy var headerBar: ActressSubListItemHeaderBar = {
        return ActressSubListItemHeaderBar()
    }()
    
    private lazy var collectionView: UICollectionView = {
        let layout = UICollectionViewFlowLayout()
        layout.itemSize = OriginalStudioCell.itemSize
        layout.minimumLineSpacing = OriginalStudioCell.itemLineSpacing
        layout.minimumInteritemSpacing = OriginalStudioCell.itemInteritemSpacing
        layout.sectionInset = UIEdgeInsets(top: 0, left: 12, bottom: 0, right: 12)
        let cv = UICollectionView(frame: .zero, collectionViewLayout: layout)
        cv.register(OriginalStudioSubCell.self, forCellWithReuseIdentifier: "OriginalStudioSubCell")
        cv.backgroundColor = .none
        cv.delegate = self
        cv.dataSource = self
        cv.isScrollEnabled = false
        cv.showsVerticalScrollIndicator = false
        cv.showsHorizontalScrollIndicator = false
        return cv
    }()
    
    private var listData: [ContentItem] = []
    
    var dataModel: OriginalStudioListResp? {
        didSet {
            guard let item = dataModel else { return }
            headerBar.titleLabel.text = item.stationName
            listData = item.contentList
            collectionView.reloadData()
        }
    }
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        backgroundColor = .none
        selectionStyle = .none
        contentView.addSubview(headerBar)
        contentView.addSubview(collectionView)
        
        headerBar.snp.makeConstraints { (make) in
            make.top.left.right.equalToSuperview()
            make.height.equalTo(ActressSubListItemHeaderBar.viewHeight)
        }
        
        collectionView.snp.makeConstraints { (make) in
            make.top.equalTo(headerBar.snp.bottom)
            make.left.right.bottom.equalToSuperview()
        }
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}

extension OriginalStudioCell: UICollectionViewDelegate, UICollectionViewDataSource {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return listData.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "OriginalStudioSubCell", for: indexPath) as! OriginalStudioSubCell
        cell.dataModel = listData[indexPath.row]
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        guard let navigationController = (UIApplication.shared.delegate as? AppDelegate)?.currentNavigationController else { return }
        let actressDetailsVC = ActressDetailsVC()
        actressDetailsVC.contentId = listData[indexPath.row].contentId
        navigationController.show(actressDetailsVC, sender: nil)
    }
}
