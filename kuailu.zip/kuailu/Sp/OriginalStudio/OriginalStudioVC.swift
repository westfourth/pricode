//
//  OriginalStudioVC.swift
//  Sp
//
//  Created by mac on 2020/11/10.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class OriginalStudioVC: UIViewController {
    
    private lazy var headerView: ActressSubListItemHeaderView = {
        return ActressSubListItemHeaderView()
    }()
    
    private lazy var tableView: UITableView = {
        let tableView = UITableView(frame: CGRect.zero, style: .grouped)
        tableView.delegate = self
        tableView.dataSource = self
        tableView.backgroundColor = .none
        tableView.separatorStyle = .none
        tableView.showsHorizontalScrollIndicator = false
        tableView.register(OriginalStudioCell.self, forCellReuseIdentifier: "OriginalStudioCell")
        tableView.contentInset = UIEdgeInsets(top: 0, left: 0, bottom: 20, right: 0)
        return tableView
    }()
    
    private var headerViewHeight: CGFloat = 0
    
    private var listData: [OriginalStudioListResp] = []
    
    private var isInitState: Bool = true
    
    private var activeIndex: Int = 0
    
    private var areaId: Int = 0
    
    private var banners: [AdvertiseResp] = []
    
    var categoryData: AVRecommendSpecialAreaResp? {
        didSet {
            guard let item = categoryData else { return }
            guard isInitState else { return }
            isInitState = false
            navigationItem.title = item.areaName
            areaId = item.areaId
            banners = AdManager.shared.AVOriginalBanners
            if !banners.isEmpty {
                headerView.bannerListData = banners
                headerViewHeight = FeaturedTopicHeaderView.maxViewHeight
                tableView.reloadData()
            }
            Alert.showLoading(parentView: self.view)
            getList()
        }
    }
    
    override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: Bundle?) {
        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
        hidesBottomBarWhenPushed = true
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationController?.navigationBar.isTranslucent = false
        view.backgroundColor = RGB(0x141516)
        if #available(iOS 11.0, *) {
            tableView.contentInsetAdjustmentBehavior = .never
        } else {
            automaticallyAdjustsScrollViewInsets = false
        }
        view.addSubview(tableView)
        
        tableView.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.navigationBar.isTranslucent = false
        navigationController?.navigationBar.barTintColor = RGB(0x141516)
    }
    
    private func getList() {
        Alert.showLoading(parentView: self.view)
        let req = OriginalStudioListReq()
        req.areaId = areaId
        Session.request(req) { [weak self] (error, resp) in
            Alert.hideLoading()
            guard let `self` = self, error == nil, let resData = resp as? [OriginalStudioListResp], !resData.isEmpty else { return }
            self.listData = resData
            self.tableView.reloadData()
        }
    }
    
    private func getMoreActressCellHegiht(section: Int) -> CGFloat {
        let totalNum = listData[section].contentList.count
        let itemRowNumber = totalNum % 3 == 0 ? totalNum / 3 : (totalNum + 1) / 3
        return (OriginalStudioSubCell.viewHeight + OriginalStudioCell.itemLineSpacing) * CGFloat(itemRowNumber) - OriginalStudioCell.itemLineSpacing
    }
    
}

extension OriginalStudioVC: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return listData.count
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return headerViewHeight
    }
    
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return .leastNonzeroMagnitude
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        return headerView
    }
    
    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        return nil
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return ActressSubListItemHeaderBar.viewHeight + getMoreActressCellHegiht(section: indexPath.row)
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "OriginalStudioCell", for: indexPath) as! OriginalStudioCell
        cell.dataModel = listData[indexPath.row]
        return cell
    }
    
}
