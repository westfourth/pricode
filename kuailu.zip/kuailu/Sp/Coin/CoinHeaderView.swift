//
//  CoinHeaderView.swift
//  Sp
//
//  Created by mac on 2021/1/20.
//  Copyright © 2021 mac. All rights reserved.
//

import UIKit

class CoinHeaderView: UITableViewHeaderFooterView {
    
    private static let sizeRatio: CGFloat = 336 / 165
    
    private static let bannerHeight: CGFloat = {
        return (UIScreen.main.bounds.width - 12 * 2) / CoinHeaderView.sizeRatio
    }()
    
    private static let marginTop: CGFloat = 20
    
    private static let marginBottom: CGFloat = {
        return CoinVC.tabBarFloatViewHeight + 10
    }()
    
    static let maxViewHeight: CGFloat = {
        return CoinHeaderView.marginTop +  CoinHeaderView.bannerHeight + CoinHeaderView.marginBottom
    }()
    
    static let minViewHeight: CGFloat = CoinVC.tabBarFloatViewHeight
    
    private lazy var cycleScrollView: CycleScrollView = {
        let cycleScrollView = CycleScrollView()
        cycleScrollView.delegate = self
        cycleScrollView.dataSource = self
        cycleScrollView.register(AVCycleScrollViewCell.self, forCellWithReuseIdentifier: "AVCycleScrollViewCell")
        cycleScrollView.layer.masksToBounds = true
        cycleScrollView.layer.cornerRadius = 4
        return cycleScrollView
    }()
    
    private var isInitState: Bool = true
    
    private var activeIndex: Int = 0
    
    var bannerListData: [AdvertiseResp] = [] {
        didSet {
            guard isInitState else { return }
            isInitState = false
            guard !bannerListData.isEmpty else { return }
            cycleScrollView.snp.updateConstraints { (make) in
                make.top.equalToSuperview().inset(CoinHeaderView.marginTop)
                make.height.equalTo(CoinHeaderView.bannerHeight)
            }
            cycleScrollView.reloadData()
        }
    }
    
    override init(reuseIdentifier: String?) {
        super.init(reuseIdentifier: reuseIdentifier)
        addSubview(cycleScrollView)
        
        cycleScrollView.snp.makeConstraints { (make) in
            make.top.equalToSuperview().inset(0)
            make.left.right.equalToSuperview().inset(12)
            make.height.equalTo(0)
        }
    
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}

extension CoinHeaderView: CycleScrollViewDataSource {
    
    func numberOfItems(in cycleScrollView: CycleScrollView) -> Int {
        return bannerListData.count
    }
    
    func cycleScrollView(_ cycleScrollView: CycleScrollView, cellForItemAt index: Int) -> UICollectionViewCell {
        let cell = cycleScrollView.dequeueReusableCell(withReuseIdentifier: "AVCycleScrollViewCell", for: index) as! AVCycleScrollViewCell
        cell.bannerImgUrl = bannerListData[index].adImage
        return cell
    }
    
}

extension CoinHeaderView: CycleScrollViewDelegate {
    
    func cycleScrollView(_ cycleScrollView: CycleScrollView, didSelectItemAt index: Int) {
        guard index < bannerListData.count else { return }
        let currentItem = bannerListData[index]
        guard let url = currentItem.adJump else { return }
        InnerIntercept.open(url)
    }
    
}
