//
//  ClassyVideoSetCell.swift
//  Sp
//
//  Created by mac on 2020/3/27.
//  Copyright © 2020 mac. All rights reserved.
//


class ClassyVideoSetCell: UICollectionViewCell {
    
    static let itemWidth: CGFloat = (UIScreen.main.bounds.size.width - 2 * 3 - 2 * 3) / 3
    
    private static let posterRatio: CGFloat = 119 / 144
    
    private static let posterHeight: CGFloat = ClassyVideoSetCell.itemWidth / ClassyVideoSetCell.posterRatio
    
    static let itemHeight: CGFloat = ClassyVideoSetCell.posterHeight + 2 + 30
    
    static let defaultImg: UIImage? = {
        return Sensitive.default_bg
    }()
    
    static let animationOption: KingfisherOptionsInfo = {
        return [.transition(.fade(0.25))]
    }()
    
    private static let collectionIconImg: UIImage? = {
        return UIImage(named: "ic_b_like_2")
    }()
    
    private static let gradientColors: [CGColor] = {
        return [RGB(36,3,33).withAlphaComponent(0.0).cgColor, RGB(36,3,33).withAlphaComponent(0.66).cgColor]
    }()
    
    private static let gradientLocations: [NSNumber] = {
        return [0.0, 1.0]
    }()
    
    private static let lockIconImg: UIImage? = {
        return UIImage(named: "ic_lock")
    }()
    
    private static let v6IconImg: UIImage? = {
        return UIImage(named: "v6_icon")
    }()
    
    private lazy var posterImgView: UIImageView = {
        let imgView = UIImageView()
        imgView.contentMode = .scaleAspectFill
        imgView.layer.masksToBounds = true
        return imgView
    }()
    
    private lazy var collectionIconImgView: UIImageView = {
        let imgView = UIImageView(image: ClassyVideoSetCell.collectionIconImg)
        return imgView
    }()
    
    private lazy var collectionNumberLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.pingFangRegular(12)
        label.textColor = .white
        return label
    }()
    
    private lazy var maskLayerView: UIView = {
        let maskView = UIView()
        let gradientLayer = CAGradientLayer()
        gradientLayer.colors = ClassyVideoSetCell.gradientColors
        gradientLayer.locations = ClassyVideoSetCell.gradientLocations
        gradientLayer.frame = CGRect(x: 0, y: 0, width: self.width, height: 30)
        maskView.layer.insertSublayer(gradientLayer, at: 0)
        maskView.addSubview(collectionNumberLabel)
        maskView.addSubview(collectionIconImgView)
        
        collectionNumberLabel.snp.makeConstraints { (make) in
            make.right.equalToSuperview().inset(4)
            make.bottom.equalToSuperview().inset(2)
        }
        
        collectionIconImgView.snp.makeConstraints { (make) in
            make.centerY.equalTo(collectionNumberLabel)
            make.size.equalTo(12)
            make.right.equalTo(collectionNumberLabel.snp.left).offset(-2)
        }
        return maskView
    }()
    
    private lazy var titleLabel: CustomLabel = {
        let label = CustomLabel()
        label.textColor = .white
        label.font = UIFont.pingFangRegular(11)
        label.numberOfLines = 2
        label.verticalAlignment = .top
        return label
    }()
    
    private lazy var v6ImgView: UIImageView = {
        let imgView = UIImageView(image: ClassyVideoSetCell.v6IconImg)
        imgView.isHidden = true
        return imgView
    }()
    
    private lazy var lockImgView: UIImageView = {
        let imgView = UIImageView(image: ClassyVideoSetCell.lockIconImg)
        return imgView
    }()
    
    private lazy var lockLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.pingFangRegular(12)
        label.textColor = .white
        label.text = "V6專享視頻"
        return label
    }()
    
    private lazy var lockMaskView: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor.black.withAlphaComponent(0.3)
        view.addSubview(lockImgView)
        view.addSubview(lockLabel)
        view.isHidden = true
        
        lockImgView.snp.makeConstraints { (make) in
            make.centerX.equalToSuperview()
            make.centerY.equalToSuperview().offset(-14)
            make.width.equalTo(40)
            make.height.equalTo(44)
        }
        
        lockLabel.snp.makeConstraints { (make) in
            make.centerX.equalToSuperview()
            make.top.equalTo(lockImgView.snp.bottom).offset(10)
        }
        return view
    }()
    
    var dataModel: VideoItem? {
        didSet {
            guard let item = dataModel else { return }
            posterImgView.kf.setImage(with: item.coverImg?.column3, placeholder: ClassyVideoSetCell.defaultImg, options: ClassyVideoSetCell.animationOption)
            collectionNumberLabel.text = item.fakeLikes > 0 ? num2TenThousandStrFormat(item.fakeLikes) : "0"
            titleLabel.text = item.title
            lockMaskView.isHidden = !(item.isSpecial && NetDefaults.userInfo?.specialAuth != true)
            v6ImgView.isHidden = !item.isSpecial
        }
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        renderView()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func renderView() {
        addSubview(posterImgView)
        addSubview(maskLayerView)
        addSubview(titleLabel)
        addSubview(lockMaskView)
        addSubview(v6ImgView)
        
        posterImgView.snp.makeConstraints { (make) in
            make.top.left.right.equalToSuperview()
            make.height.equalTo(ClassyVideoSetCell.posterHeight)
        }
        
        maskLayerView.snp.makeConstraints { (make) in
            make.left.right.equalToSuperview()
            make.bottom.equalTo(posterImgView)
            make.height.equalTo(30)
        }
        
        titleLabel.snp.makeConstraints { (make) in
            make.top.equalTo(posterImgView.snp.bottom).offset(2)
            make.left.right.equalToSuperview().inset(3)
            make.bottom.equalToSuperview()
        }
        
        lockMaskView.snp.makeConstraints { (make) in
            make.edges.equalTo(posterImgView)
        }
        
        v6ImgView.snp.makeConstraints { (make) in
            make.top.equalToSuperview().inset(8)
            make.left.equalToSuperview()
            make.width.equalTo(42)
            make.height.equalTo(14)
        }
    }
}
