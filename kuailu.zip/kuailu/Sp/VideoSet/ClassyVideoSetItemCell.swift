//
//  ClassyVideoSetItemCell.swift
//  Sp
//
//  Created by mac on 2020/3/27.
//  Copyright © 2020 mac. All rights reserved.
//


class ClassyVideoSetItemCell: UICollectionViewCell {
    
    private static let itemInteritemSpacing: CGFloat = 8
    
    private static let itemLineSpacing: CGFloat = 10
    
    private static let itemEdgeInsetMargin: CGFloat = 12
    
    private lazy var collectionView: UICollectionView = {
        let layout = UICollectionViewFlowLayout()
        layout.itemSize = CGSize(width: SmallVideoRecommendVerticalFourGridCell.itemWidth, height: SmallVideoRecommendVerticalFourGridCell.itemHeight)
        layout.minimumInteritemSpacing = ClassyVideoSetItemCell.itemInteritemSpacing
        layout.minimumLineSpacing = ClassyVideoSetItemCell.itemLineSpacing
        layout.sectionInset = UIEdgeInsets(top: 0, left: ClassyVideoSetItemCell.itemEdgeInsetMargin, bottom: 0, right: ClassyVideoSetItemCell.itemEdgeInsetMargin)
        let cv = UICollectionView(frame: .zero, collectionViewLayout: layout)
        cv.register(SmallVideoRecommendVerticalFourGridCell.self, forCellWithReuseIdentifier: "SmallVideoRecommendVerticalFourGridCell")
        cv.showsHorizontalScrollIndicator = false
        cv.bouncesZoom = false
        cv.backgroundColor = .none
        cv.state = .loading
        cv.delegate = self
        cv.dataSource = self
        cv.mj_header = getCommonMJHeader(refreshingTarget: self, headerRefreshCallback: #selector(onRefresh))
        cv.mj_footer = getCommonMJFooter(refreshingTarget: self, footerRefreshCallback: #selector(onLoad))
        return cv
    }()
    
    var itemType: ClassyVideoSetItemType = .latest
    
    private var isInitState: Bool = true
    
    var choiceId: Int = 0 {
        didSet {
            guard isInitState else { return }
            isInitState = false
            initList()
        }
    }
    
    var tagTitle: String = "" {
        didSet {
            guard isInitState else { return }
            isInitState = false
            initList()
        }
    }
    
    private var listData: [VideoItem] = []
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        addSubview(collectionView)
        
        collectionView.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    private func initList() {
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.4) { [weak self] in
            self?.onRefresh()
        }
    }
    
    private func getList(isRefresh: Bool) {
        let isLatestTab = itemType == .latest
        collectionView.state = listData.isEmpty ? .loading : .normal
        if isRefresh {
            collectionView.mj_footer?.resetNoMoreData()
        }
        var classyReq: ClassySearchVideoReq?
        var homeReq: HomeTagSerachVideoReq?
        let isFromClassy = ClassyVideoSetVC.isFromClassy
        let videoIds = isRefresh ? [] : listData.map{ $0.videoId }
        let choiceSort = isLatestTab ? 1 : 2
        if isFromClassy {
            classyReq = ClassySearchVideoReq()
            classyReq!.choiceId = choiceId
            classyReq!.videoIds = videoIds
            classyReq!.choiceSort = choiceSort
        } else {
            homeReq = HomeTagSerachVideoReq()
            homeReq!.tagTitle = tagTitle
            homeReq!.videoIds = videoIds
            homeReq!.choiceSort = choiceSort
        }
        let pageSize = isFromClassy ? classyReq!.pageSize : homeReq!.pageSize
        let collectionView = self.collectionView
        Session.request(isFromClassy ? classyReq! : homeReq!) { [weak self] (error, resp) in
            isRefresh ? collectionView.mj_header?.endRefreshing() : collectionView.mj_footer?.endRefreshing()
            guard let `self` = self else { return }
            
            guard error == nil, let resData = resp as? [VideoItem] else {
                self.handleListException(isRefresh: isRefresh)
                return
            }
            
            if resData.count < pageSize {
                collectionView.mj_footer?.endRefreshingWithNoMoreData()
            }
            
            self.listData = isRefresh ? resData : self.listData + resData
            let isEmpty = self.listData.isEmpty
            collectionView.mj_footer?.isHidden = isEmpty
            collectionView.state = isEmpty ? .empty : .normal
            collectionView.reloadData()
        }
    }
    
    private func handleListException(isRefresh: Bool) {
        if isRefresh {
            listData = []
            collectionView.reloadData()
            collectionView.state = .failed
            collectionView.mj_footer?.isHidden = true
        } else {
            collectionView.mj_footer?.endRefreshingWithNoMoreData()
            collectionView.mj_footer?.isHidden = false
        }
    }
    
    @objc private func onRefresh() {
        getList(isRefresh: true)
    }
    
    @objc private func onLoad() {
        getList(isRefresh: false)
    }
}

extension ClassyVideoSetItemCell: UICollectionViewDelegate ,UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return listData.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "SmallVideoRecommendVerticalFourGridCell", for: indexPath) as! SmallVideoRecommendVerticalFourGridCell
        cell.dataModel = listData[indexPath.row]
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        SearchResultVC.navigationToVideoPlayListVC(indexPath: indexPath, VideoList: listData)
    }
}
