//
//  AppDelegate.swift
//  Sp
//
//  Created by mac on 2020/2/17.
//  Copyright © 2020 mac. All rights reserved.
//

/// 全域性汇入，保持精简
@_exported import Public
@_exported import XSVendor
@_exported import NetRequest

@_exported import MBProgressHUD
@_exported import MJRefresh
@_exported import SnapKit
@_exported import Kingfisher
@_exported import MP3Player
@_exported import AVResourceLoader

import UIKit
import AppTrackingTransparency

#if APP_TF
import KKNote
#endif

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate, LaunchVCDelegate {
    
    var window: UIWindow?
    var window2: UIWindow?
    
    /// #获取tabbar
    var tabbar: UITabBar? {
        return (window?.rootViewController as? UITabBarController)?.tabBar
    }
    
    /// #获取当前活动的UINavigationController
    var currentNavigationController: UINavigationController? {
        return (window?.rootViewController as? UITabBarController)?.selectedViewController as? UINavigationController
    }
    
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        print(NSTemporaryDirectory())
        
        setupWindow2()
        UIViewController.noRotateAndOnlyPortrait()
        
        //  图片解码、裁剪
        KingfisherManager.shared.defaultOptions = [.processor(CustomImageProcessor()), .requestModifier(CustomRequestModifier())]
        //  扩大slider点击范围
        GlobalSettings.expandSliderHitScope()
        GlobalSettings.setupAppearance()
        
        DispatchQueue.global().async {
            Downloader.read()       //  读取下载视频数据
        }
        
        //  防止息屏
        application.isIdleTimerDisabled = true
        //
        setupWindow()
        
        #if DEBUG
        if Defaults.debugJumpLaunch {
            window?.rootViewController = TabBarController.createTabbarController()
        }
        #endif
        
        requestIDFA()
        return true
    }
    
    func applicationWillEnterForeground(_ application: UIApplication) {
        //  启动app统计，需要token
        Session.request(LaunchAppReq()) { (error, resp) in }
    }
    
    func applicationWillTerminate(_ application: UIApplication) {
        //
        ShortVideoCounter.share.write()
        //  保存下载视频数据
        Downloader.write()
    }
    
    func application(_ application: UIApplication, supportedInterfaceOrientationsFor window: UIWindow?) -> UIInterfaceOrientationMask {
        return .allButUpsideDown
    }
    
    func requestIDFA() {
        if #available(iOS 14, *) {
            if ATTrackingManager.trackingAuthorizationStatus == .notDetermined {
                ATTrackingManager.requestTrackingAuthorization { (status) in
                    if status == .authorized {
                        DispatchQueue.main.async {
                            let launchVC = LaunchVC()
                            launchVC.delegate = self
                            self.window?.rootViewController = launchVC
                        }
                    }
                }
            }
        }
    }
    
    //  window
    func setupWindow() {
        window = UIWindow()
        window?.frame = UIScreen.main.bounds
        window?.makeKeyAndVisible()
        let launchVC = LaunchVC()
        launchVC.delegate = self
        window?.rootViewController = launchVC
        //            TabBarController.createTabbarController()
    }
    
    /// LaunchVCDelegate
    func didExist(launchVC: LaunchVC, didPassReview: Bool) {
        enterMainPage(didPassReview: didPassReview)
        guard let user = NetDefaults.userInfo else {return}
        guard user.recharge == true,!Defaults.accountCerSaved else {return}
        guard let stamp = Defaults.accountCerDateTimeStamp  else {
            alertAccountVC()
            return
        }
        if Date().timeIntervalSince1970 - stamp > (7 * 24 * 3600) {
            alertAccountVC()
        }
    }
    
    // 弹出保存页面
    func alertAccountVC() {
        let cerVc = AccountCerVC()
        cerVc.isLunch = true
        let navi = UINavigationController(rootViewController: cerVc)
        Defaults.accountCerDateTimeStamp = Date().timeIntervalSince1970
        navi.modalPresentationStyle = .fullScreen
        InnerIntercept.currentNaviController().present(navi, animated: true, completion: nil)
    }
    
    func enterMainPage(didPassReview:Bool) {
        if didPassReview {
            self.window?.rootViewController = TabBarController.createTabbarController()
            UIApplication.shared.renewIcon(name: "icon1")
        } else {
            #if APP_TF
            let b = Bundle(for: KKDiaryViewController.self)
            let sb = UIStoryboard(name: "Main", bundle: b)
            let vc = sb.instantiateInitialViewController()
            self.window?.rootViewController = vc
            #else
            self.window?.rootViewController = TabBarController.createTabbarController()
            #endif
        }
    }
    //MARK:-内部跳转链接
    //    func application(_ app: UIApplication, open url: URL, options: [UIApplication.OpenURLOptionsKey : Any] = [:]) -> Bool {
    //        if url.scheme == "inner" && url.host == "cao" {
    //            InnerIntercept.handel(url)
    //            return false
    //        }
    //        return true
    //    }
    
    func setupWindow2() {
        if #available(iOS 13, *) {
            var windowScene: UIWindowScene?
            for scene in UIApplication.shared.connectedScenes {
                if scene.activationState == .foregroundActive {
                    windowScene = scene as! UIWindowScene
                }
                if UIApplication.shared.connectedScenes.count == 1 && windowScene == nil {
                    windowScene = scene as! UIWindowScene
                }
            }
            if windowScene != nil {
                window2 = UIWindow(windowScene: windowScene!)
            } else {
                window2 = UIWindow()
            }
        } else {
            window2 = UIWindow()
        }
    }
    

}


extension UIApplication {
    /// 更换icon
    /// - Parameter name: 为nil时，更换成Assets.xcassets中的AppIcon
    func renewIcon(name: String?) {
        #if APP_TF
        guard supportsAlternateIcons else {
            return
        }
        if alternateIconName == name {
            return;
        }
        setAlternateIconName(name) { (error) in
            puts(">>> 更換icon1");
        }
        #endif
    }
}
