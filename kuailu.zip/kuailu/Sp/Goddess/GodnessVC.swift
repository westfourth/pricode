//
//  GodnessVC.swift
//  Sp
//
//  Created by mac on 2020/8/18.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class GodnessVC: UIViewController {
    
    static let bottomLineHeight: CGFloat = 15
    
    private static let titleIcon: UIImage? = {
        return UIImage(named: "godness_title_icon")
    }()
    
    private lazy var titleView: UIButton = {
        let btn = UIButton()
        btn.setTitle("女神資料", for: .normal)
        btn.titleLabel?.font = UIFont.pingFangMedium(18)
        btn.setTitleColor(.white, for: .normal)
        btn.setImage(GodnessVC.titleIcon, for: .normal)
        btn.imagePosition(imageStyle: .left, spacing: 5)
        return btn
    }()
    
    private lazy var tableView: UITableView = {
        let tableView = UITableView(frame: .zero, style: .grouped)
        tableView.delegate = self
        tableView.dataSource = self
        tableView.backgroundColor = .none
        tableView.separatorStyle = .none
        tableView.bouncesZoom = false
        tableView.isDirectionalLockEnabled = true
        tableView.register(GodnessItemCell.self, forCellReuseIdentifier: "GodnessItemCell")
        tableView.state = .loading
        tableView.mj_header = getCommonMJHeader(refreshingTarget: self, headerRefreshCallback: #selector(onRefresh))
        tableView.mj_footer = getCommonMJFooter(refreshingTarget: self, footerRefreshCallback: #selector(onLoad))
        return tableView
    }()
    
    private lazy var emptyImg: UIImage = {
        return UIImage()
    }()
    
    private let titleValList: [String] = ["新晉女神", "全部女神"]
    
    private var newGoddessListData: [BeautyItem] = []
    
    private var allGoddessListData: [BeautyItem] = []
    
    private var isShowList: Bool = false
    
    private lazy var titleViewList: [GodnessTitleView] = {
        var tempList: [GodnessTitleView] = []
        for i in 0..<titleValList.count {
            var titleView = GodnessTitleView()
            titleView.titleLabel.text = titleValList[i]
            tempList.append(titleView)
        }
        return tempList
    }()
    
    private lazy var pageNum: Int = 0
    
    override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: Bundle?) {
        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
        hidesBottomBarWhenPushed = true
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = RGB(0x141516)
        view.addSubview(titleView)
        view.addSubview(tableView)
        
        titleView.snp.makeConstraints { (make) in
            make.top.equalToSuperview().inset(kTop - 32.5)
            make.left.right.equalToSuperview()
            make.height.equalTo(25)
        }
        
        tableView.snp.makeConstraints { (make) in
            make.top.equalToSuperview().inset(kTop + 10)
            make.left.right.bottom.equalToSuperview()
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.navigationBar.isTranslucent = true
        navigationController?.navigationBar.setBackgroundImage(emptyImg, for: .default)
        navigationController?.navigationBar.shadowImage = emptyImg
        getList(isRefresh: true)
    }
    
    private func getList(isRefresh: Bool) {
        tableView.state = newGoddessListData.isEmpty && allGoddessListData.isEmpty ? .loading : .normal
        let req = BeautyListReq()
        let pageNum = self.pageNum
        req.page = isRefresh ? 1 : pageNum + 1
        let tableView = self.tableView
        Session.request(req) { [weak self] (error, resp) in
            isRefresh ? tableView.mj_header?.endRefreshing() : tableView.mj_footer?.endRefreshing()
            guard let `self` = self else { return }
            guard error == nil, let resData = resp as? BeautyListResp else {
                self.handleListException(isRefresh: isRefresh, pageNum: pageNum)
                return
            }
            self.pageNum = req.page
            if isRefresh {
                self.newGoddessListData = resData.data1
            }
            self.allGoddessListData = isRefresh ? resData.data2 : self.allGoddessListData + resData.data2
            let isEmpty = self.newGoddessListData.isEmpty && self.allGoddessListData.isEmpty
            self.isShowList = !isEmpty
            tableView.state = isEmpty ? .empty : .normal
            tableView.mj_footer?.isHidden = isEmpty
            if resData.data2.count < req.pageSize {
                tableView.mj_footer?.endRefreshingWithNoMoreData()
            }
            tableView.reloadData()
        }
    }
    
    private func handleListException(isRefresh: Bool, pageNum: Int) {
        if isRefresh || pageNum == 1 {
            newGoddessListData = []
            allGoddessListData = []
            tableView.state = .failed
            tableView.mj_footer?.isHidden = true
            isShowList = false
            tableView.reloadData()
        } else {
            tableView.state = .normal
            tableView.mj_footer?.endRefreshingWithNoMoreData()
            tableView.mj_footer?.isHidden = false
            isShowList = true
        }
    }
    
    @objc private func onLoad() {
        getList(isRefresh: false)
    }
    
    @objc private func onRefresh() {
        getList(isRefresh: true)
    }
    
}

extension GodnessVC: UITableViewDelegate, UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return isShowList ? titleValList.count : 0
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 24
    }
    
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return .leastNonzeroMagnitude
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        return titleViewList[section]
    }
    
    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        return nil
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        let num = indexPath.section == 0 ? newGoddessListData.count : allGoddessListData.count
        let row = CGFloat(num % 4 == 0 ? num / 4 : Int(num / 4) + 1)
        return row * (GodnessCell.viewHeight + GodnessItemCell.itemLineSpacing) + GodnessVC.bottomLineHeight
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let section = indexPath.section
        let cell = tableView.dequeueReusableCell(withIdentifier: "GodnessItemCell", for: indexPath) as! GodnessItemCell
        let isNewGoddess = section == 0
        cell.bottomLine.isHidden = !isNewGoddess
        cell.listData = isNewGoddess ? newGoddessListData : allGoddessListData
        return cell
    }
    
}
