//
//  GodnessCell.swift
//  Sp
//
//  Created by mac on 2020/8/18.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

protocol GodnessCellDelegate: NSObjectProtocol {
    
    func switchFocusStatus(dataModel: BeautyItem, cell: GodnessCell)
    
}

class GodnessCell: UICollectionViewCell {
    
    static let viewHeight: CGFloat = GodnessCell.viewWidth + 20 + 24
    
    static let viewWidth: CGFloat = (UIScreen.main.bounds.width - 12 * 2 - 8 * 3) / 4
    
    private lazy var posterImgView: UIImageView = {
        let imgView = UIImageView()
        imgView.layer.masksToBounds = true
        imgView.contentMode = .scaleAspectFill
        imgView.layer.cornerRadius = GodnessCell.viewWidth / 2
        return imgView
    }()
    
    private lazy var nicknameLabel: UILabel = {
        let label = UILabel()
        label.textColor = .white
        label.textAlignment = .center
        label.numberOfLines = 1
        label.lineBreakMode = .byCharWrapping
        label.font = UIFont.pingFangRegular(13)
        return label
    }()
    
    private lazy var attentionBtn: UIButton = {
        let btn = UIButton()
        btn.titleLabel?.font = UIFont.pingFangRegular(10)
        btn.addTarget(self, action: #selector(onCollectionBtnTap), for: .touchUpInside)
        return btn
    }()
    
    var dataModel: BeautyItem? {
        didSet {
            guard let item = dataModel else { return }
            posterImgView.kf.setImage(with: item.logo?.column3, placeholder: ClassyScrollListRecomMoreExcitingSubCell.defaultImg, options: ClassyScrollListRecomMoreExcitingSubCell.animationOption)
            nicknameLabel.text = item.nickName
            handleAttentionBtnState(isAttention: item.isAttention)
        }
    }
    
    weak var delegate: GodnessCellDelegate?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        renderView()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func renderView() {
        addSubview(posterImgView)
        addSubview(nicknameLabel)
        addSubview(attentionBtn)
        
        posterImgView.snp.makeConstraints { (make) in
            make.top.centerX.equalToSuperview()
            make.size.equalTo(GodnessCell.viewWidth)
        }
        
        nicknameLabel.snp.makeConstraints { (make) in
            make.top.equalTo(posterImgView.snp.bottom).offset(4)
            make.left.right.equalToSuperview()
        }
        
        attentionBtn.snp.makeConstraints { (make) in
            make.left.right.bottom.equalToSuperview()
        }
    }
    
    @objc private func onCollectionBtnTap() {
        guard let item = dataModel else { return }
        delegate?.switchFocusStatus(dataModel: item, cell: self)
    }
    
    func switchCollectionBtnStatus(isAttention: Bool)  {
        dataModel?.isAttention = isAttention
        handleAttentionBtnState(isAttention: isAttention)
    }
    
    private func handleAttentionBtnState(isAttention: Bool) {
        attentionBtn.setTitle(isAttention ? "已關注" : "加關注", for: .normal)
        attentionBtn.setTitleColor(isAttention ? RGB(0xA4A4A4) : RGB(0xFA6400), for: .normal)
    }
    
}
