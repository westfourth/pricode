//
//  GodnessTitleView.swift
//  Sp
//
//  Created by mac on 2020/8/19.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class GodnessTitleView: UIView {
    
    static let indexImg: UIImage? = {
        return UIImage(named: "godness_title_index_icon")
    }()
    
    private lazy var indexIcon: UIImageView = {
        let imgView = UIImageView(image: GodnessTitleView.indexImg)
        return imgView
    }()
    
    lazy var titleLabel: UILabel = {
        let label = UILabel()
        label.text = "新晋女神"
        label.textColor = .white
        label.font = UIFont.pingFangRegular(14)
        return label
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        renderView()
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func renderView() {
        addSubview(indexIcon)
        addSubview(titleLabel)
        
        indexIcon.snp.makeConstraints { (make) in
            make.left.equalToSuperview().inset(11)
            make.centerY.equalToSuperview()
            make.size.equalTo(10)
        }
        
        titleLabel.snp.makeConstraints { (make) in
            make.left.equalTo(indexIcon.snp.right).offset(8)
            make.right.equalToSuperview().inset(11)
            make.centerY.equalToSuperview()
        }
    }
    
}
