//
//  TableViewCellGodnessItemCell.swift
//  Sp
//
//  Created by mac on 2020/8/19.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class GodnessItemCell: UITableViewCell {
    
    static let itemLineSpacing: CGFloat = 30
    
    static let marginTop: CGFloat = 12
    
    static let marginBottom: CGFloat = 15
    
    private lazy var collectionView: UICollectionView = {
        let layout = UICollectionViewFlowLayout()
        layout.itemSize = CGSize(width: GodnessCell.viewWidth, height: GodnessCell.viewHeight)
        layout.minimumLineSpacing = GodnessItemCell.itemLineSpacing
        layout.minimumInteritemSpacing = 8
        let cv = UICollectionView(frame: .zero, collectionViewLayout: layout)
        cv.register(GodnessCell.self, forCellWithReuseIdentifier: "GodnessCell")
        cv.backgroundColor = .none
        cv.contentInset = UIEdgeInsets(top: GodnessItemCell.marginTop, left: 12, bottom: GodnessItemCell.marginBottom, right: 12)
        cv.delegate = self
        cv.dataSource = self
        cv.showsVerticalScrollIndicator = false
        cv.showsHorizontalScrollIndicator = false
        return cv
    }()
    
    lazy var bottomLine: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor.white.withAlphaComponent(0.05)
        view.isHidden = true
        return view
    }()
    
    var listData: [BeautyItem] = [] {
        didSet {
            collectionView.reloadData()
        }
    }
    
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        backgroundColor = .none
        selectionStyle = .none
        contentView.addSubview(collectionView)
        contentView.addSubview(bottomLine)
        collectionView.snp.makeConstraints { (make) in
            make.left.right.top.equalToSuperview()
            make.bottom.equalToSuperview().inset(GodnessVC.bottomLineHeight)
        }
        bottomLine.snp.makeConstraints { (make) in
            make.top.equalTo(collectionView.snp.bottom)
            make.left.right.equalToSuperview().inset(12)
            make.height.equalTo(0.5)
        }
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}

extension GodnessItemCell: UICollectionViewDelegate, UICollectionViewDataSource {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return listData.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "GodnessCell", for: indexPath) as! GodnessCell
        cell.delegate = self
        cell.dataModel = listData[indexPath.row]
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        guard let navigationController = (UIApplication.shared.delegate as? AppDelegate)?.currentNavigationController else { return }
        let usersDynamicVC = UsersDynamicVC()
        usersDynamicVC.userId = listData[indexPath.row].userId
        navigationController.show(usersDynamicVC, sender: nil)
    }
}

extension GodnessItemCell: GodnessCellDelegate {
    
    func switchFocusStatus(dataModel: BeautyItem, cell: GodnessCell) {
        guard dataModel.isAttention else {
            Alert.showLoading(parentView: UIApplication.shared.keyWindow!)
            let req = FocusUserReq()
            req.beenUserId = dataModel.userId
            Session.request(req) { (error, resp) in
                Alert.hideLoading()
                guard error == nil else {
                    mm_showToast(error!.localizedDescription)
                    return
                }
                cell.switchCollectionBtnStatus(isAttention: true)
                mm_showToast("關注成功!", type: .succeed)
            }
            return
        }
        
        Alert.showCommonAlert(parentView: UIApplication.shared.keyWindow!, contentText: "取消關注後,您將無法及時收到他的動態",
                              cancelText: "再看看",
                              confirmText: "取消關注",
                              onConfirmTap: {
                                Alert.showLoading(parentView: UIApplication.shared.keyWindow!)
                                let req = CancelFocusUserReq()
                                req.beenUserId = dataModel.userId
                                Session.request(req) { (error, resp) in
                                    Alert.hideLoading()
                                    guard error == nil else {
                                        mm_showToast(error!.localizedDescription)
                                        return
                                    }
                                    cell.switchCollectionBtnStatus(isAttention: false)
                                    mm_showToast("取消成功!", type: .succeed)
                                }
        }, onCancelTap: nil)
        
    }
}
