//
//  FeaturedTopicListItemSubCell.swift
//  Sp
//
//  Created by mac on 2020/11/23.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class FeaturedTopicListItemSubCell: UITableViewCell {
    
    static let itemHeight: CGFloat = {
        return FeaturedTopicListItemSubCell.marginTop + FeaturedTopicListItemSubCell.posterImgViewHeight + FeaturedTopicListItemSubCell.titleMarginTop + FeaturedTopicListItemSubCell.titleHeight
    }()
    
    private static let marginTop: CGFloat = 10
    
    private static let titleMarginTop: CGFloat = 9
    
    private static let titleHeight: CGFloat = 42
    
    private static let posterSizeRatio: CGFloat = 336 / 180
    
    private static let posterImgViewWidth: CGFloat = {
        return UIScreen.main.bounds.width - 12 * 2
    }()
    
    private static let posterImgViewHeight: CGFloat = {
        return FeaturedTopicListItemSubCell.posterImgViewWidth / FeaturedTopicListItemSubCell.posterSizeRatio
    }()
    
    static let animationOption: KingfisherOptionsInfo = {
        return [.transition(.fade(0.25))]
    }()
    
    static let HDImg: UIImage? = {
        return UIImage(named: "video_HD_icon")
    }()
    
    static let vipDefaultImg: UIImage? = {
        return UIImage(named: "video_vip_icon")
    }()
    
    static let payDefaultImg: UIImage? = {
        return UIImage(named: "video_pay_icon")
    }()
    
    static let limitedExemptionDefaultImg: UIImage? = {
        return UIImage(named: "limited_exemption_icon")
    }()
    
    static let discountImg: UIImage? = {
        return UIImage(named: "discount_icon")
    }()
    
    static let lineGradientMaskImg: UIImage? = {
        return UIImage(named: "line_gradient_mask_bg")
    }()
    
    private lazy var posterImgView: UIImageView = {
        let imgView = UIImageView()
        imgView.contentMode = .scaleAspectFill
        imgView.layer.masksToBounds = true
        imgView.layer.cornerRadius = 10
        imgView.addSubview(lineGradientMaskImgView)
        imgView.addSubview(playTimesLabel)
        imgView.addSubview(datetimeLabel)
        imgView.addSubview(HDImgView)
        imgView.addSubview(vipOrPayImgView)
        imgView.addSubview(coinNumLabel)
        imgView.addSubview(discountImgView)
        
        lineGradientMaskImgView.snp.makeConstraints { (make) in
            make.left.right.bottom.equalToSuperview()
            make.height.equalTo(27)
        }
        
        playTimesLabel.snp.makeConstraints { (make) in
            make.left.equalToSuperview().inset(4)
            make.bottom.equalToSuperview().inset(8)
        }
        
        datetimeLabel.snp.makeConstraints { (make) in
            make.centerY.equalTo(playTimesLabel)
            make.right.equalToSuperview().inset(4)
        }
        
        HDImgView.snp.makeConstraints { (make) in
            make.left.top.equalToSuperview()
            make.width.equalTo(28)
            make.height.equalTo(14)
        }
        
        vipOrPayImgView.snp.makeConstraints { (make) in
            make.top.right.equalToSuperview()
            make.width.equalTo(36)
            make.height.equalTo(18)
        }
        
        coinNumLabel.snp.makeConstraints { (make) in
            make.left.equalTo(vipOrPayImgView.snp.left).offset(16)
            make.centerY.right.equalTo(vipOrPayImgView)
        }
        
        discountImgView.snp.makeConstraints { (make) in
            make.right.equalToSuperview().inset(8)
            make.top.equalToSuperview()
            make.width.equalTo(61)
            make.height.equalTo(55)
        }
        
        return imgView
    }()
    
    private lazy var HDImgView: UIImageView = {
        return UIImageView(image: FeaturedTopicListItemSubCell.HDImg)
    }()
    
    private lazy var vipOrPayImgView: UIImageView = {
        let imgView = UIImageView()
        imgView.contentMode = .scaleAspectFit
        return imgView
    }()
    
    private lazy var coinNumLabel: UILabel = {
        let label = UILabel()
        label.textColor = .white
        label.font = UIFont.pingFangRegular(10)
        return label
    }()
    
    private lazy var discountIconImgView: UIImageView = {
        return UIImageView(image: ActressDetailsCell.discountIconImg)
    }()
    
    private lazy var priceLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.pingFangMedium(20)
        label.textColor = .white
        return label
    }()
    
    private lazy var originalPriceLabel: UILabel = {
        let label = UILabel()
        label.textAlignment = .center
        return label
    }()
    
    private lazy var discountImgView: UIImageView = {
        let imgView = UIImageView(image: ActressDetailsCell.discountImg)
        imgView.addSubview(discountIconImgView)
        imgView.addSubview(priceLabel)
        imgView.addSubview(originalPriceLabel)
        imgView.isHidden = true
        
        discountIconImgView.snp.makeConstraints { (make) in
            make.top.equalToSuperview().inset(3)
            make.left.equalToSuperview().inset(5)
            make.size.equalTo(18)
        }
        
        priceLabel.snp.makeConstraints { (make) in
            make.left.equalTo(discountIconImgView.snp.right)
            make.right.equalToSuperview()
            make.centerY.equalTo(discountIconImgView)
        }
        
        originalPriceLabel.snp.makeConstraints { (make) in
            make.top.equalTo(discountIconImgView.snp.bottom).offset(2)
            make.left.right.equalToSuperview()
        }
        
        return imgView
    }()
    
    private lazy var lineGradientMaskImgView: UIImageView = {
        let imgView = UIImageView(image: FeaturedTopicListItemSubCell.lineGradientMaskImg)
        imgView.contentMode = .scaleAspectFill
        return imgView
    }()
    
    private lazy var playTimesLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.pingFangRegular(10)
        label.textColor = .white
        return label
    }()
    
    private lazy var datetimeLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.pingFangRegular(10)
        label.textColor = .white
        return label
    }()
    
    private lazy var titleLabel: CustomLabel = {
        let label = CustomLabel()
        label.font = UIFont.pingFangMedium(14)
        label.textColor = .white
        label.numberOfLines = 2
        label.verticalAlignment = .top
        return label
    }()
    
    var dataModel: VideoItem? {
        didSet {
            guard let item = dataModel else { return }
            posterImgView.kf.setImage(with: item.coverImg?.column1, placeholder: Sensitive.default_bg, options: FeaturedTopicListItemSubCell.animationOption)
            playTimesLabel.text = "\(num2TenThousandStrFormatWithChinese(item.fakeWatchTimes))播放"
            datetimeLabel.text = Date.getFormatPlayTime(secounds: TimeInterval(item.playTime))
            titleLabel.text = item.title
            vipOrPayImgView.isHidden = !(item.videoPayMark == .vip || item.videoPayMark == .free || item.videoPayMark == .pay && !item.discount)
            vipOrPayImgView.image = item.videoPayMark == .vip ? FeaturedTopicListItemSubCell.vipDefaultImg : item.videoPayMark == .pay ? FeaturedTopicListItemSubCell.payDefaultImg : FeaturedTopicListItemSubCell.limitedExemptionDefaultImg
            HDImgView.isHidden = !item.hd
            coinNumLabel.isHidden = !(!item.discount && item.videoPayMark == .pay)
            coinNumLabel.text = "\(item.price)"
            discountImgView.isHidden = !(item.videoPayMark == .pay && item.discount)
            priceLabel.text = "\(item.price)"
            originalPriceLabel.attributedText = NSMutableAttributedString(string: "原價\(item.originalPrice)", attributes: ActressDetailsCell.originalPriceAttributes)
        }
    }
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        backgroundColor = .none
        selectionStyle = .none
        renderView()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func renderView() {
        addSubview(posterImgView)
        addSubview(titleLabel)
        
        posterImgView.snp.makeConstraints { (make) in
            make.top.equalToSuperview().inset(FeaturedTopicListItemSubCell.marginTop)
            make.left.right.equalToSuperview().inset(12)
            make.height.equalTo(FeaturedTopicListItemSubCell.posterImgViewHeight)
        }
        
        titleLabel.snp.makeConstraints { (make) in
            make.top.equalTo(posterImgView.snp.bottom).offset(FeaturedTopicListItemSubCell.titleMarginTop)
            make.left.right.equalTo(posterImgView)
            make.bottom.equalToSuperview()
        }
        
    }
}
