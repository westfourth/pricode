//
//  FeaturedTopicListVC.swift
//  Sp
//
//  Created by mac on 2020/11/14.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class FeaturedTopicListVC: UIViewController {
    
    private static let tabBarWrapperViewHeight: CGFloat = 32
    
    private static let tabBarWrapperViewWidth: CGFloat = 148
    
    private static let tabBarWrapperMarginTop: CGFloat = 20
    
    private static let indicatorWidth: CGFloat = 74
    
    private static let collectionViewMarginTop: CGFloat = 72
    
    private static let emptyImg: UIImage = {
        return UIImage()
    }()
    
    private static let itemSize: CGSize = {
        return CGSize(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height - kTop - FeaturedTopicListVC.collectionViewMarginTop)
    }()
    
    private lazy var leftTabBar: UIButton = {
        let btn = UIButton()
        btn.setTitle("最新", for: .normal)
        btn.setTitleColor(.white, for: .normal)
        btn.titleLabel?.font = UIFont.pingFangMedium(16)
        btn.addTarget(self, action: #selector(onLeftTabTap), for: .touchUpInside)
        return btn
    }()
    
    private lazy var rightTabBar: UIButton = {
        let btn = UIButton()
        btn.setTitle("最熱", for: .normal)
        btn.setTitleColor(.white, for: .normal)
        btn.titleLabel?.font = UIFont.pingFangMedium(16)
        btn.addTarget(self, action: #selector(onRightTabTap), for: .touchUpInside)
        return btn
    }()
    
    private lazy var indicatorView: UIView = {
        let view = UIView()
        view.backgroundColor = .white
        view.layer.masksToBounds = true
        view.layer.cornerRadius = FeaturedTopicListVC.tabBarWrapperViewHeight / 2
        view.backgroundColor = Color.theme_color
        return view
    }()
    
    private lazy var tabBarWrapperView: UIView = {
        let view = UIView()
        view.layer.masksToBounds = true
        view.layer.cornerRadius = FeaturedTopicListVC.tabBarWrapperViewHeight / 2
        view.layer.borderWidth = 1
        view.layer.borderColor = Color.theme_color.cgColor
        
        view.addSubview(indicatorView)
        view.addSubview(leftTabBar)
        view.addSubview(rightTabBar)
        
        leftTabBar.snp.makeConstraints { (make) in
            make.width.equalTo(FeaturedTopicListVC.indicatorWidth)
            make.left.top.bottom.equalToSuperview()
        }
        
        rightTabBar.snp.makeConstraints { (make) in
            make.width.equalTo(leftTabBar)
            make.right.top.bottom.equalToSuperview()
        }
        
        indicatorView.snp.makeConstraints { (make) in
            make.center.equalTo(leftTabBar)
            make.size.equalTo(leftTabBar)
        }
        
        return view
    }()
    
    private lazy var collectionView: UICollectionView = {
        let layout = UICollectionViewFlowLayout()
        layout.scrollDirection = .horizontal
        layout.minimumLineSpacing = 0
        layout.minimumInteritemSpacing = 0
        layout.itemSize = FeaturedTopicListVC.itemSize
        let cv = UICollectionView(frame: .zero, collectionViewLayout: layout)
        cv.register(FeaturedTopicListItemCell.self, forCellWithReuseIdentifier: "FeaturedTopicListItemCell")
        cv.showsVerticalScrollIndicator = false
        cv.showsHorizontalScrollIndicator = false
        cv.bounces = false
        cv.bouncesZoom = false
        cv.isPagingEnabled = true
        cv.backgroundColor = .none
        cv.delegate = self
        cv.dataSource = self
        return cv
    }()
    
    private var activePageIndex: Int = 0
    
    var itemData: FeaturedTopicListResp? {
        didSet {
            renderList()
        }
    }
    
    override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: Bundle?) {
        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
        hidesBottomBarWhenPushed = true
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationItem.title = (itemData == nil || (itemData?.topicTitle.isEmpty ?? true) ? "視頻專題" : "\(itemData?.topicTitle ?? "")")
        view.backgroundColor = RGB(0x141516)
        renderView()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.navigationBar.isTranslucent = false
        navigationController?.navigationBar.setBackgroundImage(FeaturedTopicListVC.emptyImg, for: .default)
        navigationController?.navigationBar.shadowImage = FeaturedTopicListVC.emptyImg
        navigationController?.navigationBar.barTintColor = RGB(0x1C1C1C)
    }
    
    private func renderView() {
        view.addSubview(tabBarWrapperView)
        tabBarWrapperView.snp.makeConstraints { (make) in
            make.top.equalToSuperview().inset(FeaturedTopicListVC.tabBarWrapperMarginTop)
            make.centerX.equalToSuperview()
            make.width.equalTo(FeaturedTopicListVC.tabBarWrapperViewWidth)
            make.height.equalTo(FeaturedTopicListVC.tabBarWrapperViewHeight)
        }
        
    }
    
    private func renderList() {
        view.addSubview(collectionView)
        
        collectionView.snp.makeConstraints { (make) in
            make.top.equalToSuperview().inset(FeaturedTopicListVC.collectionViewMarginTop)
            make.left.right.equalToSuperview()
            make.height.equalTo(FeaturedTopicListVC.itemSize.height)
        }
        
    }
    
    private func switchIndicatorLayout(isLeftTabBar: Bool) {
        indicatorView.snp.remakeConstraints { (make) in
            make.center.equalTo(isLeftTabBar ? leftTabBar : rightTabBar)
            make.size.equalTo(leftTabBar)
        }
        updateLayoutConstraints()
        UIView.animate(withDuration: 0.15) { [weak self] in
            self?.tabBarWrapperView.layoutIfNeeded()
        }
    }
    
    private func updateLayoutConstraints() {
        tabBarWrapperView.updateConstraintsIfNeeded()
        tabBarWrapperView.updateFocusIfNeeded()
    }
    
    @objc private func onLeftTabTap() {
        guard activePageIndex != 0 else { return }
        collectionView.scrollToItem(at: IndexPath(item: 0, section: 0), at: .centeredHorizontally, animated: true)
    }
    
    @objc private func onRightTabTap() {
        guard activePageIndex != 1 else { return }
        collectionView.scrollToItem(at: IndexPath(item: 1, section: 0), at: .centeredHorizontally, animated: true)
    }
    
}

extension FeaturedTopicListVC: UICollectionViewDelegate ,UICollectionViewDataSource {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 2
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "FeaturedTopicListItemCell", for: indexPath) as! FeaturedTopicListItemCell
        cell.itemType = FeaturedTopicDetailsType(rawValue: indexPath.row + 1) ?? .latest
        cell.topicId = itemData?.topicId ?? 0
        return cell
    }
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        let currentActivePageIndex = scrollView.contentOffset.x <= scrollView.frame.width / 2 ? 0 : 1
        guard currentActivePageIndex != activePageIndex else { return }
        activePageIndex = currentActivePageIndex
        switchIndicatorLayout(isLeftTabBar: activePageIndex == 0)
    }
    
}
