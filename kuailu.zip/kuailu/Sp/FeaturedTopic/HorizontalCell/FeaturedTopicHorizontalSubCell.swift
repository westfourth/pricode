//
//  FeaturedTopicHorizontalSubCell.swift
//  Sp
//
//  Created by mac on 2021/1/14.
//  Copyright © 2021 mac. All rights reserved.
//

import UIKit

class FeaturedTopicHorizontalSubCell: UICollectionViewCell {
    
    private static let viewWidth: CGFloat = 309
    
    private static let viewHeight: CGFloat = {
        return FeaturedTopicHorizontalSubCell.posterImgViewHeight + FeaturedTopicHorizontalSubCell.titleLabelMarginTop + FeaturedTopicHorizontalSubCell.titleHeight
    }()
    
    static let itemSize: CGSize = {
        return CGSize(width: FeaturedTopicHorizontalSubCell.viewWidth, height: FeaturedTopicHorizontalSubCell.viewHeight)
    }()
    
    private static let posterImgViewHeight: CGFloat = 184
    
    private static let titleLabelMarginTop: CGFloat = 9
    
    private static let titleHeight: CGFloat = 42
    
    private lazy var posterImgView: UIImageView = {
        let imgView = UIImageView()
        imgView.contentMode = .scaleAspectFill
        imgView.layer.masksToBounds = true
        imgView.layer.cornerRadius = 4
        imgView.addSubview(lineGradientMaskImgView)
        imgView.addSubview(playTimesLabel)
        imgView.addSubview(datetimeLabel)
        imgView.addSubview(HDImgView)
        imgView.addSubview(vipOrPayImgView)
        imgView.addSubview(coinNumLabel)
        imgView.addSubview(discountImgView)
        
        lineGradientMaskImgView.snp.makeConstraints { (make) in
            make.left.right.bottom.equalToSuperview()
            make.height.equalTo(27)
        }
        
        playTimesLabel.snp.makeConstraints { (make) in
            make.left.equalToSuperview().inset(4)
            make.bottom.equalToSuperview().inset(3)
        }
        
        datetimeLabel.snp.makeConstraints { (make) in
            make.centerY.equalTo(playTimesLabel)
            make.right.equalToSuperview().inset(4)
        }
        
        HDImgView.snp.makeConstraints { (make) in
            make.left.top.equalToSuperview()
            make.width.equalTo(28)
            make.height.equalTo(14)
        }
        
        vipOrPayImgView.snp.makeConstraints { (make) in
            make.top.right.equalToSuperview()
            make.width.equalTo(36)
            make.height.equalTo(18)
        }
        
        coinNumLabel.snp.makeConstraints { (make) in
            make.left.equalTo(vipOrPayImgView.snp.left).offset(16)
            make.centerY.right.equalTo(vipOrPayImgView)
        }
        
        discountImgView.snp.makeConstraints { (make) in
            make.right.equalToSuperview().inset(4)
            make.top.equalToSuperview()
            make.width.equalTo(38)
            make.height.equalTo(34)
        }
        
        return imgView
    }()
    
    private lazy var HDImgView: UIImageView = {
        return UIImageView(image: AVRecommendHorizontalFourGridCell.HDImg)
    }()
    
    private lazy var vipOrPayImgView: UIImageView = {
        let imgView = UIImageView()
        imgView.contentMode = .scaleAspectFit
        return imgView
    }()
    
    private lazy var coinNumLabel: UILabel = {
        let label = UILabel()
        label.textColor = .white
        label.font = UIFont.pingFangRegular(10)
        return label
    }()
    
    private lazy var discountIconImgView: UIImageView = {
        return UIImageView(image: ActressDetailsCell.discountIconImg)
    }()
    
    private lazy var priceLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.pingFangMedium(10)
        label.textColor = .white
        return label
    }()
    
    private lazy var originalPriceLabel: UILabel = {
        let label = UILabel()
        label.textAlignment = .center
        return label
    }()
    
    private lazy var discountImgView: UIImageView = {
        let imgView = UIImageView(image: ActressDetailsCell.discountImg)
        imgView.addSubview(discountIconImgView)
        imgView.addSubview(priceLabel)
        imgView.addSubview(originalPriceLabel)
        imgView.isHidden = true
        
        discountIconImgView.snp.makeConstraints { (make) in
            make.top.equalToSuperview().inset(2)
            make.left.equalToSuperview().inset(3)
            make.size.equalTo(12)
        }
        
        priceLabel.snp.makeConstraints { (make) in
            make.left.equalTo(discountIconImgView.snp.right)
            make.right.equalToSuperview()
            make.centerY.equalTo(discountIconImgView)
        }
        
        originalPriceLabel.snp.makeConstraints { (make) in
            make.top.equalTo(discountIconImgView.snp.bottom).offset(1)
            make.left.right.equalToSuperview()
        }
        
        return imgView
    }()
    
    private lazy var lineGradientMaskImgView: UIImageView = {
        let imgView = UIImageView(image: AVRecommendHorizontalFourGridCell.lineGradientMaskImg)
        imgView.contentMode = .scaleAspectFill
        return imgView
    }()
    
    private lazy var titleLabel: CustomLabel = {
        let label = CustomLabel()
        label.textColor = .white
        label.font = UIFont.pingFangRegular(14)
        label.numberOfLines = 2
        label.verticalAlignment = .top
        return label
    }()
    
    private lazy var playTimesLabel: UILabel = {
        let label = UILabel()
        label.textColor = .white
        label.font = UIFont.pingFangRegular(10)
        return label
    }()
    
    private lazy var datetimeLabel: UILabel = {
        let label = UILabel()
        label.textColor = .white
        label.font = UIFont.pingFangRegular(10)
        return label
    }()
    
    var dataModel: VideoItem? {
        didSet {
            guard let item = dataModel else { return }
            posterImgView.kf.setImage(with: item.coverImg?.column2, placeholder: Sensitive.default_bg, options: AVRecommendHorizontalFourGridCell.animationOption)
            playTimesLabel.text = "\(num2TenThousandStrFormatWithChinese(item.fakeWatchTimes))播放"
            datetimeLabel.text = Date.getFormatPlayTime(secounds: TimeInterval(item.playTime))
            titleLabel.text = item.title
            vipOrPayImgView.isHidden = !(item.videoPayMark == .vip || item.videoPayMark == .free || item.videoPayMark == .pay && !item.discount)
            vipOrPayImgView.image = item.videoPayMark == .vip ? AVRecommendVerticalSixGridCell.vipDefaultImg : item.videoPayMark == .pay ? AVRecommendVerticalSixGridCell.payDefaultImg : AVRecommendVerticalSixGridCell.limitedExemptionDefaultImg
            HDImgView.isHidden = !item.hd
            coinNumLabel.isHidden = !(!item.discount && item.videoPayMark == .pay)
            coinNumLabel.text = "\(item.price)"
            discountImgView.isHidden = !(item.videoPayMark == .pay && item.discount)
            priceLabel.text = "\(item.price)"
            originalPriceLabel.attributedText = NSMutableAttributedString(string: "原價\(item.originalPrice)", attributes: AVRecommendVerticalSixGridCell.originalPriceAttributes)
        }
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        addSubview(posterImgView)
        addSubview(titleLabel)
        
        posterImgView.snp.makeConstraints { (make) in
            make.left.right.top.equalToSuperview()
            make.height.equalTo(FeaturedTopicHorizontalSubCell.posterImgViewHeight)
        }
        
        titleLabel.snp.makeConstraints { (make) in
            make.top.equalTo(posterImgView.snp.bottom).offset(FeaturedTopicHorizontalSubCell.titleLabelMarginTop)
            make.left.right.equalToSuperview()
            make.height.equalTo(FeaturedTopicHorizontalSubCell.titleHeight)
        }
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}
