//
//  FeaturedTopicCellHeaderView.swift
//  Sp
//
//  Created by mac on 2021/1/12.
//  Copyright © 2021 mac. All rights reserved.
//

import UIKit

class FeaturedTopicCellHeaderView: UIView {
    
    static let viewHeight: CGFloat = {
        return FeaturedTopicCellHeaderView.posterImgViewHeight
    }()
    
    private static let posterImgViewWidth: CGFloat = {
        return UIScreen.main.bounds.width - 12 * 2
    }()
    
    private static let posterImgViewHeight: CGFloat = {
        return FeaturedTopicCellHeaderView.posterImgViewWidth / 336 * 112
    }()
    
    private static let posterSizeRatio: CGFloat = {
        return FeaturedTopicCellHeaderView.posterImgViewWidth / 336
    }()
    
    private static let posterImgViewRectCorner: UIRectCorner = {
        return [.topLeft, .topRight]
    }()
    
    private static let posterDefaultImg: UIImage = {
        return UIImage.decrypt("featured_topic_header_bg.png.enc")
    }()
    
    private static let wrapperViewImg: UIImage? = {
        return UIImage(named: "featured_topic_header_black_bg")
    }()
    
    private static let bottomLineHorizontalPadding: CGFloat = {
        return FeaturedTopicCellHeaderView.posterSizeRatio * 8
    }()
    
    private lazy var posterImgView: UIImageView = {
        let imgView = UIImageView()
        imgView.contentMode = .scaleAspectFill
        imgView.layer.masksToBounds = true
        return imgView
    }()
    
    private lazy var horizontalLine: UIView = {
        let view = UIView()
        view.backgroundColor = Color.theme_color
        return view
    }()
    
    private lazy var titleLabel: UILabel = {
        let label = UILabel()
        label.textColor = .white
        label.font = UIFont.pingFangSemibold(28)
        return label
    }()
    
    private lazy var subTitleLabel: UILabel = {
        let label = UILabel()
        label.textColor = .white
        label.font = UIFont.pingFangRegular(14)
        return label
    }()
    
    private lazy var wrapperImgView: UIImageView = {
        let imgView = UIImageView(image: FeaturedTopicCellHeaderView.wrapperViewImg)
        imgView.contentMode = .scaleAspectFill
        return imgView
    }()
    
    var dataModel: FeaturedTopicListResp? {
        didSet {
            guard let item = dataModel else { return }
            posterImgView.kf.setImage(with: item.bgImg?.column1, placeholder: FeaturedTopicCellHeaderView.posterDefaultImg, options: AVRecommendHorizontalFourGridCell.animationOption)
            titleLabel.text = item.topicTitle
            subTitleLabel.text = item.subTitle
            horizontalLine.snp.updateConstraints { (make) in
                make.width.equalTo(item.topicTitle.getStringSize(rectSize: .zero, font: titleLabel.font).width + FeaturedTopicCellHeaderView.bottomLineHorizontalPadding)
            }
        }
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        renderView()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func renderView() {
        addSubview(posterImgView)
        addSubview(wrapperImgView)
        addSubview(horizontalLine)
        addSubview(titleLabel)
        addSubview(subTitleLabel)
        
        posterImgView.snp.makeConstraints { (make) in
            make.top.centerX.equalToSuperview()
            make.width.equalTo(FeaturedTopicCellHeaderView.posterImgViewWidth)
            make.height.equalTo(FeaturedTopicCellHeaderView.posterImgViewHeight)
        }
        
        let ratio = FeaturedTopicCellHeaderView.posterSizeRatio
        
        wrapperImgView.snp.makeConstraints { (make) in
            make.top.left.equalTo(posterImgView)
            make.width.equalTo(224 * ratio)
            make.height.equalTo(106 * ratio)
        }
        
        horizontalLine.snp.makeConstraints { (make) in
            make.top.equalToSuperview().inset(62 * ratio)
            make.left.equalToSuperview().inset(18 * ratio)
            make.height.equalTo(8)
            make.width.equalTo(0)
        }
        
        titleLabel.snp.makeConstraints { (make) in
            make.bottom.equalTo(horizontalLine).offset(3)
            make.left.equalToSuperview().inset(22 * ratio)
            make.right.equalTo(wrapperImgView)
        }
        
        subTitleLabel.snp.makeConstraints { (make) in
            make.top.equalTo(horizontalLine.snp.bottom).offset(5 * ratio)
            make.left.equalTo(horizontalLine)
            make.right.equalTo(wrapperImgView)
        }
        
    }
    
}

