//
//  FeaturedTopicVerticalCell.swift
//  Sp
//
//  Created by mac on 2020/11/10.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class FeaturedTopicVerticalCell: UITableViewCell {
    
    static let viewHeight: CGFloat = {
        return FeaturedTopicCellHeaderView.viewHeight + FeaturedTopicVerticalCell.collectionViewMarginTop + FeaturedTopicVerticalSubCell.itemSize.height + FeaturedTopicVerticalCell.moreBtnMarginTop + FeaturedTopicVerticalCell.moreBtnHeight + FeaturedTopicVerticalCell.marginBottom
    }()
    
    private static let moreBtnHeight: CGFloat = 30
    
    private static let collectionViewMarginTop: CGFloat = 11
    
    private static let moreBtnMarginTop: CGFloat = 10
    
    private static let marginBottom: CGFloat = 20
    
    private static let arrowRightImg: UIImage? = {
        return UIImage(named:"arrow_right_white_icon")
    }()
    
    private lazy var headerBar: FeaturedTopicCellHeaderView = {
        return FeaturedTopicCellHeaderView()
    }()
    
    private lazy var collectionView: UICollectionView = {
        let layout = UICollectionViewFlowLayout()
        layout.scrollDirection = .horizontal
        layout.itemSize = FeaturedTopicVerticalSubCell.itemSize
        layout.minimumLineSpacing = 8
        layout.minimumInteritemSpacing = 0
        let cv = UICollectionView(frame: .zero, collectionViewLayout: layout)
        cv.register(FeaturedTopicVerticalSubCell.self, forCellWithReuseIdentifier: "FeaturedTopicVerticalSubCell")
        cv.backgroundColor = .none
        cv.delegate = self
        cv.dataSource = self
        cv.bouncesZoom = false
        cv.showsVerticalScrollIndicator = false
        cv.showsHorizontalScrollIndicator = false
        return cv
    }()
    
    private lazy var moreBtn: UIButton = {
        let btn = UIButton()
        btn.layer.backgroundColor = rgb(0x2B2B2B).cgColor
        btn.setTitle("查看更多", for: .normal)
        btn.setTitleColor(.white, for: .normal)
        btn.titleLabel?.font = UIFont.pingFangMedium(14)
        btn.setImage(FeaturedTopicVerticalCell.arrowRightImg, for: .normal)
        btn.addTarget(self, action: #selector(onMoreBtnTap), for: .touchUpInside)
        return btn
    }()
    
    private lazy var wrapperView: UIView = {
        let view = UIView()
        view.layer.masksToBounds = true
        view.layer.cornerRadius = 10
        view.backgroundColor = rgb(0x1C1C1C)
        view.addSubview(headerBar)
        view.addSubview(collectionView)
        view.addSubview(moreBtn)
        
        headerBar.snp.makeConstraints { (make) in
            make.top.left.right.equalToSuperview()
            make.height.equalTo(FeaturedTopicCellHeaderView.viewHeight)
        }
        
        collectionView.snp.makeConstraints { (make) in
            make.top.equalTo(headerBar.snp.bottom).offset(FeaturedTopicVerticalCell.collectionViewMarginTop)
            make.left.right.equalToSuperview()
            make.height.equalTo(FeaturedTopicVerticalSubCell.itemSize.height)
        }
        
        moreBtn.snp.makeConstraints { (make) in
            make.top.equalTo(collectionView.snp.bottom).offset(FeaturedTopicVerticalCell.moreBtnMarginTop)
            make.left.right.equalToSuperview()
            make.height.equalTo(FeaturedTopicVerticalCell.moreBtnHeight)
        }
        return view
    }()
    
    private var listData: [VideoItem] = [] {
        didSet {
            collectionView.reloadData()
        }
    }
    
    var dataModel: FeaturedTopicListResp? {
        didSet {
            guard let item = dataModel else { return }
            headerBar.dataModel = item
            listData = item.videoList
        }
    }
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        backgroundColor = .none
        selectionStyle = .none
        contentView.addSubview(wrapperView)
        
        wrapperView.snp.makeConstraints { (make) in
            make.top.equalToSuperview()
            make.left.right.equalToSuperview().inset(12)
            make.bottom.equalToSuperview().inset(FeaturedTopicVerticalCell.marginBottom)
        }
        
        moreBtn.imagePosition(imageStyle: .right, spacing: 3)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    @objc private func onMoreBtnTap() {
        guard let item = dataModel, let navigationController = (UIApplication.shared.delegate as? AppDelegate)?.currentNavigationController else { return }
        let vc = FeaturedTopicListVC()
        vc.itemData = item
        navigationController.show(vc, sender: nil)
    }
    
}

extension FeaturedTopicVerticalCell: UICollectionViewDelegate, UICollectionViewDataSource {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return listData.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "FeaturedTopicVerticalSubCell", for: indexPath) as! FeaturedTopicVerticalSubCell
        cell.dataModel = listData[indexPath.row]
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        guard let navigationController = (UIApplication.shared.delegate as? AppDelegate)?.currentNavigationController else { return }
        let vc = PlayerController()
        vc.videoId = listData[indexPath.row].videoId
        navigationController.show(vc, sender: nil)
    }
    
}
