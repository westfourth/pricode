//
//  PlayerTag.swift
//  Sp
//
//  Created by mac on 2020/11/19.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class PlayerTag: NSObject, UICollectionViewDataSource, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout {
    var tagTitles = [String]()
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return tagTitles.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "ID", for: indexPath) as! PlayerTagCell
        cell.text = tagTitles[indexPath.item]
        return cell
    }
    
    //MARK:-    Delegate
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let text = ("#" + tagTitles[indexPath.item]) as NSString
        let size = text.size(withAttributes: [.font: font(14)])
        return CGSize(width: size.width + 8 * 2, height: 20)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 12
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 12
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let tagTitle = tagTitles[indexPath.item]
        let vc = Tag2VC()
        vc.tagTitle = tagTitle
        //  嵌套层级超过2级，使用delegte更为麻烦
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        appDelegate.currentNavigationController?.show(vc, sender: nil)
    }
}
