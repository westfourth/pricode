//
//  PlayerTagCell.swift
//  Sp
//
//  Created by mac on 2020/11/19.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class PlayerTagCell: UICollectionViewCell {
    @IBOutlet weak var label: UILabel!
    
    var text: String? {
        didSet {
            if text != nil {
                label.text = "#" + text!
            }
        }
    }

    override func awakeFromNib() {
        super.awakeFromNib()

    }


}
