//
//  PlayerAlert.swift
//  CaoLong
//
//  Created by mac on 2020/11/4.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class PlayerAlert: NSObject {
    //  返回是否可以下载
    class func alert(vc: UIViewController, item: VideoItem, complete: @escaping (Bool) -> Void) {
        //  只有vip才能下载
        let vipDate = NetDefaults.userInfo?.expiredVip
        if vipDate == nil || vipDate! < Date() {
            alertCacheVIP(vc: vc)
            complete(false)
        }

        //  付费视频
        if item.videoPayMark == .pay && !item.canWatch {
            alertCachePay(vc: vc)
            complete(false)
        }
        
        //  上报下载次数
        Session.request(DownloadNumReq()) { (e, resp) in
            guard let r = resp as? DownloadNum else { return }
            if r.downloadNum <= 0 {
                //  次数不够
                alertCacheNumFull(vc: vc)
                complete(false)
            } else {
                // 开始下载
                alertCacheNumRemain(vc: vc as! PlayerController, downloadNum: r.downloadNum)
                complete(true)
            }
        }
    
    }
    
    //  缓存次数
    class func alertCacheNumRemain(vc: PlayerController, downloadNum: Int) {
        let message = "剩余緩存次數：\(downloadNum)"
        let alertVC = UIAlertController(title: "已緩存", message: message, preferredStyle: .alert)
        vc.present(alertVC, animated: true, completion: nil)
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
            alertVC.dismiss(animated: true, completion: nil)
        }
    }
    
    //  缓存次数已满
    class func alertCacheNumFull(vc: UIViewController) {
        let alertVC = UIAlertController(title: "您的緩存次數已滿", message: nil, preferredStyle: .alert)
        let action = UIAlertAction(title: "整理緩存", style: .default) { (action) in
            vc.dismiss(animated: true) {
                let vc2 = DownloadController()
                vc2.hidesBottomBarWhenPushed = true
                let navVC = (UIApplication.shared.delegate as? AppDelegate)?.currentNavigationController
                navVC?.pushViewController(vc2, animated: true)
            }
        }
        let cancel = UIAlertAction(title: "取消", style: .cancel) { (action) in
            
        }
        alertVC.addAction(action)
        alertVC.addAction(cancel)
        vc.present(alertVC, animated: true, completion: nil)
    }
    
    //  付费视频
    class func alertCachePay(vc: UIViewController) {
        let alertVC = UIAlertController(title: "付費視頻要先購買才能緩存哦", message: nil, preferredStyle: .alert)
        vc.present(alertVC, animated: true, completion: nil)
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
            alertVC.dismiss(animated: true, completion: nil)
        }
    }
    
    //  vip视频
    class func alertCacheVIP(vc: UIViewController) {
        let alertVC = UIAlertController(title: "開通VIP會員才享有緩存功能哦", message: nil, preferredStyle: .alert)
        let action = UIAlertAction(title: "前往开通会员", style: .default) { (action) in
            vc.dismiss(animated: true) {
                let vc2 = Vip2VC()
                vc2.hidesBottomBarWhenPushed = true
                let navVC = (UIApplication.shared.delegate as? AppDelegate)?.currentNavigationController
                navVC?.pushViewController(vc2, animated: true)
            }
        }
        let cancel = UIAlertAction(title: "取消", style: .cancel) { (action) in
            
        }
        alertVC.addAction(action)
        alertVC.addAction(cancel)
        vc.present(alertVC, animated: true, completion: nil)
    }
}
