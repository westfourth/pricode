//
//  PlayerController.swift
//  CaoLong
//
//  Created by mac on 2020/5/20.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit
import Player
import M3U8

class PlayerController: UIViewController, UIGestureRecognizerDelegate {
    var contentView: PlayerContentView!
    var playerView = XSPlayerView()
    
    //  真实观影时长
    var realPlayTime: TimeInterval = 0
    var shouldResetRealPlayTime = true
    
    /// 是否播放过片头
    var playedHeader:Bool = true
    
    // 是否继续上次的播放进度
    var isResumed = false
    /// 外部跳转 必传字段
    var videoId:Int? {
        didSet {
            guard let id = videoId else {return}
            /// 加载视频信息
            if isViewLoaded {
                loadVideoInfo(id)
            }
        }
    }
    
    //  播放权限判断
    var responseWatchType: ShortVideoResponseWatchType = .none
    
    var error: Error?       //  responseWatchType = .error 时才有值
    
    //  用作统计分析
    var watchType: ShortVideoWatchType = .free
    
    var commentButton:UIButton?
    
    //  当前视频时长
    var currentVieoDuration:TimeInterval = 0
    
    /// 当前播放视频
    private var item:VideoItem? {
        didSet {
            guard let item = item,item.videoUrl != nil else {return}
            // 播放记录
            notimesView.isHidden = true
            buyView.isHidden = true
            vipView.isHidden = true
            
            Defaults.saveLongWatch(item)
            //  播放
            playerView.topView.titleLabel.text = item.title
            if item.playPath != nil {
                getM3u8(m3u8URL: item.playPath!)
            }
            //  无预览，不能观看
            if item.playPath == nil && !item.canWatch {
                permissionUI()
            }
        }
    }
    
    ///权限判断ui
    private func permissionUI() {
        switch self.responseWatchType{
        case .noTimes:
            notimesView.isHidden = false
            self.playerView.isCleanMode = true
            self.playerView.player.pause()
        case.needPay:
            buyView.isHidden = false
            buyBottomView.isHidden = true
            self.playerView.isCleanMode = true
            self.playerView.player.pause()
        case .onlyVip:
            buyBottomView.isHidden = true
            self.vipView.isHidden = false
            self.playerView.isCleanMode = true
            self.playerView.player.pause()
        default:
            break
        }
    }
    
    override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: Bundle?) {
        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
        hidesBottomBarWhenPushed = true
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .black
        navigationController?.interactivePopGestureRecognizer?.delegate = self
        
        //  播放器
        view.addSubview(playerView)
        playerView.delegate = self
        
        //  contentView
        let nib = UINib(nibName: "PlayerContentView", bundle: nil)
        contentView = nib.instantiate(withOwner: nil, options: nil).first as? PlayerContentView
        contentView.delegate = self
        view.addSubview(contentView)
        
        view.addSubview(buyView)
        view.addSubview(notimesView)
        view.addSubview(vipView)
        playerView.addSubview(buyBottomView)
        //  更新frame
        updateFrame(portrait: view.frame.size)
        
        // 播放结束
        NotificationCenter.default.addObserver(self, selector: #selector(playDidEndAction(_:)), name:NSNotification.Name.AVPlayerItemDidPlayToEndTime , object: nil)
        
        //
        if let id = videoId {
            loadVideoInfo(id)
        }
    }
    
    /// 播放片头 带logo
    func playHeaderFirst() {
        guard let path = Bundle.main.path(forResource: "kuailu", ofType: "mp4") else {return}
        let pItem = AVPlayerItem(url: URL(fileURLWithPath: path))
        playerView.play(pItem)
    }
    
    
    deinit {
        NotificationCenter.default.removeObserver(self)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.setNavigationBarHidden(true, animated: true)
        vipResumePlay()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        navigationController?.setNavigationBarHidden(false, animated: true)
        guard let item = playerView.player.currentItem else {return}
        playerView.player.pause()
        //上报
        if !item.currentTime().isValid {
            return
        }
        shouldResetRealPlayTime = true
        uploadWatchRecord(Int(CMTimeGetSeconds(item.currentTime())))
    }
    
    @objc func playDidEndAction(_ noti:Notification) {
        guard let item = playerView.player.currentItem else {return}
//        if !playedHeader && self.videoId  != nil {
//            playedHeader = true
//            loadVideoInfo(videoId!)
//            return
//        }
        //上报
        if !item.duration.isValid || item.duration.isIndefinite {
            return
        }
        if currentVieoDuration <= 60 {
            permissionUI()
        }
        shouldResetRealPlayTime = false
        uploadWatchRecord(Int(CMTimeGetSeconds(item.duration)))
    }
    //_______________________________________________________________________________________________________________
    // MARK: - 权限判断view
    
    lazy var buyView:BuyVideoView = {
        let v = Bundle.main.loadNibNamed("BuyVideoView", owner: nil, options: [:])?.first as! BuyVideoView
        v.delegate = self
        v.isHidden = true
        return v
    }()
    
    lazy var notimesView:NoTimesView = {
        let v = Bundle.main.loadNibNamed("NoTimesView", owner: nil, options: [:])?.first as! NoTimesView
        v.delegate = self
        v.isHidden = true
        return v
    }()
    
    lazy var vipView:VipVideoView = {
        let v = Bundle.main.loadNibNamed("VipVideoView", owner: nil, options: [:])?.first as! VipVideoView
        v.delegate = self
        v.isHidden = true
        return v
    }()
    
    lazy var buyBottomView:BuyBottomView = {
        let v = Bundle.main.loadNibNamed("BuyBottomView", owner: nil, options: [:])?.first as! BuyBottomView
        v.isHidden = true
        v.delegate = self
        v.layer.cornerRadius = 25 / 2
        v.layer.masksToBounds = true
        return v
    }()
    
    //MARK:- 加载视频信息
    private func loadVideoInfo(_ vId:Int) {
        loading()
        let req = FetchVideoInfoReq()
        req.videoId = vId
        Session.request(req) { (error, resp) in
            hideLoading()
            guard error == nil else{
                self.responseWatchType = .error
                self.error = error
                return
            }
            guard let video = resp as? VideoItem else{
                self.responseWatchType = .error
                self.error = error
                return
            }
            //观看类型 用于上传
            switch video.videoPayMark{
            case .free:
                self.watchType = .free
            case .pay:
                self.watchType = .coin
            case .vip:
                self.watchType = .vip
            }
            if video.canWatch {   //  ======  可以观看
                self.responseWatchType = .canWatch
                self.buyBottomView.isHidden = true
            } else {            //  ======  不可以观看
                if video.videoPayMark == .pay {      //  ------  需要付费
                    self.responseWatchType = .needPay
                    self.buyBottomView.isHidden = self.playedHeader ? false :true
                    self.buyBottomView.textLabel.text = "购买视频 观看完整版"
                    self.buyBottomView.payType = .pay
                    self.buyBottomView.item = video
                } else if video.videoPayMark == .vip {      // --------- Vip用户专享
                    self.responseWatchType = .onlyVip
                    self.buyBottomView.isHidden = self.playedHeader ?  false : true
                    self.buyBottomView.textLabel.text = "购买VIP 观看完整版"
                    self.buyBottomView.payType = .vip
                    if let user = NetDefaults.userInfo {
                        self.buyBottomView.isHidden = user.freeWatches == -1
                    }
                } else if video.videoPayMark == .free {      // --------- 次数限制
                    self.responseWatchType = .needPay
                    self.buyBottomView.isHidden = true
                    if let user = NetDefaults.userInfo {
                        if user.watched >= user.freeWatches {
                            self.responseWatchType = .noTimes
                        }
                    }
                }
            }
            if self.playedHeader {
                self.item = video
                #warning("xxx")
                self.contentView.currentVideo =  video
            } else {
                self.buyBottomView.isHidden = true
                self.notimesView.isHidden = true
                self.buyView.isHidden = true
                self.vipView.isHidden  = true
                
                self.playHeaderFirst()
                self.contentView.currentVideo =  video
            }
            self.buyView.item = video
        }
    }
    
    override var prefersStatusBarHidden: Bool {
        return true
    }
    
    override var preferredScreenEdgesDeferringSystemGestures: UIRectEdge {
        return .all
    }
    
    func getM3u8(m3u8URL: URL) {
        let localURL = M3U8LocalForRemote(m3u8URL, Int(M3U8_SERVER_PORT))!
        let asset = AVURLAsset(url: localURL);
        let item = AVPlayerItem(asset: asset)
        playerView.play(item)
        
        reduceWatched()
    }
    
    //  播放，长视频不缓存到本地
//    func playVideoItem() {
//        guard item != nil,item?.videoUrl != nil else {return}
//        guard let prefix = item!.videoUrl!.absoluteString.components(separatedBy: "?path=").first else {return}
//        
//        let urlString = "\(prefix)/by/id" + "?videoId=\(item?.videoId ?? 0)"
//        let url = URL(string: urlString)!
//        //  增加Authorization、User-Agent
//        let req1 = NSMutableURLRequest(url: url)
//        let req2 = M3U8RequestAddAdditionalInfo(req1)
//        var headerFields = req2?.allHTTPHeaderFields
////        headerFields?["videoId"] = String(item?.videoId ?? 0)
//        let options = ["AVURLAssetHTTPHeaderFieldsKey": headerFields]
////        let asset = AVURLAsset(url: url!, options: options as [String : Any]);
//        let asset = AVURLAsset(url: url, options: options as [String : Any]);
//        let item = AVPlayerItem(asset: asset)
//        playerView.play(item)
//        
//        reduceWatched()
//    }
    
    //  观看次数-1
    func reduceWatched() {
        if item != nil, let userInfo = NetDefaults.userInfo {
            if userInfo.freeWatches != -1 {    //  -1表示無限觀看次數
                if userInfo.watched < userInfo.freeWatches {
                    userInfo.watched += 1
                    NetDefaults.userInfo = userInfo
                }
            }
        }
    }
    
    //MARK:-    屏幕旋转
    
    override var shouldAutorotate: Bool {
        return true
    }
    
    override var supportedInterfaceOrientations: UIInterfaceOrientationMask {
        return .allButUpsideDown
    }
    
    override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        super.viewWillTransition(to: size, with: coordinator)
        coordinator.animate(alongsideTransition: { (context) in
            if size.width < size.height {
                self.updateFrame(portrait: size)
                self.navigationController?.interactivePopGestureRecognizer?.isEnabled = true
            } else {
                self.updateFrame(landscape: size)
                self.navigationController?.interactivePopGestureRecognizer?.isEnabled = false
            }
        }, completion: nil)
    }
    
    func updateFrame(portrait size: CGSize) {
        playerView.frame = CGRect(x: 0, y: portrait_safe_area().top,
                                  width: size.width, height: size.width / kPlayerPortraitRatio)
        buyView.frame = playerView.frame
        
        notimesView.frame = playerView.frame
        notimesView.isPortrait = true
        
        vipView.frame = playerView.frame
        
        let b:CGFloat = (UIApplication.shared.keyWindow?.safeAreaInsets.bottom ?? 0) < 34 ? 0:34
        //
        let buyBottomViewSize = CGSize(width: 150, height: 25)
        buyBottomView.frame = CGRect(x: playerView.frame.width - buyBottomViewSize.width - 20, y: is_ihpone_x() ? 5 : 25, width: buyBottomViewSize.width, height: buyBottomViewSize.height)

        contentView.frame = CGRect(x: 0, y: playerView.frame.maxY,
                                   width:size.width, height: size.height - playerView.frame.maxY)
    }
    
    func updateFrame(landscape size: CGSize) {
        //        playerView.frame = CGRect(x: 0, y: 0, width: size.width, height: size.height)
        playerView.frame = CGRect(x: landscape_safe_area().left, y: 0,
                                  width: size.width - landscape_safe_area().left - landscape_safe_area().right, height: size.height)
        buyView.frame = playerView.frame
        
        notimesView.frame = playerView.frame
        notimesView.isPortrait = false
        
        vipView.frame = playerView.frame
        //
        let buyBottomViewSize = CGSize(width: 150, height: 25)
        buyBottomView.frame = CGRect(x: playerView.frame.width - buyBottomViewSize.width - 20, y: 20, width: buyBottomViewSize.width, height: buyBottomViewSize.height)

        contentView.frame = CGRect(x: playerView.frame.minX, y: playerView.frame.maxY,
                                   width:playerView.frame.width, height: contentView.frame.height)
    }
}

//MARK:-    XSPlayerViewDelegate

extension PlayerController: XSPlayerViewDelegate {
    //  点击返回
    func playerView(_ playerView: XSPlayerView, didClickBack button: UIButton) {
        let isPortrait = playerView.bounds.width == screen_native_size().width
        if isPortrait {
            navigationController?.popViewController(animated: true)
        } else {
            UIDevice.current.setValue(UIDeviceOrientation.portrait.rawValue, forKey: "orientation")
        }
    }
    
    //  获取到视频时长
    func playerView(_ playerView: XSPlayerView, didGetDuration duration: TimeInterval) {
        currentVieoDuration = duration
        if isResumed {
            let percent :Float = Defaults.readWatchProgress(url: self.item!.videoUrl!)
            if percent > 0 {
                playerView.player.currentItem!.seek(to: CMTime(value: CMTimeValue(Float(duration) * percent) , timescale: 1)) { [weak self] (fished) in
                    if fished {
                        self?.isResumed = false
                    }
                }
            }
        }
    }
    
    //  点击全屏
    func playerView(_ playerView: XSPlayerView, didClickFullScreenButton button: UIButton) {
        button.isSelected = !button.isSelected
        if button.isSelected {
         UIDevice.current.setValue(UIDeviceOrientation.landscapeLeft.rawValue, forKey: "orientation")
        } else {
            UIDevice.current.setValue(UIDeviceOrientation.portrait.rawValue, forKey: "orientation")

        }
    }
    
    //  点击截屏
    func playerView(_ playerView: XSPlayerView, didClickCapture button: UIButton, image: UIImage?) {
        let vc = PlayerImageController()
        vc.image = image!
        present(vc, animated: false, completion: nil)
    }
    
    //  长按gif
    func playerView(_ playerView: XSPlayerView, didLongPressGifButton button: UIButton, images: [UIImage]?) {
        let vc = PlayerImageController()
        vc.images = images!
        present(vc, animated: false, completion: nil)
    }
    
    //  播放进度变化
    func playerView(_ playerView: XSPlayerView, playerItem playItem: AVPlayerItem, didChangeCurrentTime currentTime: TimeInterval) {
        //  每0.5秒回调一次
        realPlayTime += 0.5
        //大于1分钟 就试看一分钟，否则就观看完成再toast
        if currentVieoDuration >= 60 && currentTime >= 60 {
             permissionUI()
        }
        /// 观影进度信息
        let duration: TimeInterval = CMTimeGetSeconds(playItem.duration)
        var percent = currentTime / duration
        if percent.isNaN {
            percent = 0;
        }
        if percent > 0.1  && playedHeader {
            let url = self.item!.videoUrl!
            Defaults.writeWatchProgress(url: url, progress: Float(percent))
        }
    }
}

//_______________________________________________________________________________________________________________
// MARK: - 底部view操作
extension PlayerController:PlayerContentViewDelegate {
    
    /// 下载
    func click(view: PlayerContentView, download: UIButton) {
        guard let videoItem = item else { return }
        
        if !Downloader.hasVidelModel(video: videoItem) {
            PlayerAlert.alert(vc: self, item: videoItem) { (canDownload) in
                guard canDownload == true else { return }
                //  添加到缓存中
                Downloader.addVidelModel(video: videoItem)
                //  开始下载
                let item = videoItem.m3u8Item
                if item.status != .downloading {
                    item.download()
                } else {
                    item.cancel()
                }
                //  更新UI
                view.updateUI()
            }
        } else {
            //  开始下载
            let item = videoItem.m3u8Item
            if item.status != .downloading {
                item.download()
            } else {
                item.cancel()
            }
            //  更新UI
            view.updateUI()
        }
    }
    
    func clickMore(view: PlayerContentView, related: UIView?) {
        guard let studioID = item?.avStudioIds.first else { return }
        let vc = ActressDetailsVC()
        vc.contentId = studioID
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    func clickMore(view: PlayerContentView, guessLike: UIView?) {
//        guard let item = item,!item.contentList.isEmpty else {return}
    }
    
    
    func click(view: PlayerContentView, advertise: AdvertiseResp) {
        guard let url = advertise.adJump else {
            return
        }
        InnerIntercept.open(url)
    }
    
    func click(view: PlayerContentView, video: VideoItem) {
//        if self.playedHeader {
            // 上报观影记录
            guard let item = playerView.player.currentItem else {return}
            shouldResetRealPlayTime = true
            uploadWatchRecord(Int(CMTimeGetSeconds(item.currentTime())))
//            self.playedHeader = false
//        }
        self.videoId = video.videoId
    }
    
    //收藏
    func click(view: PlayerContentView, collect: UIButton) {
        guard item != nil else { return }
        collect.isSelected = !collect.isSelected
        item!.fakeLikes = collect.isSelected ? item!.fakeLikes + 1 : item!.fakeLikes - 1
        collect.setTitle("\(item!.fakeLikes)", for: UIControl.State.normal)
        collectAction(collect.isSelected)
    }
    
    /// 评分
    func click(view: PlayerContentView, comment: UIButton) {
        guard item != nil else { return }
        guard item!.scored else {
            iToast("您已評過分")
            return
        }
        let vc = PlayerCommentVC()
        vc.delegate = self
        commentButton = comment
        present(vc, animated: true, completion:nil)
    }
    
    /// 分享
    func click(view: PlayerContentView, share: UIButton) {
        let vc = Share2VC()
        navigationController?.pushViewController(vc, animated: true)
    }
}

// MARK: - 评分

extension PlayerController:CommentDelegate {
    func comment(vc: PlayerCommentVC, score: Int) {
        guard let item = item else {
            return
        }
        let req = CommentVideoReq()
        req.videoId = item.videoId
        req.score = score
        loading()
        Session.request(req) { (error, resp) in
            hideLoading()
            guard error == nil else {
                iToast(error!.localizedDescription)
                return
            }
            self.item?.scored = true
            self.commentButton?.isSelected = true
            item.fakeScoreNum += 1
            self.contentView.praiseButton.setTitle("\(item.fakeScoreNum)", for: .normal)
            iToast("評分成功",type: .succeed)
        }
    }
}

extension PlayerController:BuyBottomViewDelegate {
    func buyActionBottom() {
        // 首先判断金币够不够 不够去充值，够了直接买
        Session.request(AccountInfoReq()) { (error, resp) in
            guard error == nil else{
                iToast(error!.localizedDescription)
                return
            }
            guard let res = resp as?AccountInfo,Int(res.gold) >= self.item!.price else {
                iToast("金幣不足，請前往充值")
                DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 1.0) {
                    self.portraitAction()
                    let vc = Vip2VC()
                    vc.uiType = .coin
                    self.navigationController?.pushViewController(vc, animated: true)
                }
                return
            }
            // 购买一波
            let req = BuyVideoReq()
            req.videoId = self.item!.videoId
            loading()
            Session.request(req) { (error1, resp1) in
                 hideLoading()
                guard error1 == nil else {
                    // 购买失败
                    iToast(error!.localizedDescription)
                    return
                }
                //购买成功
                iToast("購買成功!",type: .succeed)
                DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() +  1.5) {
                    self.responseWatchType = .canWatch
                    self.resumePlay()
                }
            }
        }
    }
    
    func rentActionBottom() {
        // 租赁一波
//         loading()
        let req = BuyVideoReq()
        req.videoId = self.item!.videoId
        Session.request(req) { (error1, resp1) in
//            hideLoading()
            guard error1 == nil else {
                // 租赁失败
//                iToast(error1!.localizedDescription)
                let e = error1! as NSError
                if let code = e.userInfo["NetRequestErrorCodeKey"] as? Int,code == 1019 {
                    // 金币不足
                    DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 1.0) {
                        self.portraitAction()
                        let vc = Vip2VC()
                        vc.uiType = .coin
                        self.navigationController?.pushViewController(vc, animated: true)
                    }
                }
                return
            }
            //租赁成功
//            iToast("租賃成功!",type: .succeed)
            DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() +  1.5) {
                self.responseWatchType = .canWatch
                self.resumePlay()
            }
        }
    }
}
//_______________________________________________________________________________________________________________
// MARK: - 购买
extension PlayerController:BuyVideoViewDelegate {
    func backAction() {
       let isPortrait = playerView.bounds.width == screen_native_size().width
        if isPortrait {
            navigationController?.popViewController(animated: true)
        } else {
            UIDevice.current.setValue(UIDeviceOrientation.portrait.rawValue, forKey: "orientation")
        }
    }
    
    func buyAction() {
        // 首先判断金币够不够 不够去充值，够了直接买一波
        Session.request(AccountInfoReq()) { (error, resp) in
            guard error == nil else{
                iToast(error!.localizedDescription)
                return
            }
            guard let res = resp as?AccountInfo,Int(res.gold) >= self.item!.price else {
                iToast("金幣不足，請前往充值")
                DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 1.0) {
                    self.portraitAction()
                    let vc = Vip2VC()
                    vc.uiType = .coin
                    self.navigationController?.pushViewController(vc, animated: true)
                }
                return
            }
            // 购买一波
            let req = BuyVideoReq()
            req.videoId = self.item!.videoId
            loading()
            Session.request(req) { (error1, resp1) in
//                 hideLoading()
                guard error1 == nil else {
                    // 购买失败
                    iToast(error!.localizedDescription)
                    return
                }
                //购买成功
                iToast("購買成功!",type: .succeed)
                DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() +  1.5) {
                    self.responseWatchType = .canWatch
                    self.resumePlay()
                }
            }
        }
    }
    
    func rentAction() {
        // 租赁一波
//         loading()
        let req = BuyVideoReq()
        req.videoId = self.item!.videoId
//        req.purType = 3
        Session.request(req) { (error1, resp1) in
//            hideLoading()
            guard error1 == nil else {
                // 租赁失败
//                iToast(error1!.localizedDescription)
                let e = error1! as NSError
                if let code = e.userInfo["NetRequestErrorCodeKey"] as? Int,code == 1019 {
                    // 金币不足
                    DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 1.0) {
                        self.portraitAction()
                        let vc = Vip2VC()
                        vc.uiType = .coin
                        self.navigationController?.pushViewController(vc, animated: true)
                    }
                }
                return
            }
            //租赁成功
//            iToast("租賃成功!",type: .succeed)
            DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() +  1.5) {
                self.responseWatchType = .canWatch
                self.resumePlay()
            }
        }
    }
}

//_______________________________________________________________________________________________________________
// MARK: - 次数不够
extension PlayerController:NoTimesViewDelegate {
    func shareAction() {
        portraitAction()
        let vc = ShareVC()
        navigationController?.pushViewController(vc, animated: true)
    }
    
    func vipAction() {
         portraitAction()
        self.navigationController?.pushViewController(Vip2VC(), animated: true)
    }
    
    func backAction2() {
        let isPortrait = playerView.bounds.width == screen_native_size().width
        if isPortrait {
            navigationController?.popViewController(animated: true)
        } else {
            UIDevice.current.setValue(UIDeviceOrientation.portrait.rawValue, forKey: "orientation")
        }
    }
}

//MARK:-vip
extension PlayerController:VipVideoViewDelegate {
    func backAction3() {
        let isPortrait = playerView.bounds.width == screen_native_size().width
        if isPortrait {
            navigationController?.popViewController(animated: true)
        } else {
            UIDevice.current.setValue(UIDeviceOrientation.portrait.rawValue, forKey: "orientation")
        }
    }
    
    func vipAction3() {
        portraitAction()
        self.navigationController?.pushViewController(Vip2VC(), animated: true)
    }
}
//_______________________________________________________________________________________________________________
// MARK: - 收藏与权限判断相关
extension PlayerController {
    
    /// 恢复竖屏
    func portraitAction() {
        let isPortrait = self.playerView.bounds.width == screen_native_size().width
        if !isPortrait {
            UIDevice.current.setValue(UIDeviceOrientation.portrait.rawValue, forKey: "orientation")
        }
    }
    /// 收藏与取消收藏
    func collectAction(_ flag:Bool) {
        guard let item = item else {return}
        if flag {
            let req = LikeVideoReq()
            req.videoId = item.videoId
            Session.request(req) { (error, resp) in
                guard error == nil else {return}
                //收藏成功
                self.view.makeToast("已收藏，可在個人中心快速找到", duration:1.0, position: .center)
            }
        } else {
            let req = CancelLikeVideoReq()
            req.videoId = item.videoId
            Session.request(req) { (error, resp) in
                guard error == nil else {return}
                //取消收藏成功
                self.view.makeToast("取消收藏", duration:1.0, position: .center)
            }
        }
    }
    
    /// 恢复观看
    func resumePlay() {
        self.responseWatchType = .canWatch
        self.buyView.isHidden = true
        self.notimesView.isHidden = true
        self.vipView.isHidden = true
        guard let id = self.item?.videoId else {return}
        self.videoId = id
    }
    
    //MARK:-充值了vip 然后再返回回来的情况,让他自动播放
    func vipResumePlay() {
        guard let user = NetDefaults.userInfo else {return}
        switch self.responseWatchType {
        case .noTimes:
            if user.freeWatches == -1 {
                self.notimesView.isHidden = true
                guard let id = self.item?.videoId else {return}
                self.videoId = id
            }
        case .onlyVip:
            if user.expiredVip?.timeIntervalSince1970 ?? 0 - Date().timeIntervalSince1970 > 0 {
               guard let id = self.item?.videoId else {return}
               self.videoId = id
            }
        default:
            break
        }
    }
    
    //MARK:- 上报观影记录
    func uploadWatchRecord(_ seconds:Int) {
        if item?.canWatch == false {
            return
        }
        
        print(">>>>>>統計觀看時長!")
        if responseWatchType != .canWatch {
            return
        }
        let videoId = self.item!.videoId
        let req = AddStatisticsTimesReq()
        req.videoId = videoId
        req.progress = seconds
//        req.duration = Int(realPlayTime)
        req.lookType = self.watchType.rawValue
        Session.request(req) { (error, resp) in
            guard error == nil else {return}
        }
        //
        if shouldResetRealPlayTime {
            realPlayTime = 0
        }
    }
}

