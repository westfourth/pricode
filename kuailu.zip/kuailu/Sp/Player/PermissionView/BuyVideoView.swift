//
//  BuyVideoView.swift
//  CaoLong
//
//  Created by mac on 2020/6/2.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

@objc protocol BuyVideoViewDelegate {
    ///购买
    func buyAction()
    // 租赁
    func rentAction()
    // 返回
    func backAction()
    
}

class BuyVideoView: UIView {
    weak var delegate: BuyVideoViewDelegate?
    
    @IBOutlet weak var buyView: UIView!
    
    @IBOutlet weak var buyPrice: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        object_setClass(buyView.layer, CAGradientLayer.self)
        let i1 = buyView.layer as! CAGradientLayer
        i1.colors = [rgb(0xffE9483C).cgColor,rgb(0xffF04D40).cgColor]
        i1.startPoint = CGPoint(x: 0, y: 0)
        i1.endPoint = CGPoint(x: 1, y: 0)
    }
        
    /// 更新ui
    var item:VideoItem? {
        didSet {
            guard let item = item else {
                return
            }
            let p = "\(Int(item.price))"
//            let r = "\(Int(item.leasePrice))"
//            let d = "\(item.leaseDays)"
            let r = "0"
            let d = "0"
            
            let pt = NSMutableAttributedString(string: "\(p)金幣")
            pt.addAttributes([NSAttributedString.Key.foregroundColor : rgb(0xffffff)], range: NSRange(location: 0, length: pt.string.count))
            pt.addAttributes([NSAttributedString.Key.font : UIFont.systemFont(ofSize: 16, weight: .medium)], range: NSRange(location: 0, length: p.count))
            pt.addAttributes([NSAttributedString.Key.font : UIFont.systemFont(ofSize: 12, weight: .medium)], range: NSRange(location: pt.string.count - 2, length: 2))
            buyPrice.attributedText = pt
        }
    }
    
    // MARK: - 事件
    
    @IBAction func buyAction(_ sender: Any) {
        delegate?.buyAction()
    }
    
    @IBAction func rentAction(_ sender: Any) {
        delegate?.rentAction()
    }
    @IBAction func backAction(_ sender: Any) {
        delegate?.backAction()
    }
}
