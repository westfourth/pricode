//
//  VipBottomView.swift
//  CaoLong
//
//  Created by mac on 2020/6/4.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class VipBottomView: UIView {
    override  func awakeFromNib() {
        super.awakeFromNib()
    }
    
    @IBAction func vipAvtion(_ sender: Any) {
        currentNaviController().pushViewController(Vip2VC(), animated: true)
    }
    
    //MARK:-获取当时正在显示的ViewController
    private func currentNaviController()->UINavigationController {
        let rootVC = UIApplication.shared.keyWindow!.rootViewController as! UITabBarController
        let naviController = rootVC.selectedViewController as! UINavigationController
        return naviController
    }
    
}
