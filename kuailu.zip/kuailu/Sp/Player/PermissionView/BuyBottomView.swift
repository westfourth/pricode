//
//  BuyBottomView.swift
//  CaoLong
//
//  Created by mac on 2020/6/29.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

@objc protocol BuyBottomViewDelegate {
    ///购买
    func buyActionBottom()
}

class BuyBottomView: UIView {
    
    enum PayType {
        case pay        //  付费
        case vip        //  vip视频
    }
    
    var payType: PayType = .pay
    
    @IBOutlet weak var textLabel: UILabel!
    weak var delegate: BuyBottomViewDelegate?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        object_setClass(self.layer, CAGradientLayer.self)
        let i1 = self.layer as! CAGradientLayer
        i1.colors = [rgb(0x4A87FD).cgColor,rgb(0x7126FF).cgColor]
        i1.startPoint = CGPoint(x: 0, y: 0)
        i1.endPoint = CGPoint(x: 1, y: 0)
        
    }
    
    /// 更新ui
    var item:VideoItem?
    
    
    @IBAction func buyAction(_ sender: Any) {
        if payType == .vip {
            currentNaviController().pushViewController(Vip2VC(), animated: true)
        } else {
            delegate?.buyActionBottom()
        }
    }
    
    //MARK:-获取当时正在显示的ViewController
    private func currentNaviController()->UINavigationController {
        let rootVC = UIApplication.shared.keyWindow!.rootViewController as! UITabBarController
        let naviController = rootVC.selectedViewController as! UINavigationController
        return naviController
    }
}
