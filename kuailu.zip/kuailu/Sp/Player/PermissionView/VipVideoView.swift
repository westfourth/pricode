//
//  VipVideoView.swift
//  CaoLong
//
//  Created by mac on 2020/6/3.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

@objc protocol VipVideoViewDelegate {
    ///返回
    func backAction3()
    /// vip
    func vipAction3()
}

class VipVideoView: UIView {
    
    weak var delegate: VipVideoViewDelegate?
    
    @IBOutlet weak var vipView: UIView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        object_setClass(vipView.layer, CAGradientLayer.self)
        let i1 = vipView.layer as! CAGradientLayer
        i1.colors = [rgb(0xffE9483C).cgColor,rgb(0xffF04D40).cgColor]
        i1.startPoint = CGPoint(x: 0, y: 0)
        i1.endPoint = CGPoint(x: 1, y: 0)
    }
    
    @IBAction func backAction(_ sender: Any) {
        delegate?.backAction3()
    }
    
    @IBAction func vipAction(_ sender: Any) {
        delegate?.vipAction3()
    }
}
