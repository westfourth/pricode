//
//  NoTimesView.swift
//  CaoLong
//
//  Created by mac on 2020/6/3.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

@objc protocol NoTimesViewDelegate {
    ///分享
    func shareAction()
    // 充值
    func vipAction()
    // 返回
    func backAction2()
    
}


class NoTimesView: UIView {
    
    weak var delegate: NoTimesViewDelegate?
    
    @IBOutlet weak var leftPadding: NSLayoutConstraint!
    @IBOutlet weak var shareView: UIView!
    @IBOutlet weak var vipView: UIView!
    override func awakeFromNib() {
        super.awakeFromNib()
        
        object_setClass(shareView.layer, CAGradientLayer.self)
        let i = shareView.layer as! CAGradientLayer
        i.colors = [rgb(0xffFFEDE8).cgColor,rgb(0xffFFE4DD).cgColor]
        i.startPoint = CGPoint(x: 0, y: 0)
        i.endPoint = CGPoint(x: 1, y: 0)
        
        object_setClass(vipView.layer, CAGradientLayer.self)
        let i1 = vipView.layer as! CAGradientLayer
        i1.colors = [rgb(0xffE9483C).cgColor,rgb(0xffF04D40).cgColor]
        i1.startPoint = CGPoint(x: 0, y: 0)
        i1.endPoint = CGPoint(x: 1, y: 0)
        leftPadding.constant = ( UIScreen.main.bounds.size.width - 142 - 40 - 142 ) / 2.0
    }
    
    var isPortrait:Bool = true {
           didSet {
            leftPadding.constant = (self.width - 142 - 40 - 142 ) / 2.0
           }
       }
    
    @IBAction func shareAction(_ sender: Any) {
        delegate?.shareAction()
    }
    @IBAction func vipAction(_ sender: Any) {
        delegate?.vipAction()
    }
    
    @IBAction func backAction(_ sender: Any) {
         delegate?.backAction2()
    }
}
