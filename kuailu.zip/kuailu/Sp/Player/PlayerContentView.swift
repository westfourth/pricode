//
//  PlayerContentView.swift
//  CaoLong
//
//  Created by mac on 2020/5/22.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit
@objc protocol PlayerContentViewDelegate {
    // 点击视频
    func click(view:PlayerContentView, video:VideoItem)
    // 点击广告
    func click(view:PlayerContentView, advertise:AdvertiseResp)
        
    // 收藏
    func click(view:PlayerContentView, collect:UIButton)
    // 评分
    func click(view:PlayerContentView, comment:UIButton)
    // 分享
    func click(view:PlayerContentView, share:UIButton)
    // 下载
    func click(view:PlayerContentView, download:UIButton)
    
    //猜你喜欢和相关作品更多
    
    func clickMore(view:PlayerContentView, related:UIView?)
    
    func clickMore(view:PlayerContentView, guessLike:UIView?)
    
}

class PlayerContentView: UIView {
    @IBOutlet weak var avatarButton: UIButton!
    @IBOutlet weak var nameLabel: UILabel!
    //    @IBOutlet weak var tagButton: UIButton!
    @IBOutlet weak var titleLabel: UILabel!
//    @IBOutlet weak var playTimesLabel: UILabel!
    
    @IBOutlet weak var tagsCV: UICollectionView!
    @IBOutlet weak var praiseButton: UIButton!      //  评分
    @IBOutlet weak var favoriteButton: UIButton!    //  点赞
    @IBOutlet weak var shareButton: UIButton!
    @IBOutlet weak var download: UIButton!
    
    @IBOutlet weak var relatedCV: UICollectionView! // 相关
    @IBOutlet weak var likeCV: UICollectionView!    // 猜你喜欢
    
    @IBOutlet weak var relatedView: UIStackView!
    @IBOutlet weak var advertiseView: UIStackView!
    @IBOutlet weak var guessLikeView: UIStackView!
    
    @IBOutlet weak var guessLikeH: NSLayoutConstraint!
    @IBOutlet weak var adButton: UIButton!  // 广告
    
    @IBOutlet weak var titleH: NSLayoutConstraint!
    @IBOutlet weak var tagsH: NSLayoutConstraint!
    @IBOutlet weak var avatarStackH: NSLayoutConstraint!
    
    weak var delegate: PlayerContentViewDelegate?
    
    var relatedItems:[VideoItem] = [VideoItem]()    // 相关
    var guessLikeItems:[VideoItem] = [VideoItem]()  //  猜你喜欢
    
    var playerTag = PlayerTag()
    
    /// 头部信息
    var currentVideo:VideoItem? {
        didSet {
            guard currentVideo != nil else { return }
            avatarButton.kf.setImage(with: currentVideo!.logo, for: .normal, placeholder: Sensitive.default_bg)
            nameLabel.text = currentVideo?.nickName
            titleLabel.text = currentVideo!.title
//            playTimesLabel.text = "\(num2TenThousandStrFormat(currentVideo!.fakeWatchTimes))次播放"
            
            praiseButton.isSelected = currentVideo!.scored
            favoriteButton.isSelected = currentVideo!.isLike
            
            praiseButton.setTitle(String(currentVideo!.fakeScoreNum), for: .normal)
            favoriteButton.setTitle(String(currentVideo!.fakeLikes), for: .normal)
            shareButton.setTitle(String(currentVideo!.shares), for: .normal)
                        
            //
            currentVideo!.m3u8Item.progress = {[weak self] (received, expectedToReceive) -> Void in
                let progressText = String(format: "%.2f%%", (Float(received) / Float(expectedToReceive)) * 100)
                self?.download.setTitle(progressText, for: .normal)
            }
            currentVideo!.m3u8Item.completion = {[weak self] (error, String) -> Void in
                self?.updateUI()
            }
            
            //
//            tagsCV.semanticContentAttribute = .forceRightToLeft;
            playerTag.tagTitles = currentVideo!.tagTitles
            tagsCV.reloadData()
            
            //
            updateHeight()
            updateUI()
            
            loadRelatedVideos()
            loadGuessYouLikeVideos()
        }
    }
    
    func updateHeight() {
        // titleLabel
        let title = titleLabel.text as! NSString
        let size = title.boundingRect(with: CGSize(width: UIScreen.main.bounds.width - 12 * 2, height: 0), options: .usesLineFragmentOrigin, attributes: [.font: titleLabel.font], context: nil)
        titleH.constant = size.height
        
        //
        if playerTag.tagTitles.count == 0 {
            tagsH.constant = 16
        } else {
            let idx = IndexPath(item: playerTag.tagTitles.count - 1, section: 0)
            let attr = tagsCV.layoutAttributesForItem(at: idx)!
            tagsH.constant = attr.frame.maxY + 16
        }
        //
        avatarStackH.constant = currentVideo!.avStudioIds.isEmpty ? 0 : 40
    }
    
//    func updateTagButton(_ videoItem: VideoItem) {
//        if videoItem.videoPayMark == .pay {
//            tagButton.isHidden = false
//            tagButton.setBackgroundImage(UIImage(named: "ic_金币视频"), for: .normal)
//            tagButton.setTitle(String(videoItem.price), for: .normal)
//        } else if videoItem.videoPayMark == .vip {
//            tagButton.isHidden = false
//            tagButton.setBackgroundImage(UIImage(named: "ic_VIP视频"), for: .normal)
//            tagButton.setTitle(nil, for: .normal)
//        } else if videoItem.hd {
//            tagButton.isHidden = false
//            tagButton.setBackgroundImage(UIImage(named: "video_HD_icon"), for: .normal)
//            tagButton.setTitle(nil, for: .normal)
//        } else {
//            tagButton.isHidden = true
//            tagButton.setBackgroundImage(nil, for: .normal)
//            tagButton.setTitle(nil, for: .normal)
//        }
//    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        var nib = UINib(nibName: "Purchase2LongCell", bundle: nil)
        relatedCV.register(nib, forCellWithReuseIdentifier: "ID")
        likeCV.register(nib, forCellWithReuseIdentifier: "ID")
        nib = UINib(nibName: "PlayerTagCell", bundle: nil)
        tagsCV.register(nib, forCellWithReuseIdentifier: "ID")
        
        //
        tagsCV.dataSource = playerTag
        tagsCV.delegate = playerTag
        
        //
        var layout = relatedCV.collectionViewLayout as! UICollectionViewFlowLayout
        Purchase2LongCell.changeFlowLayout(layout: layout, isBigMode: false)
        layout = likeCV.collectionViewLayout as! UICollectionViewFlowLayout
        Purchase2LongCell.changeFlowLayout(layout: layout)
        
        if AdManager.shared.playItems.count > 0{
            // 有广告
            advertiseView.isHidden = false
            let randomValue = Int(arc4random() % UInt32(AdManager.shared.playItems.count))
            let item = AdManager.shared.playItems[randomValue]
            adButton.kf.setImage(with: item.adImage?.column0, for: .normal, options: [.preloadAllAnimationData])
        } else {
            // 无广告
            advertiseView.isHidden = true
        }
    }
    
    /// 相关视频
    private func loadRelatedVideos(){
        let req = RelatedVideosReq()
        req.videoId = currentVideo!.videoId
        Session.request(req) { (error, resp) in
            guard error == nil else {
                self.relatedView.isHidden = true
                return
            }
            guard let items = resp as? [VideoItem],!items.isEmpty else {
                self.relatedView.isHidden = true
                return
            }
            self.relatedItems = items
            self.relatedCV.reloadData()
        }
    }
    
    /// 猜你喜欢
    private func loadGuessYouLikeVideos() {
        let req = GuessYouLikeVideoReq()
        req.videoId = currentVideo!.videoId
        Session.request(req) { (error, resp) in
            guard error == nil else {
                self.guessLikeView.isHidden = true
                return
            }
            guard let items = resp as? [VideoItem],!items.isEmpty else{
                self.guessLikeView.isHidden = true
                return
            }
            self.guessLikeItems = items
            
            //  计算猜你喜欢高度
            let itemWidth: CGFloat = UIScreen.main.bounds.width - 10 * 2
            let itemHeight: CGFloat = itemWidth * 228 / 336
            let lineSpacing: CGFloat = 20
            self.guessLikeH.constant = 38.0 + 10.0 + CGFloat(items.count) * itemHeight + lineSpacing * CGFloat(items.count - 1)
            self.likeCV.reloadData()
        }
    }
    
    func updateUI() {
        var image: UIImage? = UIImage(named: "download_download")
        if currentVideo?.m3u8Item.status == .downloading {
            image = UIImage(named: "download_suspend")
        } else if currentVideo?.m3u8Item.status == .downloaded {
            image = UIImage(named: "download_complete")
        }
        download.setImage(image, for: .normal)
        //
        if currentVideo?.m3u8Item.status == .downloaded {
            download.setTitle("已下载", for: .normal)
            download.isEnabled = false
        }
    }
}

// MARK: - DataSource & Delegate

extension PlayerContentView: UICollectionViewDataSource, UICollectionViewDelegate {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if collectionView === relatedCV {
            return relatedItems.count
        } else {
            return guessLikeItems.count
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "ID", for: indexPath) as! Purchase2LongCell
        if collectionView === relatedCV {
            let item = relatedItems[indexPath.row]
            cell.isBigMode = false
            cell.item = item
            cell.personLabel.text = "\(item.fakeWatchTimes)播放"
        } else {
            let item = guessLikeItems[indexPath.row]
            cell.item = item
            if item.updatedAt != nil {
                cell.personLabel.text = "更新时间：\(Date.updateStringFor(date: item.updatedAt!))"
            } else {
                cell.personLabel.text = ""
            }
        }
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        let videoItem:VideoItem?
        if collectionView === relatedCV  {
            videoItem = relatedItems[indexPath.row]
        } else{
            videoItem = guessLikeItems[indexPath.row]
        }
        guard let item = videoItem else {return}
//        currentVideo = item
        delegate?.click(view: self, video: item)
    }
}

// MARK: - 事件

extension PlayerContentView {
    
    // 相关作品
    @IBAction func relateMoreAction(_ sender: UITapGestureRecognizer) {
        delegate?.clickMore(view: self, related: sender.view)
    }
    
    // 猜你喜欢
    @IBAction func guessLikeMoreAction(_ sender: UITapGestureRecognizer) {
        delegate?.clickMore(view: self, guessLike: sender.view)
    }
    
    // 头像
    @IBAction func click(avatar: UIButton) {
        delegate?.clickMore(view: self, related: avatar)
    }
    
    // 广告
    @IBAction func click(ad: UIButton) {
        guard  let ad = AdManager.shared.playItems.first else {return}
        delegate?.click(view: self, advertise: ad)
    }
    
    // 评分
    @IBAction func click(praise: UIButton) {
        Animation.scaleBounce(praise)
        delegate?.click(view: self, comment: praise)
    }
    // 收藏
    @IBAction func click(favorite: UIButton) {
        Animation.scaleBounce(favorite)
        delegate?.click(view: self, collect: favorite)
    }
    // 分享
    @IBAction func click(share: UIButton) {
        Animation.scaleBounce(share)
        delegate?.click(view: self, share: share)
    }
    // 下载
    @IBAction func click(download: UIButton) {
        Animation.scaleBounce(download)
        delegate?.click(view: self, download: download)
    }
}
