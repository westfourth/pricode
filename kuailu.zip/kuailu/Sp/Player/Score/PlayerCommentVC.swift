//
//  PlayerCommentVC.swift
//  CaoLong
//
//  Created by mac on 2020/6/2.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

@objc protocol CommentDelegate {
    ///评分
    func comment(vc:PlayerCommentVC, score:Int)
}

class PlayerCommentVC: UIViewController,UIViewControllerTransitioningDelegate, CommentPresentTransitionDelegate {
    
    weak var delegate: CommentDelegate?
    
    @IBOutlet weak var collectionView: UICollectionView!
    @IBOutlet weak var name: UILabel!
    @IBOutlet weak var submit: UIButton!
    
    var currentIndex = 4
    
//    private let names = ["独乐乐不如众乐乐","撸点满满，爱了爱了！","平平无奇，可撸","强撸灰飞烟灭","我佛了"]
    private let names = [
                          "我佛了",
                          "強擼灰飛煙滅",
                          "平平無奇，可擼",
                          "擼點滿滿，愛了愛了！",
                          "獨樂樂不如眾樂樂"]

    var presentTransition = CommentPresentTransition()
    
    override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: Bundle?) {
        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
        modalPresentationStyle = .overFullScreen
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        transitioningDelegate = self
        presentTransition.delegate = self

        collectionView.register(UINib(nibName: "PlayerCommentCell", bundle: Bundle.main), forCellWithReuseIdentifier: "PlayerCommentCell")
        
        submit.layer.shadowColor = UIColor.black.cgColor
        submit.layer.masksToBounds = false
        submit.layer.shadowRadius = 10
        submit.layer.shadowOffset = .zero
        submit.layer.shadowOpacity = 0.7
        
    }
    
    @IBAction func submitAction(_ sender: Any) {
        // 提交
        delegate?.comment(vc: self, score: (currentIndex + 1 ) * 2)
        
        dismiss(animated: true, completion: nil)
    }
    
    
    //MARK:-    转场动画
    
    func animationController(forPresented presented: UIViewController, presenting: UIViewController, source: UIViewController) -> UIViewControllerAnimatedTransitioning? {
        return presentTransition
    }
    
    func animationController(forDismissed dismissed: UIViewController) -> UIViewControllerAnimatedTransitioning? {
        return CommentDismissTransition()
    }

    func transition(didTapContainerView on: CommentPresentTransition) {
        dismiss(animated: true, completion: nil)
    }
    
}

//_______________________________________________________________________________________________________________
// MARK: - UICollectionViewDataSource&Delegate
extension PlayerCommentVC:UICollectionViewDataSource,UICollectionViewDelegate {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return names.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "PlayerCommentCell", for: indexPath) as! PlayerCommentCell
        cell.isselected = indexPath.row <= currentIndex
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        if indexPath.row == currentIndex {
            if indexPath.row != 0 {
              currentIndex = indexPath.row - 1
            } else {
                currentIndex = 0
            }
        } else {
            currentIndex = indexPath.row
        }
        name.text = names[currentIndex]
        collectionView.reloadData()
    }
}

