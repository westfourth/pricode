//
//  PlayerCommentCell.swift
//  CaoLong
//
//  Created by mac on 2020/6/2.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class PlayerCommentCell: UICollectionViewCell {
    @IBOutlet weak var icon: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    var isselected:Bool? {
        didSet {
            guard let s = isselected else {
                return
            }
            icon.image = s ? UIImage(named: "ic_star_1"):UIImage(named: "ic_star_2")
        }
    }
    
}
