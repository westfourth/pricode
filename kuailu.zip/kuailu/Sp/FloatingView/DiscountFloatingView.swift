//
//  DiscountFloatingView.swift
//  Sp
//
//  Created by mac on 2020/9/24.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class DiscountFloatingView: UIView {
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var label: UILabel!
    var timer: Timer?
    var count: Int = 0
    
    var discounts: ChargeLimitDiscounts? {
        didSet {
            guard let item = discounts else { return }
            imageView.kf.setImage(with: item.coverPicture)
            
            count = item.countDown / 1000
            label.text = timeText(count: count)
            
            timer?.invalidate()
            timer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(scheduledTimer), userInfo: nil, repeats: true)
        }
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }
    
    @IBAction func tap(_ sender: UITapGestureRecognizer) {
        guard let url = discounts?.actUrl else { return }
        InnerIntercept.open(url)
    }
    
    @objc func scheduledTimer() {
        count -= 1
        label.text = timeText(count: count)
        //
        if count == 0 {
            timer?.invalidate()
            isHidden = true
        }
    }
    
    func timeText(count: Int) -> String {
        let hours: Int = count / 3600
        let minutes: Int = (count % 3600) / 60
        let seconds: Int = count % 60
        var text = ""
        if hours > 0 {
            text = String(format: "%02d:%02d:%02d", hours, minutes, seconds)
        } else {
            text = String(format: "%02d:%02d", minutes, seconds)
        }
        return text
    }
}
