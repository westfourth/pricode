//
//  SearchVCViewController.swift
//  Sp
//
//  Created by mac on 2020/2/25.
//  Copyright © 2020 mac. All rights reserved.
//

class SearchVC: UIViewController{
    
    private let clientWidthRatio: CGFloat = UIScreen.main.bounds.size.width / 375
    
    private let maxKeyWordsLen: Int = 15
    
    private lazy var searchBgView: UIView = {
        let view = UIView()
        view.backgroundColor = RGB(0x373B3E)
        view.layer.cornerRadius = 30 * clientWidthRatio / 2
        view.clipsToBounds = true
        view.addSubview(searchIcon)
        view.addSubview(inputField)
        searchIcon.snp.makeConstraints { (make) in
            make.left.equalToSuperview().inset(12)
            make.centerY.equalToSuperview()
            make.size.equalTo(15)
        }
        inputField.snp.makeConstraints { (make) in
            make.left.equalTo(searchIcon.snp.right).offset(6)
            make.top.right.bottom.equalToSuperview()
        }
        return view
    }()
    
    private lazy var searchIcon: UIImageView = {
        return UIImageView(image: UIImage(named: "search_icon_white"))
    }()
    
    private lazy var inputField: UITextField = {
        let input  = UITextField()
        input.delegate = self
        input.font = UIFont.pingFangMedium(14)
        input.textColor = .white
        input.placeholder = "搜索視頻或用戶（最長\(maxKeyWordsLen)個字符）"
        input.setValue(RGB(0x939393), forKeyPath: "placeholderLabel.textColor")
        input.setValue(UIFont.pingFangRegular(14), forKeyPath: "placeholderLabel.font")
        input.textAlignment = .left
        input.clearButtonMode = .whileEditing
        input.addDoneOnKeyboardWithTarget(self, action: #selector(onDoneKeyboardClick))
        input.returnKeyType = .done
        return input
    }()
    
    private lazy var searchRecordVC: SearchRecordVC = {
        let searchRecordVC = SearchRecordVC()
        searchRecordVC.delegate = self
        return searchRecordVC
    }()
    
    private lazy var searchResultVC: SearchResultVC = {
        let vc = SearchResultVC()
        vc.delegate = self
        vc.view.isHidden = true
        return vc
    }()
    
    override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: Bundle?) {
        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
        hidesBottomBarWhenPushed = true
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = RGB(0xff141516)
        renderNavigator()
        renderView()
        getHistoryTagsData()
        getRecommendTags()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.navigationBar.isTranslucent = true
        navigationController?.navigationBar.barTintColor = RGB(0x141516)
    }
    
    private func renderNavigator() {
        navigationItem.rightBarButtonItem = UIBarButtonItem(customView: searchBgView)
        searchBgView.snp.makeConstraints { (make) in
            make.width.equalTo(view.width - (view.width > 375 ? 20 : 16) * 2 - 20)
            make.height.equalTo(30 * clientWidthRatio)
        }
    }
    
    private func renderView() {
        addChild(searchRecordVC)
        view.addSubview(searchRecordVC.view)
        addChild(searchResultVC)
        view.addSubview(searchResultVC.view)
        
        searchRecordVC.view.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
        
        searchResultVC.view.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
    }
    
    private func getHistoryTagsData() {
        if let historyTagsList = Defaults.historyTags {
            searchRecordVC.historyData = historyTagsList
        } else {
            searchRecordVC.historyData = []
        }
    }
    
    private func saveHistoryTagsData() {
        guard let val = inputField.text else { return }
        if var historyTagsList = Defaults.historyTags {
            if let index = historyTagsList.firstIndex(of: val) {
                historyTagsList.remove(at: index)
            }
            historyTagsList.insert(val, at: 0)
            Defaults.historyTags = historyTagsList.count > 20 ? Array(historyTagsList[0...19]) : historyTagsList
        } else {
            Defaults.historyTags = [val]
        }
    }
    
    private func getRecommendTags() {
        let req =  HotTagReq()
        Session.request(req) { [weak self] (error, resp) in
            guard let `self` = self else { return }
            guard error == nil, let resData = resp as? [HotTagResp] else { return }
            self.searchRecordVC.recommendList = resData
        }
    }
    
    private func switchToResultView() {
        searchRecordVC.view.isHidden = true
        searchResultVC.view.isHidden = false
    }
    
    @objc private func onSearchBegin() {
        inputField.resignFirstResponder()
        guard let val = inputField.text?.trimmingCharacters(in: .whitespacesAndNewlines), !val.isEmpty else {
            inputField.text = ""
            searchResultVC.keyword = ""
            return
        }
        guard val.count <= maxKeyWordsLen else {
            mm_showToast("關鍵詞不得大於\(maxKeyWordsLen)個字符")
            return
        }
        if searchResultVC.keyword != val {
            initSearchListState()
        }
        inputField.text = val
        searchResultVC.keyword = val
        saveHistoryTagsData()
        switchToResultView()
        initSearchListState()
        getList(isRefresh: true, searchResultVCType: .smallVideo)
    }
    
    private func initSearchListState() {
        searchResultVC.resultSmallVideoList = []
        searchResultVC.resultVideoList = []
        searchResultVC.resultFocusList = []
        searchResultVC.focusPageNum = 0
        searchResultVC.smallVideoCollectionView.reloadData()
        searchResultVC.videoTableView.reloadData()
        searchResultVC.focusTableView.reloadData()
    }
    
    @objc private func onDoneKeyboardClick() {
        onSearchBegin()
    }
    
    private func handleListException(scrollView: UIScrollView, searchResultVCType: SearchResultVCType, isRefresh: Bool, pageNum: Int) {
        if isRefresh || pageNum == 1 {
            switch searchResultVCType {
            case .user:
                searchResultVC.focusPageNum = 0
                searchResultVC.resultFocusList = []
                searchResultVC.focusTableView.reloadData()
            case .smallVideo:
                searchResultVC.resultSmallVideoList = []
                searchResultVC.smallVideoCollectionView.reloadData()
            case .video:
                searchResultVC.resultVideoList = []
                searchResultVC.videoTableView.reloadData()
            }
            scrollView.state = .failed
            scrollView.mj_footer?.isHidden = true
        } else {
            scrollView.mj_footer?.endRefreshingWithNoMoreData()
            scrollView.mj_footer?.isHidden = false
        }
    }
    
}

extension SearchVC: UITextFieldDelegate {
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        onSearchBegin()
        return true
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        let len = textField.text!.count + string.count - range.length
        guard len <= maxKeyWordsLen else {
            mm_showToast(inputField.placeholder!)
            return false
        }
        return true
    }
    
}

extension SearchVC: SearchRecordViewDelegate {
    
    func deleteAllRecordTags() {
        Defaults.historyTags = []
        searchRecordVC.historyData = []
    }
    
    func searchTagByTags(keyword: String) {
        inputField.text = keyword
        searchResultVC.keyword = keyword
        switchToResultView()
        getList(isRefresh: true, searchResultVCType: .smallVideo)
    }
}

extension SearchVC: SearchResultVCDelegate {
    
    func getList(isRefresh: Bool, searchResultVCType: SearchResultVCType) {
        guard let keyword  = inputField.text else { return }
        let scrollView = searchResultVCType == .smallVideo ? searchResultVC.smallVideoCollectionView : searchResultVCType == .video ? searchResultVC.videoTableView : searchResultVC.focusTableView
        scrollView.state = (searchResultVCType == .smallVideo ? searchResultVC.resultSmallVideoList.isEmpty : searchResultVCType == .video ? searchResultVC.resultVideoList.isEmpty : searchResultVC.resultFocusList.isEmpty) ? .loading : .normal
        if isRefresh {
            scrollView.mj_footer?.resetNoMoreData()
        }
        let pageNum = searchResultVCType == .user ? searchResultVC.focusPageNum : 0
        var req: AnyObject
        switch searchResultVCType {
        case .user:
            req = KeyWordSearchUserListReq()
            (req as! KeyWordSearchUserListReq).nickName = keyword
            (req as! KeyWordSearchUserListReq).page = isRefresh ? 1 : pageNum + 1
        case .smallVideo, .video:
            req = TitleSearchVideoReq()
            (req as! TitleSearchVideoReq).lastId = isRefresh ? 0 : ((searchResultVCType == .smallVideo ? self.searchResultVC.resultSmallVideoList.last?.videoId : self.searchResultVC.resultVideoList.last?.videoId) ?? 0)
            (req as! TitleSearchVideoReq).videoType = searchResultVCType == .smallVideo ? 1 : 2
            (req as! TitleSearchVideoReq).title = keyword
        }
        
        Session.request(searchResultVCType == .user ? (req as! KeyWordSearchUserListReq) : (req as! TitleSearchVideoReq)) { [weak self] (error, resp) in
            isRefresh ? scrollView.mj_header?.endRefreshing() : scrollView.mj_footer?.endRefreshing()
            guard let `self` = self else { return }
            
            guard error == nil, searchResultVCType == .user ? resp is [UserItem] : resp is [VideoItem] else {
                self.handleListException(scrollView: scrollView, searchResultVCType: searchResultVCType, isRefresh: isRefresh, pageNum: pageNum)
                return
            }
            
            switch searchResultVCType {
            case .user:
                self.searchResultVC.focusPageNum = req.page
                self.searchResultVC.resultFocusList = isRefresh ? ((resp ?? []) as! [UserItem]) : self.searchResultVC.resultFocusList + ((resp ?? []) as! [UserItem])
            case .smallVideo:
                self.searchResultVC.resultSmallVideoList = isRefresh ? ((resp ?? []) as! [VideoItem]) : self.searchResultVC.resultSmallVideoList + ((resp ?? []) as! [VideoItem])
            case .video:
                self.searchResultVC.resultVideoList = isRefresh ? ((resp ?? []) as! [VideoItem]) : self.searchResultVC.resultVideoList + ((resp ?? []) as! [VideoItem])
            }
            
            if (searchResultVCType == .user ? ((resp ?? []) as! [UserItem]).count : ((resp ?? []) as! [VideoItem]).count) < req.pageSize {
                scrollView.mj_footer?.endRefreshingWithNoMoreData()
            }
            
            if searchResultVCType == .user ? self.searchResultVC.resultFocusList.isEmpty : searchResultVCType == .smallVideo ? self.searchResultVC.resultSmallVideoList.isEmpty : self.searchResultVC.resultVideoList.isEmpty {
                scrollView.state = .empty
                scrollView.mj_footer?.isHidden = true
            } else {
                scrollView.state = .normal
                scrollView.mj_footer?.isHidden = false
                searchResultVCType == .smallVideo ? (scrollView as? UICollectionView)?.reloadData() : (scrollView as? UITableView)?.reloadData()
            }
        }
    }
}
