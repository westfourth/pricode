//
//  SearchResultFocusCell.swift
//  Sp
//
//  Created by mac on 2020/3/4.
//  Copyright © 2020 mac. All rights reserved.
//

protocol SearchResultFocusCellDelegate: NSObjectProtocol {
    
    func switchFocusStatus(dataModel: UserItem, cell: SearchResultFocusCell)
    
}

class SearchResultFocusCell: UITableViewCell {
    
    static let userId: Int = {
        return NetDefaults.userInfo?.userId ?? -1
    }()
    
    weak var delegate: SearchResultFocusCellDelegate?
    
    var isFocus: Bool = false {
        didSet {
            if isFocus {
                focusBtn.backgroundColor = .none
                focusBtn.setTitle("取消關注", for: .normal)
                focusBtn.setTitleColor(RGB(0xFA6400), for: .normal)
            } else {
                focusBtn.backgroundColor = RGB(0xFA6400)
                focusBtn.setTitle("關注", for: .normal)
                focusBtn.setTitleColor(.white, for: .normal)
            }
        }
    }
    
    static let avatarImg: UIImage? = {
        return Sensitive.avatar
    }()
    
    static let animationOption: KingfisherOptionsInfo = {
        return [.transition(.fade(0.25))]
    }()
    
    var dataModel: UserItem? {
        didSet {
            guard let item = dataModel else { return }
            focusBtn.isHidden = item.userId == SearchResultFocusCell.userId
            avatar.kf.setImage(with: item.logo?.column3, placeholder: SearchResultFocusCell.avatarImg, options: SearchResultFocusCell.animationOption)
            titleLabel.text = item.nickName
            isFocus = item.isAttention
        }
    }
    
    private lazy var avatar: UIImageView = {
        let imageView = UIImageView()
        imageView.layer.cornerRadius = 26
        imageView.layer.masksToBounds = true
        imageView.backgroundColor = RGB(0x999999)
        imageView.contentMode = .scaleAspectFill
        return imageView
    }()
    
    private lazy var titleLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.pingFangMedium(17)
        label.textColor = .white
        label.numberOfLines = 1
        return label
    }()
    
    private lazy var focusBtn: UIButton = {
        let btn = UIButton()
        btn.setTitleColor(.white, for: .normal)
        btn.setTitle("關注", for: .normal)
        btn.titleLabel?.font = UIFont.pingFangRegular(13)
        let color = RGB(0xFA6400)
        btn.backgroundColor = color
        btn.layer.borderColor = color.cgColor
        btn.layer.borderWidth = 1
        btn.layer.cornerRadius = 13
        btn.addTarget(self, action: #selector(onFocusBtnClick), for: .touchUpInside)
        return btn
    }()
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        backgroundColor = .none
        selectionStyle = .none
        renderView()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func renderView() {
        contentView.addSubview(avatar)
        contentView.addSubview(titleLabel)
        contentView.addSubview(focusBtn)
        
        avatar.snp.makeConstraints { (make) in
            make.left.equalToSuperview().inset(12)
            make.top.equalToSuperview()
            make.size.equalTo(52)
        }
        
        focusBtn.snp.makeConstraints { (make) in
            make.right.equalToSuperview().inset(16)
            make.centerY.equalTo(avatar)
            make.width.equalTo(80)
            make.height.equalTo(26)
        }
        
        titleLabel.snp.makeConstraints { (make) in
            make.centerY.equalTo(avatar)
            make.left.equalTo(avatar.snp.right).offset(12)
            make.right.equalTo(focusBtn.snp.left).offset(-12)
        }
    }
    
    @objc func onFocusBtnClick() {
        delegate?.switchFocusStatus(dataModel: dataModel!, cell: self)
    }
    
}

