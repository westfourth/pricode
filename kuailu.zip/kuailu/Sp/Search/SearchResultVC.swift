//
//  SearchResultVCViewController.swift
//  Sp
//
//  Created by mac on 2020/2/25.
//  Copyright © 2020 mac. All rights reserved.
//


protocol SearchResultVCDelegate: NSObjectProtocol {
    
    func getList(isRefresh: Bool, searchResultVCType: SearchResultVCType)
    
}

enum SearchResultVCType {
    case smallVideo
    case video
    case user
}

class SearchResultVC: UIViewController {
    
    private let itemWidth: CGFloat = (UIScreen.main.bounds.size.width - 12 * 2 - 6) / 2
    
    weak var delegate: SearchResultVCDelegate?
    
    var keyword: String = ""
    
    var focusPageNum: Int = 0
    
    var resultSmallVideoList: [VideoItem] = []
    
    var resultVideoList: [VideoItem] = []
    
    var resultFocusList: [UserItem] = []
    
    lazy var smallVideoCollectionView: UICollectionView = {
        let layout = UICollectionViewFlowLayout()
        let ratio:CGFloat = 230 / 165
        layout.itemSize = CGSize(width: itemWidth, height: itemWidth * ratio)
        layout.minimumLineSpacing = 6
        layout.minimumInteritemSpacing = 6
        layout.sectionInset = UIEdgeInsets(top: 0, left: 12, bottom: 0, right: 12)
        let cv = UICollectionView(frame: .zero, collectionViewLayout: layout)
        cv.register(SearchResultVideoCell.self, forCellWithReuseIdentifier: "SearchResultVideoCell")
        cv.backgroundColor = .none
        cv.delegate = self
        cv.dataSource = self
        cv.state = .loading
        cv.mj_header = getCommonMJHeader(refreshingTarget: self, headerRefreshCallback: #selector(onSmallVideoRefresh))
        cv.mj_footer = getCommonMJFooter(refreshingTarget: self, footerRefreshCallback: #selector(onSmallVideoLoad))
        cv.mj_footer!.isHidden = true
        return cv
    }()
    
    lazy var videoTableView: UITableView = {
        let tableView = UITableView(frame: .zero, style: .plain)
        tableView.delegate = self
        tableView.dataSource = self
        tableView.backgroundColor = .none
        tableView.separatorStyle = .none
        tableView.rowHeight = FeaturedTopicListItemSubCell.itemHeight
        tableView.estimatedRowHeight = tableView.rowHeight
        tableView.estimatedSectionFooterHeight = 0
        tableView.estimatedSectionHeaderHeight = 0
        tableView.contentInsetAdjustmentBehavior = .never
        tableView.register(FeaturedTopicListItemSubCell.self, forCellReuseIdentifier: "FeaturedTopicListItemSubCell")
        tableView.showsHorizontalScrollIndicator = false
        tableView.contentInset = UIEdgeInsets(top: 0, left: 0, bottom: 20, right: 0)
        tableView.isHidden = true
        tableView.mj_header = getCommonMJHeader(refreshingTarget: self, headerRefreshCallback: #selector(onVideoRefresh))
        tableView.mj_footer = getCommonMJFooter(refreshingTarget: self, footerRefreshCallback: #selector(onVideoLoad))
        return tableView
    }()
    
    lazy var focusTableView: UITableView = {
        let tableView = UITableView(frame: .zero, style: .plain)
        tableView.delegate = self
        tableView.dataSource = self
        tableView.backgroundColor = .none
        tableView.separatorStyle = .none
        tableView.rowHeight = 70
        tableView.estimatedRowHeight = 70
        tableView.estimatedSectionFooterHeight = 0
        tableView.estimatedSectionHeaderHeight = 0
        tableView.isHidden = true
        tableView.contentInsetAdjustmentBehavior = .never
        tableView.state = .loading
        tableView.register(SearchResultFocusCell.self, forCellReuseIdentifier: "SearchResultFocusCell")
        tableView.mj_header = getCommonMJHeader(refreshingTarget: self, headerRefreshCallback: #selector(onFocusRefresh))
        tableView.mj_footer = getCommonMJFooter(refreshingTarget: self, footerRefreshCallback: #selector(onFocusLoad))
        tableView.mj_footer!.isHidden = true
        return tableView
    }()
    
    lazy var leftTabBar: UIButton = {
        let btn = UIButton()
        btn.setTitle("小視頻", for: .normal)
        btn.setTitleColor(RGB(0xC9C9C9), for: .normal)
        btn.setTitleColor(.white, for: .selected)
        btn.titleLabel?.font = UIFont.pingFangMedium(16)
        btn.isSelected = true
        btn.addTarget(self, action: #selector(onLeftTabClick), for: .touchUpInside)
        return btn
    }()
    
    lazy var middleTabBar: UIButton = {
        let btn = UIButton()
        btn.setTitle("視頻", for: .normal)
        btn.setTitleColor(RGB(0xC9C9C9), for: .normal)
        btn.setTitleColor(.white, for: .selected)
        btn.titleLabel?.font = UIFont.pingFangMedium(16)
        btn.isSelected = false
        btn.addTarget(self, action: #selector(onMiddleTabClick), for: .touchUpInside)
        return btn
    }()
    
    lazy var rightTabBar: UIButton = {
        let btn = UIButton()
        btn.setTitle("用戶", for: .normal)
        btn.setTitleColor(RGB(0xC9C9C9), for: .normal)
        btn.setTitleColor(.white, for: .selected)
        btn.titleLabel?.font = UIFont.pingFangMedium(16)
        btn.isSelected = false
        btn.addTarget(self, action: #selector(onRightTabClick), for: .touchUpInside)
        return btn
    }()
    
    private lazy var indicatorView: UIView = {
        let view = UIView()
        view.backgroundColor = .white
        view.layer.masksToBounds = true
        view.layer.cornerRadius = 1.5
        return view
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        renderView()
    }
    
    private func renderView() {
        view.addSubview(leftTabBar)
        view.addSubview(middleTabBar)
        view.addSubview(rightTabBar)
        view.addSubview(indicatorView)
        view.addSubview(smallVideoCollectionView)
        view.addSubview(videoTableView)
        view.addSubview(focusTableView)
        
        middleTabBar.snp.makeConstraints { (make) in
            make.top.equalToSuperview().inset(kTop + 10)
            make.centerX.equalToSuperview()
            make.width.equalTo(34)
            make.height.equalTo(48)
        }
        
        leftTabBar.snp.makeConstraints { (make) in
            make.top.equalTo(middleTabBar)
            make.right.equalTo(middleTabBar.snp.left).offset(-40)
            make.width.equalTo(51)
            make.height.equalTo(48)
        }
        
        rightTabBar.snp.makeConstraints { (make) in
            make.top.equalTo(middleTabBar)
            make.left.equalTo(middleTabBar.snp.right).offset(40)
            make.width.equalTo(34)
            make.height.equalTo(48)
        }
        
        indicatorView.snp.makeConstraints { (make) in
            make.centerY.equalTo(leftTabBar).offset(13)
            make.centerX.equalTo(leftTabBar)
            make.width.equalTo(30)
            make.height.equalTo(3)
        }
        
        smallVideoCollectionView.snp.makeConstraints { (make) in
            make.top.equalTo(leftTabBar.snp.bottom)
            make.left.right.bottom.equalToSuperview()
        }
        
        videoTableView.snp.makeConstraints { (make) in
            make.top.equalTo(leftTabBar.snp.bottom)
            make.left.right.bottom.equalToSuperview()
        }
        
        focusTableView.snp.makeConstraints { (make) in
            make.top.equalTo(leftTabBar.snp.bottom)
            make.left.right.bottom.equalToSuperview()
        }
        
    }
    
    private func renderSmallVideoView() {
        switchTabBarState(searchResultVCType: .smallVideo)
        switchIndicatorLayout(searchResultVCType: .smallVideo)
    }
    
    private func renderVideoView() {
        switchTabBarState(searchResultVCType: .video)
        switchIndicatorLayout(searchResultVCType: .video)
    }
    
    private func renderFocusView() {
        switchTabBarState(searchResultVCType: .user)
        switchIndicatorLayout(searchResultVCType: .user)
    }
    
    private func switchTabBarState(searchResultVCType: SearchResultVCType) {
        switch searchResultVCType {
        case .smallVideo:
            middleTabBar.isSelected = false
            rightTabBar.isSelected = false
            leftTabBar.isSelected = true
            focusTableView.isHidden = true
            videoTableView.isHidden = true
            smallVideoCollectionView.isHidden = false
        case .video:
            rightTabBar.isSelected = false
            leftTabBar.isSelected = false
            middleTabBar.isSelected = true
            smallVideoCollectionView.isHidden = true
            focusTableView.isHidden = true
            videoTableView.isHidden = false
        case .user:
            leftTabBar.isSelected = false
            middleTabBar.isSelected = false
            rightTabBar.isSelected = true
            videoTableView.isHidden = true
            smallVideoCollectionView.isHidden = true
            focusTableView.isHidden = false
        }
    }
    
    @objc private func onSmallVideoRefresh() {
        checkKeywordValid() ? delegate?.getList(isRefresh: true, searchResultVCType: .smallVideo) : smallVideoCollectionView.mj_header?.endRefreshing()
    }
    
    @objc private func onSmallVideoLoad() {
        checkKeywordValid() ? delegate?.getList(isRefresh: false, searchResultVCType: .smallVideo) :  smallVideoCollectionView.mj_footer?.endRefreshing()
    }
    
    @objc private func onVideoRefresh() {
        checkKeywordValid() ? delegate?.getList(isRefresh: true, searchResultVCType: .video) : videoTableView.mj_header?.endRefreshing()
    }
    
    @objc private func onVideoLoad() {
        checkKeywordValid() ? delegate?.getList(isRefresh: false, searchResultVCType: .video) :  videoTableView.mj_footer?.endRefreshing()
    }
    
    @objc private func onFocusRefresh() {
        checkKeywordValid() ? delegate?.getList(isRefresh: true, searchResultVCType: .user) : focusTableView.mj_header?.endRefreshing()
    }
    
    @objc private func onFocusLoad() {
        checkKeywordValid() ? delegate?.getList(isRefresh: false, searchResultVCType: .user) : focusTableView.mj_footer?.endRefreshing()
    }
    
    @objc private func onLeftTabClick() {
        renderSmallVideoView()
        if checkKeywordValid(), resultSmallVideoList.isEmpty {
            delegate?.getList(isRefresh: true, searchResultVCType: .smallVideo)
        }
    }
    
    @objc private func onMiddleTabClick() {
        renderVideoView()
        if checkKeywordValid(), resultVideoList.isEmpty {
            delegate?.getList(isRefresh: true, searchResultVCType: .video)
        }
    }
    
    @objc private func onRightTabClick() {
        renderFocusView()
        if checkKeywordValid(), resultFocusList.isEmpty {
            delegate?.getList(isRefresh: true, searchResultVCType: .user)
        }
    }
    
    private func switchIndicatorLayout(searchResultVCType: SearchResultVCType) {
        indicatorView.snp.remakeConstraints { (make) in
            make.centerY.equalTo(leftTabBar).offset(13)
            make.centerX.equalTo(searchResultVCType == .smallVideo ? leftTabBar : searchResultVCType == .video ? middleTabBar : rightTabBar)
            make.width.equalTo(30)
            make.height.equalTo(3)
        }
        updateLayoutConstraints()
        UIView.animate(withDuration: 0.3) { [weak self] in
            self?.view.layoutIfNeeded()
        }
    }
    
    private func updateLayoutConstraints() {
        view.updateConstraintsIfNeeded()
        view.updateFocusIfNeeded()
    }
    
    private func checkKeywordValid() -> Bool {
        guard !keyword.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
            return false
        }
        return true
    }
    
    static func navigationToVideoPlayListVC(indexPath: IndexPath, VideoList: [VideoItem]) {
        guard !VideoList.isEmpty, indexPath.row < VideoList.count, let userinfo = NetDefaults.userInfo, let currentNaviController = (UIApplication.shared.delegate as? AppDelegate)?.currentNavigationController else { return }
        switch userinfo.specialAuth {
        case true:
            let shortVideoListVC = ShortVideoListVC()
            shortVideoListVC.currentPlayingIndexPath = indexPath
            shortVideoListVC.videoItems = VideoList
            shortVideoListVC.hidesBottomBarWhenPushed = true
            currentNaviController.show(shortVideoListVC, sender: nil)
        default:
            let currentItem = VideoList[indexPath.row]
            guard currentItem.isSpecial, currentItem.userId != userinfo.userId else {
                let listData = VideoList.filter{ $0.userId == userinfo.userId || !$0.isSpecial }
                guard !listData.isEmpty else { return }
                let shortVideoListVC = ShortVideoListVC()
                shortVideoListVC.currentPlayingIndexPath = IndexPath(item: listData.firstIndex(where: { $0.videoId == currentItem.videoId
                }) ?? 0, section: 0)
                shortVideoListVC.videoItems = listData
                shortVideoListVC.hidesBottomBarWhenPushed = true
                currentNaviController.show(shortVideoListVC, sender: nil)
                return
            }
            
            Alert.showCommonAlert(parentView: UIApplication.shared.keyWindow!, contentText: "該視頻為V6專享，是否\(Sensitive.gou)門票", cancelText: "升級\(Sensitive.hui)等級", confirmText: "\(Sensitive.gou)", onConfirmTap: {
                let vc = Vip2VC()
                vc.uiType = .ticket
                currentNaviController.pushViewController(vc, animated: true)
            }, onCancelTap: {
                let vc = Vip2VC()
                vc.uiType = .vip
                currentNaviController.pushViewController(vc, animated: true)
            })
        }
    }
    
}

extension SearchResultVC: UICollectionViewDelegate, UICollectionViewDataSource {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return resultSmallVideoList.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "SearchResultVideoCell", for: indexPath) as! SearchResultVideoCell
        cell.dataModel = resultSmallVideoList[indexPath.row]
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        SearchResultVC.navigationToVideoPlayListVC(indexPath: indexPath, VideoList: collectionView == smallVideoCollectionView ? resultSmallVideoList : resultVideoList)
    }
    
}

extension SearchResultVC: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return tableView == focusTableView ? resultFocusList.count : resultVideoList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard tableView == focusTableView else {
            let cell = tableView.dequeueReusableCell(withIdentifier: "FeaturedTopicListItemSubCell") as! FeaturedTopicListItemSubCell
            cell.dataModel = resultVideoList[indexPath.row]
            return cell
        }
        let cell = tableView.dequeueReusableCell(withIdentifier: "SearchResultFocusCell") as! SearchResultFocusCell
        cell.dataModel = resultFocusList[indexPath.row]
        cell.delegate = self
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        guard tableView == focusTableView else {
            let vc = PlayerController()
            vc.videoId = resultVideoList[indexPath.row].videoId
            navigationController?.pushViewController(vc, animated: true)
            return
        }
        let userId = resultFocusList[indexPath.row].userId
        guard userId != SearchResultFocusCell.userId else { return }
        let usersDynamicVC = UsersDynamicVC()
        usersDynamicVC.userId = userId
        usersDynamicVC.attentionClosure = { [weak self] (isAttention: Bool) in
            guard let `self` = self else { return }
            self.resultFocusList[indexPath.row].isAttention =  isAttention
            self.focusTableView.reloadData()
            usersDynamicVC.attentionClosure = nil
        }
        navigationController?.show(usersDynamicVC, sender: nil)
    }
    
}

extension SearchResultVC: SearchResultFocusCellDelegate {
    
    func switchFocusStatus(dataModel: UserItem, cell: SearchResultFocusCell) {
        
        guard dataModel.isAttention else {
            Alert.showLoading(parentView: view)
            let req = FocusUserReq()
            req.beenUserId = dataModel.userId
            Session.request(req) { (error, resp) in
                Alert.hideLoading()
                guard error == nil else {
                    mm_showToast(error!.localizedDescription)
                    return
                }
                dataModel.isAttention = true
                cell.isFocus = true
                mm_showToast("關注成功!", type: .succeed)
            }
            return
        }
        
        Alert.showCommonAlert(parentView: self.view, contentText: "取消關注後,您將無法及時收到他的動態",
                              cancelText: "再看看",
                              confirmText: "取消關注",
                              onConfirmTap: {
                                Alert.showLoading(parentView: self.view)
                                let req = CancelFocusUserReq()
                                req.beenUserId = dataModel.userId
                                Session.request(req) { (error, resp) in
                                    Alert.hideLoading()
                                    guard error == nil else {
                                        mm_showToast(error!.localizedDescription)
                                        return
                                    }
                                    dataModel.isAttention = false
                                    cell.isFocus = false
                                    mm_showToast("取消成功!", type: .succeed)
                                }
                              }, onCancelTap: nil)
        
    }
}

