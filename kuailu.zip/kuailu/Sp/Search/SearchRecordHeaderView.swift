//
//  SearchRecordHeaderView.swift
//  Sp
//
//  Created by mac on 2020/3/28.
//  Copyright © 2020 mac. All rights reserved.
//


protocol SearchRecordHeaderViewDelegate: NSObjectProtocol {
    func onDeleteIconTap()
}

class SearchRecordHeaderView: UICollectionReusableView {
    
    private lazy var titleLabel: UILabel = {
        let label = UILabel()
        label.text = "您已擼過"
        label.textColor = .white
        label.font = UIFont.pingFangRegular(16)
        return label
    }()
    
    private lazy var deleteIcon: UIImageView = {
        let imageView = UIImageView(image: UIImage(named: "delete_icon"))
        let tap = UITapGestureRecognizer(target: self, action: #selector(onDeleteIconTap))
        imageView.addGestureRecognizer(tap)
        imageView.isUserInteractionEnabled = true
        return imageView
    }()
    
    weak var delegate: SearchRecordHeaderViewDelegate?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        addSubview(titleLabel)
        addSubview(deleteIcon)
        
        titleLabel.snp.makeConstraints { (make) in
            make.centerY.left.equalToSuperview()
        }
        
        deleteIcon.snp.makeConstraints { (make) in
            make.centerY.right.equalToSuperview()
            make.size.equalTo(24)
        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    @objc private func onDeleteIconTap() {
        delegate?.onDeleteIconTap()
    }
}

