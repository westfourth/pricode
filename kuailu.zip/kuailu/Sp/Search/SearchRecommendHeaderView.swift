//
//  SearchRecommendHeaderView.swift
//  Sp
//
//  Created by mac on 2020/3/28.
//  Copyright © 2020 mac. All rights reserved.
//


class SearchRecommendHeaderView: UICollectionReusableView {
    
    private lazy var titleLabel: UILabel = {
        let label = UILabel()
        label.text = "別人擼過"
        label.textColor = .white
        label.font = UIFont.pingFangRegular(16)
        return label
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        addSubview(titleLabel)
        titleLabel.snp.makeConstraints { (make) in
            make.centerY.left.equalToSuperview()
        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
