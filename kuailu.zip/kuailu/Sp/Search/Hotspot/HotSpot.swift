//
//  HotSpot.swift
//  Sp
//
//  Created by mac on 2020/4/4.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class HotSpot: NSObject {
    
    var items:[HotDailyItem] = [HotDailyItem]()
    
    static let share = HotSpot()
    
    //  需要token
    func loadItems() {
        Session.request(HotDailyReq()) { [weak self] (error, resp) in
            guard let `self` = self else { return }
            guard error == nil, let items = resp as? [HotDailyItem] else {
                return
            }
            self.items = items
        }
    }
}
