//
//  HotspotVC.swift
//  Sp
//
//  Created by mac on 2020/4/1.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class HotspotVC: UIViewController {
    
    private var listData: [HotDailyItem] = []
    
    private var videos:[VideoItem] = [VideoItem]()
    
    private let posterRatio: CGFloat = 360 / 247
    
    private lazy var poster: UIImageView = {
        let imgView = UIImageView(image: Sensitive.hotspot)
        return imgView
    }()
    
    private lazy var tableView: UITableView = {
        let tableView = UITableView(frame: CGRect.zero, style: .grouped)
        tableView.delegate = self
        tableView.dataSource = self
        tableView.backgroundColor = .none
        tableView.estimatedRowHeight = 0
        tableView.estimatedSectionFooterHeight = 0
        tableView.estimatedSectionHeaderHeight = 0
        tableView.separatorStyle = .none
        tableView.rowHeight = 46
        tableView.register(HotspotCell.self, forCellReuseIdentifier: "HotspotCell")
        return tableView
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = RGB(0x161A27)
        renderNavigator()
        renderView()
        fetchListData()
    }
    
    private func renderNavigator() {
        navigationController?.navigationBar.setBackgroundImage(UIImage(), for: .default)
        navigationController?.navigationBar.shadowImage = UIImage()
        navigationController?.navigationBar.isTranslucent = true
    }
    
    private func renderView() {
        view.addSubview(tableView)
        
        tableView.snp.makeConstraints { (make) in
            make.top.equalToSuperview().offset(IS_IPHONEX ? -88 : -64)
            make.left.right.bottom.equalToSuperview()
        }
    }
    
    private func fetchListData() {
        self.listData = HotSpot.share.items
        self.videos = self.listData.map({ (item) -> VideoItem in
            return VideoItem()
        })
        let ids = self.listData.map { (item) -> Int in
            if item.hotType == .video {
                return item.hotUnionId
            }
            return -1000
        }
        let videoIds = ids.filter { (id) -> Bool in
            return id != -1000
        }
        
        let req = FetchVideoByIdsReq()
        req.videoIds = videoIds
        Session.request(req) { (error, resp) in
            guard error == nil else {
                return
            }
            if resp is [VideoItem]  {
                let items = resp as! [VideoItem]
                for i in 0..<ids.count {
                    let id = ids[i]
                    if id == -1000 {
                        self.videos[i] = VideoItem()
                    } else {
                        for v in items {
                            if v.videoId == id {
                                self.videos[i] = v
                            }
                        }
                    }
                }
            }
        }
    }
}

extension HotspotVC: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return listData.count
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return view.width / posterRatio
    }
    
    //设置分组尾的高度
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return .leastNonzeroMagnitude
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        return poster
    }
    
    //将分组尾设置为一个空的View
    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        return nil
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "HotspotCell", for: indexPath) as! HotspotCell
        let row = indexPath.row
        cell.indexLabel.text = "\(row + 1)."
        cell.indexLabel.textColor = row == 0 ? RGB(0xFF9C2C) : row == 1 ? RGB(0xF43D3A) : row == 2 ?  RGB(0x0075FA) : .white
        cell.dataModel = listData[row]
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let currentData = listData[indexPath.row]
        switch currentData.hotType {
        case .video:
            guard !self.videos.isEmpty else { return }
            let items = self.videos.filter { $0.videoId != 0 }
            SearchResultVC.navigationToVideoPlayListVC(indexPath: IndexPath(item: items.firstIndex(of: self.videos[indexPath.row]) ?? 0, section: 0), VideoList: items)
        case .activity:
            let webVC = WebVC()
            webVC.webviewUrl = currentData.jumpUrl
            navigationController?.pushViewController(webVC, animated: true)
        case .user:
            let vc = UsersDynamicVC()
            vc.userId = currentData.hotUnionId
            vc.initPageType = .smallVideo
            navigationController?.pushViewController(vc, animated: true)
        case .timeline:
            break
        }
    }
}
