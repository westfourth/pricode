//
//  HotspotCell.swift
//  Sp
//
//  Created by mac on 2020/4/1.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class HotspotCell: UITableViewCell {
    
    private static let typeImg: UIImage? = {
        return UIImage(named: "hotspot_type_icon")
    }()
    
    private static let hotImg: UIImage? = {
        return UIImage(named: "hotspot_hot_icon")
    }()
    
    private static let typeNameList: [String] = {
        return ["視頻", "人物", "活動", "動態"]
    }()
    
    lazy var indexLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.pingFangHeavy(16)
        label.textColor = .white
        return label
    }()
    
    private lazy var typeLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.pingFangRegular(12)
        label.textColor = .white
        label.textAlignment = .center
        return label
    }()
    
    private lazy var typeImgView: UIImageView = {
        return UIImageView(image: HotspotCell.typeImg)
    }()
    
    private lazy var contentLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.pingFangRegular(14)
        label.textColor = .white
        label.numberOfLines = 1
        return label
    }()
    
    private lazy var hotspotIcon: UIImageView = {
        let imgView = UIImageView(image: HotspotCell.hotImg)
        return imgView
    }()
    
    private lazy var hotNumberLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.pingFangMedium(12)
        label.textColor = RGB(0x9E9E9E)
        return label
    }()
    
    var dataModel: HotDailyItem? {
        didSet{
            guard let item = dataModel else { return }
            typeLabel.text = HotspotCell.typeNameList[item.hotType.rawValue - 1]
            hotNumberLabel.text = num2TenThousandStrFormat(item.hotValue)
            contentLabel.text = item.hotName
            contentLabel.snp.makeConstraints { (make) in
                make.centerY.equalToSuperview()
                make.left.equalToSuperview().offset(69)
                make.right.equalToSuperview().inset(hotNumberLabel.text!.getStringSize(rectSize: .zero, font: UIFont.pingFangMedium(12)).width + 12 + 12 + 5)
                
            }
        }
    }
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        backgroundColor = .none
        selectionStyle = .none
        rendView()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func rendView() {
        addSubview(indexLabel)
        addSubview(typeImgView)
        addSubview(typeLabel)
        addSubview(contentLabel)
        addSubview(hotspotIcon)
        addSubview(hotNumberLabel)
        
        indexLabel.snp.makeConstraints { (make) in
            make.centerY.equalToSuperview()
            make.left.equalToSuperview().inset(12)
        }
        
        typeImgView.snp.makeConstraints { (make) in
            make.centerY.equalToSuperview()
            make.left.equalTo(indexLabel.snp.right)
            make.width.equalTo(35)
            make.height.equalTo(16)
        }
        
        typeLabel.snp.makeConstraints { (make) in
            make.centerY.equalTo(typeImgView).offset(0.5)
            make.centerX.equalTo(typeImgView).offset(2.5)
        }
        
        hotNumberLabel.snp.makeConstraints { (make) in
            make.right.equalToSuperview().inset(12)
            make.centerY.equalToSuperview().offset(2)
        }
        
        hotspotIcon.snp.makeConstraints { (make) in
            make.centerY.equalToSuperview()
            make.right.equalTo(hotNumberLabel.snp.left).offset(-2)
        }
    }
}
