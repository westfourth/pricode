//
//  SearchResultCell.swift
//  Sp
//
//  Created by mac on 2020/2/25.
//  Copyright © 2020 mac. All rights reserved.
//


class SearchResultVideoCell: UICollectionViewCell {
    
    static let defaultImg: UIImage? = {
        return Sensitive.default_bg
    }()
    
    static let avatarImg: UIImage? = {
        return Sensitive.avatar
    }()
    
    static let animationOption: KingfisherOptionsInfo = {
        return [.transition(.fade(0.25))]
    }()
    
    static let HDImg: UIImage? = {
        return UIImage(named: "video_HD_icon")
    }()
    
    static let vipDefaultImg: UIImage? = {
        return UIImage(named: "video_vip_icon")
    }()
    
    static let payDefaultImg: UIImage? = {
        return UIImage(named: "video_pay_icon")
    }()
    
    private static let gradientColors: [CGColor] = {
        return [RGB(36,3,33).withAlphaComponent(0).cgColor, RGB(36,3,33).withAlphaComponent(0.66).cgColor]
    }()
    
    private static let gradientLocations: [NSNumber] = {
        return [0.0, 1.0]
    }()
    
    private static let collectionIconImg: UIImage? = {
        return UIImage(named: "ic_b_like_2")
    }()
    
    static let lockIconImg: UIImage? = {
        return UIImage(named: "ic_lock")
    }()
    
    static let v6IconImg: UIImage? = {
        return UIImage(named: "v6_icon")
    }()
    
    private lazy var poster: UIImageView = {
        let imgView = UIImageView()
        imgView.contentMode = .scaleAspectFill
        imgView.layer.masksToBounds = true
        imgView.layer.cornerRadius = 6
        imgView.addSubview(HDImgView)
        imgView.addSubview(vipOrPayImgView)
        imgView.addSubview(coinNumLabel)
        
        HDImgView.snp.makeConstraints { (make) in
            make.left.top.equalToSuperview()
            make.width.equalTo(28)
            make.height.equalTo(14)
        }
        
        vipOrPayImgView.snp.makeConstraints { (make) in
            make.top.right.equalToSuperview()
            make.width.equalTo(36)
            make.height.equalTo(18)
        }
        
        coinNumLabel.snp.makeConstraints { (make) in
            make.left.equalTo(vipOrPayImgView.snp.left).offset(16)
            make.centerY.right.equalTo(vipOrPayImgView)
        }
        
        return imgView
    }()
    
    private lazy var HDImgView: UIImageView = {
        return UIImageView(image: SearchResultVideoCell.HDImg)
    }()
    
    private lazy var vipOrPayImgView: UIImageView = {
        let imgView = UIImageView()
        imgView.contentMode = .scaleAspectFit
        return imgView
    }()
    
    private lazy var coinNumLabel: UILabel = {
        let label = UILabel()
        label.textColor = .white
        label.font = UIFont.pingFangRegular(10)
        return label
    }()
    
    private lazy var avatar: UIImageView = {
        let imgView = UIImageView()
        imgView.backgroundColor = RGB(0x999999)
        imgView.layer.cornerRadius = 9
        imgView.clipsToBounds = true
        return imgView
    }()
    
    private lazy var nicknameLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.pingFangRegular(10)
        label.textColor = .white
        label.numberOfLines = 1
        return label
    }()
    
    private lazy var titleLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.pingFangMedium(11)
        label.textColor = .white
        label.textAlignment = .left
        label.numberOfLines = 1
        return label
    }()
    
    private lazy var collectionIconImgView: UIImageView = {
        let imgView = UIImageView(image: SearchResultVideoCell.collectionIconImg)
        return imgView
    }()
    
    private lazy var collectionNumberLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.pingFangRegular(10)
        label.textColor = .white
        return label
    }()
    
    private lazy var maskLayerView: UIView = {
        let maskView = UIView()
        let gradientLayer = CAGradientLayer()
        gradientLayer.colors = SearchResultVideoCell.gradientColors
        gradientLayer.locations = SearchResultVideoCell.gradientLocations
        gradientLayer.frame = CGRect(x: 0, y: 0, width: self.width, height: 52)
        maskView.layer.insertSublayer(gradientLayer, at: 0)
        maskView.addSubview(titleLabel)
        maskView.addSubview(avatar)
        maskView.addSubview(collectionNumberLabel)
        maskView.addSubview(collectionIconImgView)
        maskView.addSubview(nicknameLabel)
        
        titleLabel.snp.makeConstraints { (make) in
            make.top.left.right.equalToSuperview().inset(6)
            make.height.equalTo(16)
        }
        avatar.snp.makeConstraints { (make) in
            make.size.equalTo(18)
            make.left.bottom.equalToSuperview().inset(6)
        }
        collectionNumberLabel.snp.makeConstraints { (make) in
            make.right.equalToSuperview().inset(6)
            make.centerY.equalTo(avatar)
        }
        collectionIconImgView.snp.makeConstraints { (make) in
            make.width.equalTo(12)
            make.height.equalTo(10)
            make.right.equalTo(collectionNumberLabel.snp.left).offset(-3)
            make.centerY.equalTo(collectionNumberLabel)
        }
        nicknameLabel.snp.makeConstraints { (make) in
            make.left.equalTo(avatar.snp.right).offset(3)
            make.right.equalToSuperview().inset(30)
            make.centerY.equalTo(avatar)
        }
        
        return maskView
    }()
    
    private lazy var v6ImgView: UIImageView = {
        let imgView = UIImageView(image: SearchResultVideoCell.v6IconImg)
        imgView.isHidden = true
        return imgView
    }()
    
    private lazy var lockImgView: UIImageView = {
        let imgView = UIImageView(image: SearchResultVideoCell.lockIconImg)
        return imgView
    }()
    
    private lazy var lockLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.pingFangRegular(12)
        label.textColor = .white
        label.text = "V6專享視頻"
        return label
    }()
    
    private lazy var lockMaskView: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor.black.withAlphaComponent(0.3)
        view.addSubview(lockImgView)
        view.addSubview(lockLabel)
        view.isHidden = true
        
        lockImgView.snp.makeConstraints { (make) in
            make.centerX.equalToSuperview()
            make.centerY.equalToSuperview().offset(-14)
            make.width.equalTo(40)
            make.height.equalTo(44)
        }
        
        lockLabel.snp.makeConstraints { (make) in
            make.centerX.equalToSuperview()
            make.top.equalTo(lockImgView.snp.bottom).offset(10)
        }
        return view
    }()
    
    var dataModel: VideoItem? {
        didSet {
            guard let item = dataModel else { return }
            poster.kf.setImage(with: item.coverImg?.column2, placeholder: SearchResultVideoCell.defaultImg, options: SearchResultVideoCell.animationOption)
            avatar.kf.setImage(with: item.logo?.column3, placeholder: SearchResultVideoCell.avatarImg, options: SearchResultVideoCell.animationOption)
            collectionNumberLabel.text = item.fakeLikes > 0 ? num2TenThousandStrFormat(item.fakeLikes) : "0"
            nicknameLabel.text = item.nickName
            titleLabel.text = item.title
            vipOrPayImgView.image = item.videoPayMark == .vip ? SearchResultVideoCell.vipDefaultImg : item.videoPayMark == .pay ? SearchResultVideoCell.payDefaultImg : nil
            HDImgView.isHidden = !item.hd
            coinNumLabel.isHidden = item.videoPayMark != .pay
            coinNumLabel.text = "\(item.price)"
            lockMaskView.isHidden = !(item.isSpecial && NetDefaults.userInfo?.specialAuth != true)
            v6ImgView.isHidden = !item.isSpecial
        }
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        renderView()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func renderView() {
        addSubview(poster)
        addSubview(maskLayerView)
        addSubview(lockMaskView)
        addSubview(v6ImgView)
        
        poster.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
        
        maskLayerView.snp.makeConstraints { (make) in
            make.left.right.bottom.equalToSuperview()
            make.height.equalTo(52)
        }
        
        lockMaskView.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
        
        v6ImgView.snp.makeConstraints { (make) in
            make.top.equalToSuperview().inset(8)
            make.left.equalToSuperview()
            make.width.equalTo(42)
            make.height.equalTo(14)
        }
    }
}
