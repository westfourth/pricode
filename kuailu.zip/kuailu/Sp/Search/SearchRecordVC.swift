//
//  SearchRecordView.swift
//  Sp
//
//  Created by mac on 2020/2/25.
//  Copyright © 2020 mac. All rights reserved.
//

protocol SearchRecordViewDelegate: NSObjectProtocol {
    
    func deleteAllRecordTags()
    
    func searchTagByTags(keyword: String)
    
}

class SearchRecordVC: UIViewController {
    
    weak var delegate: SearchRecordViewDelegate?
    
    private let itemWidth: CGFloat = (UIScreen.main.bounds.size.width - 12 * 2 - 6 * 2) / 3
    
    private let historyItemHorizontalPadding: CGFloat = 12 * 2
    
    private lazy var recommendItemSize: CGSize = {
        let ratio:CGFloat = 90 / 110
        return CGSize(width: itemWidth, height: itemWidth * ratio)
    }()
    
    var historyData: [String] = [] {
        didSet {
            collectionView.state = .normal
            collectionView.reloadData()
        }
    }
    
    var recommendList: [HotTagResp] = [] {
        didSet {
            collectionView.state = .normal
            collectionView.reloadData()
        }
    }
    
    private lazy var sectionHeaderHeight: CGSize = {
        return CGSize(width: view.width, height: 40)
    }()
    
    private lazy var sectionEdgeInsets: UIEdgeInsets = {
        return UIEdgeInsets(top: 0, left: 0, bottom: 20, right: 0)
    }()
    
    private lazy var collectionView: UICollectionView = {
        let layout = UICollectionViewFlowLayout()
        layout.minimumLineSpacing = 14
        layout.minimumInteritemSpacing = 6
        let cv = UICollectionView(frame: .zero, collectionViewLayout: layout)
        cv.register(SearchRecordCell.self, forCellWithReuseIdentifier: "SearchRecordCell")
        cv.register(SearchRecordHeaderView.self, forSupplementaryViewOfKind: UICollectionView.elementKindSectionHeader, withReuseIdentifier: "SearchRecordHeaderView")
        cv.register(SearchRecommendHeaderView.self, forSupplementaryViewOfKind: UICollectionView.elementKindSectionHeader, withReuseIdentifier: "SearchRecommendHeaderView")
        cv.backgroundColor = .none
        cv.state = .loading
        cv.delegate = self
        cv.dataSource = self
        return cv
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.addSubview(collectionView)
        collectionView.snp.makeConstraints { (make) in
            make.top.bottom.equalToSuperview()
            make.left.right.equalToSuperview().inset(12)
        }
    }
    
}

extension SearchRecordVC: SearchRecordHeaderViewDelegate {
    
    func onDeleteIconTap() {
        delegate?.deleteAllRecordTags()
    }
    
}

extension SearchRecordVC: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 2
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return section == 0 ? historyData.count : recommendList.count
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        return section == 0 ? (historyData.isEmpty ? .zero : sectionEdgeInsets) : (recommendList.isEmpty ? .zero : sectionEdgeInsets)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, referenceSizeForHeaderInSection section: Int) -> CGSize {
        return section == 0 ? (historyData.isEmpty ? .zero : sectionHeaderHeight) : (recommendList.isEmpty ? .zero : sectionHeaderHeight)
    }
    
    func collectionView(_ collectionView: UICollectionView, viewForSupplementaryElementOfKind kind: String, at indexPath: IndexPath) -> UICollectionReusableView {
        guard kind == UICollectionView.elementKindSectionHeader else {
            return UICollectionReusableView()
        }
        if indexPath.section == 0, let header = collectionView.dequeueReusableSupplementaryView(ofKind: kind, withReuseIdentifier: "SearchRecordHeaderView", for: indexPath) as? SearchRecordHeaderView {
            header.delegate = self
            header.isHidden = historyData.isEmpty
            return header
        } else if indexPath.section == 1, let header = collectionView.dequeueReusableSupplementaryView(ofKind: kind, withReuseIdentifier: "SearchRecommendHeaderView", for: indexPath) as? SearchRecommendHeaderView {
            header.isHidden = recommendList.isEmpty
            return header
        }
        return UICollectionReusableView()
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let itemHeight = "#\(indexPath.section == 0 ? historyData[indexPath.row] : recommendList[indexPath.row].hotTitle)".getStringSize(rectSize: .zero, font: UIFont.pingFangRegular(13)).width + historyItemHorizontalPadding
        return CGSize(width: itemHeight, height: 24)
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "SearchRecordCell", for: indexPath) as! SearchRecordCell
        let row = indexPath.row
        cell.titleLabel.text = "#\(indexPath.section == 0 ? historyData[row] : recommendList[row].hotTitle)"
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let row = indexPath.row
        delegate?.searchTagByTags(keyword: indexPath.section == 0 ? historyData[row] : recommendList[row].hotTitle)
    }
}

