//
//  SearchRecordCell.swift
//  Sp
//
//  Created by mac on 2020/3/3.
//  Copyright © 2020 mac. All rights reserved.
//

class SearchRecordCell: UICollectionViewCell {
    
    lazy var titleLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.pingFangRegular(13)
        label.textColor = .white
        label.layer.cornerRadius = 2
        label.layer.masksToBounds = true
        label.backgroundColor = RGB(0x313131)
        label.textAlignment = .center
        return label
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        addSubview(titleLabel)
        titleLabel.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
