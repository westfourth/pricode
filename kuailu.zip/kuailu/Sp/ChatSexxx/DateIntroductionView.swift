//
//  DateIntroductionView.swift
//  Sp
//
//  Created by mac on 2020/8/4.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class DateIntroductionView: UIView {
    
    @IBAction func dismiss(_ sender: Any) {
        UIView.animate(withDuration: 0.5, animations: {
            self.alpha = 0
        }) { (flag) in
            self.alpha = 1.0
            self.removeFromSuperview()
        }
    }
}
