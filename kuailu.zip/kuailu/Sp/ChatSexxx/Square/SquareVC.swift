//
//  SquareVC.swift
//  Sp
//
//  Created by mac on 2020/6/16.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

public enum SquareType: Int {
    case common = 1
    case hot = 2
    case unlocked = 3
}

class SquareVC: UIViewController {
    
    var items:[SquareItem] = [SquareItem]()
    
    /// 默认是普通
    var type:SquareType = .common
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .clear
        if type != .unlocked {
            view.addSubview(locationView)
            locationView.snp.makeConstraints { (make) in
                make.left.right.top.equalTo(0)
                make.height.equalTo(39)
            }
        }
        view.addSubview(tableView)
        tableView.snp.makeConstraints { (make) in
            make.left.equalTo(12)
            make.right.equalTo(-12)
            make.top.equalTo(type == .unlocked ? 0:39)
            make.bottom.equalTo(0)
        }
        loadData(true)
        NotificationCenter.default.addObserver(self, selector: #selector(changeCity(_:)), name: .location, object: nil)
    }
    
    @objc func changeCity(_ noti:Notification) {
        loadData(true)
    }
    
    deinit {
        NotificationCenter.default.removeObserver(self)
    }
    
    lazy var tableView : UITableView = {
        let tableView = UITableView.init(frame: CGRect.zero, style: .grouped)
        tableView.delegate = self
        tableView.dataSource = self
        tableView.clipsToBounds = true
        tableView.backgroundColor = .clear
        tableView.separatorStyle = UITableViewCell.SeparatorStyle.none
        tableView.tableFooterView = UIView()
        tableView.showsVerticalScrollIndicator = false
        tableView.register(UINib(nibName: "SquareCell", bundle: Bundle.main), forCellReuseIdentifier: "SquareCell")
        //        tableView.state = .loading
        tableView.mj_header = getCommonMJHeader(refreshingTarget: self, headerRefreshCallback: #selector(onRefresh))
        tableView.mj_footer = getCommonMJFooter(refreshingTarget: self, footerRefreshCallback: #selector(onLoadMore))
        return tableView
    }()
    
    lazy var locationView:LocationView = {
        let v = Bundle.main.loadNibNamed("LocationView", owner: nil, options: [:])?.first as! LocationView
        v.delegate = self
        return v
    }()
    
    @objc func onRefresh() {
        loadData(true)
    }
    
    @objc func onLoadMore() {
        loadData(false)
    }
    
    var isRequesting = false
    
    var responseCity:String?
    
    func loadData(_ refresh:Bool) {
        
        if isRequesting {return}
        isRequesting = true
        
        let callback:(Error?,Any?)->Void = {(e,resp) in
            Alert.hideLoading()
            self.isRequesting = false
            self.tableView.mj_header?.endRefreshing()
            self.tableView.mj_footer?.endRefreshing()
            guard let r = resp as? SquareResp, let array = r.list as? [SquareItem], !array.isEmpty else {
                if refresh {
                    if self.items.isEmpty {
                        self.tableView.state = .empty
                    }
                } else {
                    self.tableView.state = self.items.isEmpty ? .empty:.normal
                    if !self.items.isEmpty {
                        self.tableView.mj_footer?.endRefreshingWithNoMoreData()
                    }
                }
                return
            }
            Defaults.squareCurrentCity = r.cityName
            if let cityName = Defaults.squareCurrentCity  {
                if self.items.isEmpty && !cityName.elementsEqual(r.cityName){
                    mm_showToast("當前城市無樓鳳信息，看一下\(r.cityName)的小姐姐吧!")
                }
            }
            self.locationView.location.text = "\(r.cityName)"
            if refresh {
                self.items = array
            } else {
                self.items.append(contentsOf: array)
            }
            self.tableView.state = .normal
            self.tableView.reloadData()
            if array.count < 30 && !self.items.isEmpty {
                self.tableView.mj_footer?.endRefreshingWithNoMoreData()
            }
        }
        
        if type == .common {
            let req = SquareListReq()
            if let name = Defaults.squareCurrentCity {
                req.cityName = name
            } else {
                req.cityName = ""
            }
            req.lastId = refresh ? 0 : items.isEmpty ? 0:items.last?.userId ?? 0
            Alert.showLoading(parentView: self.view)
            Session.request(req, callback: callback)
        } else if type == .hot {
            // 热点
            let req = SquareHotListReq()
            if let name = Defaults.squareCurrentCity {
                req.cityName = name
            } else {
                req.cityName = ""
            }
            req.lastId = refresh ? 0 : items.isEmpty ? 0:items.last?.userId ?? 0
            Alert.showLoading(parentView: self.view)
            Session.request(req, callback: callback)
        } else if type == .unlocked {
            // 已解锁
            let req = UnLockSquareListReq()
            req.lastId = refresh ? 0 : items.isEmpty ? 0:items.last?.userId ?? 0
            Alert.showLoading(parentView: self.view)
            Session.request(req, callback: callback)
        }
    }
    
    lazy var dateView:DateIntroductionView = {
        let v = Bundle.main.loadNibNamed("DateIntroductionView", owner: nil, options: [:])?.first as! DateIntroductionView
        return v
    }()
    
}

extension SquareVC:LocationViewDelegate {
    func tapHowToDate(locationView: LocationView) {
        UIApplication.shared.keyWindow?.addSubview(dateView)
        dateView.frame = UIScreen.main.bounds
    }
    
    func tapLocation(locationView: LocationView) {
        let vc = ChooseCityVC()
        vc.chosenCityClosure = { [weak self] city in
             Defaults.squareCurrentCity = city.name
            self?.locationView.location.text = "\(city.name)"
            self?.loadData(true)
        }
        vc.hidesBottomBarWhenPushed = true
        navigationController?.pushViewController(vc, animated: true)
    }
}

// MARK: -UITableViewDataSource && Delegate
extension SquareVC:UITableViewDataSource,UITableViewDelegate {
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "SquareCell") as! SquareCell
        cell.item = items[indexPath.section]
        return cell
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return items.count
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let model = items[indexPath.section]
        let vc = UsersDynamicVC()
        vc.userId = model.userId
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return  190
    }
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return 0
    }
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 0
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        return nil
    }
    
    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        return nil
    }
}

