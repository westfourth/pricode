//
//  TagCell.swift
//  Sp
//
//  Created by mac on 2020/6/17.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class TagCell: UICollectionViewCell {
    @IBOutlet weak var name: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    static func width(_ name:String)->CGFloat {
        return 20 + name.getStringSize(rectSize: CGSize(width: Int.max, height: 16), font: UIFont.systemFont(ofSize: 10, weight: .regular)).width
    }
}
