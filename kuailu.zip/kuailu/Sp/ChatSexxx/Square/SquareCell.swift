//
//  SquareCell.swift
//  Sp
//
//  Created by mac on 2020/6/17.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class SquareCell: UITableViewCell {

    @IBOutlet weak var avatar: UIImageView!
    @IBOutlet weak var name: UILabel!
    @IBOutlet weak var location: UILabel!
    @IBOutlet weak var collectionView: UICollectionView!
    @IBOutlet weak var watchTime: UILabel!
    
    @IBOutlet weak var gender: UIImageView!
    
    @IBOutlet weak var price: UILabel!
    @IBOutlet weak var age: UILabel!
    
    @IBOutlet weak var official_icon: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        collectionView.register(UINib(nibName: "TagCell", bundle: Bundle.main), forCellWithReuseIdentifier: "TagCell")
        selectionStyle = .none
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    var item:SquareItem? {
        didSet {
            guard let item = item else {
                return
            }
            avatar.kf.setImage(with: item.squareImg,placeholder:Sensitive.default_bg,options: [.transition(.fade(0.25))])
            name.text = item.nickName
            location.text = "\(item.provinceName)·\(item.cityName)"
            watchTime.text = "\(num2TenThousandStrFormat(item.watchNum))人約她"
            let name = item.gender == .male ? "ic_male":"ic_female"
            gender.image = UIImage(named: name)
            price.text = item.price == "" ? "保密":item.price
            if let birthday = item.birthday {
                let timeI = Date().timeIntervalSince(birthday)
                let age = Int(timeI / (3600*24*365))
                self.age.text = "\(age)"
            } else {
                self.age.text = "保密"
            }
            official_icon.isHidden = !item.isOfficial
            collectionView.reloadData()
        }
    }
}

//_______________________________________________________________________________________________________________
// MARK: - UICollectionViewDataSource&Delegate
extension SquareCell:UICollectionViewDataSource,UICollectionViewDelegate,UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return item?.userTags.count ?? 0
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "TagCell", for: indexPath) as! TagCell
        cell.name.text = item?.userTags[indexPath.row] ?? ""
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: TagCell.width(item?.userTags[indexPath.row] ?? ""), height: 16)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 6
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 6
    }
    
}

