//
//  ChatTopCell.swift
//  Sp
//
//  Created by mac on 2020/6/16.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class ChatTopCell: UICollectionViewCell {

    @IBOutlet weak var name: UILabel!
    
     var tap: (() -> ())?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
//        layer.addSublayer(g)
        let tap = UITapGestureRecognizer(target: self, action:#selector(self.tapAction))
        name.addGestureRecognizer(tap)
        name.textColor = RGB(0xffC9C9C9)
    }
    
    @objc func tapAction() {
        tap?()
    }

    lazy var g :CAGradientLayer = {
       let g = CAGradientLayer()
        g.startPoint = CGPoint(x: 0, y: 0)
        g.endPoint = CGPoint(x: 1, y: 0)
        g.colors = [RGB(0xffE62865).cgColor,RGB(0xff2D35FD).cgColor]
        return g
    }()
    
    override func layoutSubviews() {
        super.layoutSubviews()
//        g.frame = name.frame
//        g.mask = name.layer
    }
    
    var current:Bool = false {
        didSet {
            if current {
//                g.colors = [RGB(0xffE62865).cgColor,RGB(0xff2D35FD).cgColor]
                name.textColor = .white
                name.font = UIFont.systemFont(ofSize: 22, weight: .medium)
            } else {
//                g.colors = [UIColor.white.cgColor,UIColor.white.cgColor]
                name.textColor = RGB(0xffC9C9C9)
                name.font = UIFont.systemFont(ofSize: 18, weight: .medium)
            }
        }
    }
}
