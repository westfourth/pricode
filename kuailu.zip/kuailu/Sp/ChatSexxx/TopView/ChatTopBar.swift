//
//  ChatTopBar.swift
//  Sp
//
//  Created by mac on 2020/6/16.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

@objc protocol ChatTopBarDelegate {
    ///点击
    func chatTopBar(didSelect index:Int)
    func chatTopBarAvatarAction()
}

class ChatTopBar: UIView {
    @IBOutlet weak var collectionView: UICollectionView!
    @IBOutlet weak var layout: UICollectionViewFlowLayout!
    
    @IBOutlet weak var avatar: UIImageView!
    
    weak var delegate: ChatTopBarDelegate?
    
    let names = ["官推","會所","樓鳳","已解鎖"]
    
    override  func awakeFromNib() {
        super.awakeFromNib()
        collectionView.register(UINib(nibName: "ChatTopCell", bundle: Bundle.main), forCellWithReuseIdentifier: "ChatTopCell")
        if let user = NetDefaults.userInfo {
            avatar.kf.setImage(with: user.logo,placeholder:Sensitive.avatar,options: [.transition(.fade(0.25))])
        }
//        addSubview(messageView)
    }
    
    lazy var messageView:MessageView = {
        let v = Bundle.main.loadNibNamed("MessageView", owner: nil, options: [:])?.first as! MessageView
//        v.isHidden = true
        return v
    }()
    
//    override func layoutSubviews() {
//        super.layoutSubviews()
//        messageView.snp.makeConstraints { (make) in
//            make.size.equalTo(CGSize(width: 38, height: 25))
//            make.right.equalTo(avatar.snp.left).offset(-15)
//            make.centerY.equalTo(avatar)
//        }
//    }
    var currentIndex:Int = 0 {
        didSet {
            collectionView.reloadData()
        }
    }
    
    @IBAction func avatarAction(_ sender: Any) {
        delegate?.chatTopBarAvatarAction()
    }
    
}

//_______________________________________________________________________________________________________________
// MARK: - UICollectionViewDataSource&Delegate
extension ChatTopBar:UICollectionViewDataSource,UICollectionViewDelegate,UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return names.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "ChatTopCell", for: indexPath) as! ChatTopCell
        cell.name.text = names[indexPath.row]
        cell.current = currentIndex == indexPath.row
        cell.tap = { [weak self] in
            if self?.currentIndex != indexPath.row {
                self?.currentIndex = indexPath.row
                collectionView.reloadData()
                self?.delegate?.chatTopBar(didSelect: indexPath.row)
            }
        }
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        if currentIndex != indexPath.row {
            currentIndex = indexPath.row
            delegate?.chatTopBar(didSelect: currentIndex)
            collectionView.reloadData()
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let name = names[indexPath.row]
        return CGSize(width: name.getStringSize(rectSize: CGSize(width: 120, height: 54), font: UIFont.systemFont(ofSize: 24, weight: .medium)).width + 12, height: 54) 
    }
    
}

