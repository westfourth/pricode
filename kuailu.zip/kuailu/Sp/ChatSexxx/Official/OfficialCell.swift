//
//  OfficialCell.swift
//  Sp
//
//  Created by mac on 2020/6/16.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class OfficialCell: UITableViewCell {
    @IBOutlet weak var gradientView: UIView!
    @IBOutlet weak var cover: UIImageView!
    @IBOutlet weak var name: UILabel!
    @IBOutlet weak var officialIcon: UIImageView!
    @IBOutlet weak var sign: UILabel!
    @IBOutlet weak var location: UILabel!
    
    @IBOutlet weak var gender: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        selectionStyle = .none
        object_setClass(gradientView.layer, CAGradientLayer.self)
        let i = gradientView.layer as! CAGradientLayer
        i.colors = [RGB(0xff000000).withAlphaComponent(0.04) .cgColor,RGB(0xff000000).withAlphaComponent(0.53).cgColor]
        i.startPoint = CGPoint(x: 0, y: 0)
        i.endPoint = CGPoint(x: 0, y: 1)
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    var item:OfficialItem? {
        didSet {
            guard let item = item else {
                return
            }
            cover.kf.setImage(with: item.bgImgs?.column1,placeholder:Sensitive.default_bg,options: [.transition(.fade(0.25))])
            name.text = item.nickName
            officialIcon.isHidden = !item.isOfficial
            location.text = "\(item.provinceName)·\(item.cityName)"
            sign.text = item.personSign
            let name = item.gender == .male ? "ic_male":"ic_female"
            gender.image = UIImage(named: name)
        }
    }
    
}
