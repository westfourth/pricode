//
//  OfficialVC.swift
//  Sp
//
//  Created by mac on 2020/6/16.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class OfficialVC: UIViewController {

    var items:[OfficialItem] = [OfficialItem]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .clear
        view.addSubview(locationView)
        locationView.snp.makeConstraints { (make) in
            make.left.right.top.equalTo(0)
            make.height.equalTo(39)
        }
        
        view.addSubview(tableView)
        tableView.snp.makeConstraints { (make) in
            make.left.equalTo(12)
            make.right.equalTo(-12)
            make.top.equalTo(locationView.snp.bottom)
            make.bottom.equalTo(0)
        }
        loadData(true)
        NotificationCenter.default.addObserver(self, selector: #selector(changeCity(_:)), name: .location, object: nil)
    }
    
    @objc func changeCity(_ noti:Notification) {
        loadData(true)
    }
    
    deinit {
        NotificationCenter.default.removeObserver(self)
    }
    
    lazy var tableView : UITableView = {
        let tableView = UITableView.init(frame: CGRect.zero, style: .grouped)
        tableView.delegate = self
        tableView.dataSource = self
        tableView.clipsToBounds = true
        tableView.backgroundColor = .clear
        tableView.separatorStyle = UITableViewCell.SeparatorStyle.none
        tableView.tableFooterView = UIView()
        tableView.register(UINib(nibName: "OfficialCell", bundle: Bundle.main), forCellReuseIdentifier: "OfficialCell")
        tableView.showsVerticalScrollIndicator = false
//        tableView.state = .loading
        tableView.mj_header = getCommonMJHeader(refreshingTarget: self, headerRefreshCallback: #selector(onRefresh))
        tableView.mj_footer = getCommonMJFooter(refreshingTarget: self, footerRefreshCallback: #selector(onLoadMore))
        return tableView
    }()
    
    lazy var locationView:LocationView = {
        let v = Bundle.main.loadNibNamed("LocationView", owner: nil, options: [:])?.first as! LocationView
        v.delegate = self
        return v
    }()
    
    @objc func onRefresh() {
        loadData(true)
    }
    
    
    @objc func onLoadMore() {
        loadData(false)
    }
    
    var isRequesting = false
    
    func loadData(_ refresh:Bool) {
        
        if isRequesting {return}
        isRequesting = true
        let req = OfficialListReq()
        if let cityName = Defaults.officialCurrentCity {
            req.cityName = cityName
        } else {
            req.cityName = ""
        }
        Alert.showLoading(parentView: self.view)
        req.lastId = refresh ? 0 : items.isEmpty ? 0:items.last?.userId ?? 0
        Session.request(req) { (e, resp) in
            Alert.hideLoading()
            self.isRequesting = false
            self.tableView.mj_header?.endRefreshing()
            self.tableView.mj_footer?.endRefreshing()
            guard let r = resp as? OfficialResp, let array = r.list as? [OfficialItem], !array.isEmpty else {
                if refresh {
                    self.tableView.state = .empty
                } else {
                    self.tableView.state = .normal
                    if !self.items.isEmpty {
                        self.tableView.mj_footer?.endRefreshingWithNoMoreData()
                    }
                }
                return
            }
            Defaults.officialCurrentCity = r.cityName
            if self.items.isEmpty && !req.cityName.elementsEqual(r.cityName) && req.cityName != "" {
                mm_showToast("當前城市無樓鳳信息，看一下\(r.cityName)的小姐姐吧!")
            }
            self.locationView.location.text = "\(r.cityName)"
            if refresh {
                self.items = array
            } else {
                self.items.append(contentsOf: array)
            }
            self.tableView.reloadData()
            self.tableView.state = .normal
            if array.count < 30 && !self.items.isEmpty {
                self.tableView.mj_footer?.endRefreshingWithNoMoreData()
            }
        }
    }
    
    lazy var dateView:DateIntroductionView = {
        let v = Bundle.main.loadNibNamed("DateIntroductionView", owner: nil, options: [:])?.first as! DateIntroductionView
        return v
    }()
}

extension OfficialVC:LocationViewDelegate {
    
    func tapHowToDate(locationView: LocationView) {
        UIApplication.shared.keyWindow?.addSubview(dateView)
        dateView.frame = UIScreen.main.bounds
    }
    
    func tapLocation(locationView: LocationView) {
        let vc = ChooseCityVC()
        vc.chosenCityClosure = { [weak self] city in
             Defaults.officialCurrentCity = city.name
            self?.locationView.location.text = "\(city.name)"
            self?.loadData(true)
        }
        vc.hidesBottomBarWhenPushed = true
        navigationController?.pushViewController(vc, animated: true)
    }
}

// MARK: -UITableViewDataSource && Delegate
extension OfficialVC:UITableViewDataSource,UITableViewDelegate {
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "OfficialCell") as! OfficialCell
        cell.item  = items[indexPath.section]
        return cell
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return items.count
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let model = items[indexPath.section]
        let vc = UsersDynamicVC()
        vc.userId = model.userId
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return  view.bounds.width - 24
    }
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return 0
    }
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return section == 0 ? 0: 8
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        return nil
    }
    
    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        return nil
    }
}
