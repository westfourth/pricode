//
//  ChatSexVC.swift
//  Sp
//
//  Created by mac on 2020/6/16.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit
import CoreLocation

/// 下载
class ChatSexVC: UIViewController {
    
    let pageViewController = UIPageViewController(transitionStyle: .scroll, navigationOrientation: .horizontal, options: nil)
    
    lazy var officialVC: OfficialVC = {
        let vc =  OfficialVC()
        vc.view.tag = 0
        return vc
    }()
    
    lazy var clubVC: ClubVC = {
        let vc =  ClubVC()
        vc.view.tag = 1
        return vc
    }()
    
    lazy var squareVC: SquareVC = {
        let vc =  SquareVC()
        vc.view.tag = 2
        return vc
    }()
    
    lazy var unlockedVC: SquareVC = {
        let vc =  SquareVC()
        vc.type = .unlocked
        vc.view.tag = 3
        return vc
    }()
    
    
//    var nextIndex = 0
    var currentIndex = 0
    let locationManager = CLLocationManager()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = RGB(0x141516)
        pageViewController.dataSource = self
        pageViewController.delegate = self

        view.addSubview(topView)
        
        addChild(pageViewController)
        view.addSubview(pageViewController.view)
        
        let v:CGFloat = (UIApplication.shared.windows.first?.safeAreaInsets.top ?? 0 ) <= 20 ? 20 :44
        topView.frame =  CGRect(x: 0, y: 0, width: view.bounds.width, height: v + 54)
        pageViewController.view.frame = CGRect(x: 0, y:topView.bounds.height, width: view.bounds.width, height: view.bounds.height - topView.bounds.height)
        
        //  默认显示官方推荐
        pageViewController.setViewControllers([officialVC], direction: .forward, animated: true, completion: nil)
        
        locationAction()
        locationAlert()
    }
    
    
    func locationAction() {
        if CLLocationManager.locationServicesEnabled() {
            locationManager.delegate = self
            locationManager.desiredAccuracy = kCLLocationAccuracyNearestTenMeters
            locationManager.distanceFilter = 50
            locationManager.requestWhenInUseAuthorization()
            locationManager.startUpdatingLocation()
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.setNavigationBarHidden(true, animated: animated)
    }
    
    private func locationAlert(){
        let a = CLLocationManager.authorizationStatus()
        if  a == .restricted  || a == .denied{
            // 一直弹框
            Session.request(FetchCityReq()) { (e, resp) in
                guard e == nil else{
                    self.alertAction()
                    return
                }
                guard let r = resp as? CityResp,r.cityName != "" else {
                    self.alertAction()
                    return
                }
                Defaults.officialCurrentCity = r.cityName
                NotificationCenter.default.post(name: .location, object: r.cityName)
            }
        }
    }
    
    private func alertAction() {
        if Defaults.officialCurrentCity != nil {
            return
        }
        
        let alert = UIAlertController(title:"未獲得定位許可權", message:"請前往設置-隱私-定位, 打開定位許可權", preferredStyle: .alert)
        let confirm = UIAlertAction(title:"馬上去設置", style: .default) { _ in
            let url = URL.init(string: UIApplication.openSettingsURLString)
            if  InnerIntercept.canOpenURL(url!) {
                InnerIntercept.open(url!)
            }
        }
        let cancel = UIAlertAction(title:"取消", style: .cancel, handler:nil)
        alert.addAction(cancel)
        alert.addAction(confirm)
        present(alert, animated:true, completion:nil)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.navigationController?.navigationBar.setBackgroundImage(UIImage(named: "navi_backImage"), for: UIBarMetrics.default)
        self.navigationController?.navigationBar.shadowImage = UIImage()
        self.navigationController?.setNavigationBarHidden(false, animated: animated)
    }
    
    lazy var topView:ChatTopBar = {
        let v = Bundle.main.loadNibNamed("ChatTopBar", owner: nil, options: [:])?.first as! ChatTopBar
        v.delegate = self
        v.messageView.delegate = self
        return v
    }()
    
    func switchAction(_ index:Int) {
        var controllers = [UIViewController]()
        switch index {
        case 0 :
            controllers = [officialVC]
        case 1:
            controllers = [clubVC]
        case 2:
            controllers = [squareVC]
        case 3:
            controllers = [unlockedVC]
        default:
            break
        }
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 0.5) {
            self.pageViewController.setViewControllers(controllers, direction:  index >= self.currentIndex ?  .forward : .reverse, animated: true, completion: nil)
            self.currentIndex = index
            self.topView.currentIndex = index
        }
    }
}

extension ChatSexVC:MessageViewDelegate {
    func messageAction() {
        let vc = MessageVC()
        vc.hidesBottomBarWhenPushed = true
        self.navigationController?.pushViewController(vc, animated: true)
    }
}

extension ChatSexVC:CLLocationManagerDelegate {
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        if !locations.isEmpty {
            let l = locations.last!
            CLGeocoder().reverseGeocodeLocation(l) { (places, e) in
                guard let places = places,!places.isEmpty else {
                    return
                }
                let p = places.first!
                if Defaults.officialCurrentCity != p.locality, let city = p.locality {
                    Defaults.officialCurrentCity = p.locality
                    Alert.showCommonAlert(parentView: self.view, contentText: "定位您當前在\(city),是否切換?", cancelText: "取消", confirmText: "確定", onConfirmTap: {
                        NotificationCenter.default.post(name: .location, object: city)
                    }) {}
                }
            }
            manager.stopUpdatingLocation()
        }
    }
    
    func locationManager(manager: CLLocationManager, didFailWithError error: NSError) {
        mm_showToast("定位出錯",type: .failed)
    }
}

//_______________________________________________________________________________________________________________
   // MARK: - UIPageViewControllerDataSource &Delegate
extension ChatSexVC:UIPageViewControllerDataSource,UIPageViewControllerDelegate {
    func pageViewController(_ pageViewController: UIPageViewController, viewControllerBefore viewController: UIViewController) -> UIViewController? {
        if viewController == squareVC {
            return  clubVC
        } else if viewController == clubVC {
            return officialVC
        } else if viewController == unlockedVC {
            return squareVC
        }
        return nil
    }
    
    func pageViewController(_ pageViewController: UIPageViewController, viewControllerAfter viewController: UIViewController) -> UIViewController? {
        if viewController == officialVC  {
            return clubVC
        } else if viewController == clubVC {
            return squareVC
        } else if viewController == squareVC {
            return unlockedVC
        }
        return nil
    }

    func pageViewController(_ pageViewController: UIPageViewController, didFinishAnimating finished: Bool, previousViewControllers: [UIViewController], transitionCompleted completed: Bool) {
        if completed == false {
            return
        }
        currentIndex = pageViewController.viewControllers!.first!.view.tag
//        topView.avatar.isHidden = currentIndex != 2
//        topView.messageView.isHidden = currentIndex != 2
        topView.currentIndex = currentIndex
    }
}

extension ChatSexVC:ChatTopBarDelegate {
    
    func chatTopBarAvatarAction() {
        guard let user = NetDefaults.userInfo else {return}
        let vc = UsersDynamicVC()
        vc.userId = user.userId
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    func chatTopBar(didSelect index: Int) {
        var controllers = [UIViewController]()
        switch index {
        case 0 :
            controllers = [officialVC]
        case 1:
            controllers = [clubVC]
        case 2:
            controllers = [squareVC]
        case 3:
            controllers = [unlockedVC]
        default:
            break
        }
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 0.1) {
            self.pageViewController.setViewControllers(controllers, direction:  index >= self.currentIndex ?  .forward : .reverse, animated: true, completion: nil)
            self.currentIndex = index
        }
//        topView.avatar.isHidden = currentIndex != 2
//        topView.messageView.isHidden = currentIndex != 2
    }
}
