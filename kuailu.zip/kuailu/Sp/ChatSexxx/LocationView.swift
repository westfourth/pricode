//
//  LocationView.swift
//  Sp
//
//  Created by mac on 2020/6/17.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

@objc protocol LocationViewDelegate {
    ///点击
    func tapHowToDate(locationView:LocationView)
    
    func tapLocation(locationView:LocationView)
    
}

class LocationView: UIView {
    weak var delegate: LocationViewDelegate?
    
    @IBOutlet weak var location: UILabel!
    
    @IBAction func tapAction(_ sender: Any) {
        let tap = sender as! UITapGestureRecognizer
        let p = tap.location(in: self)
        if p.x <= UIScreen.main.bounds.width / 2 {
            delegate?.tapHowToDate(locationView: self)
        } else {
            delegate?.tapLocation(locationView: self)
        }
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        NotificationCenter.default.addObserver(self, selector: #selector(changeCity(_:)), name: .location, object: nil)

        if let name = Defaults.officialCurrentCity {
            location.text = "\(name)"
        }
    }
    
    @objc func changeCity(_ noti:Notification) {
        if let name = noti.object as? String {
            location.text = "\(name)"
        }
    }
    
    deinit {
        NotificationCenter.default.removeObserver(self)
    }
}
