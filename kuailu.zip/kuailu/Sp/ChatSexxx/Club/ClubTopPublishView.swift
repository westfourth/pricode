//
//  ClubTopPublishView.swift
//  Sp
//
//  Created by mac on 2020/9/23.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

@objc protocol ClubTopPublishViewDelegate {
    ///点击已发布
    func publishedList()
    /// 去发布
    func toPublishAction()
}

class ClubTopPublishView: UIView {

    weak var delegate: ClubTopPublishViewDelegate?

    @IBOutlet weak var publish_count: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }
    
    @IBAction func publishAction(_ sender: Any) {
        delegate?.toPublishAction()
    }
    
    @IBAction func publishedAction(_ sender: Any) {
        delegate?.publishedList()
    }
    
}
