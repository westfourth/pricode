//
//  ClubTagCell.swift
//  Sp
//
//  Created by mac on 2020/9/23.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class ClubTagCell: UICollectionViewCell {

    @IBOutlet weak var name: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    var item:String? {
        didSet {
            guard let item = item else {
                return
            }
            name.text = item
        }
    }
}
