//
//  ClubCell.swift
//  Sp
//
//  Created by mac on 2020/9/23.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class ClubCell: UICollectionViewCell {
    
    @IBOutlet weak var cover: UIImageView!
    @IBOutlet weak var name: UILabel!
    @IBOutlet weak var age: UILabel!
    @IBOutlet weak var price: UILabel!
    @IBOutlet weak var collectionView: UICollectionView!
    
    var delete: (() -> ())?
    var longTap: (() -> ())?
    @IBOutlet weak var deleteButton: UIButton!
    @IBOutlet weak var layout: UICollectionViewFlowLayout!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        age.layer.borderColor = RGB(0xffFA6400).cgColor
        
        collectionView.register(UINib(nibName: "ClubTagCell", bundle: Bundle.main), forCellWithReuseIdentifier: "ClubTagCell")
        let longTap = UILongPressGestureRecognizer(target: self, action: #selector(longTapAction))
        longTap.minimumPressDuration = 2.0
        addGestureRecognizer(longTap)
        layout.leftAligment()
    }
    
    @objc func longTapAction() {
        longTap?()
    }
    
    @IBAction func deleteAction(_ sender: Any) {
        delete?()
    }
    
    @IBOutlet weak var reviewingView: UIView!
    var item:ClubGirlItem? {
        didSet {
            guard let item = item else {
                return
            }
            cover.kf.setImage(with: item.squareImg,placeholder:Sensitive.default_bg,options: [.transition(.fade(0.25))])
            name.text = item.nickName
            price.text = item.price
            if let birthday = item.birthday {
                let timeI = Date().timeIntervalSince(birthday)
                let age = Int(timeI / (3600*24*365))
                self.age.text = "\(age)歲"
            } else {
                age.text = "保密"
            }
            deleteButton.isHidden = !item.isSelected
            collectionView.reloadData()
            reviewingView.isHidden = item.status != .reviewing
            var sum :CGFloat = 0
            let count = item.userTags.count
            for i in item.userTags {
                let w = i.getStringSize(rectSize: CGSize(width: CGFloat.greatestFiniteMagnitude, height: 16), font: UIFont.systemFont(ofSize: 10)).width + 8
                sum = sum + w
            }
            if count > 0 {
                sum = sum + CGFloat(( count - 1) * 4)
            }
             let w = (UIScreen.main.bounds.width - 24 - 6 ) / 2.0
            if sum > (w - 12) {
                collectionViewHeight.constant = 36
            } else {
                collectionViewHeight.constant = 16
            }
        }
    }
    
    @IBOutlet weak var collectionViewHeight: NSLayoutConstraint!
    
    static func size(_ item:ClubGirlItem)->CGSize {
        let w = (UIScreen.main.bounds.width - 24 - 6 ) / 2.0
        var sum :CGFloat = 0
        let count = item.userTags.count
        for i in item.userTags {
            let w = i.getStringSize(rectSize: CGSize(width: CGFloat.greatestFiniteMagnitude, height: 16), font: UIFont.systemFont(ofSize: 10)).width + 8
            sum = sum + w
        }
        if count > 0 {
            sum = sum + CGFloat(( count - 1) * 4)
        }
        let isSmall = UIScreen.main.bounds.width <= 375
        let gap:CGFloat = isSmall  ? 10 : 0
        return CGSize(width: w, height:(sum > w - 12) ?  270 / 165 * w + 20 + gap  :270 / 165 * w + gap )
    }
}

//_______________________________________________________________________________________________________________
// MARK: - UICollectionViewDataSource&Delegate
extension ClubCell:UICollectionViewDataSource,UICollectionViewDelegate,UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return item?.userTags.count ?? 0
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "ClubTagCell", for: indexPath) as! ClubTagCell
        cell.item = item?.userTags[indexPath.row]
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let i = item?.userTags[indexPath.row] ?? ""
        return CGSize(width: i.getStringSize(rectSize: CGSize(width: CGFloat.greatestFiniteMagnitude, height: 16), font: UIFont.systemFont(ofSize: 10)).width + 8, height: 16)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 4
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 4
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        return .zero
    }
    
    
}

