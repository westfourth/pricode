//
//  ClubVC.swift
//  Sp
//
//  Created by mac on 2020/9/23.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class ClubVC: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = RGB(0xff141516)
        view.addSubview(locationView)
        locationView.snp.makeConstraints { (make) in
            make.left.right.top.equalTo(0)
            make.height.equalTo(39)
        }
        
        view.addSubview(self.publishTopView)
        publishTopView.snp.makeConstraints { (make) in
            make.left.right.equalTo(0)
            make.height.equalTo(46)
            make.top.equalTo(locationView.snp.bottom).offset(10)
        }
        
        view.addSubview(collectionView)
        collectionView.snp.makeConstraints { (make) in
            make.left.right.bottom.equalTo(0)
            make.top.equalTo(publishTopView.snp.bottom).offset(14)
        }
        loadData(true)
    }
    
    lazy var collectionView: UICollectionView = {
        let layout = UICollectionViewFlowLayout()
        layout.minimumLineSpacing = 6
        layout.minimumInteritemSpacing = 6
        layout.sectionInset = UIEdgeInsets(top: 6, left: 12, bottom: 6, right: 12)
        
        let collectionView = UICollectionView(frame: .zero, collectionViewLayout: layout)
        collectionView.dataSource = self
        collectionView.delegate = self
        
        collectionView.register(UINib(nibName: "ClubCell", bundle: Bundle.main), forCellWithReuseIdentifier: "ClubCell")
        collectionView.backgroundColor = .clear
        collectionView.showsVerticalScrollIndicator = false
        collectionView.state = .loading
        collectionView.mj_header = getCommonMJHeader(refreshingTarget: self, headerRefreshCallback: #selector(onRefresh))
        collectionView.mj_footer = getCommonMJFooter(refreshingTarget: self, footerRefreshCallback: #selector(onLoadMore))
        return collectionView
    }()
    
    lazy var dateView:DateIntroductionView = {
        let v = Bundle.main.loadNibNamed("DateIntroductionView", owner: nil, options: [:])?.first as! DateIntroductionView
        return v
    }()
    
    lazy var locationView:LocationView = {
        let v = Bundle.main.loadNibNamed("LocationView", owner: nil, options: [:])?.first as! LocationView
        v.delegate = self
        return v
    }()
    
    lazy var publishTopView:ClubTopPublishView = {
        let v = Bundle.main.loadNibNamed("ClubTopPublishView", owner: nil, options: [:])?.first as! ClubTopPublishView
        v.delegate = self
        return v
    }()
    
    @objc func onRefresh() {
        loadData(true)
    }
    
    @objc func onLoadMore() {
        guard !normoreData else {
            return
        }
        loadData(false)
    }
    
    var isRequesting = false
    
    var item:ClubGirlsResp = ClubGirlsResp()
    
    var normoreData:Bool = false
    
    func loadData(_ isRefresh:Bool) {
        if isRequesting {
            return
        }
        isRequesting = true
        let req = ClubGirlsReq()
        if !isRefresh && !item.list.isEmpty {
            req.lastId = item.list.last?.clubhouseId ?? 0
        }
        req.cityName = (Defaults.clubCurrentCity == nil ? "": Defaults.clubCurrentCity) ?? ""
        Session.request(req) { (e, resp) in
            Alert.hideLoading()
            self.isRequesting = false
            self.collectionView.mj_header?.endRefreshing()
            self.collectionView.mj_footer?.endRefreshing()
            guard e == nil else {
                mm_showToast(e!.localizedDescription)
                self.collectionView.state = .failed
                return
            }
            guard let item = resp as?ClubGirlsResp else {
                self.collectionView.state = self.item.list.isEmpty ?  .empty:.normal
                return
            }
            if !item.list.isEmpty {
                self.item = item
            }
            self.publishTopView.publish_count.text = "\(item.releaseTotal)/\(item.remTotal + item.releaseTotal)"
            Defaults.clubCurrentCity =  item.cityName == "" ?"全國":item.cityName
            self.locationView.location.text = "\(item.cityName)"
            self.normoreData = item.list.isEmpty
            guard !item.list.isEmpty else {
                if isRefresh {
                    self.collectionView.state = .empty
                    self.collectionView.reloadData()
                } else {
                    self.collectionView.mj_footer?.endRefreshingWithNoMoreData()
                }
                return
            }
            self.collectionView.state = .normal
            self.collectionView.reloadData()
        }
    }
    
}

//_______________________________________________________________________________________________________________
// MARK: - UICollectionViewDataSource&Delegate
extension ClubVC:UICollectionViewDataSource,UICollectionViewDelegate,UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return item.list.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "ClubCell", for: indexPath) as! ClubCell
        let model = item.list[indexPath.row]
        cell.item = model
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let model = item.list[indexPath.row]
        return ClubCell.size(model)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 6.0
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 6.0
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        return UIEdgeInsets(top: 6, left: 12, bottom: 6, right: 12)
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let model = item.list[indexPath.row]
        let vc = UsersDynamicVC()
        vc.userId = model.userId
        vc.hidesBottomBarWhenPushed = true
        navigationController?.pushViewController(vc, animated: true)
    }
}

extension ClubVC:LocationViewDelegate {
    
    func tapHowToDate(locationView: LocationView) {
        UIApplication.shared.keyWindow?.addSubview(dateView)
        dateView.frame = UIScreen.main.bounds
    }
    
    func tapLocation(locationView: LocationView) {
        let vc = ChooseCityVC()
        vc.chosenCityClosure = { [weak self] city in
            Defaults.clubCurrentCity = city.name
            self?.locationView.location.text = "\(city.name)"
            Alert.showLoading(parentView: self?.view ?? UIView())
            self?.loadData(true)
        }
        vc.hidesBottomBarWhenPushed = true
        navigationController?.pushViewController(vc, animated: true)
    }
}

extension ClubVC:ClubTopPublishViewDelegate {
    
    func publishedList() {
        let vc = MyClubGirlsVC()
        vc.hidesBottomBarWhenPushed  = true
        navigationController?.pushViewController(vc, animated: true)
    }
    
    func toPublishAction() {
        if item.isBusiness {
            let vc = ClubPublishVC()
            vc.callback = {
                self.loadData(true)
            }
            vc.hidesBottomBarWhenPushed = true
            InnerIntercept.currentNaviController().pushViewController(vc, animated: true)
        } else {
            alert()
        }
    }
    
    func alert() {
        Alert.showCommonAlert(parentView: self.view,
                              contentText: "您還不是認證商家哦，需繳納入駐保證金",
                              cancelText: "取消",
                              confirmText: "繳納保證金",
                              onConfirmTap: {
                                // 购买金币
                                let VC = Vip2VC()
                                VC.uiType = .bar
                                let navVC = (UIApplication.shared.delegate as? AppDelegate)?.currentNavigationController
                                navVC?.pushViewController(VC, animated: true)
        },onCancelTap: nil)
    }
}


