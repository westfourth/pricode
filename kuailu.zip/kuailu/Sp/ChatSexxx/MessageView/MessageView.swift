//
//  MessageView.swift
//  Sp
//
//  Created by mac on 2020/6/20.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

@objc protocol MessageViewDelegate {
    
    func messageAction()
}

class MessageView: UIView {
    
    weak var delegate: MessageViewDelegate?

    @IBOutlet weak var count: UIButton!
    
    @IBAction func messageAction(_ sender: UITapGestureRecognizer) {
        delegate?.messageAction()
    }
}
