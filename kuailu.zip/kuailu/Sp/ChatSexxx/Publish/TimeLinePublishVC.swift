//
//  TimeLinePublishVC.swift
//  Sp
//
//  Created by mac on 2020/6/17.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit
import TZImagePickerController
import FileUpLoader

class TimeLinePublishVC: UIViewController {

    @IBOutlet weak var leftCons: NSLayoutConstraint!
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = RGB(0xff141516)
        navigationItem.title = "發佈"
        leftCons.constant = (UIScreen.main.bounds.width - 132 - 90 ) / 2.0
    }
    
    @IBAction func uploadImgAction(_ sender: Any) {
        let picker = TZImagePickerController()
        picker.maxImagesCount = 9
        picker.allowPickingVideo = false
        picker.modalPresentationStyle = .fullScreen
        picker.didFinishPickingPhotosHandle = {  (results,assets,flag) in
            let vc = UploadImageVC()
            vc.images = results ?? [UIImage]()
            self.navigationController?.pushViewController(vc, animated: true)
        }
        present(picker, animated: true, completion: nil)
        
    }
    
    @IBAction func uploadVideoAction(_ sender: Any) {
        GlobalSettings.setImagePickerNatiBarAttribute()
        let imageVC = UIImagePickerController()
        imageVC.mediaTypes = ["public.movie"]
        imageVC.videoQuality = .typeMedium
        imageVC.videoMaximumDuration = TimeInterval(1500)
        imageVC.allowsEditing = true
        imageVC.modalPresentationStyle = .fullScreen
        if #available(iOS 13.0, *) {
            imageVC.isModalInPresentation = true
        }
        imageVC.delegate = self as? UIImagePickerControllerDelegate & UINavigationControllerDelegate
        self.present(imageVC, animated: true, completion: nil)
    }
}


// MARK: - UIImagePickerControllerDelegate
extension TimeLinePublishVC:UIImagePickerControllerDelegate,UINavigationControllerDelegate {
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        GlobalSettings.resetNaviBarAttribute()
        picker.dismiss(animated: true, completion: nil)
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        picker.dismiss(animated: true, completion: nil)
        GlobalSettings.resetNaviBarAttribute()
        if picker.mediaTypes == ["public.movie"] {
            //上传视频
            guard let videoURL = info[UIImagePickerController.InfoKey.mediaURL] as? URL   else {
                return
            }
            guard let refrenceURL = info[UIImagePickerController.InfoKey.referenceURL] as? URL else {
                return
            }
            let asset = AVURLAsset(url: videoURL, options: [AVURLAssetPreferPreciseDurationAndTimingKey:false])
            guard asset.isPlayable else {
                mm_showToast("該視頻不可播放，請重新選擇!")
                return
            }
            let seconds:Int = Int((Double(asset.duration.value)) / (Double(asset.duration.timescale)))
            UserDefaults.standard.set(seconds, forKey: "videoSeconds")
            UserDefaults.standard.synchronize()
            let item = FileItem(url:videoURL, fileIdentifier: refrenceURL.absoluteString)
            let vc =  UploadVideoViewController()
            vc.item = item
            vc.hidesBottomBarWhenPushed = true
            self.navigationController?.pushViewController(vc, animated: true)
        }
    }
}
