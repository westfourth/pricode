//
//  TimeLineImageCell.swift
//  Sp
//
//  Created by mac on 2020/6/18.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class TimeLineImageCell: UICollectionViewCell {

    @IBOutlet weak var cover: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
//        backgroundColor = UIColor.randomColor()
    }
    
    var coverUrl:String? {
        didSet {
            guard let u = coverUrl, let url = URL(string: u) else {
                return
            }
            cover.kf.setImage(with: url,placeholder:Sensitive.default_bg,options: [.transition(.fade(0.25))])
        }
    }
}
