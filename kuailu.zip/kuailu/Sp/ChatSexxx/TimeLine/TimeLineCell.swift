//
//  TimeLineCell.swift
//  Sp
//
//  Created by mac on 2020/6/18.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit
@objc protocol TimeLineCellDelegate {
    
    func timeLineCell(cell:TimeLineCell, avatar: UIImageView, item: TimeLineItem)
    
    func timeLineCell(cell:TimeLineCell, focus: UIButton, item: TimeLineItem)
    
    func timeLineCell(cell:TimeLineCell, like: UIButton, item: TimeLineItem)
    
    func timeLineCell(cell:TimeLineCell, comment: UIButton, item: TimeLineItem)
    
    func timeLineCell(cell:TimeLineCell, tapCover item: TimeLineItem, index: Int)
    
    func timeLineCell(cell:TimeLineCell, playVideo item: TimeLineItem)
    
    func timeLineCell(cell:TimeLineCell, activityItem item: TimeLineItem)
}

class TimeLineCell: UITableViewCell {
    
    private static let twoH = (UIScreen.main.bounds.width - 24 - 4 ) / 2
    
    private static let oneW = (UIScreen.main.bounds.width - 24 - 4 ) / 2
    
    private static let oneH = (UIScreen.main.bounds.width - 24 - 4 ) / 2 * (223 / 165)
    
    private static let likeImg: UIImage? = {
        return UIImage(named: "chat_like_n")
    }()
    
    private static let likeActiveImg: UIImage? = {
        return UIImage(named: "chat_like_y")
    }()
    
    private static let defaultAvatarImg: UIImage? = {
        return UIImage(named: "default_avatar")
    }()
    
    private static let maleImg: UIImage? = {
        return UIImage(named: "ic_male")
    }()
    
    private static let femaleImg: UIImage? = {
        return UIImage(named: "ic_female")
    }()
    
    private static let sexUnknownImg: UIImage? = {
        return UIImage(named: "sex_unknow")
    }()
    
    private static let reviewImg: UIImage? = {
        return UIImage(named: "reviewing_icon")
    }()
    
    private static let reviewFailureImg: UIImage? = {
        return  UIImage(named: "review_failure")
    }()
    
    private static let communityPortrayImg: UIImage? = {
        return  UIImage(named: "community_type_img")
    }()
    
    private static let communityBeautyImg: UIImage? = {
        return  UIImage(named: "community_type_datemore")
    }()
    
    private static let communityFeauturesImg: UIImage? = {
        return  UIImage(named: "community_type_feautures")
    }()
    
    private static let officialImg: UIImage? = {
        return  UIImage(named: "ic_official")
    }()
    
    private static let animationOptions: KingfisherOptionsInfo = {
        return [.transition(.fade(0.25))]
    }()
    
    @IBOutlet weak var avatar: UIImageView!
    @IBOutlet weak var name: UILabel!
    @IBOutlet weak var gender: UIImageView!
    @IBOutlet weak var focus: UIButton!
    @IBOutlet weak var location: UILabel!
    @IBOutlet weak var locationIcon: UIImageView!
    @IBOutlet weak var time: UILabel!
    @IBOutlet weak var content: UILabel!
    @IBOutlet weak var watchTime: UILabel!
    @IBOutlet weak var like: UIButton!
    @IBOutlet weak var comment: UIButton!
    
    @IBOutlet weak var videoView: UIView!
    @IBOutlet weak var videoCover: UIImageView!
    
    @IBOutlet weak var collectionView: UICollectionView!
    @IBOutlet weak var layout: UICollectionViewFlowLayout!
    
    @IBOutlet weak var contentTopCons: NSLayoutConstraint!
    @IBOutlet weak var contentHeight: NSLayoutConstraint!
    
    @IBOutlet weak var createTime: UILabel!
    
    @IBOutlet weak var topIcon: UIImageView!
    @IBOutlet weak var videoRatio: NSLayoutConstraint!
    
    @IBOutlet weak var reviewicon: UIImageView!
    @IBOutlet weak var reviewContent: UILabel!
    @IBOutlet weak var watchTimeBottomCons: NSLayoutConstraint!
    
    @IBOutlet weak var videoContentTopCons: NSLayoutConstraint!
    @IBOutlet weak var collectionContentTopCons: NSLayoutConstraint!
    @IBOutlet weak var beautyTopCons: NSLayoutConstraint!
    
    //MARK:-楼凤约她
    @IBOutlet weak var beautyView: UIView!
    @IBOutlet weak var beauty_age: UILabel!
    @IBOutlet weak var beauty_intro: UILabel!
    @IBOutlet weak var beauty_price: UILabel!
    @IBOutlet weak var beauty_pro_collectionView: UICollectionView!
    
    @IBOutlet weak var vip_icon: UIImageView!
    @IBOutlet weak var official_icon: UIImageView!
    @IBOutlet weak var vip_icon_leftCons: NSLayoutConstraint!
    
    @IBOutlet weak var activityButton: UIButton!
    @IBOutlet weak var activityButtonWidCons: NSLayoutConstraint!
    
    
    @IBOutlet weak var tagname: UIButton!
    @IBOutlet weak var tagnameWidthCons: NSLayoutConstraint!
    
    @IBOutlet weak var collectionViewBottomCons: NSLayoutConstraint!
    @IBOutlet weak var videoViewBottomCons: NSLayoutConstraint!
    
    weak var delegate: TimeLineCellDelegate?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        backgroundColor = .none
        selectionStyle = .none
        collectionView.register(UINib(nibName: "TimeLineImageCell", bundle: .main), forCellWithReuseIdentifier: "TimeLineImageCell")
        
        like.setImage(TimeLineCell.likeImg, for: .normal)
        like.setImage(TimeLineCell.likeActiveImg, for: .selected)
        
        let tap = UITapGestureRecognizer(target: self, action: #selector(avatarAction(tap:)))
        avatar.addGestureRecognizer(tap)
        
        let tap2 = UITapGestureRecognizer(target: self, action: #selector(playAction))
        videoView.addGestureRecognizer(tap2)
        
        beauty_pro_collectionView.register(UINib(nibName: "BeautyTagCell", bundle: .main), forCellWithReuseIdentifier: "BeautyTagCell")
        
        beautyView.isUserInteractionEnabled = true
        let beautyTap = UITapGestureRecognizer(target: self, action: #selector(beautyAction))
        beautyView.addGestureRecognizer(beautyTap)
        
        let layout = beauty_pro_collectionView.collectionViewLayout
        layout.leftAligment()
    }
    
    var item: TimeLineItem? {
        didSet {
            guard let item = item else { return }
            videoView.isHidden = item.video == nil
            collectionView.isHidden = item.dynamicImg.isEmpty
            avatar.kf.setImage(with: item.logo, placeholder: Sensitive.avatar, options: TimeLineCell.animationOptions)
            name.text = item.nickName
            location.text = item.cityName == "" ? Defaults.officialCurrentCity == nil ?  "\(Sensitive.cao)星":Defaults.officialCurrentCity : item.cityName
            content.text = item.topDynamic ? "             \(item.content)" : item.content
            topIcon.isHidden = !item.topDynamic
            gender.image = item.gender == .male ? TimeLineCell.maleImg : item.gender == .female ?  TimeLineCell.femaleImg : TimeLineCell.sexUnknownImg
            let timeInterV: Double = item.createdAt?.timeIntervalSince1970 ?? 0
            time.text = TimeLineCell.dateFmt(String(timeInterV))
            collectionView.reloadData()
            videoCover.kf.setImage(with: item.video?.coverImg, placeholder: Sensitive.default_bg, options: TimeLineCell.animationOptions)
            
            let isMine = item.belongType == .mine
            //            let isMine = true
            
            avatar.isHidden = isMine
            name.isHidden = isMine
            location.isHidden = isMine
            time.isHidden = isMine
            createTime.isHidden = item.belongType != .mine
            //            createTime.isHidden = false
            contentTopCons.constant = isMine ? 61 : 84
            locationIcon.isHidden = isMine
            gender.isHidden = item.belongType != .square
            //            gender.isHidden = true
            
            contentHeight.constant = item.content.getStringSize(rectSize: CGSize(width: UIScreen.main.bounds.width - 24, height: .greatestFiniteMagnitude), font: UIFont.systemFont(ofSize: 12, weight: .regular)).height
            watchTime.text = "\(num2TenThousandStrFormat(item.fakeWatchTimes))人看過"
            like.setTitle("\(item.fakeLikes < 0 ? 0 : item.fakeLikes)", for: .normal)
            like.isSelected = item.isLike
            comment.setTitle("\(item.commentNum < 0 ? 0 : item.commentNum)", for: .normal)
            
//            if item.sourceType == .portray || item.sourceType == .beauty || item.sourceType == .feautures {
//                focus.isHidden = false
//                switch item.sourceType {
//                case .portray:
//                    focus.setImage(TimeLineCell.communityPortrayImg, for: .normal)
//                case .beauty:
//                    focus.setImage(TimeLineCell.communityBeautyImg, for: .normal)
//                case .feautures:
//                    focus.setImage(TimeLineCell.communityFeauturesImg, for: .normal)
//                case .common, .image, .video, .activity:
//                    puts(#function)
//                }
//            } else {
//                focus.isHidden = true
//            }
            
            activityButton.isHidden =  ismine(item) ? true: item.belongType != .square
//            activityButton.isHidden = true
            
            var timeStr = TimeLineCell.dateFmt(String(timeInterV))
            if timeStr.contains("日") {
                let m = (timeStr.replacingOccurrences(of: "日", with: "").components(separatedBy: "月").first ?? "" ).replacingOccurrences(of: "0", with: "")
                let d =  timeStr.replacingOccurrences(of: "日", with: "").components(separatedBy: "月").last ?? ""
                timeStr = d + " " + m + "月"
                let attri = NSMutableAttributedString(string: timeStr, attributes: [NSAttributedString.Key.foregroundColor : UIColor.white])
                attri.addAttributes([NSAttributedString.Key.font : UIFont.systemFont(ofSize: 24, weight: .semibold)], range: NSRange(location: 0, length: d.count + 1))
                attri.addAttributes([NSAttributedString.Key.font : UIFont.systemFont(ofSize: 14, weight: .regular)], range: NSRange(location: timeStr.count - (m + "月").count , length: (m + "月").count))
                createTime.attributedText = attri
            } else {
                createTime.text = timeStr
            }
            if item.sourceType == .video {
                let ratio:CGFloat = (item.video?.height == 0 || item.video?.width == 0) ? CGFloat(16) / CGFloat(9) : CGFloat(item.video?.width ?? 0) / CGFloat(item.video?.height ?? 0)
                videoRatio.constant =  ratio
            }
            else {
                videoRatio.constant = 9 / 16
            }
            
            let pass = item.status == .approved
            watchTimeBottomCons.constant = pass ? 12 : 42
            reviewicon.isHidden = pass
            reviewContent.isHidden = pass
            reviewicon.image = item.status == .reviewing ? TimeLineCell.reviewImg : TimeLineCell.reviewFailureImg
            reviewContent.text = item.status == .reviewing ? "動態審核中，請耐心等待哦～" : "審核失敗，理由:\(item.notPass)"
            let tag = item.topicName != ""
            collectionViewBottomCons.constant = tag ? (pass ? 86 : 116) : pass ? 52 : 82
            videoViewBottomCons.constant = tag ? (pass ? 86 : 116) : pass ? 52 : 82
            
            videoContentTopCons.constant = item.sourceType == .beauty ? 160 + 11 : 11
            collectionContentTopCons.constant =  item.sourceType == .beauty ? 160 + 11 : 11
            
            tagnameWidthCons.constant =  "# \(item.topicName) #".getStringSize(rectSize: CGSize(width: CGFloat.greatestFiniteMagnitude, height: 20), font: UIFont.systemFont(ofSize: 13)).width +  10
            tagname.isHidden = item.topicName == ""
            tagname.setTitle("# \(item.topicName) #", for: .normal)
            // 楼风
            beautyView.isHidden = item.sourceType != .beauty
            if let birthday = item.birthday {
                let timeI = Date().timeIntervalSince(birthday)
                let age = Int(timeI / (3600 * 24 * 365))
                beauty_age.text = "年齡：\(age)"
            }
            beauty_price.text = "價格：\(item.price)"
            beauty_pro_collectionView.reloadData()
            beauty_intro.text = "簡介：\(item.personSign)"
            official_icon.image = TimeLineCell.officialImg
            if item.isOfficial {
                official_icon.isHidden = false
                vip_icon_leftCons.constant = 64
            } else {
                vip_icon_leftCons.constant = 5
                official_icon.isHidden = true
            }
            
            let l = "v\(item.level + 1)"
            vip_icon.image = UIImage(named: l)
//            activityButton.isHidden = item.sourceType != .activity
//            activityButton.setTitle("#\(item.typeName)", for: .normal)
//            activityButtonWidCons.constant = "#\(item.typeName)".getStringSize(rectSize: CGSize(width: 150, height: 20), font: UIFont.systemFont(ofSize: 13)).width + 20
        }
    }
    
    
    func ismine( _ item:TimeLineItem)->Bool {
        if let userInfo = NetDefaults.userInfo {
            return userInfo.userId == item.userId
        }
        return false
    }
    // MARK: - 方法
    @objc private func  playAction() {
        guard let item = item else { return }
        delegate?.timeLineCell(cell: self, playVideo: item)
    }
    
    @objc private func avatarAction(tap: UITapGestureRecognizer) {
        guard let item = item else { return }
        delegate?.timeLineCell(cell: self, avatar: avatar, item: item)
    }
    
    @IBAction private func commentAction(_ sender: UIButton) {
        guard let item = item else { return }
        delegate?.timeLineCell(cell: self, comment: sender, item: item)
    }
    
    @IBAction private func likeAction(_ sender: UIButton) {
        guard let item = item else { return }
        delegate?.timeLineCell(cell: self, like: sender, item: item)
    }
    
    @IBAction private func focusAction(_ sender: UIButton) {
        guard let item = item else { return }
        delegate?.timeLineCell(cell: self, focus: sender, item: item)
    }
    
    @IBAction private func activityAction(_ sender: Any) {
        Animation.scaleBounce(sender as! UIView)
        guard let item = item else { return }
        delegate?.timeLineCell(cell: self, activityItem: item)
    }
    
    /// 标签话题点击
    @IBAction private func tagAction(_ sender: Any) {
        if current_navi().topViewController is TopicDetailVC { return }
        guard let item = item else { return }
        let vc = TopicDetailVC()
        vc.hidesBottomBarWhenPushed = true
        let t = CommunityTopicItem()
        t.topicId = item.topicId
        t.topicName = item.topicName
        vc.item = t
        current_navi().pushViewController(vc, animated: true)
    }
    
    @objc private func beautyAction() {
        if current_navi().topViewController is UsersDynamicVC  { return }
        guard let item = item else { return }
        let vc = UsersDynamicVC()
        vc.userId = item.userId
        vc.hidesBottomBarWhenPushed = true
        current_navi().pushViewController(vc, animated: true)
    }
    
    //MARK:-获取当时正在显示的ViewController
    private func current_navi()->UINavigationController {
        let rootVC = UIApplication.shared.keyWindow!.rootViewController as! UITabBarController
        let naviController = rootVC.selectedViewController as! UINavigationController
        return naviController
    }
    
    static func height(_ item:TimeLineItem)-> CGFloat {
        let contentH: CGFloat = item.content.getStringSize(rectSize: CGSize(width: UIScreen.main.bounds.width - 24, height: .greatestFiniteMagnitude), font: UIFont.systemFont(ofSize: 12, weight: .regular)).height
        let itemH: CGFloat = (UIScreen.main.bounds.width - 32 ) / 3
        var count = item.dynamicImg.count
        guard let user = NetDefaults.userInfo else {return 0}
        if item.sourceType == .feautures, item.belongType != .mine, item.userId != user.userId {
            count = item.dynamicImg.count > 3 ? 3: item.dynamicImg.count
        }
        let row: Int = Int((count - 1 ) / 3 ) + 1
        let s = CGFloat(4) / CGFloat(3)
        let ratio: CGFloat = (item.video?.height == 0 || item.video?.width == 0) ? CGFloat(16) / CGFloat(9): CGFloat(item.video?.width ?? 0) / CGFloat(item.video?.height ?? 0)
        let videoH = ratio < s ? 1 / ratio * 0.6 * UIScreen.main.bounds.width : 1 / ratio * (UIScreen.main.bounds.width - 24)
        
        let collectionOrVideoH: CGFloat = item.video != nil ? videoH : count == 0 ? 0 : count == 1 ? oneH : count == 2 ? twoH : CGFloat(row) * itemH + CGFloat(row - 1) * 4
        
        let topH: CGFloat = item.belongType == .mine ? 61 : 84
        let pass = item.status == .approved
        let tag = item.topicName != ""
        let H: CGFloat = tag ? pass ? 86 : 116 : pass ? 52 : 82
        let beautyH: CGFloat = item.sourceType == .beauty ? 160 : 0
        return contentH + topH + 11  + collectionOrVideoH + H + 4 + beautyH
    }
    
    /// 根据时间戳与当前时间的比较
    private static func dateFmt(_ timeStamp: String) -> String {
        //计算出时间戳距离现在时间的一个秒数(..s)
        let interval: TimeInterval = TimeInterval(timeStamp)!
        let date = Date(timeIntervalSince1970: interval)
        var timeInterval = date.timeIntervalSinceNow
        //得到的是一个负值 (加' - ' 得正以便后面计算)
        timeInterval = -timeInterval
        //根据时间差 做所对应的文字描述 (作为返回文字描述)
        //一分钟以内
        if interval < 60 || Int(timeInterval/60) < 1 {
            return "剛剛"
        } else if Int(timeInterval/60) < 60 {
            //一小时以内
            return String(format:"%@分鐘前",String(Int(timeInterval/60)))
        } else if Int((timeInterval/60)/60) < 24 {
            //一天以内
            return String(format:"%@小時前",String(Int((timeInterval/60)/60)))
        } else {
            //一天以后
            let dateformatter = DateFormatter()
            //自定义日期格式
            dateformatter.dateFormat="MM月dd日"
            return dateformatter.string(from: date)
        }
    }
}

//_______________________________________________________________________________________________________________
// MARK: - UICollectionViewDataSource&Delegate
extension TimeLineCell:UICollectionViewDataSource,UICollectionViewDelegate,UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        guard let item = item  else { return 0 }
        if collectionView == beauty_pro_collectionView { return item.userTags.count }
        if item.sourceType == .video { return 0 }
        guard let user = NetDefaults.userInfo else { return 0 }
        if item.sourceType == .feautures, item.belongType != .mine {
            if item.userId == user.userId { return item.dynamicImg.count }
            return item.dynamicImg.count  > 3 ? 3:item.dynamicImg.count
        }
        return item.dynamicImg.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if collectionView == beauty_pro_collectionView {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "BeautyTagCell", for: indexPath) as! BeautyTagCell
            let s = item?.userTags[indexPath.row]
            cell.name.text = s
            return cell
        }
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "TimeLineImageCell", for: indexPath) as! TimeLineImageCell
        cell.coverUrl = item?.dynamicImg[indexPath.row]
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        if collectionView == beauty_pro_collectionView {return}
        guard let item = item else {return}
        delegate?.timeLineCell(cell: self, tapCover: item,index: indexPath.row)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 4
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 4
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        return .zero
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        if collectionView == beauty_pro_collectionView {
            if let s = item?.userTags[indexPath.row] {
                return CGSize(width: s.getStringSize(rectSize: CGSize(width: Int.max, height: 20), font: UIFont.systemFont(ofSize: 13)).width + 10, height: 20)
            }
            return .zero
        }
        guard let item = item else { return .zero}
        var count = item.dynamicImg.count
        guard let user = NetDefaults.userInfo else { return .zero }
        if item.sourceType == .feautures, item.belongType != .mine {
            if item.userId == user.userId {
                count = item.dynamicImg.count
            }
            count = item.dynamicImg.count > 3 ? 3 : item.dynamicImg.count
        }
        switch count {
        case 0:
            return .zero
        case 1:
            guard let item = self.item, item.imgWidth > 0, item.imgHeight > 0 else {
                return CGSize(width: TimeLineCell.oneW, height: TimeLineCell.oneH)
            }
            let screenWidth = UIScreen.main.bounds.width - 24
            let imgWidth = CGFloat(item.imgWidth)
            if imgWidth > screenWidth {
                return CGSize(width: screenWidth, height: screenWidth / imgWidth * CGFloat(item.imgHeight))
            } else {
                return CGSize(width: item.imgWidth, height: item.imgHeight)
            }
        case 2:
            return CGSize(width: TimeLineCell.twoH, height: TimeLineCell.twoH)
        default:
            let w: Double = Double((collectionView.bounds.width - 8) / 3)
            let isBig = UIScreen.main.bounds.width == 414
            return isBig ? CGSize(width: floor(w), height: floor(w)): CGSize(width: w, height: w)
        }
        
    }
}


