//
//  TimeLineVC.swift
//  Sp
//
//  Created by mac on 2020/6/16.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

public enum TimeLineType: Int {
    case latest = 0
    case focus = 1
    case classic = 2
    case mine = 3
}

class TimeLineVC: UIViewController {
    
    var items:[TimeLineItem] = [TimeLineItem]()
    
    var type:TimeLineType = .mine
    
    var listViewDidScrollCallback: ((UIScrollView) -> ())?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = RGB(0xff141516)
        view.addSubview(tableView)
        tableView.snp.makeConstraints { (make) in
            make.top.left.right.bottom.equalTo(0)
        }
        
        view.addSubview(publish)
        let tabbarHeight = type == .latest ?  UIApplication.shared.windows.first!.safeAreaInsets.bottom > 0 ? 83:49 : 20
        
        publish.snp.makeConstraints { (make) in
            make.bottom.equalTo(-30 - tabbarHeight)
            make.right.equalTo(-12)
        }
        loadData(true)
    }
    
    lazy var tableView : UITableView = {
        let tableView = UITableView.init(frame: CGRect.zero, style: .plain)
        tableView.delegate = self
        tableView.dataSource = self
        tableView.clipsToBounds = true
        tableView.backgroundColor = .clear
        tableView.separatorStyle = UITableViewCell.SeparatorStyle.none
        tableView.tableFooterView = UIView()
        tableView.register(UINib(nibName: "TimeLineCell", bundle: Bundle.main), forCellReuseIdentifier: "TimeLineCell")
        tableView.showsVerticalScrollIndicator = false
        tableView.state = .loading
        tableView.mj_header = getCommonMJHeader(refreshingTarget: self, headerRefreshCallback: #selector(onRefresh))
        tableView.mj_footer = getCommonMJFooter(refreshingTarget: self, footerRefreshCallback: #selector(onLoadMore))
        return tableView
    }()
    
    lazy var publish:UIImageView = {
        let v = UIImageView()
        let tap = UITapGestureRecognizer(target: self, action:#selector(publishAction))
        v.addGestureRecognizer(tap)
        v.isUserInteractionEnabled = true
        v.contentMode = .scaleAspectFit
        v.image = UIImage(named: "chat_publish")
        return v
    }()
    
    private lazy var bannerDeleteMaskView: UsersDynamicBannerDeleteMaskView = {
        let view = UsersDynamicBannerDeleteMaskView()
        return view
    }()
    
    @objc func publishAction() {
        //        let vc = TimeLinePublishVC()
        //        vc.hidesBottomBarWhenPushed = true
        //        navigationController?.pushViewController(vc, animated: true)
        
        //        let vc = UploadVC()
        //        let navVC = UINavigationController(rootViewController: vc)
        //        navVC.modalPresentationStyle = .fullScreen
        //       navigationController?.present(navVC, animated: true, completion: nil)
        
        guard NetDefaults.userInfo?.freeWatches == -1 else {
            PurchaseVipAlert.showPurchaseVipAlert()
            return
        }
        
        guard UploadConfig.shared.info.allow else {
            mm_showToast("系統維護中，暫不能上傳視頻!")
            return
        }
        let vc = UploadImageVC()
        navigationController?.pushViewController(vc, animated: true)
    }
    @objc func onRefresh() {
        loadData(true)
    }
    
    
    @objc func onLoadMore() {
        loadData(false)
    }
    
    var isRequesting = false
    
    func loadData(_ refresh:Bool) {
        if isRequesting {return}
        isRequesting = true
        let callback:(Error?,Any?)->Void = {[weak self] (e,resp) in
            self?.isRequesting = false
            self?.tableView.mj_header?.endRefreshing()
            self?.tableView.mj_footer?.endRefreshing()
            guard var array = resp as? [TimeLineItem], !array.isEmpty else {
                if refresh {
                    self?.tableView.state = .empty
                } else {
                    self?.tableView.state = .normal
                    if !(self?.items.isEmpty ?? false) {
                        self?.tableView.mj_footer?.endRefreshingWithNoMoreData()
                    }
                }
                self?.tableView.state = self?.items.isEmpty ?? false ? .empty:.normal
                return
            }
            array = array.map {
                if let videoUrl = $0.video?.videoUrl {
                    $0.video?.videoUrl = URL(string: videoUrl.absoluteString.replacingOccurrences(of: "?path=", with: "/dynamic?path="))
                }
                return $0
            }
            
            if refresh {
                self?.items = array
            } else {
                self?.items.append(contentsOf: array)
            }
            self?.tableView.reloadData()
            self?.tableView.state = .normal
        }
        
        //        if type == .mine {
        //            let req = TimeLineListReq()
        ////            if let user = NetDefaults.userInfo {
        ////                req.userId = user.userId
        ////            }
        //            if !refresh && !self.items.isEmpty {
        //                req.lastDynamicId = self.items.last?.dynamicId ?? 0
        //            }
        //            Session.request(req, callback: callback)
        //        } else {
        let req = TimeLineListNewReq()
        if !refresh && !self.items.isEmpty {
            req.lastDynamicId = self.items.last?.dynamicId ?? 0
        }
        req.loadType = type == .mine ? 0: type.rawValue
        Session.request(req, callback: callback)
        //        }
    }
}


// MARK: -UITableViewDataSource && Delegate
extension TimeLineVC:UITableViewDataSource,UITableViewDelegate {
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "TimeLineCell") as! TimeLineCell
        cell.item = items[indexPath.row]
        cell.delegate = self
        return cell
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return items.count
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return TimeLineCell.height(items[indexPath.row])
    }
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return 0
    }
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 0
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        return nil
    }
    
    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        return nil
    }
}


extension TimeLineVC:TimeLineCellDelegate {
    
    func timeLineCell(cell: TimeLineCell, playVideo item:TimeLineItem ) {
        
        guard NetDefaults.userInfo?.freeWatches == -1 else {
            PurchaseVipAlert.showPurchaseVipAlert()
            return
        }
        
        guard let video = item.video else {return}
        let vc = ShortVideoListVC()
        vc.fromDynamic = true
        vc.currentPlayingIndexPath = IndexPath(item: 0, section: 0)
        vc.videoItems = [video]
        vc.hidesBottomBarWhenPushed = true
        self.navigationController?.show(vc, sender: nil)
    }
    
    func timeLineCell(cell: TimeLineCell, activityItem item: TimeLineItem) {
//        let tabbar = UIApplication.shared.keyWindow?.rootViewController as! UITabBarController
//        tabbar.selectedIndex = 1
//        self.navigationController?.popToRootViewController(animated: true)
//        guard let navi = tabbar.selectedViewController as? UINavigationController, let classyVC = navi.topViewController as? ClassyVC else {return}
//        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() +  0.5) {
//            classyVC.switchToCategoryBar(type: .leapboardActivity)
//        }
        
        let vc = ChatVC()
        vc.fromUserId = item.userId
        vc.name = item.nickName
        vc.hidesBottomBarWhenPushed = true
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    func timeLineCell(cell: TimeLineCell, avatar: UIImageView,item:TimeLineItem) {
        let vc = UsersDynamicVC()
        vc.userId = item.userId
        vc.initPageType = .dynamic
        vc.attentionClosure = { [weak self] flag in
            if item.isAttention != flag {
                item.isAttention = flag
                self?.tableView.reloadData()
            }
        }
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    func timeLineCell(cell: TimeLineCell, focus: UIButton,item:TimeLineItem) {
        Animation.scaleBounce(focus)
        if item.sourceType == .beauty {
            // 约更多
            let appDelegate = UIApplication.shared.delegate as! AppDelegate
            guard let navi = appDelegate.currentNavigationController else {return}
            if navi.topViewController is Community2VC {
                let tabbar = UIApplication.shared.keyWindow?.rootViewController as! UITabBarController
                tabbar.selectedIndex = 3
                navi.popViewController(animated: true)
                DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 0.5) {
                    let appDelegate1 = UIApplication.shared.delegate as! AppDelegate
                    guard let navi1 = appDelegate1.currentNavigationController else {return}
                    let vc = navi1.topViewController! as! ChatSexVC
                    vc.topView.currentIndex = 2
                    vc.chatTopBar(didSelect: 2)
                }
            }
        } else if item.sourceType  == .portray {
            //写真
            let vc = PhotoVC()
            vc.hidesBottomBarWhenPushed = true
            self.navigationController?.pushViewController(vc, animated: true)
        } else if item.sourceType == .feautures {
            // 花絮
            let vc = UsersDynamicVC()
            vc.userId = item.userId
            vc.initPageType = .highlights
            self.navigationController?.pushViewController(vc, animated: true)
        }
    }
    
    func timeLineCell(cell: TimeLineCell, like: UIButton,item:TimeLineItem) {
        Animation.scaleBounce(like)
        like.isSelected = !like.isSelected
        var count = Int(like.title(for: .normal) ?? "0") ?? 0
        if like.isSelected {
            //点赞
            let req = TimeLineLikeReq()
            req.dynamicId = item.dynamicId
            Alert.showLoading(parentView: self.view)
            Session.request(req) { (e, resp) in
                Alert.hideLoading()
                guard e == nil else {
                    mm_showToast(e!.localizedDescription)
                    like.isSelected = false
                    return
                }
                count = count + 1
                like.setTitle("\(count)", for: .normal)
                item.commentNum = count
                item.isLike = true
                mm_showToast("點贊成功！",type: .succeed)
            }
        } else {
            let req = TimeLineCancelLikeReq()
            req.dynamicId = item.dynamicId
            Alert.showLoading(parentView: self.view)
            Session.request(req) { (e, resp) in
                Alert.hideLoading()
                guard e == nil else {
                    mm_showToast(e!.localizedDescription)
                    like.isSelected = true
                    return
                }
                count = count >= 0 ? count - 1:0
                like.setTitle("\(count)", for: .normal)
                item.commentNum = count
                item.isLike = false
                mm_showToast("取消點贊成功！",type: .succeed)
            }
        }
    }
    
    func timeLineCell(cell: TimeLineCell, comment: UIButton,item:TimeLineItem) {
        Animation.scaleBounce(comment)
        guard item.status == .approved else {
            let warning = item.status == .reviewing ? "動態審核中，請耐心等待哦～" :"審核失敗，理由:\(item.notPass)"
            mm_showToast(warning)
            return
        }
        let commentVC = CommentVC()
        commentVC.timelineItem = item
        present(commentVC, animated: true, completion: nil)
    }
    
    func timeLineCell(cell: TimeLineCell, tapCover item: TimeLineItem,index:Int) {
        
        guard NetDefaults.userInfo?.freeWatches == -1 else {
            PurchaseVipAlert.showPurchaseVipAlert()
            return
        }
        
        let urls = item.dynamicImg.map{ URL(string: $0)! }
        bannerDeleteMaskView.removeFromSuperview()
        UIApplication.shared.keyWindow!.addSubview(bannerDeleteMaskView)
        bannerDeleteMaskView.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
        bannerDeleteMaskView.bannerListData = urls
        bannerDeleteMaskView.nicknameLabel.text = item.nickName
        bannerDeleteMaskView.initPageIndex = index
        bannerDeleteMaskView.startAnimation()
    }
    
}


//_______________________________________________________________________________________________________________
// MARK: - JXPagingViewListViewDelegate
extension TimeLineVC: JXPagingViewListViewDelegate {
    func listView() -> UIView {
        return view
    }
    
    func listViewDidScrollCallback(callback: @escaping (UIScrollView) -> ()) {
        self.listViewDidScrollCallback = callback
    }
    
    func listScrollView() -> UIScrollView {
        return self.tableView
    }
}
