//
//  BeautyTagCell.swift
//  Sp
//
//  Created by mac on 2020/8/6.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class BeautyTagCell: UICollectionViewCell {
    @IBOutlet weak var name: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
