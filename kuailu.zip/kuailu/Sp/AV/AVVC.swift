//
//  AVVC.swift
//  Sp
//
//  Created by mac on 2020/11/11.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit


class AVVC: UIViewController {
    
    static let polygonImg: UIImage? = {
        return UIImage(named: "header_polygon_icon")
    }()
    
    private let categoryBarHeight: CGFloat = 48
    
    private let classyScrollListItemSize: CGSize = {
        return CGSize(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height - kTop - kBottom)
    }()
    
    private lazy var categoryBarCollectionView: UICollectionView = {
        let layout = UICollectionViewFlowLayout()
        layout.scrollDirection = .horizontal
        layout.minimumLineSpacing = 22
        layout.minimumInteritemSpacing = 22
        let cv = UICollectionView(frame: .zero, collectionViewLayout: layout)
        cv.register(AVCategoryCell.self, forCellWithReuseIdentifier: "AVCategoryCell")
        cv.showsVerticalScrollIndicator = false
        cv.showsHorizontalScrollIndicator = false
        cv.bouncesZoom = false
        cv.backgroundColor = .none
        cv.delegate = self
        cv.dataSource = self
        return cv
    }()
    
    private lazy var scrollListCollectionView: UICollectionView = {
        let layout = UICollectionViewFlowLayout()
        layout.itemSize = classyScrollListItemSize
        layout.minimumLineSpacing = 0
        layout.minimumInteritemSpacing = 0
        layout.scrollDirection = .horizontal
        let cv = UICollectionView(frame: .zero, collectionViewLayout: layout)
        cv.showsVerticalScrollIndicator = false
        cv.showsHorizontalScrollIndicator = false
        cv.bouncesZoom = false
        cv.isPagingEnabled = true
        cv.backgroundColor = .none
        cv.delegate = self
        cv.dataSource = self
        return cv
    }()
    
    private lazy var featuredTopicBtn: UIButton = {
        let btn = UIButton()
        btn.setBackgroundImage(UIImage(named: "recommend_featured_topic"), for: .normal)
        btn.addTarget(self, action: #selector(onFeaturedTopicBtnTap), for: .touchUpInside)
        return btn
    }()
    
    private lazy var navigatorBar: UIView = {
        let view = UIView()
        view.addSubview(categoryBarCollectionView)
        view.addSubview(featuredTopicBtn)
        
        featuredTopicBtn.snp.makeConstraints { (make) in
            make.centerY.right.equalToSuperview()
            make.size.equalTo(26)
        }
        
        categoryBarCollectionView.snp.makeConstraints { (make) in
            make.centerY.left.equalToSuperview()
            make.right.equalTo(featuredTopicBtn.snp.left).offset(-14)
            make.height.equalTo(categoryBarHeight)
        }
        
        return view
    }()
    
    private lazy var emptyImg: UIImage = {
        return UIImage()
    }()
    
    private var activeIndex: Int = 0
    
    private var initCategoryType: AVCategoryType = .recommend
    
    private var categoryList: [AVCategoryListResp] = [] {
        didSet {
            categoryBarCollectionView.reloadData()
            scrollListCollectionView.reloadData()
        }
    }
    
    private var categoryBarItemCenterXList: [CGFloat] = []
    
    private var categoryTitleSizeList: [CGSize] = []
    
    private var categoryTitleList: [String] = []
    
    private var isTapCategoryItem: Bool = false
    
    private var isGetCategoryList: Bool = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationItem.title = nil
        navigationItem.leftBarButtonItem = UIBarButtonItem(customView: navigatorBar)
        view.backgroundColor = RGB(0x141516)
        if #available(iOS 11.0, *) {
            categoryBarCollectionView.contentInsetAdjustmentBehavior = .never
            scrollListCollectionView.contentInsetAdjustmentBehavior = .never
        } else {
            automaticallyAdjustsScrollViewInsets = false
        }
        let screenWidth: CGFloat = UIScreen.main.bounds.width
        navigatorBar.snp.makeConstraints { (make) in
            make.width.equalTo(screenWidth - (screenWidth > 375 ? 20 : 16) * 2)
            make.height.equalTo(categoryBarHeight)
        }
        view.addSubview(scrollListCollectionView)
        
        scrollListCollectionView.snp.makeConstraints { (make) in
            make.top.left.right.equalToSuperview()
            make.height.equalTo(classyScrollListItemSize.height)
        }
        
        #if DEBUG
        if Defaults.debugJumpVersionUpdate {
        } else {
            AlertSequence.share.loadAllData()
        }
        #else
        AlertSequence.share.loadAllData()
        #endif
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.navigationBar.isTranslucent = false
        navigationController?.navigationBar.barTintColor = RGB(0x141516)
        if !isGetCategoryList, categoryList.isEmpty { getCategoryList() }
        getUserinfo()
        getAccountInfo()
    }
    
    private func getCategoryList() {
        isGetCategoryList = true
        Session.request(AVCategoryListReq()) { [weak self] (error, resp) in
            guard let `self` = self else { return }
            guard error == nil, let resData = resp as? [AVCategoryListResp], !resData.isEmpty else {
                self.isGetCategoryList = false
                return
            }
            let font = UIFont.pingFangMedium(20)
            for i in 0..<resData.count {
                let type = resData[i].type
                if self.initCategoryType == type, self.activeIndex != i {
                    self.activeIndex = i
                }
                switch type {
                case .recommend:
                    self.scrollListCollectionView.register(AVRecommendItemCell.self, forCellWithReuseIdentifier: "AVRecommendItemCell\(i)")
                case .latest, .normal:
                    self.scrollListCollectionView.register(AVOtherItemCell.self, forCellWithReuseIdentifier: "AVOtherItemCell\(i)")
                }
                self.categoryTitleSizeList.append(CGSize(width: resData[i].classifyTitle.getStringSize(rectSize: .zero, font: font).width, height: self.categoryBarHeight))
            }
            self.categoryList = resData
            guard !self.categoryTitleSizeList.isEmpty else { return }
            self.scrollListCollectionView.scrollToItem(at: IndexPath(row: self.activeIndex, section: 0), at: .centeredHorizontally, animated: true)
            self.isGetCategoryList = false
        }
    }
    
    private func getUserinfo() {
        Session.request(FetchUserInfoReq()) { (error, resp) in }
    }
    
    private func getAccountInfo() {
        Session.request(UserAccountInfoReq()) { (error, resp) in
            guard error == nil, let resData = resp as? UserAccountInfo else { return }
            WalletVC.balanceVal = resData.bala
            WalletVC.coinVal = resData.gold
            WalletVC.exchangeVal = resData.welfareNum
        }
    }
    
    @objc private func onSearchIconBtnTap() {
        navigationController?.show(SearchVC(), sender: nil)
    }
    
    @objc private func onFeaturedTopicBtnTap() {
        let featuredTopicVC = FeaturedTopicVC()
        let item = AVRecommendSpecialAreaResp()
        item.areaName = "精选专题"
        featuredTopicVC.categoryData = item
        navigationController?.show(featuredTopicVC, sender: nil)
    }
    
    private func refreshCategoryBarCollectionView(activeIndex: Int) {
        categoryBarCollectionView.scrollToItem(at: IndexPath(row: activeIndex, section: 0), at: .centeredHorizontally, animated: true)
        UIView.animate(withDuration: 0.15, delay: 0, options: .curveEaseIn, animations: {}) { [weak self] _ in
            self?.categoryBarCollectionView.reloadData()
            self?.isTapCategoryItem = false
        }
    }
    
    func switchToCategoryBar(type: AVCategoryType) {
        guard !categoryList.isEmpty else {
            initCategoryType = type
            return
        }
        guard let index = (categoryList.firstIndex { $0.type == type }), index != self.activeIndex else { return }
        DispatchQueue.main.async { [weak self] in
            guard let `self` = self else { return }
            self.activeIndex = index
            self.isTapCategoryItem = true
            self.scrollListCollectionView.scrollToItem(at: IndexPath(row: index, section: 0), at: .centeredHorizontally, animated: true)
        }
    }
    
}

extension AVVC: UICollectionViewDataSource, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return categoryList.count
    }
    
    func collectionView(_ collectionView: UICollectionView,
                        layout collectionViewLayout: UICollectionViewLayout,
                        sizeForItemAt indexPath: IndexPath) -> CGSize {
        return collectionView == categoryBarCollectionView ? categoryTitleSizeList[indexPath.row] : classyScrollListItemSize
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let row = indexPath.row
        guard collectionView == scrollListCollectionView else {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "AVCategoryCell", for: indexPath) as! AVCategoryCell
            let isActive = activeIndex == row
            cell.titleLabel.textColor = isActive ? Color.theme_color : .white
            cell.titleLabel.font = isActive ? UIFont.pingFangMedium(20) : UIFont.pingFangRegular(16)
            cell.dataModel = categoryList[row]
            return cell
        }
        var cell: UICollectionViewCell
        switch categoryList[row].type {
        case .recommend:
            cell = collectionView.dequeueReusableCell(withReuseIdentifier: "AVRecommendItemCell\(row)", for: indexPath) as! AVRecommendItemCell
            (cell as? AVRecommendItemCell)?.classifyId = categoryList[row].classifyId
            return cell
        case .latest, .normal:
            cell = collectionView.dequeueReusableCell(withReuseIdentifier: "AVOtherItemCell\(row)", for: indexPath) as! AVOtherItemCell
            (cell as? AVOtherItemCell)?.classifyId = categoryList[row].classifyId
            return cell
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let row = indexPath.row
        guard collectionView == categoryBarCollectionView, activeIndex != row else { return }
        activeIndex = row
        isTapCategoryItem = true
        scrollListCollectionView.scrollToItem(at: indexPath, at: .centeredHorizontally, animated: true)
    }
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        guard scrollView == scrollListCollectionView else { return }
        let currentActivePageIndex = Int(round(scrollView.contentOffset.x / scrollView.frame.width))
        guard isTapCategoryItem else {
            guard activeIndex != currentActivePageIndex else { return }
            activeIndex = currentActivePageIndex
            refreshCategoryBarCollectionView(activeIndex: currentActivePageIndex)
            return
        }
        guard currentActivePageIndex == activeIndex else { return }
        refreshCategoryBarCollectionView(activeIndex: currentActivePageIndex)
    }
}


