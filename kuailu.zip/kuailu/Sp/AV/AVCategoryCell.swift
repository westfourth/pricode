//
//  AVCategoryCell.swift
//  Sp
//
//  Created by mac on 2020/11/12.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class AVCategoryCell: UICollectionViewCell {
 
    lazy var titleLabel: UILabel = {
        let label = UILabel()
        label.textAlignment = .center
        return label
    }()
    
    var dataModel: AVCategoryListResp? {
        didSet {
            guard let item = dataModel else { return }
            titleLabel.text = item.classifyTitle
        }
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        addSubview(titleLabel)
        
        titleLabel.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}

