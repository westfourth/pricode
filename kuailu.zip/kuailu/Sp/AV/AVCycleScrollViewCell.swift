//
//  AVCycleScrollViewCell.swift
//  Sp
//
//  Created by mac on 2020/11/12.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class AVCycleScrollViewCell: UICollectionViewCell {
    
    static let bannerDefaultImg: UIImage? = {
        return  Sensitive.banner
    }()
    
    static let animationOptionGif: KingfisherOptionsInfo = {
        return [.transition(.fade(0.25)), .backgroundDecode, .fromMemoryCacheOrRefresh]
    }()
    
    static let animationOption: KingfisherOptionsInfo = {
        return [.transition(.fade(0.25))]
    }()
    
    private lazy var bannerImgView: AnimatedImageView = {
        let imgView = AnimatedImageView()
        imgView.contentMode = .scaleAspectFill
        imgView.layer.masksToBounds = true
        imgView.runLoopMode = .default
        return imgView
    }()
    
    var bannerImgUrl: URL? {
        didSet {
            let isGif = bannerImgUrl?.column0?.absoluteString.contains(".gif") ?? false
            bannerImgView.kf.setImage(with: bannerImgUrl?.column0, placeholder: AVCycleScrollViewCell.bannerDefaultImg, options: isGif ? AVCycleScrollViewCell.animationOptionGif : AVCycleScrollViewCell.animationOption)
        }
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        layer.masksToBounds = true
        layer.cornerRadius = 4
        addSubview(bannerImgView)
        bannerImgView.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}

