//
//  AVRecommendSwitchBottomBar.swift
//  Sp
//
//  Created by mac on 2021/1/12.
//  Copyright © 2021 mac. All rights reserved.
//

import UIKit

protocol AVRecommendSwitchBottomBarDelegate: NSObjectProtocol {
    
    func refreshList()
    
}

class AVRecommendSwitchBottomBar: UIButton {
    
    static let viewHeight: CGFloat = 38
    
    private static let refreshImg: UIImage? = {
        return UIImage(named: "AV_recommend_switch_icon")
    }()
    
    private static let animation: CABasicAnimation = {
        let animation = CABasicAnimation(keyPath: "transform.rotation.z")
        // 预设是顺时针效果，若将formValue和toValue的值互换，则为逆时针效果
        animation.fromValue = 0
        animation.toValue = Double.pi * 2
        animation.duration = 0.5
        //        animation.speed = 1
        animation.autoreverses = false
        // 解决动画结束后回到原始状态的问题
        animation.isRemovedOnCompletion = false
        animation.fillMode = .forwards
        animation.repeatCount = MAXFLOAT // 一直旋轉的話，就設定為MAXFLOAT
        // 定义动画的节奏
        animation.timingFunction = CAMediaTimingFunction(name: .linear)
        return animation
    }()
    
    weak var delegate: AVRecommendSwitchBottomBarDelegate?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setTitle("換一換", for: .normal)
        setTitleColor(rgb(0xFD9803), for: .normal)
        titleLabel?.font = FONT(12)
        setImage(AVRecommendSwitchBottomBar.refreshImg, for: .normal)
        addTarget(self, action: #selector(onRefreshTabBarTap), for: .touchUpInside)
        imagePosition(imageStyle: .left, spacing: 10)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    @objc private func onRefreshTabBarTap() {
        delegate?.refreshList()
    }
    
    func startAnimation() {
        imageView?.layer.add(AVRecommendSwitchBottomBar.animation, forKey: "ChannelItemBottomBarAnimation")
    }
    
    func stopAnimation() {
        imageView?.layer.removeAllAnimations()
    }
    
}
