//
//  AVRecommendItemCell.swift
//  Sp
//
//  Created by mac on 2020/11/10.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class AVRecommendItemCell: UICollectionViewCell {
    
    private lazy var channelTypeHeightList: [CGFloat] = {
        return [0, AVRecommendOtherCategoryView.viewHeight]
    }()
    
    private lazy var channelTypeClassList: [AnyClass] = {
        return [AVRecommendBannerView.self, AVRecommendOtherCategoryView.self]
    }()
    
    private lazy var channelTypeKeyList: [String] = {
        return ["AVRecommendBannerView", "AVRecommendOtherCategoryView"]
    }()
    
    private lazy var searchBarView: AVRecommendSearchBarView = {
        return AVRecommendSearchBarView()
    }()
    
    private lazy var tableView: UITableView = {
        let tableView = UITableView(frame: .zero, style: .grouped)
        tableView.delegate = self
        tableView.dataSource = self
        tableView.backgroundColor = .none
        tableView.separatorStyle = .none
        tableView.bouncesZoom = false
        tableView.isDirectionalLockEnabled = true
        tableView.showsVerticalScrollIndicator = false
        tableView.showsHorizontalScrollIndicator = false
        tableView.contentInset = UIEdgeInsets(top: 0, left: 0, bottom: 20, right: 0)
        tableView.contentInsetAdjustmentBehavior = .never
        for i in 0..<channelTypeClassList.count {
            tableView.register(channelTypeClassList[i], forCellReuseIdentifier: channelTypeKeyList[i])
        }
        return tableView
    }()
    
    private var listData: [AVCategoryRecommendSubListResp] = []
    
    private var isInitState: Bool = true
    
    var classifyId: Int = 0 {
        didSet {
            guard isInitState else { return }
            isInitState = false
            getList()
        }
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        renderView()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func renderView() {
        addSubview(searchBarView)
        addSubview(tableView)
        
        searchBarView.snp.makeConstraints { (make) in
            make.top.equalToSuperview().inset(20)
            make.left.right.equalToSuperview()
            make.height.equalTo(AVRecommendSearchBarView.viewHeight)
        }
        
        tableView.snp.makeConstraints { (make) in
            make.top.equalTo(searchBarView.snp.bottom).offset(20)
            make.left.right.bottom.equalToSuperview()
        }
    }
    
    private func getList() {
        let req = AVCategoryRecommendSubListReq()
        req.classifyId = classifyId
        Session.request(req) { [weak self] (error, resp) in
            guard let `self` = self, error == nil, let resData = resp as? [AVCategoryRecommendSubListResp], !resData.isEmpty else {
                return
            }
            self.listData = resData
            for i in 0..<resData.count {
                switch resData[i].type {
                case .horizontalFourGrid:
                    self.tableView.register(AVRecommendHorizontalFourGridItemCell.self, forCellReuseIdentifier: "AVRecommendHorizontalFourGridItemCell\(i)")
                    self.channelTypeHeightList.append(AVRecommendHorizontalFourGridItemCell.viewHeight)
                    self.channelTypeClassList.append(AVRecommendHorizontalFourGridItemCell.self)
                    self.channelTypeKeyList.append("AVRecommendHorizontalFourGridItemCell\(i)")
                case .verticalSixGrid:
                    self.tableView.register(AVRecommendVerticalSixGridItemCell.self, forCellReuseIdentifier: "AVRecommendVerticalSixGridItemCell\(i)")
                    self.channelTypeHeightList.append(AVRecommendVerticalSixGridItemCell.viewHeight)
                    self.channelTypeClassList.append(AVRecommendVerticalSixGridItemCell.self)
                    self.channelTypeKeyList.append("AVRecommendVerticalSixGridItemCell\(i)")
                case .verticalFourGrid:
                    self.tableView.register(AVRecommendVerticalFourGridItemCell.self, forCellReuseIdentifier: "AVRecommendVerticalFourGridItemCell\(i)")
                    self.channelTypeHeightList.append(AVRecommendVerticalFourGridItemCell.viewHeight)
                    self.channelTypeClassList.append(AVRecommendVerticalFourGridItemCell.self)
                    self.channelTypeKeyList.append("AVRecommendVerticalFourGridItemCell\(i)")
                case .horizontalScrollHorizontalChannel:
                    self.tableView.register(AVRecommendHorizontalScrollHorizontalItemCell.self, forCellReuseIdentifier: "AVRecommendHorizontalScrollHorizontalItemCell\(i)")
                    self.channelTypeHeightList.append(AVRecommendHorizontalScrollHorizontalItemCell.viewHeight)
                    self.channelTypeClassList.append(AVRecommendHorizontalScrollHorizontalItemCell.self)
                    self.channelTypeKeyList.append("AVRecommendHorizontalScrollHorizontalItemCell\(i)")
                }
                
            }
            self.tableView.reloadData()
        }
    }
    
}

extension AVRecommendItemCell: UITableViewDelegate, UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return channelTypeClassList.count
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return .leastNonzeroMagnitude
    }
    
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return .leastNonzeroMagnitude
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        return nil
    }
    
    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        return nil
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return channelTypeHeightList[indexPath.section]
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let section = indexPath.section
        switch section {
        case 0:
            let cell = tableView.dequeueReusableCell(withIdentifier: "AVRecommendBannerView", for: indexPath) as! AVRecommendBannerView
            cell.delegate = self
            cell.classifyId = classifyId
            return cell
        case 1:
            let cell = tableView.dequeueReusableCell(withIdentifier: "AVRecommendOtherCategoryView", for: indexPath) as! AVRecommendOtherCategoryView
            return cell
        default:
            let currentData = listData[section - 2]
            switch currentData.type {
            case .horizontalFourGrid:
                let cell = tableView.dequeueReusableCell(withIdentifier: "AVRecommendHorizontalFourGridItemCell\(section - 2)", for: indexPath) as! AVRecommendHorizontalFourGridItemCell
                cell.dataModel = currentData
                return cell
            case .verticalSixGrid:
                let cell = tableView.dequeueReusableCell(withIdentifier: "AVRecommendVerticalSixGridItemCell\(section - 2)", for: indexPath) as! AVRecommendVerticalSixGridItemCell
                cell.dataModel = currentData
                return cell
            case .verticalFourGrid:
                let cell = tableView.dequeueReusableCell(withIdentifier: "AVRecommendVerticalFourGridItemCell\(section - 2)", for: indexPath) as! AVRecommendVerticalFourGridItemCell
                cell.dataModel = currentData
                return cell
            case .horizontalScrollHorizontalChannel:
                let cell = tableView.dequeueReusableCell(withIdentifier: "AVRecommendHorizontalScrollHorizontalItemCell\(section - 2)", for: indexPath) as! AVRecommendHorizontalScrollHorizontalItemCell
                cell.dataModel = currentData
                return cell
            }
        }
    }
    
}

extension AVRecommendItemCell: AVRecommendBannerViewDelegate {
    
    func refreshTableView() {
        channelTypeHeightList[0] = AVRecommendBannerView.viewHeight
        tableView.reloadData()
    }
}

