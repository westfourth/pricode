//
//  PhotoPreviewVC.swift
//  Sp
//
//  Created by mac on 2020/9/2.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class PhotoPreviewVC: UIViewController {
    
    private static let profileImg: UIImage? = {
        return UIImage(named: "photo_preview_btn")
    }()
    
    private lazy var emptyImg: UIImage = {
        return UIImage()
    }()
    
    lazy var titleLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.pingFangMedium(18)
        label.textColor = .white
        label.textAlignment = .center
        label.numberOfLines = 1
        return label
    }()
    
    lazy var descLabel: CustomLabel = {
        let label = CustomLabel()
        label.font = UIFont.pingFangRegular(14)
        label.textColor = .white
        label.numberOfLines = 2
        label.verticalAlignment = .top
        return label
    }()
    
    private lazy var collectionView: UICollectionView = {
        let layout = UICollectionViewFlowLayout()
        layout.minimumLineSpacing = 0
        layout.minimumInteritemSpacing = 0
        layout.scrollDirection = .horizontal
        layout.itemSize = CGSize(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height - kTop - 20 - 30 - 26 - 20 - 38 - 16)
        let cv = UICollectionView(frame: .zero, collectionViewLayout: layout)
        cv.register(PhotoPreviewCell.self, forCellWithReuseIdentifier: "PhotoPreviewCell")
        cv.showsVerticalScrollIndicator = false
        cv.showsHorizontalScrollIndicator = false
        cv.isPagingEnabled = true
        cv.bouncesZoom = false
        cv.backgroundColor = .none
        cv.delegate = self
        cv.dataSource = self
        return cv
    }()
    
    private lazy var pageLabel: UILabel  = {
        let label = UILabel()
        label.text = " "
        label.font = UIFont.pingFangMedium(16)
        label.textAlignment = .center
        label.textColor = .white
        return label
    }()
    
    private lazy var profileBtn: UIButton = {
        let btn = UIButton()
        btn.isHidden = true
        btn.setTitle("TA的主页", for: .normal)
        btn.setTitleColor(.white, for: .normal)
        btn.titleLabel?.font = UIFont.pingFangRegular(14)
        btn.setBackgroundImage(PhotoPreviewVC.profileImg, for: .normal)
        btn.contentEdgeInsets = UIEdgeInsets(top: 0, left: 9, bottom: 0, right: 0)
        btn.addTarget(self, action: #selector(onProfileBtnTap), for: .touchUpInside)
        return btn
    }()
    
    private lazy var lockView: PhotoPreviewLockView = {
        let view = PhotoPreviewLockView()
        view.delegate = self
        return view
    }()
    
    var portrayId: Int = 0 {
        didSet {
            getList()
        }
    }
    
    var userId: Int = -1 {
        didSet {
            profileBtn.isHidden = NetDefaults.userInfo?.userId == nil || NetDefaults.userInfo?.userId == userId
        }
    }
    
    private var listData: [PortraySubItem] = []
    
    private var isVip: Bool = true {
        didSet {
            showAnimation(isShow: !isVip)
        }
    }
    
    private var pageIndex: Int = 0
    
    override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: Bundle?) {
        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
        hidesBottomBarWhenPushed = true
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = RGB(0x141516)
        view.addSubview(titleLabel)
        view.addSubview(pageLabel)
        view.addSubview(profileBtn)
        view.addSubview(descLabel)
        view.addSubview(collectionView)
        view.addSubview(lockView)
        
        titleLabel.snp.makeConstraints { (make) in
            make.top.equalToSuperview().inset(kTop - 32.5)
            make.left.right.equalToSuperview().inset(20)
            make.height.equalTo(25)
        }
        
        pageLabel.snp.makeConstraints { (make) in
            make.bottom.equalToSuperview().inset(30)
            make.height.equalTo(26)
            make.left.right.equalToSuperview().inset(20)
        }
        
        profileBtn.snp.makeConstraints { (make) in
            make.centerY.equalTo(pageLabel)
            make.right.equalToSuperview()
            make.width.equalTo(80)
            make.height.equalTo(28)
        }
        
        descLabel.snp.makeConstraints { (make) in
            make.left.right.equalToSuperview().inset(12)
            make.height.equalTo(38)
            make.bottom.equalTo(pageLabel.snp.top).offset(-20)
        }
        
        collectionView.snp.makeConstraints { (make) in
            make.top.equalToSuperview().inset(kTop + 20)
            make.left.right.equalToSuperview()
            make.bottom.equalTo(descLabel.snp.top).offset(-16)
        }
        
        lockView.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.navigationBar.isTranslucent = true
        navigationController?.navigationBar.setBackgroundImage(emptyImg, for: .default)
        navigationController?.navigationBar.shadowImage = emptyImg
        getUserinfo()
    }
    
    private func getList() {
        let req = PortrayListQueryReq()
        req.portrayId = portrayId
        Session.request(req) { [weak self] (error, resp) in
            guard let `self` = self, error == nil, let resData = resp as? [PortraySubItem], !resData.isEmpty else {
                return
            }
            self.listData = resData
            self.pageLabel.text = "1/\(resData.count)"
            self.collectionView.reloadData()
            DispatchQueue.main.async { [weak self] in
                self?.collectionView.isHidden = false
            }
        }
    }
    
    @objc private func onProfileBtnTap() {
        let usersDynamicVC = UsersDynamicVC()
        usersDynamicVC.userId = userId
        usersDynamicVC.initPageType = .photo
        navigationController?.show(usersDynamicVC, sender: nil)
    }
    
    private func showAnimation(isShow: Bool) {
        UIView.animate(withDuration: 0.3) { [weak self] in
            guard let `self` = self else { return }
            self.lockView.alpha = self.listData.count > PhotoPreviewLockView.maxLockNum && isShow && self.pageIndex + 1 >= PhotoPreviewLockView.maxLockNum ? 1 : 0
        }
    }
    
    private func getUserinfo() {
        Session.request(FetchUserInfoReq()) { [weak self] (error, resp) in
            guard error == nil, let resData = resp as? UserBase else { return }
            guard let `self` = self else { return }
            self.isVip = resData.freeWatches == -1 || resData.userId == self.userId
            self.profileBtn.isHidden = resData.userId == self.userId
        }
    }
    
}

extension PhotoPreviewVC: UICollectionViewDataSource, UICollectionViewDelegate {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return listData.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let index = indexPath.row
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "PhotoPreviewCell", for: indexPath) as! PhotoPreviewCell
        cell.bannerImgUrl = listData[index].imgUrl
        return cell
    }
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        let index = Int(round(scrollView.contentOffset.x / scrollView.frame.width))
        guard index != pageIndex else { return }
        pageIndex = index
        if PhotoPreviewLockView.maxLockNum <= index + 1 {
            isVip = NetDefaults.userInfo?.freeWatches == -1 || NetDefaults.userInfo?.userId == userId
            if !isVip, PhotoPreviewLockView.maxLockNum < index + 1, index > 0 {
                collectionView.scrollToItem(at: IndexPath(row: index - 1, section: 0), at: .centeredHorizontally, animated: true)
            }
        }
        pageLabel.text = "\(index + 1)/\(listData.count)"
    }
}

extension PhotoPreviewVC: PhotoPreviewLockViewDelegate {
    
    func hideLockView() {
        navigationController?.popViewController(animated: true)
    }
    
}
