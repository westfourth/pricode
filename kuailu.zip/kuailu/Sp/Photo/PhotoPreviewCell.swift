//
//  PhotoPreviewCell.swift
//  Sp
//
//  Created by mac on 2020/9/3.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class PhotoPreviewCell: UICollectionViewCell {
    
    static let bannerDefaultImg: UIImage? = {
        return  Sensitive.default_bg
    }()
    
    static let animationOptionGif: KingfisherOptionsInfo = {
        return [.transition(.fade(0.25)), .backgroundDecode, .fromMemoryCacheOrRefresh]
    }()
    
    static let animationOption: KingfisherOptionsInfo = {
        return [.transition(.fade(0.25))]
    }()
    
    private lazy var bannerImgView: AnimatedImageView = {
        let imgView = AnimatedImageView()
        imgView.contentMode = .scaleAspectFit
        imgView.layer.masksToBounds = true
        imgView.runLoopMode = .default
        return imgView
    }()
    
    var bannerImgUrl: URL? {
        didSet {
            let isGif = bannerImgUrl?.column0?.absoluteString.contains(".gif") ?? false
            bannerImgView.kf.setImage(with: bannerImgUrl?.column0, placeholder: PhotoPreviewCell.bannerDefaultImg, options: isGif ? PhotoPreviewCell.animationOptionGif : PhotoPreviewCell.animationOption)
        }
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        addSubview(bannerImgView)
        
        bannerImgView.snp.makeConstraints { (maker) in
            maker.edges.equalToSuperview()
        }
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
