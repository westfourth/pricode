//
//  PhotoPreviewLockView.swift
//  Sp
//
//  Created by mac on 2020/9/12.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

protocol PhotoPreviewLockViewDelegate: NSObjectProtocol {
    
    func hideLockView()
    
}

class PhotoPreviewLockView: UIView {
    
    static let maxLockNum: Int = 3
    
    private static let cancelImg: UIImage? = {
        return UIImage(named: "photo_preview_lock_cancel_btn")
    }()
    
    private static let confirmImg: UIImage? = {
        return UIImage(named: "photo_preview_lock_confirm_btn")
    }()
    
    private lazy var firstLabel: UILabel = {
        let label = UILabel()
        label.text = "非\(Sensitive.hui)可免費觀看\(PhotoPreviewLockView.maxLockNum)張寫真"
        label.textColor = .white
        label.font = UIFont.pingFangRegular(20)
        label.textAlignment = .center
        return label
    }()
    
    private lazy var secondLabel: UILabel = {
        let label = UILabel()
        label.text = "開通\(Sensitive.hui)，即可觀看所有寫真哦！"
        label.textColor = .white
        label.font = UIFont.pingFangRegular(20)
        label.textAlignment = .center
        return label
    }()
    
    private lazy var cancelBtn: UIButton = {
        let btn = UIButton()
        btn.setBackgroundImage(PhotoPreviewLockView.cancelImg, for: .normal)
        btn.addTarget(self, action: #selector(onCancelBtn), for: .touchUpInside)
        return btn
    }()
    
    private lazy var confirmBtn: UIButton = {
        let btn = UIButton()
        btn.setBackgroundImage(PhotoPreviewLockView.confirmImg, for: .normal)
        btn.addTarget(self, action: #selector(onConfirmBtn), for: .touchUpInside)
        return btn
    }()
    
    weak var delegate: PhotoPreviewLockViewDelegate?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        alpha = 0
        backgroundColor = UIColor.black.withAlphaComponent(0.76)
        renderView()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func renderView() {
        addSubview(secondLabel)
        addSubview(firstLabel)
        addSubview(cancelBtn)
        addSubview(confirmBtn)
        
        secondLabel.snp.makeConstraints { (make) in
            make.centerY.left.right.equalToSuperview()
        }
        
        firstLabel.snp.makeConstraints { (make) in
            make.bottom.equalTo(secondLabel.snp.top).offset(-20)
            make.left.right.equalToSuperview()
        }
        
        cancelBtn.snp.makeConstraints { (make) in
            make.top.equalTo(secondLabel.snp.bottom).offset(50)
            make.centerX.equalToSuperview().offset(-80)
            make.width.equalTo(117)
            make.height.equalTo(39)
        }
        
        confirmBtn.snp.makeConstraints { (make) in
            make.top.size.equalTo(cancelBtn)
            make.centerX.equalToSuperview().offset(80)
        }
    }
    
    @objc private func onCancelBtn() {
        delegate?.hideLockView()
    }
    
    @objc private func onConfirmBtn() {
        guard let currentNavigationController = (UIApplication.shared.delegate as? AppDelegate)?.currentNavigationController else { return }
        VipChargeTipVC.isFromVideoPlayList = false
        currentNavigationController.show(Vip2VC(), sender: nil)
    }
    
}
