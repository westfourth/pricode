//
//  PhotoVC.swift
//  Sp
//
//  Created by mac on 2020/8/18.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class PhotoVC: UIViewController {
    
    private static let titleIcon: UIImage? = {
        return UIImage(named: "photo_title_icon")
    }()
    
    private lazy var titleView: UIButton = {
        let btn = UIButton()
        btn.setTitle("女神寫真", for: .normal)
        btn.titleLabel?.font = UIFont.pingFangMedium(18)
        btn.setTitleColor(.white, for: .normal)
        btn.setImage(PhotoVC.titleIcon, for: .normal)
        btn.imagePosition(imageStyle: .left, spacing: 5)
        return btn
    }()
    
    private lazy var collectionView: UICollectionView = {
        let layout = UICollectionViewFlowLayout()
        layout.sectionInset = UIEdgeInsets(top: 0, left: 12, bottom: 0, right: 12)
        layout.itemSize = CGSize(width: PhotoCell.viewWidth, height: PhotoCell.viewHeight)
        layout.minimumLineSpacing = 12
        layout.minimumInteritemSpacing = 4
        let cv = UICollectionView(frame: .zero, collectionViewLayout: layout)
        cv.register(PhotoCell.self, forCellWithReuseIdentifier: "PhotoCell")
        cv.backgroundColor = .none
        cv.delegate = self
        cv.dataSource = self
        cv.showsVerticalScrollIndicator = false
        cv.showsHorizontalScrollIndicator = false
        cv.state = .loading
        cv.mj_header = getCommonMJHeader(refreshingTarget: self, headerRefreshCallback: #selector(onRefresh))
        cv.mj_footer = getCommonMJFooter(refreshingTarget: self, footerRefreshCallback: #selector(onLoad))
        return cv
    }()
    
    private lazy var emptyImg: UIImage = {
        return UIImage()
    }()
    
    private var listData: [PortrayItem] = []
    
    private lazy var pageNum: Int = 0

    override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: Bundle?) {
        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
        hidesBottomBarWhenPushed = true
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = RGB(0x141516)
        view.addSubview(titleView)
        view.addSubview(collectionView)
        
        titleView.snp.makeConstraints { (make) in
            make.top.equalToSuperview().inset(kTop - 32.5)
            make.left.right.equalToSuperview()
            make.height.equalTo(25)
        }
        
        collectionView.snp.makeConstraints { (make) in
            make.top.equalToSuperview().inset(kTop + 10)
            make.left.right.bottom.equalToSuperview()
        }
        
        getList(isRefresh: true)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.navigationBar.isTranslucent = true
        navigationController?.navigationBar.setBackgroundImage(emptyImg, for: .default)
        navigationController?.navigationBar.shadowImage = emptyImg
        getUserinfo()
    }
    
    private func getList(isRefresh: Bool) {
        collectionView.state = listData.isEmpty ? .loading : .normal
        let req = RecommendPortrayReq()
        let pageNum = self.pageNum
        req.page = isRefresh ? 1 : pageNum + 1
        if isRefresh {
            collectionView.mj_footer?.resetNoMoreData()
        }
        let collectionView = self.collectionView
        Session.request(req) { [weak self] (error, resp) in
            isRefresh ? collectionView.mj_header?.endRefreshing() : collectionView.mj_footer?.endRefreshing()
            guard let `self` = self else { return }
            guard error == nil, let resData = resp as? [PortrayItem] else {
                self.handleListException(isRefresh: isRefresh, pageNum: pageNum)
                return
            }
            self.pageNum = req.page
            self.listData = isRefresh ? resData : self.listData + resData
            let isEmpty = self.listData.isEmpty
            collectionView.state = isEmpty ? .empty : .normal
            collectionView.mj_footer?.isHidden = isEmpty
            collectionView.reloadData()
            if resData.count < req.pageSize {
                collectionView.mj_footer?.endRefreshingWithNoMoreData()
            }
        }
    }
    
    private func handleListException(isRefresh: Bool, pageNum: Int) {
        if isRefresh || pageNum == 1 {
            collectionView.state = .failed
            collectionView.mj_footer?.isHidden = true
            collectionView.reloadData()
        } else {
            collectionView.state = .normal
            collectionView.mj_footer?.endRefreshingWithNoMoreData()
            collectionView.mj_footer?.isHidden = false
        }
    }
    
    @objc private func onLoad() {
        getList(isRefresh: false)
    }
    
    @objc private func onRefresh() {
        getList(isRefresh: true)
    }
    
    private func getUserinfo() {
        Session.request(FetchUserInfoReq()) { (error, resp) in }
    }
}

extension PhotoVC: UICollectionViewDelegate, UICollectionViewDataSource {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return listData.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "PhotoCell", for: indexPath) as! PhotoCell
        cell.dataModel = listData[indexPath.row]
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let currentData = listData[indexPath.row]
        let photoPreviewVC = PhotoPreviewVC()
        photoPreviewVC.titleLabel.text = currentData.nickName
        photoPreviewVC.userId = currentData.userId
        photoPreviewVC.portrayId = currentData.portrayId
        photoPreviewVC.descLabel.text = currentData.title
        navigationController?.show(photoPreviewVC, sender: nil)
    }
}
