//
//  ChooseCitySectionHeaderView.swift
//  Sp
//
//  Created by mac on 2020/6/17.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class ChooseCitySectionHeaderView: UIView {
    
    lazy var titleLabel: UILabel = {
        let label = UILabel()
        label.textColor = RGB(0xB0B1B4)
        label.font = UIFont.pingFangMedium(16)
        return label
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = UIColor.black.withAlphaComponent(0.2)
        addSubview(titleLabel)
        titleLabel.snp.makeConstraints { (make) in
            make.top.bottom.equalToSuperview()
            make.left.right.equalToSuperview().inset(12)
        }
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}
