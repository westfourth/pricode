//
//  ChooseCityHotCityCell.swift
//  Sp
//
//  Created by mac on 2020/6/17.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

protocol ChooseCityHotCityCellDelegate: NSObjectProtocol {
    
    func chosenCity(cityItem: CityItem)
    
}

class ChooseCityHotCityCell: UITableViewCell {
    
    static let viewHeight: CGFloat = ChooseCityHotCityCell.marginTop + ChooseCityHotCityCell.titleBarHeight + CGFloat(ChooseCityHotCityCell.maxItemCellNum) / ChooseCityHotCityCell.columnNum * ChooseCityHotCityCell.itemHeight + 20
    static let marginTop: CGFloat = ChooseCityVC.searchBarHeight
    
    private static let titleBarHeight: CGFloat = 25
    
    private static let itemWidth: CGFloat = (UIScreen.main.bounds.width - ChooseCityHotCityCell.horizontalMargin * 2 - (ChooseCityHotCityCell.columnNum - 1) * ChooseCityHotCityCell.itemInteritemSpacing) / ChooseCityHotCityCell.columnNum
    
    private static let columnNum: CGFloat = 3
    
    private static let horizontalMargin: CGFloat = 13
    
    private static let itemHeight: CGFloat = 28
    
    private static let itemSize: CGSize = CGSize(width: ChooseCityHotCityCell.itemWidth, height: ChooseCityHotCityCell.itemHeight)
    
    private static let sectionInset: UIEdgeInsets = UIEdgeInsets(top: 0, left: ChooseCityHotCityCell.horizontalMargin - 8, bottom: 0, right: ChooseCityHotCityCell.horizontalMargin - 8)
    
    private static let itemInteritemSpacing: CGFloat = 6
    
    private static let maxItemCellNum: Int = 9
    
    private static let hotImg: UIImage? = {
        let image = UIImage(named: "choose_city_hot_icon")
        return image
    }()
    
    private lazy var hotImgView: UIImageView = {
        let imgView = UIImageView(image: ChooseCityHotCityCell.hotImg)
        return imgView
    }()
    
    private lazy var titleLabel: UILabel = {
        let label = UILabel()
        label.text = "熱門城市"
        label.textColor = .white
        label.font = UIFont.pingFangRegular(12)
        return label
    }()
    
    private lazy var collectionView: UICollectionView = {
        let layout = UICollectionViewFlowLayout()
        layout.itemSize = ChooseCityHotCityCell.itemSize
        layout.minimumLineSpacing = 5
        layout.minimumInteritemSpacing = ChooseCityHotCityCell.itemInteritemSpacing
        layout.sectionInset = ChooseCityHotCityCell.sectionInset
        let cv = UICollectionView(frame: .zero, collectionViewLayout: layout)
        cv.register(ChooseCityHotCitySubCell.self, forCellWithReuseIdentifier: "ChooseCityHotCitySubCell")
        cv.backgroundColor = .none
        cv.isScrollEnabled = false
        cv.bounces = false
        cv.bouncesZoom = false
        cv.delegate = self
        cv.dataSource = self
        return cv
    }()
    
    private var isInitState: Bool = true
    
    weak var delegate: ChooseCityHotCityCellDelegate?
    
    var listData: [CityItem] = [] {
        didSet {
            guard isInitState, !listData.isEmpty else { return }
            isInitState = false
            let maxNum = ChooseCityHotCityCell.maxItemCellNum
            listData = listData.count > maxNum ? Array(listData[0..<maxNum]) : listData
            collectionView.reloadData()
        }
    }
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        backgroundColor = .none
        selectionStyle = .none
        renderView()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func renderView() {
        contentView.addSubview(hotImgView)
        contentView.addSubview(titleLabel)
        contentView.addSubview(collectionView)
        
        hotImgView.snp.makeConstraints { (make) in
            make.left.equalToSuperview().inset(12)
            make.top.equalToSuperview().inset(ChooseCityHotCityCell.marginTop)
            make.width.equalTo(11)
            make.height.equalTo(14)
        }
        
        titleLabel.snp.makeConstraints { (make) in
            make.left.equalTo(hotImgView.snp.right).offset(5)
            make.centerY.equalTo(hotImgView)
        }
        
        collectionView.snp.makeConstraints { (make) in
            make.top.equalToSuperview().inset(ChooseCityHotCityCell.titleBarHeight + ChooseCityHotCityCell.marginTop)
            make.left.right.bottom.equalToSuperview()
        }
    }
    
}

extension ChooseCityHotCityCell: UICollectionViewDelegate, UICollectionViewDataSource {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return listData.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "ChooseCityHotCitySubCell", for: indexPath) as! ChooseCityHotCitySubCell
        cell.titleLabel.text = listData[indexPath.row].name
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        delegate?.chosenCity(cityItem: listData[indexPath.row])
    }
}
