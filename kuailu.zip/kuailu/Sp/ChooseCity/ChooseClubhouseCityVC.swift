//
//  ChooseClubhouseCityVC.swift
//  Sp
//
//  Created by mac on 2020/9/29.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class ChooseClubhouseCityVC: UIViewController {
    
    private static let letterMaxLen: Int = 26
    
    private static let letterIndexOffset: Int = 65
    
    private static var indexLetterArr: [String] = []
    
    private static var hotCityList: [CityItem] = []
    
    private static var cityList: [[CityItem]] = []
    
    private static var rawCityList: [CityItem] = []
    
    private static var sectionHeaderViewList: [UIView?] = []
    
    private static let maxKeyWordsLen: Int = 15
    
    private static let searchBarHeight: CGFloat = 30
    
    private static let searchImg: UIImage? = {
        return  UIImage(named: "search_icon_white")
    }()
    
    private lazy var searchImgView: UIImageView = {
        return UIImageView(image: ChooseClubhouseCityVC.searchImg)
    }()
    
    private lazy var inputField: UITextField = {
        let input  = UITextField()
        input.delegate = self
        let font = UIFont.pingFangRegular(13)
        input.font = font
        input.textColor = .white
        input.placeholder = "搜索位置（最長\(ChooseClubhouseCityVC.maxKeyWordsLen)個字符）"
        input.setValue(RGB(0xA3A4A9), forKeyPath: "placeholderLabel.textColor")
        input.setValue(font, forKeyPath: "placeholderLabel.font")
        input.textAlignment = .left
        input.clearButtonMode = .whileEditing
        input.addDoneOnKeyboardWithTarget(self, action: #selector(onDoneKeyboardTap))
        input.addTarget(self, action: #selector(onInputFieldChanged), for: .editingChanged)
        input.returnKeyType = .done
        return input
    }()
    
    private lazy var searchBarView: UIView = {
        let view = UIView()
        view.backgroundColor = RGB(0x2B2C36)
        view.layer.cornerRadius = ChooseClubhouseCityVC.searchBarHeight / 2
        view.clipsToBounds = true
        view.addSubview(searchImgView)
        view.addSubview(inputField)
        
        searchImgView.snp.makeConstraints { (make) in
            make.left.equalToSuperview().inset(12)
            make.centerY.equalToSuperview()
            make.size.equalTo(15)
        }
        
        inputField.snp.makeConstraints { (make) in
            make.left.equalTo(searchImgView.snp.right).offset(6)
            make.top.right.bottom.equalToSuperview()
        }
        return view
    }()
    
    private lazy var listTableView: UITableView = {
        let tableView = UITableView(frame: .zero, style: .plain)
        tableView.delegate = self
        tableView.dataSource = self
        tableView.backgroundColor = .none
        tableView.separatorStyle = .none
        tableView.bouncesZoom = false
        tableView.sectionIndexColor = RGB(0xB0B1B4)
        tableView.sectionFooterHeight = .leastNonzeroMagnitude
        tableView.register(ChooseCityHotCityCell.self, forCellReuseIdentifier: "ChooseCityHotCityCell")
        tableView.register(ChooseCityCell.self, forCellReuseIdentifier: "ChooseCityCell")
        tableView.state = ChooseClubhouseCityVC.indexLetterArr.isEmpty ? .loading : .normal
        return tableView
    }()
    
    private lazy var searchTableView: UITableView = {
        let tableView = UITableView(frame: .zero, style: .plain)
        tableView.delegate = self
        tableView.dataSource = self
        tableView.backgroundColor = RGB(0x141516)
        tableView.separatorStyle = .none
        tableView.bouncesZoom = false
        tableView.sectionFooterHeight = .leastNonzeroMagnitude
        tableView.register(ChooseCityCell.self, forCellReuseIdentifier: "ChooseCityCell")
        tableView.isHidden = true
        return tableView
    }()
    
    private var searchList: [CityItem] = []
    
    weak var delegate: ChooseCityVCDelegate?
    
    var chosenCityClosure: ((_ cityItem: CityItem) -> ())?
    
    override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: Bundle?) {
        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
        hidesBottomBarWhenPushed = true
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        if #available(iOS 11.0, *) {
            listTableView.contentInsetAdjustmentBehavior = .never
        } else {
            automaticallyAdjustsScrollViewInsets = false
        }
        navigationItem.title = "切換城市"
        view.backgroundColor = RGB(0x141516)
        view.addSubview(listTableView)
        view.addSubview(searchBarView)
        view.addSubview(searchTableView)
        
        searchBarView.snp.makeConstraints { (make) in
            make.top.equalToSuperview().inset(15)
            make.left.right.equalToSuperview().inset(12)
            make.height.equalTo(ChooseClubhouseCityVC.searchBarHeight)
        }
        
        listTableView.snp.makeConstraints { (make) in
            make.top.equalTo(searchBarView.snp.bottom)
            make.left.right.bottom.bottom.equalToSuperview()
        }
        
        searchTableView.snp.makeConstraints { (make) in
            make.edges.equalTo(listTableView)
        }
        
        getList()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.navigationBar.setBackgroundImage(nil, for: .default)
        navigationController?.navigationBar.barTintColor = RGB(0x141516)
        navigationController?.navigationBar.isTranslucent = false
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        chosenCityClosure = nil
    }
    
    deinit {
        chosenCityClosure = nil
    }
    
    private func getList() {
        guard ChooseClubhouseCityVC.cityList.isEmpty else { return }
        let tableView = self.listTableView
        Session.request(ClubhouseCityListReq()) { [weak self] (error, resp) in
            guard let `self` = self else { return }
            guard error == nil, let resData = resp as? CityListResp else {
                ChooseClubhouseCityVC.hotCityList = []
                ChooseClubhouseCityVC.cityList = []
                ChooseClubhouseCityVC.rawCityList = []
                ChooseClubhouseCityVC.indexLetterArr = []
                ChooseClubhouseCityVC.sectionHeaderViewList = []
                self.searchList = []
                tableView.reloadData()
                tableView.state = .failed
                return
            }
            var indexLetterArr: [String] = Array(repeating: "", count: ChooseClubhouseCityVC.letterMaxLen)
            var cityList: [[CityItem]] = Array(repeating: [], count: ChooseClubhouseCityVC.letterMaxLen)
            let letterIndexOffset = ChooseClubhouseCityVC.letterIndexOffset
            for i in 0..<resData.listRegion.count {
                let letter = resData.listRegion[i].initial.uppercased()
                for scalar in letter.unicodeScalars {
                    let index = Int(scalar.value) - letterIndexOffset
                    indexLetterArr[index] = letter
                    cityList[index].append(resData.listRegion[i])
                }
            }
            ChooseClubhouseCityVC.sectionHeaderViewList = []
            if !resData.listHot.isEmpty {
                ChooseClubhouseCityVC.hotCityList = resData.listHot
                indexLetterArr.insert("#", at: 0)
                cityList.insert([CityItem()], at: 0)
                ChooseClubhouseCityVC.sectionHeaderViewList.append(nil)
            }
            ChooseClubhouseCityVC.rawCityList = resData.listRegion
            ChooseClubhouseCityVC.indexLetterArr = indexLetterArr.filter { !$0.isEmpty }
            ChooseClubhouseCityVC.cityList = cityList.filter { !$0.isEmpty }
            self.getSectionHeaderView()
            tableView.state = ChooseClubhouseCityVC.cityList.isEmpty ? .empty : .normal
            tableView.reloadData()
        }
    }
    
    private func getSearchCitysList(text: String) {
        searchTableView.isHidden = false
        searchList = []
        ChooseClubhouseCityVC.rawCityList.forEach {
            if $0.name.contains(text) || $0.pinyin.contains(text.lowercased()) || text.contains($0.name) || text.lowercased().contains($0.pinyin) {
                searchList.append($0)
            }
        }
        searchTableView.reloadData()
    }
    
    private func getSectionHeaderView() {
        let startIndex: Int = ChooseClubhouseCityVC.hotCityList.isEmpty ? 0 : 1
        for i in startIndex..<ChooseClubhouseCityVC.indexLetterArr.count {
            let headerView = ChooseCitySectionHeaderView()
            headerView.titleLabel.text = ChooseClubhouseCityVC.indexLetterArr[i]
            ChooseClubhouseCityVC.sectionHeaderViewList.append(headerView)
        }
    }
    
    private func chosenCityCallback(cityItem: CityItem) {
        chosenCityClosure?(cityItem)
        delegate?.chosenCity(cityItem: cityItem)
        navigationController?.popViewController(animated: true)
    }
    
    @objc private func onDoneKeyboardTap() {
        inputField.resignFirstResponder()
        onInputFieldChanged()
    }
    
    @objc private func onInputFieldChanged() {
        guard !ChooseClubhouseCityVC.rawCityList.isEmpty, let val = inputField.text?.trimmingCharacters(in: .whitespacesAndNewlines), !val.isEmpty else {
            searchTableView.isHidden = true
            searchList = []
            searchTableView.reloadData()
            return
        }
        getSearchCitysList(text: val)
    }
    
}

extension ChooseClubhouseCityVC: UITableViewDelegate, UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return tableView == listTableView ? ChooseClubhouseCityVC.cityList.count : 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return tableView == listTableView ? (section == 0 && !ChooseClubhouseCityVC.hotCityList.isEmpty ? 1 : ChooseClubhouseCityVC.cityList[section].count) : searchList.count
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return tableView == listTableView ? (section == 0 && !ChooseClubhouseCityVC.hotCityList.isEmpty ? 0 : 35) : 0
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        return tableView == listTableView ? ChooseClubhouseCityVC.sectionHeaderViewList[section] : nil
    }
    
    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        return nil
    }
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return tableView == listTableView ? ChooseClubhouseCityVC.indexLetterArr[section] : nil
    }
    
    func sectionIndexTitles(for tableView: UITableView) -> [String]? {
        return tableView == listTableView ? ChooseClubhouseCityVC.indexLetterArr : nil
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return tableView == listTableView ? (indexPath.section == 0 && !ChooseClubhouseCityVC.hotCityList.isEmpty ? ChooseCityHotCityCell.viewHeight : ChooseCityCell.viewHeight) : ChooseCityCell.viewHeight
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard tableView == listTableView else {
            let cell = tableView.dequeueReusableCell(withIdentifier: "ChooseCityCell", for: indexPath) as! ChooseCityCell
            cell.cityNameLabel.text = searchList[indexPath.row].name
            return cell
        }
        guard !(indexPath.section == 0 && !ChooseClubhouseCityVC.hotCityList.isEmpty) else {
            let cell = tableView.dequeueReusableCell(withIdentifier: "ChooseCityHotCityCell", for: indexPath) as! ChooseCityHotCityCell
            cell.delegate = self
            cell.listData = ChooseClubhouseCityVC.hotCityList
            return cell
        }
        let cell = tableView.dequeueReusableCell(withIdentifier: "ChooseCityCell", for: indexPath) as! ChooseCityCell
        cell.cityNameLabel.text = ChooseClubhouseCityVC.cityList[indexPath.section][indexPath.row].name
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        guard tableView == listTableView else {
            chosenCityCallback(cityItem: searchList[indexPath.row])
            return
        }
        guard !(indexPath.section == 0 && !ChooseClubhouseCityVC.hotCityList.isEmpty) else { return }
        chosenCityCallback(cityItem: ChooseClubhouseCityVC.cityList[indexPath.section][indexPath.row])
    }
}

extension ChooseClubhouseCityVC: UITextFieldDelegate {
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        inputField.resignFirstResponder()
        onInputFieldChanged()
        return true
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        let len = textField.text!.count + string.count - range.length
        guard len <= ChooseClubhouseCityVC.maxKeyWordsLen else {
            mm_showToast(inputField.placeholder!)
            return false
        }
        return true
    }
    
}

extension ChooseClubhouseCityVC: ChooseCityHotCityCellDelegate {
    
    func chosenCity(cityItem: CityItem) {
        chosenCityCallback(cityItem: cityItem)
    }
    
}
