//
//  ChooseCityCell.swift
//  Sp
//
//  Created by mac on 2020/6/17.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class ChooseCityCell: UITableViewCell {
    
    static let viewHeight: CGFloat = 50
    
    lazy var cityNameLabel: UILabel = {
        let label = UILabel()
        label.textColor = RGB(176, 177, 180)
        label.font = UIFont.pingFangRegular(16)
        return label
    }()
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        backgroundColor = .none
        selectionStyle = .none
        addSubview(cityNameLabel)
        cityNameLabel.snp.makeConstraints { (make) in
            make.left.right.equalToSuperview().inset(12)
            make.centerY.equalToSuperview()
        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}
