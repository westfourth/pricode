//
//  FullCenterView.swift
//  Sp
//
//  Created by mac on 2021/1/13.
//  Copyright © 2021 mac. All rights reserved.
//

import UIKit

class FullCenterView: UIView {
    
    @IBOutlet weak var playButton: UIImageView!
    
    @IBOutlet weak var progressLabel: UILabel!
    
     var tapAction: (() -> ())?
    
    @IBAction func tapAction(_ sender: UITapGestureRecognizer) {
        self.tapAction?()
    }
    
}
