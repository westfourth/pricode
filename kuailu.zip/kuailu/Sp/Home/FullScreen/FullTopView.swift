//
//  FullTopView.swift
//  Sp
//
//  Created by mac on 2021/1/12.
//  Copyright © 2021 mac. All rights reserved.
//

import UIKit

class FullTopView: UIView {
    
    @IBOutlet weak var name: UILabel!
    
    @IBOutlet weak var back: UIButton!
    
     var backAction: (() -> ())?
    
    @IBAction func dismissAction(_ sender: UITapGestureRecognizer) {
        if sender.location(in: self).x  < UIScreen.main.bounds.height / 2.0{
            self.backAction?()
        }
    }
    
    @IBAction func backAction(_ sender: Any) {
        self.backAction?()
    }
}
