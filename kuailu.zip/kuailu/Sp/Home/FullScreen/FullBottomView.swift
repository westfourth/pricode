//
//  FullBottomView.swift
//  Sp
//
//  Created by mac on 2021/1/12.
//  Copyright © 2021 mac. All rights reserved.
//

import UIKit
import AVFoundation

class FullBottomView: UIView {
    
    var isSliding:Bool = false {
        didSet {
            let v = self.superview as! ShortVideoFullPlayView
            v.isClearMode = !isSliding
        }
    }
    
    private var currentTime: CMTime = CMTime.zero
    private var duration: CMTime = CMTime.zero
    weak var delegate: FullBottomViewDelegate?
    
    
    @IBOutlet weak var currentProgressTime: UILabel!
    @IBOutlet weak var slider: UISlider!
    @IBOutlet weak var totalTime: UILabel!
    @IBOutlet weak var exitFull: UIButton!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        slider.setThumbImage(UIImage(), for: .normal)
        
        addSubview(loadingView)
    }
    
    
    override func layoutSubviews() {
        super.layoutSubviews()
        loadingView.frame = CGRect(x: bounds.width / 2.0 - 0.5, y: bounds.height / 2.0 + 1.0,
                                   width: 1, height: 3);
    }
    
    //  加载动画
    lazy var loadingView: FullLineLoadingView = {
        let view = FullLineLoadingView()
        return view
    }()
    
    //  更新播放状态
    var timeControlStatus: AVPlayer.TimeControlStatus? {
        didSet {
            //  暂停时，也显示原点。
            slider.isHighlighted = timeControlStatus == .paused ? true : false
            //
            if timeControlStatus == .waitingToPlayAtSpecifiedRate {
                loadingView.startAnimation()
            } else {
                loadingView.stopAnimation()
            }
        }
    }
    
    //  更新进度
    func updateProgress(currentTime: CMTime, duration: CMTime) {
        if isSliding {      //  正在滑動不需要設定
            return;
        }
        self.currentTime = currentTime
        
        if duration != .zero && !duration.isIndefinite {
            let totalSeconds = Int(duration.value) / Int(duration.timescale)
            totalTime.text = ShortVideoCell.durationMMSS(TimeInterval(totalSeconds))
        }
        if currentTime != .zero && !currentTime.isIndefinite  {
            let currentSeconds:Int = Int(currentTime.value) / Int(currentTime.timescale)
            currentProgressTime.text = ShortVideoCell.durationMMSS(TimeInterval(currentSeconds))
        }
        self.duration = duration
        if duration == .zero || duration.isIndefinite || currentTime == .zero  {
            slider.value = 0
            slider.maximumValue = 1;
        } else {
            self.slider.maximumValue = Float(CMTimeGetSeconds(duration))
            UIView.beginAnimations(nil, context: nil)
            UIView.setAnimationDuration(0.5 + 0.25)
            self.slider.setValue(Float(CMTimeGetSeconds(currentTime)), animated: true)
            UIView.commitAnimations()
        }
    }
    
    // MARK: -  滑动条事件
    
    @IBAction func sliderTouchBegin() {
        isSliding = true
        if duration != .zero && !duration.isIndefinite {
            guard let v = centerView() else {return}
            v.progressLabel.isHidden = false
        }
    }
    
    @IBAction func sliderTouchChange() {
        if duration != .zero && !duration.isIndefinite {
            let currentTimeText = ShortVideoCell.durationText(TimeInterval(slider.value))
            currentProgressTime.text = ShortVideoCell.durationMMSS(TimeInterval(slider.value))
            guard let v = centerView() else {return}
            v.progressLabel.text = currentTimeText
        }
    }
    
    @IBAction func sliderTouchEnd() {
        let destTime = CMTimeMake(value: Int64(slider.value), timescale: 1)
        delegate?.fullBottomView(self, seekToTime: destTime, completion: {
            self.isSliding = false
            guard let v = self.centerView() else {return}
            v.progressLabel.isHidden = true
        })
    }
    
    @IBAction func sliderTouchCancel() {
        isSliding = false
        guard let v = centerView() else {return}
        v.progressLabel.isHidden = true
    }
    
    
    func centerView()->FullCenterView? {
        for v in self.superview!.subviews {
            if v is FullCenterView {
                return (v as! FullCenterView)
            }
        }
        return nil
    }
}



protocol FullBottomViewDelegate: NSObjectProtocol {
    //  拖动进度条
    func fullBottomView(_ fullBottomView: FullBottomView, seekToTime time: CMTime, completion: @escaping () -> Void)
}




class FullLineLoadingView: UIView {
    
    override init(frame: CGRect) {
        super.init(frame: frame)
//        object_setClass(layer, CAGradientLayer.self)
//        let glayer = layer as! CAGradientLayer
//        glayer.colors = [UIColor.red.cgColor,UIColor.blue.cgColor,UIColor.orange.cgColor]
//        glayer.startPoint = CGPoint(x: 0, y: 0)
//        glayer.endPoint = CGPoint(x: 1, y: 1)
        backgroundColor = UIColor.white.withAlphaComponent(0.7)
        self.isHidden = true
    }
    
     func startAnimation() {
        self.isHidden = false
        let animationG = CAAnimationGroup()
        animationG.duration = 0.5
        animationG.beginTime = CACurrentMediaTime()
        animationG.repeatCount = MAXFLOAT
        animationG.timingFunction = CAMediaTimingFunction(name: CAMediaTimingFunctionName.easeInEaseOut)
        
        // x轴缩放动画（transform.scale是以view的中心点为中心开始缩放的）
        let scaleAnimation = CABasicAnimation()
        scaleAnimation.keyPath = "transform.scale.x"
        scaleAnimation.fromValue = 1.0
        scaleAnimation.toValue = 1.0 * 896
        
        // 透明度渐变动画
        let alphaAnimation = CABasicAnimation()
        alphaAnimation.keyPath = "opacity"
        alphaAnimation.fromValue = 1.0
        alphaAnimation.toValue = 0.5
        
        
//        let backAnimation = CABasicAnimation()
//        backAnimation.keyPath = "backgroundColor"
//        backAnimation.fromValue = UIColor.randomColor().cgColor
//        backAnimation.toValue = UIColor.randomColor().cgColor
        
        animationG.animations = [scaleAnimation, alphaAnimation]
        
        self.layer.add(animationG, forKey: nil)
    }
    
     func stopAnimation() {
        self.layer.removeAllAnimations()
        self.isHidden = true
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}


