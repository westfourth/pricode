//
//  ShortVideoFullPlayView.swift
//  Sp
//
//  Created by mac on 2021/1/12.
//  Copyright © 2021 mac. All rights reserved.
//

import UIKit
import AVKit

class ShortVideoFullPlayView: UIView, FullNeedPayDelegate {
    
    var player: AVPlayer = AVPlayer(playerItem: nil)
    //  观影进度
    var periodicTimeObserver: Any?
    
    weak var delegate:ShortVideoFullPlayViewDelegate?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        layoutUI()
    }
    
    func layoutUI() {
        
        addSubview(playView)
        
        addSubview(topView)
        addSubview(centerView)
        addSubview(bottomView)
        
        playView.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
        
        let sliderHeight :CGFloat = 30
        let gap:CGFloat = 20
        topView.snp.makeConstraints { (make) in
            make.left.right.equalToSuperview()
            make.top.equalTo(gap)
            make.height.equalTo(sliderHeight)
        }

        bottomView.snp.makeConstraints { (make) in
            make.left.right.equalToSuperview()
            make.bottom.equalTo(-gap)
            make.height.equalTo(sliderHeight)
        }
        
        centerView.snp.makeConstraints { (make) in
            make.left.right.equalToSuperview()
            make.top.equalTo(topView.snp.bottom)
            make.bottom.equalTo(bottomView.snp.top)
        }
        
        isClearMode = false

    }
    
    func updatelayout() {
        playView.snp.remakeConstraints { (make) in
            make.edges.equalToSuperview()
        }
        
        let sliderHeight :CGFloat = 30
        let gap:CGFloat = 20
        topView.snp.remakeConstraints { (make) in
            make.left.right.equalToSuperview()
            make.top.equalTo(gap)
            make.height.equalTo(sliderHeight)
        }

        bottomView.snp.remakeConstraints { (make) in
            make.left.right.equalToSuperview()
            make.bottom.equalTo(-gap)
            make.height.equalTo(sliderHeight)
        }
        
        centerView.snp.remakeConstraints { (make) in
            make.left.right.equalToSuperview()
            make.top.equalTo(topView.snp.bottom)
            make.bottom.equalTo(bottomView.snp.top)
        }
    }
    
    func startPlayItem(model: ShortVideoModel) {
        player.replaceCurrentItem(with: model.playerItem?.copy() as! AVPlayerItem)   //  載入視頻
        (playView.layer as! AVPlayerLayer).player = player
        //  播放进度
        if model.playerItem  != nil {
            let playerItem = model.playerItem!
            bottomView.updateProgress(currentTime: playerItem.currentTime(), duration: playerItem.duration)
        } else {
            bottomView.updateProgress(currentTime: .zero, duration: .zero)
        }
        
        if  model.lastPlayTime?.isValid == true {
            player.currentItem?.cancelPendingSeeks()
            player.currentItem?.seek(to: model.lastPlayTime!, completionHandler: {[weak self] (finished) in
                self?.player.play()
            })
        } else {
            player.play()
        }
        
        if let videoItem = model.videoItem {
            Defaults.saveShortWatch(videoItem)
        }
        
        if let videoUrl = model.videoItem?.videoUrl,
            videoUrl.absoluteString.contains("/dynamic?path=") {
            model.responseWatchType = .canWatch
            model.watchType = .free
        } else {
            //  获取播放权限
            model.playPrediction()
        }
        
        //  如果非会员，播放次数-1（广告不计入观看次数）
        if let _ = model.videoItem, let userInfo = NetDefaults.userInfo {
            if userInfo.freeWatches != -1 {    //  -1表示無限觀看次數
                if userInfo.watched < userInfo.freeWatches {
                    userInfo.watched += 1
                    NetDefaults.userInfo = userInfo
                }
            }
        }
    }
    
    func endPlayItem(model: ShortVideoModel) {
        print(">>> endPlayItem")
        /// 上报观影记录
        model.lastPlayTime = player.currentTime()
        let value = CMTimeGetSeconds(player.currentTime())
        if !value.isNaN && !model.playEnded {
            let seconds = Int(value)
            model.uploadWatchRecord(seconds)
        }
        player.replaceCurrentItem(with: nil)
    }
    
    deinit {
        player.removeObserver(self, forKeyPath: #keyPath(AVPlayer.timeControlStatus))
        player.removeTimeObserver(periodicTimeObserver!)
        NotificationCenter.default.removeObserver(self)
    }
    
    var model:ShortVideoModel? {
        didSet {
            guard let model = model else {return}
            loadDisCountData()
            setNotification()
            // 播放权限判断 有可能在竖屏的时候就已经获取到了 所以不用重复处理
            if model.responseWatchType != .none {
                model.playPrediction()
            }
            //开始播放
            startPlayItem(model: model)
        }
    }
    
    var timer:Timer?
    
    @objc func show5Seconds() {
        timer?.invalidate()
        timer = Timer(timeInterval: 6.0, repeats: true, block: { [weak self] (t) in
            self?.timer?.invalidate()
            self?.isClearMode = true
        })
        RunLoop.main.add(timer!, forMode: .default)
    }
    
    // 清爽模式
    var isClearMode:Bool = false {
        didSet {
            topView.isHidden = isClearMode
            bottomView.totalTime.isHidden = isClearMode
            bottomView.slider.isHidden = isClearMode
            bottomView.currentProgressTime.isHidden = isClearMode
            bottomView.exitFull.isHidden = isClearMode
            if !isClearMode {
                show5Seconds()
            }
        }
    }
    
    func setNotification() {
        
        topView.name.text = model!.videoItem!.title
        
        bottomView.exitFull.addTarget(self, action: #selector(self.dismiss), for: .touchUpInside)
        
        //  监听播放结束
        NotificationCenter.default.addObserver(self, selector: #selector(playerItemDidPlayToEndTime(noti:)), name: .AVPlayerItemDidPlayToEndTime, object: nil)
        //  监听播放器状态
        player.addObserver(self, forKeyPath: #keyPath(AVPlayer.timeControlStatus), options: .new, context: nil)
        //  监听播放进度
        periodicTimeObserver = player.addPeriodicTimeObserver(forInterval: CMTimeMake(value: 1, timescale: 2), queue: DispatchQueue.main, using: {[weak self] (currentTime) in
            self?.periodicObserveCurrentTime(currentTime: currentTime)
        });
    }
    
    @objc func dismiss() {
        player.pause()
        model?.lastPlayTime = player.currentTime()
        player.replaceCurrentItem(with: nil)
        delegate?.dismissAction(model: model!)
    }
    
    //_______________________________________________________________________________________________________________
    // MARK: -  监听器
    
    override func observeValue(forKeyPath keyPath: String?, of object: Any?, change: [NSKeyValueChangeKey : Any]?, context: UnsafeMutableRawPointer?) {
        if object is AVPlayer {
            //  监听播放器状态
            if keyPath == #keyPath(AVPlayer.timeControlStatus) {
                let timeControlStatus = (object as! AVPlayer).timeControlStatus
                // 开始计时
                bottomView.timeControlStatus = timeControlStatus
                centerView.playButton.image = timeControlStatus == .paused ? UIImage(named: "ic_play") : nil
            }
        }
    }
    
    
    //  监听播放进度
    func periodicObserveCurrentTime(currentTime: CMTime) {
        guard let model = model else {return}
        let playerItem = player.currentItem
        ShortVideoCounter.share.playerItemDidChange(playerItem: playerItem)
        if  playerItem != nil {
            //  更新播放进度
            bottomView.updateProgress(currentTime: playerItem!.currentTime(), duration: playerItem!.duration)
            //  appstore审核没通过，权限放开
            if !Defaults.didPassReview {
                return
            }
            //  可以观看
            if model.responseWatchType == .canWatch ||
                model.responseWatchType == .none {
                return
            }
            
            //  非会员没有观看次数，直接暂停
            if let userInfo = NetDefaults.userInfo {
                if userInfo.freeWatches - userInfo.watched == 0 {
                    //  暂停
                    player.pause()
                    //  显示权限UI
                    playPredictionUI(shortVidelModel: model)
                    return;
                }
            }

            //  允许他看前面5秒
            if Int(CMTimeGetSeconds(currentTime)) >= 5 {
                //  暂停
                player.pause()
                //  显示权限UI
                playPredictionUI(shortVidelModel: model)
            }
        }
    }
    
    
    //  根据播放权限显示UI
    func playPredictionUI(shortVidelModel: ShortVideoModel) {
        switch shortVidelModel.responseWatchType {
        case .error:
            self.makeToast(shortVidelModel.error!.localizedDescription)
        case .noTimes:
            // 次数不够
            notimesAlert()
        case .needPay:
            //付费
            needPayAlert()
        default:
            puts(#function)
        }
    }
    
    //  监听播放结束
    @objc func playerItemDidPlayToEndTime(noti: Notification) {
        let item = noti.object as! AVPlayerItem
        //  所有的监听者都会收到播放完成通知，因此需要过滤
        guard item == player.currentItem else {
            return
        }
        item.cancelPendingSeeks()
        item.seek(to: .zero) {[weak self] (finished) in
            self?.player.play()
        }
        self.model?.playEnded = true
        self.model?.uploadWatchRecord(Int(CMTimeGetSeconds(item.duration)))
    }
    
    
    func notimesAlert() {
        addSubview(notimesView)
        notimesView.frame = bounds
    }
    
    func needPayAlert() {
        addSubview(needPayView)
        needPayView.frame = bounds
        needPayView.model = model
    }
    
    //_______________________________________________________________________________________________________________
    // MARK: - lazy load
    
    //顶部
    lazy var topView:FullTopView = {
        let v = Bundle.main.loadNibNamed("FullTopView", owner: nil, options: [:])?.first as! FullTopView
        v.backAction = { [weak self] in
            self?.dismiss()
        }
        return v
    }()
    
    // 中部
    lazy var centerView:FullCenterView = {
        let v = Bundle.main.loadNibNamed("FullCenterView", owner: nil, options: [:])?.first as! FullCenterView
        v.tapAction = {
            if self.isClearMode {
                // 清爽模式
                self.isClearMode = false
            } else {
                // 非清爽模式
                if self.player.timeControlStatus  == .paused {
                    self.player.play()
                } else {
                    self.player.pause()
                }
            }
        }
        return v
    }()
    
    // 下部
    lazy var bottomView:FullBottomView = {
        let v = Bundle.main.loadNibNamed("FullBottomView", owner: nil, options: [:])?.first as! FullBottomView
        v.delegate = self
        return v
    }()
    
    //_______________________________________________________________________________________________________________
    // MARK: - 播放器相关view
    lazy var playView: PlayerImageView = {
        var view = PlayerImageView()
        view.contentMode = .scaleAspectFill
        (view.layer as! AVPlayerLayer).videoGravity = .resizeAspectFill
        view.layer.backgroundColor = UIColor.black.cgColor
        view.layer.masksToBounds = true
        return view
    }()
    

    //_______________________________________________________________________________________________________________
    // MARK: - 权限view
    
    lazy var notimesView:FullNoTimeAlert = {
        let v = Bundle.main.loadNibNamed("FullNoTimeAlert", owner: nil, options: [:])?.first as! FullNoTimeAlert
        return v
    }()
    
    
    lazy var needPayView:FullNeedPayAlert = {
        let v = Bundle.main.loadNibNamed("FullNeedPayAlert", owner: nil, options: [:])?.first as! FullNeedPayAlert
        v.payDelegate = self
        return v
    }()
    
    
    //  ratio：宽高比
    func playViewFrame(ratio: CGFloat) -> CGRect {
        var playViewFrame = CGRect.zero
        let height: CGFloat = frame.width *  ratio
        let minY: CGFloat = (frame.height - height) / 2.0
        playViewFrame = CGRect(x: 0, y: minY, width: frame.width, height: height)
        return playViewFrame
    }
    //打折
    var exchangeConfigResp:VideoExchangeConfigResp?
    
    // 购买
    func pay() {
        buyVideo()
    }
    
    //_______________________________________________________________________________________________________________
    // MARK: -

    //  获取数据
    func loadDisCountData() {
        guard let model = self.model,let item = model.videoItem else {return}
        let req = VideoExchangeConfigReq()
        req.videoId = item.videoId
        Session.request(req) {[weak self] (error, resp) in
            guard error == nil else {
                self?.makeToast(error!.localizedDescription)
                return
            }
            let configResp = resp as! VideoExchangeConfigResp
            self?.exchangeConfigResp = configResp
        }
    }
    
    //  购买视频
    func buyVideo() {
        guard let item = model!.videoItem,let configResp = self.exchangeConfigResp else {return}
        let req = BuyVideoReq()
        req.videoId = item.videoId
        req.ticketDeductNum = configResp.ticketDeductNum
        Alert.showLoading(parentView: self)
        Session.request(req) {[weak self] (error, resp) in
            Alert.hideLoading()
            guard error == nil else {
                self?.makeToast(error!.localizedDescription)
                return
            }
            self?.makeToast("购买成功!")
            //  标记为可以观看
            self?.model!.responseWatchType = .canWatch
            /// 标记观看类型为金币观看 （统计要用到）
            self?.model!.watchType = .coin
            self?.player.play()
        }
    }
}


extension ShortVideoFullPlayView:FullBottomViewDelegate {
    func fullBottomView(_ fullBottomView: FullBottomView, seekToTime time: CMTime, completion: @escaping () -> Void) {
        player.currentItem?.cancelPendingSeeks()
        player.currentItem?.seek(to: time, completionHandler: { (finished) in
            completion()
        })
    }
}


@objc protocol ShortVideoFullPlayViewDelegate {
    
    // 退出全屏
    func dismissAction(model:ShortVideoModel)
    
}

