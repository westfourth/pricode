//
//  Share2VC.swift
//  Sp
//
//  Created by mac on 2020/9/19.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class Share2VC: UIViewController {
    @IBOutlet weak var qrImageView: UIImageView!
    @IBOutlet weak var inviteCodeLabel: UILabel!
    
    var qrURL: URL? {
        didSet {
            let image = DrawImage.qrCodeImage(text: qrURL!.absoluteString, width: 150)
            qrImageView.image = image
            if let code = qrURL?.absoluteString.components(separatedBy: "=").last {
                inviteCodeLabel.text = code
            }
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        if let url = Defaults.shareURL {
            self.qrURL = url
        }
        loadData()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        Appearance.transparent(true, navigationBar: navigationController?.navigationBar)
    }
    
    @IBAction func click(copy: UIButton) {
        guard let url = self.qrURL else {
            return
        }
        UIPasteboard.general.string = url.absoluteString
        mm_showToast("已复制到粘贴板", type: .succeed)
    }
    
    @IBAction func click(save: UIButton) {
        guard let url = self.qrURL else {
            return
        }
        let image = Share2VC.promotionCodeImage(text: url.absoluteString)
        UIImageWriteToSavedPhotosAlbum(image, self, #selector(saveImage(image:didFinishSavingWithError:contextInfo:)), nil)
    }
    
    func loadData() {
        Alert.showLoading(parentView: view)
        Session.request(ShareLinkReq()) { [weak self] (error, resp) in
            Alert.hideLoading()
            guard error == nil, let item = resp as? ShareLinkResp, let url = item.url else {
                mm_showToast(error!.localizedDescription)
                return
            }
            Defaults.shareURL = url
            self?.qrURL = url
        }
    }
    
    @objc func saveImage(image:UIImage, didFinishSavingWithError error:Error?, contextInfo:UnsafeMutableRawPointer) {
        if error == nil {
            mm_showToast("已成功保存到相簿!", type: .succeed)
        }
    }
    
    //  推广码
    class func promotionCodeImage(text: String) -> UIImage {
        UIGraphicsBeginImageContextWithOptions(UIScreen.main.bounds.size, false, 0)
        //  是否为X屏幕
        let is_iphone_x = UIApplication.shared.windows.first!.safeAreaInsets.bottom > 0
        //  大背景
        var image = UIImage(named: "share2_bg")
        image?.draw(in: UIScreen.main.bounds)
        //  分享送会员
        image = UIImage(named: "share2_title")
        var size = CGSize(width: 837/3, height: 168/3)
        let titleRect = CGRect(x: (UIScreen.main.bounds.width - size.width)/2, y: is_iphone_x ? 90 : 44, width: size.width, height: size.height)
        image?.draw(in: titleRect)
        
        //  小背景
        image = UIImage(named: "share2_square")
        size = CGSize(width: 1020/3, height: 1272/3)
        let bgRect = CGRect(x: (UIScreen.main.bounds.width - size.width)/2, y: titleRect.maxY + 24, width: size.width, height: size.height)
        image?.draw(in: bgRect)
        
        //  二维码圆角方形背景
        size = CGSize(width: 200, height: 200)
        let whiteRect = CGRect(x: (UIScreen.main.bounds.width - size.width)/2, y: bgRect.minY + 50, width: size.width, height: size.height)
        let path = UIBezierPath(roundedRect: whiteRect, byRoundingCorners: .allCorners, cornerRadii: CGSize(width: 18, height: 18))
        UIColor.white.setFill()
        path.fill()
        
        //  二维码
        let ciImage = DrawImage.qrCodeImage(text: text)
        image = UIImage(ciImage: ciImage)
        image?.draw(in: whiteRect.inset(by: UIEdgeInsets(top: 12, left: 12, bottom: 12, right: 12)))
        
        //  推广码
        var attrText = NSAttributedString(string: "邀请码", attributes: [.font: font(20, .semibold), .foregroundColor: UIColor.white])
        size = attrText.size()
        var rect = CGRect(x: (UIScreen.main.bounds.width - size.width)/2, y: whiteRect.maxY + 30, width: size.width, height: size.height)
        attrText.draw(in: rect)
        
        //  XXXXXX
        let codeText: String = text.components(separatedBy: "?p=").last ?? ""
        attrText = NSAttributedString(string: codeText, attributes: [.font: font(32, .semibold), .foregroundColor: UIColor.white])
        size = attrText.size()
        rect = CGRect(x: (UIScreen.main.bounds.width - size.width)/2, y: whiteRect.maxY + 60, width: size.width, height: size.height)
        attrText.draw(in: rect)
        
        //  扫码加入
        attrText = NSAttributedString(string: "扫码加入", attributes: [.font: font(30, .semibold), .foregroundColor: UIColor.white])
        size = attrText.size()
        rect = CGRect(x: (UIScreen.main.bounds.width - size.width)/2, y: bgRect.maxY, width: size.width, height: size.height)
        attrText.draw(in: rect)
        
        //  立即发车
        attrText = NSAttributedString(string: "立即发车", attributes: [.font: font(50, .semibold), .foregroundColor: UIColor.white])
        size = attrText.size()
        rect = CGRect(x: (UIScreen.main.bounds.width - size.width)/2, y: bgRect.maxY + 42, width: size.width, height: size.height)
        attrText.draw(in: rect)
        
        image = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        return image!
    }
}
