//
//  ShareVC.swift
//  Sp
//
//  Created by mac on 2020/3/3.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class ShareVC: UIViewController {
    
    @IBOutlet weak var spreadCode: UILabel!
    @IBOutlet weak var qrCode: UIImageView!
    @IBOutlet weak var avatar: UIImageView!
    @IBOutlet weak var link: UILabel!
    
    var videoId:Int!
    var shareLink:String?
    @IBAction func dismissAction(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    
    @IBOutlet weak var copyView: UIView!
    
    @IBOutlet weak var saveView: UIView!
    
    private static let defaultImg: UIImage? = {
        return Sensitive.default_bg
    }()
    
    private static let shareImg: CGImage? = {
        return Sensitive.share_bg?.cgImage
    }()
    
    private static let animationOption: KingfisherOptionsInfo = {
        return [.transition(.fade(0.25))]
    }()
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.layer.contents = ShareVC.shareImg
        
        self.copyView.isUserInteractionEnabled = true
        self.saveView.isUserInteractionEnabled = true
        
        let tap1 = UITapGestureRecognizer(target: self, action:#selector(self.copyAction))
        let tap2 = UITapGestureRecognizer(target: self, action:#selector(self.saveAction))
        
        self.copyView.addGestureRecognizer(tap1)
        self.saveView.addGestureRecognizer(tap2)
        self.avatar.image = ShareVC.defaultImg
        if let user = NetDefaults.userInfo {
            self.avatar.kf.setImage(with: user.logo,placeholder: ShareVC.defaultImg, options: ShareVC.animationOption)
        }
        
        loadData()
    }
    
    func loadData() {
        let req =  ShareLinkReq()
        req.videoId = self.videoId
        if let url = Defaults.shareURL {
            self.qrCode.image = self.creatQRCodeImage(text:url.absoluteString, WH: 166)
        }
        Session.request(req) { (error, resp) in
            guard error == nil else {
                return
            }
            if let item = resp as? ShareLinkResp {
                guard  let urlStr = item.url?.absoluteString else {
                    return
                }
                self.shareLink = urlStr
                if item.url != Defaults.shareURL {
                    self.qrCode.image = self.creatQRCodeImage(text:urlStr, WH: 166)
                    Defaults.shareURL = item.url
                }
            }
        }
    }
    
    @objc func saveAction() {
        
    }
    
    @objc func copyAction() {
        guard self.shareLink != nil else {
            return
        }
    }
    
    //MARK:- 生成二维码
       func creatQRCodeImage(text: String, WH: CGFloat) -> UIImage{
           
           //建立滤镜
           let filter = CIFilter(name: "CIQRCodeGenerator")
           //还原滤镜的预设属性
           filter?.setDefaults()
           //设定需要生成二维码的资料
           filter?.setValue(text.data(using: String.Encoding.utf8), forKey: "inputMessage")
           //从滤镜中取出生成的图片
           let ciImage = filter?.outputImage
           //这个清晰度好
           let bgImage = createNonInterpolatedUIImageFormCIImage(image: ciImage!, size: CGSize(width: WH, height: WH))
           return bgImage
       }
       
       
       func createNonInterpolatedUIImageFormCIImage(image: CIImage, size: CGSize) -> UIImage {
           
           let extent: CGRect = image.extent.integral
           let scale: CGFloat = min(size.width / extent.width, size.height / extent.height)
           
           let width = extent.width * scale
           let height = extent.height * scale
           let cs: CGColorSpace = CGColorSpaceCreateDeviceGray()
           let bitmapRef = CGContext(data: nil, width: Int(width), height: Int(height), bitsPerComponent: 8, bytesPerRow: 0, space: cs, bitmapInfo: 0)!
           
           let context = CIContext(options: nil)
           let bitmapImage: CGImage = context.createCGImage(image, from: extent)!
           
           bitmapRef.interpolationQuality = CGInterpolationQuality.none
           bitmapRef.scaleBy(x: scale, y: scale)
           bitmapRef.draw(bitmapImage, in: extent)
           let scaledImage: CGImage = bitmapRef.makeImage()!
           return UIImage(cgImage: scaledImage)
       }
}
