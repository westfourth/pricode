//
//  ShareView.swift
//  Sp
//
//  Created by mac on 2020/3/13.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit
import Photos

class ShareView: UIView {
    var shareLink:String?
    @IBOutlet weak var topC: NSLayoutConstraint!
    
    private static let defaultImg: UIImage? = {
        return Sensitive.default_bg
    }()
    
    private static let coverDefaultImg: UIImage = {
        return UIImage.decrypt("video_share_bg.jpg.enc")
    }()
    
    private static let animationOption: KingfisherOptionsInfo = {
        return [.transition(.fade(0.25))]
    }()
    
    private static let shareImg: CGImage? = {
        return Sensitive.share_bg?.cgImage
    }()
    
    var video:VideoItem? {
        didSet {
            guard let video = video else {
                cover.image = ShareView.coverDefaultImg
                return
            }
            
            if !(video.coverImg?.absoluteString.isEmpty ?? true) {
                cover.kf.setImage(with: video.coverImg, placeholder: ShareView.defaultImg, options: ShareView.animationOption)
            } else {
                cover.image = ShareView.coverDefaultImg
            }
            
            self.name.text = video.title
            self.author.text =  video.nickName
            
            loadData()
        }
    }
    @IBOutlet weak var inviteCode: UILabel!
    @IBOutlet weak var coverView: UIView!
    @IBOutlet weak var cover: UIImageView!
    @IBOutlet weak var website: UILabel!
    @IBOutlet weak var qrcode: UIImageView!
    @IBOutlet weak var avatar: UIImageView!
    @IBOutlet weak var copyView: UIView!
    @IBOutlet weak var saveView: UIView!
    
    @IBOutlet weak var author: UILabel!
    @IBOutlet weak var name: UILabel!
    @IBOutlet weak var backView: UIView!
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        layer.contents = ShareView.shareImg
        topC.constant = IsScreenX() ? 20 + 44 : 20;
        
        isUserInteractionEnabled = true
        
        copyView.isUserInteractionEnabled = true
        saveView.isUserInteractionEnabled = true
        
        let tap1 = UITapGestureRecognizer(target: self, action:#selector(copyAction))
        let tap2 = UITapGestureRecognizer(target: self, action:#selector(isPHPhotoLibraryAuthorized))
        
        copyView.addGestureRecognizer(tap1)
        saveView.addGestureRecognizer(tap2)
        avatar.image = ShareView.defaultImg
        if let user = NetDefaults.userInfo {
            if let logo = user.logo  {
                avatar.kf.setImage(with: logo, placeholder: ShareView.defaultImg, options: ShareView.animationOption)
            }
            inviteCode.text = "推廣碼：" + user.inviteCode
        }
        
        //        let startC = UIColor(red: 36, green: 3, blue: 33, alpha: 0.0)
        //        let endC = UIColor(red: 36, green: 3, blue: 33, alpha: 0.6)
        //        let gradientColors: [CGColor] = [startC.cgColor, endC.cgColor]
        //        let gradientLayer: CAGradientLayer = CAGradientLayer()
        //        gradientLayer.colors = gradientColors
        //        gradientLayer.startPoint = .zero
        //        gradientLayer.endPoint = CGPoint(x: 1, y: 1)
        //
        //        gradientLayer.frame = self.backView.bounds
        //        backView.layer.insertSublayer(gradientLayer, at: 0)
        
        if let site = Defaults.website {
            website.text = site
        }
    }
    
    func loadData() {
        guard let videoId = video?.videoId else { return }
        let req =  ShareLinkReq()
        req.videoId = videoId
        if let url = Defaults.shareURL {
            qrcode.image = self.creatQRCodeImage(text: url.absoluteString, WH: 166)
        }
        Session.request(req) { [weak self] (error, resp) in
            guard error == nil else { return }
            guard let `self` = self, let item = resp as? ShareLinkResp, let urlStr = item.url?.absoluteString else {
                mm_showToast("數據異常！")
                return
            }
            let urlStrArr = urlStr.components(separatedBy: "?p=")
//            self.inviteCode.text = "推广码：\(urlStrArr.last?.prefix(6) ?? "")"
            self.website.text = urlStrArr.first
            Defaults.website = urlStrArr.first
            self.shareLink = item.linkText == nil ? urlStr : item.linkText! + "：" + urlStr
            if item.url != Defaults.shareURL {
                self.qrcode.image = self.creatQRCodeImage(text: urlStr, WH: 166)
                Defaults.shareURL = item.url
            }
        }
    }
    
    //MARK:-贴上板
    @objc private func copyAction() {
        guard let link = shareLink else { return }
        UIPasteboard.general.string = link
        mm_showToast("已經複製到貼上板!", type: .succeed)
    }
    
    @objc private func isPHPhotoLibraryAuthorized() {
        if #available(iOS 11.0, *) {
            PHPhotoLibrary.requestAuthorization { (status) in
                DispatchQueue.main.async {
                    status == .authorized || status == .notDetermined ? self.saveQRCode() : self.openSystemSettingPhotoLibrary()
                }
            }
        } else {
            self.canPhotoLibary() ? self.saveQRCode() : self.openSystemSettingPhotoLibrary()
        }
    }
    
    private func canPhotoLibary() -> Bool {
        let authStatus = PHPhotoLibrary.authorizationStatus()
        return authStatus == .authorized || authStatus == .notDetermined
    }
    
    //弹出弹窗去设置
    private func openSystemSettingPhotoLibrary() {
        let alert = UIAlertController(title:"未獲得許可權將圖片保存到相冊", message:"請前往設置-隱私-照片, 打開相冊許可權", preferredStyle: .alert)
        let confirm = UIAlertAction(title:"馬上去設置", style: .default) { _ in
            let url = URL.init(string: UIApplication.openSettingsURLString)
            if  InnerIntercept.canOpenURL(url!) {
                InnerIntercept.open(url!)
            }
        }
        let cancel = UIAlertAction(title:"取消", style: .cancel, handler:nil)
        alert.addAction(cancel)
        alert.addAction(confirm)
        (UIApplication.shared.delegate as? AppDelegate)?.currentNavigationController?.present(alert, animated:true, completion:nil)
    }
    
    @objc private func saveQRCode() {
        UIGraphicsBeginImageContextWithOptions(self.bounds.size, true, UIScreen.main.scale)
        self.layer.render(in: UIGraphicsGetCurrentContext()!)
        let allImage = UIGraphicsGetImageFromCurrentImageContext()!
        let rect = CGRect(x: 0, y: 0, width: UIScreen.main.bounds.size.width * UIScreen.main.scale, height: 658 * SpreadView.ratio * UIScreen.main.scale)
        let partImage = UIImage(cgImage: allImage.cgImage!.cropping(to: rect)!, scale: UIScreen.main.scale, orientation: .up)
        UIGraphicsEndImageContext()
        UIImageWriteToSavedPhotosAlbum(partImage, self, #selector(saveImage(image:didFinishSavingWithError:contextInfo:)), nil)
    }
    
    //MARK:-保存图片到相簿
    @objc private func saveImage(image:UIImage,didFinishSavingWithError error:Error?,contextInfo:UnsafeMutableRawPointer) {
        if error == nil {
            mm_showToast("已成功保存到相簿!", type: .succeed)
        }
    }
    
    //MARK:- 生成二维码
    private func creatQRCodeImage(text: String, WH: CGFloat) -> UIImage{
        
        //建立滤镜
        let filter = CIFilter(name: "CIQRCodeGenerator")
        //还原滤镜的预设属性
        filter?.setDefaults()
        //设定需要生成二维码的资料
        filter?.setValue(text.data(using: String.Encoding.utf8), forKey: "inputMessage")
        //从滤镜中取出生成的图片
        let ciImage = filter?.outputImage
        //这个清晰度好
        let bgImage = createNonInterpolatedUIImageFormCIImage(image: ciImage!, size: CGSize(width: WH, height: WH))
        return bgImage
    }
    
    private func createNonInterpolatedUIImageFormCIImage(image: CIImage, size: CGSize) -> UIImage {
        
        let extent: CGRect = image.extent.integral
        let scale: CGFloat = min(size.width / extent.width, size.height / extent.height)
        
        let width = extent.width * scale
        let height = extent.height * scale
        let cs: CGColorSpace = CGColorSpaceCreateDeviceGray()
        let bitmapRef = CGContext(data: nil, width: Int(width), height: Int(height), bitsPerComponent: 8, bytesPerRow: 0, space: cs, bitmapInfo: 0)!
        
        let context = CIContext(options: nil)
        let bitmapImage: CGImage = context.createCGImage(image, from: extent)!
        
        bitmapRef.interpolationQuality = .none
        bitmapRef.scaleBy(x: scale, y: scale)
        bitmapRef.draw(bitmapImage, in: extent)
        let scaledImage: CGImage = bitmapRef.makeImage()!
        return UIImage(cgImage: scaledImage)
    }
}
