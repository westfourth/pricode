//
//  ShareVideoVC.swift
//  Sp
//
//  Created by mac on 2020/3/4.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class ShareVideoVC: UIViewController  {
    var video:VideoItem!
    
    override func loadView() {
        self.view = shareView
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.shareView.video = self.video
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.navigationBar.setBackgroundImage(UIImage(), for: UIBarMetrics.default)
        self.navigationController?.navigationBar.shadowImage = UIImage()
        self.navigationController?.navigationBar.isTranslucent = true
    }
    
    lazy var shareView:ShareView = {
        let xibView = Bundle.main.loadNibNamed("ShareView", owner: nil, options: [:])?.first as! ShareView
        return xibView
    }()
    
}

