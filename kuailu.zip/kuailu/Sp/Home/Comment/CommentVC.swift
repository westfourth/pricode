//
//  CommentVC.swift
//  Sp
//
//  Created by mac on 2020/3/2.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit
import IQKeyboardManagerSwift

class CommentVC: UIViewController {
    
    var transtioner:ModalTransitionManager!
    var video:VideoItem!
    
    var viewWillDisappearCallback: (() -> Void)?
    
    var items:[CommentItem] = [CommentItem]()
    
    var selectedItem:Any?
    
    var selectParentItem:CommentItem?
    
    var nomoreData:Bool = false
    
    /// 用于朋友圈
    var timelineItem:TimeLineItem?
    /// 用于小说
    var novel:NovelItem?
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        IQKeyboardManager.shared.enable = false
        IQKeyboardManager.shared.enableAutoToolbar = false
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        IQKeyboardManager.shared.enable = true
        IQKeyboardManager.shared.enableAutoToolbar = true
        self.viewWillDisappearCallback?()
    }
    
    override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: Bundle?) {
        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
        modalPresentationStyle = .overFullScreen
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let height = (560 / 780) * UIScreen.main.bounds.size.height
        transtioner = ModalTransitionManager(viewController: self, height: height)
        object_setClass(self.view.layer, CAGradientLayer.self)
        let l = self.view.layer as! CAGradientLayer
        l.colors = [RGB(0x1C1C1C).cgColor,
                    RGB(0x1C1C1C).cgColor]
        l.startPoint = CGPoint(x: 0, y: 0)
        l.endPoint = CGPoint(x: 0, y: 1)
        l.masksToBounds = true
        l.cornerRadius = 15
        let blur = UIBlurEffect(style: .dark)
        let blurView = UIVisualEffectView(effect: blur)
        blurView.alpha = 0.8
        view.addSubview(blurView)
        blurView.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
        view.addSubview(self.tableView)
        
        self.tableView.snp.makeConstraints { (make) in
            make.left.right.equalTo(0)
            make.top.equalTo(48)
            make.bottom.equalTo(-kBottom)
        }
        
        if let t = self.timelineItem {
            self.count.text = "\(num2TenThousandStrFormat(t.commentNum))條評論"
            loadTimeLineData()
        } else if let n = novel {
            count.text = "\(num2TenThousandStrFormat(n.commentNum))條評論"
            loadNovelCommentData()
        }  else  {
            self.count.text = "\(num2TenThousandStrFormat(self.video.commentNum))條評論"
            loadData()
        }
        
        self.view.addSubview(self.headView)
        headView.snp.makeConstraints { (make) in
            make.left.right.top.equalTo(0)
            make.height.equalTo(48)
        }
        self.view.addSubview(self.bottomView)
        self.bottomView.snp.makeConstraints { (make) in
            make.left.right.bottom.equalTo(0)
            make.height.equalTo(kBottom)
        }
        
        NotificationCenter.default.addObserver(self, selector: #selector(self.handelKeyBoardDisplay(_:)), name: UIResponder.keyboardWillShowNotification, object: nil)
        
        NotificationCenter.default.addObserver(self, selector: #selector(self.handelKeyBoardHide(_:)), name: UIResponder.keyboardWillHideNotification, object: nil)
    }
    
    deinit {
        NotificationCenter.default.removeObserver(self)
    }
    
    @objc func handelKeyBoardDisplay(_ noti: NSNotification) {
        guard let vc = (UIApplication.shared.delegate as? AppDelegate)?.currentNavigationController?.topViewController, vc is Home2VC || vc is ShortVideoListVC || vc is ChatSexVC || vc is TimeLineVC || vc is UsersDynamicVC || vc is Community2VC || vc is TopicDetailVC || vc is TextNovelDetailVC || vc.presentedViewController is AudioNovelDetailVC else { return }
        guard checkIsVipUser() else {
            self.input.resignFirstResponder()
            return
        }
        let info:[String:Any] = noti.userInfo as! [String : Any]
        let value:NSValue = info[UIResponder.keyboardFrameEndUserInfoKey] as! NSValue
        let rec = value.cgRectValue
        let H:CGFloat = rec.size.height
        let bottomGap = IS_IPHONEX ? kBottom - 15 - 35 : (kBottom - 35 ) / 2.0 - 2.0
        UIView.animate(withDuration: 0.5) {
            self.bottomView.snp.remakeConstraints { (make) in
                make.left.right.equalTo(0)
                make.height.equalTo(kBottom)
                make.bottom.equalTo(-(H - bottomGap))
            }
        }
    }
    
    @objc func handelKeyBoardHide(_ noti: NSNotification) {
        guard let vc = (UIApplication.shared.delegate as? AppDelegate)?.currentNavigationController?.topViewController, vc is Home2VC || vc is ShortVideoListVC || vc is ChatSexVC || vc is TimeLineVC || vc is UsersDynamicVC  || vc is Community2VC || vc is TopicDetailVC || vc is TextNovelDetailVC || vc.presentedViewController is AudioNovelDetailVC else { return }
        let itemH = IS_IPHONEX ? 83 :49
        self.input.attributedPlaceholder = NSAttributedString(string: "觀而不論非英雄，留下你的評論吧～", attributes: [NSAttributedString.Key.font : UIFont.systemFont(ofSize: 13, weight: .medium),NSAttributedString.Key.foregroundColor:RGB(84,94,119)])
        UIView.animate(withDuration: 0.5) {
            self.bottomView.snp.remakeConstraints { (make) in
                make.left.right.bottom.equalToSuperview()
                make.height.equalTo(itemH)
            }
        }
    }
    
    //_______________________________________________________________________________________________________________
    // MARK: - 懒载入
    lazy var headView:UIView =  {
        let view = UIView()
        view.backgroundColor = .clear
        view.addSubview(self.count)
        
        view.addSubview(self.tapDismiss)
        self.tapDismiss.snp.makeConstraints { (make) in
            make.size.equalTo(CGSize(width: 60, height: 44))
            make.top.right.equalToSuperview()
        }
        
        view.addSubview(self.dismiss)
        self.count.snp.makeConstraints { (make) in
            make.centerX.centerY.equalToSuperview()
        }
        self.dismiss.snp.makeConstraints { (make) in
            make.size.equalTo(CGSize(width: 23, height: 23))
            make.right.equalTo(-18)
            make.centerY.equalToSuperview()
        }
        
        view.addSubview(self.line)
        self.line.snp.makeConstraints { (make) in
            make.left.right.bottom.equalToSuperview()
            make.height.equalTo(0.5)
        }
        return view
    }()
    
    
    lazy var line:UIView = {
        let l = UIView()
        l.backgroundColor = RGB(0xff444975)
        l.alpha = 0.5
        return l
    }()
    
    lazy var tapDismiss:UIButton = {
        let button = UIButton()
        button.isUserInteractionEnabled = true
        button.backgroundColor = .clear
        button.addTarget(self, action: #selector(self.tapDismissAction), for: UIControl.Event.touchUpInside)
        return button
    }()
    
    @objc  func tapDismissAction() {
        dismiss(animated: true, completion: nil)
    }
    
    lazy var count:UILabel = {
        let label = UILabel()
        label.text = "0條評論"
        label.textColor = .white
        label.textAlignment = .center
        label.font = UIFont.systemFont(ofSize: 15, weight: UIFont.Weight.medium)
        return label
    }()
    
    lazy var dismiss:UIButton = {
        let button = UIButton()
        button.setImage(UIImage(named: "ic_close"), for: UIControl.State.normal)
        button.isUserInteractionEnabled = true
        button.addTarget(self, action: #selector(self.tapDismissAction), for: UIControl.Event.touchUpInside)
        return button
    }()
    
    //发送
    lazy var send:UIButton = {
        let button = UIButton()
        button.setImage(UIImage(named: "send_d"), for: .disabled)
        button.setImage(UIImage(named: "send_n"), for: .normal)
        button.isEnabled = false
        button.addTarget(self, action: #selector(self.sendAction), for: .touchUpInside)
        //        button.setTitle("发送", for: UIControl.State.normal)
        //        button.setTitleColor(.white, for: UIControl.State.normal)
        //        button.setTitleColor(.gray, for: UIControl.State.disabled)
        //
        //        button.titleLabel?.font = UIFont.systemFont(ofSize: 13, weight: UIFont.Weight.medium)
        //        button.addTarget(self, action: #selector(self.sendAction), for: UIControl.Event.touchUpInside)
        //        button.backgroundColor = UIColor(red: 203/255.0, green: 40/255.0, blue: 101/255.0, alpha: 0.4)
        //        button.clipsToBounds = true
        //        button.layer.cornerRadius = 5.0
        
        return button
    }()
    
    
    //输入框
    lazy var input:UITextField = {
        let i = UITextField()
        i.backgroundColor = RGB(0x212121)
        i.textColor = UIColor.white
        i.attributedPlaceholder = NSAttributedString(string: "觀而不論非英雄，留下你的評論吧～", attributes: [NSAttributedString.Key.font : UIFont.systemFont(ofSize: 13, weight: .medium),NSAttributedString.Key.foregroundColor:RGB(84,94,119)])
        i.font = UIFont.systemFont(ofSize: 13, weight: .medium)
        //        i.clearButtonMode = .whileEditing
        i.delegate = self
        i.addTarget(self, action: #selector(self.handelInput(_:)), for: UIControl.Event.editingChanged)
        return i
    }()
    
    @objc func handelInput(_ textField:UITextField) {
        self.send.isEnabled = textField.text != ""
    }
    //    lazy var bottomView:UIView = {
    //        let sendView = UIView()
    //        sendView.backgroundColor = RGB(16,20,36)
    //        sendView.addSubview(self.input)
    //        self.input.snp.makeConstraints { (make) in
    //            make.left.equalTo(12)
    //            make.top.equalTo(9)
    //            make.right.equalTo(-85)
    //            make.height.equalTo(35)
    //        }
    //
    //        sendView.addSubview(self.send)
    //        //        self.send.isEnabled = false
    //        self.send.snp.makeConstraints { (make) in
    //            make.centerY.equalTo(self.input)
    //            make.height.equalTo(35)
    //            make.width.equalTo(65)
    //            make.right.equalTo(-12)
    //        }
    //        return sendView
    //    }()
    lazy var bottomView:UIView = {
        let sendView = UIView()
        sendView.backgroundColor = rgb(0x141515)
        
        let backView = UIView()
        backView.backgroundColor = rgb(0x212121)
        backView.clipsToBounds = true
        backView.layer.cornerRadius = 17.5
        sendView.addSubview(backView)
        
        backView.snp.makeConstraints { (make) in
            make.left.equalTo(12)
            make.right.equalTo(-12)
            make.height.equalTo(35)
            if IS_IPHONEX {
                make.top.equalTo(13)
            } else {
                make.centerY.equalToSuperview()
            }
        }
        
        backView.addSubview(self.input)
        self.input.snp.makeConstraints { (make) in
            make.left.equalTo(12)
            make.right.equalTo(-40)
            make.top.bottom.equalToSuperview()
        }
        
        backView.addSubview(self.send)
        self.send.snp.makeConstraints { (make) in
            make.centerY.equalTo(self.input)
            make.size.equalTo(CGSize(width: 20, height: 20))
            make.right.equalTo(-14)
        }
        return sendView
    }()
    
    //MARK:-展开处理
    func expandHandelItems() {
        self.items = self.items.map { (item) -> CommentItem in
            if item.reply.count > 3 {
                item.displayItems = Array(item.reply.prefix(3))
            } else {
                item.displayItems = item.reply
            }
            return item
        }
    }
    
    /// 加载小说评论列表
    func loadNovelCommentData() {
        let req = NovelCommentListReq()
        req.chapterId = novel!.currentChapterId
        req.fictionId = novel!.fictionId
        req.lastId =  items.count > 0 ? items.last!.id : kStrOptionValue
        Session.request(req) { [weak self] (e, resp) in
            guard let `self` = self else { return }
            guard e == nil else {
                iToast(e!.localizedDescription)
                if req.lastId == kStrOptionValue {
                    self.tableView.state = .failed
                }
                return
            }
            guard let commentResp  = resp as? CommentListResp else { return }
            self.count.text = "\(num2TenThousandStrFormat(commentResp.data.count))條評論"
            self.nomoreData = commentResp.data.count < req.pageSize
            if req.lastId == kStrOptionValue {
                self.items = commentResp.data
                self.tableView.state = commentResp.data.isEmpty ? .empty : .normal
            } else {
                self.items.append(contentsOf: commentResp.data)
                self.tableView.state = .normal
            }
            self.items = self.items.map { (item) -> CommentItem in
                item.displayItems = item.reply.count > 3 ? Array(item.reply.prefix(3)) : item.reply
                return item
            }
            self.tableView.reloadData()
        }
    }
    
    
    //MARK:-判断是否是vip用户
    private func checkIsVipUser()-> Bool {
        //  appstore审核没通过，权限放开
        if !Defaults.didPassReview {
            return true
        }
        //
        guard let user = NetDefaults.userInfo, user.freeWatches != -1 else { return true }
        Alert.showCommonAlert(parentView: UIApplication.shared.keyWindow!,
                              contentText: "僅限\(Sensitive.fu)VIP用戶參與評論",
                              cancelText: "好的",
                              confirmText: "\(Sensitive.chong)VIP",
                              onConfirmTap: {
                                self.dismiss(animated: true) {
                                    // 购买金币
                                    VipChargeTipVC.isFromVideoPlayList = true
                                    let navVC = (UIApplication.shared.delegate as? AppDelegate)?.currentNavigationController
                                    navVC?.pushViewController(Vip2VC(), animated: true)
                                }
                              },onCancelTap: nil)
        return false
    }
    
    //_______________________________________________________________________________________________________________
    // MARK: - 朋友圈评论处理
    
    @objc func addTimeLineComment() {
        let req = TimeLineAddCommentReq()
        req.content = self.input.text!
        req.dynamicId = timelineItem!.dynamicId
        self.clearInput()
        Session.request(req) { (error, resp) in
            Alert.hideLoading()
            guard error == nil else {
                mm_showToast(error!.localizedDescription)
                return
            }
            if self.items.count == 0 {
                self.tableView.state = .normal
            }
            if resp is CommentItem {
                let newItem = resp as! CommentItem
                self.items.insert(newItem, at: 0)
                self.timelineItem!.commentNum = self.timelineItem!.commentNum + 1
                self.count.text = "\(num2TenThousandStrFormat(self.timelineItem!.commentNum))條評論"
                self.tableView.reloadData()
            }
        }
    }
    
    
    private func addNovelComment() {
        let req = NovelCommentAddReq()
        req.chapterId = novel!.currentChapterId
        req.fictionId = novel!.fictionId
        req.content = input.text!
        clearInput()
        Session.request(req) { [weak self] (error, resp) in
            hideLoading()
            guard let `self` = self else { return }
            guard error == nil else {
                iToast(error!.localizedDescription)
                return
            }
            if self.items.isEmpty {
                self.tableView.state = .normal
            }
            guard let resData = resp as? CommentItemItem,let json = resData.toJSON() , let commentItem = CommentItem.deserialize(from: json)  else { return }
            self.items.insert(commentItem, at: 0)
            self.novel!.commentNum = self.novel!.commentNum + 1
            self.count.text = "\(num2TenThousandStrFormat(self.novel!.commentNum))條評論"
            self.tableView.reloadData()
        }
    }
    
    
    /// 回复小说一级评论
    private func addNovelCommentItemItem(_ selecI:CommentItem) {
        let req = NovelCommentAddReq()
        req.content = input.text!
        req.fictionId = novel!.fictionId
        req.chapterId = novel!.currentChapterId
        req.parenId = selecI.id
        self.clearInput()
        Session.request(req) { [weak self] (error, resp) in
            hideLoading()
            guard let `self` = self else { return }
            guard error == nil else {
                iToast(error!.localizedDescription)
                return
            }
            guard let resData = resp as? CommentItemItem else { return }
            selecI.reply.insert(resData, at: 0)
            self.novel!.commentNum = self.novel!.commentNum + 1
            self.count.text = "\(num2TenThousandStrFormat(self.novel!.commentNum))條評論"
            self.expandHandelItems()
            self.tableView.reloadData()
        }
    }
    
    private func replyNovelCommentItemItem(_ selecI:CommentItemItem,_ parentItem:CommentItem) {
        let req = NovelCommentAddReq()
        req.chapterId = novel!.currentChapterId
        req.content = input.text!
        req.parenId = parentItem.id
        req.backUserId = selecI.userId
        req.fictionId = self.novel!.fictionId
        clearInput()
        Session.request(req) { [weak self] (error, resp) in
            hideLoading()
            guard let `self` = self else { return }
            guard error == nil else {
                iToast(error!.localizedDescription)
                return
            }
            guard let resData = resp as? CommentItemItem else { return }
            parentItem.reply.insert(resData, at: 0)
            self.novel!.commentNum = self.novel!.commentNum + 1
            self.count.text = "\(num2TenThousandStrFormat(self.novel!.commentNum))條評論"
            self.expandHandelItems()
            self.tableView.reloadData()
        }
    }
    
    
    //MARK:-回复一级评论
    @objc func addTimeLineCommnetItemItem(_ selecI:CommentItem) {
        let req = TimeLineAddCommentItemItemReq()
        req.content = self.input.text!
        req.dynamicId = self.timelineItem!.dynamicId
        req.parentId = selecI.commentId
        self.clearInput()
        Session.request(req) { (error, resp) in
            Alert.hideLoading()
            guard error == nil else {
                mm_showToast(error!.localizedDescription)
                return
            }
            if resp is CommentItemItem {
                let newItem = resp as! CommentItemItem
                selecI.reply.insert(newItem, at: 0)
                self.timelineItem!.commentNum = self.timelineItem!.commentNum + 1
                self.count.text = "\(num2TenThousandStrFormat(self.timelineItem!.commentNum))條評論"
                self.expandHandelItems()
                self.tableView.reloadData()
            }
        }
    }
    
    //MARK:-回复二级评论
    @objc func replyTimeLineCommnetItemItem(_ selecI:CommentItemItem, _ parentItem:CommentItem) {
        let req = TimeLineAddCommentItemItemReq()
        req.content = self.input.text!
        req.dynamicId = self.timelineItem!.dynamicId
        req.parentId = parentItem.commentId
        req.replyUserId = selecI.replyUserId
        req.replyUserNickName = selecI.userNickName
        self.clearInput()
        Session.request(req) { (error, resp) in
            Alert.hideLoading()
            guard error == nil else {
                mm_showToast(error!.localizedDescription)
                return
            }
            if resp is CommentItemItem {
                let newItem = resp as! CommentItemItem
                parentItem.reply.insert(newItem, at: 0)
                self.timelineItem!.commentNum = self.timelineItem!.commentNum + 1
                self.count.text = "\(num2TenThousandStrFormat(self.timelineItem!.commentNum))條評論"
                self.expandHandelItems()
                self.tableView.reloadData()
            }
        }
    }
    
    
    
    //MARK:-添加评论
    @objc func sendAction() {
        
        self.input.resignFirstResponder()
        
        guard checkIsVipUser(), self.input.text != "" else { return }
        
        Alert.showLoading(parentView: self.view)
        //MARK:-添加一级评论
        guard  self.selectedItem != nil else {
            // 朋友圈动态评论
            if self.timelineItem != nil {
                addTimeLineComment()
                return
            }
            if novel != nil {
                addNovelComment()
                return
            }
            
            let req = CommentAddReq()
            req.content = self.input.text!
            req.videoId = self.video.videoId
            self.clearInput()
            Session.request(req) { (error, resp) in
                Alert.hideLoading()
                guard error == nil else {
                    mm_showToast(error!.localizedDescription)
                    return
                }
                if self.items.count == 0 {
                    self.tableView.state = .normal
                }
                if resp is CommentItem {
                    let newItem = resp as! CommentItem
                    self.items.insert(newItem, at: 0)
                    self.video.commentNum = self.video.commentNum + 1
                    self.count.text = "\(num2TenThousandStrFormat(self.video.commentNum))條評論"
                    self.tableView.reloadData()
                }
            }
            return
        }
        //MARK:-添加二级评论
        if let selecI = self.selectedItem as? CommentItem {
            if self.timelineItem != nil  {
                addTimeLineCommnetItemItem(selecI)
                return
            }
            
            if novel != nil {
                // 回复小说评论
                addNovelCommentItemItem(selecI)
                return
            }
            
            let req = CommentAddReplyReq()
            req.content = self.input.text!
            req.videoId = self.video.videoId
            req.parentId = selecI.commentId
            self.clearInput()
            Session.request(req) { (error, resp) in
                Alert.hideLoading()
                guard error == nil else {
                    mm_showToast(error!.localizedDescription)
                    return
                }
                if resp is CommentItemItem {
                    let newItem = resp as! CommentItemItem
                    selecI.reply.insert(newItem, at: 0)
                    self.video.commentNum = self.video.commentNum + 1
                    self.count.text = "\(num2TenThousandStrFormat(self.video.commentNum))條評論"
                    self.expandHandelItems()
                    self.tableView.reloadData()
                }
            }
            return
        }
        //MARK:-回复别人的二级评论
        guard let selecI = self.selectedItem as? CommentItemItem, let parentItem = self.selectParentItem else { return }
        
        if self.timelineItem != nil {
            replyTimeLineCommnetItemItem(selecI,parentItem)
            return
        }
        
        if novel != nil {
            replyNovelCommentItemItem(selecI, parentItem)
            return
        }
        
        //回复别人的评论
        //评论二级
        let req = CommentAddReplyReq()
        req.content = self.input.text!
        req.videoId = self.video.videoId
        req.parentId = parentItem.commentId
        req.replyUserId = selecI.replyUserId
        req.replyUserNickName = selecI.userNickName
        self.clearInput()
        Session.request(req) { (error, resp) in
            Alert.hideLoading()
            guard error == nil else {
                mm_showToast(error!.localizedDescription)
                return
            }
            if resp is CommentItemItem {
                let newItem = resp as! CommentItemItem
                parentItem.reply.insert(newItem, at: 0)
                self.video.commentNum = self.video.commentNum + 1
                self.count.text = "\(num2TenThousandStrFormat(self.video.commentNum))條評論"
                self.expandHandelItems()
                self.tableView.reloadData()
            }
        }
        
    }
    
    //MARK:-评论完毕
    func clearInput() {
        self.input.text = ""
        self.send.isEnabled = false
        self.selectedItem = nil
        self.selectParentItem = nil
        self.input.attributedPlaceholder = NSAttributedString(string: "觀而不論非英雄，留下你的評論吧～", attributes: [NSAttributedString.Key.font : UIFont.systemFont(ofSize: 13, weight: .medium),NSAttributedString.Key.foregroundColor:RGB(84,94,119)])
    }
    
    //MARK:-载入评论
    func loadData() {
        let req = CommentListReq()
        req.videoId = self.video.videoId
        req.lastId = self.items.count > 0 ? self.items.last!.commentId:0
        Session.request(req){(erorr, resp) in
            if (erorr != nil) {
                mm_showToast(erorr!.localizedDescription)
                if req.lastId == 0 {
                    self.tableView.state = .failed
                }
            }
            if let comments  = resp as? CommentListResp {
                self.nomoreData = comments.list.count < 30
                if req.lastId == 0 {
                    self.items = comments.list
                    if comments.list.isEmpty {
                        self.tableView.state = .empty
                    } else {
                        self.tableView.state = .normal
                    }
                } else {
                    self.items.append(contentsOf: comments.list)
                    self.tableView.state = .normal
                }
                self.items = self.items.map { (item) -> CommentItem in
                    if item.reply.count > 3 {
                        item.displayItems = Array(item.reply.prefix(3))
                    } else {
                        item.displayItems = item.reply
                    }
                    return item
                }
                
                self.tableView.reloadData()
            }
        }
    }
    
    func loadTimeLineData() {
        let req = TimeLineCommentListReq()
        req.dynamicId = timelineItem!.dynamicId
        req.lastId = self.items.count > 0 ? self.items.last!.commentId:0
        if let v = timelineItem!.video {
            req.videoId = v.videoId
        }
        Session.request(req){(erorr, resp) in
            if (erorr != nil) {
                mm_showToast(erorr!.localizedDescription)
                if req.lastId == 0 {
                    self.tableView.state = .failed
                }
            }
            if let commentResp  = resp as? CommentListResp {
                self.count.text = "\(num2TenThousandStrFormat(commentResp.total))條評論"
                self.nomoreData = commentResp.data.count < 30
                if req.lastId == 0 {
                    self.items = commentResp.data
                    if commentResp.data.isEmpty {
                        self.tableView.state = .empty
                    } else {
                        self.tableView.state = .normal
                    }
                } else {
                    self.items.append(contentsOf: commentResp.data)
                    self.tableView.state = .normal
                }
                self.items = self.items.map { (item) -> CommentItem in
                    if item.reply.count > 3 {
                        item.displayItems = Array(item.reply.prefix(3))
                    } else {
                        item.displayItems = item.reply
                    }
                    return item
                }
                self.tableView.reloadData()
            }
        }
    }
    
    
    lazy var tableView : UITableView = {
        let tableView = UITableView.init(frame: CGRect.zero, style: .plain)
        tableView.delegate = self
        tableView.dataSource = self
        tableView.clipsToBounds = true
        tableView.backgroundColor = .none
        tableView.separatorStyle = .none
        tableView.register(CommentCell.self, forCellReuseIdentifier:"CELL" )
        tableView.tableFooterView = UIView()
        tableView.keyboardDismissMode = .onDrag
        tableView.state = .loading
        tableView.loadMoreBlock = { [unowned self] in
            guard self.nomoreData == false else {
                return
            }
            if self.timelineItem != nil {
                self.loadTimeLineData()
            } else {
                self.loadData()
            }
        }
        return tableView
    }()
}

//MARK:-UITextFieldDelegate
extension CommentVC:UITextFieldDelegate {
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        if string.count == 0 {
            return true
        }
        guard let existedLength = textField.text?.count else { return false }
        let selectedLength = range.length;
        let replaceLength = string.count;
        if (existedLength - selectedLength + replaceLength > 200){
            return false
        }
        return true
    }
}

//_______________________________________________________________________________________________________________
// MARK: - UITableViewDelegate&UITableViewDataSource
extension CommentVC:UITableViewDelegate,UITableViewDataSource {
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "CELL") as! CommentCell
        let item = items[indexPath.row]
        if timelineItem != nil {
            cell.configure = (item,self.timelineItem!.userId)
        } else {
            cell.configure = (item,self.video.userId)
        }
        cell.delegate = self
        return cell
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return items.count
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        self.selectedItem = self.items[indexPath.row]
        let selecti = self.items[indexPath.row]
        if !self.input.isFirstResponder {
            self.input.becomeFirstResponder()
        } else {
            self.input.resignFirstResponder()
        }
        self.input.attributedPlaceholder = NSAttributedString(string: "@\(selecti.userNickName):", attributes: [NSAttributedString.Key.font : UIFont.systemFont(ofSize: 13, weight: .medium),NSAttributedString.Key.foregroundColor:RGB(84,94,119)])
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        let item = items[indexPath.row]
        return CommentCell.height(comment: item)
    }
}

//_______________________________________________________________________________________________________________
// MARK: -CommentCellDelegate
extension CommentVC:CommentCellDelegate {
    //MARK: 二级点赞
    func commentCell(_ cell: CommentItemItemCell, parentItem: CommentItem, didTapLikeOrCancel button: UIButton, _ item: CommentItemItem) {
        print(#function)
        guard let item = cell.configure.item else {
            return
        }
        let userId = NetDefaults.userInfo!.userId
        if (button.isSelected) {
            item.likeNum = item.likeNum - 1
            
            if self.timelineItem != nil {
                //MARK:-朋友圈二级取消点赞
                let req = TimeLineCancelLikeCommentReq()
                req.dynamicId = self.timelineItem!.dynamicId
                req.commentId = item.commentId
                req.commentUserId = item.userId
                req.parentId = parentItem.commentId
                Session.request(req) { (error, resp) in
                    guard error == nil else {
                        return
                    }
                    item.likeUserIds.removeAll { (id) -> Bool in
                        return id == userId
                    }
                }
            } else if novel != nil {
                //MARK:-小说二集取消点赞
                let req = CancelNovelCommentLikeReq()
                req.id  = item.id
                Session.request(req) { (e, resp) in
                    guard e == nil  else {return}
                    item.likeUserIds.removeAll { $0 == userId }
                }
            } else {
                let req = CancelCommentLikeReq()
                req.videoId = self.video.videoId
                req.commentId = item.commentId
                req.parentId = parentItem.commentId
                Session.request(req) { (error, resp) in
                    guard error == nil else {
                        return
                    }
                    item.likeUserIds.removeAll { (id) -> Bool in
                        return id == userId
                    }
                }
            }
        } else {
            item.likeNum = item.likeNum + 1
            if self.timelineItem != nil {
                //MARK:-朋友圈二级取消点赞
                let req = TimeLineLikeCommentReq()
                req.dynamicId = self.timelineItem!.dynamicId
                req.commentId = item.commentId
                req.commentUserId = item.userId
                req.parentId = parentItem.commentId
                Session.request(req) { (error, resp) in
                    guard error == nil else {
                        return
                    }
                    item.likeUserIds.append(userId)
                }
            } else if novel != nil {
                let req = SaveNovelCommentLikeReq()
                req.id  = item.id
                Session.request(req) { (e, resp) in
                    guard e == nil  else {return}
                    item.likeUserIds.removeAll { $0 == userId }
                }
            } else {
                let req = SaveCommentLikeReq()
                req.videoId = self.video.videoId
                req.commentId = item.commentId
                req.parentId = parentItem.commentId
                Session.request(req) { (error, resp) in
                    guard error == nil else {
                        return
                    }
                    item.likeUserIds.append(userId)
                }
            }
        }
        
        cell.likeCount.text = num2TenThousandStrFormat(item.likeNum)
        button.isSelected = !button.isSelected
        cell.likeCount.textColor = button.isSelected ? RGB(0xffE62865):RGB(0xffA0A3AE)
    }
    
    //MARK:- 点击二级评论头像
    func commentCell(_ cell: CommentItemItemCell, didTapAvatarIcon avatar: UIImageView, _ item: CommentItemItem) {
        print(#function)
        dismiss(animated: true) {
            self.gotoUserMainPageVC(item.userId)
        }
    }
    //MARK:- 回复二级评论
    func commentCell(_ cell: CommentCell, parentItem: CommentItem, didTapRow atItem: CommentItemItem) {
        print(#function)
        if !self.input.isFirstResponder {
            self.input.becomeFirstResponder()
        } else {
            self.input.resignFirstResponder()
        }
        self.selectedItem = atItem
        self.input.attributedPlaceholder = NSAttributedString(string: "@\(atItem.userNickName):", attributes: [NSAttributedString.Key.font : UIFont.systemFont(ofSize: 13, weight: .medium),NSAttributedString.Key.foregroundColor:RGB(84,94,119)])
        self.selectParentItem = parentItem
    }
    
    //MARK:点击一级头像
    func commentCell(_ cell: CommentCell, didTapAvatar avatar: UIImageView, _ item: CommentItem) {
        print(#function)
        dismiss(animated: true) {
            self.gotoUserMainPageVC(item.userId)
        }
    }
    
    //MARK: 一级点赞
    func commentCell(_ cell: CommentCell, didTapLike button: UIButton, _ item: CommentItem) {
        guard let item = cell.configure.item else {
            return
        }
        
        let userId = NetDefaults.userInfo!.userId
        
        if (button.isSelected) {
            item.likeNum = item.likeNum - 1
            if self.timelineItem != nil {
                //MARK:-朋友圈点赞取消
                let req = TimeLineCancelLikeCommentReq()
                req.dynamicId = self.timelineItem!.dynamicId
                req.commentId = item.commentId
                req.commentUserId = item.userId
                Session.request(req) { (error, resp) in
                    guard error == nil else {
                        return
                    }
                    item.likeUserIds.removeAll { (id) -> Bool in
                        return id == userId
                    }
                }
            } else if novel != nil {
                let req = CancelNovelCommentLikeReq()
                req.id  = item.id
                Session.request(req) { (e, resp) in
                    guard e == nil  else {return}
                    item.likeUserIds.removeAll { $0 == userId }
                }
                return
            } else {
                let req = CancelCommentLikeReq()
                req.videoId = self.video.videoId
                req.commentId = item.commentId
                Session.request(req) { (error, resp) in
                    guard error == nil else {
                        return
                    }
                    item.likeUserIds.removeAll { (id) -> Bool in
                        return id == userId
                    }
                }
            }
        } else {
            item.likeNum = item.likeNum +  1
            if self.timelineItem != nil {
                //MARK:-朋友圈点赞
                let req = TimeLineLikeCommentReq()
                req.dynamicId = self.timelineItem!.dynamicId
                req.commentId = item.commentId
                req.commentUserId = item.userId
                Session.request(req) { (error, resp) in
                    guard error == nil else {
                        return
                    }
                    item.likeUserIds.append(userId)
                }
            } else if novel != nil {
                //MARK:-小说点赞
                let req = SaveNovelCommentLikeReq()
                req.id = item.id
                Session.request(req) { (e, resp) in
                    guard e == nil else {return}
                    item.likeUserIds.append(userId)
                }
                return
            } else {
                let req = SaveCommentLikeReq()
                req.videoId = self.video.videoId
                req.commentId = item.commentId
                Session.request(req) { (error, resp) in
                    guard error == nil else {
                        return
                    }
                    item.likeUserIds.append(userId)
                }
            }
        }
        cell.likeCount.text = num2TenThousandStrFormat(item.likeNum)
        button.isSelected = !button.isSelected
        cell.likeCount.textColor = button.isSelected ? RGB(0xffE62865):RGB(0xffA0A3AE)
    }
    
    //MARK:-展开
    func commentCell(_ cell: CommentCell, expandAction item: CommentItem) {
        let count = item.reply.count - item.displayItems.count
        if count > 3 {
            item.displayItems = Array(item.reply.prefix(item.displayItems.count + 3))
        } else {
            item.displayItems = item.reply
        }
        self.tableView.reloadData()
    }
    
    //  进入用户信息页面
    func gotoUserMainPageVC(_ userId: Int) {
        let vc = UsersDynamicVC()
        vc.userId = userId
        let navVC = (UIApplication.shared.delegate as? AppDelegate)?.currentNavigationController
        navVC?.pushViewController(vc, animated: true)
    }
}

