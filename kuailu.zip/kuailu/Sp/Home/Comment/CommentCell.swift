//
//  CommentCell.swift
//  Sp
//
//  Created by mac on 2020/3/2.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

public let kFontName = UIFont.systemFont(ofSize: 12, weight: UIFont.Weight.regular)
public let kFontContent = UIFont.systemFont(ofSize: 12, weight: .regular)
public let kColorName = RGB(0xffC0C0C0)
public let kColorContent = UIColor.white
public let tableFooterH :CGFloat = 25

//_______________________________________________________________________________________________________________
// MARK: - CommentCellDelegate
@objc protocol CommentCellDelegate {
    //头像
    func commentCell(_ cell: CommentCell, didTapAvatar avatar: UIImageView, _ item: CommentItem)
    //点赞
    func commentCell(_ cell: CommentCell, didTapLike button: UIButton, _ item: CommentItem)
    
    //点赞
    func commentCell(_ cell: CommentItemItemCell,parentItem:CommentItem, didTapLikeOrCancel  button: UIButton, _ item: CommentItemItem)
    //点击二级头像
    func commentCell(_ cell: CommentItemItemCell, didTapAvatarIcon avatar: UIImageView, _ item: CommentItemItem)
    //点击二级一整行
    func commentCell(_ cell: CommentCell,parentItem:CommentItem, didTapRow atItem: CommentItemItem)
    
    //// 展开
    func commentCell(_ cell:CommentCell, expandAction item:CommentItem)
    
}

class CommentCell: UITableViewCell {
    
    weak var delegate:CommentCellDelegate?
    
    private static let avatarImg: UIImage? = {
          return Sensitive.avatar
       }()
          
       private static let animationOption: KingfisherOptionsInfo = {
          return [.transition(.fade(0.25))]
       }()
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        self.selectionStyle = .none
        self.contentView.backgroundColor = .clear
        self.backgroundColor = .clear
        self.contentView.isUserInteractionEnabled = true
        setUI()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    var configure:(item:CommentItem?,userId:Int?){
        didSet {
            guard let item = configure.item else {
                return
            }
            guard let id = configure.userId else {
                return
            }
            if item.displayItems.count != item.reply.count {
                expandDesc.text = "—— 展開\(item.reply.count - item.displayItems.count)條回覆 "
                self.tableView.tableFooterView = self.tableFooterView
            } else {
                self.tableView.tableFooterView = UIView()
            }
            self.author.isHidden = item.userId !=  id
            if self.author.isHidden  {
                self.level.snp.remakeConstraints { (make) in
                    make.left.equalTo(self.name.snp.right).offset(6)
                    make.size.equalTo(CGSize(width: 47, height: 17))
                    make.centerY.equalTo(self.name)
                }
            } else {
                // 不隐藏的话
                self.level.snp.remakeConstraints { (make) in
                    make.left.equalTo(self.author.snp.right).offset(6)
                    make.size.equalTo(CGSize(width: 47, height: 17))
                    make.centerY.equalTo(self.name)
                }
            }
            self.level.isHidden = item.level == 0
            self.level.level.text = "\(item.level)"
            
            if (item.userLogo == nil) {
                self.avatar.image = CommentCell.avatarImg
            } else {
                self.avatar.kf.setImage(with: item.userLogo,placeholder: CommentCell.avatarImg, options: CommentCell.animationOption)
            }
            self.name.text = item.userNickName
            self.likeCount.text = "\(item.likeNum)"
            if let user = NetDefaults.userInfo {
                self.like.isSelected = item.likeUserIds.contains(user.userId)
            }
            self.likeCount.textColor = self.like.isSelected ? RGB(0xffE62865):RGB(0xffA0A3AE)
            
            let timeInterV:Double = item.createdAt?.timeIntervalSince1970 ?? 0
            self.content.attributedText = CommentCell.content(des: item.content,city:item.cityName, time: Date.getCompareCurrntTime(timeStamp:String(timeInterV)))
            
            self.tableView.snp.remakeConstraints{ (make) in
                make.left.right.equalToSuperview()
                make.top.equalTo(self.content.snp.bottom).offset(12)
                make.height.equalTo(CommentCell.tableViewhHeight(comment: item))
            }
            self.tableView.reloadData()
        }
    }

    //MARK:-内容
    class func content(des:String,city:String,time:String)->NSMutableAttributedString {
        let attr = NSMutableAttributedString(string: "\(des)    \(city)  \(time)")
        attr.setAttributes([NSAttributedString.Key.font :kFontContent,NSAttributedString.Key.foregroundColor:kColorContent], range: NSRange(location: 0, length: des.count))
        attr.setAttributes([NSAttributedString.Key.font :UIFont.systemFont(ofSize: 10, weight: .medium),NSAttributedString.Key.foregroundColor:RGB(0xff9D9D9D) ], range: NSRange(location: attr.length - "\(city)  \(time)".count , length: "\(city)  \(time)".count))
        return attr
    }
    
    //MARK:-高度
    class func height(comment:CommentItem) ->CGFloat{
        let nameH = height(text: comment.userNickName, width: 300, font: kFontName)
        let timeInterV:Double = comment.createdAt?.timeIntervalSince1970 ?? 0
        let content = CommentCell.content(des: comment.content,city:comment.cityName, time: Date.getCompareCurrntTime(timeStamp: String(timeInterV)))
        let H = 13 + nameH + 4 + height(text: content.string, width: UIScreen.main.bounds.size.width - 110, font: kFontContent) + 12
        
        if comment.reply.count > 0 {
            let tableH = CommentCell.tableViewhHeight(comment: comment)
            return H +  12 + tableH
        }
        return H
    }
    
    //MARK:-UITableView高度
   class func  tableViewhHeight(comment:CommentItem) ->CGFloat {
      let expand = comment.displayItems.count != comment.reply.count
      let items = expand ? comment.displayItems: comment.reply
        if items.count > 0 {
            var subH:CGFloat = 0
            for i in 0..<items.count {
                let item = items[i]
                let h = CommentItemItemCell.height(item: item)
                subH  = subH + h
            }
            return expand ? subH + tableFooterH: subH
        }
        return 0
    }
    
    //MARK:-根据文字内容和字型算高度
    class func height(text: String,width:CGFloat,font:UIFont) -> CGFloat {
        let maxSize = CGSize(width: width, height: CGFloat(MAXFLOAT))
        let paragraphStyle = NSMutableParagraphStyle()
        paragraphStyle.alignment = .justified
        paragraphStyle.lineBreakMode = .byWordWrapping
        paragraphStyle.lineSpacing = 5.0
        let labelSize = NSString(string: text).boundingRect(with: maxSize,
                                                            options: [.usesFontLeading, .usesLineFragmentOrigin],
                                                            attributes:[.font : font, .paragraphStyle: paragraphStyle],
                                                            context: nil).size
        return labelSize.height
    }
    
    
    //_______________________________________________________________________________________________________________
    // MARK: - setUI
    func setUI() {
        contentView.addSubview(self.avatar)
        self.avatar.snp.makeConstraints { (make) in
            make.left.top.equalTo(12)
            make.size.equalTo(CGSize(width: 36, height: 36))
        }
        
        contentView.addSubview(self.name)
        name.snp.makeConstraints { (make) in
            make.left.equalTo(self.avatar.snp.right).offset(6)
            make.top.equalTo(16)
        }
        
        contentView.addSubview(self.author)
        self.author.isHidden = true
        self.author.snp.makeConstraints { (make) in
            make.left.equalTo(self.name.snp.right).offset(6)
            make.size.equalTo(CGSize(width: 30, height: 15))
            make.centerY.equalTo(self.name)
        }
        
        contentView.addSubview(self.level)
        self.level.snp.makeConstraints { (make) in
            make.left.equalTo(self.name.snp.right).offset(6)
            make.size.equalTo(CGSize(width: 47, height: 17))
            make.centerY.equalTo(self.name)
        }
        contentView.addSubview(self.like)
        self.like.snp.makeConstraints { (make) in
            make.size.equalTo(CGSize(width: 22, height: 22))
            make.top.equalTo(12)
            make.right.equalTo(-12)
        }
        
        contentView.addSubview(self.likeCount)
        likeCount.snp.makeConstraints { (make) in
            make.centerX.equalTo(self.like)
            make.top.equalTo(self.like.snp.bottom).offset(0)
        }
        
        contentView.addSubview(self.content)
        self.content.snp.makeConstraints { (make) in
            make.left.equalTo(self.name)
            make.top.equalTo(self.name.snp.bottom).offset(4)
            make.right.equalTo(-54)
        }
        
//        contentView.addSubview(self.line)
//        self.line.snp.makeConstraints { (make) in
//            make.left.equalTo(54)
//            make.bottom.equalToSuperview()
//            make.right.equalToSuperview()
//            make.height.equalTo(1)
//        }
        contentView.addSubview(self.tableView)
        self.tableView.snp.makeConstraints { (make) in
            make.left.right.equalToSuperview()
            make.top.equalTo(self.content.snp.bottom).offset(12)
        }
    }
    
    lazy var tableFooterView :UIView = {
        let f = UIView()
        f.backgroundColor = .clear
        f.addSubview(self.expandDesc)
        self.expandDesc.snp.makeConstraints { (make) in
            make.top.bottom.equalToSuperview()
            make.left.equalTo(54)
        }
        
        f.addSubview(self.expandIcon)
        self.expandIcon.snp.makeConstraints { (make) in
            make.left.equalTo(self.expandDesc.snp.right).offset(3)
            make.size.equalTo(CGSize(width: 9, height: 6))
            make.centerY.equalTo(self.expandDesc)
        }
        
        let tap = UITapGestureRecognizer(target: self, action:#selector(self.expandAction))
        f.isUserInteractionEnabled = true
        f.addGestureRecognizer(tap)
        return f
    }()
    
    lazy var expandIcon:UIImageView = {
        let logo = UIImageView()
        logo.image = UIImage(named: "expand")
        return logo
    }()
    
    //MARK:-展开
    @objc func expandAction() {
        puts(#function)
        guard let item = self.configure.item else {
            return
        }
        self.delegate?.commentCell(self, expandAction:item)
    }
    
    lazy var expandDesc:UILabel = {
        let label = UILabel()
        label.text = "—— 展開0條回覆 "
        label.textColor = RGB(0xffC0C0C0)
        label.font = FONT(10)
        return label
    }()
    
    //_______________________________________________________________________________________________________________
    // MARK: - 懒载入
    lazy var avatar:UIImageView = {
        let logo = UIImageView()
        logo.clipsToBounds = true
        logo.layer.cornerRadius = 18
        logo.isUserInteractionEnabled = true
        let tap = UITapGestureRecognizer(target: self, action:#selector(self.userDetail(_:)))
        logo.addGestureRecognizer(tap)
        return logo
    }()
    
    @objc func userDetail(_ tap:UITapGestureRecognizer) {
        self.delegate?.commentCell(self, didTapAvatar: tap.view as! UIImageView, self.configure.item!)
    }
    
    lazy var name:UILabel = {
        let label = UILabel()
        label.textColor = kColorName
        label.font = kFontName
        return label
    }()
    
    lazy var content:UILabel = {
        let label = UILabel()
        label.numberOfLines = 0
        return label
    }()
    
    lazy var like:UIButton = {
        let button = UIButton()
        button.setImage(UIImage(named: "like_comment_s"), for: UIControl.State.selected)
        button.setImage(UIImage(named: "like_comment_n"), for: UIControl.State.normal)
        button.setEnlargeEdge(top: 20, bottom: 20, left: 20, right: 20)
        button.addTarget(self, action: #selector(self.likeAction(_:)), for: UIControl.Event.touchUpInside)
        return button
    }()
    
    lazy var level:CommentLevelView = {
        let v = Bundle.main.loadNibNamed("CommentLevelView", owner: nil, options: [:])?.first as! CommentLevelView
        return v
    }()
    
    //MARK:-点赞数
    lazy var likeCount:UILabel = {
        let label = UILabel()
        label.font = UIFont.systemFont(ofSize: 9, weight: .medium)
        label.textColor = RGB(161,161,181)
        label.textAlignment = .center
        return label
    }()
    
    //MARK:-分割线
    lazy var line:UIView = {
        let view = UIView()
        view.backgroundColor = RGB(37,38,77)
        return view
    }()
    
    lazy var tableView : UITableView = {
        let tableView1 = UITableView.init(frame: CGRect.zero, style: .plain)
        tableView1.delegate = self
        tableView1.dataSource = self
        tableView1.backgroundColor = .clear
        tableView1.isScrollEnabled = false
        tableView1.separatorStyle = UITableViewCell.SeparatorStyle.none
        tableView1.register(CommentItemItemCell.self, forCellReuseIdentifier:"CELL1" )
        tableView1.tableFooterView = self.tableFooterView
        return tableView1
    }()
    
    //MARK:-是否是作者本人
    lazy var author:UILabel = {
        let label = UILabel()
        label.font = UIFont.systemFont(ofSize: 9, weight: .bold)
        label.textColor = .white
        label.text = "作者"
        label.textAlignment = .center
        label.clipsToBounds = true
        label.layer.cornerRadius = 5.0
        label.backgroundColor = RGB(230,40,101)
        return label
    }()
    
    @objc func likeAction(_ sender:UIButton) {
        Animation.scaleBounce(sender)
        self.delegate?.commentCell(self, didTapLike: sender, self.configure.item!)
    }
}

// MARK: -UITableViewDataSource && Delegate
extension CommentCell:UITableViewDataSource,UITableViewDelegate {
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "CELL1") as! CommentItemItemCell
        cell.delegate = self
        cell.configure = (item:self.configure.item?.displayItems[indexPath.row],userId:self.configure.userId)
        return cell
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.configure.item?.displayItems.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if let model = self.configure.item?.displayItems[indexPath.row] {
            self.delegate?.commentCell(self, parentItem: self.configure.item!, didTapRow: model)
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        guard let item = self.configure.item?.displayItems[indexPath.row] else {
            return 0
        }
        let h = CommentItemItemCell.height(item: item)
        return h
    }
    
    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        return self.tableFooterView
    }
    
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        guard let item = self.configure.item else {
            return 0
        }
        return  item.displayItems.count != item.reply.count ? tableFooterH : 0
    }
}

//_______________________________________________________________________________________________________________
// MARK: - CommentItemItemCellDelgate
extension CommentCell:CommentItemItemCellDelgate {
    func commentItemItemCell(_ cell: CommentItemItemCell, didTapLike button: UIButton, _ item: CommentItemItem) {
        self.delegate?.commentCell(cell, parentItem: self.configure.item!, didTapLikeOrCancel: button, item)
    }
    func commentItemItemCell(_ cell: CommentItemItemCell, didTapAvatar avatar: UIImageView, _ item: CommentItemItem) {
        self.delegate?.commentCell(cell, didTapAvatarIcon: avatar, item)

    }
}

