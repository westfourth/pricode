//
//  CommentItemItemCell.swift
//  Sp
//
//  Created by mac on 2020/3/2.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit


@objc protocol CommentItemItemCellDelgate {
    ///点赞取消点赞
    func commentItemItemCell(_ cell: CommentItemItemCell, didTapLike button:UIButton, _ item:CommentItemItem)
    //点击头像
    func commentItemItemCell(_ cell: CommentItemItemCell, didTapAvatar avatar:UIImageView,_ item:CommentItemItem)
    
}

class CommentItemItemCell: UITableViewCell {
    
    weak var delegate: CommentItemItemCellDelgate?
    
    private static let avatarImg: UIImage? = {
          return Sensitive.avatar
       }()
          
       private static let animationOption: KingfisherOptionsInfo = {
          return [.transition(.fade(0.25))]
       }()
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        self.selectionStyle = .none
        self.backgroundColor = .clear
        setUI()
    }
    
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    var configure:(item:CommentItemItem?,userId:Int?){
        didSet {
            guard  let item = configure.item else {
                return
            }
            guard  let id = configure.userId else {
                return
            }
            self.author.isHidden = item.userId !=  id
            
            if self.author.isHidden  {
                self.level.snp.remakeConstraints { (make) in
                    make.left.equalTo(self.name.snp.right).offset(6)
                    make.size.equalTo(CGSize(width: 47, height: 17))
                    make.centerY.equalTo(self.name)
                }
            } else {
                // 不隐藏的话
                self.level.snp.remakeConstraints { (make) in
                    make.left.equalTo(self.author.snp.right).offset(6)
                    make.size.equalTo(CGSize(width: 47, height: 17))
                    make.centerY.equalTo(self.name)
                }
            }
            self.level.isHidden = item.level == 0
            self.level.level.text = "\(item.level)"
            if (item.userLogo == nil) {
                self.avatar.image = CommentItemItemCell.avatarImg
            } else {
                self.avatar.kf.setImage(with: item.userLogo, placeholder: CommentItemItemCell.avatarImg, options: CommentItemItemCell.animationOption)
            }
            self.name.text = item.userNickName
            let timeInterV:Double = item.createdAt?.timeIntervalSince1970 ?? 0
            let time =  Date.getCompareCurrntTime(timeStamp: "\(timeInterV)")
            self.content.attributedText =  CommentCell.content(des: item.replyUserNickName == "" ? item.content:"回覆\(item.replyUserNickName):\(item.content)",city: item.cityName, time: "\(time)")
            self.likeCount.text = "\(item.likeNum)"
            if let user = NetDefaults.userInfo {
                self.like.isSelected = item.likeUserIds.contains(user.userId)
            }
            self.likeCount.textColor = self.like.isSelected ? RGB(0xffE62865):RGB(0xffA0A3AE)
        }
    }
    
    class func height(item:CommentItemItem) ->CGFloat {
        let timeInterV:Double = item.createdAt?.timeIntervalSince1970 ?? 0
        let time =  Date.getCompareCurrntTime(timeStamp: "\(timeInterV)")
        
       let contentStr = item.replyUserNickName == "" ? "\(item.content)  \(time)": "回覆\(item.replyUserNickName):\(item.content)  \(time)"
        
        return 8 + 15 + 5 + CommentCell.height(text: contentStr, width:UIScreen.main.bounds.size.width - 120, font: kFontContent) + 4 + 2
    }
    
    func setUI() {
        contentView.addSubview(self.avatar)
        self.avatar.snp.makeConstraints { (make) in
            make.top.equalTo(8)
            make.left.equalTo(54)
            make.size.equalTo(CGSize(width: 23, height: 23))
        }
        
        contentView.addSubview(self.name)
        self.name.snp.makeConstraints { (make) in
            make.left.equalTo(self.avatar.snp.right).offset(4)
            make.top.equalTo(self.avatar)
        }
        
        contentView.addSubview(self.author)
        self.author.isHidden = true
        self.author.snp.makeConstraints { (make) in
            make.left.equalTo(self.name.snp.right).offset(6)
            make.size.equalTo(CGSize(width: 30, height: 15))
            make.centerY.equalTo(self.avatar)
        }
        
        
        contentView.addSubview(self.level)
        self.level.snp.makeConstraints { (make) in
            make.left.equalTo(self.name.snp.right).offset(6)
            make.size.equalTo(CGSize(width: 47, height: 17))
            make.centerY.equalTo(self.name)
        }
        
        contentView.addSubview(self.content)
        self.content.snp.makeConstraints { (make) in
            make.left.equalTo(self.name)
            make.top.equalTo(self.name.snp.bottom).offset(5)
            make.right.equalTo(-54)
        }
        
        contentView.addSubview(self.like)
        self.like.snp.makeConstraints { (make) in
            make.size.equalTo(CGSize(width: 22, height: 22))
            make.centerY.equalToSuperview()
            make.right.equalTo(-12)
        }
        
        contentView.addSubview(self.likeCount)
        likeCount.snp.makeConstraints { (make) in
            make.centerX.equalTo(self.like)
            make.top.equalTo(self.like.snp.bottom)
        }
    }
    
    //_______________________________________________________________________________________________________________
    // MARK: - 懒载入
    lazy var avatar:UIImageView = {
        let logo = UIImageView()
        logo.clipsToBounds = true
        logo.layer.cornerRadius = 11.5
        logo.isUserInteractionEnabled = true
        self.contentView.isUserInteractionEnabled = true
        let tap = UITapGestureRecognizer(target: self, action:#selector(self.userDetail(_:)))
        logo.addGestureRecognizer(tap)
        return logo
    }()
    
    @objc func userDetail(_ tap:UITapGestureRecognizer) {
        self.delegate?.commentItemItemCell(self, didTapAvatar: tap.view as! UIImageView,self.configure.item!)
    }
    
    lazy var name:UILabel = {
        let label = UILabel()
        label.textColor = kColorName
        label.font = kFontName
        return label
    }()
    
    lazy var content:UILabel = {
        let label = UILabel()
        label.textColor = RGB(0xffFFFFFF)
        label.numberOfLines = 0
        label.font = kFontContent
        return label
    }()
    
    lazy var like:UIButton = {
        let button = UIButton()
        button.setImage(UIImage(named: "like_comment_s"), for: UIControl.State.selected)
        button.setImage(UIImage(named: "like_comment_n"), for: UIControl.State.normal)
        button.setEnlargeEdge(top: 20, bottom: 20, left: 20, right: 20)
        button.addTarget(self, action: #selector(self.likeAction(_:)), for: UIControl.Event.touchUpInside)
        return button
    }()
    
    //MARK:-点赞数
    lazy var likeCount:UILabel = {
        let label = UILabel()
        label.font = UIFont.systemFont(ofSize: 9, weight: .medium)
        label.textAlignment = .center
        label.textColor = RGB(161,161,181)
        return label
    }()
    
    //MARK:-是否是作者本人
    lazy var author:UILabel = {
        let label = UILabel()
        label.font = UIFont.systemFont(ofSize: 9, weight: .bold)
        label.textColor = .white
        label.textAlignment = .center
        label.clipsToBounds = true
        label.layer.cornerRadius = 5.0
        label.backgroundColor = RGB(230,40,101)
        label.text = "作者"
        return label
    }()
    
    lazy var level:CommentLevelView = {
           let v = Bundle.main.loadNibNamed("CommentLevelView", owner: nil, options: [:])?.first as! CommentLevelView
           return v
       }()
       
    
    
    @objc func likeAction(_ sender:UIButton) {
        Animation.scaleBounce(sender)
        self.delegate?.commentItemItemCell(self, didTapLike: sender,self.configure.item!)
    }
    
}
