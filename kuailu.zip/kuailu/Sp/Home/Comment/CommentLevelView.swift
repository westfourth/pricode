//
//  CommentLevelView.swift
//  Sp
//
//  Created by mac on 2020/6/20.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class CommentLevelView: UIView {

    @IBOutlet weak var level: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }

}
