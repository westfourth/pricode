//
//  OtherHead.swift
//  Sp
//
//  Created by mac on 2020/2/29.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

@objc protocol OtherHeadDelegate {
    /// 关注列表
    func atttentionDetail(_ item:UserBase)
    /// 粉丝列表
    func fansDetail(_ item:UserBase)
}

class OtherHead: UIView {
    
    weak var delegate: OtherHeadDelegate?
    
    @IBOutlet weak var userId: UILabel!
    @IBOutlet weak var avatar: UIImageView!
    @IBOutlet weak var name: UILabel!
    @IBOutlet weak var introduction: UILabel!
    @IBOutlet weak var focus: UIButton!
    @IBOutlet weak var attention: UILabel!
    @IBOutlet weak var fans: UILabel!
    @IBOutlet weak var invite: UILabel!
    
    private static let avatarImg: UIImage? = {
        return Sensitive.avatar
    }()
    
    private static let animationOption: KingfisherOptionsInfo = {
        return [.transition(.fade(0.25))]
    }()
    
    var searchFocusListClosure: ((_ isAttention: Bool) ->())?
    
    override func awakeFromNib() {
        
        super.awakeFromNib()
        
        self.focus.setTitleColor(.white, for: UIControl.State.normal)
        self.focus.setTitleColor(.white, for: UIControl.State.selected)
        
        self.focus.setTitle("關注", for: UIControl.State.normal)
        self.focus.setTitle("取消關注", for: UIControl.State.selected)
        
        self.avatar.image = OtherHead.avatarImg
        
        self.isUserInteractionEnabled = true
        //关注和粉丝列表
        self.fans.isUserInteractionEnabled = true
        self.attention.isUserInteractionEnabled = true
        let tap1 = UITapGestureRecognizer(target: self, action: #selector(self.fansAction))
        let tap2 = UITapGestureRecognizer(target: self, action: #selector(self.attentionAction))
        self.fans.addGestureRecognizer(tap1)
        self.attention.addGestureRecognizer(tap2)
    }
    
    @objc func fansAction() {
        guard let item = self.user else {
            return
        }
        self.delegate?.fansDetail(item)
    }
    
    
    @objc func attentionAction() {
        guard let item = self.user else {
            return
        }
        
        self.delegate?.atttentionDetail(item)
    }
    
    @IBAction func focusAction(_ sender: Any) {
        guard  let item = user  else {
            return
        }
        
        if self.focus.isSelected {
            
            Alert.showCommonAlert(parentView: UIApplication.shared.keyWindow!,
                                  contentText: "取消關注後,您將無法及時收到他的動態",
                                  cancelText: "再看看",
                                  confirmText: "取消關注",
                                  onConfirmTap: { [weak self] in
                                    guard let `self` = self else { return }
                                    //取消关注
                                    self.focus.isSelected = false
                                    self.focus.backgroundColor = RGB(230,40,101)
                                    
                                    let req =  CancelFocusUserReq()
                                    req.beenUserId = item.userId
                                    Session.request(req) { [weak self] (error, resp) in
                                        guard let `self` = self, error == nil else { return }
                                        self.searchFocusListClosure?(false)
                                        mm_showToast("取消成功!", type: .succeed)
                                        self.videoItem?.isAttention = false
                                    }
                }, onCancelTap: nil)
        } else {
            //关注
            self.focus.isSelected = true
            self.focus.backgroundColor = RGB(0xff6B6F85)
            
            let req =  FocusUserReq()
            req.beenUserId = item.userId
            Session.request(req) { [weak self] (error, resp) in
                guard let `self` = self, error == nil else { return }
                self.searchFocusListClosure?(true)
                mm_showToast("關注成功!", type: .succeed)
                self.videoItem?.isAttention = true
            }
        }
    }
    
    var videoItem: VideoItem?
    
    var user:UserBase? {
        didSet {
            guard  let item = user  else {
                return
            }
            focus.isHidden = SearchResultFocusCell.userId == item.userId
            self.avatar.kf.setImage(with: item.logo, placeholder: OtherHead.avatarImg, options: OtherHead.animationOption)
            self.name.text = item.nickName
            self.introduction.text = item.personSign == "" ? "這個人很懶，啥也沒留下":item.personSign
            
            self.attention.attributedText = attribute(item.ua, title: "關注")
                       self.fans.attributedText = attribute(item.bu, title: "粉絲")
                       self.invite.attributedText = attribute(item.inviteUserNum, title: "邀請")
            
            
            self.userId.text = "用戶ID：\(item.userId)"
            self.focus.isSelected = item.attentionHe
            if item.attentionHe {
                self.focus.backgroundColor = RGB(0xff6B6F85)
            } else {
                self.focus.backgroundColor = RGB(230,40,101)
            }
        }
    }
    
    func attribute(_ count:Int,title:String)-> NSMutableAttributedString {
        let num = num2TenThousandStrFormat(count)
        let x = NSMutableAttributedString(string: "\(num) \(title)")
        x.addAttributes([NSAttributedString.Key.font :UIFont.systemFont(ofSize: 16, weight: .medium), NSAttributedString.Key.foregroundColor:UIColor.white,
        ], range: NSRange(location: 0, length: num.count))
        x.addAttributes([NSAttributedString.Key.font : UIFont.systemFont(ofSize: 14),NSAttributedString.Key.foregroundColor:UIColor.gray], range: NSRange(location: "\(num) \(title)".count - 2, length: 2))
        return x
    }
}
