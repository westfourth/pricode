//
//  UserMainPageVC.swift
//  Sp
//
//  Created by mac on 2020/2/29.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit
import JXSegmentedView

extension JXPagingListContainerView: JXSegmentedViewListContainer {}

class UserMainPageVC: UIViewController {
    var percentTransition: UIPercentDrivenInteractiveTransition?
    
    private static let avatarImg: UIImage? = {
        return Sensitive.avatar
    }()
    
    private static let animationOption: KingfisherOptionsInfo = {
        return [.transition(.fade(0.25))]
    }()
    
    private var tabBarLabelArr =  ["作品 0","喜歡 0","已\(Sensitive.gou) 0"]
    
    private var tabBarLabelInstanceArr: [UILabel] =  []
    
    private let titles =  ["00000000","00000000","00000000"]
    
    var userId:Int!
    
    var videoItem: VideoItem?
    
    var viewWillDisappearCallback: (() -> Void)?
    
    var user:UserBase?
    
    let naviHeight = UIApplication.shared.keyWindow!.naviHeight()
    
    let topSafeMargin = UIApplication.shared.keyWindow!.insets().top
    
    lazy var pagingView: JXPagingView = JXPagingListRefreshView(delegate: self)
    
    let dataSource: JXSegmentedTitleDataSource = JXSegmentedTitleDataSource()
    
    lazy var segmentedView: JXSegmentedView = JXSegmentedView(frame: CGRect(x: 0, y: 0, width: UIScreen.main.bounds.size.width, height: CGFloat(headerInSectionHeight)))
    
    /// 作品 喜欢已购买
    var controllers:[UIViewController & JXPagingViewListViewDelegate] = [UIViewController & JXPagingViewListViewDelegate]()
    
    var headHeight: Int = Int(kTop + 200)
    var headerInSectionHeight: Int = 44
    
    let publishedVC = PublishedListVC()
    let collectionVC = CollectionListVC()
    let purchasedVC = PurchasedListVC()
    
    func getLableWidth(content:String, font:UIFont,height:CGFloat) -> CGFloat {
        let size = CGSize.init(width: CGFloat(MAXFLOAT), height: height)
        let dic = [NSAttributedString.Key.font:font]
        let cString = content.cString(using: String.Encoding.utf8)
        let str = String.init(cString: cString!, encoding: String.Encoding.utf8)
        let strSize = str?.boundingRect(with: size, options: .usesLineFragmentOrigin, attributes: dic, context:nil).size
        return strSize?.width ?? 0
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.setNavigationBarHidden(true, animated: animated)
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        navigationController?.delegate = self
        self.navigationController?.interactivePopGestureRecognizer?.isEnabled = true
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        navigationController?.delegate = nil
        self.navigationController?.setNavigationBarHidden(false, animated: animated)
        self.viewWillDisappearCallback?()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let pan = XXPanGestureRecognizer(target: self, action: #selector(handlePan(pan:)))
        view.addGestureRecognizer(pan)
        pan.delegate = self
        
        view.backgroundColor = RGB(0xff141516)
        
        configurePagingView()
        
        pagingView.pinSectionHeaderVerticalOffset = Int(naviHeight)
        
        view.addSubview(naviView)
        naviView.frame = CGRect(x: 0, y: 0, width: self.view.bounds.size.width, height: naviHeight)
        
        
        publishedVC.userId = userId
        collectionVC.userId = userId
        purchasedVC.userId = userId
        
        controllers = [publishedVC,collectionVC,purchasedVC]
        
        loadData()
        
    }
    
    //MARK:-载入个人信息资料
    func loadData() {
        let req = FetchUserInfoReq()
        req.userId = self.userId
        Session.request(req) { (error, resp) in
            guard error == nil else {
                return
            }
            if let user = resp as? UserBase  {
                self.user = user
                self.infoView.user = user
                self.infoView.videoItem = self.videoItem
                self.nickname.text = user.nickName
                self.logo.kf.setImage(with: user.logo,placeholder: UserMainPageVC.avatarImg, options: UserMainPageVC.animationOption)
                self.tabBarLabelInstanceArr[0].text  = "作品 \(user.worksNum)"
                self.tabBarLabelInstanceArr[1].text = "喜歡 \(user.favoritesNum)"
                self.tabBarLabelInstanceArr[2].text = "已\(Sensitive.gou) \(user.purVideosNum)"
                //                self.dataSource.titles = self.titles
                //                self.segmentedView.reloadData()
            }
        }
    }
    
    private func renderTabBarView() {
        let width = UIScreen.main.bounds.width / 3
        for i in 0..<tabBarLabelArr.count {
            let tabBar = getTabBarView(index: i)
            segmentedView.addSubview(tabBar)
            segmentedView.sendSubviewToBack(tabBar)
            tabBar.snp.makeConstraints { (make) in
                make.top.height.equalToSuperview()
                make.width.equalTo(width)
                switch i {
                case 0:
                    make.left.equalToSuperview()
                case 1:
                    make.centerX.equalToSuperview()
                default:
                    make.right.equalToSuperview()
                }
            }
            tabBarLabelInstanceArr.append(tabBar)
        }
    }
    
    private func getTabBarView(index: Int)-> UILabel {
        let label = UILabel()
        label.text = tabBarLabelArr[index]
        label.textAlignment = .center
        label.font = UIFont.pingFangRegular(16)
        label.textColor = .white
        label.isUserInteractionEnabled = true
        return label
    }
    
    func indicators()->[JXSegmentedIndicatorLineView] {
        
        var items = [JXSegmentedIndicatorLineView]()
        for _ in 0..<3 {
            let lineView = JXSegmentedIndicatorLineView()
            lineView.indicatorColor = RGB(0xffC1C1C1)
            lineView.indicatorWidth = UIScreen.main.bounds.size.width / 3.0
            lineView.lineStyle = .lengthenOffset
            //                getLableWidth(content: self.titles[i], font: UIFont.systemFont(ofSize: 15, weight: UIFont.Weight.medium), height: 3.0)
            lineView.clipsToBounds = true
            lineView.layer.cornerRadius = 1.0
            items.append(lineView)
        }
        return items
    }
    
    func configurePagingView() {
        renderTabBarView()
        dataSource.titles = titles
        dataSource.titleSelectedColor = .clear
        dataSource.titleNormalColor = .clear
        //        dataSource.isTitleColorGradientEnabled = true
        //        dataSource.isTitleZoomEnabled = false
        //        segmentedView.isContentScrollViewClickTransitionAnimationEnabled = false
        dataSource.titleNormalFont = UIFont.pingFangMedium(16)
        dataSource.titleSelectedFont = UIFont.pingFangMedium(16)
        segmentedView.backgroundColor = RGB(0xff141535)
        segmentedView.delegate = self
        segmentedView.dataSource = dataSource
        
        
        segmentedView.indicators = indicators()
        //        segmentedView.contentEdgeInsetRight = UIScreen.main.bounds.size.width - 200
        //        segmentedView.contentEdgeInsetLeft = 12
        
        segmentedView.contentEdgeInsetRight = MineVC.indicatorMargin
        segmentedView.contentEdgeInsetLeft = MineVC.indicatorMargin
        
        
        pagingView.mainTableView.gestureDelegate = self
        
        self.view.addSubview(pagingView)
        pagingView.mainTableView.backgroundColor = RGB(0xff141516)
        pagingView.frame = self.view.bounds
        
        segmentedView.listContainer = pagingView.listContainerView
        
        //扣边返回处理，下面的程式码要加上
        pagingView.listContainerView.scrollView.panGestureRecognizer.require(toFail: self.navigationController!.interactivePopGestureRecognizer!)
        pagingView.mainTableView.panGestureRecognizer.require(toFail: self.navigationController!.interactivePopGestureRecognizer!)
    }
    
    //MARK:-头部view
    lazy var headView : UIView = {
        let hview = UIView(frame: CGRect(x: 0, y: 0, width: Int(UIScreen.main.bounds.size.width), height: headHeight))
        hview.addSubview(self.topback)
        self.topback.frame = CGRect(x: 12, y: self.topSafeMargin + 6, width: 30, height: 30)
        hview.addSubview(infoView)
        infoView.frame = CGRect(x: 0, y: naviHeight, width: UIScreen.main.bounds.size.width, height: 349 - self.naviHeight)
        
        //渐变色
        object_setClass(hview.layer, CAGradientLayer.self)
        let i = hview.layer as! CAGradientLayer
        i.colors = [RGB(0xff1D2050).cgColor,RGB(0xff141516).cgColor,RGB(0xff141535).cgColor]
        i.startPoint = CGPoint(x: 0, y: 0)
        i.endPoint = CGPoint(x: 0, y: 1)
        return hview
    }()
    
    //MARK:-信息view
    lazy var infoView:OtherHead = {
        let view =  Bundle.main.loadNibNamed("OtherHead", owner: nil, options: nil)?.first as! OtherHead
        view.delegate = self
        view.isUserInteractionEnabled = true
        return view
    }()
    
    //MARK:-导航栏view
    lazy var naviView:UIView = {
        let naviFakeView = UIView()
        naviFakeView.alpha = 0
        naviFakeView.backgroundColor = RGB(0xff141516)
        naviFakeView.frame = CGRect(x: 0, y: 0, width: self.view.bounds.size.width, height: naviHeight)
        
        naviFakeView.addSubview(self.back)
        self.back.frame = CGRect(x: 5, y: self.topSafeMargin, width:40, height: 40)
        
        naviFakeView.addSubview(self.logo)
        self.logo.frame = CGRect(x: self.back.right, y: self.topSafeMargin + 10, width:20, height: 20)
        
        naviFakeView.addSubview(self.nickname)
        self.nickname.snp.makeConstraints { (make) in
            make.centerY.equalTo(logo)
            make.left.equalTo(logo.snp.right).offset(6)
            make.right.equalToSuperview().inset(12)
        }
        
        return naviFakeView
    }()
    
    //返回按钮
    lazy var back:UIButton = {
        let b = UIButton()
        b.setImage(UIImage(named:"navigation_back"), for: UIControl.State.normal)
        b.addTarget(self, action: #selector(self.backAction), for: UIControl.Event.touchUpInside)
        b.setEnlargeEdge(top: 20, bottom: 20, left: 20, right: 20)
        b.imageView?.snp.makeConstraints({ (make) in
                   make.size.equalTo(30)
        })
        return b
    }()
    
    //返回按钮
    lazy var topback:UIButton = {
        let b = UIButton()
        b.setImage(UIImage(named:"navigation_back"), for: UIControl.State.normal)
        b.addTarget(self, action: #selector(self.backAction), for: UIControl.Event.touchUpInside)
        b.imageView?.snp.makeConstraints({ (make) in
            make.size.equalTo(30)
        })
        return b
    }()
    
    @objc  func backAction() {
        self.navigationController?.popViewController(animated: true)
    }
    
    //MARK:-暱称
    lazy var nickname:UILabel = {
        let name = UILabel()
        name.textColor = UIColor.white
        name.font = UIFont.boldSystemFont(ofSize: 16)
        name.numberOfLines = 1
        return name
    }()
    
    //MARK:-头像
    lazy var logo:UIImageView = {
        let img = UIImageView()
        img.clipsToBounds = true
        img.layer.cornerRadius = 10
        img.image = UserMainPageVC.avatarImg
        return img
    }()
    
    
    func mainTableViewDidScroll(_ scrollView: UIScrollView) {
        let thresholdDistance: CGFloat = 100
        var percent = scrollView.contentOffset.y/thresholdDistance
        percent = max(0, min(1, percent))
        naviView.alpha = percent
    }
}


//_______________________________________________________________________________________________________________
// MARK: - JXPagingViewDelegate
extension UserMainPageVC: JXPagingViewDelegate {
    
    func tableHeaderViewHeight(in pagingView: JXPagingView) -> Int {
        return headHeight
    }
    
    func tableHeaderView(in pagingView: JXPagingView) -> UIView {
        return headView
    }
    
    func heightForPinSectionHeader(in pagingView: JXPagingView) -> Int {
        return headerInSectionHeight
    }
    
    func viewForPinSectionHeader(in pagingView: JXPagingView) -> UIView {
        return segmentedView
    }
    
    func numberOfLists(in pagingView: JXPagingView) -> Int {
        return titles.count
    }
    
    func pagingView(_ pagingView: JXPagingView, initListAtIndex index: Int) -> JXPagingViewListViewDelegate {
        return  self.controllers[index]
    }
}

extension UserMainPageVC: JXSegmentedViewDelegate {
    func segmentedView(_ segmentedView: JXSegmentedView, didSelectedItemAt index: Int) {
        self.navigationController?.interactivePopGestureRecognizer?.isEnabled = true
    }
}

extension UserMainPageVC: JXPagingMainTableViewGestureDelegate {
    func mainTableViewGestureRecognizer(_ gestureRecognizer: UIGestureRecognizer, shouldRecognizeSimultaneouslyWith otherGestureRecognizer: UIGestureRecognizer) -> Bool {
        //禁止segmentedView左右滑动的时候，上下和左右都可以滚动
        if otherGestureRecognizer == segmentedView.collectionView.panGestureRecognizer {
            return false
        }
        return gestureRecognizer.isKind(of: UIPanGestureRecognizer.self) && otherGestureRecognizer.isKind(of: UIPanGestureRecognizer.self)
    }
}

//MARK:-OtherHeadDelegate
extension UserMainPageVC:OtherHeadDelegate {
    
    func atttentionDetail(_ item: UserBase) {
        guard let user = self.user else {
            return
        }
        let VC = FocusFansVC()
        VC.navigationTitle = item.nickName
        VC.currentIndex = 0
        VC.titles = ["關注 \(user.ua)","粉絲 \(user.bu)"]
        VC.userId = item.userId
        self.navigationController?.pushViewController(VC, animated: true)
    }
    
    func fansDetail(_ item: UserBase) {
        guard let user = self.user else {
            return
        }
        let VC = FocusFansVC()
        VC.navigationTitle = item.nickName
        VC.titles = ["關注 \(user.ua)","粉絲 \(user.bu)"]
        VC.userId = item.userId
        VC.currentIndex = 1
        self.navigationController?.pushViewController(VC, animated: true)
    }
}


extension UserMainPageVC: UINavigationControllerDelegate, UIGestureRecognizerDelegate {
    
    func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer, shouldRecognizeSimultaneouslyWith otherGestureRecognizer: UIGestureRecognizer) -> Bool {
        let p = pagingView.listContainerView.scrollView.contentOffset
        if p == .zero {
            return true
        }
        return false
    }
    
    @objc func handlePan(pan: XXPanGestureRecognizer) {
        let p = pan.translation(in: pan.view)
        if pan.state == .began {
            if p.equalTo(.zero) {
                pan.xxState = .possible
            } else {
                pan.xxState = pan.state
            }
        } else if pan.state == .changed {
            if pan.xxState == .possible {
                pan.xxState = .began
            } else {
                pan.xxState = pan.state
            }
        } else if (pan.state == .ended ||
            pan.state == .cancelled ||
            pan.state == .failed) {
            if pan.xxState == .possible {
                pan.xxState = .possible
            } else {
                pan.xxState = pan.state
            }
        }
        handlePan2(pan: pan)
    }
    
    @objc func handlePan2(pan: XXPanGestureRecognizer) {
        let p = pan.translation(in: pan.view)
        let progress: CGFloat = p.x / pan.view!.bounds.width
        if pan.xxState == .began {
            let p = pan.translation(in: pan.view)
            percentTransition = UIPercentDrivenInteractiveTransition()
            if p.x > 0 && fabsf(Float(p.x)) > fabsf(Float(p.y)) {
                pagingView.mainTableView.isScrollEnabled = false
                publishedVC.collectionView.isScrollEnabled = false
                self.navigationController?.popViewController(animated: true)
            }
        } else if pan.xxState == .changed {
            percentTransition?.update(progress)
        } else if pan.xxState == .cancelled || pan.xxState == .ended || pan.xxState == .failed {
            let v = pan.velocity(in: pan.view)
            if progress > 0.5 || v.x > panVelocityX {
                percentTransition?.finish()
            } else {
                percentTransition?.cancel()
            }
            pagingView.mainTableView.isScrollEnabled = true
            publishedVC.collectionView.isScrollEnabled = true
            percentTransition = nil
        }
    }
    
    func navigationController(_ navigationController: UINavigationController, animationControllerFor operation: UINavigationController.Operation, from fromVC: UIViewController, to toVC: UIViewController) -> UIViewControllerAnimatedTransitioning? {
        if operation == .pop {
            return NavPopTransition()
        } else {
            return nil
        }
    }
    
    func navigationController(_ navigationController: UINavigationController, interactionControllerFor animationController: UIViewControllerAnimatedTransitioning) -> UIViewControllerInteractiveTransitioning? {
        return percentTransition
    }
}
