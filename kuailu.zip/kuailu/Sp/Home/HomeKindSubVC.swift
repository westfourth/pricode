//
//  HomeKindSubVC.swift
//  Sp
//
//  Created by mac on 2021/1/12.
//  Copyright © 2021 mac. All rights reserved.
//

import UIKit

class HomeKindSubVC: UIViewController {
    
    private static let itemInteritemSpacing: CGFloat = 8
    
    private static let itemLineSpacing: CGFloat = 10
    
    private static let itemEdgeInsetMargin: CGFloat = 12
    
    private lazy var collectionView: UICollectionView = {
        let layout = UICollectionViewFlowLayout()
        layout.itemSize = CGSize(width: SmallVideoRecommendVerticalFourGridCell.itemWidth, height: SmallVideoRecommendVerticalFourGridCell.itemHeight)
        layout.minimumInteritemSpacing = SmallVideoRecommendVerticalFourGridItemCell.itemInteritemSpacing
        layout.minimumLineSpacing = SmallVideoRecommendVerticalFourGridItemCell.itemLineSpacing
        layout.sectionInset = UIEdgeInsets(top: 0, left: SmallVideoRecommendVerticalFourGridItemCell.itemEdgeInsetMargin, bottom: 0, right: SmallVideoRecommendVerticalFourGridItemCell.itemEdgeInsetMargin)
        let cv = UICollectionView(frame: .zero, collectionViewLayout: layout)
        cv.register(SmallVideoRecommendVerticalFourGridCell.self, forCellWithReuseIdentifier: "SmallVideoRecommendVerticalFourGridCell")
        cv.contentInset = UIEdgeInsets(top: 0, left: 0, bottom: 10, right: 0)
        cv.showsHorizontalScrollIndicator = false
        cv.bouncesZoom = false
        cv.backgroundColor = .none
        cv.contentInsetAdjustmentBehavior = .never
        cv.state = .loading
        cv.delegate = self
        cv.dataSource = self
        cv.mj_header = getCommonMJHeader(refreshingTarget: self, headerRefreshCallback: #selector(onRefresh))
        cv.mj_footer = getCommonMJFooter(refreshingTarget: self, footerRefreshCallback: #selector(onLoad))
        return cv
    }()
    
    private var listData: [VideoItem] = []
    
    private var isInitState: Bool = true
    
    var classifyId: Int = 0 {
        didSet {
            guard isInitState else { return }
            isInitState = false
            getList(isRefresh: true)
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = RGB(0x141516)
        if #available(iOS 11.0, *) {
        } else {
            automaticallyAdjustsScrollViewInsets = false
        }
        view.addSubview(collectionView)
        collectionView.snp.makeConstraints { (make) in
            make.top.equalToSuperview().inset(kTop + 10)
            make.left.right.equalToSuperview()
            make.bottom.equalToSuperview().inset(kBottom)
        }
    }
    
    private func getList(isRefresh: Bool) {
        collectionView.state = listData.isEmpty ? .loading : .normal
        let req = SmallVideoCategoryOtherSubListReq()
        req.classifyId = classifyId
        req.lastId = isRefresh ? 0 : (listData.last?.videoId ?? 0)
        if isRefresh {
            collectionView.mj_footer?.resetNoMoreData()
        }
        let collectionView = self.collectionView
        Session.request(req) { [weak self] (error, resp) in
            isRefresh ? collectionView.mj_header?.endRefreshing() : collectionView.mj_footer?.endRefreshing()
            guard let `self` = self else { return }
            guard error == nil, let resData = resp as? [VideoItem] else {
                self.handleListException(isRefresh: isRefresh)
                return
            }
            self.listData = isRefresh ? resData : self.listData + resData
            let isEmpty = self.listData.isEmpty
            collectionView.state = isEmpty ? .empty : .normal
            collectionView.mj_footer?.isHidden = isEmpty
            collectionView.reloadData()
            if resData.count < req.pageSize {
                DispatchQueue.main.async {
                    collectionView.mj_footer?.endRefreshingWithNoMoreData()
                }
            }
        }
    }
    
    private func handleListException(isRefresh: Bool) {
        if isRefresh {
            listData = []
            collectionView.reloadData()
            collectionView.state = .failed
            collectionView.mj_footer?.isHidden = true
        } else {
            collectionView.state = .normal
            collectionView.mj_footer?.endRefreshingWithNoMoreData()
            collectionView.mj_footer?.isHidden = false
        }
    }
    
    @objc private func onLoad() {
        getList(isRefresh: false)
    }
    
    @objc private func onRefresh() {
        getList(isRefresh: true)
    }
    
}

extension HomeKindSubVC: UICollectionViewDataSource, UICollectionViewDelegate {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return listData.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "SmallVideoRecommendVerticalFourGridCell", for: indexPath) as! SmallVideoRecommendVerticalFourGridCell
        cell.dataModel = listData[indexPath.row]
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        SearchResultVC.navigationToVideoPlayListVC(indexPath: indexPath, VideoList: listData)
    }
    
}
