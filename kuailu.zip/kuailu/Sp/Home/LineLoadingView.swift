//
//  LineLoadingView.swift
//  Sp
//
//  Created by mac on 2020/3/27.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class LineLoadingView: UIView {
    
    override init(frame: CGRect) {
        super.init(frame: frame)
//        object_setClass(layer, CAGradientLayer.self)
//        let glayer = layer as! CAGradientLayer
//        glayer.colors = [UIColor.red.cgColor,UIColor.blue.cgColor,UIColor.orange.cgColor]
//        glayer.startPoint = CGPoint(x: 0, y: 0)
//        glayer.endPoint = CGPoint(x: 1, y: 1)
        backgroundColor = UIColor.white.withAlphaComponent(0.7)
        self.isHidden = true
    }
    
     func startAnimation() {
        self.isHidden = false
        let animationG = CAAnimationGroup()
        animationG.duration = 0.5
        animationG.beginTime = CACurrentMediaTime()
        animationG.repeatCount = MAXFLOAT
        animationG.timingFunction = CAMediaTimingFunction(name: CAMediaTimingFunctionName.easeInEaseOut)
        
        // x轴缩放动画（transform.scale是以view的中心点为中心开始缩放的）
        let scaleAnimation = CABasicAnimation()
        scaleAnimation.keyPath = "transform.scale.x"
        scaleAnimation.fromValue = 1.0
        scaleAnimation.toValue = 1.0 * UIScreen.main.bounds.size.width
        
        // 透明度渐变动画
        let alphaAnimation = CABasicAnimation()
        alphaAnimation.keyPath = "opacity"
        alphaAnimation.fromValue = 1.0
        alphaAnimation.toValue = 0.5
        
        
//        let backAnimation = CABasicAnimation()
//        backAnimation.keyPath = "backgroundColor"
//        backAnimation.fromValue = UIColor.randomColor().cgColor
//        backAnimation.toValue = UIColor.randomColor().cgColor
        
        animationG.animations = [scaleAnimation, alphaAnimation]
        
        self.layer.add(animationG, forKey: nil)
    }
    
     func stopAnimation() {
        self.layer.removeAllAnimations()
        self.isHidden = true
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

public extension UIColor {
    static func randomColor()->UIColor {
        let r = CGFloat(arc4random()%256)/255.0
        let g = CGFloat(arc4random()%256)/255.0
        let b = CGFloat(arc4random()%256)/255.0
        return UIColor(red: r, green: g, blue: b, alpha: 1.0)
    }
}

