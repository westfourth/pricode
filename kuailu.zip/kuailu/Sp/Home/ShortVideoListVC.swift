//
//  ShortVideoListVC.swift
//  Sp
//
//  Created by mac on 2020/3/30.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit
import AVFoundation
import M3U8

public let shortVideoClearModeDidChange = NSNotification.Name("shortVideoClearModeDidChange")

class ShortVideoListVC: UIViewController, UICollectionViewDataSource, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout, ShortVideoCellDelegate {
    //  只有一个播放器（不是每个cell都有自己的播放器）
    var player: AVPlayer = AVPlayer(playerItem: nil)
    //  观影进度
    var periodicTimeObserver: Any?
    
    //  当前播放的indexPath
    public var currentPlayingIndexPath: IndexPath = IndexPath(item: 0, section: 0)
    //  数据源
    var models = [ShortVideoModel]()
    //  是否在请求数据
    var isRequesting = false
    
    //  防止第一次左滑时，两个播放器同时播放
    var viewDidAppear = false
    
    /// 是否来自动态
    var fromDynamic:Bool = false
    
    /// 是否是清屏模式
    var isClear:Bool = false {
        didSet {
            self.bottomCommentView.isHidden =  isClear
            self.clearTopView.isHidden = !isClear
            self.models =  models.map { (model) -> ShortVideoModel in
                model.isClearMode = isClear
                return model
            }
            collectionView.reloadData()
        }
    }
    
    /// 用于次级页面（非推荐、关注），videoItems != nil时，表示次级页面
    ///
    /// #设置videoItems之前，请先设置currentPlayingIndexPath
    public var videoItems: [VideoItem]? {
        didSet {
            guard let videoItems = videoItems else {
                return
            }
            loadData(with: videoItems, true)
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.addSubview(collectionView)
        collectionView.frame = view.bounds;
//        view.addSubview(self.clearTopView)
//        let v:CGFloat = (UIApplication.shared.windows.first?.safeAreaInsets.top ?? 0 ) <= 20 ? 20 :44

//        clearTopView.snp.makeConstraints { (make) in
//            make.left.right.equalToSuperview()
//            make.top.equalTo(v + 5)
//            make.height.equalTo(30)
//        }
        
        navigationController?.interactivePopGestureRecognizer?.delegate = self
        
        //  首页加载数据
        if videoItems == nil {
            collectionView.state = .loading
            collectionView.mj_header = getCommonMJHeader(refreshingTarget: self, headerRefreshCallback: #selector(refreshData))
            collectionView.loadMoreBlock = { [weak self] in
                self?.loadData()
            }
            refreshData()
        } else {
            if !fromDynamic {
                addBottomView()
            }
        }
        
        isClear = false
        
        //  监听播放结束
        NotificationCenter.default.addObserver(self, selector: #selector(playerItemDidPlayToEndTime(noti:)), name: .AVPlayerItemDidPlayToEndTime, object: nil)
        //  监听播放器状态
        player.addObserver(self, forKeyPath: #keyPath(AVPlayer.timeControlStatus), options: .new, context: nil)
        //  监听播放进度
        periodicTimeObserver = player.addPeriodicTimeObserver(forInterval: CMTimeMake(value: 1, timescale: 2), queue: DispatchQueue.main, using: {[weak self] (currentTime) in
            self?.periodicObserveCurrentTime(currentTime: currentTime)
        });
    }
    
    deinit {
        player.removeObserver(self, forKeyPath: #keyPath(AVPlayer.timeControlStatus))
        player.removeTimeObserver(periodicTimeObserver!)
        NotificationCenter.default.removeObserver(self)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.navigationBar.setBackgroundImage(UIImage(), for: UIBarMetrics.default)
        navigationController?.navigationBar.shadowImage = UIImage()
        navigationController?.navigationBar.isTranslucent = true
        if isClear {
            (UIApplication.shared.keyWindow!.rootViewController as! TabBarController).tabBar.isHidden = true
        }
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        player.play()
        viewDidAppear = true
        //
        if self.title == "關注" {
            let homeVC = self.parent as! HomeVC
            homeVC.segment.focusValue = 0
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        player.pause()
        /// 上报观影记录
        if !self.models.isEmpty {
            let model = models[self.currentPlayingIndexPath.item]
            let value = CMTimeGetSeconds(player.currentTime())     
            if !value.isNaN && !model.playEnded {
                let seconds = Int(CMTimeGetSeconds(player.currentTime()))
                model.uploadWatchRecord(seconds)
            }
        }
    }
    
    //_______________________________________________________________________________________________________________
    // MARK: -  监听器
    
    override func observeValue(forKeyPath keyPath: String?, of object: Any?, change: [NSKeyValueChangeKey : Any]?, context: UnsafeMutableRawPointer?) {
        if object is AVPlayer {
            //  监听播放器状态
            if keyPath == #keyPath(AVPlayer.timeControlStatus) {
                let timeControlStatus = (object as! AVPlayer).timeControlStatus
                let cell = collectionView.cellForItem(at: currentPlayingIndexPath) as? ShortVideoCell
                cell?.timeControlStatus = timeControlStatus
            }
        }
    }
    
    
    //  监听播放进度
    func periodicObserveCurrentTime(currentTime: CMTime) {
        let playerItem = player.currentItem
        ShortVideoCounter.share.playerItemDidChange(playerItem: playerItem)
        let cell = collectionView.cellForItem(at: currentPlayingIndexPath) as? ShortVideoCell
        if cell != nil && playerItem != nil {
            //  更新播放进度
            cell!.updateProgress(currentTime: playerItem!.currentTime(), duration: playerItem!.duration)
            //  appstore审核没通过，权限放开
            if !Defaults.didPassReview {
                return
            }
            //  异常判断
            guard let model = currentPlayingShortVideoModel() else {
                return
            }
            //  可以观看
            if model.responseWatchType == .canWatch ||
                model.responseWatchType == .none {
                return
            }
            
            //  非会员没有观看次数，直接暂停
            if let userInfo = NetDefaults.userInfo {
                if userInfo.freeWatches - userInfo.watched == 0 {
                    //  暂停
                    player.pause()
                    //  显示权限UI
                    playPredictionUI(shortVidelModel: model)
                    return;
                }
            }

            //  允许他看前面5秒
            if Int(CMTimeGetSeconds(currentTime)) >= 5 {
                //  暂停
                player.pause()
                //  显示权限UI
                playPredictionUI(shortVidelModel: model)
            }
        }
    }
    
    //  监听播放结束
    @objc func playerItemDidPlayToEndTime(noti: Notification) {
        let item = noti.object as! AVPlayerItem
        //  所有的监听者都会收到播放完成通知，因此需要过滤
        guard item == player.currentItem else {
            return
        }
        item.cancelPendingSeeks()
        item.seek(to: .zero) {[weak self] (finished) in
            self?.player.play()
        }
        /// 上报观影记录
        guard self.models.count > 0 else {
            return
        }
        let model = self.models[self.currentPlayingIndexPath.item]
        model.playEnded = true
        model.uploadWatchRecord(Int(CMTimeGetSeconds(item.duration)))
    }
    
    //_______________________________________________________________________________________________________________
    // MARK: -  刷新、加载更多
    
    @objc func refreshData() {
        loadData(true)
    }
    
    //  加载网络数据
    @objc func loadData(_ isRefresh: Bool = false) {
        ///回掉处理 保持精简
        let callback:(Error?, Any?) -> Void = {[weak self] (error, resp) in
            guard self != nil else {
                return
            }
            self?.isRequesting = false
            //  此操作是刷新数据，非向下加载更多
            if isRefresh {
                self?.player.replaceCurrentItem(with: nil)
                self?.collectionView.mj_header?.endRefreshing()
                self?.models.removeAll()
                self?.collectionView.reloadData()
            }
            //  接口报错
            if error != nil {
                if isRefresh {
                    self?.collectionView.state = .failed
                }
                return
            }
            //  数据为空
            guard resp is [VideoItem] else {
                if isRefresh {
                    self?.collectionView.state = .empty
                }
                return
            }
            self?.collectionView.state = .normal
            //  数据不为空
            let videoItems = resp as! [VideoItem]
            //  继续处理
            self?.loadData(with: videoItems, isRefresh)
        }
        
        //
        if isRequesting {
            return
        }
        isRequesting = true
        if self.title == "關注"  {
            if isRefresh == false, let last = models.last {
                Defaults.focusLastVideoID = last.videoItem!.videoId
            }
            let req = FocusVideoListReq()
            req.lastId = isRefresh ? 0 : Defaults.focusLastVideoID
            Session.request(req, callback: callback)
        } else {
            let req = RecommendVideoReq()
            Session.request(req, callback: callback)
        }
    }
    
    //  从 [VideoItem] 中生成 [ShortVideoModel]
    func loadData(with videoItems: [VideoItem], _ isRefresh: Bool = false) {
        var items:[ShortVideoModel] = [ShortVideoModel]()
        for i in 0..<videoItems.count {
            let videoItem = videoItems[i];
            
            let model = ShortVideoModel()
            if !HotSpot.share.items.isEmpty {
                model.hots = HotSpot.share.items
            }
            model.isdynamic = fromDynamic
            model.videoItem = videoItem
            model.isClearMode = (UIApplication.shared.keyWindow?.rootViewController as! TabBarController).tabBar.isHidden
            if InnerIntercept.currentNaviController().topViewController is Home2VC && self.videoItems == nil  {
                model.hasActivity = Defaults.hasDiscountActivity
            }
            let videoUrl = videoItem.videoUrl
            if let videoURL = videoUrl {
                let localURL = M3U8LocalForRemote(videoURL, Int(M3U8_SERVER_PORT))
                model.playerItem = AVPlayerItem(url: localURL!)
            }
            
            items.append(model)
            //  第一个播放，预缓存后面的
            if i != currentPlayingIndexPath.item, let videoURL = videoUrl {
                M3U8PreCache.share().preCache(videoURL)
            }
        }
        if self.videoItems != nil {     //  videoItems != nil時，表示次級頁面
            self.models.append(contentsOf: items)
        } else {                        //  推薦、關注加入廣告
            insertAdsPriority(items: items)
        }
        guard self.models.isEmpty == false else {
            self.collectionView.state = .empty
            return
        }
        if items.count > 0 {
            self.collectionView.reloadData()
        }
        //  播放指定
        if isRefresh {
            self.startPlayItem(indexPath: currentPlayingIndexPath)
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.05) {
                self.collectionView.scrollToItem(at: self.currentPlayingIndexPath, at: .centeredVertically, animated: false)
            }
        }
    }
    
    /// 排序插入视频广告
    func insertAds(items: [ShortVideoModel]) {
        for item in items {
            self.models.append(item)
            if AdManager.shared.videoAds.count == 0 {
                continue
            }
            //  插入广告
            if (self.models.count + 1) % (AdManager.shared.videoInsertNum + 1) == 0 {
                let idx = (self.models.count + 1) / (AdManager.shared.videoInsertNum + 1) - 1
                let idx2 = idx % AdManager.shared.videoAds.count
                let adModel = AdManager.shared.videoAds[idx2]
                //
                let videoModel = ShortVideoModel()
                videoModel.videoAd = adModel
                
                //  视频地址
                if let videoUrl = adModel.adPlay {
                    let localURL = M3U8LocalForRemote(videoUrl, Int(M3U8_SERVER_PORT))!
                    videoModel.playerItem = AVPlayerItem(url: localURL)
                    //  预缓存
                    M3U8PreCache.share().preCache(videoUrl)
                    
                    self.models.append(videoModel)
                }
            }
        }
    }
    
    /// 权重插入视频广告
    func insertAdsPriority(items: [ShortVideoModel]) {
        for item in items {
            self.models.append(item)
            if AdManager.shared.videoAds.count == 0 {
                continue
            }
            //  插入广告
            if (self.models.count + 1) % (AdManager.shared.videoInsertNum + 1) == 0 {
                let adModel = AdManager.shared.randomVideoAd()!
        
                //
                let videoModel = ShortVideoModel()
                videoModel.videoAd = adModel
                
                //  视频地址
                if let videoUrl = adModel.adPlay {
                    let localURL = M3U8LocalForRemote(videoUrl, Int(M3U8_SERVER_PORT))!
                    videoModel.playerItem = AVPlayerItem(url: localURL)
                    //  预缓存
                    M3U8PreCache.share().preCache(videoUrl)
                    
                    self.models.append(videoModel)
                }
            }
        }
    }
    
    lazy var collectionView: UICollectionView = {
        let layout = UICollectionViewFlowLayout()
        layout.minimumLineSpacing = 0
        layout.minimumInteritemSpacing = 0
        layout.itemSize = ShortVideoCell.itemSize()
        
        let collectionView = UICollectionView(frame: .zero, collectionViewLayout: layout)
        collectionView.register(ShortVideoCell.self, forCellWithReuseIdentifier: "CELL")
        collectionView.dataSource = self
        collectionView.delegate = self
        
        collectionView.backgroundColor = RGB(0xff141516)
        collectionView.isPagingEnabled = true
        collectionView.showsVerticalScrollIndicator = false
        collectionView.scrollsToTop = false
        collectionView.contentInsetAdjustmentBehavior = .never
        collectionView.delaysContentTouches = false
        return collectionView
    }()
    
    
    //MARK: 顶部图
    lazy var clearTopView:ClearModeTopView = {
        let v = Bundle.main.loadNibNamed("ClearModeTopView", owner: nil, options: [:])?.first as! ClearModeTopView
        v.isHidden = true
        v.delegate = self
        return v
    }()

    
//    //MARK: 全屏幕
//    lazy var fullView:ShortVideoFullPlayView = {
//        let v = Bundle.main.loadNibNamed("ShortVideoFullPlayView", owner: nil, options: [:])?.first as! ShortVideoFullPlayView
//        v.delegate = self
//        v.notimesView.delegate = self
//        v.needPayView.delegte = self
//        return v
//    }()
    
    //MARK: 剧集view
    lazy var serialView:VideoSerialView = {
        let v = Bundle.main.loadNibNamed("VideoSerialView", owner: nil, options: [:])?.first as! VideoSerialView
        v.delegate = self
        return v
    }()
    
    lazy var bottomCommentView:UIView = {
       return UIView()
    }()
    
    //MARK:-获取当前的剧集
    func fetchSerailItems(_ model:ShortVideoModel) {
        guard let item = model.videoItem,item.isVideoSerial else {
            self.serialView.isHidden = true
            return
        }
        
        // 是否有剧集
        guard model.serialItems.isEmpty else {
            self.handelCurrentSerial(item, items: model.serialItems)
            return
        }
        
        let req = FetchVideoSerialByIdReq()
        req.videoId = item.videoId
        Session.request(req) { (error, resp) in
            guard error == nil  else{
                self.serialView.isHidden = true
                return
            }
            guard let array = resp as? [VideoItem],!array.isEmpty else {
                self.serialView.isHidden = true
                return
            }
            // model持有剧集
            model.serialItems = array
            self.handelCurrentSerial(item, items: array)
        }
    }
    
    /// 当前选中的剧集
    private func handelCurrentSerial(_ playingItem:VideoItem,items:[VideoItem]) {
        if let index = items.firstIndex(where: {$0.videoId == playingItem.videoId}) {
            self.serialView.currentPlayingIndx = index
        }
        self.serialView.isHidden = false
        self.serialView.items = items
    }
    
    
    //_______________________________________________________________________________________________________________
    // MARK: - 数据源
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return models.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CELL", for: indexPath) as! ShortVideoCell
        //  播放器
        let aPlayer = indexPath == currentPlayingIndexPath ? player : nil
        let playerItem: AVPlayerItem? = aPlayer?.currentItem
        print("====== cellForItemAt indexPath: \(indexPath), player: \(aPlayer), visibleItems: \(collectionView.indexPathsForVisibleItems)")
        
        //  委托
        cell.delegate = self
        cell.cellSubviews?.delegate = self
        cell.cellSubviews?.collection?.delegate = self
        cell.cellSubviews?.hot?.delegate = self
        cell.fullView.delegate = self
        cell.fullView.notimesView.delegate = self
        cell.fullView.needPayView.delegte = self

        //  播放器画面
        (cell.playView.layer as! AVPlayerLayer).player = aPlayer
//        (cell.containerView.layer as! AVPlayerLayer).player = aPlayer
        
        //  播放进度
        if playerItem != nil {
            cell.updateProgress(currentTime: playerItem!.currentTime(), duration: playerItem!.duration)
        } else {
            cell.updateProgress(currentTime: .zero, duration: .zero)
        }
        
        let model = models[indexPath.row];
        cell.model = model
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        //  正常视频
        if models[indexPath.row].isClearMode {
            let cell = collectionView.cellForItem(at: indexPath) as! ShortVideoCell
            if cell.clearMode {
                cell.clearMode = false
            } else {
                if player.timeControlStatus == .paused {
                    self.player.play()
                } else {
                    player.pause()
                }
            }
        } else {
            if player.timeControlStatus == .paused {
                self.player.play()
            } else {
                player.pause()
            }
        }
    }
    
    func scrollViewWillEndDragging(_ scrollView: UIScrollView, withVelocity velocity: CGPoint, targetContentOffset: UnsafeMutablePointer<CGPoint>) {
        puts(#function)
        guard  self.models.count > 0 else {
            return
        }
        let row: Int = Int(round(targetContentOffset.pointee.y / ShortVideoCell.itemSize().height))
        if row != currentPlayingIndexPath.item {
            endPlayItem(indexPath: currentPlayingIndexPath)
        }
    }
    
    /// 不可以通过willDisplayCell、didEndDisplayingCell来计算，在快速滑动时会出问题
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        puts(#function)
        guard  self.models.count > 0 else {
            return
        }
        //  计算当前是第几个
        let row = Int(round(collectionView.contentOffset.y / ShortVideoCell.itemSize().height))
        if row != currentPlayingIndexPath.item {
            let nextPlayIndexPath = IndexPath(item: row, section: 0)
            startPlayItem(indexPath: nextPlayIndexPath)
        }
    }
    
    //_______________________________________________________________________________________________________________
    // MARK: -
    
    //  当前播放视频的ShortVideoModel
    func currentPlayingShortVideoModel() -> ShortVideoModel? {
        let row = currentPlayingIndexPath.item
        if row < self.models.count {
            return self.models[row]
        }
        return nil
    }
    
    //  拖动进度条
    func shortVideoCell(_ shortVideoCell: ShortVideoCell, seekToTime time: CMTime, completion: @escaping () -> Void) {
        player.currentItem?.cancelPendingSeeks()
        player.currentItem?.seek(to: time, completionHandler: { (finished) in
            completion()
        })
    }
    
    //  广告倒计时
    func shortVideoCell(_ shortVideoCell: ShortVideoCell, didCountdown remainTime: Int) {
        if remainTime == 0 {
            //  恢复滑动
            collectionView.isScrollEnabled = true
        }
    }
    
    func startPlayItem(indexPath: IndexPath) {
        print(">>> startPlayItem \(indexPath)")
        guard self.models.count > 0, indexPath.row < self.models.count, indexPath.row >= 0 else {
            return
        }
        let model = models[indexPath.item]
        self.clearTopView.name.text = model.videoItem?.title
        player.replaceCurrentItem(with: model.playerItem)   //  載入視頻
        currentPlayingIndexPath = indexPath
        
        /// 获取当前正在播放的剧集
        if videoItems != nil {
            fetchSerailItems(model)
        }
        
        if model.videoAd != nil {
            collectionView.isScrollEnabled = false
        }
        
        if viewDidAppear, model.lastPlayTime?.isValid == true {
            player.currentItem?.cancelPendingSeeks()
            player.currentItem?.seek(to: model.lastPlayTime!, completionHandler: {[weak self] (finished) in
                self?.player.play()
            })
        } else {
            let delegate = UIApplication.shared.delegate as? AppDelegate
            let tabVC = delegate?.window?.rootViewController as? TabBarController
            let b = tabVC?.currentDisplayShortVideo()
            if b == true {
                player.play()
            } else {
                player.pause()
            }
        }

        collectionView.reloadData()
        
        if let videoItem = model.videoItem {
            Defaults.saveShortWatch(videoItem)
        }
        
        if let videoUrl = model.videoItem?.videoUrl,
            videoUrl.absoluteString.contains("/dynamic?path=") {
            model.responseWatchType = .canWatch
            model.watchType = .free
        } else {
            //  获取播放权限
            model.playPrediction()
        }
        
        //  如果非会员，播放次数-1（广告不计入观看次数）
        if let _ = model.videoItem, let userInfo = NetDefaults.userInfo {
            if userInfo.freeWatches != -1 {    //  -1表示無限觀看次數
                if userInfo.watched < userInfo.freeWatches {
                    userInfo.watched += 1
                    NetDefaults.userInfo = userInfo
                }
            }
        }
        
        //  如果是关注，记录最后一次观看的视频ID
        if self.title == "關注", let videoId = model.videoItem?.videoId {
            Defaults.focusLastVideoID = videoId
        }
    }
    
    func endPlayItem(indexPath: IndexPath) {
        print(">>> endPlayItem \(indexPath)")
        guard self.models.count > 0, indexPath.row < self.models.count, indexPath.row >= 0 else {
            return
        }
        /// 上报观影记录
        let model = models[indexPath.row]
        model.lastPlayTime = player.currentTime()
        let value = CMTimeGetSeconds(player.currentTime())
        if !value.isNaN && !model.playEnded {
            let seconds = Int(value)
            model.uploadWatchRecord(seconds)
        }
        player.replaceCurrentItem(with: nil)
    }
}


//_______________________________________________________________________________________________________________
// MARK: - 其他

extension ShortVideoListVC: UIGestureRecognizerDelegate {
    
    func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer, shouldReceive touch: UITouch) -> Bool {
        if (touch.view?.isKind(of: UISlider.self))! {
            return false
        }
        return true
    }
    
    //  根据播放权限显示UI
    func playPredictionUI(shortVidelModel: ShortVideoModel) {
//        presentedViewController?.dismiss(animated: false, completion: nil)
        
        /*
         当进入分享，退到桌面再返回app时，会触发addPeriodicTimeObserver回调。
         */
        if !self.isViewLoaded || self.view.window == nil {
            return
        }
        switch shortVidelModel.responseWatchType {
        case .error:
            mm_showToast(shortVidelModel.error!.localizedDescription)
        case .noTimes:
            let vc = VideoNeedTimesVC()
            vc.shortVideoModel = shortVidelModel
            present(vc, animated: true, completion: nil)
        case .needPay:
            let vc = VideoNeedPayVC()
            vc.shortVideoModel = shortVidelModel
            vc.delegate = self
            present(vc, animated: true, completion: nil)
        default:
            puts(#function)
        }
    }
    
    //  进入用户信息
    public func gotoUesrMainPage() {
        guard self.models.isEmpty == false else {   //  沒有數據時，防止崩潰
            return
        }
        let model = self.models[self.currentPlayingIndexPath.item]
        guard let videoItem = model.videoItem else {
            return
        }
        let vc = UsersDynamicVC()
        vc.userId = videoItem.userId
        vc.initPageType = .smallVideo
        vc.viewWillDisappearCallback = {
            self.refreshCurrentDisplayingCell()
        }
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    //  刷新当前显示的cell
    @objc func refreshCurrentDisplayingCell() {
        guard let currentCell = self.collectionView.cellForItem(at: self.currentPlayingIndexPath) as? ShortVideoCell, let subViews = currentCell.cellSubviews else {
            return
        }
        guard let model = subViews.model else {
            return
        }
        subViews.model = model
    }
    
    //  非首页时，在底部添加按钮
    func addBottomView() {
        guard let tabBar = (UIApplication.shared.delegate as! AppDelegate).tabbar else {
            return
        }
        //  bottomCommentView
        view.addSubview(bottomCommentView)
        bottomCommentView.frame = CGRect(x: 0, y: UIScreen.main.bounds.height - tabBar.height,
                              width: tabBar.width, height: tabBar.height)
        bottomCommentView.backgroundColor = RGB(0x07072F)
        
        //  button
        let button = UIButton()
        bottomCommentView.addSubview(button)
        button.frame = CGRect(x: 0, y: 0, width: tabBar.width, height: 49)
        button.setTitle("觀而不論非英雄，留下你的評論吧～", for: .normal)
        button.setTitleColor(.white, for: .normal)
        button.titleLabel?.font = UIFont.pingFangRegular(16)
        button.contentHorizontalAlignment = .left
        button.titleEdgeInsets = UIEdgeInsets(top: 0, left: 12, bottom: 0, right: 0)
        button.addTarget(self, action: #selector(clickBottomButton(_:)), for: .touchUpInside)
        
        /// 剧集view
        bottomCommentView.addSubview(serialView)
        serialView.frame = button.bounds
        serialView.isHidden = true
    }
    
    //  点击底部button
    @objc func clickBottomButton(_ button: UIButton) {
        guard let currentCell = self.collectionView.cellForItem(at: self.currentPlayingIndexPath) as? ShortVideoCell, let subViews = currentCell.cellSubviews else {
            return
        }
        self.shortVideoCellSubviews(subViews, didClickComment: subViews.commentButton)
    }
}

//_______________________________________________________________________________________________________________
// MARK: -  ShortVideoCellSubviewsDelegate

extension ShortVideoListVC: ShortVideoCellSubviewsDelegate {
    
    // 全屏
    func shortVideoCellSubviews(_ subViews: ShortVideoCellSubviews, didClickFull button: UIButton) {
        if let user = NetDefaults.userInfo {
            if user.level < 6 {
                let v6 = V6PermissionVC()
                v6.vipAction = {
                    let vc = Vip2VC()
                    vc.hidesBottomBarWhenPushed = true
                    self.navigationController?.pushViewController(vc, animated: true)
                }
                present(v6, animated: true, completion: nil)
            } else {
                // 全屏播放
                player.pause()
                if self.player.currentItem != nil {
                    self.models[self.currentPlayingIndexPath.row].lastPlayTime = player.currentItem!.currentTime()
                }
                let cell = collectionView.cellForItem(at: currentPlayingIndexPath) as! ShortVideoCell
                cell.fullView.model = self.models[self.currentPlayingIndexPath.row]
                player.replaceCurrentItem(with: nil)
                let window = UIApplication.shared.keyWindow!
                let containerView = cell.containerView
                let frame = containerView.superview!.convert(containerView.frame, to: window)
                window.addSubview(containerView)
                containerView.frame = frame
                //  旋转动画
                UIView.animate(withDuration: 0.3, animations: {
                    containerView.transform = CGAffineTransform.init(rotationAngle: CGFloat(Double.pi / 2))
                    containerView.frame = window.bounds
                    cell.fullView.isHidden = false
                }) { (finished) in
                    for v in containerView.subviews {
                        if v is ShortVideoFullPlayView {
                            (v as! ShortVideoFullPlayView).updatelayout()
                        }
                    }
                    let oriectationVC = StatusBarOrientationController()
                    oriectationVC.supportedOrientations = .landscapeRight
                    let appDelegate = UIApplication.shared.delegate as! AppDelegate
                    appDelegate.window2?.rootViewController = oriectationVC
                }
            }
        }
    }
     
    // 清屏
    func shortVideoCellSubviews(_ subViews: ShortVideoCellSubviews, didClickClear button: UIButton) {
        isClear = button.isSelected
        if InnerIntercept.currentNaviController().topViewController is Home2VC {
            NotificationCenter.default.post(name: shortVideoClearModeDidChange, object: isClear)
        }
    }
    
    //  分享
    func shortVideoCellSubviews(_ subViews: ShortVideoCellSubviews, didClickShare button: UIButton) {
        guard let model = subViews.model, let videoItem = model.videoItem else {
            return
        }
        
        let vc = ShareActionVC()
        vc.videoItem = videoItem
        vc.modalPresentationStyle = .overFullScreen
        present(vc, animated: true, completion: nil)
    }
    
    //  评论
    func shortVideoCellSubviews(_ subViews: ShortVideoCellSubviews, didClickComment button: UIButton) {
        guard let model = subViews.model, let videoItem = model.videoItem else {
            return
        }
        let commentVC = CommentVC()
        commentVC.video = videoItem
        commentVC.viewWillDisappearCallback = {
            subViews.model = model
        }
        present(commentVC, animated: true, completion: nil)
    }
    
    //  点赞
    func shortVideoCellSubviews(_ subViews: ShortVideoCellSubviews, didClickLike button: UIButton) {
        guard let model = subViews.model, let videoItem = model.videoItem else {
            return
        }
        //  刷新显示
        videoItem.isLike = !videoItem.isLike
        videoItem.fakeLikes += videoItem.isLike ? 1 : -1
        subViews.model = model
        //  请求网络
        if videoItem.isLike {       //  點贊
            let req = LikeVideoReq()
            req.videoId = videoItem.videoId
            Session.request(req) { (error, resp) in }
        } else {                    //  取消點贊
            let req = CancelLikeVideoReq()
            req.videoId = videoItem.videoId
            Session.request(req) { (error, resp) in }
        }
    }
    
    //  头像
    func shortVideoCellSubviews(_ subViews: ShortVideoCellSubviews, didClickAvatar button: UIButton) {
        //  如果是广告
        if let videoAd = subViews.model?.videoAd {
            jumpToDownload(videoAd: videoAd)
            return
        }
        guard let model = subViews.model, let videoItem = model.videoItem else {
            return
        }
        let vc = UsersDynamicVC()
        vc.userId = videoItem.userId
        vc.initPageType = .smallVideo
        vc.viewWillDisappearCallback = {
            self.refreshCurrentDisplayingCell()
        }
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    //  添加关注
    func shortVideoCellSubviews(_ subViews: ShortVideoCellSubviews, didClickAdd button: UIButton) {
        guard let model = subViews.model, let videoItem = model.videoItem else {
            return
        }
        button.setImage(UIImage(named:"ic_follew_1"), for: .normal)
        videoItem.isAttention = true
        let req =  FocusUserReq()
        req.beenUserId = videoItem.userId
        Session.request(req) { (error, resp) in
            guard error == nil else {
                return
            }
            button.isHidden = true
            mm_showToast("關注成功!", type: .succeed)
        }
    }
    
    //  下载
    func shortVideoCellSubviews(_ subViews: ShortVideoCellSubviews, didClickDownload button: UIButton) {
        //  如果是广告
        if let videoAd = subViews.model?.videoAd {
            jumpToDownload(videoAd: videoAd)
        }
    }
    
    func jumpToDownload(videoAd: AdvertiseResp) {
        guard let adJump = videoAd.adJump else {
            return
        }
        if adJump.scheme == "http" || adJump.scheme == "https" {
            if videoAd.jumpType == .inner {
                let webVC = WebVC()
                webVC.webviewUrl = adJump
                self.navigationController?.pushViewController(webVC, animated: true)
            } else {
                InnerIntercept.open(adJump)
            }
        } else {
            InnerIntercept.open(adJump)
        }
    }
}


extension ShortVideoListVC: ShortVideoCellCollectionDelegate, HotSpotViewDelegate, ShortVideoCounterViewDelegate {
    //  点击视频计时器
    func didClick(counterView: ShortVideoCounterView) {
//        let vc = TaskVC()
//        vc.hidesBottomBarWhenPushed = true
//        navigationController?.pushViewController(vc, animated: true)
    }
    
    //  点击标签
    func shortVideoCellCollection(_ collection: ShortVideoCellCollection, didSelect cell: ShortVideoCellCollectionCell) {
        guard let tagTitle = cell.text,let name = tagTitle.components(separatedBy: "#").last  else {
            return
        }
        ClassyVideoSetVC.isFromClassy = false
        let classyVideoSetVC = ClassyVideoSetVC()
        classyVideoSetVC.tagTitle = name
        navigationController?.show(classyVideoSetVC, sender: nil)
    }
    
    //  热点
    func hotView(didTap hotView: HotSpotView) {
        let hotVC = HotspotVC()
        hotVC.hidesBottomBarWhenPushed = true
        navigationController?.pushViewController(hotVC, animated: true)
    }
}

//MARK:-剧集点击
extension ShortVideoListVC:VideoSerialViewDelegate {
    func videoSerial(_ view: VideoSerialView, item: VideoItem) {
        ///播放第n个剧集
        let localUrl = M3U8LocalForRemote(item.videoUrl, Int(M3U8_SERVER_PORT))!
        let item = AVPlayerItem(url: localUrl)
        player.replaceCurrentItem(with: item)
        player.play()
    }
}

extension ShortVideoListVC:ClearModeTopViewDelegate {
    func cancel() {
        self.isClear = false
    }
}


extension ShortVideoListVC:ShortVideoFullPlayViewDelegate {
    
    func dismissAction(model: ShortVideoModel) {
        self.models[self.currentPlayingIndexPath.row] = model
        exitFull {}
    }
    
    func exitFull(completion: @escaping () -> Void) {
        let cell = collectionView.cellForItem(at: currentPlayingIndexPath) as! ShortVideoCell
        self.startPlayItem(indexPath: self.currentPlayingIndexPath)
        UIView.animate(withDuration: 0.25, animations: {
            let containerView = cell.containerView
            cell.fullView.playView.image = nil
            containerView.transform = CGAffineTransform.identity
            containerView.frame = UIApplication.shared.keyWindow!.bounds
            cell.fullView.isHidden = true
        }) { (finished) in
            if finished {
                cell.addSubview(cell.containerView)
                cell.containerView.frame = UIApplication.shared.keyWindow!.bounds
                cell.setNeedsLayout()
                
                let oriectationVC = StatusBarOrientationController()
                oriectationVC.supportedOrientations = .portrait
                let appDelegate = UIApplication.shared.delegate as! AppDelegate
                appDelegate.window2?.rootViewController = oriectationVC
                completion()
            }
        }
    }
}

extension ShortVideoListVC:FullNoTimeAlertDelegate {
    
    func vip() {
        exitFull {
            let vc = Vip2VC()
            vc.hidesBottomBarWhenPushed = true
            self.navigationController?.pushViewController(vc, animated: true)
        }
    }
    
    func share() {
        exitFull {
            let vc = ShareActionVC()
            vc.videoItem = self.models[self.currentPlayingIndexPath.row].videoItem!
            vc.modalPresentationStyle = .overFullScreen
            self.present(vc, animated: true, completion: nil)
        }
    }
    
}


extension ShortVideoListVC:FullNeedPayAlertDelegate {
    
    func charge() {
        exitFull {
            let vc = Vip2VC()
            vc.uiType = .coin
            vc.hidesBottomBarWhenPushed = true
            self.navigationController?.pushViewController(vc, animated: true)
        }
    }
}
