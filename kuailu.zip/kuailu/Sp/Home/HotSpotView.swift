//
//  HotSpotView.swift
//  Sp
//
//  Created by mac on 2020/4/4.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

protocol HotSpotViewDelegate: NSObjectProtocol {
    //  点击
    func hotView(didTap  hotView: HotSpotView)
}

class HotSpotView: NSObject {
     public weak var superView: UIView?
    
     weak var delegate: HotSpotViewDelegate?
    
      public init(superView: UIView) {
        self.superView = superView
        super.init()
        self.superView?.addSubview(self.hotView)
    }
    
//    var item:HotDailyItem? {
//        didSet {
//            guard let item = item else {
//                return
//            }
//            name.text = item.hotName
//        }
//    }
    
    var items:[HotDailyItem]? {
        didSet {
            guard let _ = items else {
                return
            }
            self.marqueeView.reload()
        }
    }
    
    public func superViewDidLayout(bounds: CGRect, minY: CGFloat) {
          let height: CGFloat = 30
          //  边距
          let padding = UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 0)
        
//         var size = (name.text! as NSString).boundingRect(with: CGSize(width: titleLabelWidth, height: 0), options: .usesLineFragmentOrigin, attributes: [.font: name.font!], context: nil).size
        
          hotView.frame = CGRect(x: padding.left,
                                 y: minY - height - padding.bottom,
                                 width: bounds.width, height: height)
      }
    
    lazy var hotView:UIView = {
        let v = UIView()
        v.backgroundColor = UIColor.black.withAlphaComponent(0.5)
        v.clipsToBounds = true
        v.addSubview(icon)
        icon.frame = CGRect(x: 10, y: 5, width: 18, height: 20)
        
//        v.addSubview(name)
//        name.frame = CGRect(x: icon.right +  3, y: 4, width: 268 - 10 - 18 - 24, height: 22)
        
        v.addSubview(marqueeView)
//        marqueeView.frame = CGRect(x: icon.right +  3, y: 4, width: 268 - 10 - 18 - 24, height: 22)
        
        v.addSubview(arrow)
        arrow.frame = CGRect(x: UIScreen.main.bounds.width - 28, y: 9, width: 8, height: 11)
        
        v.isUserInteractionEnabled = true
        let tap = UITapGestureRecognizer(target: self, action:#selector(tapAction))
        v.addGestureRecognizer(tap)
        
        return v
    }()
    
    //MARK:-跑马灯
    lazy var marqueeView:MarqueeView  = {
        let m = MarqueeView(frame: CGRect(x: icon.right +  3, y: 4, width: 268 - 10 - 18 - 24, height: 22))
        m.automaticSlidingInterval = 3
        m.delegate = self
        m.dataSource = self
        return m
    }()
     
    @objc func tapAction() {
        delegate?.hotView(didTap: self)
    }
    
    lazy var icon:UIImageView = {
        let logo = UIImageView()
        logo.image = UIImage(named: "fire")
        return logo
    }()
    
    lazy var name:UILabel = {
    let label = UILabel()
    label.text = "最新女主角閃亮登場，各位狼友快上車"
    label.textColor = RGB(0xffFFDB46)
    label.font = UIFont.pingFangMedium(12)
    return label
    }()
    
    lazy var arrow:UIImageView = {
        let logo = UIImageView()
        logo.contentMode = .scaleAspectFit
        logo.image = UIImage(named: "arrow_gold")
        return logo
    }()
}

//_______________________________________________________________________________________________________________
// MARK: - MarqueeViewDelegate && MarqueeViewDataSource
extension HotSpotView:MarqueeViewDelegate {
    func mqrqueeView(_ marqueeView: MarqueeView, didSelectCellAt index: Int) {
         delegate?.hotView(didTap: self)
    }
}

extension HotSpotView:MarqueeViewDataSource {
    func numberOfItems(_ marqueeView: MarqueeView) -> Int {
        guard let items = self.items else {
            return 0
        }
        return items.count
    }
    
    func marqueeView(_ marqueeView: MarqueeView, cellForItemAt index: Int) -> NSAttributedString {
        guard let items = self.items else {
            return NSAttributedString(string: "")
        }
        let contens = items.map { (item) -> String in
            return item.hotName
        }
        let attr = NSAttributedString.init(string: contens[index], attributes: [NSAttributedString.Key.font : UIFont.pingFangMedium(12),NSAttributedString.Key.foregroundColor:RGB(0xffFFDB46)])
        return attr
    }
}



