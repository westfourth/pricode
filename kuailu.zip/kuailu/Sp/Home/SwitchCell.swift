//
//  SwitchCell.swift
//  CollectionViewHeaderDemo
//
//  Created by mac on 2021/1/11.
//

import UIKit

class SwitchCell: UICollectionViewCell {

    @IBOutlet weak var name: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    func scale() {
        UIView.animate(withDuration: 1.0) {
            self.name.font = UIFont.systemFont(ofSize: 20, weight: .medium)
        }
    }
    
    func normal() {
        UIView.animate(withDuration: 1.0) {
            self.name.font = UIFont.systemFont(ofSize: 16, weight: .regular)
        }
    }

}
