//
//  ClearModeTopView.swift
//  Sp
//
//  Created by mac on 2021/1/12.
//  Copyright © 2021 mac. All rights reserved.
//

import UIKit

@objc protocol ClearModeTopViewDelegate {
    func cancel()
}

class ClearModeTopView: UIView {
    weak var delegate: ClearModeTopViewDelegate?

    @IBOutlet weak var name: UILabel!
    
    
    @IBAction func tapAction(_ sender: Any) {
        delegate?.cancel()
    }
    
}
