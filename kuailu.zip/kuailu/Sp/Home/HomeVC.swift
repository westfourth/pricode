//
//  HomeVC.swift
//  Sp
//
//  Created by mac on 2020/2/17.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

//  绝对值超过这个值时，表示pan是swipe
let panVelocityX: CGFloat = 500

/**
 在iOS12.4上，从屏幕1/4的位置平移，translationInView:得到的point总是zero。
 使用XXPanGestureRecognizer处理这个bug。
 */
class XXPanGestureRecognizer: UIPanGestureRecognizer {
    var xxState: UIGestureRecognizer.State = .possible
}

class HomeVC: UITabBarController {
    var previousSelectedIndex: Int = 0
    var segment: HomeSegment!
    var items = [UIViewController]()
    
    var focusVC = ShortVideoListVC()        //  关注
    var recommandVC = ShortVideoListVC()    //  推荐
    var featureVC = ClassyScrollListRecomItemVC()      //  精选
    
    var percentTransition: UIPercentDrivenInteractiveTransition?
    var tabBarTransition = TabBarTransition()
    
    var activityEntryImgView: UIImageView? {
        didSet {
            activityEntryImgView?.isHidden = segment.selectedSegmentIndex == 2
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let search = UIBarButtonItem(barButtonSystemItem: .search, target: self, action:  #selector(onSearchBarClick))
        navigationItem.rightBarButtonItem = search
        
        let nib = UINib(
            nibName: "HomeSegment", bundle: nil)
        segment = nib.instantiate(withOwner: nil, options: nil).first as! HomeSegment
        segment.delegate = self
        let leftItem = UIBarButtonItem(customView: segment)
        navigationItem.leftBarButtonItem = leftItem
        segment.tapCallback = {[weak self] (idx: Int) in
            self?.selectedIndex = idx
        }
        
        items = [focusVC, recommandVC, featureVC]
        
        //  将推荐设置为显示
        recommandVC.title = "推薦"
        focusVC.title = "關注"
        featureVC.title = "精选"
        self.viewControllers = items
        self.tabBar.isHidden = true
        
        //  默认
        segment.selectedSegmentIndex = 1
        self.selectedViewController = items[1]
        self.previousSelectedIndex = 1
        //
        let pan = XXPanGestureRecognizer(target: self, action: #selector(handlePan(pan:)))
        view.addGestureRecognizer(pan)
        pan.delegate = self
        
        //
        #if DEBUG
        if Defaults.debugJumpVersionUpdate {
            
        } else {
            AlertSequence.share.loadAllData()
        }
        #else
        AlertSequence.share.loadAllData()
        #endif
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        //  转场动画
        self.delegate = self
        self.navigationController?.delegate = self
        loadFocusNum()
    }
    
    // MARK: - 点击事件
    
    @objc func onSearchBarClick() {
        let searchVC = SearchVC()
        navigationController?.show(searchVC, sender: nil)
    }
    
    //  关注数量
    func loadFocusNum() {
        let req = FetchUpdateVideoCountReq()
        Session.request(req) { (err, resp) in
            guard err == nil, let r = resp as? UpdateVideoCountResp else {
                return
            }
            self.segment.focusValue = r.newVideoNum
        }
    }
}

// MARK: - 水平滑动处理

extension HomeVC: UITabBarControllerDelegate, UINavigationControllerDelegate, UIGestureRecognizerDelegate {
    
    @objc func handlePan(pan: XXPanGestureRecognizer) {
        let p = pan.translation(in: pan.view)
        if pan.state == .began {
            if p.equalTo(.zero) {
                pan.xxState = .possible
            } else {
                pan.xxState = pan.state
            }
        } else if pan.state == .changed {
            if pan.xxState == .possible {
                pan.xxState = .began
            } else {
                pan.xxState = pan.state
            }
        } else if (pan.state == .ended ||
                    pan.state == .cancelled ||
                    pan.state == .failed) {
            if pan.xxState == .possible {
                pan.xxState = .possible
            } else {
                pan.xxState = pan.state
            }
        }
        handlePan2(pan: pan)
    }
    
    @objc func handlePan2(pan: XXPanGestureRecognizer) {
        let p = pan.translation(in: pan.view)
        var progress: CGFloat = p.x / pan.view!.bounds.width
        if pan.xxState == .began {
            percentTransition = UIPercentDrivenInteractiveTransition()
            if p.x > 0 {        // 向右滑动
                let idx = self.selectedIndex - 1
                if idx >= 0 && idx < items.count {
                    self.selectedViewController = items[idx]
                }
            } else if p.x < 0 { // 向左滑动
                let idx = self.selectedIndex + 1
                if idx >= 0 && idx < items.count {
                    self.selectedViewController = items[idx]
                }
            }
            
            //            if p.x > 0 && self.selectedViewController == recommandVC {
            //                self.selectedViewController = focusVC
            //            } else if p.x < 0 && self.selectedViewController == focusVC {
            //                self.selectedViewController = recommandVC
            //            } else if p.x < 0 && self.selectedViewController == recommandVC {
            //                recommandVC.gotoUesrMainPage()
            //            }
        } else if pan.xxState == .changed {
            if self.selectedIndex > self.previousSelectedIndex {
                progress = -progress
            }
            percentTransition?.update(progress)
        } else if pan.xxState == .cancelled || pan.xxState == .ended {
            let v = pan.velocity(in: pan.view)
            if progress > 0.5 || v.x > panVelocityX {   //  向右滑动
                percentTransition?.finish()
                segment.selectedSegmentIndex = self.selectedIndex
                self.previousSelectedIndex = self.selectedIndex
            } else if progress < -0.5 || -v.x > panVelocityX {  //  向左滑动
                percentTransition?.finish()
                segment.selectedSegmentIndex = self.selectedIndex
                self.previousSelectedIndex = self.selectedIndex
            } else {
                percentTransition?.cancel()
            }
            percentTransition = nil
            
            
            //            if (progress > 0.5 || v.x > panVelocityX) && self.selectedViewController == focusVC {
            //                percentTransition?.finish()
            //                segment.selectedSegmentIndex = 0
            //            } else if (progress < -0.5 || -v.x > panVelocityX) && self.selectedViewController == recommandVC {
            //                percentTransition?.finish()
            //                segment.selectedSegmentIndex = 1
            //            } else {
            //                percentTransition?.cancel()
            //            }
            //            percentTransition = nil
        }
    }
    
    func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer, shouldReceive touch: UITouch) -> Bool {
        if touch.view!.isKind(of: UISlider.self) {
            return false
        }
        return true
    }
    
    //MARK:-    转场动画
    
    func tabBarController(_ tabBarController: UITabBarController, animationControllerForTransitionFrom fromVC: UIViewController, to toVC: UIViewController) -> UIViewControllerAnimatedTransitioning? {
        let fromIdx = items.firstIndex(of: fromVC)!
        let toIdx = items.firstIndex(of: toVC)!
        if fromIdx < toIdx {
            tabBarTransition.type = .right
            return tabBarTransition
        } else if fromIdx > toIdx {
            tabBarTransition.type = .left
            return tabBarTransition
        }
        return nil
        
        //        if fromVC == recommandVC && toVC == focusVC {
        //            tabBarTransition.type = .left
        //            return tabBarTransition
        //        } else if fromVC == focusVC && toVC == recommandVC {
        //            tabBarTransition.type = .right
        //            return tabBarTransition
        //        }
        //        return nil
    }
    
    func tabBarController(_ tabBarController: UITabBarController, interactionControllerFor animationController: UIViewControllerAnimatedTransitioning) -> UIViewControllerInteractiveTransitioning? {
        return percentTransition
    }
    
    func navigationController(_ navigationController: UINavigationController, animationControllerFor operation: UINavigationController.Operation, from fromVC: UIViewController, to toVC: UIViewController) -> UIViewControllerAnimatedTransitioning? {
        return nil
        
        //        if operation == .push && toVC.isKind(of: UserMainPageVC.self) {
        //            return NavPushTransition()
        //        } else {
        //            return nil
        //        }
    }
    
    func navigationController(_ navigationController: UINavigationController, interactionControllerFor animationController: UIViewControllerAnimatedTransitioning) -> UIViewControllerInteractiveTransitioning? {
        return nil
        
        //        return percentTransition
    }
}

extension HomeVC: HomeSegmentDelegate {
    
    func switchHomeActivityEntryImgViewStatus(isHide: Bool) {
        activityEntryImgView?.isHidden = isHide
    }
    
}
