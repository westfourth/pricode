//
//  swift
//  Sp
//
//  Created by mac on 2020/5/2.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

protocol ShortVideoCounterViewDelegate: NSObjectProtocol {
    //  点击
    func didClick(counterView: ShortVideoCounterView)
}

class ShortVideoCounterView: UIButton {
    let strokeWidth: CGFloat = 3        //  線條粗細
    var imgView = UIImageView()
    
    weak var delegate: ShortVideoCounterViewDelegate?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        layer.addSublayer(blackShapeLayer)
        layer.addSublayer(gradientSuperLayer)
        layer.addSublayer(textLayer)
        
        greenShapeLayer.strokeEnd = 0
        greenShapeLayer.lineCap = .round
        textLayer.opacity = 0
        
        gradientSuperLayer.addSublayer(gradientLayer)
        gradientSuperLayer.mask = greenShapeLayer
        
        //
        addSubview(imgView)
        imgView.image = UIImage(named: "straw_hat")
        imgView.contentMode = .scaleAspectFit

        gradientLayer.anchorPoint = CGPoint(x: 1, y: 1)
        
        addTarget(self, action: #selector(click(button:)), for: .touchUpInside)
        NotificationCenter.default.addObserver(self, selector: #selector(notify(noti:)), name: shortVideoCounterDidChange, object: nil)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    deinit {
        NotificationCenter.default.removeObserver(self)
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        imgView.frame = self.bounds.insetBy(dx: 8, dy: 8)
        //  textLayer
        let attrText = textLayer.string as! NSAttributedString
        let textSize = attrText.size()
        textLayer.frame = CGRect(x: (bounds.size.width - textSize.width)/2, y: -textSize.height,
                                 width: textSize.width, height: textSize.height)
        
        let radius = bounds.size.width / 2.0
        let point = CGPoint(x: radius, y: radius)
        
        //  blackShapeLayer
        blackShapeLayer.path = UIBezierPath(arcCenter: point,
                                  radius: radius - strokeWidth / 2.0,
                                  startAngle: 0,
                                  endAngle: CGFloat.pi * 2,
                                  clockwise: true).cgPath
        blackShapeLayer.lineWidth = strokeWidth
        
        //  gradientSuperLayer
        gradientSuperLayer.frame = self.bounds
        //  gradientLayer
        gradientLayer.bounds = CGRect(x: 0, y: 0, width: radius,
                                      height: radius * sqrt(2))
        gradientLayer.position = CGPoint(x: radius, y: radius)
        
        //
        greenShapeLayer.path = UIBezierPath(arcCenter: point,
                                  radius: radius - strokeWidth / 2.0,
                                  startAngle: -CGFloat.pi/2.0,
                                  endAngle: CGFloat.pi/2.0 * 3,
                                  clockwise: true).cgPath
        greenShapeLayer.lineWidth = strokeWidth
    }
    
    //  MARK: - 懒加载
    
    lazy var blackShapeLayer: CAShapeLayer = {
        var layer = CAShapeLayer()
        layer.strokeColor = RGB(0x3A2900).cgColor
        layer.fillColor = UIColor.black.withAlphaComponent(0.34).cgColor
        layer.contentsScale = UIScreen.main.scale
        return layer
    }()
    
        
    lazy var gradientSuperLayer: CALayer = {
        var layer = CAGradientLayer()
        layer.backgroundColor = RGB(0xFFC43B).cgColor
        layer.contentsScale = UIScreen.main.scale
        return layer
    }()
    
    //  特殊的
    lazy var gradientLayer: CAGradientLayer = {
        var layer = CAGradientLayer()
        layer.colors = [RGB(0xFFC43B).cgColor, UIColor.white.cgColor]
        layer.startPoint = CGPoint(x: 0, y: 0.5)
        layer.endPoint = CGPoint(x: 1, y: 0.5)
        layer.contentsScale = UIScreen.main.scale
        return layer;
    }()
    
    lazy var greenShapeLayer: CAShapeLayer = {
        var layer = CAShapeLayer()
        layer.strokeColor = RGB(0xFFC43B).cgColor
        layer.fillColor = UIColor.clear.cgColor
        layer.contentsScale = UIScreen.main.scale
        return layer
    }()
    
    lazy var textLayer: CATextLayer = {
        var layer = CATextLayer()
        layer.string = attrText(with: ShortVideoCounterConfig.score)
        layer.contentsScale = UIScreen.main.scale
        return layer
    }()
    
    func attrText(with num: Int) -> NSMutableAttributedString {
        let text = "草帽券+\(num)"
        let attrs = [NSAttributedString.Key.font: UIFont.systemFont(ofSize: 14),
                     NSAttributedString.Key.foregroundColor: UIColor.white]
        let attrText = NSMutableAttributedString(string: text, attributes: attrs)
        attrText.addAttributes([NSAttributedString.Key.foregroundColor: RGB(0xFCC31C)], range: NSMakeRange(0, 3))
        return attrText
    }
    
    //MARK:- 事件处理
    
    //
    @objc func click(button: UIButton) {
        self.delegate?.didClick(counterView: self)
    }
    
    //
    @objc func notify(noti: Notification) {
        let totalTime = noti.object as! Float
        let percent = totalTime / Float(ShortVideoCounterConfig.circleTime)
        if Defaults.todayReportCount >= ShortVideoCounterConfig.maxReportTimes {
            update(percent: 0.99)
        } else {
            update(percent: percent)
            if totalTime == 0 {
                moveUp(textLayer)
            }
        }
    }
    
    public func update(percent: Float) {
//        print(">>> 百分比: \(percent)")
        CATransaction.begin()
        CATransaction.setAnimationDuration(0.01)
        greenShapeLayer.strokeEnd = CGFloat(percent)
        gradientLayer.transform = CATransform3DMakeRotation(CGFloat.pi * 2 * (CGFloat(percent) + 0.005), 0, 0, 1)
        CATransaction.commit()
    }
    
    //  向上移动，同时变透明
    func moveUp(_ layer: CALayer) {
        let t = CAKeyframeAnimation()
        t.keyPath = "transform.translation.y"
        t.values = [0, -25]
        
        let o = CAKeyframeAnimation()
        o.keyPath = "opacity"
        o.values = [1, 0]
        o.timingFunctions = [CAMediaTimingFunction(name: .easeInEaseOut)]
        
        let s = CAKeyframeAnimation()
        s.keyPath = "transform.scale"
        s.values = [1, 0.9]
        
        let g = CAAnimationGroup()
        g.animations = [s, t, o]
        g.duration = 1.25
        
        g.isRemovedOnCompletion = false
        g.fillMode = .forwards
        layer.add(g, forKey: nil)
    }
}
