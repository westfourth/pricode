//
//  FocusListVC.swift
//  Sp
//
//  Created by mac on 2020/3/27.
//  Copyright © 2020 mac. All rights reserved.
//


import UIKit
import AVFoundation
import M3U8Cache

class FocusListVC: UIViewController, UICollectionViewDataSource, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout, ShortVideoCellDelegate {
    //  只有一个播放器（不是每个cell都有自己的播放器）
    var player: AVPlayer = AVPlayer(playerItem: nil)
    var periodicTimeObserver: Any?
    
    //  当前播放的indexPath
    var currentPlayIndexPath: IndexPath = IndexPath(item: 0, section: 0)
    var models = [ShortVideoModel]()
    
    var nomoreData:Bool = false
    
    let line = LineLoadingView(frame: CGRect(x: UIScreen.main.bounds.size.width / 2.0 - 0.5, y: UIScreen.main.bounds.size.height - UIApplication.shared.keyWindow!.insets().bottom - 49 - 2.0, width: 1.0, height: 2.0))
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.addSubview(collectionView)
        if #available(iOS 11.0, *) {
            collectionView.contentInsetAdjustmentBehavior = .never
        } else {
            automaticallyAdjustsScrollViewInsets = false
        }
        collectionView.snp.makeConstraints { (make) in
            make.left.right.top.equalToSuperview()
            make.height.equalTo(UIScreen.main.bounds.size.height)
        }
        //  监听播放器状态
        player.addObserver(self, forKeyPath: "timeControlStatus", options: .new, context: nil)
        //  监听播放进度
        periodicTimeObserver = player.addPeriodicTimeObserver(forInterval: CMTimeMake(value: 1, timescale: 2), queue: DispatchQueue.main, using: {[weak self] (currentTime) in
            self?.observeCurrentTime(currentTime: currentTime)
        });
        loadData()
        view.addSubview(line)
    }
    
    deinit {
        player.removeObserver(self, forKeyPath: "timeControlStatus")
        player.removeTimeObserver(periodicTimeObserver!)
        NotificationCenter.default.removeObserver(self)
        print(#function)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.navigationBar.setBackgroundImage(UIImage(), for: UIBarMetrics.default)
        self.navigationController?.navigationBar.shadowImage = UIImage()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        player.pause()
    }
    
    //_______________________________________________________________________________________________________________
    // MARK: -
    
    override func observeValue(forKeyPath keyPath: String?, of object: Any?, change: [NSKeyValueChangeKey : Any]?, context: UnsafeMutableRawPointer?) {
        if object is AVPlayer {
            //  监听播放器状态
            if keyPath == "timeControlStatus" {
                let timeControlStatus = (object as! AVPlayer).timeControlStatus
                if timeControlStatus == .waitingToPlayAtSpecifiedRate {
                    line.startAnimation()
                } else if timeControlStatus == .playing || timeControlStatus == .paused {
                    line.stopAnimation()
                }
                let row = currentRow(collectionView: collectionView)
                let indexPath = IndexPath(item: row, section: 0)
                let cell = collectionView.cellForItem(at: indexPath) as? ShortVideoCell
                if cell != nil {
                    cell!.timeControlStatus = timeControlStatus
                }
            }
        }
    }
    
    //  监听播放进度
    func observeCurrentTime(currentTime: CMTime) {
        let row = currentRow(collectionView: collectionView)
        let indexPath = IndexPath(item: row, section: 0)
        let cell = collectionView.cellForItem(at: indexPath) as? ShortVideoCell
        let playerItem = player.currentItem
        if cell != nil && playerItem != nil {
            cell!.updateProgress(currentTime: playerItem!.currentTime(), duration: playerItem!.duration)
        }
    }
    
    @objc func loadData() {
        let req = FocusVideoListReq()
        req.lastId = self.models.count > 0 ? self.models.last!.videoItem!.videoId:0
        Session.request(req) { (error, resp) in
            self.collectionView.mj_header?.endRefreshing()
            if error != nil {
                self.collectionView.state = .failed
                return;
            }
            guard resp is [VideoItem] else {
                self.collectionView.state = .empty
                return
            }
            let array = resp as! [VideoItem]
            self.nomoreData = array.count < 30
            if array.count == 0 && req.lastId == 0 {
                self.collectionView.state = .empty
                return
            }
            self.self.collectionView.state = .normal
            var items:[ShortVideoModel] = [ShortVideoModel]()
            for i in 0..<array.count {
                let videoItem = array[i];
                if videoItem.videoUrl == nil {
                    continue
                }
                let videoUrl = videoItem.videoUrl!
                let localURL = M3U8LocalForRemote(videoUrl, Int(M3U8_SERVER_PORT))!
                
                let model = ShortVideoModel()
                model.videoItem = videoItem
                model.playerItem = AVPlayerItem(url: localURL)
                items.append(model)
                //  第一个播放，预快取后面的
                if i > self.currentPlayIndexPath.row && i - self.currentPlayIndexPath.row < 30 {
                    M3U8PreCache.share().preCache(videoUrl)
                }
            }
            if req.lastId == 0 {
                self.models = items
            } else {
                self.models.append(contentsOf: items)
            }
            //  播放第一个
            if self.models.count > 0 {
                self.startPlayItem(indexPath: self.currentPlayIndexPath)
            }
        }
    }

lazy var collectionView: UICollectionView = {
    let layout = UICollectionViewFlowLayout()
    layout.minimumLineSpacing = 0
    layout.minimumInteritemSpacing = 0
    layout.itemSize = ShortVideoCell.itemSize()
    
    let collectionView = UICollectionView(frame: .zero, collectionViewLayout: layout)
    collectionView.dataSource = self
    collectionView.delegate = self
    
    collectionView.register(ShortVideoCell.self, forCellWithReuseIdentifier: "CELL")
    collectionView.backgroundColor = .black
    collectionView.isPagingEnabled = true
    collectionView.showsVerticalScrollIndicator = false
    collectionView.scrollsToTop = false
    
    collectionView.state = .loading
    collectionView.mj_header = getCommonMJHeader(refreshingTarget: self, headerRefreshCallback: #selector(refreshAction))
    collectionView.loadMoreBlock = {
        guard self.nomoreData == false else {
            return
        }
        self.loadData()
    }
    return collectionView
}()

@objc func refreshAction() {
    self.models.removeAll()
    loadData()
}

//_______________________________________________________________________________________________________________
// MARK: - 资料来源

func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
    return models.count
}

func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
    let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CELL", for: indexPath) as! ShortVideoCell
    //  播放器
    let aPlayer = indexPath == currentPlayIndexPath ? player : nil
    let playerItem: AVPlayerItem? = aPlayer?.currentItem
    print("====== cellForItemAt indexPath: \(indexPath), player: \(aPlayer), visibleItems: \(collectionView.indexPathsForVisibleItems)")
    
    cell.delegate = self
    cell.cellSubviews?.delegate = self
    cell.cellSubviews?.collection?.delegate = self
    //  播放器画面
    (cell.fgImageView.layer as! AVPlayerLayer).player = aPlayer
    (cell.bgImageView.layer as! AVPlayerLayer).player = aPlayer
    //  播放进度
    if playerItem != nil {
        cell.updateProgress(currentTime: playerItem!.currentTime(), duration: playerItem!.duration)
    } else {
        cell.updateProgress(currentTime: .zero, duration: .zero)
    }
    
    let model = models[indexPath.row];
    //  封面
    if model.didShowCover {
        cell.fgImageView.image = nil
        cell.bgImageView.image = nil
    } else {
        cell.fgImageView.kf.setImage(with: model.videoItem?.coverImg,placeholder: nil, options: [.transition(.fade(0.25))])
        cell.bgImageView.kf.setImage(with: model.videoItem?.coverImg, placeholder: nil, options: [.transition(.fade(0.25))])
        model.didShowCover = true
    }
    //
    cell.model = model
    return cell
}

func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
    guard let currentItem = player.currentItem else {
        return
    }
    if player.timeControlStatus == .paused {
        let t = CMTimeSubtract(currentItem.duration, currentItem.currentTime())
        if CMTimeGetSeconds(t) < 1.0 {
            currentItem.seek(to: .zero) {[weak self] (finished) in
                //                    self?.player.play()
                self?.playAciton()
            }
        } else {
            //                player.play()
            playAciton()
        }
    } else {
        player.pause()
    }
}

//MARK:-播放前的判断
func playAciton() {
    guard self.models.count > 0 else {
        return
    }
    let model = self.models[self.currentPlayIndexPath.row]
    guard let item = model.videoItem  else {
        return
    }
    
    let req = CheckVideoAvaliableReq()
    req.videoId = item.videoId
    
    //检查是否可看
    Session.request(req) { (error, resp) in
        guard error == nil else {
            iToast(error!.localizedDescription)
            return
        }
        if resp is CheckVideoAvaliable {
            let res = resp as! CheckVideoAvaliable
            if res.canWatch {
                // 可以看 直接看
                self.player.play()
            } else {
                if res.reasonType == .notime {
                    Alert.showTimesNotEnoughAlert(parentView: self.view,
                                                  onCancelTap: {
                                                    // 充值vip
                                                    let VC = VipVC()
                                                    VipChargeTipVC.isFromVideoPlayList = true
                                                    VC.hidesBottomBarWhenPushed = true
                                                    self.parent?.navigationController?.pushViewController(VC, animated: true)
                    }) {
                        //  去分享视讯
                        let VC = ShareVideoVC()
                        VC.hidesBottomBarWhenPushed = true
                        VC.video = item
                        self.parent?.navigationController?.pushViewController(VC, animated: true)
                    }
                    return
                }
                //不可以看
                var goldBalance = 0
                //获取账户资讯并快取
                Session.request(AccountInfoReq()) { (error, resp) in
                    if error == nil {
                        if resp is AccountInfo  {
                            let info = resp as! AccountInfo
                            let json = info.toJSON()
                            NetDefaults.cacheAccountInfo =  json
                        }
                    }
                    
                    if let account = NetDefaults.fetchAccountInfo() {
                        goldBalance = Int(account.gold)
                    }
                    if item.pay {
                        //收费
                        let enough = goldBalance > item.price
                        Alert.showCoinNotEnoughAlert(parentView: self.view,
                                                     videoAuthor: item.nickName,
                                                     videoPrice: "\(item.price)",
                            balance: "\(goldBalance)",
                            balanceEnough: enough,
                            isShowBottomBar: true,
                            onCancelTap: {
                                //我要上传
                                if !enough {
                                    NotificationCenter.default.post(name: .uploadVideoNotificaitonName, object: nil)
                                }
                        }) {
                            if enough {
                                //余额够 买它
                                let req1 = PurchaseVideoReq()
                                req1.videoId = item.videoId
                                Alert.showLoading(parentView: self.view)
                                Session.request(req1) { (error, resp) in
                                    Alert.hideLoading()
                                    guard error == nil else {
                                        iToast(error!.localizedDescription)
                                        return
                                    }
                                    iToast("購買成功!")
                                    self.player.play()
                                }
                            } else {
                                // 购买金币
                                let VC = VipVC()
                                VipChargeTipVC.isFromVideoPlayList = true
                                VC.hidesBottomBarWhenPushed = true
                                self.parent?.navigationController?.pushViewController(VC, animated: true)
                            }
                        }
                    }
                }
            }
        }
    }
}

func scrollViewWillEndDragging(_ scrollView: UIScrollView, withVelocity velocity: CGPoint, targetContentOffset: UnsafeMutablePointer<CGPoint>) {
    puts(#function)
    guard  self.models.count > 0 else {
        return
    }
    let row: Int = Int(round(targetContentOffset.pointee.y / ShortVideoCell.itemSize().height))
    if row != currentPlayIndexPath.item {
        endPlayItem(indexPath: currentPlayIndexPath)
    }
}

/// 不可以通过willDisplayCell、didEndDisplayingCell来计算，在快速滑动时会出问题
func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
    puts(#function)
    guard  self.models.count > 0 else {
        return
    }
    //  计算当前是第几个
    let row = currentRow(collectionView: scrollView as! UICollectionView)
    if row != currentPlayIndexPath.item {
        let nextPlayIndexPath = IndexPath(item: row, section: 0)
        startPlayItem(indexPath: nextPlayIndexPath)
    }
}

//_______________________________________________________________________________________________________________
// MARK: -

//  计算当前UICollectionView展示第几行
func currentRow(collectionView: UICollectionView) -> Int {
    return Int(round(collectionView.contentOffset.y / ShortVideoCell.itemSize().height))
}

func shortVideoCell(_ shortVideoCell: ShortVideoCell, seekToTime time: CMTime, completion: @escaping () -> Void) {
    player.currentItem?.cancelPendingSeeks()
    player.currentItem?.seek(to: time, completionHandler: { (finished) in
        completion()
    })
}

func startPlayItem(indexPath: IndexPath) {
    print(">>> startPlayItem \(indexPath)")
    currentPlayIndexPath = indexPath
    
    let model = models[indexPath.item]
    player.replaceCurrentItem(with: model.playerItem)   //  載入視訊
    if player.timeControlStatus == .paused {
        //            player.play()
        self.playAciton()
    }
    collectionView.reloadData()
}

func endPlayItem(indexPath: IndexPath) {
    print(">>> endPlayItem \(indexPath)")
    player.replaceCurrentItem(with: nil)
}
}


//_______________________________________________________________________________________________________________
// MARK: -  Delegate

extension FocusListVC: ShortVideoCellCollectionDelegate {
    func shortVideoCellCollection(_ collection: ShortVideoCellCollection, didSelect cell: ShortVideoCellCollectionCell) {
        puts(#function)
    }
}

extension FocusListVC: ShortVideoCellSubviewsDelegate {
    //  分享
    func shortVideoCellSubviews(_ subViews: ShortVideoCellSubviews, didClickShare button: UIButton) {
        puts(#function)
        //        let shareVC = ShareVC()
        //        let model = self.models[self.currentPlayIndexPath.row]
        //        shareVC.videoId = model.videoItem?.videoId
        //        present(shareVC, animated: true, completion: nil)
        
        let VC = ShareVideoVC()
        VC.hidesBottomBarWhenPushed = true
        let model = self.models[self.currentPlayIndexPath.row]
        VC.video = model.videoItem
        navigationController?.pushViewController(VC, animated: true)
    }
    //  评论
    func shortVideoCellSubviews(_ subViews: ShortVideoCellSubviews, didClickComment button: UIButton) {
        puts(#function)
        let commentVC = CommentVC()
        let model = self.models[self.currentPlayIndexPath.row]
        guard let video  = model.videoItem else {
            return
        }
        commentVC.video = video
        commentVC.delegate = self
        commentVC.callbackCount = { count in
            let commentText = String(count).addShadow()
            commentText.addAttributes([.foregroundColor: UIColor.white], range: NSMakeRange(0, commentText.length));
            button.setAttributedTitle(commentText, for: .normal)
        }
        
        commentVC.callback = {
            // 购买金币
            let VC = VipVC()
            VipChargeTipVC.isFromVideoPlayList = true
            VC.hidesBottomBarWhenPushed = true
            self.parent?.navigationController?.show(VC, sender: nil)
        }
        present(commentVC, animated: true, completion: nil)
    }
    //  点赞
    func shortVideoCellSubviews(_ subViews: ShortVideoCellSubviews, didClickLike button: UIButton) {
        let model = self.models[self.currentPlayIndexPath.row]
        guard let videoId = model.videoItem?.videoId else {
            return
        }
        puts(#function)
        
        var likeCount = model.videoItem!.realLikes
        if button.isSelected {
            // 取消点赞
            let model = self.models[self.currentPlayIndexPath.row]
            likeCount = likeCount - 1
            model.videoItem?.isLike = false
            model.videoItem?.realLikes =  (model.videoItem?.realLikes ?? 1) - 1
            self.models[self.currentPlayIndexPath.row] = model
            let req = CancelLikeVideoReq()
            req.videoId = videoId
            Session.request(req) { (error, resp) in
                guard error == nil else {
                    return
                }
            }
        } else {
            //点赞
            let model = self.models[self.currentPlayIndexPath.row]
            likeCount = likeCount  + 1
            model.videoItem?.isLike = true
            model.videoItem?.realLikes =  (model.videoItem?.realLikes ?? 0) + 1
            self.models[self.currentPlayIndexPath.row] = model
            let req = LikeVideoReq()
            req.videoId = model.videoItem?.videoId ?? 0
            Session.request(req) { (error, resp) in
                guard error == nil else {
                    return
                }
            }
        }
        button.isSelected = !button.isSelected
        let likeText = String(likeCount).addShadow()
        likeText.addAttributes([.foregroundColor: UIColor.white], range: NSMakeRange(0, likeText.length));
        button.setAttributedTitle(likeText, for: .normal)
    }
    //  头像
    func shortVideoCellSubviews(_ subViews: ShortVideoCellSubviews, didClickAvatar button: UIButton) {
        puts(#function)
        let item = subViews.model!
        let VC = UserMainPageVC()
        VC.userId = item.videoItem?.userId
        VC.hidesBottomBarWhenPushed = true
        self.navigationController?.pushViewController(VC, animated:true)
    }
    //  新增关注
    func shortVideoCellSubviews(_ subViews: ShortVideoCellSubviews, didClickAdd button: UIButton) {
        puts(#function)
        let model = self.models[self.currentPlayIndexPath.row]
        guard let userId = model.videoItem?.userId else{return}
        if button.isSelected {
            
            Alert.showCommonAlert(parentView: self.view, contentText: "取消關注後,您將無法及時收到他的動態",
                                  cancelText: "再看看",
                                  confirmText: "取消關注",
                                  onConfirmTap: {
                                    //取消关注
                                    button.isSelected = false
                                    model.videoItem?.isAttention = false
                                    self.models[self.currentPlayIndexPath.row] = model
                                    let req =  CancelFocusUserReq()
                                    req.beenUserId = userId
                                    Session.request(req) { (error, resp) in
                                        guard error == nil else {
                                            return
                                        }
                                        iToast("取消成功!")
                                    }
            }, onCancelTap: nil)
        } else {
            //关注
            button.isSelected = true
            model.videoItem?.isAttention = true
            self.models[self.currentPlayIndexPath.row] = model
            let req =  FocusUserReq()
            req.beenUserId = userId
            Session.request(req) { (error, resp) in
                guard error == nil else {
                    return
                }
                iToast("關注成功!")
            }
        }
    }
}

//______________________________________________________________________________________________________________
// MARK: - CommentVCDelegate
extension FocusListVC:CommentVCDelegate {
    func commentViewController(commentViewController: CommentVC, _ userId: Int) {
        let VC = UserMainPageVC()
        VC.userId = userId
        VC.hidesBottomBarWhenPushed = true
        self.navigationController?.pushViewController(VC, animated:true)
    }
}


