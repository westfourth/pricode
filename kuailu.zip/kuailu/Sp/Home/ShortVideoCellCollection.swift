//
//  ShortVideoCellCollection.swift
//  Puff
//
//  Created by mac on 2019/12/9.
//  Copyright © 2019 mac. All rights reserved.
//

import UIKit

class ShortVideoCellCollection: NSObject, UICollectionViewDataSource, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout {
    public weak var superView: UIView?
    public weak var delegate: ShortVideoCellCollectionDelegate?
    
    var tagNames: [String] = [] {
        didSet {
            collectionView.reloadData()
        }
    }
    
    var isHidden: Bool = false {
        didSet {
            collectionView.isHidden = isHidden
        }
    }
    
    public init(superView: UIView) {
        self.superView = superView
        super.init()
        superView.addSubview(collectionView)
    }

    public func superViewDidLayout(bounds: CGRect, minY: CGFloat) {
        let height: CGFloat = 30
        //  边距
        let padding = UIEdgeInsets(top: 0, left: 12, bottom: 4, right: 12)
        collectionView.frame = CGRect(x: padding.left, y: minY - height - padding.bottom,
                                      width: bounds.width - (padding.left + padding.right), height: height)
    }
    
    
    
    lazy var collectionView: UICollectionView = {
        let layout = UICollectionViewFlowLayout()
        layout.minimumLineSpacing = 6
        layout.itemSize = ShortVideoCell.itemSize()
        layout.scrollDirection = .horizontal
        
        let collectionView = UICollectionView(frame: .zero, collectionViewLayout: layout)
        collectionView.dataSource = self
        collectionView.delegate = self

        collectionView.register(ShortVideoCellCollectionCell.self, forCellWithReuseIdentifier: "CELL")
        collectionView.backgroundColor = .clear
        collectionView.showsHorizontalScrollIndicator = false
        return collectionView
    }()
    
    //_______________________________________________________________________________________________________________
    // MARK: - 资料来源
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return tagNames.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CELL", for: indexPath) as! ShortVideoCellCollectionCell
        cell.text = "#\(tagNames[indexPath.item])"
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let cell = collectionView.cellForItem(at: indexPath)
        self.delegate?.shortVideoCellCollection(self, didSelect: cell as! ShortVideoCellCollectionCell)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let text = tagNames[indexPath.item]
        return ShortVideoCellCollectionCell.itemSize(text: text)
    }
}


//_______________________________________________________________________________________________________________
// MARK: - ShortVideoCellCollectionDelegate

protocol ShortVideoCellCollectionDelegate: NSObjectProtocol {
    //  点击标签
    func shortVideoCellCollection(_ collection: ShortVideoCellCollection, didSelect cell: ShortVideoCellCollectionCell)
}


//_______________________________________________________________________________________________________________
// MARK: - ShortVideoCellCollectionCell

class ShortVideoCellCollectionCell: UICollectionViewCell {
    var text: String? {
        didSet {
            label.attributedText = text?.addShadow()
        }
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        contentView.addSubview(label)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        label.frame = bounds
    }
    
    lazy var label: UILabel = {
        var label = UILabel()
        label.font = UIFont.pingFangMedium(15)
        label.textColor = .white
        label.textAlignment = .center
        label.backgroundColor = UIColor.black.withAlphaComponent(0.3)
        label.layer.cornerRadius = 4
        label.layer.masksToBounds = true
        label.layer.borderWidth = 0.5
        label.layer.borderColor = UIColor.white.withAlphaComponent(0.2).cgColor
        return label
    }()
    
    class func itemSize(text: String) -> CGSize {
        let boundingRect = ("#\(text)" as NSString).boundingRect(with: .zero, options: .usesLineFragmentOrigin, attributes: [.font: UIFont.pingFangMedium(15)], context: nil)
        return CGSize(width: boundingRect.width + 2 * 7, height: boundingRect.height + 2 * 2)
    }
}
