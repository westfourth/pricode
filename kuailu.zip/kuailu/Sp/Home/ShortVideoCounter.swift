//
//  ShortVideoCounter.swift
//  Sp
//
//  Created by mac on 2020/5/2.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit
import AVFoundation

let shortVideoCounterDidChange = NSNotification.Name("ShortVideoCounterDidChange")

/// 最后一次播放的时间
var shortVideoLastPlayTime: Float64 = 0

class ShortVideoCounter: NSObject {
    static let share = ShortVideoCounter()
    
    var models = [ShortVideoCounterModel]()
    
    var totalTime: Float = 0 {
        didSet {
//            print(">>> 当前时间\(totalTime)")
            NotificationCenter.default.post(name: shortVideoCounterDidChange, object: totalTime, userInfo: nil)
            if totalTime == 0 {
                reportTodayCount()
            }
        }
    }
    
    func filePath() -> String {
        let cacheDir = NSSearchPathForDirectoriesInDomains(.cachesDirectory, .userDomainMask, true).first
        let filePath = (cacheDir! as NSString).appendingPathComponent("ShortVideoCounter")
        return filePath
    }
    
    func read() {
        let data = NSData(contentsOfFile: filePath())
        guard data != nil else {
            return
        }
        let sameWeak = isSameWeak(path: filePath())
        if sameWeak {
            models = NSKeyedUnarchiver.unarchiveObject(with: data! as Data) as! [ShortVideoCounterModel]
            //  更新总时间
            var total: Float = 0
            for model in models {
                if NSCalendar.current.isDateInToday(model.date) {
                    total += model.time
                }
            }
            totalTime = total.truncatingRemainder(dividingBy: ShortVideoCounterConfig.circleTime)
        } else {
            models = [ShortVideoCounterModel]()
        }
    }
    
    func write() {
        let data = NSKeyedArchiver.archivedData(withRootObject: models)
        (data as NSData).write(toFile: filePath(), atomically: true)
    }
    
    /// 播放器播放回调
    ///
    /// https://app.yskkkkb.me/api/m3u8/decode?path=sp/u3/9j/po/05/0c2cf439361a4d979d94bf96f69151a5.m3u8
    func playerItemDidChange(playerItem: AVPlayerItem?) {
        guard playerItem != nil else {
            return
        }
        guard let asset = playerItem?.asset as? AVURLAsset else {
            return
        }
        let fileName = asset.url.lastPathComponent
        var model: ShortVideoCounterModel?
        
        //  找到fileName对应的model
        for i in 0..<models.count {
            let item = models[i]
            if item.fileName == fileName {
                model = item
                break
            }
        }
        if model == nil {
            model = ShortVideoCounterModel(fileName: fileName, time: 0, date: Date())
            models.append(model!)
        }
        //  一部视频最多纪录3分钟
        if model!.time > ShortVideoCounterConfig.maxEachTime {
            return
        }
        
        //  如果该视频不足3分钟
        let duration = CMTimeGetSeconds(playerItem!.duration)
        if Float(duration) <= ShortVideoCounterConfig.maxEachTime {
            //  该视频已经看完
            if Float(duration) - model!.time <= 1 {
                return
            }
        }
        
        let currentPlayTime = CMTimeGetSeconds(playerItem!.currentTime())
        let deltaTime = currentPlayTime - shortVideoLastPlayTime;
        if deltaTime <= 1.0 && deltaTime > 0 {
            model?.time += Float(deltaTime)
            //
            totalTime += Float(deltaTime)
            //  每10分钟归零
            if totalTime >= ShortVideoCounterConfig.circleTime {
                totalTime = 0
            }
        }
        
        //  记录最后一次播放时间
        shortVideoLastPlayTime = currentPlayTime;
    }
    
    //  判断当前访问此文件的时间 与 此文件最后一次写入的时间是否一致
    func isSameWeak(path: String) -> Bool {
        //  此文件不存在
        if FileManager.default.fileExists(atPath: path) == false {
            return false
        }
        //  取此文件的创建时间
        let attrs = try! FileManager.default.attributesOfItem(atPath: path)
        let createDate = attrs[FileAttributeKey.creationDate] as! Date
        let weak1 = NSCalendar.current.component(.weekOfYear, from: createDate)
        let weak2 = NSCalendar.current.component(.weekOfYear, from: Date())
        return weak1 == weak2
    }
    
    func reportTodayCount() {
        //  一天最多上报2次
        if Defaults.todayReportCount >= ShortVideoCounterConfig.maxReportTimes {
            return
        }
        //
        Defaults.todayReportCount += 1
        //  上报接口
        let req = OperateMisssonReq()
        req.missionId = ShortVideoCounterConfig.missionId
        Session.request(req) { (error, resp) in
            puts(#function)
        }
    }
}


//  视频配置。（默认值，获取到视频配置信息后，更新值）
struct ShortVideoCounterConfig {
    static var maxEachTime: Float = 3 * 60      //  每個視頻最多時長
    static var circleTime: Float = 1 * 60       //  每圈時長
    static var score: Int = 1                   //  單次領取草帽幣數
    static var maxReportTimes: Int = 20         //  每天上報次數上限
    static var missionId: Int = 0               //  任務id
}


class ShortVideoCounterModel: NSObject, NSSecureCoding {
    
    static var supportsSecureCoding: Bool {
        return true
    }
    
    var fileName: String        //  m3u8名稱
    var time: Float             //  此m3u8的播放時間
    var date: Date
    
    init(fileName: String, time: Float, date: Date) {
        self.fileName = fileName
        self.time = time
        self.date = date
        super.init()
    }
    
    required init?(coder: NSCoder) {
        fileName = coder.decodeObject(forKey: "fileName") as! String
        time = coder.decodeFloat(forKey: "time")
        date = coder.decodeObject(forKey: "date") as! Date
        super.init()
    }
    
    func encode(with coder: NSCoder) {
        coder.encode(fileName, forKey: "fileName")
        coder.encode(time, forKey: "time")
        coder.encode(date, forKey: "date")
    }
}
