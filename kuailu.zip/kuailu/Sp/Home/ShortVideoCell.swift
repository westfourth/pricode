//
//  ShortVideoCell.swift
//  ShortVideo
//
//  Created by mac on 2019/12/7.
//  Copyright © 2019 mac. All rights reserved.
//

import UIKit
import AVFoundation

class PlayerImageView: UIImageView {
    override class var layerClass: AnyClass {
        return AVPlayerLayer.self
    }
}

class ShortVideoCell: UICollectionViewCell {
    private var currentTime: CMTime = CMTime.zero
    private var duration: CMTime = CMTime.zero
    // 正在滑动
    private var isSliding = false {
        didSet {
            if isSliding {
                self.clearMode = false
            } else {
                countdownTimer = Timer(fireAt: Date(), interval: 5, target: self, selector: #selector(countdown(timer:)), userInfo: nil, repeats: true)
                RunLoop.main.add(countdownTimer!, forMode: .common)
            }
        }
    }
    //  正在滑動
    private var countdownTimer: Timer?
    private var countdown: Int = 0
    
    private var clearmodeTimer:Timer?
    
    var clearMode:Bool = false {
        didSet {
            if !self.model!.isClearMode {
                return
            }
            currentProgressTime.isHidden = clearMode
            totalTime.isHidden = clearMode
            slider.isHidden = clearMode
            for v in containerView.subviews {
                if ["fullScreen","clear"].contains(v.accessibilityIdentifier) && self.model!.isClearMode {
                    v.isHidden = clearMode
                }
            }
            if !clearMode && !isSliding {
                show5Seconds()
            }
        }
    }
    
    @objc func show5Seconds() {
        clearmodeTimer?.invalidate()
        clearmodeTimer = Timer(timeInterval: 6.0, repeats: true, block: { [weak self] (t) in
            self?.clearmodeTimer?.invalidate()
            self?.clearMode = true
        })
        RunLoop.main.add(clearmodeTimer!, forMode: .common)
    }
    //_______________________________________________________________________________________________________________
    // MARK: - 接口
    
    weak var delegate: ShortVideoCellDelegate?
    
    var cellSubviews: ShortVideoCellSubviews?
    
    //  更新资料
    var model: ShortVideoModel? {
        didSet {
            //  封面
            if model!.didShowCover {
                playView.image = nil
            } else {
                if model?.videoItem != nil {    //  此數據為視頻數據
                    playView.kf.setImage(with: model?.videoItem?.coverImg?.column0, placeholder: nil)
//                    fullView.playView.kf.setImage(with: model?.videoItem?.coverImg?.column0, placeholder: nil)
                    countdownLabel.isHidden = true
                } else {                        //  此數據為廣告數據
                    playView.kf.setImage(with: model?.videoAd?.adImage?.column0, placeholder: nil)
                    countdownLabel.isHidden = false
                    if let minStaySecond = model?.videoAd?.minStaySecond {
                        countdown = minStaySecond
                        countdownTimer?.invalidate()
                        countdownTimer = Timer(fireAt: Date(), interval: 1, target: self, selector: #selector(countdown(timer:)), userInfo: nil, repeats: true)
                        RunLoop.main.add(countdownTimer!, forMode: .common)
                    }
                }
            }
            
            cellSubviews?.model = model
            updateSlider(model!)
            //  更新画面比例
            setNeedsLayout()
        }
    }
    
    
    /// 滑动条
    func updateSlider(_ model:ShortVideoModel) {
        currentProgressTime.isHidden = !model.isClearMode
        totalTime.isHidden = !model.isClearMode
        let tabbarFrame = (UIApplication.shared.delegate as! AppDelegate).tabbar!.frame
        //  slider
        let sliderHeight:CGFloat = 30;
        
        if model.isClearMode {
            let leftPadding:CGFloat = 40
            clearMode = false
            slider.frame = CGRect(x: leftPadding, y: ShortVideoCell.itemSize().height - UIApplication.shared.keyWindow!.safeAreaInsets.bottom - sliderHeight / 2 - 4, width: bounds.size.width - leftPadding - leftPadding, height: sliderHeight)
            
            loadingView.frame = CGRect(x: bounds.width / 2.0 - 0.5, y: ShortVideoCell.itemSize().height - UIApplication.shared.keyWindow!.safeAreaInsets.bottom - 2,
                                       width: 1, height: 3);
        } else {
            let hotHeight: CGFloat = model.hots != nil ? 30 : 0
            let offsetY: CGFloat = 10
            slider.frame = CGRect(x: 0, y: tabbarFrame.minY - hotHeight - offsetY - sliderHeight / 2 - 1,
                                  width: bounds.width, height: sliderHeight)
            loadingView.frame = CGRect(x: bounds.width / 2.0 - 0.5, y: tabbarFrame.minY - hotHeight - offsetY - 2,
                                       width: 1, height: 3);
        }
    }
    
    //  更新播放状态
    var timeControlStatus: AVPlayer.TimeControlStatus? {
        didSet {
            playImageView.image = timeControlStatus == .paused ? UIImage(named: "ic_play") : nil
            //  暂停时，也显示原点。
            slider.isHighlighted = timeControlStatus == .paused ? true : false
            //
            if timeControlStatus == .waitingToPlayAtSpecifiedRate {
                loadingView.startAnimation()
            } else {
                loadingView.stopAnimation()
            }
        }
    }
    
    //  更新进度
    func updateProgress(currentTime: CMTime, duration: CMTime) {
        if isSliding {      //  正在滑動不需要設定
            return;
        }
        self.currentTime = currentTime
        
        if duration != .zero && !duration.isIndefinite {
            let totalSeconds = Int(duration.value) / Int(duration.timescale)
            totalTime.text = ShortVideoCell.durationMMSS(TimeInterval(totalSeconds))
        }
        if currentTime != .zero && !currentTime.isIndefinite  {
            let currentSeconds:Int = Int(currentTime.value) / Int(currentTime.timescale)
            currentProgressTime.text = ShortVideoCell.durationMMSS(TimeInterval(currentSeconds))
        }
        self.duration = duration
        if duration == .zero || duration.isIndefinite || currentTime == .zero  {
            slider.value = 0
            slider.maximumValue = 1;
        } else {
            self.slider.maximumValue = Float(CMTimeGetSeconds(duration))
            UIView.beginAnimations(nil, context: nil)
            UIView.setAnimationDuration(0.5 + 0.25)
            self.slider.setValue(Float(CMTimeGetSeconds(currentTime)), animated: true)
            UIView.commitAnimations()
        }
        //
    }
    
    //  广告倒计时
    @objc func countdown(timer: Timer) {
        countdownLabel.text = "\(countdown)s"
        self.delegate?.shortVideoCell(self, didCountdown: countdown)
        if countdown <= 0 {
            countdownTimer?.invalidate()
            countdownLabel.isHidden = true
        }
        countdown -= 1
    }
    
    //_______________________________________________________________________________________________________________
    // MARK: - 生命周期
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        contentView.addSubview(containerView)
        
//        contentView.addSubview(blurView)
//        let superView = blurView.contentView
        let superView = containerView
        
        superView.addSubview(playView)
        superView.addSubview(playImageView)
        superView.addSubview(loadingView)
        
        cellSubviews = ShortVideoCellSubviews(superView: superView)
        superView.addSubview(progressLabel)
        
        superView.addSubview(countdownLabel)
        
        superView.addSubview(slider)
        
        superView.addSubview(currentProgressTime)
        superView.addSubview(totalTime)
        
        superView.addSubview(fullView)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
//        blurView.frame = bounds
        containerView.frame = bounds
        fullView.frame = containerView.bounds
        var ratio: CGFloat = CGFloat(640) / CGFloat(360)        //  視頻高寬比
        if let item = self.model?.videoItem, item.width != 0 {
            ratio = CGFloat(item.height) / CGFloat(item.width)
        }
        
        let value = ratio / (UIScreen.main.bounds.size.height / UIScreen.main.bounds.size.width)
        let full: Bool = (value <= 1.0 && value >= 0.8)
        playView.frame = full ? bounds : playViewFrame(ratio: ratio)
        //
        cellSubviews?.superViewDidLayout(bounds: bounds)
        
        //  playImageView
        var size = CGSize(width: 40, height: 40)
        playImageView.frame = CGRect(x: (bounds.width - size.width) / 2.0,
                                     y: (bounds.height - size.height) / 2.0,
                                     width: size.width, height: size.height)
        
        let tabbarFrame = (UIApplication.shared.delegate as! AppDelegate).tabbar!.frame
        
        let safeH = ShortVideoCell.itemSize().height - UIApplication.shared.keyWindow!.safeAreaInsets.bottom
//        //  slider
        let sliderHeight:CGFloat = 30;
//        slider.frame = CGRect(x: 0, y: tabbarFrame.minY - sliderHeight / 2 - 1,
//                              width: bounds.width, height: sliderHeight)
        let timeWidth:CGFloat = 40
        currentProgressTime.frame = CGRect(x: 0, y: safeH - 13.5, width: timeWidth, height: 20)

        totalTime.frame = CGRect(x: bounds.width - timeWidth, y: safeH - 13.5, width: timeWidth, height: 20)
        
        //  loadingView
        loadingView.frame = CGRect(x: bounds.width / 2.0 - 0.5, y: tabbarFrame.minY - 2,
                                   width: 1, height: 3);
        
        if  self.model != nil {
            if self.model!.isClearMode {
                loadingView.frame = CGRect(x: bounds.width / 2.0 - 0.5, y: ShortVideoCell.itemSize().height - UIApplication.shared.keyWindow!.safeAreaInsets.bottom - 5,
                                           width: 1, height: 3);
            }
        }
        //  progressLabel
        progressLabel.frame = CGRect(x: 0, y: tabbarFrame.minY - 200,
                                     width: bounds.width, height: 30)
        
        //  countLabel
        size = CGSize(width: 70, height: 30)
        let statusH = UIApplication.shared.statusBarFrame.height
        countdownLabel.frame = CGRect(x: bounds.width - size.width, y: statusH + 44 + 20,
                                  width: size.width + size.height / 2, height: size.height)
    }
    
    override func willMove(toSuperview newSuperview: UIView?) {
        if newSuperview == nil {
            countdownTimer?.invalidate()
        }
    }
    
    //  ratio：宽高比
    func playViewFrame(ratio: CGFloat) -> CGRect {
        var playViewFrame = CGRect.zero
        let height: CGFloat = frame.width *  ratio
        let minY: CGFloat = (frame.height - height) / 2.0
        playViewFrame = CGRect(x: 0, y: minY, width: frame.width, height: height)
        return playViewFrame
    }
    
    //_______________________________________________________________________________________________________________
    // MARK: -  控件
    
//    lazy var blurView: UIVisualEffectView = {
//        let effect = UIBlurEffect(style: .light)
//        var view = UIVisualEffectView(effect: effect)
//        return view
//    }()
    
//    lazy var containerView: PlayerImageView = {
//        var view = PlayerImageView()
//        view.contentMode = .scaleAspectFill
//        (view.layer as! AVPlayerLayer).videoGravity = .resizeAspectFill
//        view.layer.backgroundColor = UIColor.black.cgColor
//        view.isUserInteractionEnabled = true
//        return view
//    }()
    
    lazy var containerView: UIView = {
        var view = UIView()
//        object_setClass(view.layer, CAGradientLayer.self)
//        let layer = view.layer as! CAGradientLayer
//        layer.colors = [RGB(0x161a27).cgColor, RGB(0x070324).cgColor]
        view.backgroundColor = RGB(0x141516)
        return view
    }()
    
    lazy var playView: PlayerImageView = {
        var view = PlayerImageView()
        view.contentMode = .scaleAspectFill
        (view.layer as! AVPlayerLayer).videoGravity = .resizeAspectFill
        view.layer.backgroundColor = UIColor.black.cgColor
        view.layer.masksToBounds = true
        view.accessibilityIdentifier = "playView"
        return view
    }()
    
    //  播放、暂停、载入显示
    lazy var playImageView: UIImageView = {
        let view = UIImageView()
        view.contentMode = .scaleAspectFit
//        GlobalSettings.addBlackShadow(view)
        return view
    }()
    
    //  进度条
    lazy var slider: UISlider = {
        let view = UISlider()
        view.minimumTrackTintColor = rgb(0xE78C05).withAlphaComponent(0.5)
        view.maximumTrackTintColor = UIColor.clear
        view.setThumbImage(DrawImage.sliderImage(), for: .normal)
//        view.setThumbImage(UIImage(), for: .highlighted)
        view.tag = sliderTag
        
        view.addTarget(self, action: #selector(sliderTouchBegin), for: .touchDown)
        view.addTarget(self, action: #selector(sliderTouchChange), for: .valueChanged)
        view.addTarget(self, action: #selector(sliderTouchEnd), for: .touchUpInside)
        view.addTarget(self, action: #selector(sliderTouchCancel), for: .touchUpOutside)
        view.addTarget(self, action: #selector(sliderTouchCancel), for: .touchCancel)
        return view
    }()
    
    //  加载动画
    lazy var loadingView: LineLoadingView = {
        let view = LineLoadingView()
        return view
    }()
    
    lazy var progressLabel: UILabel = {
        let view = UILabel()
        view.text = "00:00"
        view.textColor = UIColor.white
        view.textAlignment = .center
        view.font = UIFont.systemFont(ofSize: 24)
        view.isHidden = true
        return view
    }()
    
    
    /// 当前时间
    lazy var currentProgressTime: UILabel = {
        let view = UILabel()
        view.text = "--:--"
        view.textColor = UIColor.white
        view.textAlignment = .center
        view.font = UIFont.systemFont(ofSize: 10)
        view.isHidden = true
        return view
    }()
    
    /// 视频总时长
    lazy var totalTime: UILabel = {
        let view = UILabel()
        view.text = "--:--"
        view.textColor = UIColor.white
        view.textAlignment = .center
        view.font = UIFont.systemFont(ofSize: 10)
        view.isHidden = true
        return view
    }()
    
    
    //  倒计时
    lazy var countdownLabel: UILabel = {
        let view = UILabel()
        view.backgroundColor = UIColor.black.withAlphaComponent(0.4)
        view.text = "3s"
        view.textColor = UIColor.white
        view.textAlignment = .center
        view.font = UIFont.systemFont(ofSize: 16)
        view.layer.cornerRadius = 15
        view.layer.masksToBounds = true
        view.padding = UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 4)
//        view.isHidden = true
        return view
    }()
    
    //_______________________________________________________________________________________________________________
    // MARK: -  滑动条事件
    
    @objc func sliderTouchBegin() {
        isSliding = true
        if duration != .zero && !duration.isIndefinite {
            progressLabel.isHidden = false
        }
    }
    
    @objc func sliderTouchChange() {
        if duration != .zero && !duration.isIndefinite {
            let currentTimeText = ShortVideoCell.durationText(TimeInterval(slider.value))
            progressLabel.text = currentTimeText
            currentProgressTime.text = ShortVideoCell.durationMMSS(TimeInterval(slider.value))
        }
    }
    
    @objc func sliderTouchEnd() {
        let destTime = CMTimeMake(value: Int64(slider.value), timescale: 1)
        delegate?.shortVideoCell(self, seekToTime: destTime, completion: {
            self.isSliding = false
            self.progressLabel.isHidden = true
        })
    }
    
    @objc func sliderTouchCancel() {
        isSliding = false
        progressLabel.isHidden = true
    }
    
    //_______________________________________________________________________________________________________________
    // MARK: -
    
    //  生成时间字串，格式：00:00
    static func durationText(_ duration: TimeInterval) -> String {
        let minute: Int = Int(duration / 60)
        let second: Int = Int(duration) % 60
        let string = String(format: "%02d:%02d", minute, second)
        return string
    }
    
    static func durationMMSS(_ duration:TimeInterval)->String {
        let minutes:Int = Int(duration) / 60
        let seconds: Int = Int(duration) % 60
        let string = String(format: "%02d:%02d",minutes, seconds)
        return string
    }
    
    static func itemSize() -> CGSize {
        return UIScreen.main.bounds.size
    }
    
    
    //MARK: 全屏幕
    lazy var fullView:ShortVideoFullPlayView = {
        let v = Bundle.main.loadNibNamed("ShortVideoFullPlayView", owner: nil, options: [:])?.first as! ShortVideoFullPlayView
        v.isHidden = true
        return v
    }()
}

protocol ShortVideoCellDelegate: NSObjectProtocol {
    //  拖动进度条
    func shortVideoCell(_ shortVideoCell: ShortVideoCell, seekToTime time: CMTime, completion: @escaping () -> Void)
    
    //  倒计时
    func shortVideoCell(_ shortVideoCell: ShortVideoCell, didCountdown remainTime:Int)
}
