//
//  Home2VC.swift
//  Sp
//
//  Created by mac on 2021/1/12.
//  Copyright © 2021 mac. All rights reserved.
//

import UIKit

class Home2VC: UIViewController {
    @IBOutlet weak var collectionView: UICollectionView!
    
    @IBOutlet weak var layout: UICollectionViewFlowLayout!
    
    @IBOutlet weak var moreKindButton: UIButton!
    
    var currentIndex = 0 {
        didSet {
            switchFloatActivityEntryImgViewStatus()
        }
    }
        
    var controllers:[UIViewController] = [UIViewController]()
    
    var isClear:Bool = false
    
    var activityEntryImgView: UIImageView? {
        didSet {
            switchFloatActivityEntryImgViewStatus()
        }
    }
    
    let pageViewController = UIPageViewController(transitionStyle: .scroll, navigationOrientation: .horizontal, options: nil)
    
    override func viewDidLoad() {
        super.viewDidLoad()
        collectionView.register(UINib(nibName: "SwitchCell", bundle: Bundle.main), forCellWithReuseIdentifier: "SwitchCell")
        pageViewController.dataSource = self
        pageViewController.delegate = self
        addChild(pageViewController)
        view.insertSubview(pageViewController.view, belowSubview: collectionView)
        
        pageViewController.view.frame = CGRect(x: 0, y:0, width: view.bounds.width, height: view.bounds.height)
        
        NotificationCenter.default.addObserver(self, selector: #selector(clearModeChangeAction(noti:)), name:shortVideoClearModeDidChange , object: nil)
        
        Session.request(ChargeLimitDiscountsReq()){(erorr, resp) in
            guard erorr == nil, let _ = resp as? ChargeLimitDiscounts else {
                self.loadKindsData()
                Defaults.hasDiscountActivity = false
                return
            }
            Defaults.hasDiscountActivity = true
            self.loadKindsData()
        }
        
        let aView = pageViewController.view.subviews.first as? UIScrollView
        aView?.delaysContentTouches = false   
    }
    
    deinit {
        NotificationCenter.default.removeObserver(self)
    }
    
    var kinds:[ClassyKindItem] = [ClassyKindItem]()
    
    func loadKindsData() {
        
        Alert.showLoading(parentView: self.view)
        Session.request(ClassyKindListReq()) { (e, resp) in
            Alert.hideLoading()
            guard e == nil else {
                iToast(e!.localizedDescription)
                return
            }
            guard let r = resp as? [ClassyKindItem],!r.isEmpty else {
                return
            }
            self.kinds.append(contentsOf: r)
            for i in self.kinds {
                if i.type == .classic {
                    let vc = ShortVideoListVC()
                    self.controllers.append(vc)
                } else if i.type == .recommend {
                    let vc = SmallVideoRecommendVC()
                    self.controllers.append(vc)
                } else {
                    let vc = HomeKindSubVC()
                    self.controllers.append(vc)
                }
            }
            
            if self.controllers.first! is HomeKindSubVC {
                let vc = self.controllers.first as! HomeKindSubVC
                vc.classifyId = self.kinds.first!.classifyId
            } else if self.controllers.first! is SmallVideoRecommendVC {
                let vc = self.controllers.first as! SmallVideoRecommendVC
                vc.classifyId = self.kinds.first!.classifyId
            }
            //  默认显示官方推荐
            self.pageViewController.setViewControllers([self.controllers.first!], direction: .forward, animated: true, completion: nil)
            
            self.collectionView.reloadData()
            
            self.switchFloatActivityEntryImgViewStatus()
        }
        
    }
    
    @IBAction func moreKindsAciton(_ sender: Any) {
        let vc = SmallVideoTopicVC()
        vc.hidesBottomBarWhenPushed = true
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @objc func clearModeChangeAction(noti:Notification) {
        if let clear = noti.object as? Bool {
            self.isClear = clear
//            self.pageViewController.dataSource = nil
//            self.pageViewController.dataSource = self
            if !self.controllers.isEmpty {
                pageViewController.setViewControllers([controllers[currentIndex]], direction: .forward, animated: true, completion: nil)
            }
            UIView.animate(withDuration: 0.1) {
                self.collectionView.alpha = clear ? 0:1.0
                self.moreKindButton.alpha = clear ? 0:1.0
            } completion: { (finished) in
                self.collectionView.isHidden = clear
                self.moreKindButton.isHidden = clear
                self.activityEntryImgView?.isHidden = clear
                if let v = self.activityView() {
                    v.isHidden = clear
                }
            }
        }
    }
    
    /// 查找打折view
    func activityView()->DiscountFloatingView? {
//        for v in view.subviews {
//            if v is DiscountFloatingView {
//                return v as? DiscountFloatingView
//            }
//        }
        return nil
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.setNavigationBarHidden(true, animated: animated)
        tabBarController?.tabBar.isTranslucent = true
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        // 如果当前是短视频，就给短视频发送viewDidAppear
        let vc = pageViewController.viewControllers?.first
        if vc is ShortVideoListVC {
            // 修复重新进入不能播放bug
            vc?.viewDidAppear(animated)
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.navigationController?.setNavigationBarHidden(false, animated: animated)
        tabBarController?.tabBar.isTranslucent = false
    }
    
    private func switchFloatActivityEntryImgViewStatus() {
        activityEntryImgView?.isHidden = !(!kinds.isEmpty && currentIndex < kinds.count && kinds[currentIndex].type == .classic)
    }
    
    /// 设置id
    func setId(currentIndex:Int) {
        if controllers[currentIndex] is  HomeKindSubVC {
            let vc = controllers[currentIndex] as! HomeKindSubVC
            vc.classifyId = kinds[currentIndex].classifyId
        } else if  self.controllers[currentIndex] is SmallVideoRecommendVC {
            let vc = self.controllers[currentIndex] as! SmallVideoRecommendVC
            vc.classifyId = self.kinds[currentIndex].classifyId
        }
    }
}


//_______________________________________________________________________________________________________________
// MARK: - UICollectionViewDataSource&Delegate
extension Home2VC:UICollectionViewDataSource,UICollectionViewDelegate,UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return kinds.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "SwitchCell", for: indexPath) as! SwitchCell
        cell.name.text = kinds[indexPath.row].classifyTitle
        currentIndex == indexPath.row ? cell.scale():cell.normal()
        cell.name.textColor = currentIndex == indexPath.row ? rgb(0xffFF9903):.white
        return cell
    }
    
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let title = kinds[indexPath.row].classifyTitle
        return CGSize(width: title.getStringSize(rectSize: CGSize(width: CGFloat.greatestFiniteMagnitude, height: 40), font: UIFont.systemFont(ofSize: 20, weight: .medium)).width + 15, height: 40)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        return .zero
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return  0
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return  0
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        pageViewController.setViewControllers([controllers[indexPath.row]], direction: indexPath.row >= self.currentIndex ?  .forward : .reverse, animated: true, completion: nil)
        let index = indexPath.row
        setId(currentIndex: index)
        currentIndex = indexPath.row
        collectionView.reloadData()
        collectionView.scrollToItem(at: indexPath, at: UICollectionView.ScrollPosition.left, animated: true)
    }
}


//_______________________________________________________________________________________________________________
// MARK: - UIPageViewControllerDataSource &Delegate
extension Home2VC:UIPageViewControllerDataSource,UIPageViewControllerDelegate {
    func pageViewController(_ pageViewController: UIPageViewController, viewControllerBefore viewController: UIViewController) -> UIViewController? {
        if isClear { return nil}
        if self.controllers.isEmpty {return nil}
        let i = controllers.firstIndex(where:  {$0 == viewController}) ?? 0
        if i > 0 {
            return controllers[i - 1]
        }
        return nil
    }
    
    func pageViewController(_ pageViewController: UIPageViewController, viewControllerAfter viewController: UIViewController) -> UIViewController? {
        if self.controllers.isEmpty {return nil}
        if isClear { return nil}
        let i = controllers.firstIndex(where:  {$0 == viewController}) ?? 0
        if i < self.controllers.count - 1 {
            return controllers[i + 1]
        }
        return nil
    }
    
    func pageViewController(_ pageViewController: UIPageViewController, didFinishAnimating finished: Bool, previousViewControllers: [UIViewController], transitionCompleted completed: Bool) {
        if completed == false {
            return
        }
        if self.controllers.isEmpty {return }
        currentIndex = self.controllers.firstIndex(where:  {$0 == pageViewController.viewControllers!.first!}) ?? 0
        setId(currentIndex: currentIndex)
        collectionView.reloadData()
        collectionView.scrollToItem(at: IndexPath(row: currentIndex , section: 0), at: UICollectionView.ScrollPosition.left, animated: true)
    }
    
}


