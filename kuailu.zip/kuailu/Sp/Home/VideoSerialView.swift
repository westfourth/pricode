//
//  VideoSerialView.swift
//  Sp
//
//  Created by mac on 2020/5/22.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

@objc protocol VideoSerialViewDelegate {
    /// 点击某个剧集
    func videoSerial(_ view:VideoSerialView,item:VideoItem)
}

class VideoSerialView: UIView {
    weak var delegate: VideoSerialViewDelegate?

    @IBOutlet weak var collectionView: UICollectionView!
    @IBOutlet weak var layout: UICollectionViewFlowLayout!
    
    var selectedIndex = 10000
    
    var items:[VideoItem]? {
        didSet {
            guard let _ = items else {
                return
            }
//            selectedIndex = 10000
            self.collectionView.reloadData()
        }
    }
    
    var currentPlayingIndx:Int? {
        didSet {
            guard let index = currentPlayingIndx  else {
                return
            }
            selectedIndex = index
            self.collectionView.reloadData()
        }
    }
    
    override  func awakeFromNib() {
        super.awakeFromNib()
       backgroundColor = RGB(0x07072F)
        layout.sectionInset = UIEdgeInsets(top: 0, left: 12, bottom: 0, right: 0)
        layout.itemSize = CGSize(width: 57, height: collectionView.bounds.size.height)
        layout.scrollDirection = .horizontal
        
        collectionView.register(UINib(nibName: "VideoSerialCell", bundle: Bundle.main), forCellWithReuseIdentifier: "VideoSerialCell")
    }
}

extension VideoSerialView:UICollectionViewDataSource,UICollectionViewDelegate {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return items?.count ?? 0
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "VideoSerialCell", for: indexPath) as! VideoSerialCell
        cell.index.text = "\(indexPath.row + 1)"
        if indexPath.row == selectedIndex {
            cell.layer.borderColor = UIColor.white.cgColor
            cell.layer.borderWidth = 1.0
        } else {
            cell.layer.borderWidth = 0.0
        }
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        guard let items = items else {return}
        if selectedIndex != indexPath.row {
            selectedIndex = indexPath.row
            collectionView.reloadData()
            delegate?.videoSerial(self, item: items[indexPath.row])
        }
    }
}


