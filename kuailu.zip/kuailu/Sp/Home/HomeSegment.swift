//
//  HomeSegment.swift
//  Sp
//
//  Created by mac on 2020/5/26.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

protocol HomeSegmentDelegate: NSObjectProtocol {
    
    func switchHomeActivityEntryImgViewStatus(isHide: Bool)
    
}

class HomeSegment: UIView {
    @IBOutlet weak var focusLabel: UILabel!
    @IBOutlet weak var recommandLabel: UILabel!
    @IBOutlet weak var featureLabel: UILabel!
    
    @IBOutlet weak var focusBadge: UILabel!
    @IBOutlet weak var recommandBadge: UILabel!
    @IBOutlet weak var featureBadge: UILabel!
    
    weak var delegate: HomeSegmentDelegate?
    
    //  0 - 关注, 1 - 推荐, 3 - 精选 
    var selectedSegmentIndex: Int = 0 {
        didSet {
            delegate?.switchHomeActivityEntryImgViewStatus(isHide: selectedSegmentIndex == 2)
            focusLabel.font = font(16)
            recommandLabel.font = font(16)
            featureLabel.font = font(16)
            
            if selectedSegmentIndex == 0 {
                focusLabel.font = font(18, .semibold)
            } else if selectedSegmentIndex == 1 {
                recommandLabel.font = font(18, .semibold)
            } else if selectedSegmentIndex == 2 {
                featureLabel.font = font(18, .semibold)
            }
        }
    }
    
    var focusValue: Int = 0 {
        didSet {
            focusBadge.text = String(focusValue)
            focusBadge.isHidden = focusValue == 0
        }
    }
    
    var tapCallback: ((Int) -> Void)?
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }
    
    override var intrinsicContentSize: CGSize {
        return CGSize(width: 210, height: 44)
    }
    
    @IBAction func tap(tap: UITapGestureRecognizer) {
        let index = tap.view!.tag
        self.selectedSegmentIndex = index
        self.tapCallback?(index)
    }
}
