//
//  VideoSerialCell.swift
//  Sp
//
//  Created by mac on 2020/5/22.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class VideoSerialCell: UICollectionViewCell {

    @IBOutlet weak var index: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
