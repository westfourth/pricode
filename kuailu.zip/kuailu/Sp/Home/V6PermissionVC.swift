//
//  V6PermissionVC.swift
//  Sp
//
//  Created by mac on 2021/1/11.
//  Copyright © 2021 mac. All rights reserved.
//

import UIKit

class V6PermissionVC: UIViewController {
    @IBOutlet weak var v6: UIButton!
    
     var vipAction: (() -> ())?
    
    var transtioner:ModalTransitionManager!

    
    override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: Bundle?) {
        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
        modalPresentationStyle = .overFullScreen
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        transtioner = ModalTransitionManager(viewController: self, height: 240)
        object_setClass(self.view.layer, CAGradientLayer.self)
        let l = self.view.layer as! CAGradientLayer
        l.colors = [Color.theme_color.cgColor,
                    RGB(0xFFB03B).cgColor]
        l.startPoint = CGPoint(x: 0, y: 0)
        l.endPoint = CGPoint(x: 0, y: 1)
        l.masksToBounds = true
        l.cornerRadius = 22
        gridientVip()
    }
    
    func gridientVip() {
        object_setClass(v6.layer, CAGradientLayer.self)
        let l = v6.layer as! CAGradientLayer
        l.colors = [RGB(0xFFE2BE).cgColor,
                    RGB(0xFFD18E).cgColor]
        l.startPoint = CGPoint(x: 0, y: 0)
        l.endPoint = CGPoint(x: 1, y: 0)
        l.masksToBounds = true
        l.cornerRadius = 22
    }
    
    @IBAction func vip(_ sender: Any) {
        dismiss(animated: true) {
            if self.vipAction != nil {
                self.vipAction!()
            }
        }
    }
}
