//
//  ShortVideoCellSubviews.swift
//  Sp
//
//  Created by mac on 2020/2/27.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

/**
 该物件主要是展示短视频的其他UI。当短视频出现问题时，可移除此类，方便除错。
 */
class ShortVideoCellSubviews: NSObject {
    public weak var superView: UIView?
    public weak var delegate: ShortVideoCellSubviewsDelegate?
    
    var collection: ShortVideoCellCollection?
    var hot:HotSpotView?
    
    private static let avatarImg: UIImage? = {
        return Sensitive.avatar
    }()
    
    static let animationOption: KingfisherOptionsInfo = {
        return [.transition(.fade(0.25))]
    }()
    
    var hasHotSpot = false
    
    //  更新资料
    var model: ShortVideoModel? {
        didSet {
            if let v = model?.videoItem {   //  視頻
                downloadButton.isHidden = true
                coinButton.isHidden = false
                collection?.isHidden = false
                
                likeButton.isUserInteractionEnabled = true
                commentButton.isUserInteractionEnabled = true
                shareButton.isUserInteractionEnabled = true
                addButton.isUserInteractionEnabled = true
                fullScreen.isUserInteractionEnabled = true
                clear.isUserInteractionEnabled = true
                

                hasHotSpot = model?.hots != nil
                hot?.items = model?.hots
                
                hot?.hotView.isHidden = model!.isdynamic ? true: !hasHotSpot
                //
                let commentText = String(v.commentNum < 0 ? "0" : num2TenThousandStrFormat(v.commentNum)).addShadow()
                commentText.addAttributes([.foregroundColor: UIColor.white], range: NSMakeRange(0, commentText.length));
                commentButton.setAttributedTitle(commentText, for: .normal)
                //
                let likeText = String(v.fakeLikes < 0 ? "0" : num2TenThousandStrFormat(v.fakeLikes)).addShadow()
                likeText.addAttributes([.foregroundColor: UIColor.white], range: NSMakeRange(0, likeText.length));
                likeButton.setAttributedTitle(likeText, for: .normal)
                likeButton.isSelected = v.isLike
                //
                addButton.setImage(UIImage(named: "ic_follew_2"), for: .normal)
                addButton.isHidden = model!.isdynamic ? true: v.isAttention
                //  如果是自己，隐藏
                if let user = NetDefaults.userInfo {
                    if let userID = model?.videoItem?.userId {
                        if userID == user.userId {
                            addButton.isHidden = true
                        }
                    }
                }
                //
                userNameLabel.attributedText = "@\(v.nickName)".addShadow()
                titleLabel.attributedText = v.title.addShadow()
                avatarButton.kf.setImage(with: v.logo, for: .normal,placeholder: ShortVideoCellSubviews.avatarImg, options: ShortVideoCellSubviews.animationOption)
                collection?.tagNames = v.tagTitles.count > 3 ? Array(v.tagTitles.prefix(3)):v.tagTitles
                coinButton.isHidden = v.price == 0
//                coinLabel.attributedText =  "\(v.price)\(Sensitive.jin)".addShadow()
            } else if let v = model?.videoAd {                    //  廣告
                hot?.hotView.isHidden = true
                downloadButton.isHidden = false
                coinButton.isHidden = true
                collection?.isHidden = true
                
                likeButton.isUserInteractionEnabled = false
                commentButton.isUserInteractionEnabled = false
                shareButton.isUserInteractionEnabled = false
                addButton.isUserInteractionEnabled = false
                fullScreen.isUserInteractionEnabled = false
                clear.isUserInteractionEnabled = false

                userNameLabel.attributedText = "@\(v.adUserName)".addShadow()
//                titleLabel.attributedText = v.adName.addShadow()
                let titleLabelAttrText = v.adName.addShadow()
                let attach = NSTextAttachment()
                attach.image = UIImage(named: "sv_ad")
                attach.bounds = CGRect(x: -3, y: -3, width: 78/3, height: 42/3)
                let attachAttrText = NSAttributedString(attachment: attach)
                titleLabelAttrText.append(attachAttrText)
                titleLabel.attributedText = titleLabelAttrText
                
                addButton.setImage(UIImage(named: "sv_link"), for: .normal)
                addButton.isHidden = false
                avatarButton.kf.setImage(with: v.adUserLogo, for: .normal,placeholder: ShortVideoCellSubviews.avatarImg, options: ShortVideoCellSubviews.animationOption)
                
                let r1 = 120 +  Int(arc4random() % 5000)
                let commentText = String( num2TenThousandStrFormat(r1)).addShadow()
                commentText.addAttributes([.foregroundColor: UIColor.white], range: NSMakeRange(0, commentText.length));
                commentButton.setAttributedTitle(commentText, for: .normal)
                //
                let r2 = 120 +  Int(arc4random() % 5000)
                let likeText = String(num2TenThousandStrFormat(r2)).addShadow()
                likeText.addAttributes([.foregroundColor: UIColor.white], range: NSMakeRange(0, likeText.length));
                likeButton.setAttributedTitle(likeText, for: .normal)
                
            }
            guard let model = model else {return}
            setUI(model)
            superViewDidLayout(bounds: bounds)
        }
    }
    
    
    func setUI(_ model:ShortVideoModel) {
        if model.videoItem != nil {
            clear.isSelected = model.isClearMode
            // 视频
            if model.isClearMode {
                // 清爽模式
                isHidden = true
            } else {
                // 非清爽模式
                isHidden = model.isdynamic
                if !model.isdynamic {
                    coinButton.isHidden = model.videoItem?.price == 0
                }
                fullScreen.isHidden = !isHoritzonVideo(model)
            }
        } else {
            // 广告
            isHidden = true
        }
        layoutRightViews(self.bounds,model: model)
    }
    
    // 是否是横屏视频
    func isHoritzonVideo(_ model:ShortVideoModel)->Bool {
        var ratio: CGFloat = CGFloat(640) / CGFloat(360)        //  視頻高寬比
        if let item = model.videoItem, item.width != 0 {ratio = CGFloat(item.height) / CGFloat(item.width)}
        return ratio < 1
    }
    
    
    var isHidden: Bool = false {
        didSet {
            //  下部
            titleLabel.isHidden = isHidden
            userNameLabel.isHidden = isHidden
            coinButton.isHidden = isHidden

            collection?.isHidden = isHidden
            hot?.hotView.isHidden = hasHotSpot ? isHidden : true

            //  右侧
            shareButton.isHidden = isHidden
            commentButton.isHidden = isHidden
            likeButton.isHidden = isHidden
            fullScreen.isHidden = isHidden
            clear.isHidden = isHidden

            avatarButton.isHidden = isHidden
            addButton.isHidden = isHidden
        }
    }
    
    
    public init(superView: UIView) {
        self.superView = superView
        super.init()
        
        //  下部（从下到上）
        superView.addSubview(titleLabel)
        superView.addSubview(userNameLabel)
        superView.addSubview(coinButton)
        superView.addSubview(downloadButton)
        collection = ShortVideoCellCollection(superView: superView)
        hot = HotSpotView(superView: superView)
        
        //  右侧（从下到上）
        superView.addSubview(fullScreen)
        superView.addSubview(clear)
        superView.addSubview(shareButton)
        superView.addSubview(commentButton)
        superView.addSubview(likeButton)
        
        superView.addSubview(avatarButton)
        superView.addSubview(addButton)
        
        addTargetAndEvent()
    }
    
    
    var bounds:CGRect = .zero
    
    public func superViewDidLayout(bounds: CGRect) {
        if model?.videoItem != nil {    //  視頻
            layoutBottomViews_video(bounds)
        } else {                        //  廣告
            layoutBottomViews_ad(bounds)
        }
        self.bounds = bounds
        if model != nil {
            layoutRightViews(bounds, model:model!)
        }
    }
    
    //  下部
    func layoutBottomViews_ad(_ bounds: CGRect) {
        let tabbarFrame = (UIApplication.shared.delegate as! AppDelegate).tabbar!.frame
        
        var padding = UIEdgeInsets(top: 0, left: 12, bottom: 12, right: 12 + 50)
    
        var size = CGSize(width: 260, height: 40)
        downloadButton.frame = CGRect(x: padding.left, y: tabbarFrame.minY - size.height - padding.bottom,
                                 width: size.width, height: size.height)
        padding.bottom += size.height + 8
        
        //  titleLabel
        let titleLabelWidth = bounds.width - (padding.left + padding.right)
        if titleLabel.text == nil {
            titleLabel.text = ""
        }
        size = (titleLabel.text! as NSString).boundingRect(with: CGSize(width: titleLabelWidth, height: 0), options: .usesLineFragmentOrigin, attributes: [.font: titleLabel.font!], context: nil).size
        if titleLabel.numberOfLines > 0 {
            let maxHeight = titleLabel.font.lineHeight * CGFloat(titleLabel.numberOfLines)
            if size.height > maxHeight {
                size.height = maxHeight
            }
        }
        //titleLabel
        titleLabel.frame = CGRect(x: padding.left, y: tabbarFrame.minY - size.height - padding.bottom,
                                  width: titleLabelWidth, height: size.height)
        //  userNameLabel
        if userNameLabel.text == nil {
            userNameLabel.text = ""
        }
        size = (userNameLabel.text! as NSString).size(withAttributes: [.font: userNameLabel.font!])
        userNameLabel.frame = CGRect(x: padding.left, y: titleLabel.frame.minY - size.height - 6,
                                     width: size.width, height: size.height)
    }
    
    //  下部
    func layoutBottomViews_video(_ bounds: CGRect) {
        let tabbarFrame = (UIApplication.shared.delegate as! AppDelegate).tabbar!.frame
        //  边距
        hot?.superViewDidLayout(bounds: bounds, minY: tabbarFrame.minY)
        
        var padding = UIEdgeInsets(top: 0, left: 12, bottom: hasHotSpot ? 12 + 30 + 10 : 10, right: 12 + 50)
        
        //  coinButton
//        var size = (coinLabel.text! as NSString).size(withAttributes: [.font: coinLabel.font!])
        var size = CGSize(width: 25 * 2, height: 9 * 2)
        coinButton.frame = CGRect(x: padding.left, y: tabbarFrame.minY - size.height - padding.bottom,
                                 width: size.width, height: size.height)
        padding.bottom += coinButton.isHidden ? 0 : size.height + 8
        
        //  titleLabel
        let titleLabelWidth = bounds.width - (padding.left + padding.right)
        if titleLabel.text == nil {
            titleLabel.text = ""
        }
        size = (titleLabel.text! as NSString).boundingRect(with: CGSize(width: titleLabelWidth, height: 0), options: .usesLineFragmentOrigin, attributes: [.font: titleLabel.font!], context: nil).size
        if titleLabel.numberOfLines > 0 {
            let maxHeight = titleLabel.font.lineHeight * CGFloat(titleLabel.numberOfLines)
            if size.height > maxHeight {
                size.height = maxHeight
            }
        }
        //titleLabel
        titleLabel.frame = CGRect(x: padding.left, y: tabbarFrame.minY - size.height - padding.bottom,
                                  width: titleLabelWidth, height: size.height)
        //  userNameLabel
        if userNameLabel.text == nil {
            userNameLabel.text = ""
        }
        size = (userNameLabel.text! as NSString).size(withAttributes: [.font: userNameLabel.font!])
        userNameLabel.frame = CGRect(x: padding.left, y: titleLabel.frame.minY - size.height - 6,
                                     width: size.width, height: size.height)
        
        //  collection
        collection?.superViewDidLayout(bounds: bounds, minY: userNameLabel.frame.minY)
    }
    
    //  右部
    func layoutRightViews(_ bounds: CGRect, model:ShortVideoModel) {
        var isNeedFullScreen:Bool = false
        if model.videoItem != nil  {
            isNeedFullScreen = isHoritzonVideo(model)
        }
        let tabbarFrame = (UIApplication.shared.delegate as! AppDelegate).tabbar!.frame
        //  边距
        let padding = UIEdgeInsets(top: 0, left: 0, bottom: 12 + 10, right: 12)
        let size = CGSize(width: 45, height: 45)
        let left = bounds.width - size.width - padding.right
        //  竖直间距
        let space: CGFloat = 20
        
        let activityGap:CGFloat = model.hasActivity ?  60:0
        
        fullScreen.frame = isNeedFullScreen ?  CGRect(x: left, y: tabbarFrame.minY - size.height - padding.bottom - 20 - activityGap,
                                                      width: size.width, height: size.height):.zero
        
        clear.frame = isNeedFullScreen ?  CGRect(x: left, y: fullScreen.frame.minY - size.height - 8,
                                                 width: size.width, height: size.height):CGRect(x: left, y: tabbarFrame.minY - size.height - padding.bottom - 20 - activityGap,
                                                                                                width: size.width, height: size.height)
        //  shareButton
        shareButton.frame = CGRect(x: left, y: clear.frame.minY - size.height - space,
                                   width: size.width, height: size.height)
        
//        //  commentButton
        commentButton.frame = CGRect(x: left, y: shareButton.frame.minY - size.height - space,
                                     width: size.width, height: size.height)
//
        //  likeButton
        likeButton.frame = CGRect(x: left, y: commentButton.frame.minY - size.height - space,
                                  width: size.width, height: size.height)
        //  avatarButton
        avatarButton.frame = CGRect(x: left, y: likeButton.frame.minY - size.height - space - 15,
                                    width: size.width, height: size.height)
        
        //  addButton
        let addButtonSize = CGSize(width: 24, height: 24)
        addButton.frame = CGRect(x: avatarButton.frame.midX - addButtonSize.width / 2,
                                 y: avatarButton.frame.maxY - addButtonSize.height / 2,
                                 width: addButtonSize.width, height: addButtonSize.height)
    }
    
    //_______________________________________________________________________________________________________________
    // MARK: -  下部
    
    //  标题
    lazy var titleLabel: UILabel = {
        var label = UILabel()
        label.font = UIFont.pingFangRegular(14)
        label.textColor = .white
        label.numberOfLines = 2
//        GlobalSettings.addBlackShadow(label)
        return label
    }()
    
    //  用户名称
    lazy var userNameLabel: UILabel = {
        var label = UILabel()
        label.font = UIFont.pingFangMedium(15)
        label.textColor = .white
//        GlobalSettings.addBlackShadow(label)
        return label
    }()
    
    //  金币
    lazy var coinButton: UIButton = {
        var button = UIButton()
        button.setBackgroundImage(UIImage(named: "coin_pay"), for: .normal)
        return button
    }()
    
    lazy var downloadButton: UIButton = {
        var button = UIButton()
        button.setImage(UIImage(named: "sv_download"), for: .normal)
        return button
    }()
    
    //_______________________________________________________________________________________________________________
    // MARK: -  右侧
    
    
    //  全屏
    lazy var fullScreen: UIButton = {
        var button = UIButton()
        button.setImage(UIImage(named: "watch_fullscreen"), for: .normal)
        button.accessibilityIdentifier = "fullScreen"
        return button
    }()
    
    
    //  清屏
    lazy var clear: UIButton = {
        var button = UIButton()
        button.setImage(UIImage(named: "watch_clear_yes"), for: .normal)
        button.setImage(UIImage(named: "watch_clear_no"), for: .selected)
        button.accessibilityIdentifier = "clear"
        return button
    }()
    
    
    //  分享
    lazy var shareButton: UIButton = {
        var button = UIButton()
        button.setImage(UIImage(named: "ic_share"), for: .normal)
        let shareText = "下载".addShadow()
        shareText.addAttributes([.foregroundColor: UIColor.white], range: NSMakeRange(0, shareText.length));
        button.setAttributedTitle(shareText, for: .normal)
        button.titleLabel?.font = UIFont.pingFangRegular(11)
        button.verticalAlign = true
        button.verticalAlignSpacing = 4
//        GlobalSettings.addBlackShadow(button)
        return button
    }()
    
    //  评论
    lazy var commentButton: UIButton = {
        var button = UIButton()
        button.setImage(UIImage(named: "ic_comment"), for: .normal)
        button.titleLabel?.font = UIFont.pingFangRegular(11)
        button.verticalAlign = true
        button.verticalAlignSpacing = 4
//        GlobalSettings.addBlackShadow(button)
        return button
    }()
    
    //  点赞
    lazy var likeButton: UIButton = {
        var button = UIButton()
        button.setImage(UIImage(named: "ic_b_like_2"), for: .normal)
        button.setImage(UIImage(named: "ic_b_like_1"), for: .selected)
        button.titleLabel?.font = UIFont.pingFangRegular(11)
        button.verticalAlign = true
        button.verticalAlignSpacing = 4
//        GlobalSettings.addBlackShadow(button)
        return button
    }()
    
    //  头像
    lazy var avatarButton: UIButton = {
        var button = UIButton()
        button.setImage(ShortVideoCellSubviews.avatarImg, for: .normal)
        button.layer.cornerRadius = 25
//        button.layer.borderColor = UIColor.white.cgColor
//        button.layer.borderWidth = 1
        button.layer.masksToBounds = true
//        GlobalSettings.addBlackShadow(button)
        return button
    }()
    
    //  添加关注
    lazy var addButton: UIButton = {
        var button = UIButton()
        button.setImage(UIImage(named: "ic_follew_2"), for: .normal)
        //        button.setImage(UIImage(named: "ic_follew_1"), for: .selected)
        return button
    }()
}


//_______________________________________________________________________________________________________________
// MARK: - 添加事件

extension ShortVideoCellSubviews {
    func addTargetAndEvent() {
        shareButton.addTarget(self, action: #selector(didClickShare(_:)), for: .touchUpInside)
        commentButton.addTarget(self, action: #selector(didClickComment(_:)), for: .touchUpInside)
        likeButton.addTarget(self, action: #selector(didClickLike(_:)), for: .touchUpInside)
        avatarButton.addTarget(self, action: #selector(didClickAvatar(_:)), for: .touchUpInside)
        addButton.addTarget(self, action: #selector(didClickAdd(_:)), for: .touchUpInside)
        downloadButton.addTarget(self, action: #selector(didClickDownload(_:)), for: .touchUpInside)
        fullScreen.addTarget(self, action: #selector(didClickfull(_:)), for: .touchUpInside)
        clear.addTarget(self, action: #selector(didClickClear(_:)), for: .touchUpInside)

    }
    
    @objc func didClickfull(_ button: UIButton) {
        Animation.scaleBounce(button)
        self.delegate?.shortVideoCellSubviews(self, didClickFull: button)
    }
    
    @objc func didClickClear(_ button: UIButton) {
        Animation.scaleBounce(button)
        button.isSelected = !button.isSelected
        self.delegate?.shortVideoCellSubviews(self, didClickClear: button)
    }
    
    @objc func didClickShare(_ button: UIButton) {
        Animation.scaleBounce(button)
        self.delegate?.shortVideoCellSubviews(self, didClickShare: button)
    }
    
    @objc func didClickComment(_ button: UIButton) {
        Animation.scaleBounce(button)
        self.delegate?.shortVideoCellSubviews(self, didClickComment: button)
    }
    
    @objc func didClickLike(_ button: UIButton) {
        Animation.scaleBounce(button)
        self.delegate?.shortVideoCellSubviews(self, didClickLike: button)
        //  1秒内不能重复点击
        likeButton.removeTarget(self, action: #selector(didClickLike(_:)), for: .touchUpInside)
        DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
            self.likeButton.addTarget(self, action: #selector(self.didClickLike(_:)), for: .touchUpInside)
        }
    }
    
    @objc func didClickAvatar(_ button: UIButton) {
        guard let viewControllers = (UIApplication.shared.delegate as? AppDelegate)?.currentNavigationController?.viewControllers, !(viewControllers.last is ShortVideoListVC && viewControllers[viewControllers.count - 2] is UserMainPageVC) else { return }
        self.delegate?.shortVideoCellSubviews(self, didClickAvatar: button)        
    }
    
    @objc func didClickAdd(_ button: UIButton) {
        Animation.scaleBounce(button)
        self.delegate?.shortVideoCellSubviews(self, didClickAdd: button)
    }
    
    @objc func didClickDownload(_ button: UIButton) {
        self.delegate?.shortVideoCellSubviews(self, didClickDownload: button)
    }
}


//_______________________________________________________________________________________________________________
// MARK: - ShortVideoCellSubviewsDelegate

protocol ShortVideoCellSubviewsDelegate: NSObjectProtocol {
    
    //  全屏
    func shortVideoCellSubviews(_ subViews: ShortVideoCellSubviews, didClickFull button: UIButton)
    //  清屏
    func shortVideoCellSubviews(_ subViews: ShortVideoCellSubviews, didClickClear button: UIButton)
    //  分享
    func shortVideoCellSubviews(_ subViews: ShortVideoCellSubviews, didClickShare button: UIButton)
    //  评论
    func shortVideoCellSubviews(_ subViews: ShortVideoCellSubviews, didClickComment button: UIButton)
    //  点赞
    func shortVideoCellSubviews(_ subViews: ShortVideoCellSubviews, didClickLike button: UIButton)
    //  头像
    func shortVideoCellSubviews(_ subViews: ShortVideoCellSubviews, didClickAvatar button: UIButton)
    //  添加关注
    func shortVideoCellSubviews(_ subViews: ShortVideoCellSubviews, didClickAdd button: UIButton)
    //  下载
    func shortVideoCellSubviews(_ subViews: ShortVideoCellSubviews, didClickDownload button: UIButton)
}
