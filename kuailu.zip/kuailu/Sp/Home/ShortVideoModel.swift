//
//  VideoTestModel.swift
//  ShortVideo
//
//  Created by mac on 2019/12/7.
//  Copyright © 2019 mac. All rights reserved.
//

import UIKit
import AVFoundation

/// 用作统计分析
enum ShortVideoWatchType: Int {
    case free   = 1     //  免費次數
    case vip    = 2     //  vip觀看
    case coin   = 3     //  金幣觀看
}

/// 可看标记
enum ShortVideoResponseWatchType: Int {
    case none       = 0     //  還沒有響應
    case error      = 1     //  網絡出錯
    case canWatch   = 2     //  可以觀看
    case noTimes    = 3     //  次數不夠
    case needPay    = 4     //  需要付費
    case onlyVip    = 5     //vip专享
}

class ShortVideoModel: NSObject {
    
    var videoItem: VideoItem?
    var videoAd: AdvertiseResp?
    var playerItem: AVPlayerItem?
    
    /// 是否有打折活动 这里字段用来区分打折活动 右下角打折问题
    var hasActivity:Bool = false
    
    /// 清屏模式
    var isClearMode = false
    
    //  是否显示过封面。（暂时没用到）
    var didShowCover = false
    
    //  播放权限
    var responseWatchType: ShortVideoResponseWatchType = .none
    
    var error: Error?       //  responseWatchType = .error 時才有值
    
    //  用作统计分析
    var watchType: ShortVideoWatchType = .free
    
    /// 是否播放结束。播放j结束后如果快退回某一秒 可以不用记录
    var playEnded:Bool = false
    
    var lastPlayTime: CMTime?
    
    var hots:[HotDailyItem]?
    
    /// 持有的剧集
    var serialItems:[VideoItem] = [VideoItem]()
    
    var isdynamic:Bool = false      //  動態
    
    //  播放前的判断
    func playPrediction() {
        self.responseWatchType = .none
        guard let item = self.videoItem else {
            return
        }
        let req = CheckVideoAvaliableReq()
        req.videoId = item.videoId
        //  检查是否可看
        Session.request(req) { (error, resp) in
            guard error == nil else {
                self.responseWatchType = .error
                self.error = error
                return
            }
            if resp is CheckVideoAvaliable {
                let res = resp as! CheckVideoAvaliable
                if res.canWatch {   //  ======  可以觀看
                    self.responseWatchType = .canWatch
                    self.watchType = .free
                    // 取当前用户账户信息 当前用户是否是vip
                    if let currentUser = NetDefaults.userInfo, currentUser.freeWatches == -1 {
                        self.watchType = .vip
                    }
                } else {            //  ======  不可以觀看
                    if res.reasonType == .notime {              //  ------  次數不夠彈框
                        self.responseWatchType = .noTimes
                    } else if res.reasonType == .needPay {      //  ------  需要付費
                        self.responseWatchType = .needPay
                    }
                }
            }
        }
    }
    
    /// 上传观影记录
    func uploadWatchRecord(_ seconds:Int) {
        if self.responseWatchType == .canWatch {
            print(">>>>>>統計觀看時長!")
            let videoId = self.videoItem!.videoId
            let req = AddStatisticsTimesReq()
            req.videoId = videoId
            req.progress = seconds
            req.lookType = self.watchType.rawValue
            Session.request(req) { (error, resp) in
                guard error == nil else {
                    return
                }
            }
        }
    }
}



