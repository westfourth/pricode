//
//  MarqueeView.swift
//  Sp
//
//  Created by mac on 2020/4/6.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

@objc
protocol MarqueeViewDelegate:NSObjectProtocol {
    @objc optional func mqrqueeView(_ marqueeView:MarqueeView,didSelectCellAt index:Int) -> Void
}

protocol MarqueeViewDataSource:NSObjectProtocol {
    /// MARK: - 多少条数据
    func numberOfItems(_ marqueeView:MarqueeView) -> Int
    /// MARK: - 每条的attributedString
    func marqueeView(_ marqueeView:MarqueeView, cellForItemAt index:Int) -> NSAttributedString
}

class MarqueeView: UIView {
    /// MARK: - 当前idx
    var curtIdx:Int = 0
    
    weak var delegate:MarqueeViewDelegate?
    
    weak var dataSource:MarqueeViewDataSource?
    
    /// MARK: - 时钟
    var timer: Timer?
    
    var automaticSlidingInterval: CGFloat = 3.0 {
        didSet{
            
        }
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.setUI()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    lazy var label1:UILabel = {
        let label = UILabel()
        label.textColor = RGB(255, 91, 111)
        label.font = FONT(12)
        return label
    }()
    
    lazy var label2:UILabel = {
        let label = UILabel()
        label.textColor = RGB(255, 91, 111)
        label.font = FONT(12)
        return label
    }()
    
    func setUI() {
        self.addSubview(label1)
        self.addSubview(label2)
        label1.frame = CGRect.init(x: 0, y: 0, width: self.frame.size.width, height: self.frame.size.height)
        label2.frame = CGRect.init(x: 0, y: self.frame.size.height, width: self.frame.size.width, height: self.frame.size.height)
        
        let tapAction:UITapGestureRecognizer = UITapGestureRecognizer.init(target: self, action: #selector(tapAction(_:)))
        self.addGestureRecognizer(tapAction)
    }
    
    @objc func tapAction(_ tap:UITapGestureRecognizer){
        if let _ = delegate {
            delegate!.mqrqueeView!(self, didSelectCellAt: curtIdx)
        }
    }
}

extension MarqueeView{
    func cancelTimer() {
        guard self.timer != nil else {
            return
        }
        self.timer!.invalidate()
        self.timer = nil
    }
    func startTimer(){
        self.timer = Timer.scheduledTimer(timeInterval: TimeInterval(self.automaticSlidingInterval),
                                          target: self,
                                          selector: #selector(self.animationAction(_:)),
                                          userInfo: nil, repeats: true)
    }
    
    func reload() {
        self.cancelTimer()
        self.resetAction(0)
    }
    
    func resetAction(_ startInx:Int) {
        let counts = dataSource!.numberOfItems(self)
        label1.attributedText = dataSource!.marqueeView(self, cellForItemAt: startInx)
        guard counts > startInx + 1  else {
            return
        }
        curtIdx = startInx + 1
        label2.attributedText = dataSource!.marqueeView(self, cellForItemAt: startInx + 1)
        self.startTimer()
    }
    
    @objc func animationAction(_ sender:Timer){
        UIView.animate(withDuration: 0.75, animations: {
            let oneOriY = self.label1.frame.origin.y
            let twoOriY = self.label2.frame.origin.y
            if oneOriY > twoOriY {
                var rectOne:CGRect = self.label2.frame
                rectOne.origin.y = -rectOne.size.height
                self.label2.frame = rectOne
                var rectTwo:CGRect = self.label1.frame
                rectTwo.origin.y = 0
                self.label1.frame = rectTwo
            } else {
                var rectOne:CGRect = self.label1.frame
                rectOne.origin.y = -rectOne.size.height
                self.label1.frame = rectOne
                var rectTwo:CGRect = self.label2.frame
                rectTwo.origin.y = 0
                self.label2.frame = rectTwo
            }
        }) { (true) in
            let oneOriY = self.label1.frame.origin.y
            let twoOriY = self.label2.frame.origin.y
            var l :UILabel = self.label1
            if oneOriY < twoOriY {
                l = self.label1
            } else {
                l = self.label2
            }
            var rectOne:CGRect = l.frame
            rectOne.origin.y = rectOne.size.height
            l.frame = rectOne
            guard self.dataSource != nil else {return}
            if (self.curtIdx + 1 < self.dataSource!.numberOfItems(self)) {
                l.attributedText = self.dataSource?.marqueeView(self, cellForItemAt: self.curtIdx + 1)
                self.curtIdx = self.curtIdx + 1
            } else if (self.curtIdx + 1 == self.dataSource!.numberOfItems(self)) {
                l.attributedText = self.dataSource?.marqueeView(self, cellForItemAt: 0)
                self.curtIdx = 0
            }
        }
    }
}
