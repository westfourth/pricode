//
//  TabBarController.swift
//  Sp
//
//  Created by mac on 2020/3/16.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit
import AVKit
import FileUpLoader
import GCDWebServers
import M3U8
import IQKeyboardManagerSwift
import Flurry_iOS_SDK
import CoreLocation
class TabBarController: UITabBarController {
    var webServer = GCDWebServer()
    let locationManager = CLLocationManager()

    override func viewDidLoad() {
        super.viewDidLoad()
        //  清理视频缓存
        clearCache()
        //  启动本地伺服器
        startLocalServer()
        //  启动统计
        startFlurry()
        //  状态显示
        setupScrollViewState()
        
        //  忽略静音键
        try? AVAudioSession.sharedInstance().setCategory(.playback)
        
        //  键盘处理
        IQKeyboardManager.shared.enable = true
        IQKeyboardManager.shared.shouldResignOnTouchOutside = true
        
        self.delegate = self
        
        // 1001 token解析错误的情况
        NotificationCenter.default.addObserver(self, selector:#selector(self.userLogin) , name:.reLogin , object: nil)
        //  账号被踢
        NotificationCenter.default.addObserver(self, selector:#selector(self.loginKickedOutAction) , name:.loginKickedout , object: nil)
        // 刷新用户信息
        NotificationCenter.default.addObserver(self, selector:#selector(self.refreshInfoAction) , name:.refreshInfo , object: nil)
        
        // 播放页面清屏模式
        NotificationCenter.default.addObserver(self, selector: #selector(clearModeChangeAction(noti:)), name:shortVideoClearModeDidChange , object: nil)
        
        locationAction()
    }
    
    
    func locationAction() {
        if CLLocationManager.locationServicesEnabled() {
            locationManager.delegate = self
            locationManager.desiredAccuracy = kCLLocationAccuracyNearestTenMeters
            locationManager.distanceFilter = 50
            locationManager.requestWhenInUseAuthorization()
            locationManager.startUpdatingLocation()
        }
    }
    
    
    @objc func clearModeChangeAction(noti:Notification) {
        if let clear = noti.object as? Bool {
            UIView.animate(withDuration: 0.1) {
                self.tabBar.alpha = clear ? 0:1.0
            } completion: { (finished) in
                self.tabBar.isHidden = clear
            }
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
    }
    
    
    //  清理视频缓存
    func clearCache() {
        let size = M3U8CacheManager.size()
        if size > 2 << 30 {     //  2GB
            M3U8CacheManager.clear()
        }
    }
    
    //  启动本地伺服器
    func startLocalServer() {
        GCDWebServer.setLogLevel(4)
        M3U8Cache.addHandler(for: webServer, port: Int(M3U8_SERVER_PORT))
        webServer.start(withPort: UInt(M3U8_SERVER_PORT), bonjourName: nil)
        //
        TabBarController.saveKey()
    }
    
    //  将key保存在temp目录下
    class func saveKey() {
        let path = Bundle.main.path(forResource: "key", ofType: nil)
        let dir = NSTemporaryDirectory()
        let destPath = dir + "key";
        try? FileManager.default.copyItem(atPath: path!, toPath: destPath)
    }
    
    //  启动统计
    func startFlurry() {
        #if DEBUG
        return
        #endif
        let v = Bundle.main.infoDictionary!["VestBag"] as! NSString
        let range = v.range(of: "-")
        let version = v.substring(from: range.location + 1)
        let builder = FlurrySessionBuilder
            .init()
            .withCrashReporting(true)
            .withLogLevel(FlurryLogLevelAll)
            .withAppVersion(version)
        Flurry.startSession("S46BVY38ZGJJWX78FH4G", with: builder)
    }
    
    /// 状态显示
    func setupScrollViewState() {
        UIScrollView.setClass(ScrollStateEmptyView.self, for: .empty)
        UIScrollView.setClass(ScrollStateFailedView.self, for: .failed)
        UIScrollView.setClass(ScrollStateLoadingView.self, for: .loading)
    }
    
    //  建立UITabBarController
    class func createTabbarController() -> TabBarController {
        let n = class_getName(self)
        let s = String(cString: n)
        let moduleName = s.components(separatedBy: ".").first!
        
        let path = Bundle.main.path(forResource: "TabBar", ofType: "plist")
        let array = NSArray(contentsOfFile: path!) as! [[String: String]]
        
        let tabBarController = TabBarController()
        var controllers = [UINavigationController]()
        
        for dict: [String: String] in array {
            let controllerName = moduleName + "." + dict["controller"]!
            let controllerClass = NSClassFromString(controllerName) as! UIViewController.Type
            let controller = controllerClass.init()
            
            let title = dict["title"]
            let image = UIImage(named: dict["image"]!)?.withRenderingMode(.alwaysOriginal)
            let selectedImage = UIImage(named: dict["selected_image"]!)?.withRenderingMode(.alwaysOriginal)
            
            let item = UITabBarItem(title: title, image: image, selectedImage: selectedImage)
//            item.titlePositionAdjustment = UIOffset(horizontal: 0, vertical: -14)
            
            let navVC = UINavigationController(rootViewController: controller)
            navVC.tabBarItem = item
            controllers.append(navVC)
        }
        tabBarController.viewControllers = controllers
        return tabBarController
    }

     // 上传操作
//    @objc func uploadAction() {
//         let tabBarController = UIApplication.shared.keyWindow!.rootViewController as! UITabBarController
//         let navigationController = tabBarController.selectedViewController as! UINavigationController
//         let uploadAlertVC = UploadAlertVC()
//         uploadAlertVC.delegate = self
//         navigationController.present(uploadAlertVC, animated: true, completion: nil)
//     }
    
    @objc func uploadAction() {
        let tabBarController = UIApplication.shared.keyWindow!.rootViewController as! UITabBarController
        let navigationController = tabBarController.selectedViewController as! UINavigationController
        let vc = UploadVC()
        let navVC = UINavigationController(rootViewController: vc)
        navVC.modalPresentationStyle = .fullScreen
        navigationController.present(navVC, animated: true, completion: nil)
    }
    
    /// 登陆
    @objc func userLogin() {
        Session.request(TravelerReq()) { (error, resp) in  }
    }
    
    //  异地登陆被t的情况处理
    @objc func loginKickedOutAction() {
        Alert.showComfirmAlert(parentView: self.view!,
                               contentText:"有另外一臺裝置登錄了您的賬號，請使用手機號重新進行登入!") {
                                let vc = LoginVC()
                                vc.isFromKickedOut = true
                                let navVC = UINavigationController(rootViewController: vc)
                                navVC.modalPresentationStyle = .fullScreen
                                self.present(navVC, animated: true, completion: nil)
        }
    }
    
    //刷新用户信息
    @objc func refreshInfoAction() {
        Session.request(FetchUserInfoReq()) { (error, resp) in}
    }
}


extension TabBarController {
    // 当前是否展示ShortVideoListVC
    func currentDisplayShortVideo() -> Bool {
        let homeVC = (selectedViewController as? UINavigationController)?.viewControllers.first
        guard homeVC is Home2VC else { return false }
        let vc = (homeVC as! Home2VC).pageViewController.viewControllers?.first
        let b = vc is ShortVideoListVC
        return b
    }
}

extension TabBarController: UITabBarControllerDelegate {
//    func tabBarController(_ tabBarController: UITabBarController, shouldSelect viewController: UIViewController) -> Bool {
//        let controller = ((viewController as! UINavigationController).topViewController)!
//        if type(of: controller).description().contains("PublishVC") {
//            print(">>> 處理")
//            uploadAction()
//            return false
//        }
//        return true;
//    }
    
}



extension TabBarController:CLLocationManagerDelegate {
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        if !locations.isEmpty {
            let l = locations.last!
            CLGeocoder().reverseGeocodeLocation(l) { (places, e) in
                guard let places = places,!places.isEmpty else {
                    return
                }
                let p = places.first!
                if let city = p.locality {
                    Defaults.officialCurrentCity = city
                }
            }
            manager.stopUpdatingLocation()
        }
    }
    
    func locationManager(manager: CLLocationManager, didFailWithError error: NSError) {
        mm_showToast("定位出錯",type: .failed)
    }
}


extension TabBarController:UIImagePickerControllerDelegate,UINavigationControllerDelegate {
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        GlobalSettings.resetNaviBarAttribute()
        picker.dismiss(animated: true, completion: nil)
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        GlobalSettings.resetNaviBarAttribute()
        picker.dismiss(animated: true, completion: nil)
        if picker.mediaTypes == ["public.movie"] {
            //上传视频
            guard let videoURL = info[UIImagePickerController.InfoKey.mediaURL] as? URL   else {
                return
            }
            /// 保存拍摄视频
            if picker.sourceType == .camera {
                let canSaveVideo =  UIVideoAtPathIsCompatibleWithSavedPhotosAlbum(videoURL.path)
                if canSaveVideo {
                    UISaveVideoAtPathToSavedPhotosAlbum(videoURL.path, self, #selector(self.video(video:didFinishSavingWithError:contextInfo:)), nil)
                }
            }
            
            guard FileItem.size(with: videoURL) <= (UploadConfig.shared.info.size * 1024 * 1024)  else {
                mm_showToast("視頻大小最大為\(UploadConfig.shared.info.size)M,請重新選擇!", duration: 2.0)
                return
            }
            let asset = AVURLAsset(url: videoURL, options: [AVURLAssetPreferPreciseDurationAndTimingKey:false])
            let seconds:Int = Int((Double(asset.duration.value)) / (Double(asset.duration.timescale)))
            
            guard seconds >= UploadConfig.shared.info.minTimes else {
                mm_showToast("最低視頻時長為\(UploadConfig.shared.info.minTimes)秒!", duration: 2.0)
                return
            }
            
            guard seconds <= UploadConfig.shared.info.maxTimes else {
                mm_showToast("最大視頻時長為\(UploadConfig.shared.info.maxTimes)秒!", duration: 2.0)
                return
            }
            
            let VC = UploadVideoVC()
            VC.item = FileItem(url: videoURL, fileIdentifier: videoURL.absoluteString)
            VC.videoSeconds = seconds
            VC.hidesBottomBarWhenPushed = true
            let rootVC = (UIApplication.shared.keyWindow!.rootViewController ) as! UITabBarController
            let navigationController = rootVC.selectedViewController as! UINavigationController
            navigationController.pushViewController(VC, animated: true)
        }
    }
    
    @objc func video(video:String, didFinishSavingWithError error:Error?, contextInfo:UnsafeMutableRawPointer) {
        if error == nil {
//            let VC = UploadVC()
//            VC.item = FileItem(url: videoURL, fileIdentifier: video)
//            VC.videoSeconds = seconds
//            VC.hidesBottomBarWhenPushed = true
//            let rootVC = (UIApplication.shared.keyWindow!.rootViewController ) as! UITabBarController
//            let navigationController = rootVC.selectedViewController as! UINavigationController
//            navigationController.pushViewController(VC, animated: true)
        }
    }
}


extension TabBarController:UploadAlertVCDelegate {
    func uploadViewControllerTakeVideoAction(uploadViewController: UploadAlertVC) {
        
        guard UploadConfig.shared.info.allow else {
            mm_showToast("系統維護中，暫不能上傳視頻!")
            return
        }
        
        guard UIImagePickerController.isSourceTypeAvailable(UIImagePickerController.SourceType.camera) else {
            mm_showToast("相機不可用!")
            return
        }
        let picker = UIImagePickerController()
        picker.modalPresentationStyle = .fullScreen
        if #available(iOS 13.0, *) {
            picker.isModalInPresentation = true
        }
        GlobalSettings.setImagePickerNatiBarAttribute()
        picker.allowsEditing = true
        picker.sourceType = .camera
        picker.delegate = self
        picker.mediaTypes = ["public.movie"]
//        picker.cameraFlashMode = .off
        picker.videoQuality = .typeMedium
        picker.videoMaximumDuration = TimeInterval(UploadConfig.shared.info.maxTimes)
        let rootVC = (UIApplication.shared.keyWindow!.rootViewController ) as! UITabBarController
        let navigationController = rootVC.selectedViewController as! UINavigationController
        navigationController.present(picker, animated: true, completion: nil)
    }
    
    #if DEBUG
    override func motionBegan(_ motion: UIEvent.EventSubtype, with event: UIEvent?) {
        present(DebugVC(), animated: true, completion: nil)
    }
    #endif
}

