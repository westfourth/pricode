//
//  TopActressCell.swift
//  Sp
//
//  Created by mac on 2020/11/10.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class TopActressCell: UITableViewCell {
    
    static let viewHeight: CGFloat = {
        return TopActressHeaderView.viewHeight + TopActressCell.collectionViewHeight + TopActressCell.marginBottom
    }()
    
    private static let itemSize: CGSize = {
        return FeaturedTopicVerticalSubCell.itemSize
    }()
    
    private static let collectionViewHeight: CGFloat = {
        return TopActressCell.itemSize.height
    }()
    
    private static let marginBottom: CGFloat = 10
    
    private lazy var headerView: TopActressHeaderView = {
        let view = TopActressHeaderView()
        view.addGestureRecognizer(UITapGestureRecognizer(target: self, action:#selector(onPosterImgViewTap)))
        return view
    }()
    
    private lazy var collectionView: UICollectionView = {
        let layout = UICollectionViewFlowLayout()
        layout.minimumLineSpacing = 8
        layout.minimumInteritemSpacing = 0
        layout.scrollDirection = .horizontal
        layout.itemSize = TopActressCell.itemSize
        let cv = UICollectionView(frame: .zero, collectionViewLayout: layout)
        cv.register(FeaturedTopicVerticalSubCell.self, forCellWithReuseIdentifier: "FeaturedTopicVerticalSubCell")
        cv.showsVerticalScrollIndicator = false
        cv.showsHorizontalScrollIndicator = false
        cv.bouncesZoom = false
        cv.backgroundColor = .none
        cv.delegate = self
        cv.dataSource = self
        return cv
    }()
    
    private lazy var splitLine: UIView = {
        let view = UIView()
        view.backgroundColor = rgb(0x2A2A2A)
        return view
    }()
    
    private var listData: [VideoItem] = []
    
    private var isInitState: Bool = true
    
    var dataModel: ActressSubListResp? {
        didSet {
            guard isInitState else { return }
            isInitState = false
            guard let item = dataModel, !item.allContentList.isEmpty else { return }
            let contentItem = item.allContentList[0]
            headerView.dataModel = contentItem
            guard !contentItem.videoList.isEmpty else { return }
            listData = contentItem.videoList
            collectionView.reloadData()
        }
    }
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        backgroundColor = .none
        selectionStyle = .none
        renderView()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func renderView() {
        contentView.addSubview(headerView)
        contentView.addSubview(collectionView)
        contentView.addSubview(splitLine)
        
        headerView.snp.makeConstraints { (make) in
            make.top.left.right.equalToSuperview()
            make.height.equalTo(TopActressHeaderView.viewHeight)
        }
        
        collectionView.snp.makeConstraints { (make) in
            make.top.equalTo(headerView.snp.bottom)
            make.left.right.equalToSuperview()
            make.height.equalTo(TopActressCell.collectionViewHeight)
        }
        
        splitLine.snp.makeConstraints { (make) in
            make.left.right.bottom.equalToSuperview()
            make.height.equalTo(0.5)
        }
        
    }
    
    @objc private func onPosterImgViewTap() {
        guard let navigationController = (UIApplication.shared.delegate as? AppDelegate)?.currentNavigationController, let item = dataModel, !item.allContentList.isEmpty else { return }
        let actressDetailsVC = ActressDetailsVC()
        actressDetailsVC.contentId = item.allContentList[0].contentId
        navigationController.show(actressDetailsVC, sender: nil)
    }
}

extension TopActressCell: UICollectionViewDataSource, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return listData.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "FeaturedTopicVerticalSubCell", for: indexPath) as! FeaturedTopicVerticalSubCell
        cell.dataModel = listData[indexPath.row]
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        guard let navigationController = (UIApplication.shared.delegate as? AppDelegate)?.currentNavigationController else { return }
        let vc = PlayerController()
        vc.videoId = listData[indexPath.row].videoId
        navigationController.pushViewController(vc, animated: true)
    }
}

