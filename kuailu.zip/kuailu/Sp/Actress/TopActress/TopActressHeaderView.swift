//
//  TopActressProfileView.swift
//  Sp
//
//  Created by mac on 2020/11/10.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class TopActressHeaderView: UIView {
    
    static let viewHeight: CGFloat = 96
    
    private static let avatarSize: CGFloat = 60
    
    private static let moreBtnImg: UIImage? = {
        return UIImage(named: "top_actress_more_btn_icon")
    }()
    
    private lazy var avatarImgView: UIImageView = {
        let imgView = UIImageView()
        imgView.contentMode = .scaleAspectFill
        imgView.layer.masksToBounds = true
        imgView.layer.cornerRadius = TopActressHeaderView.avatarSize / 2
        return imgView
    }()
    
    private lazy var nicknameLabel: UILabel = {
        let label = UILabel()
        label.textColor = .white
        label.font = font(18, .medium)
        return label
    }()
    
    private lazy var worksNumLabel: UILabel = {
        let label = UILabel()
        label.textColor = .white
        label.font = font(14)
        return label
    }()
    
    private lazy var moreBtn: UIButton = {
        let btn = UIButton()
        btn.setTitle("更多", for: .normal)
        btn.setTitleColor(rgb(0xA8A8A8), for: .normal)
        btn.titleLabel?.font = font(12)
        btn.setImage(TopActressHeaderView.moreBtnImg, for: .normal)
        btn.isUserInteractionEnabled = false
        return btn
    }()
    
    var dataModel: ContentItem? {
        didSet {
            guard let item = dataModel else { return }
            avatarImgView.kf.setImage(with: item.headImg?.column3, placeholder: ClassyScrollListRecomMoreExcitingSubCell.defaultImg, options: ClassyScrollListRecomMoreExcitingSubCell.animationOption)
            nicknameLabel.text = item.contentName
            worksNumLabel.text = "\(item.videoNum)部影片"
        }
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        renderView()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func renderView() {
        addSubview(avatarImgView)
        addSubview(nicknameLabel)
        addSubview(worksNumLabel)
        addSubview(moreBtn)
        
        avatarImgView.snp.makeConstraints { (make) in
            make.left.equalToSuperview().inset(13)
            make.centerY.equalToSuperview()
            make.size.equalTo(TopActressHeaderView.avatarSize)
        }
        
        nicknameLabel.snp.makeConstraints { (make) in
            make.left.equalTo(avatarImgView.snp.right).offset(14)
            make.top.equalTo(avatarImgView).offset(5)
            make.right.equalToSuperview().inset(60)
        }
        
        worksNumLabel.snp.makeConstraints { (make) in
            make.left.equalTo(nicknameLabel)
            make.right.equalToSuperview().inset(12)
            make.bottom.equalTo(avatarImgView).offset(-5)
        }
        
        moreBtn.snp.makeConstraints { (make) in
            make.centerY.equalTo(nicknameLabel)
            make.right.equalToSuperview().inset(12)
            make.width.equalTo(44)
        }
        
        moreBtn.imagePosition(imageStyle: .right, spacing: 4)
    }
}
