//
//  ActressVC.swift
//  Sp
//
//  Created by mac on 2020/11/10.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class ActressVC: UIViewController {
    
    private lazy var headerView: ActressHeaderView = {
        return ActressHeaderView()
    }()
    
    private lazy var tableView: UITableView = {
        let tableView = UITableView(frame: .zero, style: .grouped)
        tableView.delegate = self
        tableView.dataSource = self
        tableView.backgroundColor = .none
        tableView.separatorStyle = .none
        tableView.contentInsetAdjustmentBehavior = .never
        tableView.showsHorizontalScrollIndicator = false
        tableView.contentInset = UIEdgeInsets(top: 0, left: 0, bottom: 20, right: 0)
        return tableView
    }()
    
    private var headerViewHeight: CGFloat = ActressHeaderView.minViewHeight
    
    private var listData: [ActressSubListResp] = []
    
    private var activeIndex: Int = 0
    
    private var banners: [AdvertiseResp] = []
    
    var categoryData: AVRecommendSpecialAreaResp? {
        didSet {
            guard let item = categoryData else { return }
            navigationItem.title = item.areaName
            banners = AdManager.shared.AVPopularityBanners
            if !banners.isEmpty {
                headerView.bannerListData = banners
                headerViewHeight = ActressHeaderView.maxViewHeight
                tableView.reloadData()
            }
            getList()
        }
    }
    
    override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: Bundle?) {
        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
        hidesBottomBarWhenPushed = true
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationController?.navigationBar.isTranslucent = false
        view.backgroundColor = RGB(0x141516)
        if #available(iOS 11.0, *) {
        } else {
            automaticallyAdjustsScrollViewInsets = false
        }
        view.addSubview(tableView)
        tableView.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.navigationBar.isTranslucent = false
        navigationController?.navigationBar.barTintColor = RGB(0x141516)
    }
    
    private func getList() {
        Alert.showLoading(parentView: self.view)
        let req = ActressSubListReq()
        Session.request(req) { [weak self] (error, resp) in
            Alert.hideLoading()
            guard let `self` = self else { return }
            guard error == nil, let resData = resp as? ActressSubListResp, !resData.allContentList.isEmpty || !resData.featuredList.isEmpty else { return }
            
            var tempList: [ActressSubListResp] = []
            
            resData.featuredList.forEach {
                let actressSubListResp = ActressSubListResp()
                actressSubListResp.type = .topActressVertical
                actressSubListResp.allContentList.append($0)
                tempList.append(actressSubListResp)
            }
            
            if !resData.allContentList.isEmpty {
                let actressSubListResp = ActressSubListResp()
                actressSubListResp.type = .moreActress
                actressSubListResp.allContentList = resData.allContentList
                tempList.append(actressSubListResp)
            }
            
            self.listData = tempList
            for i in 0..<tempList.count {
                switch tempList[i].type {
                case .topActressVertical:
                    self.tableView.register(TopActressCell.self, forCellReuseIdentifier: "TopActressCell\(i)")
                default:
                    self.tableView.register(MoreActressCell.self, forCellReuseIdentifier: "MoreActressCell\(i)")
                }
            }
            self.tableView.reloadData()
        }
    }
    
    private func getMoreActressCellHegiht(section: Int) -> CGFloat {
        let totalNum = listData[section].allContentList.count
        let itemRowNumber = totalNum % 4 == 0 ? totalNum / 4 : totalNum / 4 + 1
        return (MoreActressSubCell.viewHeight + MoreActressCell.itemLineSpacing) * CGFloat(itemRowNumber) - MoreActressCell.itemLineSpacing
    }
    
}

extension ActressVC: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return listData.count
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return headerViewHeight
    }
    
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return .leastNonzeroMagnitude
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        return headerView
    }
    
    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        return nil
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        let type = listData[indexPath.row].type
        return type == .topActressVertical ? TopActressCell.viewHeight : MoreActressCell.minViewHeight + getMoreActressCellHegiht(section: indexPath.row)
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let row = indexPath.row
        let currentItem = listData[row]
        switch currentItem.type {
        case .topActressVertical:
            let cell = tableView.dequeueReusableCell(withIdentifier: "TopActressCell\(row)", for: indexPath) as! TopActressCell
            cell.dataModel = currentItem
            return cell
        default:
            let cell = tableView.dequeueReusableCell(withIdentifier: "MoreActressCell\(row)", for: indexPath) as! MoreActressCell
            cell.dataModel = currentItem
            return cell
        }
    }
}

