//
//  MoreActressCell.swift
//  Sp
//
//  Created by mac on 2020/11/10.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class MoreActressCell: UITableViewCell {
    
    static let columnNum: CGFloat = 4
    
    static let itemLineSpacing: CGFloat = 16
    
    static let itemInteritemSpacing: CGFloat = 30
    
    static let itemEdgeInsetMargin: CGFloat = 15
    
    static let minViewHeight: CGFloat = MoreActressHeaderView.viewHeight
    
    private static let itemSize: CGSize = {
        return CGSize(width: MoreActressSubCell.viewWidth, height: MoreActressSubCell.viewHeight)
    }()
    
    private lazy var headerView: MoreActressHeaderView = {
        return MoreActressHeaderView()
    }()
    
    private lazy var collectionView: UICollectionView = {
        let layout = UICollectionViewFlowLayout()
        layout.itemSize = MoreActressCell.itemSize
        layout.minimumLineSpacing = MoreActressCell.itemLineSpacing
        layout.minimumInteritemSpacing = MoreActressCell.itemInteritemSpacing
        layout.sectionInset = UIEdgeInsets(top: 0, left: MoreActressCell.itemEdgeInsetMargin, bottom: 0, right: MoreActressCell.itemEdgeInsetMargin)
        let cv = UICollectionView(frame: .zero, collectionViewLayout: layout)
        cv.register(MoreActressSubCell.self, forCellWithReuseIdentifier: "MoreActressSubCell")
        cv.backgroundColor = .none
        cv.bouncesZoom = false
        cv.bounces = false
        cv.delegate = self
        cv.dataSource = self
        cv.isScrollEnabled = false
        cv.showsVerticalScrollIndicator = false
        cv.showsHorizontalScrollIndicator = false
        return cv
    }()
    
    private var listData: [ContentItem] = []
    
    private var isInitState: Bool = true
    
    var dataModel: ActressSubListResp? {
        didSet {
            guard isInitState else { return }
            isInitState = false
            guard let item = dataModel, !item.allContentList.isEmpty else { return }
            listData = item.allContentList
            collectionView.reloadData()
        }
    }
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        backgroundColor = .none
        selectionStyle = .none
        contentView.addSubview(headerView)
        contentView.addSubview(collectionView)
        
        headerView.snp.makeConstraints { (make) in
            make.top.left.right.equalToSuperview()
            make.height.equalTo(MoreActressHeaderView.viewHeight)
        }
        
        collectionView.snp.makeConstraints { (make) in
            make.top.equalTo(headerView.snp.bottom)
            make.left.right.bottom.equalToSuperview()
        }
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}

extension MoreActressCell: UICollectionViewDelegate, UICollectionViewDataSource {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return listData.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "MoreActressSubCell", for: indexPath) as! MoreActressSubCell
        cell.dataModel = listData[indexPath.row]
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        guard let navigationController = (UIApplication.shared.delegate as? AppDelegate)?.currentNavigationController else { return }
        let actressDetailsVC = ActressDetailsVC()
        actressDetailsVC.contentId = listData[indexPath.row].contentId
        navigationController.show(actressDetailsVC, sender: nil)
    }
}
