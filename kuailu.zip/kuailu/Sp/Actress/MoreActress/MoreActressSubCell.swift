//
//  MoreActressSubCell.swift
//  Sp
//
//  Created by mac on 2020/11/10.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class MoreActressSubCell: UICollectionViewCell {
    
    static let viewHeight: CGFloat = {
        return MoreActressSubCell.viewWidth + MoreActressSubCell.titleLabelMarginTop + MoreActressSubCell.titleLabelHeight
    }()
    
    static let viewWidth: CGFloat = {
        return (UIScreen.main.bounds.width - MoreActressCell.itemEdgeInsetMargin * 2 - MoreActressCell.itemInteritemSpacing * (MoreActressCell.columnNum - 1)) / MoreActressCell.columnNum
    }()
    
    private static let titleLabelMarginTop: CGFloat = 9
    
    private static let titleLabelHeight: CGFloat = 16
    
    private lazy var posterImgView: UIImageView = {
        let imgView = UIImageView()
        imgView.layer.masksToBounds = true
        imgView.contentMode = .scaleAspectFill
        imgView.layer.cornerRadius = MoreActressSubCell.viewWidth / 2
        return imgView
    }()
    
    private lazy var nicknameLabel: UILabel = {
        let label = UILabel()
        label.textColor = .white
        label.textAlignment = .center
        label.font = UIFont.pingFangRegular(11)
        return label
    }()
    
    var dataModel: ContentItem? {
        didSet {
            guard let item = dataModel else { return }
            posterImgView.kf.setImage(with: item.headImg?.column3, placeholder: ClassyScrollListRecomMoreExcitingSubCell.defaultImg, options: ClassyScrollListRecomMoreExcitingSubCell.animationOption)
            nicknameLabel.text = item.contentName
        }
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        renderView()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func renderView() {
        addSubview(posterImgView)
        addSubview(nicknameLabel)
        
        posterImgView.snp.makeConstraints { (make) in
            make.top.centerX.equalToSuperview()
            make.size.equalTo(MoreActressSubCell.viewWidth)
        }
        
        nicknameLabel.snp.makeConstraints { (make) in
            make.top.equalTo(posterImgView.snp.bottom).offset(MoreActressSubCell.titleLabelMarginTop)
            make.left.right.equalToSuperview()
            make.height.equalTo(MoreActressSubCell.titleLabelHeight)
        }
        
    }
    
}
