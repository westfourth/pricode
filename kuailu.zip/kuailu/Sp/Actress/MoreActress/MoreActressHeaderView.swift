//
//  ActressSubListItemHeaderBar.swift
//  Sp
//
//  Created by mac on 2020/11/13.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class MoreActressHeaderView: UIView {
    
    static let viewHeight: CGFloat = 50
    
    private lazy var titleLabel: UILabel = {
        let label = UILabel()
        label.text = "全部女優"
        label.textColor = .white
        label.font = UIFont.pingFangMedium(20)
        return label
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        addSubview(titleLabel)
        
        titleLabel.snp.makeConstraints { (make) in
            make.left.equalToSuperview().inset(12)
            make.centerY.right.equalToSuperview()
        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}
