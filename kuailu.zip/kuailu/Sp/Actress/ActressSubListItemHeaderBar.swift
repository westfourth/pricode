//
//  ActressSubListItemHeaderBar.swift
//  Sp
//
//  Created by mac on 2021/1/15.
//  Copyright © 2021 mac. All rights reserved.
//

import UIKit

class ActressSubListItemHeaderBar: UIView {
    
    static let viewHeight: CGFloat = 52
    
    private lazy var iconImgView: UIImageView = {
        return UIImageView(image: AVVC.polygonImg)
    }()
    
    lazy var titleLabel: UILabel = {
        let label = UILabel()
        label.textColor = .white
        label.font = UIFont.pingFangRegular(14)
        return label
    }()

    override init(frame: CGRect) {
        super.init(frame: frame)
        renderView()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func renderView() {
        addSubview(iconImgView)
        addSubview(titleLabel)
        
        iconImgView.snp.makeConstraints { (make) in
            make.left.equalToSuperview().inset(12)
            make.centerY.equalToSuperview()
            make.size.equalTo(10)
        }
        
        titleLabel.snp.makeConstraints { (make) in
            make.left.equalTo(iconImgView.snp.right).offset(8)
            make.centerY.right.equalToSuperview()
        }
    }

}
