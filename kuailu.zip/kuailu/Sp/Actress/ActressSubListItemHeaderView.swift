//
//  ActressSubListItemHeaderView.swift
//  Sp
//
//  Created by mac on 2020/11/10.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class ActressSubListItemHeaderView: UITableViewHeaderFooterView {
    
    private static let sizeRatio: CGFloat = 336 / 165
    
    private static let bannerHeight: CGFloat = {
        return (UIScreen.main.bounds.width - 12 * 2) / ActressSubListItemHeaderView.sizeRatio
    }()
    
    private static let marginTop: CGFloat = 20
    
    private static let marginBottom: CGFloat = 50
    
    static let maxViewHeight: CGFloat = {
        return ActressSubListItemHeaderView.marginTop +  ActressSubListItemHeaderView.bannerHeight + ActressSubListItemHeaderView.marginBottom
    }()
    
    static let minViewHeight: CGFloat = ActressSubListItemHeaderBar.viewHeight
    
    private lazy var cycleScrollView: CycleScrollView = {
        let cycleScrollView = CycleScrollView()
        cycleScrollView.delegate = self
        cycleScrollView.dataSource = self
        cycleScrollView.register(AVCycleScrollViewCell.self, forCellWithReuseIdentifier: "AVCycleScrollViewCell")
        cycleScrollView.layer.masksToBounds = true
        cycleScrollView.layer.cornerRadius = 4
        return cycleScrollView
    }()
    
    private var isInitState: Bool = true
    
    private var activeIndex: Int = 0
    
    var bannerListData: [AdvertiseResp] = [] {
        didSet {
            guard isInitState else { return }
            isInitState = false
            guard !bannerListData.isEmpty else { return }
            cycleScrollView.snp.updateConstraints { (make) in
                make.top.equalToSuperview().inset(ActressSubListItemHeaderView.marginTop)
                make.height.equalTo(ActressSubListItemHeaderView.bannerHeight)
            }
            cycleScrollView.reloadData()
        }
    }
    
    override init(reuseIdentifier: String?) {
        super.init(reuseIdentifier: reuseIdentifier)
        addSubview(cycleScrollView)
        
        cycleScrollView.snp.makeConstraints { (make) in
            make.top.equalToSuperview().inset(0)
            make.left.right.equalToSuperview().inset(12)
            make.height.equalTo(0)
        }
    
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}

extension ActressSubListItemHeaderView: CycleScrollViewDataSource {
    
    func numberOfItems(in cycleScrollView: CycleScrollView) -> Int {
        return bannerListData.count
    }
    
    func cycleScrollView(_ cycleScrollView: CycleScrollView, cellForItemAt index: Int) -> UICollectionViewCell {
        let cell = cycleScrollView.dequeueReusableCell(withReuseIdentifier: "AVCycleScrollViewCell", for: index) as! AVCycleScrollViewCell
        cell.bannerImgUrl = bannerListData[index].adImage
        return cell
    }
    
}

extension ActressSubListItemHeaderView: CycleScrollViewDelegate {
    
    func cycleScrollView(_ cycleScrollView: CycleScrollView, didSelectItemAt index: Int) {
        guard index < bannerListData.count else { return }
        let currentItem = bannerListData[index]
        guard let url = currentItem.adJump else { return }
        InnerIntercept.open(url)
    }
    
}
