//
//  ActressCell.swift
//  Sp
//
//  Created by mac on 2020/11/10.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class ActressCategoryCell: UICollectionViewCell {
    
    static let viewWidth: CGFloat = 45
    
    static let viewHeight: CGFloat = 50
    
    private lazy var titleLabel: UILabel = {
        let label = UILabel()
        label.textColor = .white
        label.font = UIFont.pingFangRegular(14)
        label.textAlignment = .center
        return label
    }()
    
    var dataModel: ActressCategoryListResp? {
        didSet {
            guard let item = dataModel else { return }
            titleLabel.text = item.areaMenuName
        }
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        addSubview(titleLabel)
        
        titleLabel.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}
