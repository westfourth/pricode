//
//  ExchangeVC.swift
//  Sp
//
//  Created by mac on 2020/2/28.
//  Copyright © 2020 mac. All rights reserved.
//


class ExchangeVC: UIViewController {
    
    private static let characterSet: CharacterSet = {
        let inputLimitCharacters: String = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789"
        return NSCharacterSet(charactersIn: inputLimitCharacters).inverted
    }()
    
    private static let vipCardImg: UIImage = {
        return UIImage.decrypt("exchange_vip_card.png.enc")
    }()
    
    private static let vipImg: UIImage? = {
        return UIImage(named: "exchange_vip_icon")
    }()
    
    private static let monthImg: UIImage? = {
        return UIImage(named: "exchange_month_icon")
    }()
    
    private lazy var inputPanel: UIView = {
        let view = UIView()
        view.backgroundColor = RGB(0x373B3E)
        view.layer.cornerRadius = 6
        view.clipsToBounds = true
        return view
    }()
    
    private lazy var inputField: UITextField = {
        let input  = UITextField()
        input.placeholder = "請輸入\(Sensitive.dui)碼"
        input.text = ""
        input.textColor = .white
        input.setValue(UIColor.white.withAlphaComponent(0.36), forKeyPath: "placeholderLabel.textColor")
        input.setValue(UIFont.pingFangMedium(16), forKeyPath: "placeholderLabel.font")
        input.font = UIFont.pingFangMedium(16)
        input.keyboardType = .asciiCapable
        input.delegate = self
        input.addTarget(self, action: #selector(onInputFieldChanged), for: .editingChanged)
        return input
    }()
    
    private lazy var vipImgView: UIImageView = {
        return UIImageView(image: ExchangeVC.vipImg)
    }()
    
    private lazy var vipCardImgView: UIImageView = {
        return UIImageView(image: ExchangeVC.vipCardImg)
    }()
    
    private lazy var exchangeCodeLabel: UILabel = {
        let label = UILabel()
        label.textColor = RGB(0xE5C2AC)
        label.font = UIFont.pingFangMedium(16)
        return label
    }()
    
    private lazy var exchangeStatusLabel: UILabel = {
        let label = UILabel()
        label.textColor = .white
        label.font = UIFont.pingFangMedium(12)
        return label
    }()
    
    private lazy var monthImgView: UIImageView = {
        return UIImageView(image: ExchangeVC.monthImg)
    }()
    
    private lazy var exchangeMonthLabel: UILabel = {
        let label = UILabel()
        label.textColor = .white
        label.font = UIFont.pingFangSemibold(16)
        label.textAlignment = .center
        return label
    }()
    
    private lazy var vipCardView: UIView = {
        let view = UIView()
        view.isHidden = true
        let ratio = (self.view.width - 12 * 2) / 336
        view.addSubview(vipCardImgView)
        view.addSubview(vipImgView)
        view.addSubview(monthImgView)
        view.addSubview(exchangeMonthLabel)
        view.addSubview(exchangeCodeLabel)
        view.addSubview(exchangeStatusLabel)
        
        vipCardImgView.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
        
        vipImgView.snp.makeConstraints { (make) in
            make.left.equalToSuperview().inset(24 * ratio)
            make.top.equalToSuperview().inset(20 * ratio)
            make.width.equalTo(60)
            make.height.equalTo(24)
        }
        
        monthImgView.snp.makeConstraints { (make) in
            make.centerY.equalTo(vipImgView)
            make.left.equalTo(vipImgView.snp.right).offset(6)
            make.width.equalTo(84)
            make.height.equalTo(26)
        }
        
        exchangeMonthLabel.snp.makeConstraints { (make) in
            make.left.right.equalTo(monthImgView)
            make.centerY.equalTo(monthImgView).offset(-1)
        }
        
        exchangeCodeLabel.snp.makeConstraints { (make) in
            make.left.equalTo(vipImgView)
            make.top.equalTo(vipImgView.snp.bottom).offset(25)
        }
        
        exchangeStatusLabel.snp.makeConstraints { (make) in
            make.left.equalTo(vipImgView)
            make.top.equalTo(exchangeCodeLabel.snp.bottom).offset(4)
        }
        
        return view
    }()
    
    private lazy var ruleTipView: UILabel = {
        let label = UILabel()
        label.numberOfLines = 0
        let ruleTipText = """
        \(Sensitive.dui)規則:
        1、每張\(Sensitive.dui)碼僅限使用一次
        2、\(Sensitive.dui)成功後請前往VIP\(Sensitive.hui)查看\(Sensitive.dui)記錄
        3、切勿頻繁嘗試\(Sensitive.dui)，如頻繁驗證系統將限制\(Sensitive.dui)
        """
        let paraph = NSMutableParagraphStyle()
        paraph.lineSpacing = 8 // 字型的行間距
        let attributes = [NSAttributedString.Key.font: UIFont.pingFangMedium(11),
                          NSAttributedString.Key.foregroundColor: RGB(0x666768),
                          NSAttributedString.Key.paragraphStyle: paraph]
        label.attributedText = NSAttributedString(string: ruleTipText, attributes: attributes)
        return label
    }()
    
    private lazy var gradientLayer: CAGradientLayer = {
        let gradientColors = [RGB(0xF86104).cgColor, RGB(0xFA9C18).cgColor]
        let gradientLocations:[NSNumber] = [0, 1]
        let gradientLayer = CAGradientLayer()
        gradientLayer.colors = gradientColors
        gradientLayer.locations = gradientLocations
        gradientLayer.startPoint = CGPoint(x: 0, y: 1)
        gradientLayer.endPoint  = CGPoint(x: 1.0, y: 1)
        gradientLayer.frame = CGRect(x: 0, y: 0, width: 240, height: 42)
        return gradientLayer
    }()
    
    private lazy var confirmBtn: UIButton = {
        let btn = UIButton()
        btn.setTitleColor(.white, for: .normal)
        btn.setTitle("確認\(Sensitive.dui)", for: .normal)
        btn.titleLabel?.font = UIFont.pingFangRegular(18)
        btn.clipsToBounds = true
        btn.layer.cornerRadius = 21
        btn.backgroundColor = RGB(0x999999)
        btn.addTarget(self, action: #selector(onConfirmBtnClick), for: .touchUpInside)
        return btn
    }()
    
    private var isExchange: Bool = false
    
    override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: Bundle?) {
        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
        hidesBottomBarWhenPushed = true
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationItem.title = "\(Sensitive.dui)中心"
        navigationController?.navigationBar.barTintColor = RGB(0x141516)
        navigationController?.navigationBar.isTranslucent = false
        navigationController?.navigationBar.shadowImage = UIImage()
        view.backgroundColor = RGB(0x141516)
        renderView()
    }
    
    private func renderView() {
        view.addSubview(inputPanel)
        view.addSubview(inputField)
        view.addSubview(vipCardView)
        view.addSubview(ruleTipView)
        view.addSubview(confirmBtn)
        inputPanel.snp.makeConstraints { (make) in
            make.top.equalToSuperview().inset(10)
            make.left.right.equalToSuperview().inset(12)
            make.height.equalTo(44)
        }
        
        inputField.snp.makeConstraints { (make) in
            make.centerY.equalTo(inputPanel)
            make.left.equalTo(inputPanel).offset(12)
            make.right.equalTo(inputPanel)
        }
        
        vipCardView.snp.makeConstraints { (make) in
            make.left.right.equalToSuperview().inset(12)
            make.top.equalTo(inputPanel.snp.bottom).offset(12)
            make.height.equalTo(0)
        }
        
        ruleTipView.snp.makeConstraints { (make) in
            make.top.equalTo(vipCardView.snp.bottom).offset(8)
            make.left.right.equalToSuperview().inset(12)
        }
        
        confirmBtn.snp.makeConstraints { (make) in
            make.bottom.equalToSuperview().inset(44)
            make.centerX.equalToSuperview()
            make.width.equalTo(240)
            make.height.equalTo(42)
        }
    }
    
    @objc private func onConfirmBtnClick() {
        let val = inputField.text
        if val == "" {
            mm_showToast("請輸入\(Sensitive.dui)碼哦！")
            return
        }
        
        if isExchange {
            exchangeExchangeCode()
            return
        }
        
        if val!.count == 6 {
            onInputFieldChanged()
            return
        }
        
        mm_showToast("\(Sensitive.dui)碼無效", type: .failed)
    }
    
    private func exchangeExchangeCode() {
        Alert.showLoading(parentView: self.view)
        let req = ConvertVipReq()
        req.reCode = inputField.text!
        Session.request(req) { (error, resp) in
            Alert.hideLoading()
            guard error == nil else {
                self.renderDefaultView()
                mm_showToast("\(Sensitive.dui)失敗", type: .failed)
                return
            }
            mm_showToast("\(Sensitive.dui)成功", type: .succeed, callback: { [weak self] in
                self?.navigationController?.popViewController(animated: true)
            })
        }
    }
    
    private func renderDefaultView() {
        isExchange = false
        vipCardView.snp.updateConstraints { (make) in
            make.height.equalTo(0)
        }
        vipCardView.isHidden = true
        confirmBtn.backgroundColor = RGB(0x999999)
        gradientLayer.removeFromSuperlayer()
    }
    
    @objc private func onInputFieldChanged() {
        let val = inputField.text!.trimmingCharacters(in: .whitespacesAndNewlines)
        inputField.text = val
        guard val.count == 6 else {
            renderDefaultView()
            return
        }
        inputField.resignFirstResponder()
        Alert.showLoading(parentView: self.view)
        let req = ConvertVipInfoReq()
        req.reCode = val
        Session.request(req) { [weak self] (error, resp) in
            Alert.hideLoading()
            guard let `self` = self else { return }
            guard error == nil, let resData = resp as? ConverVipInfo else {
                self.renderDefaultView()
                mm_showToast("\(Sensitive.dui)碼無效", type: .failed)
                return
            }
            let isNotUse = resData.status == .notuse
            self.exchangeCodeLabel.text = "\(Sensitive.dui)碼：\(val)"
            self.exchangeMonthLabel.text = "\(resData.vipDay)天"
            self.exchangeStatusLabel.text = "\(Sensitive.dui)狀態：\(isNotUse ? "未\(Sensitive.dui)" : "已\(Sensitive.dui)")"
            let height = (UIScreen.main.bounds.width - 12 * 2) / 346 * 176
            self.vipCardView.snp.updateConstraints { (make) in
                make.height.equalTo(height)
            }
            self.vipCardView.isHidden = false
            if isNotUse {
                self.isExchange = true
                self.confirmBtn.backgroundColor = .none
                self.confirmBtn.layer.insertSublayer(self.gradientLayer, at: 0)
            } else {
                self.isExchange = false
                mm_showToast("\(Sensitive.dui)碼已被使用", type: .failed)
                self.confirmBtn.backgroundColor = RGB(0x999999)
                self.gradientLayer.removeFromSuperlayer()
            }
        }
    }
}

extension ExchangeVC: UITextFieldDelegate {
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        let text = textField.text!
        let len = text.count + string.count - range.length
        guard len <= 6 else {
            return false
        }
        let filtered = string.components(separatedBy: ExchangeVC.characterSet).joined(separator: "")
        return string == filtered
    }
}
