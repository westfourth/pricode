//
//  ActressDetailsVC.swift
//  Sp
//
//  Created by mac on 2020/11/10.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class ActressDetailsVC: UIViewController {
    
    private static let posterSizeRatio: CGFloat = 420 / 277
    
    static let posterHeight: CGFloat = UIScreen.main.bounds.width / ActressDetailsVC.posterSizeRatio
    
    private static let emptyImg: UIImage? = {
        return UIImage()
    }()
    
    private static let defaultImg: UIImage? = {
        return Sensitive.banner
    }()
    
    private static let animationOption: KingfisherOptionsInfo = {
        return [.transition(.fade(0.25))]
    }()
    
    private lazy var headerView: ActressDetailsHeaderView = {
        return ActressDetailsHeaderView()
    }()
    
    private lazy var tableView: UITableView = {
        let tableView = UITableView(frame: .zero, style: .grouped)
        tableView.delegate = self
        tableView.dataSource = self
        tableView.backgroundColor = .none
        tableView.separatorStyle = .none
        tableView.bouncesZoom = false
        tableView.isDirectionalLockEnabled = true
        tableView.rowHeight = FeaturedTopicListItemSubCell.itemHeight
        tableView.estimatedRowHeight = tableView.rowHeight
        tableView.showsHorizontalScrollIndicator = false
        tableView.register(FeaturedTopicListItemSubCell.self, forCellReuseIdentifier: "FeaturedTopicListItemSubCell")
        tableView.state = .loading
        tableView.mj_footer = getCommonMJFooter(refreshingTarget: self, footerRefreshCallback: #selector(onLoad))
        return tableView
    }()
    
    private lazy var navigatorBgImgView: UIImageView = {
        let imgView = UIImageView()
        imgView.backgroundColor = RGB(0x141516)
        imgView.alpha = 0
        imgView.addSubview(nicknameLabel)
        nicknameLabel.snp.makeConstraints { (make) in
            make.left.right.equalToSuperview().inset(30)
            make.bottom.equalToSuperview().inset(9)
        }
        return imgView
    }()
    
    private lazy var nicknameLabel: UILabel = {
        let label = UILabel()
        label.font = font(18)
        label.textColor = .white
        label.textAlignment = .center
        return label
    }()
    
    private lazy var posterImgView: UIImageView = {
        let imgView = UIImageView(frame: CGRect(x: 0, y: 0, width: UIScreen.main.bounds.width, height: ActressDetailsVC.posterHeight))
        imgView.contentMode = .scaleAspectFill
        imgView.layer.masksToBounds = true
        return imgView
    }()
    
    private let navigatorBgViewAlphaThreshold: CGFloat = ActressDetailsVC.posterHeight - MARGIN_TOP
    
    private var listData: [VideoItem] = []
    
    private var dataModel: ActressDetailsResp?
    
    var viewWillDisappearCallback: (() -> Void)?
    
    var attentionClosure: ((_ isAttention: Bool) ->())?
    
    var contentId: Int? {
        didSet {
            getProfileData()
        }
    }
    
    override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: Bundle?) {
        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
        hidesBottomBarWhenPushed = true
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        if #available(iOS 11.0, *) {
            tableView.contentInsetAdjustmentBehavior = .never
        } else {
            automaticallyAdjustsScrollViewInsets = false
        }
        view.backgroundColor = RGB(0x141516)
        renderView()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        guard let navigationBar = navigationController?.navigationBar else { return }
        navigationBar.isTranslucent = true
        navigationBar.barTintColor = RGB(0x141516)
        navigationBar.setBackgroundImage(ActressDetailsVC.emptyImg, for: .default)
        navigationBar.shadowImage = ActressDetailsVC.emptyImg
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        viewWillDisappearCallback?()
        guard let isAttention = dataModel?.isAttention else { return }
        attentionClosure?(isAttention)
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        viewWillDisappearCallback = nil
        attentionClosure = nil
    }
    
    deinit {
        viewWillDisappearCallback = nil
        attentionClosure = nil
    }
    
    private func renderView() {
        view.addSubview(posterImgView)
        view.addSubview(tableView)
        view.addSubview(navigatorBgImgView)
        
        tableView.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
        navigatorBgImgView.snp.makeConstraints { (make) in
            make.top.left.right.equalToSuperview()
            make.height.equalTo(MARGIN_TOP)
        }
        
    }
    
    private func getProfileData() {
        guard let contentId = self.contentId else { return }
        let req = ActressDetailsReq()
        req.contentId = contentId
        let tableView = self.tableView
        Session.request(req) { [weak self] (error, resp) in
            guard let `self` = self, error == nil, let resData = resp as? ActressDetailsResp else {
                tableView.state = .failed
                return
            }
            tableView.state = .normal
            self.dataModel = resData
            self.nicknameLabel.text = resData.contentName
            self.posterImgView.kf.setImage(with: resData.selfImg?.column1, placeholder: ActressDetailsVC.defaultImg, options: ActressDetailsVC.animationOption)
            self.headerView.dataModel = resData
            self.tableView.reloadData()
            self.getList(isRefresh: true)
        }
    }
    
    private func getAccountInfo() {
        Session.request(UserAccountInfoReq()) { (error, resp) in
            guard error == nil, let resData = resp as? UserAccountInfo else { return }
            WalletVC.balanceVal = resData.bala
            WalletVC.coinVal = resData.gold
            WalletVC.exchangeVal = resData.welfareNum
        }
    }
    
    private func getList(isRefresh: Bool) {
        guard let contentId = self.contentId else { return }
        let req = ActressDetailsListReq()
        req.contentId = contentId
        req.lastId = isRefresh ? 0 : (listData.last?.videoId ?? 0)
        if isRefresh {
            tableView.mj_footer?.resetNoMoreData()
        }
        let tableView = self.tableView
        Session.request(req) { [weak self] (error, resp) in
            isRefresh ? tableView.mj_header?.endRefreshing() : tableView.mj_footer?.endRefreshing()
            guard let `self` = self else { return }
            guard error == nil, let resData = resp as? [VideoItem] else {
                self.handleListException(isRefresh: isRefresh)
                return
            }
            self.listData = isRefresh ? resData : self.listData + resData
            tableView.mj_footer?.isHidden = self.listData.isEmpty
            tableView.reloadData()
            if resData.count < req.pageSize {
                tableView.mj_footer?.endRefreshingWithNoMoreData()
            }
        }
    }
    
    private func handleListException(isRefresh: Bool) {
        if isRefresh {
            listData = []
            tableView.reloadData()
            tableView.state = .failed
            tableView.mj_footer?.isHidden = true
        } else {
            tableView.state = .normal
            tableView.mj_footer?.endRefreshingWithNoMoreData()
            tableView.mj_footer?.isHidden = false
        }
    }
    
    @objc private func onLoad() {
        getList(isRefresh: false)
    }
    
}

extension ActressDetailsVC: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return listData.count
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        guard let data = dataModel else { return 0 }
        return data.info.getStringSize(rectSize: CGSize(width: ActressDetailsHeaderView.introWidth, height: 0), font: font(12)).height + ActressDetailsHeaderView.minViewHeight
    }
    
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return .leastNonzeroMagnitude
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        return headerView
    }
    
    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        return nil
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "FeaturedTopicListItemSubCell", for: indexPath) as! FeaturedTopicListItemSubCell
        cell.dataModel = listData[indexPath.row]
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let vc = PlayerController()
        vc.videoId = listData[indexPath.row].videoId
        navigationController?.pushViewController(vc, animated: true)
    }
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        let offsetY = scrollView.contentOffset.y
        let isNegative = offsetY < 0
        navigatorBgImgView.alpha = isNegative ? 0 : offsetY > navigatorBgViewAlphaThreshold ? 1 : offsetY / navigatorBgViewAlphaThreshold
        let posterHeight = ActressDetailsVC.posterHeight
        let isHidden = offsetY > posterHeight
        posterImgView.isHidden = isHidden
        posterImgView.frame = CGRect(x: 0, y: isNegative ? 0 : isHidden ? -posterHeight : -offsetY, width: posterImgView.width, height: isNegative ? posterHeight + -offsetY: posterHeight )
    }
}
