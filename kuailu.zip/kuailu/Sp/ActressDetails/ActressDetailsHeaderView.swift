//
//  ActressDetailsHeaderView.swift
//  Sp
//
//  Created by mac on 2020/11/10.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class ActressDetailsHeaderView: UITableViewHeaderFooterView{
    
    private static let ratio: CGFloat = UIScreen.main.bounds.width / 420
    
    static let minViewHeight: CGFloat = {
        return ActressDetailsVC.posterHeight + ActressDetailsHeaderView.profileViewHeight
    }()
    
    private static let profileViewHeight: CGFloat = 70
    
    private static let textMargin: CGFloat = 12
    
    static let introWidth: CGFloat = {
        return UIScreen.main.bounds.width - ActressDetailsHeaderView.textMargin * 2
    }()
    
    private static let unfollowedImg: UIImage? = {
        return UIImage(named: "actress_unfollowed")
    }()
    
    private static let attentionImg: UIImage? = {
        return UIImage(named: "actress_attention")
    }()
    
    private lazy var nicknameLabel: UILabel = {
        let label = UILabel()
        label.textColor = .white
        label.font = font(26, .semibold)
        return label
    }()
    
    private lazy var worksNumLabel: UILabel = {
        let label = UILabel()
        label.textColor = .white
        label.textAlignment = .center
        label.font = font(24, .light)
        return label
    }()
    
    private lazy var worksLabel: UILabel = {
        let label = UILabel()
        label.text = "作品"
        label.textColor = .white
        label.textAlignment = .center
        label.font = font(16, .regular)
        return label
    }()
    
    private lazy var timesNumLabel: UILabel = {
        let label = UILabel()
        label.textColor = .white
        label.textAlignment = .center
        label.font = font(24, .light)
        return label
    }()
    
    private lazy var timesLabel: UILabel = {
        let label = UILabel()
        label.text = "累計播放"
        label.textColor = .white
        label.textAlignment = .center
        label.font = font(16, .regular)
        return label
    }()
    
    private lazy var introTitleLabel: UILabel = {
        let label = UILabel()
        label.text = "個人介紹"
        label.textColor = .white
        label.font = font(14)
        return label
    }()
    
    private lazy var introLabel: UILabel = {
        let label = UILabel()
        label.textColor = rgb(0xF1F1F1)
        label.font = font(12)
        label.numberOfLines = 0
        return label
    }()
    
    private lazy var workTitleLabel: UILabel = {
        let label = UILabel()
        label.text = "個人作品"
        label.textColor = .white
        label.font = font(14)
        return label
    }()
    
    private lazy var attentionBtn: UIButton = {
        let btn = UIButton()
        btn.addTarget(self, action: #selector(onFocusBtnTap), for: .touchUpInside)
        return btn
    }()
    
    var dataModel: ActressDetailsResp? {
        didSet {
            guard let item = dataModel else { return }
            nicknameLabel.text = item.contentName
            worksNumLabel.text = "\(item.videoNum)"
            timesNumLabel.text = num2TenThousandStrFormat(item.playNum)
            introLabel.text = item.info
            attentionBtn.setBackgroundImage(item.isAttention ? ActressDetailsHeaderView.unfollowedImg : ActressDetailsHeaderView.attentionImg , for: .normal)
        }
    }
    
    override init(reuseIdentifier: String?) {
        super.init(reuseIdentifier: reuseIdentifier)
        layer.masksToBounds = true
        renderView()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func renderView() {
        addSubview(nicknameLabel)
        addSubview(worksNumLabel)
        addSubview(worksLabel)
        addSubview(timesNumLabel)
        addSubview(timesLabel)
        addSubview(attentionBtn)
        addSubview(introTitleLabel)
        addSubview(introLabel)
        addSubview(workTitleLabel)
        
        let ratio = ActressDetailsHeaderView.ratio
        
        nicknameLabel.snp.makeConstraints { (make) in
            make.left.right.equalToSuperview().inset(18)
            make.top.equalToSuperview().inset((UIScreen.main.bounds.width > 400 ? 96 : 80) * ratio)
        }
        
        worksNumLabel.snp.makeConstraints { (make) in
            make.top.equalTo(nicknameLabel.snp.bottom).offset(19 * ratio)
            make.left.equalTo(nicknameLabel)
        }
        
        worksLabel.snp.makeConstraints { (make) in
            make.left.equalTo(worksNumLabel)
            make.top.equalTo(worksNumLabel.snp.bottom).offset(2 * ratio)
        }
        
        timesNumLabel.snp.makeConstraints { (make) in
            make.top.equalTo(worksNumLabel)
            make.left.equalTo(worksNumLabel.snp.right).offset(44)
        }
        
        timesLabel.snp.makeConstraints { (make) in
            make.left.equalTo(timesNumLabel)
            make.top.equalTo(timesNumLabel.snp.bottom).offset(2 * ratio)
        }
        
        attentionBtn.snp.makeConstraints { (make) in
            make.top.equalTo(worksLabel.snp.bottom).offset(16 * ratio)
            make.left.equalTo(worksLabel)
            make.width.equalTo(107)
            make.height.equalTo(34)
        }
        
        introTitleLabel.snp.makeConstraints { (make) in
            make.top.equalToSuperview().inset(ActressDetailsVC.posterHeight + 8)
            make.left.equalToSuperview().inset(ActressDetailsHeaderView.textMargin)
        }
        
        introLabel.snp.makeConstraints { (make) in
            make.left.right.equalToSuperview().inset(ActressDetailsHeaderView.textMargin)
            make.top.equalTo(introTitleLabel.snp.bottom).offset(4)
        }
        
        workTitleLabel.snp.makeConstraints { (make) in
            make.left.equalTo(introTitleLabel)
            make.bottom.equalToSuperview().inset(4)
        }
    }
    
    @objc private func onFocusBtnTap() {
        guard let isAttention = dataModel?.isAttention else { return }
        isAttention ? cancelAttentionUser() : attentionUser()
    }
    
    private func attentionUser() {
        guard let contentId = dataModel?.contentId else { return }
        loading()
        let req = ActressDetailsAttentionReq()
        req.beenUserId = contentId
        Session.request(req) { [weak self] (error, resp) in
            hideLoading()
            guard let `self` = self, error == nil else { return }
            self.dataModel?.isAttention = true
            self.attentionBtn.setBackgroundImage(ActressDetailsHeaderView.unfollowedImg, for: .normal)
        }
    }
    
    private func cancelAttentionUser() {
        guard let contentId = dataModel?.contentId else { return }
        loading()
        let req = ActressDetailsCancelAttentionReq()
        req.beenUserId = contentId
        Session.request(req) { [weak self] (error, resp) in
            hideLoading()
            guard let `self` = self, error == nil else { return }
            self.dataModel?.isAttention = false
            self.attentionBtn.setBackgroundImage(ActressDetailsHeaderView.attentionImg, for: .normal)
        }
    }
    
}
