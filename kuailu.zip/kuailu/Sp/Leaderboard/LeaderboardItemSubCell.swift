//
//  LeaderboardItemSubCell.swift
//  Sp
//
//  Created by mac on 2020/11/10.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class LeaderboardItemSubCell: UITableViewCell {
    
    static let itemHeight: CGFloat = LeaderboardItemSubCell.marginTop + LeaderboardItemSubCell.posterHeight + LeaderboardItemSubCell.titleHeight
    
    private static let marginTop: CGFloat = 15
    
    private static let placeImgList: [UIImage?] = {
        return  [UIImage(named: "champion_icon"), UIImage(named: "runner_up_icon"), UIImage(named: "third_icon")]
    }()
    
    private static let titleHeight: CGFloat = 32
    
    private static let posterSizeRatio: CGFloat = 16 / 9
    
    private static let posterWidth: CGFloat = UIScreen.main.bounds.width - 12 * 2
    
    private static let posterHeight: CGFloat = LeaderboardItemSubCell.posterWidth / LeaderboardItemSubCell.posterSizeRatio
    
    static let defaultImg: UIImage? = {
        return Sensitive.default_bg
    }()
    
    static let vipDefaultImg: UIImage? = {
        return UIImage(named: "video_vip_icon")
    }()
    
    static let payDefaultImg: UIImage? = {
        return UIImage(named: "video_pay_icon")
    }()
    
    static let limitedExemptionDefaultImg: UIImage? = {
        return UIImage(named: "limited_exemption_icon")
    }()
    
    static let animationOption: KingfisherOptionsInfo = {
        return [.transition(.fade(0.25))]
    }()
    
    private static let lineGradientMaskImg: UIImage? = {
        return UIImage(named: "line_gradient_mask_bg")
    }()
    
    private lazy var posterImgView: UIImageView = {
        let imgView = UIImageView()
        imgView.contentMode = .scaleAspectFill
        imgView.layer.masksToBounds = true
        imgView.layer.cornerRadius = 4
        imgView.addSubview(lineGradientMaskImgView)
        imgView.addSubview(buyNumLabel)
        imgView.addSubview(datetimeLabel)
        imgView.addSubview(vipOrPayImgView)
        imgView.addSubview(coinNumLabel)
        imgView.addSubview(discountImgView)
        imgView.addSubview(placeImgView)
        
        lineGradientMaskImgView.snp.makeConstraints { (make) in
            make.left.right.bottom.equalToSuperview()
            make.height.equalTo(44)
        }
        
        buyNumLabel.snp.makeConstraints { (make) in
            make.left.equalToSuperview().inset(3)
            make.bottom.equalToSuperview().inset(3)
        }
        
        datetimeLabel.snp.makeConstraints { (make) in
            make.centerY.equalTo(buyNumLabel)
            make.right.equalToSuperview().inset(3)
        }
        
        vipOrPayImgView.snp.makeConstraints { (make) in
            make.top.right.equalToSuperview()
            make.width.equalTo(36)
            make.height.equalTo(18)
        }
        
        coinNumLabel.snp.makeConstraints { (make) in
            make.left.equalTo(vipOrPayImgView.snp.left).offset(16)
            make.centerY.right.equalTo(vipOrPayImgView)
        }
        
        discountImgView.snp.makeConstraints { (make) in
            make.right.equalToSuperview().inset(8)
            make.top.equalToSuperview()
            make.width.equalTo(61)
            make.height.equalTo(55)
        }
        
        placeImgView.snp.makeConstraints { (make) in
            make.top.left.equalToSuperview().inset(6)
            make.width.equalTo(36)
            make.height.equalTo(47)
        }
        
        return imgView
    }()
    
    private lazy var vipOrPayImgView: UIImageView = {
        let imgView = UIImageView()
        imgView.contentMode = .scaleAspectFit
        return imgView
    }()
    
    private lazy var coinNumLabel: UILabel = {
        let label = UILabel()
        label.textColor = .white
        label.font = UIFont.pingFangRegular(10)
        return label
    }()
    
    private lazy var placeImgView: UIImageView = {
        let imgView = UIImageView()
        imgView.isHidden = true
        return imgView
    }()
    
    private lazy var discountIconImgView: UIImageView = {
        return UIImageView(image: ActressDetailsCell.discountIconImg)
    }()
    
    private lazy var priceLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.pingFangMedium(20)
        label.textColor = .white
        return label
    }()
    
    private lazy var originalPriceLabel: UILabel = {
        let label = UILabel()
        label.textAlignment = .center
        return label
    }()
    
    private lazy var discountImgView: UIImageView = {
        let imgView = UIImageView(image: ActressDetailsCell.discountImg)
        imgView.addSubview(discountIconImgView)
        imgView.addSubview(priceLabel)
        imgView.addSubview(originalPriceLabel)
        imgView.isHidden = true
        
        discountIconImgView.snp.makeConstraints { (make) in
            make.top.equalToSuperview().inset(3)
            make.left.equalToSuperview().inset(5)
            make.size.equalTo(18)
        }
        
        priceLabel.snp.makeConstraints { (make) in
            make.left.equalTo(discountIconImgView.snp.right)
            make.right.equalToSuperview()
            make.centerY.equalTo(discountIconImgView)
        }
        
        originalPriceLabel.snp.makeConstraints { (make) in
            make.top.equalTo(discountIconImgView.snp.bottom).offset(2)
            make.left.right.equalToSuperview()
        }
        
        return imgView
    }()
    
    private lazy var lineGradientMaskImgView: UIImageView = {
        let imgView = UIImageView(image: LeaderboardItemSubCell.lineGradientMaskImg)
        imgView.contentMode = .scaleAspectFill
        return imgView
    }()
    
    private lazy var buyNumLabel: UILabel = {
        let label = UILabel()
        label.font = FONT(10)
        label.textColor = .white
        return label
    }()
    
    private lazy var datetimeLabel: UILabel = {
        let label = UILabel()
        label.font = FONT(10)
        label.textColor = .white
        return label
    }()
    
    private lazy var titleLabel: UILabel = {
        let label = UILabel()
        label.font = FONT(14)
        label.textColor = .white
        label.numberOfLines = 1
        label.lineBreakMode = .byCharWrapping
        return label
    }()
    
    var currentIndex: Int = 0
    
    var type: AVLeaderboardType = .coin
    
    var dataModel: AVLeaderboardItem? {
        didSet {
            guard let item = dataModel else { return }
            posterImgView.kf.setImage(with: item.coverImg?.column1, placeholder: LeaderboardItemSubCell.defaultImg, options: LeaderboardItemSubCell.animationOption)
            buyNumLabel.text = type == .coin ? "\(num2TenThousandStrFormatWithChinese(item.fakeWatchTimes))播放" : "收藏數：\(item.fakeLikes)人"
            datetimeLabel.text = Date.getFormatPlayTime(secounds: TimeInterval(item.playTime))
            titleLabel.text = item.videoTitle
            if currentIndex < 3 {
                placeImgView.image = LeaderboardItemSubCell.placeImgList[currentIndex]
                placeImgView.isHidden = false
            } else {
                placeImgView.isHidden = true
            }
            vipOrPayImgView.isHidden = !(item.videoPayMark == .vip || item.videoPayMark == .free || item.videoPayMark == .pay && !item.discount)
            vipOrPayImgView.image = item.videoPayMark == .vip ? LeaderboardItemSubCell.vipDefaultImg : item.videoPayMark == .pay ? LeaderboardItemSubCell.payDefaultImg : LeaderboardItemSubCell.limitedExemptionDefaultImg
            coinNumLabel.isHidden = !(!item.discount && item.videoPayMark == .pay)
            coinNumLabel.text = "\(item.price)"
            discountImgView.isHidden = !(item.videoPayMark == .pay && item.discount)
            priceLabel.text = "\(item.price)"
            originalPriceLabel.attributedText = NSMutableAttributedString(string: "原價\(item.originalPrice)", attributes: ActressDetailsCell.originalPriceAttributes)
        }
    }
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        backgroundColor = .none
        selectionStyle = .none
        renderView()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func renderView() {
        addSubview(posterImgView)
        addSubview(titleLabel)
        
        posterImgView.snp.makeConstraints { (make) in
            make.top.equalToSuperview().inset(LeaderboardItemSubCell.marginTop)
            make.left.right.equalToSuperview().inset(12)
            make.height.equalTo(LeaderboardItemSubCell.posterHeight)
        }
        
        titleLabel.snp.makeConstraints { (make) in
            make.top.equalTo(posterImgView.snp.bottom).offset(8.5)
            make.left.right.equalTo(posterImgView)
        }
    }
    
}
