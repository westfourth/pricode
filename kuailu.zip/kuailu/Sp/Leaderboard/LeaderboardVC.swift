//
//  Leaderboard.swift
//  Sp
//
//  Created by mac on 2020/11/10.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

enum AVLeaderboardType {
    case coin
    case like
}

class LeaderboardVC: UIViewController {
    
    private static let posterRatio: CGFloat = 360 / 171
    
    private static let posterHeight: CGFloat = UIScreen.main.bounds.width / LeaderboardVC.posterRatio
    
    private static let  posterImg: UIImage = {
        return UIImage.decrypt("leaderboard_poster.jpg.enc")
    }()
    
    private static let wrapperViewMarginTop: CGFloat = LeaderboardVC.posterHeight * 0.9
    
    private static let wrapperViewHeight: CGFloat = UIScreen.main.bounds.height - LeaderboardVC.wrapperViewMarginTop + LeaderboardVC.warpperViewMarginBottom
    
    private static let barWrapperViewHeight: CGFloat = 45
    
    private static let warpperViewMarginBottom: CGFloat = 16
    
    private static let collectionViewSize: CGSize = CGSize(width: UIScreen.main.bounds.width, height: LeaderboardVC.wrapperViewHeight - LeaderboardVC.barWrapperViewHeight - LeaderboardVC.warpperViewMarginBottom)
    
    private lazy var posterImgView: UIImageView = {
        let imgView = UIImageView(image: LeaderboardVC.posterImg)
        imgView.layer.masksToBounds = true
        imgView.contentMode = .scaleAspectFill
        return imgView
    }()
    
    private lazy var wrapperView: UIView = {
        let view = UIView()
        view.backgroundColor = RGB(0x232323)
        view.layer.masksToBounds = true
        view.layer.cornerRadius = 16
        view.addSubview(collectionView)
        view.addSubview(barWrapperView)
        barWrapperView.snp.makeConstraints { (make) in
            make.top.left.right.equalToSuperview()
            make.height.equalTo(LeaderboardVC.barWrapperViewHeight)
        }
        
        collectionView.snp.makeConstraints { (make) in
            make.top.equalTo(barWrapperView.snp.bottom)
            make.left.right.equalToSuperview()
            make.bottom.equalToSuperview().inset(LeaderboardVC.warpperViewMarginBottom)
        }
        return view
    }()
    
    private lazy var leftTabBar: UIButton = {
        let btn = UIButton()
        btn.setTitle("\(Sensitive.jin)榜", for: .normal)
        btn.setTitleColor(.white, for: .normal)
        btn.titleLabel?.font = UIFont.pingFangRegular(15)
        btn.addTarget(self, action: #selector(onLeftTabTap), for: .touchUpInside)
        return btn
    }()
    
    private lazy var rightTabBar: UIButton = {
        let btn = UIButton()
        btn.setTitle("收藏榜", for: .normal)
        btn.setTitleColor(.white, for: .normal)
        btn.titleLabel?.font = UIFont.pingFangRegular(15)
        btn.addTarget(self, action: #selector(onRightTabTap), for: .touchUpInside)
        return btn
    }()
    
    private lazy var indicatorView: UIView = {
        let view = UIView()
        view.backgroundColor = RGB(0xFA6400)
        view.layer.masksToBounds = true
        view.layer.cornerRadius = 1
        return view
    }()
    
    private lazy var splitLine: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor.white.withAlphaComponent(0.2)
        return view
    }()
    
    private lazy var collectionView: UICollectionView = {
        let layout = UICollectionViewFlowLayout()
        layout.minimumLineSpacing = 0
        layout.itemSize = LeaderboardVC.collectionViewSize
        layout.scrollDirection = .horizontal
        let cv = UICollectionView(frame: .zero, collectionViewLayout: layout)
        cv.register(LeaderboardItemCell.self, forCellWithReuseIdentifier: "LeaderboardItemCell")
        cv.showsVerticalScrollIndicator = false
        cv.showsHorizontalScrollIndicator = false
        cv.bounces = false
        cv.isPagingEnabled = true
        cv.backgroundColor = .none
        cv.delegate = self
        cv.dataSource = self
        return cv
    }()
    
    private lazy var barWrapperView: UIView = {
        let view = UIView()
        view.addSubview(leftTabBar)
        view.addSubview(rightTabBar)
        view.addSubview(splitLine)
        view.addSubview(indicatorView)
        
        leftTabBar.snp.makeConstraints { (make) in
            make.top.equalToSuperview().inset(16)
            make.left.equalToSuperview().inset(20)
            make.width.equalTo(56)
            make.height.equalTo(20)
        }
        
        rightTabBar.snp.makeConstraints { (make) in
            make.top.equalTo(leftTabBar)
            make.left.equalTo(leftTabBar.snp.right).offset(15)
            make.size.equalTo(leftTabBar)
        }
        
        splitLine.snp.makeConstraints { (make) in
            make.top.equalTo(leftTabBar.snp.bottom).offset(8)
            make.left.right.equalToSuperview()
            make.height.equalTo(0.5)
        }
        
        indicatorView.snp.makeConstraints { (make) in
            make.centerY.equalTo(splitLine)
            make.centerX.equalTo(leftTabBar)
            make.width.equalTo(36)
            make.height.equalTo(2)
        }
        return view
    }()
  
    private lazy var emptyImg: UIImage = {
        return UIImage()
    }()
    
    private var activePageIndex: Int = 0
    
    override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: Bundle?) {
        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
        hidesBottomBarWhenPushed = true
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = RGB(0x232323)
        renderView()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.navigationBar.isTranslucent = true
        navigationController?.navigationBar.setBackgroundImage(emptyImg, for: .default)
        navigationController?.navigationBar.shadowImage = emptyImg
    }
    
    private func renderView() {
        view.addSubview(posterImgView)
        view.addSubview(wrapperView)
        
        posterImgView.snp.makeConstraints { (make) in
            make.top.left.right.equalToSuperview()
            make.height.equalTo(LeaderboardVC.posterHeight)
        }
        
        wrapperView.snp.makeConstraints { (make) in
            make.top.equalToSuperview().inset(LeaderboardVC.wrapperViewMarginTop)
            make.left.right.equalToSuperview()
            make.bottom.equalToSuperview().offset(LeaderboardVC.warpperViewMarginBottom)
        }
    }
    
    private func switchCurrentPageByTapping(activePageIndex: Int) {
        collectionView.setContentOffset(CGPoint(x: activePageIndex == 0 ? 0 : view.width, y: 0), animated: true)
    }
    
    private func switchCurrentPageByScrolling(activePageIndex: Int) {
        let isLeftTabBarActive = activePageIndex == 0
        rightTabBar.isSelected = !isLeftTabBarActive
        leftTabBar.isSelected = isLeftTabBarActive
        switchIndicatorLayout(isLeftTabBar: isLeftTabBarActive)
    }
    
    private func switchIndicatorLayout(isLeftTabBar: Bool) {
        indicatorView.snp.remakeConstraints { (make) in
            make.centerY.equalTo(splitLine)
            make.centerX.equalTo(isLeftTabBar ? leftTabBar : rightTabBar)
            make.width.equalTo(36)
            make.height.equalTo(2)
        }
        updateLayoutConstraints()
        UIView.animate(withDuration: 0.2) { [weak self] in
            self?.barWrapperView.layoutIfNeeded()
        }
    }
    
    private func updateLayoutConstraints() {
        barWrapperView.updateConstraintsIfNeeded()
        barWrapperView.updateFocusIfNeeded()
    }
    
    @objc private func onLeftTabTap() {
        guard activePageIndex == 1 else { return }
        switchCurrentPageByTapping(activePageIndex: 0)
    }
    
    @objc private func onRightTabTap() {
        guard activePageIndex == 0 else { return }
        switchCurrentPageByTapping(activePageIndex: 1)
    }
}

extension LeaderboardVC: UICollectionViewDelegate ,UICollectionViewDataSource {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 2
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "LeaderboardItemCell", for: indexPath) as! LeaderboardItemCell
        cell.type = indexPath.row == 0 ? .coin : .like
        return cell
    }
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        let currentActivePageIndex = scrollView.contentOffset.x <= scrollView.frame.width / 2 ? 0 : 1
        guard currentActivePageIndex != activePageIndex else { return }
        activePageIndex = currentActivePageIndex
        switchCurrentPageByScrolling(activePageIndex: activePageIndex)
    }
    
}
