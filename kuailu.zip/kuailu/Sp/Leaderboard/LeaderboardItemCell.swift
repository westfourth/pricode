//
//  LeaderboardItemCell.swift
//  Sp
//
//  Created by mac on 2020/11/10.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class LeaderboardItemCell: UICollectionViewCell {
    
    private lazy var tableView: UITableView =  {
        let tableView = UITableView(frame: .zero, style: .grouped)
        tableView.delegate = self
        tableView.dataSource = self
        tableView.backgroundColor = .none
        tableView.separatorStyle = .none
        tableView.contentInsetAdjustmentBehavior = .never
        tableView.rowHeight = LeaderboardItemSubCell.itemHeight
        tableView.register(LeaderboardItemSubCell.self, forCellReuseIdentifier: "LeaderboardItemSubCell")
        tableView.showsHorizontalScrollIndicator = false
        tableView.contentInset = UIEdgeInsets(top: 0, left: 0, bottom: 20, right: 0)
        tableView.state = .loading
        return tableView
    }()
    
    private var listData: [AVLeaderboardItem] = []
    
    private var isInitState: Bool = true
    
    var type: AVLeaderboardType = .coin {
        didSet {
            guard isInitState else { return }
            isInitState = false
            getList()
        }
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        addSubview(tableView)
        tableView.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func getList() {
        let tableView = self.tableView
        Session.request(type == .coin ? AVLeaderboardCoinReq() : AVLeaderboardLikeReq()) { [weak self] (error, resp) in
            guard let `self` = self, error == nil, let res = resp as? AVLeaderboardItemResp, !res.data.isEmpty else {
                tableView.state = .failed
                return
            }
            self.listData = res.data
            tableView.state = res.data.isEmpty ? .empty : .normal
            tableView.reloadData()
        }
    }
    
}


extension LeaderboardItemCell: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return listData.count
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return .leastNonzeroMagnitude
    }
    
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return .leastNonzeroMagnitude
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        return nil
    }
    
    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        return nil
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "LeaderboardItemSubCell", for: indexPath) as! LeaderboardItemSubCell
        cell.type = type
        let row = indexPath.row
        cell.currentIndex = row
        cell.dataModel = listData[row]
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        guard let navigationController = (UIApplication.shared.delegate as? AppDelegate)?.currentNavigationController else { return }
        let vc = PlayerController()
        vc.videoId = listData[indexPath.row].videoId
        navigationController.pushViewController(vc, animated: true)
    }
    
}
