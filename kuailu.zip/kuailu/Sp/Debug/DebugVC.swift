//
//  DebugVC.swift
//  CaoLong
//
//  Created by mac on 2020/8/14.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class DebugVC: UIViewController {
    @IBOutlet weak var lineModeSegment: UISegmentedControl!
    @IBOutlet weak var launchSwitch: UISwitch!
    @IBOutlet weak var versoinUpdateSwitch: UISwitch!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        lineModeSegment.selectedSegmentIndex = Defaults.debugLineMode.rawValue
        launchSwitch.isOn = Defaults.debugJumpLaunch
        versoinUpdateSwitch.isOn = Defaults.debugJumpVersionUpdate
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        UserDefaults.standard.synchronize()
    }
    
    @IBAction func dismiss() {
        dismiss(animated: true, completion: nil)
    }
    
    @IBAction func lineModeSegmentDidChange(_ sender: UISegmentedControl) {
        Defaults.debugLineMode = ChooseLineMode(rawValue: sender.selectedSegmentIndex)!
        UserDefaults.standard.synchronize()
    }
    
    @IBAction func launchSwitchDidChange(_ sender: UISwitch) {
        Defaults.debugJumpLaunch = sender.isOn
        UserDefaults.standard.synchronize()
    }
    
    @IBAction func versoinUpdateSwitchDidChange(_ sender: UISwitch) {
        Defaults.debugJumpVersionUpdate = sender.isOn
        UserDefaults.standard.synchronize()
    }
    
}
