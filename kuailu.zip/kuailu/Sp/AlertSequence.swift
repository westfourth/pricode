//
//  AlertSequence.swift
//  Sp
//
//  Created by mac on 2020/9/24.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

//  |版本更新 --> 系统公告
//  |活动
//  |首充折扣
class AlertSequence {
    
    static let share: AlertSequence = {
        return AlertSequence()
    }()
    
    //  显示活动、首充折扣控制器
    private lazy var homeViewController: Home2VC? = {
        guard let tabbarVC = UIApplication.shared.keyWindow?.rootViewController as? UITabBarController, let navVC = tabbarVC.viewControllers as? [UINavigationController] else { return nil }
        for i in 0..<navVC.count {
            if let vc = navVC[i].viewControllers.first as? Home2VC { return vc }
        }
        return nil
    }()
    
    //  显示系统公告控制器
    private lazy var avViewController: AVVC? = {
        guard let tabbarVC = UIApplication.shared.keyWindow?.rootViewController as? UITabBarController, let navVC = tabbarVC.viewControllers as? [UINavigationController] else { return nil }
        for i in 0..<navVC.count {
            if let vc = navVC[i].viewControllers.first as? AVVC { return vc }
        }
        return nil
    }()
    //  avVC视图
    private lazy var avVCView: UIView? = {
        return avViewController?.view
    }()
    //  homeVC视图
    private lazy var homeVCView: UIView? = {
        return homeViewController?.view
    }()
    
    //  顶层window窗口视图
    private lazy var keyWindow: UIWindow? = {
        return UIApplication.shared.keyWindow
    }()
    
    private var activityTitle: String?
    
    private var activityURL: URL?
    
    private var activityJumpType: ActivityJumpType = .inner
    
    private var activityMaskAlertCoverURL: URL?
    
    private var discounts: ChargeLimitDiscounts? {
        didSet {
            homeVCView?.addSubview(discountFloatingView)
            let tabbarFrame = (UIApplication.shared.delegate as! AppDelegate).tabbar!.frame
            
            discountFloatingView.snp.makeConstraints { (make) in
                make.right.equalTo(-8)
                make.bottom.equalTo(-tabbarFrame.height - 12)
                make.width.height.equalTo(68)
            }
            discountFloatingView.discounts = discounts
        }
    }
    
    private lazy var activityEntryImgView: AnimatedImageView = {
        let imgView = AnimatedImageView()
        imgView.isUserInteractionEnabled = true
        imgView.contentMode = .scaleAspectFit
        imgView.runLoopMode = .default
        let tap = UITapGestureRecognizer(target: self, action: #selector(onActivityEntryBtnTap))
        imgView.addGestureRecognizer(tap)
        return imgView
    }()
    
    private lazy var discountFloatingView: DiscountFloatingView = {
        let nib = UINib(nibName: "DiscountFloatingView", bundle: nil)
        let view = nib.instantiate(withOwner: nil, options: nil).first as! DiscountFloatingView
        return view
    }()
    
    func loadAllData() {
        getActivityData()
        loadVersionData()
        getChargeLimitDiscounts()
    }
    
    //  版本更新
    func loadVersionData() {
        let req = VersionUpadateReq()
        Session.request(req) { [weak self] (error, resp) in
            
            guard let `self` = self else { return }
            guard error == nil, let item = resp as? VersionUpadateResp, item.hasNewVersion else {
                self.loadAnnocementData()
                return
            }
            CustomMBProgressHUD.tapBlankDismiss = false
            guard let keyWindow = self.keyWindow else { return }
            Alert.showVersionUpdateAlert(parentView: keyWindow, contentText: item.info, isForceUpdate: item.isForceUpdate, versionNumber: item.versionNum, onConfirmTap: { [weak self] in
                //载入公告消息
                guard let `self` = self else { return }
                guard let url = item.link else {
                    mm_showToast("下載鏈接不合法!", type: .failed)
                    return
                }
                if InnerIntercept.canOpenURL(url) {
                    InnerIntercept.open(url)
                } else{
                    mm_showToast("下載鏈接不合法!", type: .failed)
                }
                if !item.isForceUpdate {
                    self.loadAnnocementData()
                }
            }) { [weak self] in
                guard let `self` = self else { return }
                if !item.isForceUpdate {
                    self.loadAnnocementData()
                }
            }
        }
    }
    
    //  系统公告
    func loadAnnocementData() {
        Session.request(AnnouncementReq()) { [weak self] (error, resp) in
            guard let `self` = self else { return }
            guard error == nil, let item = resp as? AnnouncementResp else {
                self.showActivityMaskAlert()
                return
            }
            CustomMBProgressHUD.tapBlankDismiss = false
            guard let view = self.avVCView else { return }
            Alert.showAnnouncementAlert(parentView: view, contentText: item.content) { [weak self] in
                if let url = item.appCenterUrl, InnerIntercept.canOpenURL(url) {
                    InnerIntercept.open(url)
                }
                DispatchQueue.main.async {
                    self?.showActivityMaskAlert()
                }
            } onConfirmTap: { [weak self] in
                DispatchQueue.main.async {
                    self?.showActivityMaskAlert()
                }
                
            }
            
        }
    }
    
    //  活动
    private func getActivityData() {
        Session.request(ActivityReq()) { [weak self] (error, resp) in
            
            guard let `self` = self, let resDataArr = resp as? [ActivityResp], !resDataArr.isEmpty else { return }
            
            let resData = resDataArr[0]
            
            guard let url = resData.actUrl else { return }
            
            self.activityURL = url
            
            self.activityJumpType = resData.jumpType
            
            if let coverURL = resData.coverPicture {
                self.activityEntryImgView.kf.setImage(with: coverURL.column0, options: coverURL.column0?.absoluteString.contains(".gif") ?? false ? ClassyCycleScrollViewCell.animationOptionGif : ClassyCycleScrollViewCell.animationOption)
            }
            
            if let title = resData.actTitle {
                self.activityTitle = title
            }
            
            if let maskCoverURL = resData.altPicture {
                self.activityMaskAlertCoverURL = maskCoverURL
            }
        }
    }
    
    //  限时折扣
    func getChargeLimitDiscounts() {
        let req = ChargeLimitDiscountsReq()
        Session.request(req){ [weak self] (erorr, resp) in
            guard erorr == nil, let res = resp as? ChargeLimitDiscounts else { return }
            self?.discounts = res
        }
    }
    
    //  显示活动
    private func showActivityMaskAlert() {
        guard activityURL != nil, NetDefaults.token != nil else {
            CustomMBProgressHUD.tapBlankDismiss = true
            return
        }
        CustomMBProgressHUD.tapBlankDismiss = false
        guard let view = avVCView else { return }
        Alert.showActivityMaskAlert(parentView: view, maskCoverURL: activityMaskAlertCoverURL,onConfirmTap: { [weak self] in
            CustomMBProgressHUD.tapBlankDismiss = true
            guard let `self` = self else { return }
            self.activityMaskAlertCallback()
            self.onActivityEntryBtnTap()
        }) { [weak self] in
            CustomMBProgressHUD.tapBlankDismiss = true
            self?.activityMaskAlertCallback()
        }
    }
    
    @objc private func onActivityEntryBtnTap() {
        guard let url = activityURL else { return }
        InnerIntercept.open(url)
    }
    
    private func activityMaskAlertCallback() {
        guard let Home2VC = homeViewController, let view = homeVCView else { return }
        Home2VC.activityEntryImgView = activityEntryImgView
        view.addSubview(activityEntryImgView)
        activityEntryImgView.snp.makeConstraints { (make) in
            make.top.equalTo(kTop)
            make.left.equalTo(10)
            make.size.equalTo(100)
        }
        
    }
}
