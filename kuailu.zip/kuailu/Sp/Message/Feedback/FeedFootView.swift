//
//  FeedFootView.swift
//  Sp
//
//  Created by mac on 2020/3/18.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

@objc protocol FeedFootViewDelegate {
    /// 邮箱
    func feedFooterView(footerView:FeedFootView,mailDidEndEditing textfield:UITextField)
    // 投诉原因
    func feedFooterView(footerView:FeedFootView,reasonDidEndEditing textview:UITextView)
    //选择照片成功
    func feedFooterView(footerView:FeedFootView,uploadSucess logo: String?)
    
}

class FeedFootView: UICollectionReusableView {
    
    weak var delegate: FeedFootViewDelegate?
    
    @IBOutlet weak var place: UILabel!
    
    @IBOutlet weak var mail: UITextField!
    
    @IBOutlet weak var reason: UITextView!
    
    @IBOutlet weak var resultView: UIView!
    
    @IBOutlet weak var resultImageView: UIImageView!
    
    var logoPath: String? {
        didSet {
            guard let logoPath = logoPath else {
                self.resultView.isHidden = true
                self.delegate?.feedFooterView(footerView: self, uploadSucess: nil)
                return
            }
             self.delegate?.feedFooterView(footerView: self, uploadSucess: logoPath)
            self.resultView.isHidden = false
        }
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        self.backgroundColor = .clear
        self.mail.attributedPlaceholder = NSAttributedString(string: "請輸入郵箱", attributes: [NSAttributedString.Key.font : UIFont.systemFont(ofSize: 11, weight: .medium),NSAttributedString.Key.foregroundColor:RGB(84,94,119)])
    }
    
    @IBAction func clearSelectedImage(_ sender: UIButton) {
        self.logoPath = nil
    }
    
    @IBAction func uploadAction(_ sender: UIButton) {
        let imageVC = UIImagePickerController()
        imageVC.modalPresentationStyle = .fullScreen
        if #available(iOS 13.0, *) {
            imageVC.isModalInPresentation = true
        }
        let rootVC = UIApplication.shared.keyWindow!.rootViewController as! UITabBarController
        let naviController = rootVC.selectedViewController as! UINavigationController
        
        imageVC.delegate = self as! UIImagePickerControllerDelegate as! UIImagePickerControllerDelegate & UINavigationControllerDelegate
        imageVC.allowsEditing = true
        
        let alertController = UIAlertController(title: nil, message: nil, preferredStyle: UIAlertController.Style.actionSheet)
        for i in 0..<3 {
            let action  = UIAlertAction(title: i == 0 ? "拍照":i == 1 ? "相簿":"取消", style: i == 2 ? UIAlertAction.Style.cancel:UIAlertAction.Style.default) { (action) in
                if i < 2 {
                    imageVC.sourceType =  i == 0 ?  UIImagePickerController.SourceType.camera : UIImagePickerController.SourceType.photoLibrary
                    GlobalSettings.setImagePickerNatiBarAttribute()
                    naviController.topViewController!.present(imageVC, animated: true, completion: nil)
                }
            }
            alertController.addAction(action)
        }
        naviController.topViewController!.present(alertController, animated: true, completion: nil)
    }
}

extension FeedFootView:UIImagePickerControllerDelegate,UINavigationControllerDelegate {
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        GlobalSettings.resetNaviBarAttribute()
        picker.dismiss(animated: true, completion: nil)
    }
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
         GlobalSettings.resetNaviBarAttribute()
        let image = info[UIImagePickerController.InfoKey.editedImage] as! UIImage
        Alert.showLoading(parentView: UIApplication.shared.keyWindow!)
        picker.dismiss(animated: true, completion: nil)
        ImageUploader.upload(image) { (error, domain,suffix) in
              Alert.hideLoading()
            guard error == nil else {
                mm_showToast("圖片上傳失敗", type: .failed)
                return
            }
            guard let logo = URL(string: domain + suffix) else {
                return
            }
            self.logoPath = suffix
            self.resultImageView.kf.setImage(with: logo, options: [.transition(.fade(0.25))] )
        }
    }
}

extension FeedFootView:UITextViewDelegate {
    func textView(_ textView: UITextView, shouldChangeTextIn range: NSRange, replacementText text: String) -> Bool {
        if text.count == 0 {
            return true
        }
        guard let existedLength = textView.text?.count else { return false }
        let selectedLength = range.length;
        let replaceLength = text.count;
        if (existedLength - selectedLength + replaceLength > 200){
            return false
        }
        return true
    }
    
    func textViewDidChange(_ textView: UITextView) {
        if textView.text.count > 200 {
            textView.text = String(textView.text.suffix(200))
        }
        self.place.isHidden = textView.text != ""
    }
    
    func textViewDidEndEditing(_ textView: UITextView) {
         self.delegate?.feedFooterView(footerView: self, reasonDidEndEditing: textView)
    }
}

extension FeedFootView:UITextFieldDelegate {
    func textFieldDidEndEditing(_ textField: UITextField) {
         self.delegate?.feedFooterView(footerView: self, mailDidEndEditing: textField)
    }
}
