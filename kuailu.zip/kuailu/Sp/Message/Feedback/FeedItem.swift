//
//  FeedItem.swift
//  Sp
//
//  Created by mac on 2020/3/18.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class FeedItem: NSObject {
    
    var isselected:Bool = false
    
    var title:String = ""
    
}
