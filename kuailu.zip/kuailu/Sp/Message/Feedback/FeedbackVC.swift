//
//  FeedbackVC.swift
//  Sp
//
//  Created by mac on 2020/3/18.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class FeedbackVC: UIViewController {
    @IBOutlet weak var collectionVIew: UICollectionView!
    @IBOutlet weak var layout: UICollectionViewFlowLayout!
    
    var reason:String = ""
    
    var mail:String?
    
    var resultImage: String?
    
    var items:[FeedItem] = [FeedItem]()
    
    //    var currentIndex = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = RGB(0xff141516)
        navigationItem.title = "我要反饋"
        collectionVIew.backgroundColor = .clear
        collectionVIew.register(UINib(nibName: "FeedCell", bundle: Bundle.main), forCellWithReuseIdentifier: "FeedCell")
        
        collectionVIew.register(UINib(nibName: "FeedFootView", bundle: Bundle.main), forSupplementaryViewOfKind: UICollectionView.elementKindSectionFooter, withReuseIdentifier: "FeedFootView")
        
        self.layout.itemSize = CGSize(width: 100, height: 27)
        self.layout.footerReferenceSize = CGSize(width: UIScreen.main.bounds.size.width, height: 380)
        self.layout.minimumInteritemSpacing = (UIScreen.main.bounds.size.width - 300 - 24) / 2.0
        self.layout.minimumLineSpacing = 8
        
        let titles = ["視頻播放失敗","視頻播放卡頓","沒找到資源","無法搜索",
                      "視頻質量差","分類有誤","\(Sensitive.ti)","無法\(Sensitive.chong)",
            "\(Sensitive.gou)\(Sensitive.hui)","APP不好用","賬號問題","其他"]
        
        for i in 0..<titles.count {
            let item = FeedItem()
            item.title = titles[i]
            item.isselected = false
            items.append(item)
        }
    }
    
    //MARK:-提交
    @IBAction func submitAction(_ sender: Any) {
        
        guard reason != "" else {
            mm_showToast("請填寫問題描述!")
            return
        }
        
        guard mail != nil else {
            mm_showToast("請填寫郵箱!")
            return
        }
        guard  mail != "" else {
            mm_showToast("請填寫郵箱!")
            return
        }
        
        guard validateEmail(email: mail!) else {
            mm_showToast("郵箱地址不合法!", type: .failed)
            return
        }
        
        guard resultImage != nil else {
            mm_showToast("請上傳圖片!")
            return
        }
        let items = self.items.filter { (item) -> Bool in
            return item.isselected
        }
        guard !items.isEmpty else {
            mm_showToast("請至少選擇一個問題!")
            return
        }
        Alert.showLoading(parentView: UIApplication.shared.keyWindow!)
        let req = FeedbackSubmitReq()
        req.email = mail!
        req.desc = reason
        req.img = resultImage!
        let reasons = items.map({ (item) ->String in
            return item.title
        })
        req.title = reasons.joined(separator: ",")
        Session.request(req) { (error, resp) in
            Alert.hideLoading()
            guard error == nil else {
                mm_showToast(error!.localizedDescription)
                return
            }
            mm_showToast("提交成功,感謝您的反饋!", type:  .succeed)
            self.navigationController?.popViewController(animated: true)
        }
    }
}

extension FeedbackVC:UICollectionViewDataSource,UICollectionViewDelegate {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return items.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "FeedCell", for: indexPath) as! FeedCell
        cell.item = items[indexPath.row]
        //        cell.itemSelected = currentIndex == indexPath.row
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        operate(indexPath.row)
    }
    
    //MARK:-操作处理
    func operate(_ i :Int) {
        let items = self.items.filter { (item) -> Bool in
            return item.isselected
        }
        let item = self.items[i]
        let selected = item.isselected
        if items.count == 3 {
            if selected {
                self.items[i].isselected = false
            } else {
                mm_showToast("最多可選擇3個問題!")
                return
            }
        } else {
            self.items[i].isselected = !selected
        }
        self.collectionVIew.reloadItems(at: [IndexPath(row: i, section: 0)])
    }
    
    func collectionView(_ collectionView: UICollectionView, viewForSupplementaryElementOfKind kind: String, at indexPath: IndexPath) -> UICollectionReusableView {
        if kind == UICollectionView.elementKindSectionFooter {
            let footer = collectionView.dequeueReusableSupplementaryView(ofKind: kind, withReuseIdentifier: "FeedFootView", for: indexPath) as! FeedFootView
            footer.delegate = self as FeedFootViewDelegate
            return footer
        }
        return UICollectionReusableView()
    }
}

extension FeedbackVC:FeedFootViewDelegate {
    func feedFooterView(footerView: FeedFootView, mailDidEndEditing textfield: UITextField) {
        mail = textfield.text
    }
    
    func feedFooterView(footerView: FeedFootView, reasonDidEndEditing textview: UITextView) {
        reason = textview.text
    }
    
    func feedFooterView(footerView: FeedFootView, uploadSucess logoPath: String?) {
        self.resultImage = logoPath
    }
}

