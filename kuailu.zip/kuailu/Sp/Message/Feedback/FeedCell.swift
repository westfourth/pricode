//
//  FeedCell.swift
//  Sp
//
//  Created by mac on 2020/3/18.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class FeedCell: UICollectionViewCell {
    
    @IBOutlet weak var name: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    var item:FeedItem? {
        didSet {
            guard  let item = item else {
                return
            }
            self.name.text = item.title
            self.name.backgroundColor = item.isselected ? RGB(230,40,101): UIColor.white.withAlphaComponent(0.3)
        }
    }
    
    var itemSelected:Bool = false {
        didSet {
            self.name.backgroundColor = itemSelected ?RGB(230,40,101): UIColor.white.withAlphaComponent(0.3)
        }
    }

}
