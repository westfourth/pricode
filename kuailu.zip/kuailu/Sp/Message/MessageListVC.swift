//
//  MessageListVC.swift
//  Sp
//
//  Created by mac on 2021/1/19.
//  Copyright © 2021 mac. All rights reserved.
//

import UIKit

class MessageListVC: UIViewController {

    @IBOutlet weak var tableView: UITableView!
    
    // 会话
    var items:[ConversationListItem] = [ConversationListItem]()

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = RGB(0xff141516)
        navigationItem.title = "消息"
        tableView.register(UINib(nibName: "MessageListCell", bundle: Bundle.main), forCellReuseIdentifier: "MessageListCell")
//        tableView.state = .loading
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        loadData()
    }
     
    /// loadData
    @objc func loadData() {
        items = ChatManager.shared.conversations()
        Session.request(ConversationListReq()) { (e, resp) in
            guard e == nil else {
                iToast(e!.localizedDescription)
                self.tableView.state = self.items.isEmpty ? .failed:.normal
                return
            }
            guard let items = resp as? [ConversationListItem], !items.isEmpty else {
                self.tableView.state = self.items.isEmpty ? .empty:.normal
                if !self.items.isEmpty {
                    self.tableView.mj_footer?.endRefreshingWithNoMoreData()
                }
                self.tableView.reloadData()
                return
            }
            ChatManager.shared.insertConversations(conversations: items)
            self.items = ChatManager.shared.conversations()
            self.tableView.state = self.items.isEmpty ? .empty : .normal
            self.tableView.reloadData()
        }
    }
}

// MARK: -UITableViewDataSource && Delegate
extension MessageListVC:UITableViewDataSource,UITableViewDelegate {
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "MessageListCell") as! MessageListCell
        cell.item = items[indexPath.row]
        return cell
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return items.count
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let item = items[indexPath.row]
        item.num = 0
        ChatManager.shared.insertConversations(conversations: [item])
        ///会话列表跳转
        let uid = item.fromUser?.userId
        let vc = ChatVC()
        vc.fromUserId = uid
        vc.conversation = item
        vc.name = item.fromUser?.userNickName
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 80
    }
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return 0
    }
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 0
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        return nil
    }
    
    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        return nil
    }
}


class ChatManager : NSObject {
    
    static let shared = ChatManager()
    
    //_______________________________________________________________________________________________________________
    // MARK: - 会话列表存取

     func conversations()->[ConversationListItem] {
        var items :[ConversationListItem] = [ConversationListItem]()
        if let jsons = UserDefaults.standard.array(forKey: "conversation") as? [JSON] , !jsons.isEmpty {
            for json  in jsons {
                if let item = ConversationListItem.deserialize(from: json) {
                    items.append(item)
                }
            }
        }
        return items
    }

     func insertConversations(conversations:[ConversationListItem]) {
        var jsons:[JSON] = [JSON]()
        if let array = UserDefaults.standard.array(forKey: "conversation") as? [JSON] {
            jsons.append(contentsOf: array)
        }
        for v in conversations {
            if let json = v.toJSON() {
                if jsons.isEmpty {
                    jsons.append(json)
                } else {
                    // 包含
                    if let _ = jsons.filter( {return $0["fromUserId"] as! Int == v.fromUserId}).last {
                        // 替换
                        let index = jsons.firstIndex(where: {$0["fromUserId"] as! Int == v.fromUserId}) ?? 0
                        jsons[index] = json
                    } else {
                        // 不包含
                        jsons.append(json)
                    }
                }
            }
        }
        UserDefaults.standard.setValue(jsons, forKey: "conversation")
        UserDefaults.standard.synchronize()
    }
}


