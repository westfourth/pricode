
//
//  AnnocementListVC.swift
//  Sp
//
//  Created by mac on 2020/3/18.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class AnnocementListVC: UIViewController {

    var page:Int = 1
    
    var items:[NoticeItem] = [NoticeItem]()
    
    var nomoreData:Bool = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = RGB(0xff141516)
        navigationItem.title = "系統消息"
        view.addSubview(tableView)
        tableView.snp.makeConstraints { (make) in
            make.edges.equalTo(0)
        }
        loadData()
    }
    
    
    func loadData() {
        let req = NoticeListReq()
        req.page = self.page
        Session.request(req) { (error, resp) in
            guard error == nil else {
                mm_showToast(error!.localizedDescription)
                self.tableView.state = .failed
                return
            }
            if resp is [NoticeItem] {
                let array = resp as! [NoticeItem]
                guard !array.isEmpty else {
                    self.tableView.state = .empty
                    return
                }
                self.nomoreData = array.count < 30
                if self.page == 1 {
                    self.items = array
                    if array.isEmpty {
                        self.tableView.state = .empty
                    } else{
                        self.tableView.state = .normal
                    }
                } else {
                    self.items.append(contentsOf: array)
                    if  self.items.isEmpty {
                        self.tableView.state = .empty
                    } else{
                        self.tableView.state = .normal
                    }
                }
                Defaults.latestId = self.items.first!.annId
            }
            self.tableView.reloadData()
        }
    }
    
    
    lazy var tableView : UITableView = {
        let tableView = UITableView.init(frame: CGRect.zero, style: .plain)
        tableView.delegate = self
        tableView.dataSource = self
        tableView.clipsToBounds = true
        tableView.backgroundColor = .clear
        tableView.separatorStyle = UITableViewCell.SeparatorStyle.none
        tableView.register(UINib(nibName: "AnnocementCell", bundle: Bundle.main), forCellReuseIdentifier: "AnnocementCell")
        tableView.tableFooterView = UIView()
        tableView.state = .loading
        tableView.loadMoreBlock = { [unowned self] in
            guard self.nomoreData == false else {
                return
            }
            self.page = self.page + 1
            self.loadData()
        }
        return tableView
    }()
    
}

// MARK: -UITableViewDataSource && Delegate
extension AnnocementListVC:UITableViewDataSource,UITableViewDelegate {
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "AnnocementCell") as! AnnocementCell
        cell.item = self.items[indexPath.row]
        cell.delegate = self
        return cell
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.items.count
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
//        let item = items[indexPath.row]
//        let VC = AnnocementDetailVC()
//        VC.item = item
//        self.navigationController?.pushViewController(VC, animated: true)
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return AnnocementCell.height(items[indexPath.row])
    }
}

extension AnnocementListVC:AnnocementCellDelegate {
    func activityAction(_ item: NoticeItem) {
        puts(#function)
        guard let url = item.annJumpUrl else {
            return
        }
        guard let token = NetDefaults.token  else {
            return
        }
        
        guard let value = URL(string: url.absoluteString +  "?token=" + token) else {
            return
        }
        WebVC.webViewType = .activity
        let VC = WebVC()
        VC.webviewUrl = value
        self.navigationController?.pushViewController(VC, animated: true)
    }
    
}
