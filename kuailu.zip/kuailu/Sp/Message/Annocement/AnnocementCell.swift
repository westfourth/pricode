//
//  AnnocementCell.swift
//  Sp
//
//  Created by mac on 2020/3/18.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

@objc protocol AnnocementCellDelegate {
    ///点击
    func activityAction(_ item:NoticeItem)
    
}

class AnnocementCell: UITableViewCell {

    @IBOutlet weak var name: UILabel!
    
    @IBOutlet weak var time: UILabel!
    
    @IBOutlet weak var content: UITextView!
    
    @IBOutlet weak var check: UIButton!
    
    weak var delegate: AnnocementCellDelegate?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        contentView.backgroundColor = .clear
        backgroundColor = .clear
        selectionStyle = .none
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
    }
    
    @IBAction func checkAction(_ sender: Any) {
        guard self.item != nil else {
            return
        }
        self.delegate?.activityAction(self.item!)
    }
    
    private lazy var formatDate:DateFormatter = {
        let f = DateFormatter()
        f.dateFormat = "yyyy-MM-dd HH:mm:ss"
        return f
    }()
    
    @IBOutlet weak var contentHeightCons: NSLayoutConstraint!
    var item:NoticeItem? {
        didSet {
            guard  let item = item else {
                return
            }
            self.check.isHidden = item.annType == .common
            self.check.setTitle(item.buttonName, for: UIControl.State.normal)
            self.name.text = item.name
            self.time.text = self.formatDate.string(from: item.createdAt ?? Date())
            self.content.text = item.content
            contentHeightCons.constant = item.content.getStringSize(rectSize: CGSize(width: Int(UIScreen.main.bounds.size.width) - 110, height: Int.max), font: UIFont.systemFont(ofSize: 12)).height
        }
    }
    
    /// item高度
    /// - Parameter item: 公告
    static func height(_ item:NoticeItem) -> CGFloat {
        return 40 + item.content.getStringSize(rectSize: CGSize(width: Int(UIScreen.main.bounds.size.width) - 110, height: Int.max), font: UIFont.systemFont(ofSize: 12)).height + 30
    }
    
}
