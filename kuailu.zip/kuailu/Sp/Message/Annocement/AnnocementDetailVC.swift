//
//  AnnocementDetailVC.swift
//  Sp
//
//  Created by mac on 2020/3/19.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class AnnocementDetailVC: UIViewController {
    
    @IBOutlet weak var name: UILabel!
    @IBOutlet weak var time: UILabel!
    @IBOutlet weak var avatar: UIImageView!
    
    private lazy var contentView: UITextView = {
        let textView = UITextView()
        textView.isEditable = false
        textView.linkTextAttributes = [NSAttributedString.Key.foregroundColor : RGB(0x1E90FF)]
        textView.dataDetectorTypes = .link
        textView.backgroundColor = .none
        textView.font = UIFont.pingFangRegular(12)
        textView.textColor = RGB(0xA9A9A9)
        return textView
    }()
    
    var item:NoticeItem? {
        didSet {
            guard let _ = item else {
                return
            }
        }
    }
    
    private static let formatDate:DateFormatter = {
        let f = DateFormatter()
        f.dateFormat = "yyyy-MM-dd HH:mm:ss"
        return f
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = RGB(0xff141516)
        navigationItem.title = "消息詳情"
        view.addSubview(contentView)
        contentView.snp.makeConstraints { (make) in
            make.top.equalTo(name.snp.bottom)
            make.left.equalTo(avatar.snp.right).offset(8)
            make.right.equalToSuperview().inset(40)
            make.bottom.equalToSuperview()
        }
        guard  let item = self.item else { return }
        name.text = item.name
        time.text = AnnocementDetailVC.formatDate.string(from: item.createdAt ?? Date())
        contentView.text = item.content
    }
}
