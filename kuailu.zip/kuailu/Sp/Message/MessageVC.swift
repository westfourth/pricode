//
//  ActivityVC.swift
//  Sp
//
//  Created by mac on 2020/2/17.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class MessageVC: UIViewController {
    
    var onlineURL:URL?
    var detailts = ["系統消息或公告都在這裡哦" ,"有什麼問題您跟我說哦，我馬上來幫您～","九月开门红！日活50万邀您共享！"]
    var icons = [false,false,false]
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.navigationBar.setBackgroundImage(UIImage(named: "navi_backImage_bg"), for: UIBarMetrics.default)
        self.navigationController?.navigationBar.shadowImage = UIImage()
        loadOnlineURL()
        loadData()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = RGB(0xff141516)
        navigationItem.title = "通知"
        self.navigationItem.rightBarButtonItem = UIBarButtonItem(customView: back)
        view.addSubview(self.tableView)
        tableView.snp.makeConstraints { (make) in
            make.edges.equalTo(0)
        }
        tableView.tableHeaderView = self.tableHeaderView
        
        var s = detailts[2]
        let g = NSCalendar(calendarIdentifier: NSCalendar.Identifier.gregorian)
        let c = g?.components(NSCalendar.Unit.month, from: Date())
        let numberf = NumberFormatter()
        numberf.numberStyle = .spellOut
        numberf.locale = Locale(identifier: "zh_Hans")
        let m = numberf.string(from: NSNumber(value: c?.month ?? 9)) ?? "九"
        s = s.replacingOccurrences(of: "九月", with: "\(m)月")
        detailts[2] = s
        tableView.reloadData()
    }
    
    func loadOnlineURL() {
        Session.request(OnLineWebReq()) { (error, resp) in
            guard error == nil else {
                return
            }
            if resp is OnLineWebItem {
                let item = resp as! OnLineWebItem
                self.onlineURL = item.signUrl
            }
        }
    }
    
    func loadData() {
        let req = NoticeListReq()
        req.page = 1
        Session.request(req) { [weak self] (error, resp) in
            guard error == nil else {
                return
            }
            if resp is [NoticeItem]  {
                let array = resp as! [NoticeItem]
                guard !array.isEmpty else {
                    return
                }
                let item = array.first!
                self?.detailts[1] = item.name
                self?.icons[1] = Defaults.latestId != item.annId
            }
            self?.tableView.reloadData()
        }
    }
    
    @objc func feedbackAction() {
        print(#function)
        let VC =  FeedbackVC()
        VC.hidesBottomBarWhenPushed = true
        self.navigationController?.pushViewController(VC, animated: true)
    }
    
    //_______________________________________________________________________________________________________________
    // MARK: - Lazy Load
    lazy var tableView : UITableView = {
        let tableView = UITableView.init(frame: CGRect.zero, style: .plain)
        tableView.delegate = self
        tableView.dataSource = self
        tableView.clipsToBounds = true
        tableView.backgroundColor = UIColor.clear
        tableView.separatorStyle = UITableViewCell.SeparatorStyle.none
        tableView.register(UINib(nibName: "MessageCell", bundle: Bundle.main), forCellReuseIdentifier: "MessageCell")
        tableView.tableFooterView = UIView()
        return tableView
    }()
    
    lazy var tableHeaderView: UIView = {
        let view = UIView(frame: CGRect(x: 0, y: 0, width: UIScreen.main.bounds.size.width, height: 80))
        view.backgroundColor = .clear
        let titles = ["粉絲","點贊","評論","消息"]
        let imageNames = ["ic_fs","ic_dz","ic_pl","ic_message"]
        let actions:[Selector] = [#selector(self.fansList),#selector(self.likeList),#selector(self.commentsList),#selector(self.chat)]
        let gap:CGFloat = (UIScreen.main.bounds.width - 240 - 80 ) / 3.0
        let ratio = 1.5
        for i in 0..<4 {
            let btn = button(titles[i], image: UIImage(named:imageNames[i])!, action: actions[i])
//            btn.backgroundColor = .red
            view.addSubview(btn)
            switch i {
            case 0:
                btn.snp.makeConstraints { (make) in
                    make.left.equalToSuperview().inset(40)
                    make.centerY.equalToSuperview()
                    make.size.equalTo(60)
                }
            case 1:
                btn.snp.makeConstraints { (make) in
                    make.left.equalToSuperview().inset(40 + 60 + gap)
                    make.size.equalTo(60)
                    make.centerY.equalToSuperview()
                }
                
            case 2:
                
                btn.snp.makeConstraints { (make) in
                    make.left.equalToSuperview().inset(40 + 120 + gap + gap)
                    make.size.equalTo(60)
                    make.centerY.equalToSuperview()
                }
                
            default:
                btn.snp.makeConstraints { (make) in
                    make.right.equalToSuperview().inset(40)
                    make.centerY.equalToSuperview()
                    make.size.equalTo(60)
                }
            }
        }
        view.addSubview(self.line)
        self.line.snp.makeConstraints { (make) in
            make.left.right.bottom.equalToSuperview()
            make.height.equalTo(0.5)
        }
        return view
    }()
    
    @objc func fansList() {
        print(#function)
        let VC =  FansListVC()
        VC.hidesBottomBarWhenPushed = true
        self.navigationController?.pushViewController(VC, animated: true)
    }
    
    @objc func likeList() {
        print(#function)
        let VC =  LikeListVC()
        VC.hidesBottomBarWhenPushed = true
        self.navigationController?.pushViewController(VC, animated: true)
    }
    
    @objc func commentsList() {
        print(#function)
        let VC =  CommentListVC ()
        VC.hidesBottomBarWhenPushed = true
        self.navigationController?.pushViewController(VC, animated: true)
    }
    
    @objc func chat() {
        print(#function)
        navigationController?.pushViewController(MessageListVC(), animated: true)
    }
    
    
    lazy var back:UIButton = {
        let b = UIButton()
        b.setTitle("我要反饋", for: UIControl.State.normal)
        b.setTitleColor(RGB(0xffA9A9A9), for: UIControl.State.normal)
        b.titleLabel?.font = UIFont.pingFangRegular(14)
        b.addTarget(self, action: #selector(self.feedbackAction), for: UIControl.Event.touchUpInside)
        return b
    }()
    
    lazy var line:UIView = {
        let l = UIView()
        l.backgroundColor = RGB(0x373B46)
        return l
    }()
    
    //MARK:-生成按钮
    func button(_ title:String,image:UIImage,action:Selector)->UIButton {
        let b = UIButton()
        let shareText = title.addShadow()
        shareText.addAttributes([.foregroundColor: UIColor.white], range: NSMakeRange(0, shareText.length));
        b.setAttributedTitle(shareText, for: .normal)
        b.titleLabel?.font = UIFont.pingFangRegular(12)
        b.setImage(image, for: .normal)
        b.addTarget(self, action: action, for: UIControl.Event.touchUpInside)
        b.verticalAlign = true
        b.verticalAlignSpacing = 5.0
        return b
    }
    
}

// MARK: -UITableViewDataSource && Delegate
extension MessageVC:UITableViewDataSource,UITableViewDelegate {
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "MessageCell") as! MessageCell
        let index = indexPath.row
        cell.logo.image = UIImage(named: index == 0 ? "ic_kf" :"ic_gg")
        cell.name.text = index == 1 ? "公告": index == 0 ? "在線客服":"诚招代理！广告招租！"
        cell.content.text = detailts[indexPath.row]
        cell.lastest = icons[indexPath.row]
        return cell
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 3
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if indexPath.row == 0  {
            //在线客服
            guard self.onlineURL != nil else {
                mm_showToast("在線客服地址獲取失敗!")
                return
            }
            let webVC = WebVC()
            webVC.webviewUrl = self.onlineURL!
            self.navigationController?.pushViewController(webVC, animated: true)
        } else if indexPath.row == 1 {
            //系统公告列表
            let VC =  AnnocementListVC()
            VC.hidesBottomBarWhenPushed = true
            self.navigationController?.pushViewController(VC, animated: true)
        } else if indexPath.row == 2 {
            self.navigationController?.pushViewController(InviteAgentVC(), animated: true)
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 65
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 10
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        return UIView()
        
    }
}
