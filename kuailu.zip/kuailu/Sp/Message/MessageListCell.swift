//
//  MessageListCell.swift
//  Sp
//
//  Created by mac on 2021/1/19.
//  Copyright © 2021 mac. All rights reserved.
//

import UIKit

class MessageListCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    @IBOutlet weak var avatar: UIImageView!
    @IBOutlet weak var name: UILabel!
    @IBOutlet weak var content: UILabel!
    @IBOutlet weak var time: UILabel!
    @IBOutlet weak var unread: UILabel!
    @IBOutlet weak var unreadWidCons: NSLayoutConstraint!
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    
    private lazy var format:DateFormatter = {
        let f = DateFormatter()
        f.dateFormat = "yyyy-MM-dd"
        return f
    }()
    
    var item:ConversationListItem? {
        didSet {
            guard let item = item,let user = item.fromUser else {
                return
            }
            avatar.kf.setImage(with: user.userLogo,placeholder:Sensitive.avatar,options: [.transition(.fade(0.25))])
            name.text = user.userNickName
            content.text = item.info
            unread.isHidden = item.num == 0
            unread.text = "\(item.num)"
            unreadWidCons.constant = "\(item.num)".count <= 2 ? 16:"\(item.num)".getStringSize(rectSize: .zero, font: UIFont.systemFont(ofSize: 11)).width + 8
            time.text = format.string(from: item.createdAt ?? Date())
        }
    }
    
}
