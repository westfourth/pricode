//
//  MessageCell.swift
//  Sp
//
//  Created by mac on 2020/3/18.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class MessageCell: UITableViewCell {
    @IBOutlet weak var logo: UIImageView!
    @IBOutlet weak var name: UILabel!
    @IBOutlet weak var content: UILabel!
    
    @IBOutlet weak var icon: UIView!
    private static let avatarImg: UIImage? = {
           return Sensitive.avatar
    }()
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        contentView.backgroundColor = .clear
        backgroundColor = .clear
        selectionStyle = .none
        logo.image = MessageCell.avatarImg
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    
    var lastest:Bool = false {
        didSet {
            self.icon.isHidden = !lastest
        }
    }
}
