//
//  InviteAgentVC.swift
//  Sp
//
//  Created by mac on 2020/9/10.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class InviteAgentVC: UIViewController {
    var onlineURL:URL?
    var items:[AdrentalItem] = [AdrentalItem]()
    
    @IBOutlet weak var tableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = RGB(0x141516)
        tableView.register(UINib(nibName: "InviteAgentCell", bundle: Bundle.main), forCellReuseIdentifier: "InviteAgentCell")
        self.navigationItem.rightBarButtonItem = UIBarButtonItem(customView: self.official)
        loadOnlineURL()
        loadAdData()
    }
    
    lazy var official:UIButton = {
        let b = UIButton()
        b.setTitle("联系官方", for: UIControl.State.normal)
        b.setTitleColor(RGB(0xffA9A9A9), for: UIControl.State.normal)
        b.titleLabel?.font = UIFont.pingFangRegular(15)
        b.addTarget(self, action: #selector(self.officialAction), for: UIControl.Event.touchUpInside)
        return b
    }()
    
    @objc func officialAction() {
        //在线客服
        guard self.onlineURL != nil else {
            mm_showToast("在線客服地址獲取失敗!")
            return
        }
        let webVC = WebVC()
        webVC.webviewUrl = self.onlineURL!
        self.navigationController?.pushViewController(webVC, animated: true)
    }
    
    func loadOnlineURL() {
        Session.request(OnLineWebReq()) { (error, resp) in
            guard error == nil else {
                return
            }
            if resp is OnLineWebItem {
                let item = resp as! OnLineWebItem
                self.onlineURL = item.signUrl
            }
        }
    }
    
    
    func loadAdData() {
        Session.request(AdrentalsReq()) { (e, resp) in
            guard e == nil else {return}
            guard let items = resp as? [AdrentalItem] else {return}
            self.items = items
            self.tableView.reloadData()
        }
    }
    
    
}

// MARK: -UITableViewDataSource && Delegate
extension InviteAgentVC:UITableViewDataSource,UITableViewDelegate {
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "InviteAgentCell") as! InviteAgentCell
        cell.items = items
        return cell
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return InviteAgentCell.height(items: items)
    }
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return .leastNonzeroMagnitude
    }
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return .leastNonzeroMagnitude
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        return nil
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
    }
}

