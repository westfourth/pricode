//
//  InviteAgentCell.swift
//  Sp
//
//  Created by mac on 2020/9/10.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class InviteAgentCell: UITableViewCell {

    @IBOutlet weak var content: UITextView!
    @IBOutlet weak var tableView: UITableView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        contentView.backgroundColor = .clear
        backgroundColor = .clear
        tableView.register(UINib(nibName: "InviteAgentContactCell", bundle: Bundle.main), forCellReuseIdentifier: "InviteAgentContactCell")
        tableView.separatorStyle = .none
        
        var s = content.text
        let g = NSCalendar(calendarIdentifier: NSCalendar.Identifier.gregorian)
        let c = g?.components(NSCalendar.Unit.month, from: Date())
        let numberf = NumberFormatter()
        numberf.numberStyle = .spellOut
        numberf.locale = Locale(identifier: "zh_Hans")
        let m = numberf.string(from: NSNumber(value: c?.month ?? 9)) ?? "九"
        s = s?.replacingOccurrences(of: "九月", with: "\(m)月")
        content.text = s
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
    var items:[AdrentalItem] = [AdrentalItem]() {
        didSet {
            self.tableView.reloadData()
        }
    }
    
    static func height(items:[AdrentalItem])->CGFloat {
        return CGFloat(44 * items.count + 170 + 46 + 5)
    }
}

// MARK: -UITableViewDataSource && Delegate
extension InviteAgentCell:UITableViewDataSource,UITableViewDelegate {
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "InviteAgentContactCell") as! InviteAgentContactCell
        cell.item = self.items[indexPath.row]
        return cell
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.items.count
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 44
    }

    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return .leastNonzeroMagnitude
    }
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return .leastNonzeroMagnitude
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        return nil
    }
    
    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        return nil
    }

}
