//
//  InviteAgentContactCell.swift
//  Sp
//
//  Created by mac on 2020/9/10.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class InviteAgentContactCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    @IBOutlet weak var name: UILabel!
    
    var item:AdrentalItem? {
        didSet {
            guard let item = item else {return}
            name.text = item.title + ":" + item.contactNo
        }
    }
    
    @IBAction func copyAction(_ sender: Any) {
        guard let item = item else {
            return
        }
        UIPasteboard.general.string = item.contactNo
        mm_showToast("已經複製到貼上板!", type: .succeed)
    }
}
