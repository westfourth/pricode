//
//  LikeListVC.swift
//  Sp
//
//  Created by mac on 2020/3/18.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit
class LikeListVC: UIViewController {
    
    var items:[CommentMeItem] = [CommentMeItem]()
    
    var page:Int = 1
    
    var nomoreData:Bool = false
    
        
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = RGB(0xff141516)
        navigationItem.title = "点赞"
        view.addSubview(tableView)
        tableView.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
        self.loadData()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.page = 1
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.navigationBar.barTintColor = RGB(0xff141516)
        navigationController?.navigationBar.isTranslucent = true
    }
    
    //MARK:-laodData获取资料
    
    func loadData() {
        let req = LikeMeListReq()
        req.page = self.page
        Session.request(req) { (error, resp) in
            guard error == nil else {
                mm_showToast(error!.localizedDescription)
                self.tableView.state = .failed
                return
            }
            if resp is [CommentMeItem] {
                var array = resp as! [CommentMeItem]
                array =  array.map { (item) -> CommentMeItem in
                    item.isLikeMe = true
                    return item
                }
                self.nomoreData = array.count < 30
                if self.page == 1 {
                    self.items = array
                    if array.isEmpty {
                        self.tableView.state = .empty
                    } else{
                        self.tableView.state = .normal
                    }
                } else {
                    self.items.append(contentsOf: array)
                    if  self.items.isEmpty {
                        self.tableView.state = .empty
                    } else{
                        self.tableView.state = .normal
                    }
                }
            }
            self.tableView.reloadData()
        }
    }
    
    
    lazy var tableView : UITableView = {
        let tableView = UITableView.init(frame: CGRect.zero, style: .plain)
        tableView.delegate = self
        tableView.dataSource = self
        tableView.clipsToBounds = true
        tableView.backgroundColor = UIColor.clear
        tableView.separatorStyle = UITableViewCell.SeparatorStyle.singleLine
        tableView.register(UINib(nibName: "CommentMeCell", bundle: Bundle.main), forCellReuseIdentifier: "CommentMeCell")
        tableView.separatorStyle = .none
        tableView.state = .loading
        tableView.loadMoreBlock = { [unowned self] in
            guard self.nomoreData == false else {
                return
            }
            self.page = self.page + 1
            self.loadData()
        }
        return tableView
    }()
}

// MARK: -UITableViewDataSource && Delegate
extension LikeListVC:UITableViewDataSource,UITableViewDelegate {
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "CommentMeCell") as! CommentMeCell
        cell.item = self.items[indexPath.row]
        return cell
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.items.count
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let userId = self.items[indexPath.row].userId
        guard userId != FocusCell.userId else { return }
        let vc = UsersDynamicVC()
        vc.userId = userId
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 75
    }
}

////MARK:-FocusCellDelegate
//extension LikeListVC:FocusCellDelegate {
//
//    func focuCell(cell: FocusCell, button: UIButton) {
//        print(#function)
//        guard let item = cell.item else {
//            return
//        }
//        if item.isAttention {
//            Alert.showCommonAlert(parentView: UIApplication.shared.keyWindow!, contentText: "取消关注后,您将无法及时收到他的动态",
//                                  cancelText: "再看看",
//                                  confirmText: "取消关注",
//                                  onConfirmTap: {
//                                  item.isAttention = false
//                                             //取消关注
//                                             let req = CancelFocusUserReq()
//                                             req.beenUserId = item.userId
//                                             Session.request(req) { (error, resp) in
//                                                 guard error == nil else {
//                                                     showToast(error!.localizedDescription)
//                                                     return
//                                                 }
//                                                showToast("取消成功!")
//                                             }
//                                    self.tableView.reloadData()
//            }, onCancelTap: nil)
//        } else {
//            item.isAttention = true
//            //关注
//            let req = FocusUserReq()
//            req.beenUserId = item.userId
//            Session.request(req) { (error, resp) in
//                guard error == nil else {
//                    showToast(error!.localizedDescription)
//                    return
//                }
//                showToast("关注成功!")
//            }
//            tableView.reloadData()
//        }
//    }
//
//    func focusCell(cell: FocusCell, avatar: UIImageView) {
//        print(#function)
//        guard let item = cell.item else {
//            return
//        }
//    }
//}


