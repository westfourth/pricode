//
//  CommentMeCell.swift
//  Sp
//
//  Created by mac on 2020/3/18.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class CommentMeCell: UITableViewCell {
    @IBOutlet weak var logo: UIImageView!
    @IBOutlet weak var cover: UIImageView!
    @IBOutlet weak var name: UILabel!
    @IBOutlet weak var content: UILabel!
    @IBOutlet weak var time: UILabel!
    
   private static let defaultImg: UIImage? = {
       return Sensitive.default_bg
   }()
    
    private static let avatarImg: UIImage? = {
        return Sensitive.avatar
    }()
    
    private static let animationOption: KingfisherOptionsInfo = {
        return [.transition(.fade(0.25))]
    }()
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        contentView.backgroundColor = .none
        backgroundColor = .none
        selectionStyle = .none
        let img = CommentMeCell.avatarImg
        logo.image = img
        cover.image = img
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
    var item:CommentMeItem? {
        didSet {
            guard let item = item else {
                return
            }
            self.logo.kf.setImage(with: item.logo,placeholder: CommentMeCell.avatarImg, options: CommentMeCell.animationOption)
            self.cover.kf.setImage(with: item.coverImg,placeholder: CommentMeCell.defaultImg, options: CommentMeCell.animationOption)
            self.name.text = item.nickName
            let tip  = item.isLikeMe ?  "點讚了你": item.type == .commentmine ? "在作品中提到了你":"回覆你了你的評論"
            let format = DateFormatter()
            format.dateFormat = "MM-dd"
            let timeStr = format.string(from: item.createdAt ?? Date())
            self.time.text = "\(tip)  \(timeStr) "
            self.content.text = item.content
        }
    }
}
