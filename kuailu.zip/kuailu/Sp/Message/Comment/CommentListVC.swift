//
//  CommentListVC.swift
//  Sp
//
//  Created by mac on 2020/3/18.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class CommentListVC: UIViewController {
    
    var items:[CommentMeItem] = [CommentMeItem]()
    
    var page:Int = 1
    
    var nomoreData:Bool = false
        
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = RGB(0xff141516)
        navigationItem.title = "評論"
        view.addSubview(tableView)
        tableView.snp.makeConstraints { (make) in
            make.left.right.top.bottom.equalTo(0)
        }
    }
    
    deinit {
        puts(#function)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.page = 1
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.navigationBar.barTintColor = RGB(0xff141516)
           navigationController?.navigationBar.isTranslucent = true
        self.loadData()
    }
    
    //MARK:-laodData获取资料
    func loadData() {
        let req = CommentMeListReq()
        req.page = self.page
        Session.request(req) { (error, resp) in
            guard error == nil else {
                mm_showToast(error!.localizedDescription)
                self.tableView.state = .failed
                return
            }
            if resp is [CommentMeItem] {
                let array = resp as! [CommentMeItem]
                self.nomoreData = array.count < 30
                if self.page == 1 {
                    self.items = array
                    if array.isEmpty {
                        self.tableView.state = .empty
                    } else{
                        self.tableView.state = .normal
                    }
                } else {
                    self.items.append(contentsOf: array)
                    if  self.items.isEmpty {
                        self.tableView.state = .empty
                    } else{
                        self.tableView.state = .normal
                    }
                }
            }
            self.tableView.reloadData()
        }
    }
    
    
    lazy var tableView : UITableView = {
        let tableView = UITableView.init(frame: CGRect.zero, style: .plain)
        tableView.delegate = self
        tableView.dataSource = self
        tableView.clipsToBounds = true
        tableView.backgroundColor = UIColor.clear
        tableView.separatorStyle = UITableViewCell.SeparatorStyle.singleLine
        tableView.register(UINib(nibName: "CommentMeCell", bundle: Bundle.main), forCellReuseIdentifier: "CommentMeCell")
        tableView.separatorStyle = .none
        tableView.state = .loading
        tableView.loadMoreBlock = { [unowned self] in
            guard self.nomoreData == false else {
                return
            }
            self.page = self.page + 1
            self.loadData()
        }
        return tableView
    }()
}

// MARK: -UITableViewDataSource && Delegate
extension CommentListVC:UITableViewDataSource,UITableViewDelegate {
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "CommentMeCell") as! CommentMeCell
        cell.item = self.items[indexPath.row]
        return cell
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.items.count
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let commentUserId = self.items[indexPath.row].commentUserId
        guard commentUserId != FocusCell.userId else { return }
       let vc = UsersDynamicVC()
       vc.userId = commentUserId
       self.navigationController?.pushViewController(vc, animated: true)
    }

    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 75
    }
}


