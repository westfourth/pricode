//
//  ChatVC.swift
//  Sp
//
//  Created by mac on 2021/1/20.
//  Copyright © 2021 mac. All rights reserved.
//

import UIKit

class ChatVC: UIViewController {
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var bottomView: UIView!
    @IBOutlet weak var input: UITextField!
    @IBOutlet weak var send: UIButton!
    @IBOutlet weak var warning: MarqueeLabel!
    
    var isrequesting:Bool = false
    
    var items:[ChatMessageItem] = [ChatMessageItem] ()
    
    var timer:Timer?
    
    var fromUserId:Int! {
        didSet {
            
        }
    }
    
    var name:String? {
        didSet {
            guard let name = name else {
                return
            }
            DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 0.5) {
                self.navigationItem.title = name
            }
        }
    }
    
    var conversation:ConversationListItem? {
        didSet {
            guard let _ = conversation else {
                return
            }
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.navigationBar.setBackgroundImage(UIImage(named: "navi_backImage_bg"), for: UIBarMetrics.default)
        navigationItem.rightBarButtonItem = UIBarButtonItem(customView: more)
        self.navigationController?.navigationBar.shadowImage = UIImage()
        input.attributedPlaceholder = NSMutableAttributedString(string: "发送消息……", attributes: [NSAttributedString.Key.foregroundColor : rgb(0xff676A73),NSAttributedString.Key.font:UIFont.systemFont(ofSize: 12)])
        
        send.isEnabled = false
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = RGB(0xff141516)
        loadData()
        tableView.register(UINib(nibName: "ChatMessageCell", bundle: Bundle.main), forCellReuseIdentifier: "ChatMessageCell")
        tableView.state = .loading
        tableView.reloadData()
        
        timer = Timer.scheduledTimer(withTimeInterval: 10, repeats: true, block: { [weak self] (timer)  in
            self?.loadData()
        })
        
        warning.type = .continuous
        warning.animationCurve = .easeInOut
        warning.font = UIFont.systemFont(ofSize: 12, weight: .regular)
        warning.textColor = .black
        
        querymine()
        queryhim()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        // 插入
        if self.conversation != nil && !self.items.isEmpty {
            self.conversation!.info = self.items.last!.info
            ChatManager.shared.insertConversations(conversations: [self.conversation!])
        }
        
        if conversation == nil && !self.items.isEmpty {
            // 直接私信 需要构建一条会话信息
            let c = ConversationListItem()
            c.fromUser = him
            c.toUser  = mine
            c.info = items.last!.info
            c.createdAt = self.items.last!.createdAt
            c.fromUserId = him.userId
            c.toUserId = mine.userId
            ChatManager.shared.insertConversations(conversations: [c])
        }
        timer?.invalidate()
        timer = nil
    }
    

    @objc func loadData() {
        items = messages(userId: fromUserId)
        let req = ChatMessageListReq()
        req.fromUserId = self.fromUserId
        Session.request(req) { (e, resp) in
            guard e == nil else {
                self.tableView.state = self.items.isEmpty ? .empty:.normal
                self.tableView.reloadData()
                iToast(e!.localizedDescription)
                return
            }
            guard let array = resp as? [ChatMessageItem], !array.isEmpty else {
                self.tableView.state = self.items.isEmpty ? .empty:.normal
                self.tableView.reloadData()
                return
            }
            self.items.append(contentsOf: array)
            insertMessage(userId: self.fromUserId, messages: array)
            self.tableView.state = self.items.isEmpty ? .empty:.normal
            self.tableView.reloadData()
        }
    }
    
    
    @IBAction func inputChanged(_ sender: UITextField) {
        send.isEnabled = sender.text != ""
    }
    
    
    lazy var more:UIButton = {
        let v = UIButton(type: .custom)
        v.setImage(UIImage(named: "chat_more"), for: .normal)
        v.addTarget(self, action: #selector(self.moreAction), for: .touchUpInside)
        return v
    }()
    
    @objc func moreAction() {
        let vc = ChatMoreVC()
        vc.callback = { [weak self] in
            let vc = UsersDynamicVC()
            vc.userId = self?.fromUserId
            vc.initPageType = .profile
            vc.hidesBottomBarWhenPushed = true
            self?.navigationController?.pushViewController(vc, animated: true)
        }
        present(vc, animated: true, completion: nil)
    }
    
    @IBAction func sendAction(_ sender: UIButton) {
//        self.view.endEditing(true)
        guard let userInfo =  NetDefaults.userInfo,userInfo.freeWatches == -1 else {
            chatPermission {
                let vc = Vip2VC()
                vc.hidesBottomBarWhenPushed = true
                self.navigationController?.pushViewController(vc, animated: true)
            }
            return
        }
        
        guard self.input.text != "" else {
            return
        }
        guard isrequesting == false else {
            return
        }
        isrequesting = true
        let req = SendMessageReq()
        req.toUserId = fromUserId
        req.info = self.input.text!
//        Alert.showLoading(parentView: self.view)
        Session.request(req) { (e, resp) in
            self.tableView.mj_header?.endRefreshing()
//            Alert.hideLoading()
            self.isrequesting = false
            self.input.text = ""
            guard e == nil else {
                iToast(e!.localizedDescription)
                return
            }
            guard let item = resp as? ChatMessageItem else {
                return
            }
            self.items.append(item)
            insertMessage(userId: self.fromUserId, messages: [item])
            self.tableView.state = .normal
            self.tableView.reloadData()
            self.send.isEnabled = false
//            mm_showToast("发送成功!", type: .succeed, duration: 1.0, callback: nil)
            self.tableView.scrollToRow(at: IndexPath(row: 0, section: self.items.count - 1), at: UITableView.ScrollPosition.bottom, animated: true)
        }
    }
    
    
    
    var mine:ConversationUser = ConversationUser()
    var him:ConversationUser = ConversationUser()
    
    //_______________________________________________________________________________________________________________
    // MARK: - 查询我和对方的消息
    func queryhim() {
        let req = FetchUserInfoReq()
        req.userId = fromUserId
        
        Session.request(req) { (e, resp) in
            guard e == nil else {return}
            guard let item = resp as? UserBase else {
                return
            }
            self.him.userId = self.fromUserId
            self.him.userNickName = item.nickName
            self.him.userLogo = item.logo
            self.him.level = item.level
        }
    }
    
    func querymine() {
        if let item = NetDefaults.userInfo {
            self.mine.userId = item.userId
            self.mine.userNickName = item.nickName
            self.mine.userLogo = item.logo
            self.mine.level = item.level
        }
    }
    
}


//MARK:-UITextFieldDelegate
extension ChatVC:UITextFieldDelegate {
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        if string.count == 0 {
            return true
        }
        guard let existedLength = textField.text?.count else { return false }
        let selectedLength = range.length;
        let replaceLength = string.count;
        if (existedLength - selectedLength + replaceLength > 40){
            return false
        }
        return true
    }
}

// MARK: -UITableViewDataSource && Delegate
extension ChatVC:UITableViewDataSource,UITableViewDelegate {
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ChatMessageCell") as! ChatMessageCell
        cell.item = self.items[indexPath.section]
        cell.delegate = self
        return cell
    }

    func numberOfSections(in tableView: UITableView) -> Int {
        return items.count
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return ChatMessageCell.cellHeight(self.items[indexPath.section])
    }
    
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return 5
    }
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 0
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        return nil
    }
    
    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        let v = UIView()
        v.backgroundColor = .clear
        return v
    }
}

extension ChatVC:ChatMessageCellDelegate {
    func chatMessageCell(didClick cell: ChatMessageCell, avatar: UIImageView) {
        guard let item = cell.item,let user = item.fromUser else {
            return
        }
        
        let vc = UsersDynamicVC()
        vc.userId = user.userId
        vc.initPageType = .profile
        vc.hidesBottomBarWhenPushed = true
        self.navigationController?.pushViewController(vc, animated: true)
    }
}


//_______________________________________________________________________________________________________________
// MARK: - 消息存取

public func insertMessage(userId:Int,messages:[ChatMessageItem]) {
    var jsons:[JSON] = [JSON]()
    if let array = UserDefaults.standard.array(forKey: "\(userId)") as? [JSON] {
        jsons.append(contentsOf: array)
    }
    for v in messages {
        if let json = v.toJSON() {
            jsons.append(json)
        }
    }
    UserDefaults.standard.setValue(jsons, forKey: "\(userId)")
    UserDefaults.standard.synchronize()
}

public func messages(userId:Int)->[ChatMessageItem] {
    var items :[ChatMessageItem] = [ChatMessageItem]()
    if let jsons = UserDefaults.standard.array(forKey: "\(userId)") as? [JSON] , !jsons.isEmpty {
        for json  in jsons {
            if let item = ChatMessageItem.deserialize(from: json) {
                items.append(item)
            }
        }
    }
    return items
}
