//
//  ChatMessageCell.swift
//  Sp
//
//  Created by mac on 2021/1/20.
//  Copyright © 2021 mac. All rights reserved.
//

import UIKit

@objc protocol ChatMessageCellDelegate {
    ///点击
    func chatMessageCell( didClick cell:ChatMessageCell, avatar:UIImageView)
    
}

class ChatMessageCell: UITableViewCell {

    weak var delegate: ChatMessageCellDelegate?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        avatar.isUserInteractionEnabled = true
        let tap = UITapGestureRecognizer(target: self, action:#selector(tapAvatar))
        avatar.addGestureRecognizer(tap)
    }
    
    
    @objc func tapAvatar() {
        delegate?.chatMessageCell(didClick: self, avatar: avatar)
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    
    @IBOutlet weak var avatar: UIImageView!
    @IBOutlet weak var content: UILabel!
    @IBOutlet weak var contentHeightCons: NSLayoutConstraint!
    @IBOutlet weak var contentWIdthCons: NSLayoutConstraint!
    
    @IBOutlet weak var time: UILabel!
    
    @IBOutlet weak var avatarLeftCons: NSLayoutConstraint!
    
    @IBOutlet weak var contentLeft: NSLayoutConstraint!
    
    lazy var contentFont:UIFont =  {
        let f =  UIFont.systemFont(ofSize: 12, weight: .medium)
        return f
    }()
    
    var item:ChatMessageItem? {
        didSet {
            guard let item = item,let user = item.fromUser else {
                return
            }
            avatar.kf.setImage(with: item.fromUser?.userLogo,placeholder:Sensitive.avatar,options: [.transition(.fade(0.25))])
            
            content.text = ""
            
            content.text = item.info
            
            let contentW = item.info.getStringSize(rectSize: CGSize(width: UIScreen.main.bounds.width - 150, height: CGFloat.greatestFiniteMagnitude), font:contentFont).width + 20
            
            contentWIdthCons.constant = contentW <= UIScreen.main.bounds.width - 150 ? contentW : UIScreen.main.bounds.width - 150
            
            contentHeightCons.constant = item.info.getStringSize(rectSize: CGSize(width: contentW, height: CGFloat.greatestFiniteMagnitude), font:contentFont).height +  16
            
            
            let isMine = ismine(user)
            content.backgroundColor = isMine == false ? rgb(0xffFFFFFD):rgb(0xffFF9903)
            content.textColor = isMine == false ? rgb(0xff292929):.white
            avatarLeftCons.constant = isMine ? UIScreen.main.bounds.width - 44 - 12 : 12
            
            contentLeft.constant = isMine ? UIScreen.main.bounds.width - 68 - contentW : 68
            if item.createdAt != nil {
                let t:TimeInterval =  item.createdAt!.timeIntervalSince1970
                time.text = Date.getCompareCurrntTime(timeStamp:String(t))
            }
        }
    }
    
    func ismine(_ user:ConversationUser)->Bool {
        if let userInfo = NetDefaults.userInfo {
            return userInfo.userId == user.userId
        }
        return false
    }
    
    func myId()->Int {
        if let userInfo = NetDefaults.userInfo {
            return userInfo.userId
        }
        return 0
    }
    
    static func cellHeight(_ item:ChatMessageItem)->CGFloat {
        
        let contentW = item.info.getStringSize(rectSize: CGSize(width: UIScreen.main.bounds.width - 150, height: CGFloat.greatestFiniteMagnitude), font:UIFont.systemFont(ofSize: 12, weight: .medium)).width + 20
        
        let W:CGFloat = contentW <= UIScreen.main.bounds.width - 150 ? contentW : UIScreen.main.bounds.width - 150
        
        let H:CGFloat = item.info.getStringSize(rectSize: CGSize(width: W, height: CGFloat.greatestFiniteMagnitude), font:UIFont.systemFont(ofSize: 12, weight: .medium)).height +  16
        
//        return H + 12 + 15 + 12 + 5
        return H + 12 + 15
        
    }
    
}
