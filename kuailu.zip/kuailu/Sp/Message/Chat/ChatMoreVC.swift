//
//  ChatMoreVC.swift
//  Sp
//
//  Created by mac on 2021/1/20.
//  Copyright © 2021 mac. All rights reserved.
//

import UIKit

class ChatMoreVC: UIViewController {

    
    var transtioner:ModalTransitionManager!
    
     var callback: (() -> ())?
    
    override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: Bundle?) {
        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
        modalPresentationStyle = .overFullScreen
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    @IBAction func cancelAction(_ sender: UITapGestureRecognizer) {
        dismiss(animated: true, completion: nil)
    }
    
    
    @IBAction func mainPageAction(_ sender: Any) {
        callback?()
        dismiss(animated: true, completion: nil)
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let gap:CGFloat  = UIApplication.shared.keyWindow!.safeAreaInsets.bottom > 0 ? 34:0
        transtioner = ModalTransitionManager(viewController: self, height: 96 + gap)
    }
}
