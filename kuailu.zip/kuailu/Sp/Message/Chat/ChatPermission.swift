//
//  ChatPermission.swift
//  Sp
//
//  Created by mac on 2021/1/20.
//  Copyright © 2021 mac. All rights reserved.
//

import UIKit

class ChatPermission: UIView {

     var callback: (() -> ())?
    
    @IBAction func tapAllAction(_ sender: Any) {    }
    
    @IBAction func cancelAction(_ sender: Any) {
        hideLoading()
    }
    
    @IBAction func buyAction(_ sender: Any) {
        if callback != nil {
            callback!()
        }
        hideLoading()
    }
}

public func chatPermission(_ completion:@escaping(()->())) {
    hideLoading()
    let loadingView = Bundle.main.loadNibNamed("ChatPermission", owner: nil, options: [:])?.first as! ChatPermission
    loadingView.frame = UIScreen.main.bounds
    
    loadingView.callback = {
        completion()
    }
    UIApplication.shared.keyWindow!.showToast(loadingView, duration: 10000, position: .center)
}
