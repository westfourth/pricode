//
//  LaunchVC.swift
//  Sp
//
//  Created by mac on 2020/3/13.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit


@objc protocol LaunchVCDelegate {
    func didExist(launchVC: LaunchVC, didPassReview: Bool)
}

class LaunchVC: UIViewController {
    weak var delegate: LaunchVCDelegate?
    var count = 0
    var timer:Timer?
    var item:AdvertiseResp?
    
    /// 用于封禁特殊情况处理
    var forbidden = false
    
    @IBOutlet weak var accountView: UIView!
    @IBOutlet weak var code: UIImageView!
    
    @IBOutlet weak var skip: UIButton!
    @IBOutlet weak var lanunch: UIImageView!
    
    let lanunchImage = UIImage(named: "LaunchImage")
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //
        skip.layer.cornerRadius = 22;
        skip.layer.masksToBounds = true;
        skip.layer.backgroundColor = UIColor.black.withAlphaComponent(0.6).cgColor
        
        //  点击封面
        let tap = UITapGestureRecognizer(target: self, action:#selector(self.luanchAction(_:)))
        self.lanunch.addGestureRecognizer(tap)
        self.lanunch.image = lanunchImage
        
        startTimer()
        chooseLine()
    }
    
    deinit {
        self.timer?.invalidate()
    }
    
    func startTimer() {
        #if DEBUG
        count = 2
        #else
        count = 5
        #endif
        self.skip.isEnabled = false
        self.skip.setTitle("\(self.count)", for: UIControl.State.normal)
        
        self.timer?.invalidate()
        self.timer = Timer(timeInterval: 1.0, target: self, selector: #selector(self.timeAction), userInfo: nil, repeats: true)
        RunLoop.current.add(self.timer!, forMode: RunLoop.Mode.common)
    }
    
    /// 定时器
    @objc func timeAction() {
        self.count = self.count - 1
        var title: String? = "\(self.count)"
        var image: UIImage? = UIImage(named: "guanbi_btn")
        var color: UIColor? = UIColor.black.withAlphaComponent(0.4)
        if self.count <= 0 {
            title = nil
            color = nil
            self.skip.isEnabled = true
            self.timer?.invalidate()
        } else {
            image = nil;
        }
        self.skip.setTitle(title, for: .normal)
        self.skip.setBackgroundImage(image, for: .normal)
//        self.skip.layer.backgroundColor = color?.cgColor
    }
    
    /// 点击封面，跳到广告页
    @objc func luanchAction(_ tap:UITapGestureRecognizer) {
        guard let url = self.item?.adJump,self.item?.jumpType == .outter else {
            mm_showToast("url不合法!", type: .failed)
            return
        }
        if InnerIntercept.canOpenURL(url) {
            InnerIntercept.open(url)
        } else {
            mm_showToast("url不合法!", type: .failed)
        }
    }
    
    /// 倒计时后，显示的跳过
    @IBAction @objc func skipAction(_ sender: Any) {
        willGotoTabBarController()
    }
    
    func retryChooseLine() {
        let controller = UIAlertController(title: "选线失败，是否重试?", message: nil, preferredStyle: .alert)
        let cancel = UIAlertAction(title: "退出", style: .cancel) { (action) in
            exit(-1)
        }
        let retry = UIAlertAction(title: "重试", style: .destructive) { (action) in
            self.startTimer()
            self.chooseLine()
        }
        controller.addAction(cancel)
        controller.addAction(retry)
        present(controller, animated: true, completion: nil)
    }
    
    func willGotoTabBarController() {
        if !Defaults.didPassReview {
            self.delegate?.didExist(launchVC: self, didPassReview: false)
        } else {
            guard !forbidden, NetDefaults.token != nil  else {
                // 封禁或者登录失败
                self.exitApp(title: "獲取token失敗，請重啟APP")
                return
            }
            self.delegate?.didExist(launchVC: self, didPassReview: true)
            //            if NetDefaults.token != nil {
            //                self.delegate?.didExist(launchVC: self, didPassReview: true)
            //            } else {
            //                self.exitApp(title: "获取token失败，请重启APP")
            //            }
            
        }
    }
    
    func exitApp(title: String) {
        let alert = UIAlertController.init(title: title, message: nil, preferredStyle: .alert)
        let action = UIAlertAction.init(title: "退出", style: .destructive, handler: {
            (action) -> Void in
            exit(-1);
        })
        alert.addAction(action)
        self.present(alert, animated: true, completion: nil)
    }
    
    // MARK: -  网络处理
    /// 选线
    func chooseLine() {
        #if DEBUG               // debug模式
        
//        #warning("目前仅仅是为了调试######")
//        ChooseLine.share.mode = .test
        ChooseLine.share.mode = Defaults.debugLineMode
        #endif
        
        ChooseLine.share.chooseLine { (line) in
            guard line != nil else {
                #if !DEBUG      // release模式
                self.backupChooseLine()
                #endif
                return
            }
            
            NetDefaults.finalLine = line!
            let tz = TimeZone.current
            //  旧金山
            if tz.secondsFromGMT() != -25200 {
                Defaults.didPassReview = true
                self.handlePassReview()
            }
        }
    }
    
    /// 是否过审
    ///
    /// isSuccess = 0;  进入马甲包
    @available(*, unavailable, message: "通过时区判断")
    func getReviewStatus() {
        if Defaults.didPassReview {
            self.handlePassReview()
            return;
        }
        let packageName = Bundle.main.infoDictionary!["VestBag"] as! String
        Switch.switchAction(packageName: packageName) { (success) in
            if success != nil && success == true {      //  進入主包
                Defaults.didPassReview = true
            } else {                                    //  進入馬甲包
                #if STORE       //  商店包沒有過審時，重設置路線為正常視頻
                NetDefaults.finalLine = "https://app.mbkbf.me/api/"
                #endif
            }
            if Defaults.didPassReview {
                self.handlePassReview()
            }
        }
    }
    
    /// 过审状态处理
    func handlePassReview() {
        //  获取广告
        self.getAdvertisement()
        if NetDefaults.token == nil {
            self.travellerLogin()
        } else {
            self.launchAppStatistics()
        }
    }
    
    /// 获取广告，不需要token
    func getAdvertisement() {
        AdManager.shared.load { (resp) in
            self.item = resp
            self.lanunch.kf.setImage(with: resp?.adImage?.column0, placeholder: self.lanunchImage)
        }
    }
    
    /// 游客登陆
    func travellerLogin() {
        Session.request(TravelerReq()) { [weak self](error, resp) in
            guard error == nil else {
                mm_showToast(error!.localizedDescription)
                if let error = error as NSError? {
                    if let code = error.userInfo["NetRequestErrorCodeKey"] as? Int, code == 1002 {
                        // 被封禁了
                        self?.forbidden = true
                    }
                }
                return
            }
            Session.request(FetchUserInfoReq()) { (e, resp) in}
            //            self?.accountView.isHidden = false
            //            if let user = NetDefaults.userInfo {
            //                let combine = DeviceId.deviceId + "*" + "\(user.userId)"
            //                self?.code.image = self?.creatQRCodeImage(text: combine, WH: 206)
            //                self?.saveWindowShot()
            //            }
            //  获取热点
            HotSpot.share.loadItems()
            //  上传视频配置信息
            UploadConfig.shared.loadConfig()
        }
    }
    
    /// #启动app统计，需要token
    func launchAppStatistics() {
        Session.request(LaunchAppReq()) { (error, resp) in
            Session.request(FetchUserInfoReq()) { (e, resp) in}
            if let err = error {
                if err.localizedDescription == "token解析錯誤" {
                    self.travellerLogin()
                }
            } else {
                //  获取热点
                HotSpot.share.loadItems()
                //  上传视频配置信息
                UploadConfig.shared.loadConfig()
            }
        }
    }
    
    #if DEBUG
    override func motionBegan(_ motion: UIEvent.EventSubtype, with event: UIEvent?) {
        present(DebugVC(), animated: true, completion: nil)
    }
    #endif
}


//MARK:-    当选线失败后，启动备用选线

extension LaunchVC {
    /// 启动备用选线
    func backupChooseLine() {
        backupLines { (lines) in
            ChooseLine.share.lines = lines
            // 线路探测
            ChooseLine.share.chooseLine { (line) in
                guard line != nil else {
                    self.retryChooseLine()
                    return
                }
                NetDefaults.finalLine = line!
                if ReviewCheck.shouldEnterMain() {
                    Defaults.didPassReview = true
                    self.handlePassReview()
                }
            }
        }
    }
    
    /// 获取备用线路
    func backupLines(completion: @escaping ([String]) -> Void) {
        let appJson = Bundle.main.infoDictionary!["APP_JSON"] as! String
        let url = URL(string: appJson)!
        var req = URLRequest(url: url)
        req.timeoutInterval = 15
        req.cachePolicy = .reloadIgnoringLocalAndRemoteCacheData
        URLSession.shared.dataTask(with: req) { (data, resp, err) in
            guard err == nil else {
                completion([])
                return
            }
            guard resp is HTTPURLResponse,
                  (resp as! HTTPURLResponse).statusCode == 200 else {
                completion([])
                return
            }
            let lines = try! JSONSerialization.jsonObject(with: data!, options: []) as! [String]
    
            /// 加上api
            var lines2 = [String]()
            for line in lines {
                lines2.append(line + "/api/")
            }
            
            completion(lines2)
        }.resume()
    }
}
