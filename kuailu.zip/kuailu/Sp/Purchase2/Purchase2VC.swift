//
//  Purchase2VC.swift
//  Sp
//
//  Created by mac on 2020/11/16.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class Purchase2VC: UIViewController {
    @IBOutlet weak var segmentControl: XSIndicatorSegmentedControl!
    @IBOutlet weak var pageView: UIView!
    
    var pageVC: UIPageViewController?
    var items = [Purchase2CateVC]()
    
    var uiType: Purchase2CateVC.UIType = .short
    var apiType: Purchase2CateVC.APIType = .purchase {
        didSet {
            switch apiType {
            case .purchase:
                title = "我的购买"
            case .favorite:
                title = "我的收藏"
            case .history:
                title = "观看记录"
            }
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        segmentControl.setTitleTextAttributes([.font: font(15), .foregroundColor: UIColor.white], for: .normal)
        segmentControl.indicatorView.backgroundColor = rgb(0xFA6400)
        segmentControl.indicatorViewSize = CGSize(width: 34, height: 3)
        
        //
        segmentControl.selectedSegmentIndex = uiType.rawValue
        setupPages()
    }

    func setupPages() {
        for i in 0..<2 {
            let vc = Purchase2CateVC()
            vc.uiType = Purchase2CateVC.UIType(rawValue: i)!
            vc.apiType = apiType
            vc.delegate = self
            items.append(vc)
        }
        
        let index = uiType.rawValue
        let showVC = items[index]
        
        pageVC = UIPageViewController(transitionStyle: .scroll, navigationOrientation: .horizontal, options: nil)
        pageVC?.setViewControllers([showVC], direction: .forward, animated: false, completion: nil)
        pageVC?.dataSource = self
        pageVC?.delegate = self
        
        pageView.addSubview(pageVC!.view)
        pageVC!.view.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
    }

    @IBAction func segmentValueDidChange(_ sender: XSIndicatorSegmentedControl) {
        guard let showVC = pageVC?.viewControllers?.first as? Purchase2CateVC else {
            return
        }
        let index = items.firstIndex(of: showVC)!
        let direction: UIPageViewController.NavigationDirection = sender.selectedSegmentIndex > index ? .forward : .reverse
        let nextVC = items[sender.selectedSegmentIndex]
        pageVC?.setViewControllers([nextVC], direction: direction, animated: true, completion: nil)
        //
        uiType = Purchase2CateVC.UIType(rawValue: sender.selectedSegmentIndex)!
    }
}


extension Purchase2VC: UIPageViewControllerDataSource, UIPageViewControllerDelegate {
    
    func pageViewController(_ pageViewController: UIPageViewController, viewControllerBefore viewController: UIViewController) -> UIViewController? {
        var index = items.firstIndex(of: viewController as! Purchase2CateVC)!
        index -= 1
        if index < 0 {
            return nil
        }
        return items[index]
    }
    
    func pageViewController(_ pageViewController: UIPageViewController, viewControllerAfter viewController: UIViewController) -> UIViewController? {
        var index = items.firstIndex(of: viewController as! Purchase2CateVC)!
        index += 1
        if index >= items.count {
            return nil
        }
        return items[index]
    }
    
    func pageViewController(_ pageViewController: UIPageViewController, didFinishAnimating finished: Bool, previousViewControllers: [UIViewController], transitionCompleted completed: Bool) {
        guard let showVC = pageViewController.viewControllers?.first as? Purchase2CateVC else {
            return
        }
        let index = items.firstIndex(of: showVC)
        segmentControl.selectedSegmentIndex = index!
    }
}
