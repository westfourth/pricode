//
//  Purchase2ShortCell.swift
//  Sp
//
//  Created by mac on 2020/11/16.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class Purchase2ShortCell: UICollectionViewCell {

    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var button: UIButton!
    @IBOutlet weak var gradientView: UIView!
    
    var item: VideoItem? {
        didSet {
            guard item != nil else { return }
            imageView.kf.setImage(with: item!.coverImg)
            button.setTitle(String(item!.fakeLikes), for: .normal)
        }
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        gradient()
    }
    
    func gradient() {
        object_setClass(gradientView.layer, CAGradientLayer.self)
        let layer = gradientView.layer as! CAGradientLayer
        layer.colors = [UIColor.clear.cgColor, UIColor.black.withAlphaComponent(0.6).cgColor]
    }

    class func changeFlowLayout(layout: UICollectionViewFlowLayout) {
        let width = (UIScreen.main.bounds.width - 2) / 2
        layout.itemSize = CGSize(width: width, height: width * 236 / 178)
        layout.minimumLineSpacing = 2
        layout.minimumInteritemSpacing = 2
    }
}
