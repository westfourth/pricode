//
//  Purchase2LongCell.swift
//  Sp
//
//  Created by mac on 2020/11/16.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class Purchase2LongCell: UICollectionViewCell {
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var gradientView: UIView!
    @IBOutlet weak var personLabel: UILabel!
    @IBOutlet weak var timeLabel: UILabel!
    @IBOutlet weak var coinButton: UIButton!
    @IBOutlet weak var titleLabel: UILabel!
    
    private lazy var HDImgView: UIImageView = {
        return UIImageView(image: AVRecommendVerticalSixGridCell.HDImg)
    }()
    
    var isBigMode = true  //  是否是大图显示
    
    var item: VideoItem? {
        didSet {
            guard let item = self.item else { return }
            imageView.kf.setImage(with: item.coverImg, placeholder: AVCycleScrollViewCell.bannerDefaultImg)
            titleLabel.text = item.title
            titleLabel.font = isBigMode ? font(14, .semibold) : font(11)
            self.layer.cornerRadius = isBigMode ? 10 : 5;
            imageView.layer.cornerRadius = isBigMode ? 10 : 5;
            personLabel.text = "购买人数：\(item.purNum)人"
            timeLabel.text = timeText(count: item.playTime)
            HDImgView.isHidden = !item.hd
            //
            coinButton.setTitle(String(item.price), for: .normal)
            //
            if item.videoPayMark == .pay {
                coinButton.isHidden = false
                coinButton.setBackgroundImage(UIImage(named: "purchase2_coin"), for: .normal)
                coinButton.setTitle(String(item.price), for: .normal)
            } else if item.videoPayMark == .vip {
                coinButton.isHidden = false
                coinButton.setBackgroundImage(UIImage(named: "ic_VIP视频"), for: .normal)
                coinButton.setTitle(nil, for: .normal)
            } else {
                coinButton.isHidden = true
                coinButton.setBackgroundImage(nil, for: .normal)
                coinButton.setTitle(nil, for: .normal)
            }
        }
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        gradient()
        addSubview(HDImgView)
        HDImgView.snp.makeConstraints { (make) in
            make.left.top.equalToSuperview()
            make.width.equalTo(28)
            make.height.equalTo(14)
        }
    }
    
    func gradient() {
        object_setClass(gradientView.layer, CAGradientLayer.self)
        let layer = gradientView.layer as! CAGradientLayer
        layer.colors = [UIColor.clear.cgColor, UIColor.black.withAlphaComponent(0.6).cgColor]
    }
    
    func timeText(count: Int) -> String {
        let hours: Int = count / 3600
        let minutes: Int = (count % 3600) / 60
        let seconds: Int = count % 60
        var text = ""
        if hours > 0 {
            text = String(format: "%02d:%02d:%02d", hours, minutes, seconds)
        } else {
            text = String(format: "%02d:%02d", minutes, seconds)
        }
        return text
    }
    
    class func changeFlowLayout(layout: UICollectionViewFlowLayout, isBigMode: Bool = true) {
        if isBigMode {
            let width = UIScreen.main.bounds.width - 10 * 2
            layout.itemSize = CGSize(width: width, height: width * 196 / 366 + 30)
            layout.minimumLineSpacing = 20
            layout.minimumInteritemSpacing = 20
            layout.sectionInset = UIEdgeInsets.zero
        } else {
            layout.itemSize = CGSize(width: 164, height: 112)
            layout.minimumLineSpacing = 8
            layout.minimumInteritemSpacing = 8
            layout.sectionInset = UIEdgeInsets.zero
        }
    }
}
