//
//  Purchase2CateVC.swift
//  Sp
//
//  Created by mac on 2020/11/16.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class Purchase2CateVC: UIViewController {
    weak var delegate: Purchase2VC?
    @IBOutlet weak var collectionView: UICollectionView!
    @IBOutlet weak var flowLayout: UICollectionViewFlowLayout!
    
    //  显示类型
    enum UIType: Int {
        case short      //  小视频
        case long       //  视频
    }
    
    enum APIType: Int {
        case purchase   //  我的购买
        case favorite   //  我的收藏
        case history    //  观看记录
    }
    
    var uiType: UIType = .short     //  UI显示
    var apiType: APIType = .purchase
    var items = [VideoItem]()
    var page: Int = 1
    var inRequest = false       //  正在请求

    override func viewDidLoad() {
        super.viewDidLoad()
        
        //
        var nib = UINib(nibName: "Purchase2ShortCell", bundle: nil)
        collectionView.register(nib, forCellWithReuseIdentifier: "S");
        nib = UINib(nibName: "Purchase2LongCell", bundle: nil)
        collectionView.register(nib, forCellWithReuseIdentifier: "L");
        
        //
        if uiType == .short {
            Purchase2ShortCell.changeFlowLayout(layout: flowLayout)
        } else {
            Purchase2LongCell.changeFlowLayout(layout: flowLayout)
        }
        
        //
        getData()
    }
}

//  网络数据
extension Purchase2CateVC {
    
    func getData() {
        if inRequest {
            return
        }
        switch apiType {
        case .purchase:
            getPurchaseData()
            collectionView.loadMoreBlock = { [weak self] in
                self?.getPurchaseData()
            }
        case .favorite:
            getFavoriteData()
            collectionView.loadMoreBlock = { [weak self] in
                self?.getFavoriteData()
            }
        case .history:
            getWatchData()
        }
    }

    func getPurchaseData() {
        let req = PruchasedVideoReq()
        req.userId = NetDefaults.userInfo?.userId ?? 0
        req.page = page
        req.videoType = uiType == .short ? 1 : 2
        inRequest = true
        Session.request(req) { (error, resp) in
            self.inRequest = false
            guard error == nil  else{
                self.collectionView.state = .failed
                return
            }
            guard let array = resp as? [VideoItem], !array.isEmpty else{
                if self.page == 1 {
                    self.collectionView.state = .empty
                }
                return
            }
            self.collectionView.state = .normal
            if self.page == 1 {
                self.items = array
            } else {
                self.items.append(contentsOf: array)
            }
            self.page += 1
            self.collectionView.reloadData()
        }
    }
    
    func getFavoriteData() {
        let req = CollectVideoReq()
        req.userId = NetDefaults.userInfo?.userId ?? 0
        req.page = page
        req.videoType = uiType == .short ? 1 : 2
        inRequest = true
        Session.request(req) { (error, resp) in
            self.inRequest = false
            guard error == nil  else{
                self.collectionView.state = .failed
                return
            }
            guard let array = resp as? [VideoItem], !array.isEmpty else{
                if self.page == 1 {
                    self.collectionView.state = .empty
                }
                return
            }
            self.collectionView.state = .normal
            if self.page == 1 {
                self.items = array
            } else {
                self.items.append(contentsOf: array)
            }
            self.page += 1
            self.collectionView.reloadData()
        }
    }
    
    func getWatchData() {
        if uiType == .short {
            items = Defaults.shortWatchItems
        } else {
            items = Defaults.longWatchItems
        }
        self.collectionView.reloadData()
    }
}


extension Purchase2CateVC: UICollectionViewDataSource, UICollectionViewDelegate {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return items.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let item = items[indexPath.item]
        if uiType == .short {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "S", for: indexPath) as! Purchase2ShortCell
            cell.item = item
            return cell
        } else {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "L", for: indexPath) as! Purchase2LongCell
            cell.item = item
            return cell
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let item = items[indexPath.item]
        if uiType == .short {
            let vc = ShortVideoListVC()
            vc.currentPlayingIndexPath = indexPath
            vc.videoItems = items
            vc.hidesBottomBarWhenPushed = true
            delegate?.navigationController?.pushViewController(vc, animated: true)
        } else {
            let vc = PlayerController()
            vc.videoId = item.videoId
            delegate?.navigationController?.pushViewController(vc, animated: true)
        }
    }
    
}
