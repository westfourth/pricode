//
//  TopicDetailVC.swift
//  Sp
//
//  Created by mac on 2020/9/30.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class TopicDetailVC: UIViewController {
    
    @IBOutlet weak var tableView: UITableView!
    
    var ads:[AdvertiseResp] = [AdvertiseResp]()
    
    var items:[TimeLineItem] = [TimeLineItem]()
    var item:CommunityTopicItem!
    
    private lazy var bannerDeleteMaskView: UsersDynamicBannerDeleteMaskView = {
        let view = UsersDynamicBannerDeleteMaskView()
        return view
    }()
    
    private lazy var emptyImg: UIImage = {
        return UIImage()
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationItem.title = item.topicName
        view.backgroundColor = RGB(0xff141516)
        tableView.register(UINib(nibName: "TimeLineCell", bundle: Bundle.main), forCellReuseIdentifier: "TimeLineCell")
        tableView.state = .loading
        tableView.mj_header = getCommonMJHeader(refreshingTarget: self, headerRefreshCallback: #selector(onRefresh))
        tableView.mj_footer = getCommonMJFooter(refreshingTarget: self, footerRefreshCallback: #selector(onLoadMore))
        loadData(true)
        loadAdsData()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.setNavigationBarHidden(false, animated: animated)
        navigationController?.navigationBar.setBackgroundImage(emptyImg, for: .default)
        navigationController?.navigationBar.shadowImage = emptyImg
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.navigationController?.setNavigationBarHidden(false, animated: animated)
    }
    
    lazy var headerView: UIView = {
        let r:CGFloat = 165 / 336
        let h :CGFloat = (UIScreen.main.bounds.width - 12 * 2) * r
        let v = UIView(frame: CGRect(x: 0, y: 0, width: view.bounds.width, height: h + 24))
        v.backgroundColor = RGB(0x141516)
        v.addSubview(pagerView)
        pagerView.snp.makeConstraints { (make) in
            make.top.equalToSuperview()
            make.left.right.equalToSuperview().inset(12)
            make.height.equalTo(h)
        }
        v.addSubview(pageControl)
        return v
    }()
    
    
    lazy var pagerView: CycleScrollView = {
        let cycleScrollView = CycleScrollView()
        cycleScrollView.delegate = self
        cycleScrollView.dataSource = self
        cycleScrollView.register(UINib(nibName: "DateSexBannerCell", bundle: Bundle.main), forCellWithReuseIdentifier: "DateSexBannerCell")
        cycleScrollView.hidesPageControl = true
        cycleScrollView.layer.masksToBounds = true
        cycleScrollView.layer.cornerRadius = 4
        return cycleScrollView
    }()
    
    private lazy var pageControl: CarouselPageControl = {
        let view = CarouselPageControl()
        return view
    }()
    
    func loadAdsData() {
        ads = AdManager.shared.topicBanners(item.topicId)
        if !ads.isEmpty {
            tableView.tableHeaderView = headerView
            pageControl.snp.makeConstraints { (make) in
                make.centerX.equalToSuperview()
                make.bottom.equalTo(pagerView.snp.bottom).offset(-10)
                make.width.equalTo(CGFloat(ads.count) * 14)
                make.height.equalTo(6)
            }
        }
        pageControl.isHidden = ads.count <= 1
        pageControl.numberOfPages = ads.count
    }
    
    @objc func onRefresh() {
        loadData(true)
    }
    
    
    @objc func onLoadMore() {
        loadData(false)
    }
    
    var isRequesting = false
    var page:Int = 1
    
    func loadData(_ refresh:Bool) {
        if isRequesting {return}
        isRequesting = true
        let callback:(Error?,Any?)->Void = {[weak self] (e,resp) in
            self?.isRequesting = false
            self?.tableView.mj_header?.endRefreshing()
            self?.tableView.mj_footer?.endRefreshing()
            guard var array = resp as? [TimeLineItem], !array.isEmpty else {
                if refresh {
                    self?.tableView.state = .empty
                } else {
                    self?.tableView.state = .normal
                    if !(self?.items.isEmpty ?? false) {
                        self?.tableView.mj_footer?.endRefreshingWithNoMoreData()
                    }
                }
                self?.tableView.state = self?.items.isEmpty ?? false ? .empty:.normal
                return
            }
            array = array.map {
                if let videoUrl = $0.video?.videoUrl {
                    $0.video?.videoUrl = URL(string: videoUrl.absoluteString.replacingOccurrences(of: "?path=", with: "/dynamic?path="))
                }
                return $0
            }
            
            if refresh {
                self?.items = array
            } else {
                self?.items.append(contentsOf: array)
            }
            self?.tableView.reloadData()
            self?.tableView.state = .normal
        }
        
        let req = TimeLineListNewReq()
        if !refresh && !self.items.isEmpty {
            req.lastDynamicId = self.items.last?.dynamicId ?? 0
        }
        req.topicId = item.topicId
        req.loadType = 0
        Session.request(req, callback: callback)
    }
}

extension TopicDetailVC:CycleScrollViewDataSource {
    func numberOfItems(in cycleScrollView: CycleScrollView) -> Int {
        return ads.count
    }
    
    func cycleScrollView(_ cycleScrollView: CycleScrollView, cellForItemAt index: Int) -> UICollectionViewCell {
        let cell = pagerView.dequeueReusableCell(withReuseIdentifier: "DateSexBannerCell", for: index) as! DateSexBannerCell
        cell.item = ads[index]
        return cell
    }
}

extension TopicDetailVC:CycleScrollViewDelegate {
    func cycleScrollView(_ cycleScrollView: CycleScrollView, didSelectItemAt index: Int) {
        let ad = ads[index]
        guard let url = ad.adJump else {return}
        // 广告点击
        InnerIntercept.open(url)
    }
    
    func cycleScrollView(_ cycleScrollView: CycleScrollView, didScrollFromIndex fromIndex: Int, toIndex: Int) {
        pageControl.currentPage = toIndex
    }
    
}



// MARK: -UITableViewDataSource && Delegate
extension TopicDetailVC:UITableViewDataSource,UITableViewDelegate {
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "TimeLineCell") as! TimeLineCell
        cell.item = items[indexPath.row]
        cell.delegate = self
        return cell
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return items.count
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return TimeLineCell.height(items[indexPath.row])
    }
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return 0
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 0
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        return nil
    }
    
    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        return nil
    }
}


extension TopicDetailVC:TimeLineCellDelegate {
    
    func timeLineCell(cell: TimeLineCell, playVideo item:TimeLineItem ) {
        
        guard NetDefaults.userInfo?.freeWatches == -1 else {
            PurchaseVipAlert.showPurchaseVipAlert()
            return
        }
        
        guard let video = item.video else { return }
        let vc = ShortVideoListVC()
        vc.fromDynamic = true
        vc.currentPlayingIndexPath = IndexPath(item: 0, section: 0)
        vc.videoItems = [video]
        vc.hidesBottomBarWhenPushed = true
        self.navigationController?.show(vc, sender: nil)
    }
    
    func timeLineCell(cell: TimeLineCell, activityItem item: TimeLineItem) {
//        let tabbar = UIApplication.shared.keyWindow?.rootViewController as! UITabBarController
//        tabbar.selectedIndex = 1
//        self.navigationController?.popToRootViewController(animated: true)
//        guard let navi = tabbar.selectedViewController as? UINavigationController, let classyVC = navi.topViewController as? ClassyVC else {return}
//        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() +  0.5) {
//            classyVC.switchToCategoryBar(type: .leapboardActivity)
//        }
        
        let vc = ChatVC()
        vc.fromUserId = item.userId
        vc.name = item.nickName
        vc.hidesBottomBarWhenPushed = true
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    func timeLineCell(cell: TimeLineCell, avatar: UIImageView, item: TimeLineItem) {
        let vc = UsersDynamicVC()
        vc.userId = item.userId
        vc.initPageType = .dynamic
        vc.attentionClosure = { [weak self] flag in
            if item.isAttention != flag {
                item.isAttention = flag
                self?.tableView.reloadData()
            }
        }
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    func timeLineCell(cell: TimeLineCell, focus: UIButton, item: TimeLineItem) {
        Animation.scaleBounce(focus)
        if item.sourceType == .beauty {
            // 约更多
            let appDelegate = UIApplication.shared.delegate as! AppDelegate
            guard let navi = appDelegate.currentNavigationController else {return}
            if navi.topViewController is Community2VC {
                let tabbar = UIApplication.shared.keyWindow?.rootViewController as! UITabBarController
                tabbar.selectedIndex = 3
                navi.popViewController(animated: true)
                DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 0.5) {
                    let appDelegate1 = UIApplication.shared.delegate as! AppDelegate
                    guard let navi1 = appDelegate1.currentNavigationController else {return}
                    let vc = navi1.topViewController! as! ChatSexVC
                    vc.topView.currentIndex = 2
                    vc.chatTopBar(didSelect: 2)
                }
            }
        } else if item.sourceType  == .portray {
            //写真
            let vc = PhotoVC()
            vc.hidesBottomBarWhenPushed = true
            self.navigationController?.pushViewController(vc, animated: true)
        } else if item.sourceType == .feautures {
            // 花絮
            let vc = UsersDynamicVC()
            vc.userId = item.userId
            vc.initPageType = .highlights
            self.navigationController?.pushViewController(vc, animated: true)
        }
    }
    
    func timeLineCell(cell: TimeLineCell, like: UIButton,item:TimeLineItem) {
        Animation.scaleBounce(like)
        like.isSelected = !like.isSelected
        var count = Int(like.title(for: .normal) ?? "0") ?? 0
        if like.isSelected {
            //点赞
            let req = TimeLineLikeReq()
            req.dynamicId = item.dynamicId
            Alert.showLoading(parentView: self.view)
            Session.request(req) { (e, resp) in
                Alert.hideLoading()
                guard e == nil else {
                    mm_showToast(e!.localizedDescription)
                    like.isSelected = false
                    return
                }
                count = count + 1
                like.setTitle("\(count)", for: .normal)
                item.commentNum = count
                item.isLike = true
                mm_showToast("點贊成功！",type: .succeed)
            }
        } else {
            let req = TimeLineCancelLikeReq()
            req.dynamicId = item.dynamicId
            Alert.showLoading(parentView: self.view)
            Session.request(req) { (e, resp) in
                Alert.hideLoading()
                guard e == nil else {
                    mm_showToast(e!.localizedDescription)
                    like.isSelected = true
                    return
                }
                count = count >= 0 ? count - 1:0
                like.setTitle("\(count)", for: .normal)
                item.commentNum = count
                item.isLike = false
                mm_showToast("取消點贊成功！",type: .succeed)
            }
        }
    }
    
    func timeLineCell(cell: TimeLineCell, comment: UIButton,item:TimeLineItem) {
        Animation.scaleBounce(comment)
        guard item.status == .approved else {
            let warning = item.status == .reviewing ? "動態審核中，請耐心等待哦～" :"審核失敗，理由:\(item.notPass)"
            mm_showToast(warning)
            return
        }
        let commentVC = CommentVC()
        commentVC.timelineItem = item
        present(commentVC, animated: true, completion: nil)
    }
    
    func timeLineCell(cell: TimeLineCell, tapCover item: TimeLineItem,index:Int) {
        
        guard NetDefaults.userInfo?.freeWatches == -1 else {
            PurchaseVipAlert.showPurchaseVipAlert()
            return
        }
        
        let urls = item.dynamicImg.map{ URL(string: $0)! }
        bannerDeleteMaskView.removeFromSuperview()
        UIApplication.shared.keyWindow!.addSubview(bannerDeleteMaskView)
        bannerDeleteMaskView.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
        bannerDeleteMaskView.bannerListData = urls
        bannerDeleteMaskView.nicknameLabel.text = item.nickName
        bannerDeleteMaskView.initPageIndex = index
        bannerDeleteMaskView.startAnimation()
    }
}
