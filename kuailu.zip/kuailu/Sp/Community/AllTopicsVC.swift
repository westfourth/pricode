//
//  AllTopicsVC.swift
//  Sp
//
//  Created by mac on 2020/9/30.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class AllTopicsVC: UIViewController {
    
    @IBOutlet weak var tableView: UITableView!
    
    private lazy var emptyImg: UIImage = {
        return UIImage()
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = RGB(0x141516)
        navigationItem.title = "全部話題"
  
        tableView.register(UINib(nibName: "AllTopicCell", bundle: Bundle.main), forCellReuseIdentifier: "AllTopicCell")
        tableView.backgroundColor = .none
        tableView.separatorStyle = .none
        tableView.state = .loading
        tableView.mj_header = getCommonMJHeader(refreshingTarget: self, headerRefreshCallback: #selector(onRefresh))
        tableView.mj_footer = getCommonMJFooter(refreshingTarget: self, footerRefreshCallback: #selector(onLoadMore))
        loadData(true)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.setNavigationBarHidden(false, animated: animated)
        navigationController?.navigationBar.setBackgroundImage(emptyImg, for: .default)
        navigationController?.navigationBar.shadowImage = emptyImg
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        navigationController?.setNavigationBarHidden(false, animated: animated)
    }
    
    @objc func onRefresh() {
        loadData(true)
    }
    
    @objc func onLoadMore() {
        loadData(false)
    }
    
    var isRequesting = false
    
    var items:[CommunityTopicItem] = [CommunityTopicItem]()
    
    func loadData(_ refresh:Bool) {
        if isRequesting {return}
        isRequesting = true
        let callback:(Error?,Any?)->Void = {[weak self] (e,resp) in
            self?.isRequesting = false
            self?.tableView.mj_header?.endRefreshing()
            self?.tableView.mj_footer?.endRefreshing()
            guard let array = resp as? [CommunityTopicItem], !array.isEmpty else {
                if refresh {
                    self?.tableView.state = .empty
                } else {
                    self?.tableView.state = .normal
                    if !(self?.items.isEmpty ?? false) {
                        self?.tableView.mj_footer?.endRefreshingWithNoMoreData()
                    }
                }
                self?.tableView.state = self?.items.isEmpty ?? false ? .empty:.normal
                return
            }
            if refresh {
                self?.items = array
            } else {
                self?.items.append(contentsOf: array)
            }
            self?.tableView.reloadData()
            self?.tableView.state = .normal
        }
        
        let req = CommunityAllTopicListReq()
        if !refresh && !self.items.isEmpty {
            req.topicId = self.items.last?.topicId ?? 0
        }
        Session.request(req, callback: callback)
    }

}

// MARK: -UITableViewDataSource && Delegate
extension AllTopicsVC:UITableViewDataSource,UITableViewDelegate {
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "AllTopicCell") as! AllTopicCell
        cell.item = items[indexPath.section]
        return cell
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        return items.count
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let vc = TopicDetailVC()
        vc.item = items[indexPath.section]
        vc.hidesBottomBarWhenPushed = true
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 105
    }
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return .leastNonzeroMagnitude
    }
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return .leastNonzeroMagnitude
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        return nil
    }
    
    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        return nil
    }
}
