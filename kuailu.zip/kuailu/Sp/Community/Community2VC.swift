//
//  Community2VC.swift
//  Sp
//
//  Created by mac on 2020/9/30.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit
import JXSegmentedView
class Community2VC: UIViewController {
    
    private let sectionH:CGFloat = 44
    
    private var headHeight:CGFloat =  160
    
    private let titles =  ["精選","廣場","關注"]
    
    private lazy var pagingView: JXPagingView = JXPagingListRefreshView(delegate: self)
    
    private let dataSource: JXSegmentedTitleDataSource = JXSegmentedTitleDataSource()
    
    private var controllers:[UIViewController & JXPagingViewListViewDelegate] = [UIViewController & JXPagingViewListViewDelegate]()
    
    private lazy var publish:UIImageView = {
        let v = UIImageView()
        let tap = UITapGestureRecognizer(target: self, action:#selector(publishAction))
        v.addGestureRecognizer(tap)
        v.isUserInteractionEnabled = true
        v.contentMode = .scaleAspectFit
        v.image = UIImage(named: "chat_publish")
        return v
    }()
    
    private lazy var topView:ComminityTopView = {
        let v = Bundle.main.loadNibNamed("ComminityTopView", owner: nil, options: [:])?.first as! ComminityTopView
        return v
    }()
    
    private lazy var headerView:CommunityHeaderView = {
        let v = Bundle.main.loadNibNamed("CommunityHeaderView", owner: nil, options: [:])?.first as! CommunityHeaderView
        v.backgroundColor = RGB(0xff141516)
        v.delegate = self
        return v
    }()
    
    private lazy var segmentedView: JXSegmentedView = {
        let v = JXSegmentedView(frame: CGRect(x: 0, y: 0, width: UIScreen.main.bounds.width, height:sectionH))
        let line = UIView()
        line.frame = CGRect(x: 10, y: 43, width: UIScreen.main.bounds.width - 20, height: 1.0)
        line.backgroundColor = rgb(0x262B42)
        v.addSubview(line)
        return v
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = RGB(0xff141516)
        let r:CGFloat = 165 / 336
        let h :CGFloat = UIScreen.main.bounds.width * r
        headHeight = headHeight + h + 12
        
        configurePagingView()
        view.addSubview(topView)
        let v:CGFloat = (UIApplication.shared.windows.first?.safeAreaInsets.top ?? 0 ) <= 20 ? 20 :44
        topView.frame =  CGRect(x: 0, y: 0, width: view.bounds.width, height: v + 44)
        
        for i in 0..<3 {
            let vc = TimeLineVC()
            vc.publish.isHidden = true
            vc.type = i == 0 ? .classic:i == 1 ? .mine:.focus
            controllers.append(vc)
        }
        segmentedView.defaultSelectedIndex = 1
        
        view.addSubview(publish)
        publish.snp.makeConstraints { (make) in
            make.bottom.equalTo(-kBottom)
            make.right.equalTo(-12)
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.setNavigationBarHidden(true, animated: animated)
        getUserinfo()
        if AdManager.shared.communityBanners.isEmpty {
            headHeight = 160
            pagingView.reloadData()
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.navigationController?.setNavigationBarHidden(false, animated: animated)
    }
    
    private func configurePagingView() {
        dataSource.titles = titles
        dataSource.titleSelectedColor = .white
        dataSource.titleNormalColor = RGB(0xffCFCFCF)
        segmentedView.isContentScrollViewClickTransitionAnimationEnabled = false
        dataSource.titleNormalFont = UIFont.systemFont(ofSize: 16)
        dataSource.titleSelectedFont = UIFont.systemFont(ofSize: 16,weight: .medium)
        segmentedView.backgroundColor = RGB(0xff141516)
        segmentedView.delegate = self
        segmentedView.dataSource = dataSource
        
        segmentedView.indicators = indicators()
        segmentedView.contentEdgeInsetRight = 220
        segmentedView.contentEdgeInsetLeft = 25
        
        pagingView.mainTableView.gestureDelegate = self
        
        self.view.addSubview(pagingView)
        pagingView.mainTableView.backgroundColor = .clear
        let v:CGFloat = (UIApplication.shared.windows.first?.safeAreaInsets.top ?? 0 ) <= 20 ? 20 :44
        pagingView.frame = CGRect(x: 0, y: v + 44, width: self.view.bounds.width, height: self.view.bounds.height -  v - 44)
        pagingView.pinSectionHeaderVerticalOffset = 0
        
        segmentedView.listContainer = pagingView.listContainerView
        
        //扣边返回处理，下面的程式码要加上
        pagingView.listContainerView.scrollView.panGestureRecognizer.require(toFail: self.navigationController!.interactivePopGestureRecognizer!)
        pagingView.mainTableView.panGestureRecognizer.require(toFail: self.navigationController!.interactivePopGestureRecognizer!)
    }
    
    private func indicators()->[JXSegmentedIndicatorLineView] {
        let width :CGFloat = 35
        var items = [JXSegmentedIndicatorLineView]()
        for _ in 0..<4 {
            let lineView = JXSegmentedIndicatorLineView()
            lineView.indicatorColor = RGB(0xffFA6400)
            lineView.indicatorWidth = width
            lineView.lineStyle = .lengthenOffset
            lineView.clipsToBounds = true
            lineView.layer.cornerRadius = 1.0
            items.append(lineView)
        }
        return items
    }
    
    @objc private func publishAction()  {
        
        guard NetDefaults.userInfo?.freeWatches == -1 else {
            PurchaseVipAlert.showPurchaseVipAlert()
            return
        }
        
        guard UploadConfig.shared.info.allow else {
            mm_showToast("系統維護中，暫不能上傳視頻!")
            return
        }
        let vc = UploadImageVC()
        vc.hidesBottomBarWhenPushed = true
        navigationController?.pushViewController(vc, animated: true)
    }
    
    private func getUserinfo() {
        Session.request(FetchUserInfoReq()) { (error, resp) in }
    }
}

extension Community2VC:CommunityHeaderViewDelegate {
    
    func topicItemAction(_ item: CommunityTopicItem) {
        let vc = TopicDetailVC()
        vc.item = item
        vc.hidesBottomBarWhenPushed = true
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    func allTopicsAction() {
        let vc = AllTopicsVC()
        vc.hidesBottomBarWhenPushed = true
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
}

extension Community2VC: JXPagingViewDelegate {
    
    func tableHeaderViewHeight(in pagingView: JXPagingView) -> Int {
        return Int(headHeight)
    }
    
    func tableHeaderView(in pagingView: JXPagingView) -> UIView {
        return headerView
    }
    
    func heightForPinSectionHeader(in pagingView: JXPagingView) -> Int {
        return Int(sectionH)
    }
    
    func viewForPinSectionHeader(in pagingView: JXPagingView) -> UIView {
        return segmentedView
    }
    
    func numberOfLists(in pagingView: JXPagingView) -> Int {
        return self.controllers.count
    }
    
    func pagingView(_ pagingView: JXPagingView, initListAtIndex index: Int) -> JXPagingViewListViewDelegate {
        return  self.controllers[index]
    }
    
    func segmentedView(_ segmentedView: JXSegmentedView, didScrollSelectedItemAt index: Int) {
        segmentedView.selectItemAt(index: index)
    }
}

extension Community2VC: JXSegmentedViewDelegate {
    
    func segmentedView(_ segmentedView: JXSegmentedView, didSelectedItemAt index: Int) {
        self.navigationController?.interactivePopGestureRecognizer?.isEnabled = true
    }

}

extension Community2VC: JXPagingMainTableViewGestureDelegate {
    
    func mainTableViewGestureRecognizer(_ gestureRecognizer: UIGestureRecognizer, shouldRecognizeSimultaneouslyWith otherGestureRecognizer: UIGestureRecognizer) -> Bool {
        //禁止segmentedView左右滑动的时候，上下和左右都可以滚动
        if otherGestureRecognizer == segmentedView.collectionView.panGestureRecognizer {
            return false
        }
        return gestureRecognizer.isKind(of: UIPanGestureRecognizer.self) && otherGestureRecognizer.isKind(of: UIPanGestureRecognizer.self)
    }
    
}
