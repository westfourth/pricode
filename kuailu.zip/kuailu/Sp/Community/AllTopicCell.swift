//
//  AllTopicCell.swift
//  Sp
//
//  Created by mac on 2020/9/30.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class AllTopicCell: UITableViewCell {
    
    @IBOutlet weak var cover: UIImageView!
    @IBOutlet weak var name: UILabel!
    @IBOutlet weak var content: UILabel!
    @IBOutlet weak var count: UILabel!
    
    private lazy var bottomLineView: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor.white.withAlphaComponent(0.5)
        return view
    }()
    
    var item:CommunityTopicItem? {
        didSet {
            guard let item = item else { return }
            cover.kf.setImage(with: item.topicLogo?.column2,placeholder:Sensitive.default_bg,options: [.transition(.fade(0.25))])
            name.text = item.topicName
            content.text = item.topicDesc
            count.text = item.dynamicNum == 0 ? "":"\(item.dynamicNum)個動態"
        }
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        backgroundColor = .none
        selectionStyle = .none
        addSubview(bottomLineView)
        bottomLineView.snp.makeConstraints { (make) in
            make.left.right.bottom.equalToSuperview()
            make.height.equalTo(0.5)
        }
    }
}
