//
//  ComminityTopView.swift
//  Sp
//
//  Created by mac on 2020/8/3.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class ComminityTopView: UIView {
    @IBOutlet weak var avatar: UIImageView!
    
    override func awakeFromNib() {
        if let user = NetDefaults.userInfo {
            avatar.kf.setImage(with: user.logo,placeholder:Sensitive.avatar,options: [.transition(.fade(0.25))])
        }
    }
    
    @IBAction func avatarAction(_ sender: Any) {
        guard let navi = current_navi() else {return}
        guard let user = NetDefaults.userInfo else {return}
        let vc = UsersDynamicVC()
        vc.userId = user.userId
        navi.pushViewController(vc, animated: true)
    }
    
    @IBAction func messageAction(_ sender: Any) {
        guard let navi = current_navi() else {return}
        let vc = MessageVC()
        vc.hidesBottomBarWhenPushed = true
        navi.pushViewController(vc, animated: true)
    }
    
    @IBAction func backAction(_ sender: Any) {
        guard let navi = current_navi() else {return}
        navi.popViewController(animated: true)
    }

    
    private func current_navi()->UINavigationController? {
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        guard let navi = appDelegate.currentNavigationController else {
            return nil
        }
        return navi
    }
}
