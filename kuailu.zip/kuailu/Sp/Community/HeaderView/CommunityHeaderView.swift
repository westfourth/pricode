//
//  CommunityHeaderView.swift
//  Sp
//
//  Created by mac on 2020/9/30.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

@objc protocol CommunityHeaderViewDelegate {
    ///点击
    func allTopicsAction()
    
    func topicItemAction(_ item:CommunityTopicItem)
    
}

class CommunityHeaderView: UIView {

    weak var delegate: CommunityHeaderViewDelegate?

    @IBOutlet weak var collectionView: UICollectionView!
    
    var ads:[AdvertiseResp] = [AdvertiseResp]()
    
    lazy var pagerView: CycleScrollView = {
        let cycleScrollView = CycleScrollView()
        cycleScrollView.delegate = self
        cycleScrollView.dataSource = self
        cycleScrollView.register(UINib(nibName: "DateSexBannerCell", bundle: Bundle.main), forCellWithReuseIdentifier: "DateSexBannerCell")
        cycleScrollView.hidesPageControl = true
        cycleScrollView.layer.masksToBounds = true
        cycleScrollView.layer.cornerRadius = 4
        return cycleScrollView
    }()
    
    private lazy var pageControl: CarouselPageControl = {
        let view = CarouselPageControl()
        return view
    }()
    
    override func awakeFromNib() {
        super.awakeFromNib()
        collectionView.collectionViewLayout.leftAligment()
        collectionView.register(UINib(nibName: "CommunityTopicCell", bundle: Bundle.main), forCellWithReuseIdentifier: "CommunityTopicCell")
        addSubview(pagerView)
        addSubview(pageControl)
        loadTopicsData()
        loadAdData()
    }
    
    func loadAdData() {
        ads = AdManager.shared.communityBanners
        let r:CGFloat = 165 / 336
        let h :CGFloat = (UIScreen.main.bounds.width - 12 * 2) * r
        if !ads.isEmpty {
            pagerView.snp.makeConstraints { (make) in
                make.top.equalTo(12)
                make.left.right.equalToSuperview().inset(12)
                make.height.equalTo(h)
            }
            pageControl.snp.makeConstraints { (make) in
                make.centerX.equalToSuperview()
                make.bottom.equalTo(pagerView.snp.bottom).offset(-10)
                make.width.equalTo(CGFloat(ads.count) * 14)
                make.height.equalTo(6)
            }
            pageControl.isHidden = ads.count <= 1
        }
        pageControl.numberOfPages = ads.count
    }
    
    var topics:[CommunityTopicItem] = [CommunityTopicItem]()
    
    func loadTopicsData() {
        Session.request(CommunityHomeTopicListReq()) { (e, resp) in
            guard e == nil  else {return}
            guard let topics = resp as? [CommunityTopicItem] else {return}
            self.topics = topics
            self.collectionView.reloadData()
        }
    }
    
    // 全部话题
    @IBAction func allTopicsAction(_ sender: Any) {
        delegate?.allTopicsAction()
    }
}

extension CommunityHeaderView:CycleScrollViewDataSource {
    func numberOfItems(in cycleScrollView: CycleScrollView) -> Int {
        return ads.count
    }
    
    func cycleScrollView(_ cycleScrollView: CycleScrollView, cellForItemAt index: Int) -> UICollectionViewCell {
        let cell = pagerView.dequeueReusableCell(withReuseIdentifier: "DateSexBannerCell", for: index) as! DateSexBannerCell
        cell.item = ads[index]
        return cell
    }
}

extension CommunityHeaderView:CycleScrollViewDelegate {
    func cycleScrollView(_ cycleScrollView: CycleScrollView, didSelectItemAt index: Int) {
        let ad = ads[index]
        guard let url = ad.adJump else {return}
         //广告点击
        InnerIntercept.open(url)
    }
    
    func cycleScrollView(_ cycleScrollView: CycleScrollView, didScrollFromIndex fromIndex: Int, toIndex: Int) {
        pageControl.currentPage = toIndex
    }
}



//_______________________________________________________________________________________________________________
// MARK: - UICollectionViewDataSource&Delegate
extension CommunityHeaderView:UICollectionViewDataSource,UICollectionViewDelegate,UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return topics.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CommunityTopicCell", for: indexPath) as! CommunityTopicCell
        cell.item = topics[indexPath.row]
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let item = topics[indexPath.row]
        delegate?.topicItemAction(item)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: 146, height: 80)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 4.0
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 4.0
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        return .zero
    }
    
    
}

