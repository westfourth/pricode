//
//  DateSexBannerCell.swift
//  CaoLong
//
//  Created by mac on 2020/8/6.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class DateSexBannerCell: UICollectionViewCell {
    @IBOutlet weak var cover: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        cover.contentMode = .scaleAspectFill
        cover.layer.masksToBounds = true
        cover.layer.cornerRadius = 4
        layer.masksToBounds = true
        layer.cornerRadius = 4
    }
    
    var item:AdvertiseResp? {
        didSet {
            guard let item = item else { return }
            cover.kf.setImage(with: item.adImage?.column0,placeholder:Sensitive.default_bg,options: [.transition(.fade(0.25))])
        }
    }
}
