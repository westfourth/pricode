//
//  CommunityTopicCell.swift
//  Sp
//
//  Created by mac on 2020/9/30.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class CommunityTopicCell: UICollectionViewCell {
    
    @IBOutlet weak var cover: UIImageView!
    @IBOutlet weak var name: UILabel!
    @IBOutlet weak var subName: UILabel!
    
    var item:CommunityTopicItem? {
        didSet {
            guard let item = item else {
                return
            }
            cover.kf.setImage(with: item.topicLogo?.column2,placeholder:Sensitive.default_bg,options: [.transition(.fade(0.25))])
            name.text = item.topicName
            subName.text = item.topicDesc
        }
    }
    
}
