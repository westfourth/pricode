//
//  AudioNovelDetailVC.swift
//  CaoLong
//
//  Created by mac on 2021/1/26.
//  Copyright © 2021 mac. All rights reserved.
//

import UIKit
import AVFoundation
import MP3Player
import AVResourceLoader

class AudioNovelDetailVC: UIViewController {
    @IBOutlet weak var scrollView: UIScrollView!
    
    @IBOutlet weak var lineLeftCons: NSLayoutConstraint!
    @IBOutlet weak var lineRightCons: NSLayoutConstraint!
    
    @IBOutlet weak var cover: UIImageView!
    @IBOutlet weak var chapterName: UILabel!
    @IBOutlet weak var tagCollectionView: UICollectionView!
    
    @IBOutlet weak var circleView: UIView!
    
    @IBOutlet weak var playButton: UIButton!
    @IBOutlet weak var collect: UIButton!
    @IBOutlet weak var comment: UIButton!
    @IBOutlet weak var reward: UIButton!
    
    @IBOutlet weak var guessLikecollectionView: UICollectionView!
    
    @IBOutlet weak var adertise: UIImageView!
    @IBOutlet weak var advertiseIcon: UILabel!
    
    @IBOutlet weak var slider: AudioPlayerSlider!
    
    @IBOutlet weak var advertiseTopCons: NSLayoutConstraint!
    
    @IBOutlet weak var novelName: UILabel!
    @IBOutlet weak var animateImageVIew: UIImageView!
    
    var guessLikeItems:[NovelItem] = [NovelItem]()
    
    var observer  = MP3PlayerObserver()
    
    var currentIndex = 0
    
    var duration:CMTime = .zero
    
    var chapterids:[Int] = [Int]()
    
    //MARK:-
    
    override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: Bundle?) {
        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
        self.modalPresentationStyle = .overFullScreen
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        lineLeftCons.constant = UIScreen.main.bounds.width / 2.0
        lineRightCons.constant = UIScreen.main.bounds.width / 3.0
        
        
        tagCollectionView.register(UINib(nibName: "NovelTagCell", bundle: Bundle.main), forCellWithReuseIdentifier: "NovelTagCell")
        guessLikecollectionView.register(UINib(nibName: "AudioNovelGuessLikeCell", bundle: Bundle.main), forCellWithReuseIdentifier: "AudioNovelGuessLikeCell")
        
        addcirleLayer()
        startAnimation()
        MP3Player.share().observers.add(observer)
        setupObserver()

        
        loadAd()
        
        animateImageVIew.animationDuration = 1.0
        var array:[UIImage] = [UIImage]()
        for  i in 0 ..< 3 {
            let name = "播放中\(i + 1)"
            array.append(UIImage(named: name)!)
        }
        animateImageVIew.animationImages = array
        
        if let v = currentPlayingChapter {
            floatPlayingHandel()
        } else {
            self.slider.setValue(0, animated: true)
        }
    }
    
    func floatPlayingHandel() {
        // 针对悬浮状态进来 同步播放信息
        if MP3Player.share().player.currentItem != nil {
            if MP3Player.share().player.timeControlStatus != .playing {
                MP3Player.share().player.play()
            }
            self.timeStatus = MP3Player.share().player.timeControlStatus
            self.duration = MP3Player.share().player.currentItem!.duration
            if duration.isValid && !duration.isIndefinite {
                self.slider.maximumValue = Float(CMTimeGetSeconds(MP3Player.share().player.currentItem!.duration))
            }
        }
    }
    
    func loadAd() {
        
        guard !AdManager.shared.audioItems.isEmpty, let audioAd = AdManager.shared.randomAudiotem(AdManager.shared.audioItems) else {
            adertise.isHidden = true
            advertiseIcon.isHidden = true
            advertiseTopCons.constant = 40
            return
        }
        
        adertise.kf.setImage(with: audioAd.adImage,placeholder:Sensitive.default_bg,options: [.transition(.fade(0.25))])
        
    }
    
    deinit {
        MP3Player.share().observers.remove(observer)
    }
    
    //    override func viewWillDisappear(_ animated: Bool) {
    //        super.viewWillDisappear(animated)
    //        if MP3Player.share().player.timeControlStatus == .playing {
    //            MP3Player.share().player.pause()
    //        }
    //    }
    
    /// 加载小说
    var id:Int? {
        didSet {
            guard let id = id else {
                return
            }
            loadData(id)
            loadguessLikeData(id)
            
        }
    }
    
    func loadData(_ id:Int) {
        let req = QueryNovelReq()
        req.fictionId = id
        Session.request(req) { (e, resp) in
            guard e == nil else {
                iToast(e!.localizedDescription)
                return
            }
            guard let item = resp as? NovelItem else {
                return
            }
            let chapterids = item.chapters.map({return $0.chapterId})
            self.chapterids = chapterids
            MP3QueueManager.shared.append(chapterids)
            self.item = item
        }
    }
    
    func loadguessLikeData(_ id:Int) {
        let req = NovelguessLikeReq()
        req.fictionId = id
        Session.request(req) { (e, resp) in
            guard e == nil else {return}
            guard let items = resp as? [NovelItem], !items.isEmpty else {
                return
            }
            self.guessLikeItems = items
            self.guessLikecollectionView.reloadData()
        }
    }
    
    /// 正在播放的章节
    var currentPlayingChapter:NovelChapterItem? {
        didSet {
            guard let _ = currentPlayingChapter else {
                return
            }
        }
    }
    
    var item:NovelItem? {
        didSet {
            guard let item = item else {
                return
            }
            Defaults.saveNovel(item)
            collect.isSelected = item.isLike
            comment.setTitle(num2TenThousandStrFormat(item.commentNum), for: .normal)
            reward.setTitle(num2TenThousandStrFormat(Int(item.income)), for: .normal)
            tagCollectionView.reloadData()
            cover.kf.setImage(with: item.coverImg,placeholder:Sensitive.default_bg,options: [.transition(.fade(0.25))])
            novelName.text = item.fictionTitle
            if currentPlayingChapter != nil {
                // 悬浮窗进入
                // 查找当前的章节 更新当前索引
                if !item.chapters.isEmpty {
                    let index = item.chapters.firstIndex(where: {$0.chapterId == currentPlayingChapter!.chapterId}) ?? 0
                    currentIndex = index
                    self.chapterName.text = self.item!.chapters.first(where: {$0.chapterId == currentPlayingChapter!.chapterId})?.chapterTitle ?? ""
                }
            } else {
                if let v = someChapter {
                    // 加载指定章节的内容
                    if !item.chapters.isEmpty {
                        let index = item.chapters.firstIndex(where: {$0.chapterId == v.chapterId}) ?? 0
                        currentIndex = index
                    }
                    loadChapterData(v.chapterId)
                } else {
                    if !item.chapters.isEmpty {
                        loadChapterData(item.chapters.first!.chapterId)
                    }
                }
            }
        }
    }
    
    var someChapter:(fictionId:Int,chapterId:Int)? {
        didSet {
            guard let v = someChapter else {
                return
            }
            id = v.fictionId
        }
    }
    
    /// 加载某一个章节的文本信息
    var chapterId:Int? {
        didSet {
            guard let id = chapterId else {
                return
            }
            self.scrollView.setContentOffset(.zero, animated: true)
            loadChapterData(id)
        }
    }
    
    //    /// 权限type
    //    var permissionType:NovelReasonType = .canWatch {
    //        didSet {
    //            switch permissionType {
    //            case .notimes:
    //                puts(#function)
    //
    //            case .needPay:
    //                puts(#function)
    //
    //            case .vip:
    //
    //                puts(#function)
    //
    //            default:
    //                break
    //            }
    /// 加载某一个章节的文本内容
    func loadChapterData(_ id:Int) {
        var ficitionId = 0
        if let _ = someChapter {
            ficitionId = someChapter!.fictionId
        } else {
            ficitionId = item!.fictionId
        }
        MP3QueueManager.shared.someItem(ficitionId, id) { (value) in
            guard let value = value else {
                return
            }
            self.chapterName.text = self.item!.chapters.first(where: {$0.chapterId == value.chapterId})?.chapterTitle ?? ""
            if value.canWatch {
                //                // 直接播放音频小说
                self.titleView.name = value.chapterTitle
                self.play(chapter: value)
            } else {
                //                self.permissionType = value.reasonType
                PurchaseVipAlert.showPurchaseVipAlert { [weak self] in
                    self?.dismiss(animated: true, completion: {
                        VipChargeTipVC.isFromVideoPlayList = false
                        InnerIntercept.currentNaviController().show(Vip2VC(), sender: nil)
                    })
                }
            }
        }
    }
    
    var timeStatus:AVPlayer.TimeControlStatus = .waitingToPlayAtSpecifiedRate {
        didSet {
            self.playButton.isSelected = timeStatus != .paused
            if timeStatus == .waitingToPlayAtSpecifiedRate {
                // 动画
                startAnimation()
            } else {
                // 停止动画
                stopAnimation()
            }
            timeStatus == .playing ?  titleView.icon.startAnimating():titleView.icon.stopAnimating()
            
            timeStatus == .playing ?  animateImageVIew.startAnimating():animateImageVIew.stopAnimating()
            
            
        }
    }
    
    var status:AVPlayer.Status = .readyToPlay {
        didSet {
            
        }
    }
    
    func play(chapter: NovelChapterItem) {
        MP3PlayNow.share.chapter = chapter
    }
    
    func setupObserver() {
        observer.itemStatus = { status in
            if status == .readyToPlay {
                MP3Player.share().player.play()
            }
        }
        
        observer.timeControlStatus =  {[weak self] timeStatus in
            self?.timeStatus = timeStatus
        }
        
        observer.duration = {[weak self] (duration:CMTime)  in
            if duration.isValid && !duration.isIndefinite {
                self?.duration = duration
                self?.slider.maximumValue = Float(CMTimeGetSeconds(duration))
                let start = "00:00"
                self?.slider.contentValue.text = "\(start)/\(durationText(TimeInterval(self?.slider.maximumValue ?? 0)))"
            }
        }
        
        observer.currentTime = { [weak self] (currentTime:CMTime) in
            //            print("currerntTime = \(CMTimeGetSeconds(currentTime))")
            if currentTime.isValid && !currentTime.isIndefinite {
                self?.updateProgress(currentTime)
            }
        }
        
        observer.playToEndTime = { [weak self] in
            self?.slider.setValue(0, animated: true)
            MP3Player.share().player.seek(to: .zero) { [weak self] (finished) in
                MP3Player.share().player.play()
            }
        }
        
        // 上一首、下一首
        observer.currentItem = {[weak self] (previsou, current) in
            guard let chapter = MP3PlayNow.share.chapter else {return}
            self?.updateUI(chapter)
        }
    }
    
    /// 更新ui
    func updateUI(_ chapterItem:NovelChapterItem) {
        self.chapterName.text = self.item!.chapters.first(where: {$0.chapterId == chapterItem.chapterId})?.chapterTitle ?? ""
    }
    
    func updateProgress(_ currentTime:CMTime) {
        if isSliding  {
            return
        }
        if currentTime != .zero  {
            let start = durationText(TimeInterval(CMTimeGetSeconds(currentTime)))
            self.slider.contentValue.text = "\(start)/\(durationText(TimeInterval(CMTimeGetSeconds(MP3Player.share().player.currentItem!.duration))))"
            UIView.beginAnimations(nil, context: nil)
            UIView.setAnimationDuration(0.5 + 0.25)
            self.slider.setValue(Float(CMTimeGetSeconds(currentTime)), animated: true)
            UIView.commitAnimations()
        }
    }
    
    //_______________________________________________________________________________________________________________
    // MARK: - 加载动画相关
    
    lazy var circleBackLayer: CAShapeLayer =  {
        return CAShapeLayer()
    }()
    
    
    lazy var redLineLayer: CAShapeLayer =  {
        return CAShapeLayer()
    }()
    
    func addcirleLayer() {
        
        self.circleView.layer.addSublayer(circleBackLayer)
        self.circleView.layer.addSublayer(redLineLayer)
        
        let w:CGFloat = 72 / 2.0
        let backPath = UIBezierPath(arcCenter: CGPoint(x:w,y:w),
                                    radius: 38,
                                    startAngle: -0.5 * CGFloat.pi,
                                    endAngle: CGFloat.pi * 1.5,
                                    clockwise: true)
        circleBackLayer.lineWidth = 2;  // 线条宽度
        circleBackLayer.strokeColor = UIColor.gray.cgColor
        circleBackLayer.fillColor = UIColor.clear.cgColor
        circleBackLayer.lineCap = CAShapeLayerLineCap(rawValue: "round");
        circleBackLayer.path = backPath.cgPath
        
        
        // 画刻度
        let frontPath = UIBezierPath(arcCenter: CGPoint(x:w,y:w),
                                     radius: 38,
                                     startAngle: -0.5 * CGFloat.pi,
                                     endAngle: CGFloat.pi * 1.5,
                                     clockwise: true)
        redLineLayer.lineWidth = 2;
        redLineLayer.strokeStart = 0;
        redLineLayer.strokeColor = UIColor.red.cgColor
        redLineLayer.fillColor =  UIColor.clear.cgColor
        redLineLayer.lineCap = CAShapeLayerLineCap(rawValue: "round");
        redLineLayer.path = frontPath.cgPath
        redLineLayer.strokeEnd = 1
    }
    
    
    lazy var animation:CABasicAnimation = {
        let animation = CABasicAnimation()
        animation.keyPath = "strokeEnd"
        animation.duration = 1.0
        animation.fromValue = 0
        animation.repeatCount = Float(CGFloat.greatestFiniteMagnitude)
        return animation
    }()
    
    
    func startAnimation() {
        if !(circleView.layer.sublayers?.contains(redLineLayer) ?? false) {
            circleView.layer.addSublayer(redLineLayer)
        }
        redLineLayer.add(animation, forKey: nil)
    }
    
    func stopAnimation() {
        redLineLayer.removeAllAnimations()
        if (circleView.layer.sublayers?.contains(redLineLayer) ?? false) {
            circleView.layer.sublayers?.removeAll(where:  {$0 == redLineLayer})
        }
    }
    
    
    
    //_______________________________________________________________________________________________________________
    // MARK: - slider滑动事件
    
    var isSliding:Bool = false
    @IBAction func sliderBegin(_ sender: AudioPlayerSlider) {
        isSliding = true
    }
    
    @IBAction func sliderValueChange(_ sender: AudioPlayerSlider) {
        let start = durationText(TimeInterval(slider.value))
        self.slider.contentValue.text = "\(start)/\(durationText(TimeInterval(self.slider.maximumValue)))"
    }
    
    @IBAction func touchCancel(_ sender: AudioPlayerSlider) {
        isSliding = false
    }
    
    @IBAction func touchEnd(_ sender: AudioPlayerSlider) {
        MP3Player.share().player.currentItem?.cancelPendingSeeks()
        MP3Player.share().player.currentItem?.seek(to: CMTime(value: CMTimeValue(self.slider.value), timescale: 1), completionHandler: { (finished) in
            self.isSliding = false
            if finished {
                MP3Player.share().player.play()
            }
        })
    }
    
    
    
    
    //_______________________________________________________________________________________________________________
    // MARK: - action
    
    // 目录
    @IBAction func chaptersAction(_ sender: UIButton) {
        Animation.scaleBounce(sender)
        guard let item = item else {return}
        let vc = NovelChaptersVC()
        vc.delegate = self
        vc.item = item
        vc.defaultIndex = currentIndex
        present(vc, animated: true, completion: nil)
    }
    
    // 快进
    @IBAction func forward15Action(_ sender: UIButton) {
        Animation.scaleBounce(sender)
        
        var desTime:CMTime = .zero
        guard !isSliding else {return}
        desTime = CMTime(value: CMTimeValue(self.slider.value + 15), timescale: CMTimeScale(1.0))
        isSliding = true
        self.slider.setValue(Float(CMTimeGetSeconds(desTime)), animated: true)
        MP3Player.share().player.currentItem?.seek(to: desTime, completionHandler: { (finished) in
            self.isSliding = false
            MP3Player.share().player.play()
        })
    }
    
    // 快退
    @IBAction func retreat15Action(_ sender: UIButton) {
        Animation.scaleBounce(sender)
        var desTime:CMTime = .zero
        guard !isSliding else {return}
        if self.slider.value > 15 {
            desTime = CMTime(value: CMTimeValue(self.slider.value - 15), timescale: CMTimeScale(1.0))
        }
        isSliding = true
        self.slider.setValue(Float(CMTimeGetSeconds(desTime)), animated: true)
        MP3Player.share().player.currentItem?.seek(to: desTime, completionHandler: { (finished) in
            self.isSliding = false
            MP3Player.share().player.play()
        })
    }
    
    // 播放暂停
    @IBAction func playorPauseAction(_ sender: UIButton) {
        Animation.scaleBounce(sender)
        if MP3Player.share().player.timeControlStatus == .paused {
            MP3Player.share().player.play()
        } else {
            MP3Player.share().player.pause()
        }
    }
    
    // 上一首
    @IBAction func lastAction(_ sender: UIButton) {
        Animation.scaleBounce(sender)
        guard let item = self.item,!item.chapters.isEmpty,!self.chapterids.isEmpty else { return}
        guard currentIndex - 1 >= 0 else {
            return
        }
        MP3QueueManager.shared.previous(chapterids[currentIndex]) { (chapterItem) in
            guard let chapter = chapterItem  else {return}
            guard chapter.canWatch  else {
                PurchaseVipAlert.showPurchaseVipAlert()
                return
            }
            self.currentIndex = self.currentIndex - 1
            self.chapterName.text = self.item!.chapters.first(where: {$0.chapterId == chapter.chapterId})?.chapterTitle ?? ""
            self.cover.kf.setImage(with: chapter.coverImg,placeholder:Sensitive.default_bg,options: [.transition(.fade(0.25))])
            self.play(chapter: chapterItem!)
        }
    }
    
    // 下一首
    @IBAction func nextAction(_ sender: UIButton) {
        Animation.scaleBounce(sender)
        guard let item = self.item,!item.chapters.isEmpty,!self.chapterids.isEmpty else { return}
        guard currentIndex + 1 < chapterids.count else {
            return
        }
        MP3QueueManager.shared.next(chapterids[currentIndex]) { (chapterItem) in
            guard let chapter = chapterItem else {return}
            guard chapter.canWatch  else {
                PurchaseVipAlert.showPurchaseVipAlert()
                return
            }
            self.currentIndex = self.currentIndex + 1
            self.chapterName.text = self.item!.chapters.first(where: {$0.chapterId == chapter.chapterId})?.chapterTitle ?? ""
            self.cover.kf.setImage(with: chapter.coverImg,placeholder:Sensitive.default_bg,options: [.transition(.fade(0.25))])
            self.play(chapter: chapterItem!)
        }
    }
    
    /// 广告点击
    @IBAction func advertiseAction(_ sender: UITapGestureRecognizer) {
        guard !AdManager.shared.audioItems.isEmpty, let audioAd = AdManager.shared.randomAudiotem(AdManager.shared.audioItems) else {
            return
        }
        // 打开
        
        guard let url = audioAd.adJump else {return}
        // 广告点击
        if InnerIntercept.canOpenURL(url) {
            InnerIntercept.open(url)
        }
        
    }
    
    @IBAction func dismissAction(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    
    //_______________________________________________________________________________________________________________
    // MARK: - 底部 / 评论 + 收藏 + 打赏
    @IBAction func colletionAction(_ sender: UIButton) {
        Animation.scaleBounce(sender)
        guard let item = item else {
            return
        }
        loading()
        let req = NovelCollectionReq()
        req.fictionId = item.fictionId
        req.isLike = !sender.isSelected
        Session.request(req) { (e, resp) in
            hideLoading()
            guard e == nil else {
                iToast(e!.localizedDescription)
                return
            }
            sender.isSelected = !sender.isSelected
        }
    }
    
    @IBAction func commentAction(_ sender: UIButton) {
        Animation.scaleBounce(sender)
        guard let item = item,let ids = item.chapters.map( {return $0.chapterId}) as? [Int] else {
            return
        }
        item.currentChapterId = ids[currentIndex]
        let commentVC = CommentVC()
        commentVC.novel = item
        present(commentVC, animated: true, completion: nil)
    }
    
    @IBAction func rewardAction(_ sender: UIButton) {
        Animation.scaleBounce(sender)
    }
    
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        let v = scrollView.contentOffset.y
        //        self.navigationItem.titleView = v >= 20 ? self.titleView :nil
        animateImageVIew.isHidden  = v < 20
        novelName.isHidden = v < 20
    }
    
    
    //MARK: 顶部view
    lazy var titleView:AudioNovelTitleView = {
        let v = Bundle.main.loadNibNamed("AudioNovelTitleView", owner: nil, options: [:])?.first as! AudioNovelTitleView
        return v
    }()
}


//_______________________________________________________________________________________________________________
// MARK: - UICollectionViewDataSource&Delegate
extension AudioNovelDetailVC:UICollectionViewDataSource,UICollectionViewDelegate,UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if collectionView == tagCollectionView {
            return item?.tagList.count ?? 0
        }
        return guessLikeItems.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if collectionView == tagCollectionView {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "NovelTagCell", for: indexPath) as! NovelTagCell
            cell.name.text = item?.tagList[indexPath.row].title ?? ""
            return cell
        }
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "AudioNovelGuessLikeCell", for: indexPath) as! AudioNovelGuessLikeCell
        cell.item = guessLikeItems[indexPath.row]
        return cell
    }
    
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        if collectionView == tagCollectionView {
            let name = item?.tagList[indexPath.row].title  ?? ""
            return NovelTagCell.itemSize(name)
        }
        return AudioNovelGuessLikeCell.itemSize()
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        return .zero
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return  8.0
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        if collectionView == tagCollectionView {return 6.0}
        return 8.0
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        if collectionView == tagCollectionView {
            // 点击标签
            guard let currentItem = item?.tagList[indexPath.row] else { return }
            let novelReadingRecomChannelAndTagsListVC = NovelReadingRecomChannelAndTagsListVC()
            novelReadingRecomChannelAndTagsListVC.navigationTitle = currentItem.title
            novelReadingRecomChannelAndTagsListVC.type = .reading
            novelReadingRecomChannelAndTagsListVC.readingType = .tag
            novelReadingRecomChannelAndTagsListVC.tagId = currentItem.tagId
            InnerIntercept.currentNaviController().show(novelReadingRecomChannelAndTagsListVC, sender: nil)
            dismiss(animated: true) {}
        } else {
            // 点击音频小说
            let id = guessLikeItems[indexPath.row].fictionId
            self.scrollView.setContentOffset(.zero, animated: true)
            self.currentPlayingChapter = nil
            self.id = id
        }
    }
}


extension  AudioNovelDetailVC : NovelChaptersVCDelegate {
    func novel(_ vc: NovelChaptersVC, didSelect chapterId: Int) {
        self.chapterId = chapterId
        self.currentIndex = self.item!.chapters.map({return $0.chapterId}).firstIndex(where: {$0 == chapterId }) ?? 0
    }
}


//_______________________________________________________________________________________________________________
// MARK: -

public func durationText(_ duration: TimeInterval) -> String {
    let minute: Int = Int(duration / 60)
    let second: Int = Int(duration) % 60
    let string = String(format: "%02d:%02d", minute, second)
    return string
}
