//
//  AudioNovelGuessLikeCell.swift
//  CaoLong
//
//  Created by mac on 2021/1/26.
//  Copyright © 2021 mac. All rights reserved.
//

import UIKit

class AudioNovelGuessLikeCell: UICollectionViewCell {
    @IBOutlet weak var cover: UIImageView!
    @IBOutlet weak var read: UIButton!
    @IBOutlet weak var collect: UIButton!
    @IBOutlet weak var name: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    static func itemSize()->CGSize {
        let w:CGFloat = 112
        let h:CGFloat = w + 5 + 34
        return CGSize(width: w, height: h)
    }
    
    var item:NovelItem? {
        didSet {
            guard let item = item else {
                return
            }
            cover.kf.setImage(with: item.coverImg,placeholder:Sensitive.default_bg,options: [.transition(.fade(0.25))])
            read.setTitle(num2TenThousandStrFormat(item.fakeWatchTimes), for: .normal)
            collect.setTitle(num2TenThousandStrFormat(item.fakeLikes), for: .normal)
            name.text = item.fictionTitle
        }
    }
}
