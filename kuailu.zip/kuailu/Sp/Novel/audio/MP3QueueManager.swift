//
//  Mp3SourceManager.swift
//  CaoLong
//
//  Created by mac on 2021/1/30.
//  Copyright © 2021 mac. All rights reserved.
//

import UIKit

class MP3QueueManager: NSObject {

    static let shared = MP3QueueManager()
    /// 存储的是章节详情
    var items:[NovelChapterItem] = [NovelChapterItem]()
    
    ///章节ids
    var ids:[Int] = [Int]()
    
    /// 当前的小说id 请求章节详情 必须用到这个字段
    var ficitionId:Int?
    
    func append(_ contentsof:[Int]) {
        ids.append(contentsOf: contentsof)
    }
    
    func append(_ item:NovelChapterItem) {
        items.append(item)
    }
    
    /// 下一首
    func next(_ currrentChapterId:Int,callback:@escaping((NovelChapterItem?)->())) {
        guard !ids.isEmpty else {
            callback(nil)
            return
        }
        guard self.ficitionId != nil else {
            callback(nil)
            return
        }
        guard let index = ids.firstIndex(where: {$0 == currrentChapterId }),index + 1 < ids.count else {
            callback(nil)
            return
        }
        someItem(ficitionId!, ids[index + 1]) { (item) in
            callback(item)
        }
    }
    
    /// 上一首
    func previous(_ currrentChapterId:Int,callback:@escaping((NovelChapterItem?)->())) {
        guard !ids.isEmpty else {
            callback(nil)
            return
        }
        guard self.ficitionId != nil else {
            callback(nil)
            return
        }
        guard let index = self.ids.firstIndex(where: {$0 == currrentChapterId }),index > 0 else {
            callback(nil)
            return
        }
        someItem(ficitionId!, ids[index - 1]) {(item) in
            callback(item)
        }
    }
    
    
    //MARK:-获取某个章节的音频内容
    func someItem(_ ficitionId:Int, _ chapterId:Int,callback:@escaping((NovelChapterItem?)->())) {
        self.ficitionId = ficitionId
        let req = QueryNovelChapterReq()
        req.chapterId = chapterId
        req.fictionId = ficitionId
        Session.request(req) { [weak self] (e, resp) in
            guard e == nil else {
                callback(nil)
                return
            }
            guard let item = resp as? NovelChapterItem else {
                callback(nil)
               return
            }
            
            if item.canWatch && item.playPath != nil {
                /// 添加至队列
                self?.items.append(item)
            }
            callback(item)
        }
    }
}
