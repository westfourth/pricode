//
//  MP3FloatingView.swift
//  mp3
//
//  Created by mac on 2021/2/2.
//

import UIKit
import MP3Player
import MediaPlayer

class MP3FloatingView: UIView {
    static var share = MP3FloatingView()
    var observer = MP3PlayerObserver()
    
    var imageView = UIImageView()
    let shapeLayer = CAShapeLayer()
    
    var duration: Float64 = 1
    
    var progress = 0.0 {
        didSet {
            shapeLayer.strokeEnd = CGFloat(progress)
        }
    }
    
    var chapter: NovelChapterItem? {
        didSet {
            guard chapter != nil else { return }
            isHidden = false
            imageView.kf.setImage(with: chapter!.coverImg, placeholder:UIImage(named: "AppIcon"), options: [.transition(.fade(0.25))])
        }
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = .white
        isHidden = true
        
        layer.addSublayer(shapeLayer)
        shapeLayer.strokeColor = UIColor.red.cgColor
        shapeLayer.fillColor = UIColor.clear.cgColor
        shapeLayer.lineWidth = 2
        shapeLayer.strokeEnd = 0
        
        addSubview(imageView)
        imageView.image = UIImage(named: "AppIcon")
        imageView.contentMode = .scaleAspectFill
        
        rotateAnimation()
        
        //
        addGestures()
        //
        observe()
        
        let notiName = Notification.Name.init("AVPlayerStartPlayVideoNotification")
        NotificationCenter.default.addObserver(self, selector: #selector(videoStartPlay(_:)), name: notiName, object: nil)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    deinit {
        MP3Player.share().observers.remove(observer)
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        self.layer.cornerRadius = self.frame.width / 2
        self.layer.masksToBounds = true
        
        imageView.frame = bounds.inset(by: UIEdgeInsets(top: 2, left: 2, bottom: 2, right: 2))
        imageView.layer.cornerRadius = imageView.frame.width / 2
        imageView.layer.masksToBounds = true
        
        let size = bounds.size
        let path = UIBezierPath(arcCenter: CGPoint(x: size.width / 2, y: size.height / 2), radius: size.width / 2 - 1, startAngle: CGFloat(-Double.pi / 2), endAngle: CGFloat(Double.pi / 2 * 3), clockwise: true)
        shapeLayer.path = path.cgPath
    }
    
    func addGestures() {
        let singleTap = UITapGestureRecognizer(target: self, action: #selector(singleTap(_:)))
        singleTap.numberOfTapsRequired = 1
        addGestureRecognizer(singleTap)
        
        let doubleTap = UITapGestureRecognizer(target: self, action: #selector(doubleTap(_:)))
        doubleTap.numberOfTapsRequired = 2
        addGestureRecognizer(doubleTap)
        
        singleTap.require(toFail: doubleTap)
    }
    
    func observe() {
        MP3Player.share().observers.add(observer)
        observer.duration = { [weak self] (time) in
            self?.duration = CMTimeGetSeconds(time)
        }
        observer.currentTime = { [weak self] (time) in
            let currentTime = CMTimeGetSeconds(time)
            guard let d = self?.duration else {
                return
            }
            self?.shapeLayer.strokeEnd = CGFloat(currentTime / d)
        }
        observer.timeControlStatus = { [weak self] (status) in
            guard let l = self?.imageView.layer else { return }
            if status == .paused {
                l.timeOffset = CACurrentMediaTime()
                l.speed = 0
            } else {
                l.speed = 1
                l.beginTime = l.timeOffset
                l.timeOffset = 0
            }
        }
    }
    
    func rotateAnimation() {
        let rotateAnim = CAKeyframeAnimation(keyPath: "transform.rotation.z")
        rotateAnim.duration = 8
        rotateAnim.values = [0, Double.pi * 2]
        rotateAnim.repeatCount = Float(Int.max)
        rotateAnim.isRemovedOnCompletion = false
        imageView.layer.add(rotateAnim, forKey: nil)
    }
    
    @objc func singleTap(_ tap: UITapGestureRecognizer) {
        guard let chapter = self.chapter else { return}
        guard NetDefaults.userInfo?.freeWatches == -1 else {
            PurchaseVipAlert.showPurchaseVipAlert()
            return
        }
        let vc = AudioNovelDetailVC()
        vc.id = MP3QueueManager.shared.ficitionId
        vc.currentPlayingChapter = chapter
        let root = UIApplication.shared.keyWindow?.rootViewController
        root?.present(vc, animated: true, completion: nil)
    }
    
    @objc func doubleTap(_ tap: UITapGestureRecognizer) {
        if MP3Player.share().player.timeControlStatus == .paused {
            MP3Player.share().player.play()
        } else {
            MP3Player.share().player.pause()
        }
    }
    
    @objc func videoStartPlay(_ noti: Notification) {
        isHidden = true
        MP3Player.share().player.pause()
        MPNowPlayingInfoCenter.default().nowPlayingInfo = nil
    }
}
