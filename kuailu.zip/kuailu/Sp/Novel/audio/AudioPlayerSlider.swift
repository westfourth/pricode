//
//  AudioPlayerSlider.swift
//  CaoLong
//
//  Created by mac on 2021/1/26.
//  Copyright © 2021 mac. All rights reserved.
//

import UIKit
//_______________________________________________________________________________________________________________
// MARK: - 自定义slider

@IBDesignable
class AudioPlayerSlider: UISlider {
    
    weak var contentValue:UILabel!
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.setup()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        self.setup()
    }
    
    func setup() {
        self.maximumTrackTintColor = rgb(0xff9695A3)
        self.minimumTrackTintColor = UIColor.red
        
        let contentValue = UILabel(frame: CGRect.zero)
        contentValue.textColor = .black
        contentValue.backgroundColor = .white
        contentValue.textAlignment = .center
        contentValue.font = UIFont.systemFont(ofSize: 12,weight: .medium)
        contentValue.clipsToBounds = true
        contentValue.layer.cornerRadius = 10.5
        self.contentValue = contentValue
        self.addSubview(contentValue)
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        bringSubviewToFront(contentValue)
        
        let classs = subviews.map( {return $0.classForCoder})
        let names = classs.map( {return NSStringFromClass($0)})
        if names.contains("_UISlideriOSVisualElement") {
            for v in subviews {
                if NSStringFromClass(v.classForCoder) == "_UISlideriOSVisualElement" {
                    for c in v.subviews {
                        if c is UIImageView {
                            c.isHidden = true
                        }
                    }
                }
            }
        } else {
            // 低系统版本问题
            for  v  in subviews {
                if v is UIImageView {
                    v.subviews.first?.isHidden = true
                }
            }
        }
    }
    
    override func thumbRect(forBounds bounds: CGRect, trackRect rect: CGRect, value: Float) -> CGRect {
        let size = CGSize(width: 80, height: 21)
        let realRect = rect.inset(by: UIEdgeInsets(top: 0, left: size.width / 2, bottom: 0, right: size.width / 2))
        let thumbRect = CGRect(x: realRect.minX - size.width / 2 + realRect.width * CGFloat(value / self.maximumValue), y: (bounds.height - size.height) / 2, width: size.width, height: size.height)
        if contentValue != nil {
            contentValue.frame = thumbRect
        }
        return thumbRect
    }
}

