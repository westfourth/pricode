//
//  AudioNovelTitleView.swift
//  CaoLong
//
//  Created by mac on 2021/1/26.
//  Copyright © 2021 mac. All rights reserved.
//

import UIKit

class AudioNovelTitleView: UIView {
    @IBOutlet weak var icon: UIImageView!
    @IBOutlet weak var title: UILabel!
    
    var name:String = "" {
        didSet {
            self.title.text = name
        }
    }
    
    override var intrinsicContentSize: CGSize {
        return CGSize(width:30 + name.getStringSize(rectSize: .zero, font: UIFont.systemFont(ofSize: 14, weight: .medium)).width , height: 44)
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        icon.animationDuration = 1.0
        var array:[UIImage] = [UIImage]()
        for  i in 0 ..< 3 {
            let name = "播放中\(i + 1)"
            array.append(UIImage(named: name)!)
        }
        icon.animationImages = array
        let name = "播放中1"
        icon.image  = UIImage(named: name)
    }
}
