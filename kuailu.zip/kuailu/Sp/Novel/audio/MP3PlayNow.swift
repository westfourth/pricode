//
//  MP3PlayNow.swift
//  CaoLong
//
//  Created by mac on 2021/2/1.
//  Copyright © 2021 mac. All rights reserved.
//

import UIKit
import MP3Player
import MediaPlayer

class MP3PlayNow: NSObject {
    static var share = MP3PlayNow()
    var observer = MP3PlayerObserver()
    
    var imageView = UIImageView()
    
    override init() {
        super.init()
        MP3Player.share().observers.add(observer)
        observer.duration = { (time) in
            MP3NowUI.share().duration = CMTimeGetSeconds(time)
        }
        observer.currentTime = { (time) in
            MP3NowUI.share().currentTime = CMTimeGetSeconds(time)
        }
        
        MP3NowUI.share().play = {
            MP3Player.share().player.play()
        }
        MP3NowUI.share().pause = {
            MP3Player.share().player.pause()
        }
        MP3NowUI.share().nextTrack = { [weak self] in
            guard let chapter = self?.chapter else { return }
            MP3QueueManager.shared.next(chapter.chapterId) { (chapter) in
                guard chapter != nil else { return }
                self?.chapter = chapter
            }
        }
        MP3NowUI.share().previousTrack = { [weak self] in
            guard let chapter = self?.chapter else { return }
            MP3QueueManager.shared.previous(chapter.chapterId) { (chapter) in
                guard chapter != nil else { return }
                self?.chapter = chapter
            }
        }
        MP3NowUI.share().changePlaybackPosition = { (time) in
            let cmTime = CMTime(value: CMTimeValue(time), timescale: 1)
            MP3Player.share().player.seek(to: cmTime) { (complete) in
                
            }
        }
    }
    
    
    deinit {
        MP3Player.share().observers.remove(observer)
        MPNowPlayingInfoCenter.default().nowPlayingInfo = nil
    }
    
    //
    var chapter: NovelChapterItem? {
        didSet {
            MP3FloatingView.share.chapter = chapter
            
            guard chapter != nil else { return }
            
            let now = MP3NowUI.share()
            now.title = chapter!.chapterTitle
            
//            imageView.kf.setImage(with: chapter!.coverImg) { (image, error, type, url) in
//                if let image = image {
//                    now.image = image
//                } else {
//                    now.image = UIImage(named: "AppIcon")!
//                }
//            }
            //
            let asset = XSCacheLoader.share().asset(with: chapter!.playPath!)
            let item = AVPlayerItem(asset: asset)
            MP3Player.share().player.replaceCurrentItem(with: item)
        }
    }
}
