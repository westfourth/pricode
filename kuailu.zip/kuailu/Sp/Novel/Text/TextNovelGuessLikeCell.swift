//
//  TextNovelGuessLikeCell.swift
//  CaoLong
//
//  Created by mac on 2021/1/26.
//  Copyright © 2021 mac. All rights reserved.
//

import UIKit

class TextNovelGuessLikeCell: UICollectionViewCell {
    @IBOutlet weak var name: UILabel!
    @IBOutlet weak var num: UILabel!
    @IBOutlet weak var content: UILabel!
    @IBOutlet weak var watchnum: UIButton!
    @IBOutlet weak var collectnum: UIButton!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    var item:NovelItem? {
        didSet {
            guard let item = item else {
                return
            }
            name.text = item.fictionTitle
            num.text = ""
            content.attributedText = attribute(item.info,
                                               font: UIFont.systemFont(ofSize: 10, weight: .regular),
                                               lineSpacing: 5.0,
                                               textColor: rgb(0xffB5B5B5))
            watchnum.setTitle(num2TenThousandStrFormat(item.fakeWatchTimes), for: .normal)
            collectnum.setTitle(num2TenThousandStrFormat(item.fakeLikes), for: .normal)
            
        }
    }
    
    static func itemSize()->CGSize {
        return CGSize(width: UIScreen.main.bounds.width - 20, height: 104)
    }

}
