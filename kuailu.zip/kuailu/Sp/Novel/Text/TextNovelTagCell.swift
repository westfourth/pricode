//
//  TextNovelTagCell.swift
//  CaoLong
//
//  Created by mac on 2021/1/26.
//  Copyright © 2021 mac. All rights reserved.
//

import UIKit

class TextNovelTagCell: UICollectionViewCell {

    @IBOutlet weak var name: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        name.textColor = .randomColor()
    }

    static func itemSize(_ name:String)->CGSize {
        let w:CGFloat = 13 + 6 + name.getStringSize(rectSize: CGSize.zero, font: UIFont.systemFont(ofSize: 13, weight: .medium)).width
        return CGSize(width: w, height: 18)
    }
}
