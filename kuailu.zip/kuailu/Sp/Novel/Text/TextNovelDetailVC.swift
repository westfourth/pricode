//
//  TextNovelDetailVC.swift
//  CaoLong
//
//  Created by mac on 2021/1/26.
//  Copyright © 2021 mac. All rights reserved.
//

import UIKit

class TextNovelDetailVC: UIViewController {
    @IBOutlet weak var tagCollectionView: UICollectionView!
    @IBOutlet weak var guessLikeCollection: UICollectionView!
    
    @IBOutlet weak var guessLikeHeightCons: NSLayoutConstraint!
    
    @IBOutlet weak var scrollView: UIScrollView!
    
    @IBOutlet weak var advertise: UIImageView!
    @IBOutlet weak var advertiseIcon: UILabel!
    
    @IBOutlet weak var chapterName: UILabel!
    @IBOutlet weak var text: UILabel!
    
    @IBOutlet weak var collect: UIButton!
    @IBOutlet weak var comment: UIButton!
    @IBOutlet weak var reward: UIButton!
    
    @IBOutlet weak var advertiseTopCons: NSLayoutConstraint!
    /// 猜你喜欢
    var guessLikeItems:[NovelItem] = [NovelItem]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tagCollectionView.register(UINib(nibName: "TextNovelTagCell", bundle: Bundle.main), forCellWithReuseIdentifier: "TextNovelTagCell")
        guessLikeCollection.register(UINib(nibName: "TextNovelGuessLikeCell", bundle: Bundle.main), forCellWithReuseIdentifier: "TextNovelGuessLikeCell")
        guessLikeHeightCons.constant = 0
        
        loadAd()
    }
    
    
    
    func loadAd() {
        
        guard !AdManager.shared.textItems.isEmpty, let textAd = AdManager.shared.randomTextItem(AdManager.shared.textItems) else {
            advertise.isHidden = true
            advertiseIcon.isHidden = true
            advertiseTopCons.constant = 30
            return
        }
        
        advertise.kf.setImage(with: textAd.adImage,placeholder:Sensitive.default_bg,options: [.transition(.fade(0.25))])
        
    }
    
    var currentIndex = 0
    /// 加载小说
    var id:Int? {
        didSet {
            guard let id = id else {
                return
            }
            loadData(id)
            loadguessLikeData(id)
        }
    }
    
    
    var type:NovelReasonType = .canWatch {
        didSet {
            
        }
    }
    
    /// 加载指定的章节
    var someChapter:(fictionId:Int,chapterId:Int)? {
        didSet {
            guard let v = someChapter else {
                return
            }
            id = v.fictionId
        }
    }
    
    var item:NovelItem? {
        didSet {
            guard let item = item else {
                return
            }
            Defaults.saveNovel(item)
            self.scrollView.setContentOffset(.zero, animated: true)
            novelName = item.fictionTitle
            tagCollectionView.reloadData()
            self.collect.isSelected = item.isLike
            self.comment.setTitle(num2TenThousandStrFormat(item.commentNum), for: .normal)
            self.reward.setTitle(num2TenThousandStrFormat(Int(item.price)), for: .normal)
            if let v = someChapter {
                // 加载指定的章节
                if !item.chapters.isEmpty {
                    let index = item.chapters.firstIndex(where: {$0.chapterId == v.chapterId}) ?? 0
                    currentIndex = index
                }
                self.chapterId = v.chapterId
            } else {
                if !item.chapters.isEmpty {
                    // 默认加载第一个章节
                    self.chapterId = item.chapters.first!.chapterId
                }
            }
        }
    }
    
    
    var novelName:String = ""
    
    func loadData(_ id:Int) {
        let req = QueryNovelReq()
        req.fictionId = id
        Session.request(req) { [weak self] (e, resp) in
            guard e == nil else {
                iToast(e!.localizedDescription)
                return
            }
            guard let item = resp as? NovelItem else {
                return
            }
            self?.item = item
        }
    }
    
    func loadguessLikeData(_ id:Int) {
        let req = NovelguessLikeReq()
        req.fictionId = id
        Session.request(req) {[weak self]  (e, resp) in
            guard e == nil else {return}
            guard let items = resp as? [NovelItem], !items.isEmpty else {
                return
            }
            self?.guessLikeItems = items
            self?.guessLikeCollection.reloadData()
            self?.guessLikeHeightCons.constant = CGFloat(items.count) * TextNovelGuessLikeCell.itemSize().height + CGFloat( (items.count - 1)) * 12
        }
    }
    
    /// 加载某一个章节的文本信息
    var chapterId:Int? {
        didSet {
            self.scrollView.setContentOffset(.zero, animated: true)
            guard let id = chapterId else {
                return
            }
            loadChapterData(id)
        }
    }
    
    /// 加载某一个章节的文本内容
    func loadChapterData(_ id:Int) {
        let req = QueryNovelChapterReq()
        req.chapterId = id
        req.fictionId = someChapter != nil ? someChapter!.fictionId: item?.fictionId ?? 0
        loading()
        Session.request(req) {[weak self] (e, resp) in
            hideLoading()
            guard e == nil else {
                iToast(e!.localizedDescription)
                return
            }
            guard let item = resp as? NovelChapterItem else {
                return
            }
            self?.chapterName.text = item.chapterTitle
            // 刷新显示内容
            // 解码文本小说内容
            if item.canWatch {
                guard let texturl = item.playPath else {
                    return
                }
                self?.parseText(texturl)
            } else {
                // 弹框显示去冲vip
                PurchaseVipAlert.showPurchaseVipAlert()
            }
        }
    }
    
    // 下载文本内容 并显示刷新
    func parseText(_ url:URL) {
        loading()
        let task =  URLSession.shared.dataTask(with: URLRequest(url: url)) { [weak self] (data, response, e) in
            DispatchQueue.main.async {
                hideLoading()
                guard e == nil else {
                    return
                }
                guard let r = response as? HTTPURLResponse else {return}
                guard r.statusCode == 200  else {
                    iToast(HTTPURLResponse.localizedString(forStatusCode: r.statusCode))
                    return
                }
                guard let responseData = data,let textData = xor_decrypt_novel(responseData) as? Data else {return}
                //转换成字符串
                guard let text = String(data: textData, encoding: .utf8) else {return}
                // 显示
                self?.text.attributedText = attribute(text,
                                                      font: UIFont.systemFont(ofSize: 15, weight: .regular),
                                                      lineSpacing: 8,
                                                      textColor: rgb(0xffB5B5B5))
//                self?.view.setNeedsLayout()
            }
        }
        task.resume()
    }
    
    //_______________________________________________________________________________________________________________
    // MARK: - action
    @IBAction func chaptersAction(_ sender: UIButton) {
        Animation.scaleBounce(sender)
        guard let item = item else {return}
        let vc = NovelChaptersVC()
        vc.defaultIndex = currentIndex
        vc.item = item
        vc.delegate = self
        present(vc, animated: true, completion: nil)
    }
    
    //下一章
    @IBAction func nextAction(_ sender: UIButton) {
        Animation.scaleBounce(sender)
        guard let item = self.item else {return}
        guard !item.chapters.isEmpty else {return}
        guard self.currentIndex < item.chapters.count - 1  else {
            return
        }
        currentIndex = currentIndex + 1
        self.chapterId = item.chapters[currentIndex].chapterId
    }
    
    /// 收藏
    @IBAction func collectAction(_ sender: UIButton) {
        Animation.scaleBounce(sender)
        guard let item = item else {
            return
        }
        let req = NovelCollectionReq()
        req.fictionId = item.fictionId
        req.isLike = !sender.isSelected
        Session.request(req) { (e, resp) in
            guard e == nil else {
                iToast(e!.localizedDescription)
                return
            }
            sender.isSelected = !sender.isSelected
        }
    }
    
    /// 评论
    @IBAction func commentAction(_ sender: UIButton) {
        Animation.scaleBounce(sender)
        guard let item = item,let ids = item.chapters.map( {return $0.chapterId}) as? [Int],!ids.isEmpty else {
            return
        }
        item.currentChapterId = ids[currentIndex]
        let commentVC = CommentVC()
        commentVC.novel = item
        present(commentVC, animated: true, completion: nil)
    }
    
    @IBAction func rewardAction(_ sender: UIButton) {
    }
    
    @IBAction func advertiseAction(_ sender: Any) {
        guard !AdManager.shared.textItems.isEmpty, let textAd = AdManager.shared.randomTextItem(AdManager.shared.textItems) else {
            return
        }
        
        guard let url = textAd.adJump else {return}
        // 广告点击
        if InnerIntercept.canOpenURL(url) {
            InnerIntercept.open(url)
        }
        
    }
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        let v = scrollView.contentOffset.y
        navigationItem.title = v >= 5 ?  novelName: ""
    }
    
}


//_______________________________________________________________________________________________________________
// MARK: - UICollectionViewDataSource&Delegate
extension TextNovelDetailVC:UICollectionViewDataSource,UICollectionViewDelegate,UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if collectionView == tagCollectionView {
            return item?.tagList.count ?? 0
        }
        return guessLikeItems.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if collectionView == tagCollectionView {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "TextNovelTagCell", for: indexPath) as! TextNovelTagCell
            cell.name.text = item?.tagList[indexPath.row].title ??  ""
            return cell
        }
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "TextNovelGuessLikeCell", for: indexPath) as! TextNovelGuessLikeCell
        cell.item = guessLikeItems[indexPath.row]
        return cell
    }
    
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        if collectionView == tagCollectionView {
            let name = item?.tagList[indexPath.row].title ?? ""
            return TextNovelTagCell.itemSize(name)
        }
        return TextNovelGuessLikeCell.itemSize()
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        return .zero
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        if collectionView == guessLikeCollection {
            return 12
        }
        return 10
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return  15
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        if collectionView == tagCollectionView {
            // 点击标签
            guard let currentItem = item?.tagList[indexPath.row] else { return }
            let novelReadingRecomChannelAndTagsListVC = NovelReadingRecomChannelAndTagsListVC()
            novelReadingRecomChannelAndTagsListVC.navigationTitle = currentItem.title
            novelReadingRecomChannelAndTagsListVC.type = .novel
            novelReadingRecomChannelAndTagsListVC.tagId = currentItem.tagId
            navigationController?.show(novelReadingRecomChannelAndTagsListVC, sender: nil)
            
        } else {
            // 点击猜你喜欢
            let id = guessLikeItems[indexPath.row].fictionId
            self.scrollView.setContentOffset(.zero, animated: true)
            self.id = id
        }
    }
}

/// 点击某个章节
extension TextNovelDetailVC:NovelChaptersVCDelegate {
    func novel(_ vc: NovelChaptersVC, didSelect chapterId: Int) {
        self.chapterId = chapterId
        self.currentIndex = self.item!.chapters.map({return $0.chapterId}).firstIndex(where: {$0 == chapterId }) ?? 0
    }
}

