//
//  NovelTagCell.swift
//  CaoLong
//
//  Created by mac on 2021/1/26.
//  Copyright © 2021 mac. All rights reserved.
//

import UIKit

class NovelTagCell: UICollectionViewCell {

    @IBOutlet weak var name: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    static func itemSize(_ name:String)->CGSize {
        let w = name.getStringSize(rectSize: .zero, font: UIFont.systemFont(ofSize: 12)).width  + 8
        return CGSize(width: w, height: 16)
    }

}
