//
//  CoinNotEnoughView.swift
//  Sp
//
//  Created by mac on 2020/3/24.
//  Copyright © 2020 mac. All rights reserved.
//


class CoinNotEnoughView: UIView {
    
    private var clientHeight: CGFloat = 380
    
    private lazy var wrapperView: UIView = {
        let view = UIView()
        view.alpha = 0
        let topColor = RGB(0x151C39)
        let centerColor = RGB(0x090E22)
        let buttomColor = RGB(0x19051D)
        let gradientColors = [topColor.cgColor, centerColor.cgColor, buttomColor.cgColor]
        let gradientLocations:[NSNumber] = [0, 1, 1]
        let gradientLayer = CAGradientLayer()
        gradientLayer.colors = gradientColors
        gradientLayer.locations = gradientLocations
        gradientLayer.frame = CGRect(x: 0, y: 0, width: UIScreen.main.bounds.width, height: clientHeight)
        view.layer.insertSublayer(gradientLayer, at: 0)
        view.addSubview(titleLabel)
        view.addSubview(upSplitLine)
        view.addSubview(descLabel)
        view.addSubview(priceLabel)
        view.addSubview(balanceLabel)
        view.addSubview(uploadBtn)
        view.addSubview(comfirmBtn)
        view.addSubview(bottomSplitLine)
        view.addSubview(tipLabel)
        renderView()
        return view
    }()
    
    private lazy var maskLayerView: UIView = {
        let view = UIView()
        view.backgroundColor = .none
        let tap = UITapGestureRecognizer(target: self, action: #selector(onMaskTap))
        view.addGestureRecognizer(tap)
        return view
    }()
    
    private lazy var titleLabel: UILabel = {
        let label = UILabel()
        label.text = "\(Sensitive.zhi)"
        label.font = UIFont.pingFangHeavy(16)
        label.textColor = .white
        return label
    }()
    
    private lazy var upSplitLine: UIView = {
        let line = UIView()
        line.backgroundColor = RGB(0xD8D8D8).withAlphaComponent(0.0756)
        return line
    }()
    
    private lazy var bottomSplitLine: UIView = {
        let line = UIView()
        line.backgroundColor = RGB(0xD8D8D8).withAlphaComponent(0.0756)
        return line
    }()
    
    private lazy var descLabel: UILabel = {
        let label = UILabel()
        label.numberOfLines = 0
        label.textAlignment = .center
        return label
    }()
    
    private lazy var priceLabel: UILabel = {
        let label = UILabel()
        return label
    }()
    
    private lazy var balanceLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.pingFangRegular(14)
        label.textColor = .white
        label.layer.backgroundColor = RGB(0x1141C7).cgColor
        label.layer.cornerRadius = 12
        label.textAlignment = .center
        return label
    }()
    
    private lazy var uploadBtn: UIButton = {
        let btn = UIButton()
        btn.setTitleColor(RGB(0x4D4D4D), for: .normal)
        btn.titleLabel?.font = UIFont.pingFangMedium(15)
        btn.layer.backgroundColor = UIColor.white.cgColor
        btn.layer.cornerRadius = 4
        btn.addTarget(self, action: #selector(onUploadTap), for: .touchUpInside)
        return btn
    }()
    
    private lazy var comfirmBtn: UIButton = {
        let btn = UIButton()
        btn.setTitleColor(.white, for: .normal)
        btn.titleLabel?.font = UIFont.pingFangMedium(15)
        btn.layer.backgroundColor = RGB(0xE62865).cgColor
        btn.layer.cornerRadius = 4
        btn.addTarget(self, action: #selector(onComfirmTap), for: .touchUpInside)
        return btn
    }()
    
    private lazy var tipLabel: UILabel = {
        let label = UILabel()
        label.numberOfLines = 0
        label.textAlignment = .center
        let ruleTipText = """
        \(Sensitive.cao)短視頻支持並鼓勵原創，您的\(Sensitive.fu)
  將全額付給上傳用戶，感謝您的支持
"""
        let paraph = NSMutableParagraphStyle()
        paraph.lineSpacing = 6 // 字型的行間距
        let attributes = [NSAttributedString.Key.font: UIFont.pingFangRegular(12),
                          NSAttributedString.Key.foregroundColor: UIColor.white,
                          NSAttributedString.Key.paragraphStyle: paraph]
        label.attributedText = NSAttributedString(string: ruleTipText, attributes: attributes)
        return label
    }()
    
    private var balanceStrLen: CGFloat = 0
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    init(author: String = "",
         price: String = "",
         balance: String = "",
         isBalanceEnough:Bool = false, viewHeight: CGFloat = 380) {
        super.init(frame: .zero)
        clientHeight = viewHeight
        let descAttributes = [NSAttributedString.Key.font: UIFont.pingFangRegular(12),
                              NSAttributedString.Key.foregroundColor: UIColor.white
        ]
        let descAttributedString = NSMutableAttributedString(string: "該視頻由 「\(author)」 上傳，並設定觀看\(Sensitive.jia)為：", attributes: descAttributes)
        descAttributedString.addAttributes([NSAttributedString.Key.foregroundColor: UIColor.red],range: NSRange(location: 6, length: author.count))
        descLabel.attributedText = descAttributedString
        let priceAttributes = [NSAttributedString.Key.font: UIFont.pingFangHeavy(32),
                               NSAttributedString.Key.foregroundColor: RGB(0xFFCD5D)
        ]
        let priceAttributedString = NSMutableAttributedString(string: "\(price)\(Sensitive.jin)", attributes: priceAttributes)
        priceAttributedString.addAttributes([NSAttributedString.Key.font: UIFont.pingFangRegular(20)], range: NSRange(location: price.count, length: 2))
        priceLabel.attributedText = priceAttributedString
        balanceLabel.text = "我的\(Sensitive.jin)：\(balance)"
        balanceStrLen = balanceLabel.text!.getStringSize(rectSize: .zero, font: UIFont.pingFangRegular(14)).width
        uploadBtn.setTitle(isBalanceEnough ? "取消" : "我要上傳", for: .normal)
        comfirmBtn.setTitle(isBalanceEnough ? "確認\(Sensitive.zhi)" : "\(Sensitive.gou)\(Sensitive.jin)", for: .normal)
        addSubview(maskLayerView)
        addSubview(wrapperView)
        maskLayerView.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
        wrapperView.snp.makeConstraints { (make) in
            make.width.equalToSuperview()
            make.bottom.equalToSuperview().offset(clientHeight)
            make.height.equalTo(clientHeight)
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.04, execute:{ [weak self] in
            guard let `self` = self else { return }
            self.showAnimation()
        })
    }
    
    private func renderView() {
        
        titleLabel.snp.makeConstraints { (make) in
            make.centerX.equalToSuperview()
            make.top.equalToSuperview().inset(17)
        }
        
        upSplitLine.snp.makeConstraints { (make) in
            make.top.equalTo(titleLabel.snp.bottom).offset(15)
            make.width.equalToSuperview()
            make.height.equalTo(0.5)
        }
        
        descLabel.snp.makeConstraints { (make) in
            make.top.equalTo(upSplitLine.snp.bottom).offset(30)
            make.left.right.equalToSuperview().inset(12)
            make.centerX.equalToSuperview()
        }
        
        priceLabel.snp.makeConstraints { (make) in
            make.top.equalTo(descLabel.snp.bottom).offset(30)
            make.centerX.equalToSuperview()
        }
        
        balanceLabel.snp.makeConstraints { (make) in
            make.top.equalTo(priceLabel.snp.bottom).offset(8)
            make.centerX.equalToSuperview()
            make.width.equalTo(balanceStrLen + 16 * 2)
            make.height.equalTo(24)
        }
        
        uploadBtn.snp.makeConstraints { (make) in
            make.left.equalToSuperview().inset(32)
            make.top.equalTo(balanceLabel.snp.bottom).offset(47)
            make.width.equalTo(118)
            make.height.equalTo(36)
        }
        
        comfirmBtn.snp.makeConstraints { (make) in
            make.right.equalToSuperview().inset(32)
            make.top.equalTo(balanceLabel.snp.bottom).offset(47)
            make.width.equalTo(118)
            make.height.equalTo(36)
        }
        
        bottomSplitLine.snp.makeConstraints { (make) in
            make.top.equalTo(comfirmBtn.snp.bottom).offset(16)
            make.width.equalToSuperview()
            make.height.equalTo(0.5)
        }
        
        tipLabel.snp.makeConstraints { (make) in
            make.top.equalTo(bottomSplitLine.snp.bottom).offset(19)
            make.centerX.equalToSuperview()
        }
        
    }
    
    @objc private func onMaskTap() {
        dismissAnimation()
        Alert.commonAlert?.hide(animated: true)
        Alert.initAlertState()
    }
    
    @objc private func onUploadTap() {
        dismissAnimation()
        Alert.onCancelBtnClick()
    }
    
    @objc private func onComfirmTap() {
        dismissAnimation()
        Alert.onConfirmBtnClick()
    }
    
    private func dismissAnimation() {
        wrapperView.snp.updateConstraints { (make) in
            make.bottom.equalToSuperview().offset(clientHeight)
        }
        updateConstraint()
        UIView.animate(withDuration: 0.3) { [weak self] in
            guard let `self` = self else { return }
            self.layoutIfNeeded()
        }
    }
    
    private func showAnimation() {
        wrapperView.snp.updateConstraints { (make) in
            make.bottom.equalToSuperview()
        }
        updateConstraint()
        UIView.animate(withDuration: 0.5) { [weak self] in
            guard let `self` = self else { return }
            self.wrapperView.alpha = 1
            self.layoutIfNeeded()
        }
    }
    
    private func updateConstraint() {
        wrapperView.updateConstraintsIfNeeded()
        wrapperView.updateFocusIfNeeded()
    }
}
