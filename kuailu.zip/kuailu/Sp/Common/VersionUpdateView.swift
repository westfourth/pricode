//
//  TimeNotEnoughView.swift
//  Sp
//
//  Created by mac on 2020/4/3.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class VersionUpdateView: UIView  {
    
    private var isForceUpdate: Bool = true
    
    private lazy var updateBtnImg: UIImage? = {
        return UIImage(named: "update_btn")
    }()
    
    private lazy var updateCloseBtnImg: UIImage? = {
        return UIImage(named: "update_close_btn")
    }()
    
    private lazy var updateBgImgView: UIImageView = {
        return UIImageView(image: UIImage(named: "udpate_bg"))
    }()
    
    private lazy var tipLabel: UILabel = {
        let label = UILabel()
        label.text = "版本更新通知！"
        label.font = UIFont.pingFangMedium(28)
        label.textColor = .white
        label.textAlignment = .center
        return label
    }()
    
    private lazy var subTipLabel: UILabel = {
        let label = UILabel()
        label.text = "強烈建議您儘快下載最新版本哦"
        label.font = UIFont.pingFangMedium(14)
        label.textColor = .white
        label.textAlignment = .center
        return label
    }()
    
    private lazy var tipWrapperView: UIView = {
        let view = UIView()
        view.backgroundColor = RGB(0xFC8C41)
        view.addSubview(subTipLabel)
        view.addSubview(tipLabel)
        
        subTipLabel.snp.makeConstraints { (make) in
            make.left.right.equalToSuperview()
            make.bottom.equalToSuperview().inset(11)
        }
        
        tipLabel.snp.makeConstraints { (make) in
            make.left.right.equalToSuperview()
            make.bottom.equalTo(subTipLabel.snp.top).offset(-2)
        }
        
        return view
    }()
    
    private lazy var titleLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.pingFangMedium(23)
        label.textColor = .black
        return label
    }()
    
    private lazy var contentTextView: UITextView = {
        let textView = UITextView()
        textView.isEditable = false
        textView.isSelectable = false
        textView.font = UIFont.pingFangRegular(13)
        textView.textColor = RGB(0x6F7474)
        return textView
    }()
    
    private lazy var wrapperView: UIView = {
        let view = UIView()
        view.backgroundColor = .white
        view.layer.cornerRadius = 12
        view.layer.masksToBounds = true
        view.addSubview(tipWrapperView)
        view.addSubview(titleLabel)
        view.addSubview(contentTextView)
        view.addSubview(comfirmBtn)
        
        tipWrapperView.snp.makeConstraints { (make) in
            make.top.left.right.equalToSuperview()
            make.height.equalTo(141)
        }
        
        titleLabel.snp.makeConstraints { (make) in
            make.top.equalTo(tipWrapperView.snp.bottom).offset(8)
            make.left.right.equalToSuperview().inset(12)
        }
        
        contentTextView.snp.makeConstraints { (make) in
            make.top.equalTo(titleLabel.snp.bottom).offset(6)
            make.left.right.equalToSuperview().inset(20)
            make.height.equalTo(140)
        }
        
        comfirmBtn.snp.makeConstraints { (make) in
            make.centerX.equalToSuperview()
            make.bottom.equalToSuperview()
            make.width.equalTo(240)
            make.height.equalTo(62)
        }
        
        return view
    }()
    
    private lazy var comfirmBtn: UIButton = {
        let btn = UIButton()
        btn.setBackgroundImage(updateBtnImg, for: .normal)
        btn.setTitle("立即升級", for: .normal)
        btn.setTitleColor(.white, for: .normal)
        btn.titleLabel?.font = UIFont.pingFangMedium(18)
        btn.contentEdgeInsets = UIEdgeInsets(top: -6, left: 0, bottom: 0, right: 0)
        btn.addTarget(self, action: #selector(onComfirmTap), for: .touchUpInside)
        return btn
    }()
    
    private lazy var closeBtn: UIButton = {
        let btn = UIButton()
        btn.setBackgroundImage(updateCloseBtnImg, for: .normal)
        btn.addTarget(self, action: #selector(onCloseTap), for: .touchUpInside)
        return btn
    }()
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    init(contentText: String, isForceUpdate: Bool, versionNumber: String) {
        super.init(frame: .zero)
        self.isForceUpdate = isForceUpdate
        titleLabel.text = "升級到\(versionNumber)版本"
        contentTextView.text = contentText
        renderView()
    }
    
    private func renderView() {
        addSubview(wrapperView)
        addSubview(updateBgImgView)
        
        wrapperView.snp.makeConstraints { (make) in
            make.top.equalToSuperview().inset(33)
            make.right.left.equalToSuperview()
            make.bottom.equalToSuperview().inset(isForceUpdate ? 0 : 25 + 38)
        }
        
        updateBgImgView.snp.makeConstraints { (make) in
            make.top.equalTo(wrapperView).offset(-33)
            make.centerX.equalToSuperview()
            make.width.equalTo(164)
            make.height.equalTo(98)
        }
        guard !isForceUpdate else { return }
        addSubview(closeBtn)
        closeBtn.snp.makeConstraints { (make) in
            make.centerX.bottom.equalToSuperview()
            make.size.equalTo(38)
        }
    }
    
    @objc private func onComfirmTap() {
        isForceUpdate ? Alert.confirmClosure?() : Alert.onConfirmBtnClick()
    }
    
    @objc private func onCloseTap() {
        Alert.onCancelBtnClick()
    }
}
