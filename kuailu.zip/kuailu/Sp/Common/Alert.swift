//
//  Alert.swift
//  Puff
//
//  Created by mac on 2019/9/23.
//  Copyright © 2019 mac. All rights reserved.
//


class Alert: NSObject {
    
    static let toastImgArr: [String] = ["toast_succeed","toast_failed","toast_forbidden","toast_warning"]
    
    static var toastInstance: MBProgressHUD?
    
    static var toastBlockTask: DispatchWorkItem?
    
    private static let versionUpdateIcon: UIImage = {
        return UIImage.decrypt("version_update.png.enc")
    }()
    
    static var applicationCenterClosure: (() -> ())?
    
    static var confirmClosure: (() -> ())?
    
    static var cancelClosure: (() -> ())?
    
    static var commonAlert: CustomMBProgressHUD?
    
    static var loading: MBProgressHUD?
    
    static let loadingImgView = UIImageView(image: UIImage(named: "loading_icon"))
    
    static let animation: CABasicAnimation = {
        let animation = CABasicAnimation(keyPath: "transform.rotation.z")
        // 预设是顺时针效果，若将formValue和toValue的值互换，则为逆时针效果
        animation.fromValue = 0
        animation.toValue = Double.pi * 2
        animation.duration = 1
        //        animation.speed = 1
        animation.autoreverses = false
        // 解决动画结束后回到原始状态的问题
        animation.isRemovedOnCompletion = false
        animation.fillMode = .forwards
        animation.repeatCount = MAXFLOAT // 一直旋轉的話，就設定為MAXFLOAT
        // 定义动画的节奏
        animation.timingFunction = CAMediaTimingFunction(name: .easeInEaseOut)
        return animation
    }()
    
    @objc class func onCancelBtnClick() {
        Alert.cancelClosure?()
        Alert.commonAlert?.hide(animated: true)
        Alert.initAlertState()
    }
    
    @objc class func onApplicationCenterBtnClick() {
        Alert.applicationCenterClosure?()
        Alert.commonAlert?.hide(animated: true)
        Alert.initAlertState()
    }
    
    @objc class func onConfirmBtnClick() {
        Alert.confirmClosure?()
        Alert.commonAlert?.hide(animated: true)
        Alert.initAlertState()
    }
    
    class func hidePreviousAlert() {
        Alert.commonAlert?.hide(animated: false)
        Alert.initAlertState()
    }
    
    class func initAlertState() {
        Alert.commonAlert = nil
        Alert.cancelClosure = nil
        Alert.confirmClosure = nil
        Alert.applicationCenterClosure = nil
    }
    
    class func showCommonAlert(parentView: UIView, contentText: String = "", cancelText: String = "取消", confirmText: String = "確定", onConfirmTap: (()->())?, onCancelTap: (()->())?) {
        hidePreviousAlert()
        Alert.confirmClosure = onConfirmTap
        Alert.cancelClosure = onCancelTap
        let alertView = UIView()
        alertView.backgroundColor = .white
        alertView.layer.cornerRadius = 12
        alertView.clipsToBounds = true
        
        let contentLabel = UILabel()
        contentLabel.text = contentText
        contentLabel.font = UIFont.pingFangRegular(17)
        contentLabel.textColor = .black
        contentLabel.textAlignment = contentText.count > 13 ? .left : .center
        contentLabel.numberOfLines = 0
        
        let cancelBtn = UIButton()
        
        cancelBtn.backgroundColor = RGB(0xB0B0B0)
        cancelBtn.setTitle(cancelText, for: .normal)
        cancelBtn.setTitleColor(.white, for: .normal)
        cancelBtn.titleLabel?.font = UIFont.pingFangMedium(15)
        cancelBtn.addTarget(self, action: #selector(onCancelBtnClick), for: .touchUpInside)
        
        let confirmBtn = UIButton()
        confirmBtn.backgroundColor = RGB(0xFE6000)
        confirmBtn.setTitle(confirmText, for: .normal)
        confirmBtn.setTitleColor(.white, for: .normal)
        confirmBtn.titleLabel?.font = UIFont.pingFangMedium(15)
        confirmBtn.addTarget(self, action: #selector(onConfirmBtnClick), for: .touchUpInside)
        
        alertView.addSubview(contentLabel)
        alertView.addSubview(cancelBtn)
        alertView.addSubview(confirmBtn)
        
        contentLabel.snp.makeConstraints { (make) in
            make.centerX.equalToSuperview()
            make.top.equalTo(35)
            make.width.equalTo(230)
            //            make.height.equalTo(48)
        }
        
        cancelBtn.snp.makeConstraints { (make) in
            make.left.bottom.equalToSuperview()
            make.width.equalTo(144)
            make.height.equalTo(44)
        }
        
        confirmBtn.snp.makeConstraints { (make) in
            make.right.bottom.equalToSuperview()
            make.width.equalTo(144)
            make.height.equalTo(44)
        }
        
        commonAlert = CustomMBProgressHUD.showAdded(to: parentView, animated: true)
        commonAlert!.customView = alertView
        alertView.snp.makeConstraints { (make) in
            make.width.equalTo(288)
            make.height.equalTo(166)
        }
    }
    
    class func showClassyWelfareAlert(parentView: UIView, onConfirmTap: (()->())?) {
        hidePreviousAlert()
        Alert.confirmClosure = onConfirmTap
        let alertView = UIView()
        alertView.backgroundColor = .white
        alertView.layer.cornerRadius = 12
        alertView.clipsToBounds = true
        
        let contentView = UIView(frame: CGRect(x: (288 - 230) / 2, y: 50, width: 230, height: 30))
        let contentLabel = UILabel(frame: CGRect(x: 0, y: 0, width: 230, height: 30))
        contentLabel.text = "恭喜您，搶購成功！"
        contentLabel.font = UIFont.pingFangRegular(22)
        contentLabel.textColor = RGB(0x383838)
        contentLabel.textAlignment = .center
        contentLabel.numberOfLines = 0
        contentView.addSubview(contentLabel)
        let cancelGradientLayer = CAGradientLayer()
        cancelGradientLayer.colors = [RGB(0xB0B0B0).cgColor, RGB(0x898989).cgColor]
        cancelGradientLayer.locations = [0, 1]
        cancelGradientLayer.startPoint = CGPoint(x: 0, y: 1)
        cancelGradientLayer.endPoint  = CGPoint(x: 1.0, y: 1)
        cancelGradientLayer.frame = CGRect(x: 0, y: 0, width: 144, height: 44)
        let cancelBtn = UIButton()
        cancelBtn.setTitle("好的", for: .normal)
        cancelBtn.setTitleColor(.white, for: .normal)
        cancelBtn.titleEdgeInsets = UIEdgeInsets(top: 0, left: 0, bottom: 2, right: 0)
        cancelBtn.titleLabel?.font = UIFont.pingFangMedium(15)
        cancelBtn.addTarget(self, action: #selector(onCancelBtnClick), for: .touchUpInside)
        cancelBtn.layer.insertSublayer(cancelGradientLayer, at: 0)
        let confirmGradientLayer = CAGradientLayer()
        confirmGradientLayer.colors = [RGB(0xFE6000).cgColor, RGB(0xFC9239).cgColor]
        confirmGradientLayer.locations = [0, 1]
        confirmGradientLayer.startPoint = CGPoint(x: 0, y: 1)
        confirmGradientLayer.endPoint  = CGPoint(x: 1.0, y: 1)
        confirmGradientLayer.frame = CGRect(x: 0, y: 0, width: 144, height: 44)
        let confirmBtn = UIButton()
        confirmBtn.setTitle("立即播放", for: .normal)
        confirmBtn.setTitleColor(.white, for: .normal)
        confirmBtn.titleEdgeInsets = UIEdgeInsets(top: 0, left: 0, bottom: 2, right: 10)
        confirmBtn.titleLabel?.font = UIFont.pingFangRegular(16)
        confirmBtn.addTarget(self, action: #selector(onConfirmBtnClick), for: .touchUpInside)
        confirmBtn.layer.insertSublayer(confirmGradientLayer, at: 0)
        
        let triangleImgView = UIImageView(image: UIImage(named: "classy_welfare_alert_btn_triangle"))
        
        confirmBtn.addSubview(triangleImgView)
        
        triangleImgView.snp.makeConstraints { (make) in
            make.centerY.equalToSuperview()
            make.right.equalToSuperview().inset(30)
            make.width.equalTo(13)
            make.height.equalTo(16)
        }
        
        alertView.addSubview(contentView)
        alertView.addSubview(cancelBtn)
        alertView.addSubview(confirmBtn)
        
        
        cancelBtn.snp.makeConstraints { (make) in
            make.left.bottom.equalToSuperview()
            make.width.equalTo(144)
            make.height.equalTo(44)
        }
        
        confirmBtn.snp.makeConstraints { (make) in
            make.right.bottom.equalToSuperview()
            make.size.equalTo(cancelBtn)
        }
        
        commonAlert = CustomMBProgressHUD.showAdded(to: parentView, animated: true)
        commonAlert!.customView = alertView
        alertView.snp.makeConstraints { (make) in
            make.width.equalTo(288)
            make.height.equalTo(166)
        }
    }
    
    class func showComfirmAlert(parentView: UIView, contentText: String = "", onConfirmTap: (()->())?) {
        hidePreviousAlert()
        Alert.confirmClosure = onConfirmTap
        let alertView = UIView()
        alertView.backgroundColor = .white
        alertView.layer.cornerRadius = 12
        alertView.clipsToBounds = true
        
        let contentLabel = UILabel()
        contentLabel.text = contentText
        contentLabel.font = UIFont.pingFangRegular(17)
        contentLabel.textColor = RGB(0x4D4D4D)
        contentLabel.textAlignment = contentText.count > 13 ? .left : .center
        contentLabel.numberOfLines = 0
        
        let confirmBtn = UIButton()
        confirmBtn.backgroundColor = RGB(0xF32660)
        confirmBtn.setTitle("確定", for: .normal)
        confirmBtn.setTitleColor(.white, for: .normal)
        confirmBtn.titleLabel?.font = UIFont.pingFangMedium(15)
        confirmBtn.addTarget(self, action: #selector(onConfirmBtnClick), for: .touchUpInside)
        
        alertView.addSubview(contentLabel)
        alertView.addSubview(confirmBtn)
        
        contentLabel.snp.makeConstraints { (make) in
            make.centerX.equalToSuperview()
            make.top.equalTo(35)
            make.width.equalTo(230)
        }
        
        confirmBtn.snp.makeConstraints { (make) in
            make.left.right.bottom.equalToSuperview()
            make.height.equalTo(44)
        }
        
        commonAlert = CustomMBProgressHUD.showAdded(to: parentView, animated: true)
        commonAlert!.customView = alertView
        alertView.snp.makeConstraints { (make) in
            make.width.equalTo(288)
            make.height.equalTo(166)
        }
    }
    
    //MARK:-系统通知
    class func showAnnouncementAlert(parentView: UIView, contentText: String = "", applicationCenterTap: (()->())?, onConfirmTap: (()->())?) {
        hidePreviousAlert()
        
        Alert.applicationCenterClosure = applicationCenterTap
        Alert.confirmClosure = onConfirmTap
        
        let alertView = UIView()
        alertView.layer.cornerRadius = 4
        alertView.layer.masksToBounds = true
        alertView.backgroundColor = .white
        
        let titleLabel = UILabel()
        titleLabel.font = UIFont.pingFangMedium(22)
        titleLabel.textColor = .black
        titleLabel.text = "系統公告"
        
        let textView = UITextView()
        textView.isEditable = false
        textView.text = contentText
        textView.linkTextAttributes = [NSAttributedString.Key.foregroundColor : RGB(0x1E90FF)]
        textView.dataDetectorTypes = .link
        textView.backgroundColor = .none
        textView.font = UIFont.pingFangRegular(14)
        textView.textColor = .black
        
        let lineImgView = UIImageView(image: UIImage(named: "announcement_line"))
        
        let hornImgView = UIImageView(image: UIImage(named: "announcement_horn"))
        
        let btnImg = UIImage(named: "update_btn")
        
        let applicationCenterBtn = UIButton()
        applicationCenterBtn.setBackgroundImage(btnImg, for: .normal)
        applicationCenterBtn.contentEdgeInsets = UIEdgeInsets(top: -6, left: 0, bottom: 0, right: 0)
        applicationCenterBtn.setTitle("應用中心", for: .normal)
        applicationCenterBtn.setTitleColor(.white, for: .normal)
        applicationCenterBtn.titleLabel?.font = UIFont.pingFangRegular(18)
        applicationCenterBtn.addTarget(self, action: #selector(onApplicationCenterBtnClick), for: .touchUpInside)
        
        let confirmBtn = UIButton()
        confirmBtn.setBackgroundImage(btnImg, for: .normal)
        confirmBtn.contentEdgeInsets = applicationCenterBtn.contentEdgeInsets
        confirmBtn.setTitle("我知道了", for: .normal)
        confirmBtn.setTitleColor(.white, for: .normal)
        confirmBtn.titleLabel?.font = UIFont.pingFangRegular(18)
        confirmBtn.addTarget(self, action: #selector(onConfirmBtnClick), for: .touchUpInside)
        
        alertView.addSubview(hornImgView)
        alertView.addSubview(titleLabel)
        alertView.addSubview(lineImgView)
        alertView.addSubview(textView)
        alertView.addSubview(applicationCenterBtn)
        alertView.addSubview(confirmBtn)
        
        hornImgView.snp.makeConstraints { (make) in
            make.right.top.equalToSuperview()
            make.width.equalTo(88)
            make.height.equalTo(87)
        }
        
        titleLabel.snp.makeConstraints { (make) in
            make.top.equalToSuperview().inset(25)
            make.left.equalToSuperview().inset(20)
        }
        
        lineImgView.snp.makeConstraints { (make) in
            make.top.equalTo(titleLabel.snp.bottom)
            make.centerX.equalTo(titleLabel)
            make.width.equalTo(93)
            make.height.equalTo(4)
        }
        
        textView.snp.makeConstraints { (make) in
            make.top.equalTo(hornImgView.snp.bottom).offset(6)
            make.centerX.equalToSuperview()
            make.width.equalTo(224)
            make.height.equalTo(170)
        }
        
        applicationCenterBtn.snp.makeConstraints { (make) in
            make.left.equalToSuperview().inset(10)
            make.bottom.equalToSuperview().inset(6)
            make.width.equalTo(120)
            make.height.equalTo(50)
        }
        
        confirmBtn.snp.makeConstraints { (make) in
            make.right.equalToSuperview().inset(10)
            make.centerY.size.equalTo(applicationCenterBtn)
        }
        
        commonAlert = CustomMBProgressHUD.showAdded(to: parentView, animated: true)
        commonAlert!.customView = alertView
        alertView.snp.makeConstraints { (make) in
            make.width.equalTo(270)
            make.height.equalTo(346)
        }
    }
    
    //MARK:-活动弹框
    class func showActivityMaskAlert(parentView: UIView, maskCoverURL: URL?, onConfirmTap: (()->())?, onCancelTap: (()->())?) {
        
        hidePreviousAlert()
        
        Alert.confirmClosure = onConfirmTap
        Alert.cancelClosure = onCancelTap
        
        let alertView = UIView()
        
        let imgView = AnimatedImageView()
        imgView.isUserInteractionEnabled = true
        imgView.contentMode = .scaleAspectFit
        imgView.runLoopMode = .default
        let tap = UITapGestureRecognizer(target: self, action: #selector(onConfirmBtnClick))
        imgView.addGestureRecognizer(tap)
        if let url = maskCoverURL {
            imgView.kf.setImage(with: url.column0, options: url.column0?.absoluteString.contains(".gif") ?? false ? ClassyCycleScrollViewCell.animationOptionGif : ClassyCycleScrollViewCell.animationOption)
        }
        
        alertView.addSubview(imgView)
        imgView.snp.makeConstraints { (make) in
            make.size.equalTo(UIScreen.main.bounds.width)
            make.top.centerX.equalToSuperview()
        }
        
        let closeBtn = UIButton()
        closeBtn.setBackgroundImage(UIImage(named: "activity_close_btn"), for: .normal)
        closeBtn.addTarget(self, action: #selector(onCancelBtnClick), for: .touchUpInside)
        
        alertView.addSubview(closeBtn)
        closeBtn.snp.makeConstraints { (make) in
            make.size.equalTo(40)
            make.bottom.centerX.equalToSuperview()
        }
        
        commonAlert = CustomMBProgressHUD.showAdded(to: parentView, animated: true)
        commonAlert!.customView = alertView
        alertView.snp.makeConstraints { (make) in
            make.width.equalTo(UIScreen.main.bounds.width)
            make.height.equalTo(UIScreen.main.bounds.width + 20 + 40)
        }
    }
    
    //MARK:-版本更新
    class func showVersionUpdateAlert(parentView: UIView, contentText: String = "", isForceUpdate: Bool = true, versionNumber: String = "", onConfirmTap: (()->())?, onCancelTap: (()->())?) {
        hidePreviousAlert()
        Alert.confirmClosure = onConfirmTap
        Alert.cancelClosure = onCancelTap
        let versionUpdateView = VersionUpdateView(contentText: contentText, isForceUpdate: isForceUpdate, versionNumber: versionNumber)
        commonAlert = CustomMBProgressHUD.showAdded(to: parentView, animated: true)
        commonAlert!.customView = versionUpdateView
        versionUpdateView.snp.makeConstraints { (make) in
            make.width.equalTo(296)
            make.height.equalTo(430 + (isForceUpdate ? 0 : 25 + 38))
        }
    }
    
    class func showLoading(parentView: UIView) {
        hidePreviousLoading()
        loading = MBProgressHUD.showAdded(to: parentView, animated: true)
        loading?.margin = 0
        loading?.mode = .customView
        loading?.customView = loadingImgView
        loading?.bezelView.style = .solidColor
        loading?.bezelView.backgroundColor = .none
        loading?.backgroundColor = UIColor.black.withAlphaComponent(0.3)  //設定遮罩為半透明黑色
        loading?.animationType = .zoom
        loadingImgView.snp.makeConstraints { (make) in
            make.size.equalTo(50)
        }
        loadingImgView.layer.add(animation, forKey: nil)
    }
    
    class func hideLoading() {
        loading?.hide(animated: true)
        loading = nil
    }
    
    class func hidePreviousLoading() {
        loading?.hide(animated: false)
        loading = nil
    }
}


