//
//  PurchaseVipAlert.swift
//  Sp
//
//  Created by mac on 2020/12/25.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class PurchaseVipAlert: UIView {
    
    private static let instance: PurchaseVipAlert = {
        return PurchaseVipAlert()
    }()
    
    private static let bgImg: UIImage? = {
        return UIImage(named: "purchase_vip_bg_icon")
    }()
    
    private static let cancelImg: UIImage? = {
        return UIImage(named: "purchase_vip_cancel_icon")
    }()
    
    private static let confirmImg: UIImage? = {
        return UIImage(named: "purchase_vip_confirm_icon")
    }()
    
    var completion: (() -> ())?
    
    private lazy var tipLabel: UILabel = {
        let label = UILabel()
        label.text = "很遺憾，您當前沒有享受VIP特權的福利！！！"
        label.textColor = rgb(0x313131)
        label.font = font(14, .light)
        label.textAlignment = .center
        return label
    }()
    
    private lazy var cancelBtn: UIButton = {
        let btn = UIButton()
        btn.setBackgroundImage(PurchaseVipAlert.cancelImg, for: .normal)
        btn.addTarget(self, action: #selector(onCancelBtnTap), for: .touchUpInside)
        return btn
    }()
    
    private lazy var confirmBtn: UIButton = {
        let btn = UIButton()
        btn.setBackgroundImage(PurchaseVipAlert.confirmImg, for: .normal)
        btn.addTarget(self, action: #selector(onConfirmBtnTap), for: .touchUpInside)
        return btn
    }()
    
    
    private lazy var bgImgView: UIImageView = {
        let imgView = UIImageView(image: PurchaseVipAlert.bgImg)
        imgView.isUserInteractionEnabled = true
        imgView.addSubview(tipLabel)
        imgView.addSubview(cancelBtn)
        imgView.addSubview(confirmBtn)
        
        tipLabel.snp.makeConstraints { (make) in
            make.top.equalToSuperview().inset(162)
            make.left.right.equalToSuperview()
        }
        
        cancelBtn.snp.makeConstraints { (make) in
            make.bottom.equalToSuperview().inset(10)
            make.left.equalToSuperview().inset(25)
            make.width.equalTo(142)
            make.height.equalTo(54)
        }
        
        confirmBtn.snp.makeConstraints { (make) in
            make.bottom.equalTo(cancelBtn)
            make.right.equalToSuperview().inset(25)
            make.width.equalTo(142)
            make.height.equalTo(54)
        }
        
        return imgView
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        alpha = 0
        backgroundColor = UIColor.black.withAlphaComponent(0.5)
        addSubview(bgImgView)
        
        bgImgView.snp.makeConstraints { (make) in
            make.center.equalToSuperview()
            make.width.equalTo(331)
            make.height.equalTo(259)
        }
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    @objc private func onCancelBtnTap() {
        hidePopUpAlertAnimation()
    }
    
    @objc private func onConfirmBtnTap() {
        hidePopUpAlertAnimation()
        guard let navigationController = (UIApplication.shared.delegate as? AppDelegate)?.currentNavigationController else { return }
        VipChargeTipVC.isFromVideoPlayList = false
        navigationController.show(Vip2VC(), sender: nil)
    }
    
    private func startPopUpAlertAnimation() {
        UIView.animate(withDuration: 0.5) { [weak self] in
            self?.alpha = 1
        }
    }
    
    private func hidePopUpAlertAnimation() {
        UIView.animate(withDuration: 0.5) { [weak self] in
            self?.alpha = 0
        } completion: { [weak self] isCompletion in
            self?.removeFromSuperview()
        }
    }
    
    static func showPurchaseVipAlert() {
        
        guard let window = UIApplication.shared.keyWindow else { return }
        PurchaseVipAlert.instance.removeFromSuperview()
        window.addSubview(PurchaseVipAlert.instance)
        
        PurchaseVipAlert.instance.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
        let instance =  PurchaseVipAlert.instance
        instance.startPopUpAlertAnimation()
        instance.completion = {
            guard let navigationController = (UIApplication.shared.delegate as? AppDelegate)?.currentNavigationController else { return }
            VipChargeTipVC.isFromVideoPlayList = false
            navigationController.show(Vip2VC(), sender: nil)
        }
    }
    
    
    /// added by wangdazhaung  主要用在present的AudioNoveldetailVC
    static func showPurchaseVipAlert(_ completion:@escaping(()->())) {
        guard let window = UIApplication.shared.keyWindow else { return }
        PurchaseVipAlert.instance.removeFromSuperview()
        window.addSubview(PurchaseVipAlert.instance)
        
        PurchaseVipAlert.instance.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
        
        let instance = PurchaseVipAlert.instance
        instance.startPopUpAlertAnimation()
        instance.completion = {
            completion()
        }
    }
    
}
