//
//  CommonCategoryScrollView.swift
//
//  Created by mac on 2019/10/22.
//  Copyright © 2019 mac. All rights reserved.
//


class CommonCategoryScrollView: UIScrollView {
    
    
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        isUserInteractionEnabled = true
        isDirectionalLockEnabled = true
        clipsToBounds = false
        showsHorizontalScrollIndicator = false
        showsVerticalScrollIndicator = false
        scrollsToTop = false
        isPagingEnabled = true
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}
