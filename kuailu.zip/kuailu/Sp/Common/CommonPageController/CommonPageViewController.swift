


protocol CommonPageViewControllerDelegate: NSObjectProtocol {
    func commonPageViewController(_ viewController: CommonPageViewController, scrollViewDidScroll scrollView: UIScrollView)
}

class CommonPageViewController: UIViewController {
    
    weak var delegate: CommonPageViewControllerDelegate?
    private(set) var viewControllers = [UIViewController]()
    private(set) var currentIndex: Int = 0
    private var pageScrollView: UIScrollView!
    
    init(viewControllers: [UIViewController]) {
        super.init(nibName: nil, bundle: nil)
        self.viewControllers = viewControllers
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        prepareView()
    }
 
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        pageScrollView.frame = CGRect(x: 0, y: 0, width: view.width, height: view.height)
        pageScrollView.contentSize = CGSize(width: view.width * CGFloat(viewControllers.count), height: 0)
        for i in 0..<viewControllers.count {
            let child = viewControllers[i]
            child.view.frame.origin.x = CGFloat(i) * view.width
        }
    }
    
    private func prepareView() {
        pageScrollView = UIScrollView()
        pageScrollView.showsVerticalScrollIndicator = false
        pageScrollView.showsHorizontalScrollIndicator = false
        pageScrollView.isPagingEnabled = true
        pageScrollView.delegate = self
        view.addSubview(pageScrollView)
        for child in viewControllers {
            pageScrollView.addSubview(child.view)
            addChild(child)
        }
        if #available(iOS 11.0, *) {
            pageScrollView.contentInsetAdjustmentBehavior = .never
            
        } else {
            automaticallyAdjustsScrollViewInsets = false
        }
    }
    
    func move(to: Int, animated: Bool) {
        pageScrollView.setContentOffset(CGPoint(x: CGFloat(to) * view.width, y: 0), animated: animated)
//        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 0.5) {
//            self.scrollViewDidEndDecelerating(self.pageScrollView)
//        }
    }
}

extension CommonPageViewController: UIScrollViewDelegate {
    
//    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
//        currentIndex = Int(scrollView.contentOffset.x / scrollView.width + 0.5) % viewControllers.count
//    }
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
         delegate?.commonPageViewController(self, scrollViewDidScroll: scrollView)
    }
}

