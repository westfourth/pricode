//
//  ScrollStateEmptyView.swift
//  Puff
//
//  Created by mac on 2019/11/1.
//  Copyright © 2019 mac. All rights reserved.
//

import UIKit

class ScrollStateEmptyView: UIView {

    override init(frame: CGRect) {
        super.init(frame: frame)
        addSubview(imageView)
        addSubview(label)
        setNeedsUpdateConstraints()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    deinit {
        puts(#function)
    }
    
    override func updateConstraints() {
        imageView.snp.makeConstraints { (make) in
            make.centerX.equalToSuperview().multipliedBy(1)
            make.centerY.equalToSuperview().multipliedBy(0.8)
            make.width.equalTo(158)
            make.height.equalTo(146)
            
        }
        label.snp.makeConstraints { (make) in
            make.centerX.equalToSuperview().multipliedBy(1)
            make.top.equalTo(imageView.snp.bottom).offset(30)
        }
        super.updateConstraints()
    }

    var imageView: UIImageView = {
        let imageView = UIImageView()
        let image = UIImage(named: "common_bg_nodata")
        imageView.image = image
        return imageView
    }()
    
    var label: UILabel = {
        let label = UILabel()
        label.font = UIFont.pingFangMedium(15)
        label.textColor = RGB(0x999999)
        label.textAlignment = .center
        label.text = "暫無信息~";
        return label
    }()
    
}
