//
//  ScrollStateLoadingView.swift
//  Puff
//
//  Created by mac on 2019/11/1.
//  Copyright © 2019 mac. All rights reserved.
//

import UIKit

class ScrollStateLoadingView: UIView, UIScrollViewAnimate {
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        addSubview(animateImageView)
        addSubview(label)
        setNeedsUpdateConstraints()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    deinit {
        puts(#function)
    }
    
    override func updateConstraints() {
        animateImageView.snp.makeConstraints { (make) in
            make.centerX.equalToSuperview()
            make.centerY.equalToSuperview().multipliedBy(0.8)
        }
        label.snp.makeConstraints { (make) in
            make.centerX.equalToSuperview().multipliedBy(1)
            make.top.equalTo(animateImageView.snp.bottom).offset(30)
        }
        super.updateConstraints()
    }
    
    private static let animatedImages: [UIImage] = {
        var a = [UIImage]()
        for i in 1...3 {
            let image = UIImage(named: "common_bg_loading_\(i)")!
            a.append(image)
        }
        return a
    }()
    
    func startAnimating() {
        animateImageView.startAnimating()
    }
    
    func stopAnimating() {
        animateImageView.stopAnimating()
    }
    
    var animateImageView: UIImageView = {
        let imageView = UIImageView()
        imageView.animationImages = animatedImages
        imageView.animationDuration = Double(animatedImages.count) * 1.0 / 8.0;
        return imageView
    }()
    
    var label: UILabel = {
        let label = UILabel()
        label.font = UIFont.pingFangMedium(15)
        label.textColor = RGB(0x999999)
        label.textAlignment = .center
        label.text = "拚命載入中~";
        return label
    }()
    
}
