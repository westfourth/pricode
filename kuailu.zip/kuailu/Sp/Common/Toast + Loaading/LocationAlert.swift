//
//  LocationAlert.swift
//  CaoLong
//
//  Created by mac on 2020/6/26.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class LocationAlert: UIView {
    @IBOutlet weak var bgView: UIView!
    @IBOutlet weak var location: UILabel!
    
    var callback: ((String?) -> ())?
    var cancel: (() -> ())?
    
    override func awakeFromNib() {
        super.awakeFromNib()
//        object_setClass(bgView.layer, CAGradientLayer.self)
//        let i = bgView.layer as! CAGradientLayer
//        i.colors = [rgb(0xffF31258).cgColor,rgb(0xffFF6A62).cgColor,rgb(0xffC83C33).cgColor]
//        i.startPoint = CGPoint(x: 0, y: 0)
//        i.endPoint = CGPoint(x: 1, y: 0)
        bgView.backgroundColor =  UIColor.black.withAlphaComponent(0.4)
    }
    
    var city:String? {
        didSet {
            guard let name = city else {
                return
            }
            location.text = "定位您当前在\(name)，是否切换？"
        }
    }
    
    @IBAction func confirmAction(_ sender: Any) {

        callback?(city)
    }
    
    @IBAction func cancelAction(_ sender: Any) {
    
        cancel?()
    }
}
