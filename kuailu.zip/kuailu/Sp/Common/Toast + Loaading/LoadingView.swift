//
//  LoadingView.swift
//  CaoLong
//
//  Created by mac on 2020/6/4.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class LoadingView: UIView {
    
    @IBOutlet weak var logo: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        logo.layer.add(animation, forKey: nil)
        logo.animationDuration = 3.0
        contentMode = .center
    }
    
//    private let animatedImages: [UIImage] = {
//        var a = [UIImage]()
//        for i in 0...90 {
////            if i % 2 == 1 {
//                let image = UIImage(named: "loading\(i)")!
//                a.append(image)
////            }
//        }
//        return a
//    }()
    
    lazy var animation: CABasicAnimation = {
        let animation = CABasicAnimation(keyPath: "transform.rotation.z")
        animation.fromValue = 0
        animation.toValue = Double.pi * 2
        animation.duration = 1
        animation.autoreverses = false
        animation.isRemovedOnCompletion = false
        animation.fillMode = .forwards
        animation.repeatCount = MAXFLOAT
        animation.timingFunction = CAMediaTimingFunction(name: .easeInEaseOut)
        return animation
    }()

    deinit {
        logo.layer.removeAllAnimations()
    }
}

