//
//  Toast.swift
//  CaoLong
//
//  Created by mac on 2020/6/4.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class Toast: UIView {
    @IBOutlet weak var icon: UIImageView!
    @IBOutlet weak var name: UILabel!
    @IBOutlet weak var widthCons: NSLayoutConstraint!
    @IBOutlet weak var HeightCons: NSLayoutConstraint!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        icon.image = UIImage(named: "toast_失敗")
    }
    
    var title:String = "" {
        didSet {
            name.text = title
            // 计算title的长度和高度
             let maxWidth = UIScreen.main.bounds.width * 0.7
            let minWidth:CGFloat =  140
            let w = title.getStringSize(rectSize: .zero, font: UIFont.systemFont(ofSize: 15)).width
            let h = title.getStringSize(rectSize: CGSize(width: maxWidth - 20, height: UIScreen.main.bounds.size.height), font: UIFont.systemFont(ofSize: 15)).height
            
            let gap:CGFloat = 20
            if w + gap <= maxWidth {
                if w + gap < minWidth {
                    widthCons.constant = minWidth
                } else {
                    widthCons.constant = w + gap
                }
            } else {
                widthCons.constant = maxWidth
            }
            HeightCons.constant = h + 50 + 18 + 6 + 20
        }
    }
    
    var type:ToastType = .warning {
        didSet {
            switch type {
            case .warning:
                icon.image = UIImage(named: "toast_失敗")
            case .succeed:
                icon.image = UIImage(named: "toast_成功")
            default:
                break
            }
        }
    }
}
