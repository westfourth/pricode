//
//  LoadingToast.swift
//  CaoLong
//
//  Created by mac on 2020/6/5.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit
import ToastSwiftFramework

public enum ToastType: Int {
    case succeed = 0
    case failed = 1
//    case forbidden = 2
    case warning = 3
}

public func loading() {
    hideLoading()
    let loadingView = Bundle.main.loadNibNamed("LoadingView", owner: nil, options: [:])?.first as! LoadingView
    loadingView.frame = UIScreen.main.bounds
    UIApplication.shared.keyWindow!.showToast(loadingView, duration: 10000, position: .center)
}

public func hideLoading() {
     UIApplication.shared.keyWindow!.hideAllToasts()
}


public func iToast(_ text: String, type: ToastType = .warning, duration: Double = 1, callback: ((Bool)->())? = nil) {
    hideLoading()
    let toast = Bundle.main.loadNibNamed("Toast", owner: nil, options: [:])?.first as! Toast
    toast.title = text
    toast.type = type
    toast.frame = UIScreen.main.bounds
    UIApplication.shared.keyWindow!.showToast(toast, duration: duration, position: .center,completion: callback)
}


public func locationToast(_ city:String,callback:@escaping((String)->())) {
    hideLoading()
    let loadingView = Bundle.main.loadNibNamed("LocationAlert", owner: nil, options: [:])?.first as! LocationAlert
    loadingView.frame = UIScreen.main.bounds
    loadingView.city = city
    loadingView.cancel = {
        hideLoading()
    }
    
    loadingView.callback = {  (name) in
        hideLoading()
        guard let name = name else {return}
        callback(name)
    }
    
    UIApplication.shared.keyWindow!.showToast(loadingView, duration: 10000, position: .center)
}
