//
//  CommonAlertView.swift
//  CaoLong
//
//  Created by mac on 2020/7/3.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

public func alertController(_ title:String,
                            cancelTitle:String,
                            superView:UIView,
                            cancelCallBack:@escaping(()->()),
                            positiveTitle:String,
                            positiveCallBack:@escaping(()->())) {
    hideLoading()
    let toast = Bundle.main.loadNibNamed("CommonAlertView", owner: nil, options: [:])?.first as! CommonAlertView
    toast.title = title
    toast.cancelButton.setTitle(cancelTitle, for: .normal)
    toast.positiveButton.setTitle(positiveTitle, for: .normal)
    toast.frame = UIScreen.main.bounds
    toast.cancel = {
        superView.hideAllToasts()
        cancelCallBack()
    }
    toast.positive = {
         superView.hideAllToasts()
      positiveCallBack()
    }
    
    superView.showToast(toast, duration: 100000, position: .center,completion: nil)
}

class CommonAlertView: UIView {
    @IBOutlet weak var name: UILabel!
    @IBOutlet weak var cancelButton: UIButton!
    @IBOutlet weak var positiveButton: UIButton!
    @IBOutlet weak var heightCons: NSLayoutConstraint!
    
     var cancel: (() -> ())?
     var positive: (() -> ())?
    
    var title:String?{
        didSet {
            guard let content = title else {
                return
            }
            heightCons.constant = 25 + content.getStringSize(rectSize: CGSize(width: 250, height: CGFloat.greatestFiniteMagnitude), font: UIFont.systemFont(ofSize: 17)).height + 40 + 60
            name.text = content
        }
    }
    
    @IBAction func cancelAction(_ sender: Any) {
        cancel?()
    }
    
    @IBAction func positiveAction(_ sender: Any) {
        positive?()
    }
    
}
