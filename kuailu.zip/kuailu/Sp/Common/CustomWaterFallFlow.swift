//
//  CustomWaterFallFlow.swift
//  Puff
//
//  Created by mac on 2019/12/10.
//  Copyright © 2019 mac. All rights reserved.
//


class CustomWaterFallFlow: UICollectionViewFlowLayout {
    var dataArray:[Any] = []
    private var attrArray:[UICollectionViewLayoutAttributes] = []
    private var column:Int = 0
    private lazy var framYArray = [CGFloat](repeating: self.sectionInset.top, count: column)
    
    func initLayout (data:[Any],columns:Int,marginLeft:CGFloat,marginRight:CGFloat,marginMinH:CGFloat,marginMinV:CGFloat) {
        
        self.dataArray = data
        self.minimumInteritemSpacing = marginMinH
        self.minimumLineSpacing = marginMinV
        self.sectionInset = UIEdgeInsets(top: 0, left:marginLeft , bottom: 0, right: marginRight)
        self.column = columns
        
    }
    
    override func prepare() {
        //        print("test dataArray prepare \(self.dataArray.count)")
        attrArray = []
        framYArray = [CGFloat](repeating: self.sectionInset.top, count: column)
        //计算每个宽度
        //        let allwidth = (self.collectionView?.bounds.size.width)!
        //        let marginleft = self.sectionInset.left
        //        let marginRight = self.sectionInset.right
        //        let totalMargin:CGFloat = ((CGFloat)(column - 1) * self.minimumInteritemSpacing)
        //        let itemw:CGFloat = (allwidth - marginRight - marginleft - totalMargin) / (CGFloat)(column)
        for i in 0..<self.dataArray.count {
            //            print("test dataArray \(i)")
            //            print("test dataArray \(self.dataArray[i].width), \(self.dataArray[i].height)")
            
            let indexpath = IndexPath(item: i, section: 0)
            let attrs = UICollectionViewLayoutAttributes(forCellWith: indexpath)
            
            //计算每个高度
            //              let model: Any = self.dataArray[i]
            //              let itemh  = model.height > model.width ? model.height * itemw / model.width : 360
            //计算每个X
            //计算当前cell是第几列
            //            let colunm = self.getMinYofTheFrameY(frameYArray: self.framYArray)
            
            //            let itemX = marginleft + (self.minimumInteritemSpacing + itemw) * (CGFloat)(colunm)
            
            //取出当前的列数的Y值
            //              let itemY = self.framYArray[colunm]
            //               attrs.frame = CGRect(x: itemX, y: itemY, width: itemw, height: itemh)
            //              self.framYArray[colunm] = self.framYArray[colunm] + itemh + self.minimumLineSpacing
            self.attrArray.append(attrs)
        }
    }
    
    override func layoutAttributesForElements(in rect: CGRect) -> [UICollectionViewLayoutAttributes]? {
        return self.attrArray
    }
    
    override var collectionViewContentSize: CGSize{
        //假设阵列的第一列值最大
        var maxY = self.framYArray[0];
        for i in 0 ..< self.framYArray.count {
            if(maxY<self.framYArray[i]){
                maxY = self.framYArray[i]
            }
        }
        
        return CGSize(width: (self.collectionView?.bounds.size.width)!, height: maxY)
        
    }
    
    //计算那列的最大Y值最小
    private func getMinYofTheFrameY(frameYArray:[CGFloat])->(Int){
        //假设第0列的最大Y值最小
        var minIndex:Int = 0
        var minY = frameYArray[minIndex]
        for u in 0 ..< frameYArray.count {
            if(minY > frameYArray[u]){
                minY = frameYArray[u]
                minIndex = u
            }
        }
        return minIndex
    }
}
