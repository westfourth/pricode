
//
//  UIFontExtension.swift
//  Sp
//
//  Created by mac on 2020/3/30.
//  Copyright © 2020 mac. All rights reserved.
//

/// 修补在UITableViewCell中不能使用font()
func FONT(_ size: CGFloat, _ weight: UIFont.Weight = .regular) -> UIFont {
    return font(size, weight)
}

/// 字体
func font(_ size: CGFloat, _ weight: UIFont.Weight = .regular) -> UIFont {
    var fontName: String = ""
    switch weight {
    case .ultraLight:
        fontName = "PingFangSC-Ultralight"
    case .thin:
        fontName = "PingFangSC-Thin"
    case .light:
        fontName = "PingFangSC-Light"
    case .regular:
        fontName = "PingFangSC-Regular"
    case .medium:
        fontName = "PingFangSC-Medium"
    case .semibold:
        fontName = "PingFangSC-Semibold"
    default:
        assert(false, "平方字体不支持：\(weight)")
    }
    let fontDesc = UIFontDescriptor(name: fontName, size: size)
    return UIFont(descriptor: fontDesc, size: 0)
    //    return UIFont.systemFont(ofSize: size, weight: weight)
}

extension UIFont {
    // 可以通过let names = UIFont.fontNames(forFamilyName: "PingFang SC") 来遍历所有PingFang 的字型名字 iOS9.0 以后支持
    /*
     PingFangSC-Semibold 苹方-简 中粗体
     PingFangSC-Regular 苹方-简 常规体
     PingFangSC-Medium 苹方-简 中黑体
     PingFangSC-Light 苹方-简 细体
     PingFangSC-Thin 苹方-简 纤细体
     PingFangSC-Ultralight 苹方-简 极细体
     */
    
    public static func pingFangSemibold(_ size: CGFloat) -> UIFont {
        guard let font = UIFont(name: "PingFangSC-Semibold", size: size) else {
            return UIFont.systemFont(ofSize: size)
        }
        return font
    }
    
    public static func pingFangHeavy(_ size: CGFloat) -> UIFont {
        guard let font = UIFont(name: "PingFangSC-Semibold", size: size) else {
            return UIFont.systemFont(ofSize: size)
        }
        return font
    }
    
    public static func pingFangRegular(_ size: CGFloat) -> UIFont {
        guard let font = UIFont(name: "PingFangSC-Regular", size: size) else {
            return UIFont.systemFont(ofSize: size)
        }
        return font
    }
    
    public static func pingFangMedium(_ size: CGFloat) -> UIFont {
        guard let font = UIFont(name: "PingFangSC-Medium", size: size) else {
            return UIFont.systemFont(ofSize: size)
        }
        return font
    }
    
    public static func pingFangLight(_ size: CGFloat) -> UIFont {
        guard let font = UIFont(name: "PingFangSC-Light", size: size) else {
            return UIFont.systemFont(ofSize: size)
        }
        return font
    }
    
    public static func pingFangThin(_ size: CGFloat) -> UIFont {
        guard let font = UIFont(name: "PingFangSC-Thin", size: size) else {
            return UIFont.systemFont(ofSize: size)
        }
        return font
    }
    
    public static func pingFangUltralight(_ size: CGFloat) -> UIFont {
        guard let font = UIFont(name: "PingFangSC-Ultralight", size: size) else {
            return UIFont.systemFont(ofSize: size)
        }
        return font
    }
}

//MARK: -定义button相对label的位置
enum UIButtonImagePosition {
    case top          //圖片在上，文字在下，垂直居中對齊
    case bottom       //圖片在下，文字在上，垂直居中對齊
    case left         //圖片在左，文字在右，水平居中對齊
    case right        //圖片在右，文字在左，水平居中對齊
}

extension UIButton {
    //MARK: -Description 设置Button图片的位置
    /// - Parameters:
    ///   - imageStyle: 图片位置
    ///   - spacing: 按钮图片与文字之间的间隔
    func imagePosition(imageStyle: UIButtonImagePosition, spacing: CGFloat) {
        //得到imageView和titleLabel的宽高
        let imageWidth = self.imageView?.frame.size.width
        let imageHeight = self.imageView?.frame.size.height
        
        var labelWidth: CGFloat! = 0.0
        var labelHeight: CGFloat! = 0.0
        
        labelWidth = self.titleLabel?.intrinsicContentSize.width
        labelHeight = self.titleLabel?.intrinsicContentSize.height
        
        //初始化imageEdgeInsets和labelEdgeInsets
        var imageEdgeInsets = UIEdgeInsets.zero
        var labelEdgeInsets = UIEdgeInsets.zero
        
        //根据style和space得到imageEdgeInsets和labelEdgeInsets的值
        switch imageStyle {
        case .top:
            //上 左 下 右
            imageEdgeInsets = UIEdgeInsets(top: -labelHeight-spacing/2, left: 0, bottom: 0, right: -labelWidth)
            labelEdgeInsets = UIEdgeInsets(top: 0, left: -imageWidth!, bottom: -imageHeight!-spacing/2, right: 0)
            break
        case .left:
            imageEdgeInsets = UIEdgeInsets(top: 0, left: -spacing/2, bottom: 0, right: spacing)
            labelEdgeInsets = UIEdgeInsets(top: 0, left: spacing/2, bottom: 0, right: -spacing/2)
            break
        case .bottom:
            imageEdgeInsets = UIEdgeInsets(top: 0, left: 0, bottom: -labelHeight!-spacing/2, right: -labelWidth)
            labelEdgeInsets = UIEdgeInsets(top: -imageHeight!-spacing/2, left: -imageWidth!, bottom: 0, right: 0)
            break
        case .right:
            imageEdgeInsets = UIEdgeInsets(top: 0, left: labelWidth+spacing/2, bottom: 0, right: -labelWidth-spacing/2)
            labelEdgeInsets = UIEdgeInsets(top: 0, left: -imageWidth!-spacing/2, bottom: 0, right: imageWidth!+spacing/2)
            break
        }
        
        self.titleEdgeInsets = labelEdgeInsets
        self.imageEdgeInsets = imageEdgeInsets
    }
}
