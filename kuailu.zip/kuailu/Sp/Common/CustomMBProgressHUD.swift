//
//  CustomMBProgressHUD.swift
//  Sp
//
//  Created by mac on 2020/2/28.
//  Copyright © 2020 mac. All rights reserved.
//

class CustomMBProgressHUD: MBProgressHUD {
    
    static var tapBlankDismiss: Bool = true
    
    override init(frame: CGRect) {
        super.init(frame: frame)
    }
    
    override init(view: UIView) {
        super.init(view: view)
        self.mode = .customView //模式設定為自定義檢查
        self.margin = 0 // HUD內部檢查相對於HUD的邊距
        let tap = UITapGestureRecognizer(target: self, action: #selector(onMaskLayerTapCallback))
        self.backgroundView.addGestureRecognizer(tap)
        self.bezelView.style = .solidColor
        self.bezelView.backgroundColor = .none
        self.backgroundColor = UIColor.black.withAlphaComponent(0.3)  //設定遮罩為半透明黑色
        //        self.backgroundView.style = .blur  //模糊的遮罩背景
        //        self.backgroundView.blurEffectStyle = .light
        //        self.backgroundView.alpha = 0.5
        self.animationType = .zoom
        ///如果设定了minShowTime，就会在hide方法触发后判断任务执行的时间是否短于minShowTime。因此即使任务在minShowTime之前完成了，HUD也不会立即消失，它会在走完minShowTime之后才消失，这应该也是避免HUD一闪而过的情况。
        self.minShowTime = TimeInterval(0.5)
        ///用来推迟HUD的显示。如果设定了graceTime，那么HUD会在show方法触发后的graceTime时间后显示。它的意义是：如果任务完成所消耗的时间非常短并且短于graceTime，则HUD就不会出现了，避免HUD一闪而过的差体验。
        //        self.graceTime = TimeInterval(0.5)
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    @objc private func onMaskLayerTapCallback() {
        if CustomMBProgressHUD.tapBlankDismiss  {
             self.hide(animated: true)
        }
    }
}



