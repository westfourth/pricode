//
//  CustomMJRefresh.swift
//  Sp
//
//  Created by mac on 2020/2/26.
//  Copyright © 2020 mac. All rights reserved.
//

public func getCommonMJHeader(refreshingTarget: Any, headerRefreshCallback: Selector)-> MJRefreshNormalHeader {
    let mjHeader = MJRefreshNormalHeader(refreshingTarget: refreshingTarget, refreshingAction: headerRefreshCallback)
    mjHeader.setTitle("下拉刷新", for: .idle)
    mjHeader.setTitle("刷新中...", for: .refreshing)
    mjHeader.setTitle("準備刷新數據", for: .pulling)
    mjHeader.setTitle("沒有更多數據", for: .noMoreData)
    mjHeader.lastUpdatedTimeLabel?.isHidden = true
    return mjHeader
}

public func getCommonMJFooter(refreshingTarget: Any, footerRefreshCallback: Selector)-> MJRefreshAutoNormalFooter {
    let mjFooter = MJRefreshAutoNormalFooter(refreshingTarget: refreshingTarget, refreshingAction: footerRefreshCallback)
    mjFooter.setTitle("", for: .idle)
    mjFooter.setTitle("載入中...", for: .refreshing)
    mjFooter.setTitle("準備加載數據", for: .pulling)
    mjFooter.setTitle("到底啦", for: .noMoreData)
    // 是否自动重新整理(预设为YES)
    //        mjFooter?.isAutomaticallyRefresh = true;
    // 设定触发上拉载入回拨偏移量
//    mjFooter.triggerAutomaticallyRefreshPercent = -20;
    return mjFooter
}

//MARK:-全局数字万化处理
public func num2TenThousandStrFormat(_ num: Int)-> String {
    return num < 10000 ? "\(num)" : "\(String(format:"%.1f",  Double(num) / 10000))w"
    //    if num < 10000 { return "\(num)" }
    //    let rawVal = Double(num) / 10000
    //    let remainder =  rawVal.truncatingRemainder(dividingBy: 1)
    //    return "\(remainder < 0.1 ? "\(Int(rawVal))" : remainder >= 0.95 ? "\(Int(rawVal) + 1)" : String(format:"%.1f", rawVal))w"
}

//MARK:-全局数字万化处理
public func num2TenThousandStrFormatWithChinese(_ num: Int)-> String {
    return num < 10000 ? "\(num)" : "\(String(format:"%.1f",  Double(num) / 10000))萬"
}
