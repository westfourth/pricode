
//  Created by bestdew on 2019/3/8.
//  Copyright © 2019 bestdew. All rights reserved.




enum ScrollDirection: Int {
    case horizontal
    case vertical
}

protocol CycleScrollViewDataSource: NSObjectProtocol {
    /// Return number of pages
    func numberOfItems(in cycleScrollView: CycleScrollView) -> Int
    /// The cell that is returned must be retrieved from a call to -dequeueReusableCellWithReuseIdentifier:forIndex:
    func cycleScrollView(_ cycleScrollView: CycleScrollView, cellForItemAt index: Int) -> UICollectionViewCell
}

@objc protocol CycleScrollViewDelegate: NSObjectProtocol {
    /// Called when the cell is clicked
    @objc optional func cycleScrollView(_ cycleScrollView: CycleScrollView, didSelectItemAt index: Int)
    /// Called when the offset changes. The progress range is from 0 to the maximum index value, which means the progress value for a round of scrolling
    @objc optional func cycleScrollViewDidScroll(_ cycleScrollView: CycleScrollView, progress: Double)
    /// Called when scrolling to a new index page
    @objc optional func cycleScrollView(_ cycleScrollView: CycleScrollView, didScrollFromIndex fromIndex: Int, toIndex: Int)
}

class CycleScrollView: UIView {
    
    weak var delegate: CycleScrollViewDelegate?
    weak var dataSource: CycleScrollViewDataSource?
    
    /// default horizontal. scroll direction
    var scrollDirection: ScrollDirection = .horizontal {
        didSet {
            switch scrollDirection {
            case .vertical:
                flowLayout?.scrollDirection = .vertical
            default:
                flowLayout?.scrollDirection = .horizontal
            }
        }
    }
    /// default 3.f. automatic scroll time interval
    var autoScrollInterval: TimeInterval = 3 {
        didSet {
            addTimer()
        }
    }
    var isAutoScroll: Bool = true {
        didSet {
            addTimer()
        }
    }
    /// default true. turn off any dragging temporarily
    var allowsDragging: Bool = true {
        didSet {
            collectionView.isScrollEnabled = allowsDragging
        }
    }
    /// default the view size
    var itemSize: CGSize = CGSize.zero {
        didSet {
            itemSizeFlag = true
            flowLayout.itemSize = itemSize
            flowLayout.headerReferenceSize = CGSize(width: (bounds.width - itemSize.width) / 2, height: (bounds.height - itemSize.height) / 2)
            flowLayout.footerReferenceSize = CGSize(width: (bounds.width - itemSize.width) / 2, height: (bounds.height - itemSize.height) / 2)
        }
    }
    /// default 0.0
    var itemSpacing: CGFloat = 0.0 {
        didSet {
            flowLayout.minimumLineSpacing = itemSpacing
        }
    }
    /// default 1.f(no scaling), it ranges from 0.f to 1.f
    var itemZoomScale: CGFloat = 1.0 {
        didSet {
            flowLayout.zoomScale = itemZoomScale
        }
    }
    
    var hidesPageControl: Bool = false {
        didSet {
            pageControl?.isHidden = hidesPageControl
        }
    }
    var pageIndicatorTintColor: UIColor = UIColor.gray {
        didSet {
//            pageControl?.pageIndicatorTintColor = pageIndicatorTintColor
        }
    }
    var currentPageIndicatorTintColor: UIColor = UIColor.white {
        didSet {
//            pageControl?.currentPageIndicatorTintColor = currentPageIndicatorTintColor
        }
    }
    /// current page index
    var pageIndex: Int {
        return changeIndex(currentIndex())
    }
    /// current content offset
    var contentOffset: CGPoint {
        switch scrollDirection {
        case .vertical:
            return CGPoint(x: 0.0, y: max(0.0, collectionView.contentOffset.y - (flowLayout.itemSize.height + flowLayout.minimumLineSpacing) * 2))
        default:
            return CGPoint(x: max(0.0, collectionView.contentOffset.x - (flowLayout.itemSize.width + flowLayout.minimumLineSpacing) * 2), y: 0.0)
        }
    }
    /// load completed callback
    var loadCompletion: (() -> Void)? = nil
    
    var initPageIndex: Int = 0
    
    //    private var pageControl: UIPageControl!
    private var pageControl: CarouselPageControl!
    private var collectionView: UICollectionView!
    private var flowLayout: CycleScrollViewFlowLayout!
    private var timer: Timer?
    private var numberOfItems: Int = 0
    private var fromIndex: Int = 0
    private var itemSizeFlag: Bool = false
    private var indexOffset: Int = 0
    
    // MARK: - Override Func
    override init(frame: CGRect) {
        super.init(frame: frame)
        initialization()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        initialization()
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        flowLayout.itemSize = bounds.size
        flowLayout.headerReferenceSize = .zero
        flowLayout.footerReferenceSize = .zero
        collectionView.frame = bounds
        
    }
    
    override func willMove(toSuperview newSuperview: UIView?) {
        if newSuperview == nil { removeTimer() }
    }
    
    deinit {
        collectionView.delegate = nil
        collectionView.dataSource = nil
    }
    
    // MARK: - Open Func
    func register(_ cellClass: AnyClass?, forCellWithReuseIdentifier identifier: String) {
        collectionView.register(cellClass, forCellWithReuseIdentifier: identifier)
    }
    
    func register(_ nib: UINib?, forCellWithReuseIdentifier identifier: String) {
        collectionView.register(nib, forCellWithReuseIdentifier: identifier)
    }
    
    func dequeueReusableCell(withReuseIdentifier identifier: String, for index: Int) -> UICollectionViewCell {
        let indexPath = IndexPath(item: changeIndex(index), section: 0)
        return collectionView.dequeueReusableCell(withReuseIdentifier: identifier, for: indexPath)
    }
    
    func reloadData() {
        removeTimer()
        UIView.performWithoutAnimation { [weak self] in
            self?.collectionView.reloadData()
        }
        collectionView.performBatchUpdates(nil) { [weak self] _ in
            guard let `self` = self else { return }
            self.configuration()
            self.loadCompletion?()
            self.pageControl.snp.updateConstraints { (make) in
                make.width.equalTo(CGFloat(self.pageControl.numberOfPages) * 14)
            }
            self.updatePageControl()
        }
    }
    
    func refreshCollectionView() {
        collectionView.reloadData()
    }
    
    func adjustWhenViewWillAppear() {
        guard numberOfItems > 1 else { return }
        
        var index = currentIndex()
        let position = scrollPosition()
        if index == 1 {
            index = numberOfItems - 3
        } else if index == numberOfItems - 2 {
            index = 2
        }
        let indexPath = IndexPath(item: index, section: 0)
        collectionView.scrollToItem(at: indexPath, at: position, animated: false)
    }
    
    func scrollToNextItem() {
        removeTimer()
        automaticScroll()
        addTimer()
    }
    
    func scrollToPreviousItem() {
        removeTimer()
        let index = currentIndex() - 1
        let position = scrollPosition()
        let indexPath = IndexPath(item: index, section: 0)
        collectionView.scrollToItem(at: indexPath, at: position, animated: true)
        addTimer()
    }
    
    // MARK: - Private Func
    private func initialization() {
        flowLayout = CycleScrollViewFlowLayout()
        flowLayout.minimumLineSpacing = 0
        flowLayout.minimumInteritemSpacing = 0
        flowLayout.scrollDirection = .horizontal
        
        collectionView = UICollectionView(frame: .zero, collectionViewLayout: flowLayout)
        collectionView.backgroundColor = nil
        collectionView.delegate = self
        collectionView.dataSource = self
        if #available(iOS 14.0, *) {
            collectionView.isPagingEnabled = false
        } else {
            collectionView.isPagingEnabled = true
        }
        collectionView.scrollsToTop = false
        collectionView.bounces = false
        collectionView.showsVerticalScrollIndicator = false
        collectionView.showsHorizontalScrollIndicator = false
        
        addSubview(collectionView)
        pageControl = CarouselPageControl()
        addSubview(pageControl)
        pageControl.snp.makeConstraints { (make) in
            make.centerX.equalToSuperview()
            make.bottom.equalToSuperview().inset(12)
            make.width.equalTo(CGFloat(self.pageControl.numberOfPages) * 14)
            make.height.equalTo(6)
        }
        DispatchQueue.main.async { [weak self] in
            self?.configuration()
            self?.loadCompletion?()
        }
    }
    
    private func configuration() {
        fromIndex = 0
        indexOffset = 0
        
        guard numberOfItems > 1 else { return }
        
        collectionView.scrollToItem(at: IndexPath(item: 2 + initPageIndex, section: 0), at: scrollPosition(), animated: false)
        
        addTimer()
        updatePageControl()
    }
    
    private func addTimer() {
        removeTimer()
        
        if numberOfItems < 2 || !isAutoScroll || autoScrollInterval <= 0.0 { return }
        timer = Timer.scheduledTimer(timeInterval: autoScrollInterval, target: self, selector: #selector(automaticScroll), userInfo: nil, repeats: true)
        RunLoop.main.add(timer!, forMode: .common)
    }
    
    private func updatePageControl() {
        pageControl.currentPage = 0
        pageControl.numberOfPages = max(0, numberOfItems - 4)
        pageControl.isHidden = (hidesPageControl || pageControl.numberOfPages < 2)
    }
    
    @objc private func automaticScroll() {
        let index = currentIndex() + 1
        let position = scrollPosition()
        let indexPath = IndexPath(item: index, section: 0)
        collectionView.scrollToItem(at: indexPath, at: position, animated: true)
    }
    
    private func removeTimer() {
        timer?.invalidate()
        timer = nil
    }
    
    private func scrollPosition() -> UICollectionView.ScrollPosition {
        switch scrollDirection {
        case .vertical:
            return .centeredVertically
        default:
            return .centeredHorizontally
        }
    }
    
    private func currentIndex() -> Int {
        var index = 0
        
        if numberOfItems < 2 || bounds.width <= 0.0 || bounds.height <= 0.0 {
            return index
        }
        
        switch scrollDirection {
        case .vertical:
            let height = flowLayout.itemSize.height + flowLayout.minimumLineSpacing
            index = Int((collectionView.contentOffset.y + height / 2) / height)
        default:
            let width = flowLayout.itemSize.width + flowLayout.minimumLineSpacing
            index = Int((collectionView.contentOffset.x + width / 2) / width)
        }
        return min(numberOfItems - 2, max(1, index))
    }
    
    private func changeIndex(_ index: Int) -> Int {
        guard numberOfItems > 1 else { return index }
        
        var idx = index
        
        switch index {
        case 0:
            idx = numberOfItems - 6
        case 1:
            idx = numberOfItems - 5
        case numberOfItems - 2:
            idx = 0
        case numberOfItems - 1:
            idx = 1
        default:
            idx = index - 2
        }
        return idx
    }
}

extension CycleScrollView: UICollectionViewDelegate {
    
    func collectionView(_ collectionView: UICollectionView, shouldHighlightItemAt indexPath: IndexPath) -> Bool {
        return true
    }
    
    func collectionView(_ collectionView: UICollectionView, didHighlightItemAt indexPath: IndexPath) {
        removeTimer()
    }
    
    func collectionView(_ collectionView: UICollectionView, didUnhighlightItemAt indexPath: IndexPath) {
        addTimer()
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        if let delegate = delegate, delegate.responds(to: #selector(CycleScrollViewDelegate.cycleScrollView(_:didSelectItemAt:))) {
            delegate.cycleScrollView!(self, didSelectItemAt: changeIndex(indexPath.item))
        }
    }
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        pageControl.currentPage = pageIndex
        
        var total: CGFloat = 0.0
        var offset: CGFloat = 0.0
        switch scrollDirection {
        case .vertical:
            total = CGFloat(numberOfItems - 5) * (flowLayout.itemSize.height + flowLayout.minimumLineSpacing)
            offset = contentOffset.y.truncatingRemainder(dividingBy:((flowLayout.itemSize.height + flowLayout.minimumLineSpacing) * CGFloat(numberOfItems - 4)))
        default:
            total = CGFloat(numberOfItems - 5) * (flowLayout.itemSize.width + flowLayout.minimumLineSpacing)
            offset = contentOffset.x.truncatingRemainder(dividingBy:((flowLayout.itemSize.width + flowLayout.minimumLineSpacing) * CGFloat(numberOfItems - 4)))
        }
        let percent = Double(offset / total)
        let progress = percent * Double(numberOfItems - 5)
        if let delegate = delegate, delegate.responds(to: #selector(CycleScrollViewDelegate.cycleScrollViewDidScroll(_:progress:))) {
            delegate.cycleScrollViewDidScroll!(self, progress: progress)
        }
    }
    
    func scrollViewWillBeginDragging(_ scrollView: UIScrollView) {
        removeTimer()
    }
    
    func scrollViewDidEndDragging(_ scrollView: UIScrollView, willDecelerate decelerate: Bool) {
        addTimer()
    }
    
    func scrollViewDidEndScrollingAnimation(_ scrollView: UIScrollView) {
        let index = currentIndex()
        if index == 1 {
            let position = scrollPosition()
            let indexPath = IndexPath(item: numberOfItems - 3, section: 0)
            collectionView.scrollToItem(at: indexPath, at: position, animated: false)
        } else if index == numberOfItems - 2 {
            let position = scrollPosition()
            let indexPath = IndexPath(item: 2, section: 0)
            collectionView.scrollToItem(at: indexPath, at: position, animated: false)
        }
        let toIndex = changeIndex(index)
        if let delegate = delegate, delegate.responds(to: #selector(CycleScrollViewDelegate.cycleScrollView(_:didScrollFromIndex:toIndex:))) {
            delegate.cycleScrollView!(self, didScrollFromIndex: fromIndex, toIndex: toIndex)
        }
        fromIndex = toIndex
    }
    
    func scrollViewWillEndDragging(_ scrollView: UIScrollView, withVelocity velocity: CGPoint, targetContentOffset: UnsafeMutablePointer<CGPoint>) {
        
        guard pageIndex == fromIndex else { return }
        
        let sum = velocity.x + velocity.y
        if sum > 0 {
            indexOffset = 1
        } else if sum < 0 {
            indexOffset = -1
        } else {
            indexOffset = 0
        }
    }
    
    func scrollViewWillBeginDecelerating(_ scrollView: UIScrollView) {
        let position = scrollPosition()
        let index = currentIndex() + indexOffset
        let indexPath = IndexPath(item: index, section: 0)
        collectionView.scrollToItem(at: indexPath, at: position, animated: true)
        indexOffset = 0
    }
}

extension CycleScrollView: UICollectionViewDataSource {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        numberOfItems = dataSource?.numberOfItems(in: self) ?? 0
        if numberOfItems > 1 { numberOfItems += 4 }
        return numberOfItems
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let index = changeIndex(indexPath.item)
        return (dataSource?.cycleScrollView(self, cellForItemAt: index))!
    }
}
