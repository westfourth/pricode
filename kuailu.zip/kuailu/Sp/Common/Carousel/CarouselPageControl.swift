//
//  CarouselPageControl.swift
//  Puff
//
//  Created by mac on 2019/10/17.
//  Copyright © 2019 mac. All rights reserved.
//


class CarouselPageControl: UIView {
    
    var pageControlDiameter: CGFloat = 6
    var currentPage: NSInteger = 0 {
        didSet {
            if oldValue == currentPage { return }
            if currentPage < oldValue {// 向右拉伸
                UIView.animate(withDuration: 0.3, animations: {
                    for dot in self.subviews {
                        var dotFrame = dot.frame
                        dot.layer.borderWidth = 1
                        if dot.tag == self.currentPage {
                            dotFrame.size.width = self.pageControlDiameter * 2.5
                        } else if dot.tag <= oldValue && dot.tag > self.currentPage {
                            dotFrame.origin.x +=  self.pageControlDiameter * 1.5
                            dotFrame.size.width = self.pageControlDiameter
                        }
                        dot.backgroundColor = .white
                        dot.layer.borderColor = UIColor.white.cgColor
                        dot.frame = dotFrame
                    }
                })
                
            } else {// 向左拉伸
                UIView.animate(withDuration: 0.3, animations: {
                    for dot in self.subviews {
                        var dotFrame = dot.frame
                        dot.layer.borderWidth = 1
                        if dot.tag == self.currentPage {
                            dotFrame.size.width = self.pageControlDiameter * 2.5
                            dotFrame.origin.x -= self.pageControlDiameter * 1.5
                            dot.backgroundColor = .white
                            dot.layer.borderColor = UIColor.white.cgColor
                        } else if dot.tag > oldValue && dot.tag < self.currentPage {
                            dotFrame.origin.x -= self.pageControlDiameter * 1.5
                        } else if dot.tag == oldValue {
                            dotFrame.size.width = self.pageControlDiameter
                            dot.backgroundColor = .white
                            dot.layer.borderColor = UIColor.white.cgColor
                        }
                        dot.frame = dotFrame
                    }
                })
            }
        }
    }
    var numberOfPages: NSInteger = 0 {
        didSet {
            if self.numberOfPages == 0 { return }
            if self.subviews.count > 0 {
                for view in self.subviews {
                    view.removeFromSuperview()
                }
            }
            
            var dotX: CGFloat = 0;
            var dotW: CGFloat = pageControlDiameter;
            var bgColor: UIColor
            for i in 0..<numberOfPages {
                dotX = i <= currentPage ? pageControlDiameter * 2.5 * CGFloat(i) : pageControlDiameter * 2.5 * CGFloat(i) + pageControlDiameter
                dotW = i == currentPage ? pageControlDiameter * 2.5 : pageControlDiameter
                bgColor = .white
                let temp = UIView()
                temp.frame = CGRect(x: CGFloat(dotX), y: CGFloat(0), width: CGFloat(dotW), height: pageControlDiameter)
                temp.layer.cornerRadius = pageControlDiameter * 0.5
                temp.layer.masksToBounds = true
                temp.backgroundColor = bgColor
                temp.tag = i
                temp.layer.borderWidth = 1
                temp.layer.borderColor = UIColor.white.cgColor
                addSubview(temp)
            }
        }
    }
}
