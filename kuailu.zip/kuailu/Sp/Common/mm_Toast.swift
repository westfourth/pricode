//
//  Toast.swift
//  Sp
//
//  Created by mac on 2020/4/4.
//  Copyright © 2020 mac. All rights reserved.
//


public enum mm_ToastType: Int {
    case succeed = 0
    case failed = 1
    case forbidden = 2
    case warning = 3
}

public func mm_showToast(_ text: String, type: mm_ToastType = .warning, duration: Double = 1, callback: (()->())? = nil) {
    /// 处理1001超时特殊情况处理
    guard  text != "The request timed out." else {
        return
    }
    
    mm_hidePreviousToast()
    
    let wrapperView = UIView()
    wrapperView.backgroundColor = UIColor.black.withAlphaComponent(0.6)
    wrapperView.layer.cornerRadius = 6
    wrapperView.layer.masksToBounds = true
    
    let imgView = UIImageView(image: UIImage(named: Alert.toastImgArr[type.rawValue]))
    
    let toastLabel = UILabel()
    toastLabel.text = text
    toastLabel.font = UIFont.pingFangRegular(16)
    toastLabel.textColor = .white
    toastLabel.textAlignment = .center
    toastLabel.numberOfLines = 2
    
    wrapperView.addSubview(imgView)
    wrapperView.addSubview(toastLabel)
    
    imgView.snp.makeConstraints { (make) in
        make.centerX.equalToSuperview()
        make.top.equalToSuperview().inset(18)
        make.size.equalTo(50)
    }
    
    toastLabel.snp.makeConstraints { (make) in
        make.centerX.equalToSuperview()
        make.bottom.equalToSuperview().inset(11)
        make.left.right.equalToSuperview().inset(20)
    }
    
    let toast = MBProgressHUD.showAdded(to: UIApplication.shared.keyWindow!, animated: true)
    Alert.toastInstance = toast
    
    toast.margin = 0
    toast.bezelView.style = .solidColor
    toast.bezelView.backgroundColor = .none
    toast.backgroundColor = .none
    toast.animationType = .zoom
    toast.minShowTime = 0.5
    toast.mode = .customView
    
    let labelLen = text.getStringSize(rectSize: .zero, font: UIFont.pingFangRegular(16)).width
    let maxWidth = UIScreen.main.bounds.width * 0.7
    let horizontalPadding: CGFloat = 20 * 2
    let minLabelLen: CGFloat  = 94
    let wrapperWidth = labelLen <= minLabelLen ? minLabelLen + horizontalPadding : (labelLen + horizontalPadding <= maxWidth ? labelLen + horizontalPadding : maxWidth)
    let wrapperHeight = wrapperWidth >= maxWidth ? 114 + 16 : 114
    
    toast.customView = wrapperView
    
    wrapperView.snp.makeConstraints { (make) in
        make.width.equalTo(wrapperWidth)
        make.height.equalTo(wrapperHeight)
    }
    
    Alert.toastBlockTask = DispatchWorkItem {
        mm_hideToast()
        callback?()
    }
    guard let task = Alert.toastBlockTask else {
        mm_initToastState()
        return
    }
    DispatchQueue.main.asyncAfter(deadline: .now() + duration , execute: task)
}


public func mm_hideToast() {
    Alert.toastInstance?.hide(animated: true)
    mm_initToastState()
}

public func mm_hidePreviousToast() {
    Alert.toastInstance?.hide(animated: false)
    mm_initToastState()
}

public func  mm_initToastState() {
    Alert.toastInstance = nil
    Alert.toastBlockTask?.cancel()
    Alert.toastBlockTask = nil
}

public func numberZeroTruncationFormat(_ number: Double) -> String {
    return number.truncatingRemainder(dividingBy: 1) == 0 ? String(Int(number)) : String(number)
}

public func validateEmail(email: String) -> Bool {
    if email.count == 0 { return false }
    let emailRegex = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}"
    let emailTest:NSPredicate = NSPredicate(format: "SELF MATCHES %@", emailRegex)
    return emailTest.evaluate(with: email)
}

/// unicode转中文
///
/// - Parameter unicodeStr: str
/// - Returns:
public func replaceUnicode(unicodeStr: String) -> String {
    let tempStr1 = unicodeStr.replacingOccurrences(of: "\\u", with: "\\U")
    let tempStr2 = tempStr1.replacingOccurrences(of: "\"", with: "\\\"")
    let tempStr3 = "\"".appending(tempStr2).appending("\"")
    let tempData = tempStr3.data(using: String.Encoding.utf8)
    var returnStr:String = ""
    do {
        returnStr = try PropertyListSerialization.propertyList(from: tempData!, options: [.mutableContainers], format: nil) as! String
    } catch {
        print(error)
    }
    return returnStr.replacingOccurrences(of: "\\r\\n", with: "\n")
}

/// 中文转unicode （utf8）
///
/// - Parameter string: str
/// - Returns:unicode
public func utf8ToUnicode(string: String) -> String {
    let dataEncode = string.data(using: String.Encoding.nonLossyASCII)
    let unicodeStr = String(data: dataEncode!, encoding: String.Encoding.utf8)
    return unicodeStr!
}

/// 圆角设置
///
/// - Parameters:
///   - view: 需要设置的控件
///   - corner: 哪些圆角
///   - radius: 圆角半径
/// - Return: layer图层
public func drawRectCorner(view: UIView, corner: UIRectCorner, radius: CGSize) -> CALayer {
    let maskLayer = CAShapeLayer()
    maskLayer.frame = view.bounds
    let maskPath = UIBezierPath.init(roundedRect: view.bounds, byRoundingCorners: corner, cornerRadii: radius)
    maskLayer.path = maskPath.cgPath
    return maskLayer
}

/// 一位数补零
public func singleDigitSupplementZero(_ num: Int) -> String {
    return num > 9 ? "\(num)" : "0\(num)"
}

/// 获取当前时区的Date
public func getCurrenTimezonetDate(_ date: Date = Date()) -> Date {
    let nowDate = date
    let zone = NSTimeZone.system
    let interval = zone.secondsFromGMT(for: nowDate)
    let localeDate = nowDate.addingTimeInterval(TimeInterval(interval))
    return localeDate
}
