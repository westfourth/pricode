//
//  ModalTransitionManager.swift
//  Tabbar
//
//  Created by mac on 2020/3/16.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class ModalTransitionManager: NSObject, UIViewControllerTransitioningDelegate, PanBottomPresentTransitionDelegate {
    weak var viewController: UIViewController?
    var height: CGFloat
    var percentTransition: UIPercentDrivenInteractiveTransition?
    let presentTransition = ModalPresentTransition()        //  防止提前釋放
    
    init(viewController: UIViewController, height: CGFloat) {
        self.viewController = viewController
        self.height = height
        super.init()
        let pan = UIPanGestureRecognizer(target: self, action: #selector(pan(_:)))
        viewController.view.addGestureRecognizer(pan)
        viewController.transitioningDelegate = self
        //
        presentTransition.delegate = self
    }
    
    @objc func pan(_ pan: UIPanGestureRecognizer) {
        let progress: CGFloat = pan.translation(in: pan.view).y / pan.view!.frame.height
        if pan.state == .began {
            percentTransition = UIPercentDrivenInteractiveTransition()
            viewController!.dismiss(animated: true, completion: nil)
        } else if pan.state == .changed {
            percentTransition!.update(progress)
        } else if (pan.state == .ended || pan.state == .cancelled) {
            if progress > 0.5 {
                percentTransition!.finish()
            } else {
                percentTransition!.cancel()
            }
            percentTransition = nil
        }
    }
    
    //_______________________________________________________________________________________________________________
    // MARK: -
    
    func animationController(forPresented presented: UIViewController, presenting: UIViewController, source: UIViewController) -> UIViewControllerAnimatedTransitioning? {
        presentTransition.height = height
        return presentTransition
    }

    func animationController(forDismissed dismissed: UIViewController) -> UIViewControllerAnimatedTransitioning? {
        return ModalDismissTransition()
    }

    func interactionControllerForPresentation(using animator: UIViewControllerAnimatedTransitioning) -> UIViewControllerInteractiveTransitioning? {
        return percentTransition
    }

    
    func interactionControllerForDismissal(using animator: UIViewControllerAnimatedTransitioning) -> UIViewControllerInteractiveTransitioning? {
        return percentTransition
    }
    
    //_______________________________________________________________________________________________________________
    // MARK: -
    func transition(didTapContainerView on: ModalPresentTransition) {
        self.viewController?.dismiss(animated: true, completion: nil)
    }
}
