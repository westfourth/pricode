//
//  TabBarTransition.swift
//  Sp
//
//  Created by mac on 2020/4/6.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

enum TabBarTransitionType: Int {
    case left       //  新控制器的view從左邊滑入
    case right
}

class TabBarTransition: NSObject, UIViewControllerAnimatedTransitioning {
    var type: TabBarTransitionType = .left
    
    func transitionDuration(using transitionContext: UIViewControllerContextTransitioning?) -> TimeInterval {
        return 0.25
    }
    
    func animateTransition(using transitionContext: UIViewControllerContextTransitioning) {
        let fromVC = transitionContext.viewController(forKey: .from)!
        let toVC = transitionContext.viewController(forKey: .to)!
        let containerView = transitionContext.containerView
        containerView.addSubview(toVC.view)
                
        let factor: CGFloat = type == .left ? 1.0 : -1.0
        let rect = UIScreen.main.bounds
        toVC.view.transform = CGAffineTransform.init(translationX: -rect.width * factor, y: 0)
        
        UIView.animate(withDuration: transitionDuration(using: transitionContext), animations: {
            toVC.view.transform = CGAffineTransform.identity
            fromVC.view.transform = CGAffineTransform.init(translationX: rect.width * factor, y: 0)
            //
        }) { (finished) in
            fromVC.view.transform = CGAffineTransform.identity
            toVC.view.transform = CGAffineTransform.identity
            transitionContext.completeTransition(!transitionContext.transitionWasCancelled)
        }
    }
}
