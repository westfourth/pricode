//
//  ModalPresentTransition.swift
//  Butterfly
//
//  Created by mac on 2019/9/3.
//  Copyright © 2019 mac. All rights reserved.
//

import UIKit

class ModalPresentTransition: NSObject, UIViewControllerAnimatedTransitioning, UIGestureRecognizerDelegate {
    var height: CGFloat = UIScreen.main.bounds.height
    weak var delegate: PanBottomPresentTransitionDelegate?
    
    func transitionDuration(using transitionContext: UIViewControllerContextTransitioning?) -> TimeInterval {
        return 0.25
    }
    
    func animateTransition(using transitionContext: UIViewControllerContextTransitioning) {
        let toVC = transitionContext.viewController(forKey: .to)!
        let containerView = transitionContext.containerView
        containerView.addSubview(toVC.view)
        //  添加点击手势
        let tap = UITapGestureRecognizer(target: self, action: #selector(tap(_:)))
        tap.delegate = self
        containerView.addGestureRecognizer(tap)
                
        var rect0 = UIScreen.main.bounds
        rect0.origin.y = rect0.height
        rect0.size.height = self.height
        toVC.view.frame = rect0
        //
        containerView.backgroundColor = UIColor.clear
        
        UIView.animate(withDuration: transitionDuration(using: transitionContext), animations: {
            var rect1 = UIScreen.main.bounds
            rect1.origin.y = rect1.height - self.height
            rect1.size.height = self.height
            toVC.view.frame = rect1
            //
            containerView.backgroundColor = UIColor.black.withAlphaComponent(0.4)
        }) { (finished) in
            transitionContext.completeTransition(!transitionContext.transitionWasCancelled)
        }
    }
    
    @objc func tap(_ tap: UITapGestureRecognizer) {
        self.delegate?.transition(didTapContainerView: self)
    }
    
    func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer, shouldReceive touch: UITouch) -> Bool {
        return gestureRecognizer.view == touch.view
    }
}


protocol PanBottomPresentTransitionDelegate: NSObjectProtocol {
    func transition(didTapContainerView on: ModalPresentTransition)
}
