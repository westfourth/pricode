//
//  ModalDismissTransition.swift
//  Butterfly
//
//  Created by mac on 2019/9/3.
//  Copyright © 2019 mac. All rights reserved.
//

import UIKit

class ModalDismissTransition: NSObject, UIViewControllerAnimatedTransitioning {

    func transitionDuration(using transitionContext: UIViewControllerContextTransitioning?) -> TimeInterval {
        return 0.25
    }
    
    func animateTransition(using transitionContext: UIViewControllerContextTransitioning) {
        let fromVC = transitionContext.viewController(forKey: .from)!
        let containerView = transitionContext.containerView
        
        //
        containerView.backgroundColor = UIColor.black.withAlphaComponent(0.4)
        
        UIView.animate(withDuration: transitionDuration(using: transitionContext), animations: {
            var rect = fromVC.view.frame
            rect.origin.y = UIScreen.main.bounds.height
            fromVC.view.frame = rect
            //
            containerView.backgroundColor = UIColor.clear
        }) { (finished) in
            transitionContext.completeTransition(!transitionContext.transitionWasCancelled)
        }
    }
}
