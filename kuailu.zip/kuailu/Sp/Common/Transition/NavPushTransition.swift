//
//  PanPushTransition.swift
//  Butterfly
//
//  Created by mac on 2019/9/3.
//  Copyright © 2019 mac. All rights reserved.
//

import UIKit

class NavPushTransition: NSObject, UIViewControllerAnimatedTransitioning {
    
    func transitionDuration(using transitionContext: UIViewControllerContextTransitioning?) -> TimeInterval {
        return 0.25
    }
    
    func animateTransition(using transitionContext: UIViewControllerContextTransitioning) {
        let fromVC = transitionContext.viewController(forKey: .from)!
        let toVC = transitionContext.viewController(forKey: .to)!
        
        let containerView = transitionContext.containerView
        containerView.addSubview(toVC.view)
        
        let toVCToRect = transitionContext.finalFrame(for: toVC)
        let fromVCFromRect = transitionContext.initialFrame(for: fromVC)
        
        var toRect = toVCToRect
        toRect.origin.x = toRect.width
        toVC.view.frame = toRect
        
        UIView.animate(withDuration: transitionDuration(using: transitionContext), delay: 0, options: [.curveLinear], animations: {
            var fromRect = fromVCFromRect
            fromRect.origin.x = -fromRect.width / 4
            fromVC.view.frame = fromRect
            
            toVC.view.frame = toVCToRect
        }) { (finished) in
            transitionContext.completeTransition(!transitionContext.transitionWasCancelled)
        }
    }
}
