//
//  NavPopTransition.swift
//  Sp
//
//  Created by mac on 2020/4/6.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class NavPopTransition: NSObject, UIViewControllerAnimatedTransitioning {

    func transitionDuration(using transitionContext: UIViewControllerContextTransitioning?) -> TimeInterval {
        return 0.25
    }
    
    func animateTransition(using transitionContext: UIViewControllerContextTransitioning) {
        let fromVC = transitionContext.viewController(forKey: .from)!
        let toVC = transitionContext.viewController(forKey: .to)!
        
        let containerView = transitionContext.containerView
        containerView.insertSubview(toVC.view, belowSubview: fromVC.view)
        
        let toVCToRect = transitionContext.finalFrame(for: toVC)
        let fromVCFromRect = transitionContext.initialFrame(for: fromVC)
        
        var toRect = toVCToRect
        toRect.origin.x = -toRect.width / 4
        toVC.view.frame = toRect
        
        UIView.animate(withDuration: transitionDuration(using: transitionContext), delay: 0, options: [.curveLinear], animations: {
            var fromRect = fromVCFromRect
            fromRect.origin.x = fromRect.width
            fromVC.view.frame = fromRect
            
            toVC.view.frame = toVCToRect
        }) { (finished) in
            transitionContext.completeTransition(!transitionContext.transitionWasCancelled)
        }
    }
}
