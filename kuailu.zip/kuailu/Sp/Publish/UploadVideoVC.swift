 //
 //  UploadVideoVC.swift
 //  Sp
 //
 //  Created by mac on 2020/3/27.
 //  Copyright © 2020 mac. All rights reserved.
 //
 
 import UIKit
 import FileUpLoader
 import AVKit
 class UploadVideoVC: UIViewController {
    
    
    @IBOutlet weak var titleLength: UILabel!
    
    @IBOutlet weak var titleInput: UITextView!
    
    @IBOutlet weak var titlePlace: UILabel!
    
    
    @IBOutlet weak var priceInput: UITextField!
    
    @IBOutlet weak var cateView: UIView!
    
    @IBOutlet weak var collectionView: UICollectionView!
    @IBOutlet weak var layout: UICollectionViewLayout!
    
    @IBOutlet weak var uploadView: UIView!
    
    @IBOutlet weak var videoView: UIView!
    /// 视频缩图
    @IBOutlet weak var videoThumb: UIImageView!
    
    @IBOutlet weak var upload: UIButton!
    
    @IBOutlet weak var listLabel: UILabel!      //  底部123列表
    
    @IBOutlet weak var setPriceLabel: UILabel!      //  設定價格
    
    
    
    var selectedItems:[PublishCateItem] = [PublishCateItem]()
    
    /// 视频时长
    var videoSeconds:Int = 0
    
    ///上传id
    var videoId:String?
    
    var videoUrl:String?
    
    var coverSuffix:String?
    
    ///视频第一桢图片
    var videoThumImage:UIImage? {
        didSet {
            guard let image = videoThumImage else {
                videoView.isHidden = true
                return
            }
            self.videoView.isHidden = false
            self.videoThumb.image = image
        }
    }
    
    //MARK:-选中的视频
    var item:FileItem? {
        didSet {
            guard let item = item else {
                return
            }
            let hud = MBProgressHUD.showAdded(to:self.view, animated: true)
            hud.label.text = "視頻合成中..."
            item.uploadSequenctly(progress: { (sent, total) in
                let per = Double((Double(sent)) * 1.00 /  Double(total)) * 100
                hud.detailsLabel.text = String(format:"%.2f%@",per,"%")
                print("upload>>>>>\(per)%")
            }) { (error,videoId,videoURL) in
                DispatchQueue.main.async {
                    hud.hide(animated: true)
                    guard error == nil else {
                        mm_showToast(error!.localizedDescription)
                        return
                    }
                    mm_showToast("視頻合成成功！", type: .succeed)
                    let asset = AVURLAsset.init(url: item.url, options: nil)
                    let gen = AVAssetImageGenerator.init(asset: asset)
                    gen.appliesPreferredTrackTransform = true
                    let time = CMTimeMakeWithSeconds(0.0, preferredTimescale: 1)
                    var actualTime : CMTime = CMTimeMakeWithSeconds(0, preferredTimescale: 0)
                    do {
                        let image = try gen.copyCGImage(at: time, actualTime: &actualTime)
                        self.videoThumImage = UIImage(cgImage: image)
                    } catch  {
                        mm_showToast("獲取視頻第一楨圖片錯誤!")
                    }
                }
                guard videoId != nil else {
                    mm_showToast("videoId為空!")
                    return
                }
                guard videoURL != nil else {
                    mm_showToast("videoURL為空!")
                    return
                }
                self.videoUrl = videoURL
                self.videoId = videoId
            }
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.navigationBar.setBackgroundImage(UIImage(named: "navi_backImage"), for: UIBarMetrics.default)
        self.navigationController?.navigationBar.shadowImage = UIImage()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = RGB(0xff141516)
        navigationItem.title = "發布"
        
        setTexts()
        
        self.collectionView.register(UINib(nibName: "SelectedCateCell", bundle: Bundle.main), forCellWithReuseIdentifier: "SelectedCateCell")
        
        let tap = UITapGestureRecognizer(target: self, action:#selector(self.chooseCateAction))
        self.cateView.isUserInteractionEnabled = true
        self.cateView.addGestureRecognizer(tap)
        
        
        self.videoView.isUserInteractionEnabled = true
        let videoTap = UITapGestureRecognizer(target: self, action:#selector(self.playLocalVideo))
        self.videoView.addGestureRecognizer(videoTap)
        
        let place = NSAttributedString(string: "輸入視頻\(Sensitive.jia)（建議0～100\(Sensitive.jin)）", attributes: [NSAttributedString.Key.font : UIFont.systemFont(ofSize: 11),NSAttributedString.Key.foregroundColor:UIColor.white.withAlphaComponent(0.5)])
        self.priceInput.attributedPlaceholder = place
        
        Appearance.gradient(view: upload, style: .orange)
        self.uploadView.isUserInteractionEnabled = true
        let uploadTap = UITapGestureRecognizer(target: self, action:#selector(self.uploadAction(_:)))
        self.uploadView.addGestureRecognizer(uploadTap)
        
        if UploadConfig.shared.info.usedTimes >= UploadConfig.shared.info.uploadNTimes {
            showForbidUploadVideoAlert()
        } else {
            checkIsCanUploadVideo()
        }
        
        /// 获取上次选中的标签
        if  let items = UploadConfig.shared.fetchTags() {
            self.selectedItems = items
            self.collectionView.reloadData()
        }
    }
    
    /// 更新敏感词汇
    func setTexts() {
        listLabel.text = """
        1、\(Sensitive.jin)\(Sensitive.shou)支持\(Sensitive.ti)（\(Sensitive.zhi)寶、\(Sensitive.wei)、\(Sensitive.yin)\(Sensitive.zhuan)） 2、發佈後，請在我的動態查看審核進度  3、審核通過後，將在首頁或話題頁面展示
        """
        
        setPriceLabel.text = "設定\(Sensitive.jia)"
        priceInput.placeholder = "輸入視頻\(Sensitive.jia)（建議0～100\(Sensitive.jin)）"
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        UploadConfig.shared.loadConfig()
    }
    
    private func checkIsCanUploadVideo() {
        Alert.showLoading(parentView: view)
        Session.request(UploadVideoInfoReq()) { [weak self] (error, resp) in
            Alert.hideLoading()
            guard let `self` = self else { return }
            guard error == nil, let res = resp as? UploadVideoInfo else { return }
            UploadConfig.shared.info = res
            if UploadConfig.shared.info.usedTimes >= UploadConfig.shared.info.uploadNTimes {
                self.showForbidUploadVideoAlert()
            }
        }
    }
    
    private func showForbidUploadVideoAlert() {
        CustomMBProgressHUD.tapBlankDismiss = false
        Alert.showComfirmAlert(parentView: view, contentText:"今日您已上傳\(UploadConfig.shared.info.usedTimes)次，單日最大上傳\(UploadConfig.shared.info.uploadNTimes)次哦！") { [weak self] in
            self?.navigationController?.popViewController(animated: true)
            CustomMBProgressHUD.tapBlankDismiss = true
        }
    }
    
    //MARK:-上传视频
    @objc func uploadAction(_ sender: Any) {
        let imageVC = UIImagePickerController()
        imageVC.mediaTypes = ["public.movie"]
        imageVC.videoQuality = .typeMedium
        imageVC.videoMaximumDuration = TimeInterval(UploadConfig.shared.info.maxTimes)
        imageVC.allowsEditing = true
        imageVC.modalPresentationStyle = .fullScreen
        if #available(iOS 13.0, *) {
            imageVC.isModalInPresentation = true
        }
        GlobalSettings.setImagePickerNatiBarAttribute()
        imageVC.delegate = self as? UIImagePickerControllerDelegate & UINavigationControllerDelegate
        self.present(imageVC, animated: true, completion: nil)
    }
    
    
    //MARK:-播放本地视频
    @objc func playLocalVideo() {
        guard self.item != nil else {
            return
        }
        guard let localURL = self.item!.url as? URL else {
            return
        }
        let player = AVPlayer(url: localURL)
        let vc = AVPlayerViewController()
        vc.player = player
        player.play()
        present(vc, animated: true, completion: nil)
    }
    
    /// 封面
    var coverImageURL:URL? {
        didSet {
            guard let url = coverImageURL else {
                self.videoView.isHidden = true
                self.coverSuffix = nil
                return
            }
            self.videoView.isHidden = false
            self.videoThumb.kf.setImage(with: url, options: [.transition(.fade(0.25))])
        }
    }
    
    @IBAction func chooseCoverAction(_ sender: Any) {
        let imageVC = UIImagePickerController()
        imageVC.modalPresentationStyle = .fullScreen
        if #available(iOS 13.0, *) {
            imageVC.isModalInPresentation = true
        }
        GlobalSettings.setImagePickerNatiBarAttribute()
        imageVC.delegate = self as? UIImagePickerControllerDelegate & UINavigationControllerDelegate
        imageVC.allowsEditing = true
        imageVC.mediaTypes = ["public.image"]
        self.present(imageVC, animated: true, completion: nil)
    }
    
    @IBAction func uploadSubmitAction(_ sender: Any) {
        guard  self.titleInput.text != "" else {
            mm_showToast("請填寫視頻標題!")
            return
        }
        guard self.videoThumImage != nil else {
            mm_showToast("請上傳視頻!")
            return
        }
        guard self.videoUrl != nil else {
            return
        }
        
        guard self.selectedItems.count > 0 else {
            mm_showToast("請選擇分類!")
            return
        }
        
        guard self.videoId != nil else {
            mm_showToast("videoId為空!")
            return
        }
        
        guard let item = self.item else {
            return
        }
        var pay:Bool = false
        var price:Double = 0.0
        
        if self.priceInput.text == "" {
            //            Alert.showCommonAlert(parentView: self.view,
            //                                  contentText: "您确定视频发布免费吗",
            //                                  cancelText: "重新编辑",
            //                                  confirmText: "确定",
            //                                  onConfirmTap:nil) {
            //                                    self.priceInput.becomeFirstResponder()
            //            }
        } else {
            pay = true
            price = Double(self.priceInput.text!.components(separatedBy: "\(Sensitive.jin)").first!)!
        }
        
        let req = AddVideoReqAddVideoReq()
        if self.coverSuffix != nil {
            req.coverImg = [self.coverSuffix!]
        }
        req.pay = pay
        req.playTime = self.videoSeconds
        req.price = price
        req.size = item.totalLength
        req.title = self.titleInput.text!
        req.tags = self.selectedItems.map{return $0.tagsId}
        req.videoUrl = self.videoUrl!
        req.id = self.videoId!
        Alert.showLoading(parentView: self.view)
        item.uploadOkwithTitle(req.title,
                               videoId: self.videoId!) { (error1) in
            DispatchQueue.main.async {
                Alert.hideLoading()
            }
            guard error1 == nil else {
                mm_showToast(error1!.localizedDescription)
                return
            }
            
            Session.request(req) { (error, resp) in
                guard error == nil else {
                    mm_showToast(error!.localizedDescription)
                    return
                }
                
                /// 视频真正经过了后台合成，并且上传成功,写入档案,记录这个文件已经上传过后台
                FileUpLoader.default().writeCombineVideo(item.fileIdentifier)
                
                Alert.showCommonAlert(parentView: self.view,
                                      contentText: "请前往個人中心小視頻查看上傳狀態!",
                                      cancelText: "返回首頁",
                                      confirmText: "立即前往",
                                      onConfirmTap: { [weak self] in
                                        self?.navigationController?.popToRootViewController(animated: true)
                                        guard let rootVC = UIApplication.shared.keyWindow?.rootViewController as? UITabBarController else { return }
                                        rootVC.selectedIndex = 4
                                        guard let userId = NetDefaults.userInfo?.userId else { return }
                                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.25) {
                                            guard let navigationController = (UIApplication.shared.delegate as? AppDelegate)?.currentNavigationController else { return }
                                            let vc = UsersDynamicVC()
                                            vc.initPageType = .smallVideo
                                            vc.userId = userId
                                            navigationController.pushViewController(vc, animated: true)
                                        }
                                      }) { [weak self] in
                    self?.navigationController?.popToRootViewController(animated: true)
                }
            }
        }
    }
    @objc func chooseCateAction() {
        let VC = ChooseCateVC()
        VC.delegate = self
        self.navigationController?.pushViewController(VC, animated: true)
    }
 }
 
 
 extension UploadVideoVC:UITextViewDelegate {
    func textView(_ textView: UITextView, shouldChangeTextIn range: NSRange, replacementText text: String) -> Bool {
        if text.count == 0 {
            return true
        }
        guard let existedLength = textView.text?.count else { return false }
        let selectedLength = range.length;
        let replaceLength = text.count;
        if (existedLength - selectedLength + replaceLength > 30){
            return false
        }
        return true
    }
    
    func textViewDidChange(_ textView: UITextView) {
        if textView.text.count > 30 {
            textView.text = String(textView.text.suffix(30))
        }
        self.titleLength.text = "\(textView.text.count)/30"
        self.titlePlace.isHidden = textView.text != ""
    }
 }
 
 extension UploadVideoVC:UITextFieldDelegate {
    func textFieldDidEndEditing(_ textField: UITextField) {
        if textField.text != "" {
            let price:Int = Int(textField.text!) ?? 0
            self.priceInput.attributedText = priceAttrText(price: price)
        }
    }
    
    func priceAttrText(price: Int) -> NSAttributedString {
        let attr1: [NSAttributedString.Key: AnyObject] = [.foregroundColor: rgb(0xFA6400), .font: font(18, .medium)]
        let attr2: [NSAttributedString.Key: AnyObject] = [.foregroundColor: rgb(0xBCBCBC), .font: font(14)]
        let attrText = NSMutableAttributedString(string: "\(price)\(Sensitive.jin)", attributes: attr2)
        attrText.setAttributes(attr1, range: NSMakeRange(0, "\(price)".count))
        return attrText
    }
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        textField.text = ""
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        let c = string.first
        if textField.text == "" && c == "0" {
            return false
        }
        if textField.text!.count >= 3 && string != "" {
            return false
        }
        return true
    }
 }
 //_______________________________________________________________________________________________________________
 // MARK: - UIImagePickerControllerDelegate
 extension UploadVideoVC:UIImagePickerControllerDelegate,UINavigationControllerDelegate {
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        GlobalSettings.resetNaviBarAttribute()
        picker.dismiss(animated: true, completion: nil)
    }
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        GlobalSettings.resetNaviBarAttribute()
        picker.dismiss(animated: true, completion: nil)
        // 上传封面
        if picker.mediaTypes == ["public.image"] {
            let image = info[UIImagePickerController.InfoKey.editedImage] as! UIImage
            Alert.showLoading(parentView: UIApplication.shared.keyWindow!)
            ImageUploader.upload(image) { (error, domain,suffix) in
                Alert.hideLoading()
                guard error == nil else {
                    mm_showToast("圖片上傳失敗")
                    return
                }
                self.coverSuffix = suffix
                guard let logo = URL(string: domain + suffix) else {
                    return
                }
                self.coverImageURL = logo
            }
        } else if picker.mediaTypes == ["public.movie"] {
            //上传视频
            guard let videoURL = info[UIImagePickerController.InfoKey.mediaURL] as? URL   else {
                return
            }
            
            guard FileItem.size(with: videoURL) <= (UploadConfig.shared.info.size * 1024 * 1024)  else {
                mm_showToast("視頻最大為\(UploadConfig.shared.info.size)M,請重新選擇!",duration: 2.0)
                return
            }
            
            /// 作为视频档案唯一识别符号 上面的videourl每次选择都会变化 不能作为档案识别符号
            guard let refrenceURL = info[UIImagePickerController.InfoKey.referenceURL] as? URL else {
                return
            }
            if FileUpLoader.default().combineVideoSucess(refrenceURL.absoluteString) {
                mm_showToast("您已經上傳過視頻,請重新選擇!")
                return
            }
            let asset = AVURLAsset(url: videoURL, options: [AVURLAssetPreferPreciseDurationAndTimingKey:false])
            
            guard asset.isPlayable else {
                mm_showToast("該視頻不可播放，請重新選擇!")
                return
            }
            let seconds:Int = Int((Double(asset.duration.value)) / (Double(asset.duration.timescale)))
            guard seconds >= UploadConfig.shared.info.minTimes else {
                mm_showToast("最低視頻時長為\(UploadConfig.shared.info.minTimes)秒!",duration: 2.0)
                return
            }
            
            guard seconds <= UploadConfig.shared.info.maxTimes else {
                mm_showToast("最大視頻時長為\(UploadConfig.shared.info.maxTimes)秒!",duration: 2.0)
                return
            }
            self.videoSeconds = seconds
            self.item = FileItem(url:videoURL, fileIdentifier: refrenceURL.absoluteString)
            //            FileItem.mov2mp4(with:videoURL) { (resultURL) in
            //                DispatchQueue.main.async {
            //                    self.item = FileItem(url:resultURL, fileIdentifier: refrenceURL.absoluteString)
            //                }
            //            }
        }
    }
 }
 
 //_______________________________________________________________________________________________________________
 // MARK: - UICollectionViewDataoSource&Delegate
 extension UploadVideoVC:UICollectionViewDataSource,UICollectionViewDelegate,UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return self.selectedItems.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "SelectedCateCell", for: indexPath) as! SelectedCateCell
        cell.item = self.selectedItems[indexPath.row]
        cell.delegate = self
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: CateCell.itemW(self.selectedItems[indexPath.row]), height: 31)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        return UIEdgeInsets(top: 15, left: 0, bottom: 0, right: 0)
    }
 }
 
 extension UploadVideoVC:ChooseCateVCDelegate {
    func chooseCateViewContorller(chooseCateViewContorller: ChooseCateVC, selectedItems: [PublishCateItem]) {
        self.selectedItems = selectedItems
        UploadConfig.shared.saveTags(selectedItems)
        self.collectionView.reloadData()
    }
 }
 
 extension UploadVideoVC: SelectedCateCellDelegate {
    func selectedCateCell(cell:SelectedCateCell,deleteItem item:PublishCateItem) {
        self.selectedItems.removeAll { (subItem) -> Bool in
            return item.tagsId == subItem.tagsId
        }
        self.collectionView.reloadData()
    }
 }
 
