//
//  UploadAlertVC.swift
//  Sp
//
//  Created by mac on 2020/3/7.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit
import MobileCoreServices
import AVKit

@objc protocol UploadAlertVCDelegate {
    ///点击
    func uploadViewControllerTakeVideoAction(uploadViewController:UploadAlertVC)
    
}

class UploadAlertVC: UIViewController {
    weak var delegate: UploadAlertVCDelegate?
    var transtioner:ModalTransitionManager!
    
    override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: Bundle?) {
        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
        modalPresentationStyle = .overFullScreen
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    lazy var upload:UIButton = {
        let button = UIButton()
        button.setImage(UIImage(named: "img_release_2"), for: UIControl.State.normal)
        button.addTarget(self, action: #selector(uploadAction(_:)), for: UIControl.Event.touchUpInside)
        return button
    }()
    
    
    lazy var takeVideo:UIButton = {
        let button = UIButton()
        button.setImage(UIImage(named: "img_release_1"), for: UIControl.State.normal)
        button.addTarget(self, action: #selector(takeVideoAction(_:)), for: UIControl.Event.touchUpInside)
        return button
    }()
    
    
    lazy var tapDismiss:UIButton = {
        let button = UIButton()
        button.isUserInteractionEnabled = true
        button.backgroundColor = .clear
        button.addTarget(self, action: #selector(self.tapDismissAction), for: UIControl.Event.touchUpInside)
        return button
    }()
    
    @objc  func tapDismissAction() {
        dismiss(animated: true, completion: nil)
    }
    
    lazy var dismiss:UIButton = {
        let button = UIButton()
        button.setImage(UIImage(named: "ic_close_3"), for: UIControl.State.normal)
        button.addTarget(self, action: #selector(dismissAction(_:)), for: UIControl.Event.touchUpInside)
        return button
    }()
    
    lazy var uploadTitle:UILabel = {
        let label = UILabel()
        label.text = "上傳視頻"
        label.font = UIFont.pingFangMedium(13)
        label.textColor = .white
        label.textAlignment = .center
        return label
    }()
    
    lazy var takeVideoTitle:UILabel = {
        let label = UILabel()
        label.text = "拍攝視頻"
        label.font = UIFont.pingFangMedium(13)
        label.textColor = .white
        label.textAlignment = .center
        return label
    }()
    
    @objc func uploadAction(_ sender: Any) {
        dismiss(animated: true, completion: nil)
        guard UploadConfig.shared.info.allow else {
          mm_showToast("系統維護中，暫不能上傳視頻!")
          return
        }
        let rootVC = (UIApplication.shared.keyWindow!.rootViewController ) as! UITabBarController
        let navigationController = rootVC.selectedViewController as! UINavigationController
        let chooseVC = UploadVideoVC()
        chooseVC.hidesBottomBarWhenPushed = true
        navigationController.pushViewController(chooseVC, animated: true)
    }
    
    
   @objc func takeVideoAction(_ sender: Any) {
        dismiss(animated: true, completion: nil)
       guard UploadConfig.shared.info.allow else {
        mm_showToast("系統維護中，暫不能上傳視頻!")
        return
      }
        self.delegate?.uploadViewControllerTakeVideoAction(uploadViewController: self)
    }
    
    @objc func dismissAction(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        transtioner = ModalTransitionManager(viewController: self, height: 240)
        view.backgroundColor = RGB(0xff141516)
        view.addSubview(self.upload)
        upload.snp.makeConstraints { (make) in
            make.left.equalTo(80)
            make.top.equalTo(35)
            make.size.equalTo(CGSize(width: 70, height: 70))
        }
        
        view.addSubview(self.takeVideo)
        takeVideo.snp.makeConstraints { (make) in
            make.right.equalTo(-80)
            make.top.equalTo(35)
            make.size.equalTo(CGSize(width: 70, height: 70))
        }
        
        view.addSubview(self.uploadTitle)
        self.uploadTitle.snp.makeConstraints { (make) in
            make.centerX.equalTo(self.upload)
            make.top.equalTo(self.upload.snp.bottom).offset(10)
        }
        
        view.addSubview(self.takeVideoTitle)
        self.takeVideoTitle.snp.makeConstraints { (make) in
            make.centerX.equalTo(self.takeVideo)
            make.top.equalTo(self.takeVideo.snp.bottom).offset(10)
        }
        
        view.addSubview(self.tapDismiss)
        self.tapDismiss.snp.makeConstraints { (make) in
            make.centerX.bottom.equalToSuperview()
            make.size.equalTo(CGSize(width: 70, height: 70))
        }
        
        view.addSubview(self.dismiss)
        self.dismiss.snp.makeConstraints { (make) in
            make.centerX.equalToSuperview()
            make.top.equalTo(175)
            make.size.equalTo(CGSize(width: 35, height: 35))
        }
    }
}


