//
//  CateCell.swift
//  Sp
//
//  Created by mac on 2020/3/5.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

@objc protocol CateCellDelegate {
    
    func cateCell(_ cell:CateCell,didTapButton button:UIButton)
}

class CateCell: UICollectionViewCell {

    @IBOutlet weak var name: UIButton!
    
    weak var delegate: CateCellDelegate?
    
    @IBAction func tapAction(_ sender: UIButton) {
        
        self.delegate?.cateCell(self, didTapButton: sender)
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    var item:PublishCateItem? {
        didSet {
            guard let model = item  else {
                return
            }
            name.setTitle(model.tagsTitle, for: UIControl.State.normal)
            name.backgroundColor = model.selected ? .white : rgb(0x2E2E36)
            name.setTitleColor(model.selected ? rgb(0xFF5F23) : .white, for: .normal)
        }
    }

    //MARK:-动态长度
    class func itemW(_ item:PublishCateItem)->CGFloat {
        let name = item.tagsTitle
        guard name != "" else {
            return 60
        }
        let strSize = (name as NSString).boundingRect(with: CGSize(width: UIScreen.main.bounds.size.width - 25, height: 27), options: .usesLineFragmentOrigin, attributes: [NSAttributedString.Key.font: UIFont.systemFont(ofSize: 12, weight: UIFont.Weight.bold)], context: nil).size
        return strSize.width + 38
    }
    
}
