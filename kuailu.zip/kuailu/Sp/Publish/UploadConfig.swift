//
//  UploadConfig.swift
//  Sp
//
//  Created by mac on 2020/3/27.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

/// 视频上传配置信息

class UploadConfig: NSObject {

    static let shared = UploadConfig()
    
    var info:UploadVideoInfo = UploadVideoInfo()
    
    func loadConfig() {
        Session.request(UploadVideoInfoReq()) { (error, resp) in
            guard error == nil else {
                return
            }
            if resp is UploadVideoInfo {
                let item = resp as! UploadVideoInfo
                self.info = item
                //  更新默认配置
                ShortVideoCounterConfig.maxEachTime = Float(item.missionResp.eachTime * 60)
                ShortVideoCounterConfig.circleTime = Float(item.missionResp.time * 60)
                ShortVideoCounterConfig.score = item.missionResp.score
                ShortVideoCounterConfig.maxReportTimes = item.missionResp.limited
                ShortVideoCounterConfig.missionId = item.missionResp.missionId
                ShortVideoCounter.share.read()
            }
        }
    }
    
    //MARK:-存取发布分类标签
    func saveTags(_ items:[PublishCateItem]) {
        let jsonArray = items.toJSON()
        UserDefaults.standard.set(jsonArray, forKey: "PublishCateItem")
        UserDefaults.standard.synchronize()
    }
    
    func fetchTags()-> [PublishCateItem]? {
        if let jsonArray = UserDefaults.standard.object(forKey: "PublishCateItem") as? [[String : Any]] {
            var items:[PublishCateItem] = [PublishCateItem]()
            if jsonArray.count > 0 {
                for i in jsonArray {
                    items.append(PublishCateItem.deserialize(from: i)!)
                }
                return items
            }
        }
        return nil
    }
    
}
