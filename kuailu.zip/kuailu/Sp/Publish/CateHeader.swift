//
//  CateHeader.swift
//  Sp
//
//  Created by mac on 2020/3/5.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class CateHeader: UICollectionReusableView {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    @IBOutlet weak var name: UILabel!
    
    var item:PublishCateListResp? {
        didSet {
            guard let item = item else {
                return
            }
            name.text = item.tagsTitle
        }
    }
    
}
