//
//  SelectedCateCell.swift
//  Sp
//
//  Created by mac on 2020/3/7.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

@objc protocol SelectedCateCellDelegate {
    //删除
    func selectedCateCell(cell:SelectedCateCell,deleteItem item:PublishCateItem)
}

class SelectedCateCell: UICollectionViewCell {
    
    weak var delegate: SelectedCateCellDelegate?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        let tap = UITapGestureRecognizer(target: self, action:#selector(deleteAction))
        name.addGestureRecognizer(tap)
    }
    
    @IBOutlet weak var name: UILabel!
    
    @IBAction func deleteAction(_ sender: Any) {
        guard let item = self.item else {
            return
        }
        self.delegate?.selectedCateCell(cell: self, deleteItem: item)
    }
    
    var item:PublishCateItem? {
        didSet {
            guard let item = item else {
                return
            }
            self.name.text = item.tagsTitle
        }
    }
}
