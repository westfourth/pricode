//
//  ChooseCateVC.swift
//  Sp
//
//  Created by mac on 2020/3/5.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

@objc protocol ChooseCateVCDelegate {
    ///保存
    func chooseCateViewContorller(chooseCateViewContorller:ChooseCateVC, selectedItems:[PublishCateItem])
    
}

class ChooseCateVC: UIViewController {

    weak var delegate: ChooseCateVCDelegate?

    var items:[PublishCateListResp] = [PublishCateListResp]()
    //最多选择5个
    var selectedCount:Int = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = RGB(0xff141516)
        navigationItem.title = "選擇分類"
        navigationController?.navigationBar.isTranslucent = true
        navigationItem.rightBarButtonItem = UIBarButtonItem(customView: save)
        
        view.addSubview(topTitle)
        topTitle.snp.makeConstraints { (make) in
            make.left.right.equalToSuperview()
            make.top.equalToSuperview().inset(kTop + 10)
        }
        
        view.addSubview(collectionView)
        collectionView.snp.makeConstraints { (make) in
            make.left.right.bottom.equalToSuperview()
            make.top.equalTo(topTitle.snp.bottom).offset(10)
        }
        loadData()
    }
    
    func loadData() {
        let req = PublishCateListReq()
        Session.request(req) { (error, resp) in
            guard error == nil else {
                self.collectionView.state = .failed
                return
            }
            if resp is [PublishCateListResp] {
                let items = resp as! [PublishCateListResp]
                self.items = items
                if self.items.isEmpty {
                    self.collectionView.state = .empty
                } else {
                    self.collectionView.state = .normal
                }
                self.collectionView.reloadData()
            }
        }
    }
    
    lazy var topTitle:UILabel = {
        let label = UILabel()
        label.text = "選擇分類獲取更多精準推薦，同時可加速審核，最多選擇3個"
        label.textColor = UIColor.white.withAlphaComponent(0.5)
        label.font = UIFont.pingFangRegular(11)
        label.textAlignment = .center
        return label
    }()
    
    lazy var save:UIButton = {
        let button = UIButton()
        button.frame = CGRect(x: 0, y: 0, width: 80, height: 27)
        button.setTitle("保存", for: UIControl.State.normal)
        button.titleLabel?.font = UIFont.pingFangHeavy(13)
        button.titleLabel?.textColor = .white
        button.addTarget(self, action: #selector(saveAction), for: UIControl.Event.touchUpInside)
        
        button.clipsToBounds = true
        button.layer.cornerRadius = 15
        
        Appearance.gradient(view: button, style: .orange)
        
        return button
    }()
    
    @objc func saveAction() {
        if self.selectedCount == 0 {
            mm_showToast("請至少選擇一個分類!")
            return
        }
        let selectedItems = _selectedItems()
        self.delegate?.chooseCateViewContorller(chooseCateViewContorller: self, selectedItems: selectedItems)
        self.navigationController?.popViewController(animated: true)
    }
    
    func _selectedItems()->[PublishCateItem] {
        var selectedItems:[PublishCateItem] = [PublishCateItem]()
        for i  in 0..<self.items.count {
            let itemA = self.items[i]
            for j in 0..<itemA.tagsList.count {
                let subItem = itemA.tagsList[j]
                if subItem.selected {
                    selectedItems.append(subItem)
                }
            }
        }
        return selectedItems
    }
    
    lazy var collectionView: UICollectionView = {
        let layout = UICollectionViewFlowLayout()
        layout.minimumLineSpacing = 10.0
        layout.headerReferenceSize = CGSize(width: UIScreen.main.bounds.size.width, height: 25)
        layout.sectionInset = UIEdgeInsets(top: 10, left: 12, bottom: 10, right: 12)
        let collectionView = UICollectionView(frame: .zero, collectionViewLayout: layout)
        collectionView.dataSource = self
        collectionView.delegate = self
        
        collectionView.register(UINib(nibName: "CateCell", bundle: Bundle.main), forCellWithReuseIdentifier: "CateCell")
        
        collectionView.register(UINib(nibName: "CateHeader", bundle: Bundle.main), forSupplementaryViewOfKind: UICollectionView.elementKindSectionHeader, withReuseIdentifier:"CateHeader")
        
        collectionView.backgroundColor = .clear
        collectionView.state = .loading
        collectionView.showsVerticalScrollIndicator = false
        return collectionView
    }()
}

//_______________________________________________________________________________________________________________
// MARK: - UICollectionViewDataSource & UICollectionViewDelegate
extension ChooseCateVC:UICollectionViewDataSource,UICollectionViewDelegate,UICollectionViewDelegateFlowLayout {
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        self.items.count
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        let item = self.items[section]
        return item.tagsList.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CateCell", for: indexPath) as! CateCell
        cell.delegate = self
        let item = self.items[indexPath.section]
        let model = item.tagsList[indexPath.row]
        cell.item = model
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, viewForSupplementaryElementOfKind kind: String, at indexPath: IndexPath) -> UICollectionReusableView {
        if kind == UICollectionView.elementKindSectionHeader {
            let headerView = collectionView.dequeueReusableSupplementaryView(ofKind: UICollectionView.elementKindSectionHeader, withReuseIdentifier: "CateHeader", for: indexPath) as! CateHeader
            let item = self.items[indexPath.section]
            headerView.item = item
            return headerView
        }
        return UICollectionReusableView()
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let item = self.items[indexPath.section]
        let model = item.tagsList[indexPath.row]
        return CGSize(width: CateCell.itemW(model), height: 27)
    }
}

//_______________________________________________________________________________________________________________
// MARK: - cell点击事件
extension ChooseCateVC:CateCellDelegate {
    
    func cateCell(_ cell: CateCell, didTapButton button: UIButton) {
        guard  let item = cell.item else {
            return
        }
        if item.selected {
            item.selected = false
            selectedCount = selectedCount - 1
            collectionView.reloadItems(at: [itemIndexPath(item)])
        } else {
            if self.selectedCount < 3 {
                selectedCount = selectedCount + 1
                item.selected = true
                collectionView.reloadItems(at: [itemIndexPath(item)])
            } else{
                mm_showToast("最多選擇3個！")
            }
        }
    }
    
    private func itemIndexPath(_ item:PublishCateItem) -> IndexPath {
        for i  in 0..<self.items.count {
            let itemA = self.items[i]
            for j in 0..<itemA.tagsList.count {
                let subItem = itemA.tagsList[j]
                if item.tagsId == subItem.tagsId {
                    return IndexPath(row: j, section: i)
                }
            }
        }
        return IndexPath(row: 0, section: 0)
    }
}
