//
//  UploadCellAdapter.swift
//  Sp
//
//  Created by mac on 2020/8/18.
//  Copyright © 2020 mac. All rights reserved.
//

import Foundation

class UploadCellAdapter: NSObject, Adapter, UploadCellDelegate {
    
    typealias M = HotCreationItem
    typealias V = UploadCell
    
    weak var controller: UploadVC?
    var model: HotCreationItem?
    var view: UploadCell? {
        didSet {
            view?.bgImageView.kf.setImage(with: model!.imgUrl)
            view?.titleLabel.text = "#" + model!.tagsTitle
            view?.uploadButton.setTitle(model!.btnName, for: .normal)
            view?.delegate = self
        }
    }
    
    func didClickButtonOn(_ cell: UploadCell) {
        guard let item = model else { return }
        let pItem = PublishCateItem()
        pItem.tagsId = item.tagsId
        pItem.tagsTitle = item.tagsTitle
        UploadConfig.shared.saveTags([pItem])
        let vc = UploadVideoVC()
        controller?.navigationController?.pushViewController(vc, animated: true)
    }
}
