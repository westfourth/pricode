//
//  UploadCell.swift
//  Sp
//
//  Created by mac on 2020/8/4.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class UploadCell: UICollectionViewCell {
    @IBOutlet weak var bgImageView: UIImageView!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var uploadButton: UIButton!
    
    weak var delegate: UploadCellDelegate?
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    @IBAction func click(_ sender: UIButton) {
        delegate?.didClickButtonOn(self)
    }
}

protocol UploadCellDelegate: NSObject {
    func didClickButtonOn(_ cell: UploadCell)
}
