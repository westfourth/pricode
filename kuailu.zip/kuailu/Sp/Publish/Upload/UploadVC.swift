//
//  UploadVC.swift
//  Sp
//
//  Created by mac on 2020/8/4.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class UploadVC: UIViewController {
    @IBOutlet weak var collectionView: UICollectionView!
    var pageControl = CarouselPageControl()
    var adapters = [UploadCellAdapter]()
    
    var layer = CAShapeLayer()
    
    //MARK:-    Life Circle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //
        collectionView.contentInsetAdjustmentBehavior = .never
        collectionView.isPagingEnabled = true
        collectionView.showsHorizontalScrollIndicator = false
        let nib = UINib(nibName: "UploadCell", bundle: nil)
        collectionView.register(nib, forCellWithReuseIdentifier: "ID")
        
        //  pageControl
        pageControl.numberOfPages = 0
        pageControl.currentPage = 0
        view.addSubview(pageControl)
        pageControl.snp.makeConstraints { (make) in
            make.centerX.equalToSuperview().offset(-30)
            make.bottom.equalTo(collectionView).offset(-20 - 25)
        }
        
        //
        view.layer.addSublayer(layer);
        layer.fillColor = rgb(20, 21, 21).cgColor
        
        //
        requestHotCreationList()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.setNavigationBarHidden(true, animated: true)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        navigationController?.setNavigationBarHidden(false, animated: true)
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        //
        let layout = collectionView.collectionViewLayout as! UICollectionViewFlowLayout
        layout.scrollDirection = .horizontal
        layout.minimumLineSpacing = 0
        layout.minimumInteritemSpacing = 0
        layout.itemSize = collectionView.bounds.size
        //
        let path = UIBezierPath()
        let cframe = collectionView.frame
        path.move(to: CGPoint(x: cframe.minX, y: cframe.maxY))
        path.addQuadCurve(to: CGPoint(x: cframe.maxX, y: cframe.maxY), controlPoint: CGPoint(x: cframe.midX, y: cframe.maxY - 50))
        layer.path = path.cgPath
    }
    
    //MARK:-    Actions
    
    //  本地作品
    @IBAction func clickLocalWorks(_ sender: UIButton) {
        guard UploadConfig.shared.info.allow else {
            mm_showToast("系統維護中，暫不能上傳視頻!")
            return
        }
        let vc = UploadVideoVC()
        navigationController?.pushViewController(vc, animated: true)
    }
    
    //  写真
    @IBAction func clickPortray(_ sender: UIButton) {
        guard UploadConfig.shared.info.allow else {
          mm_showToast("系統維護中，暫不能上傳視頻!")
          return
        }
        let vc = UploadPortrayVC()
        navigationController?.pushViewController(vc, animated: true)
    }
    
    //  动态
    @IBAction func clickTrends(_ sender: UIButton) {
        guard UploadConfig.shared.info.allow else {
          mm_showToast("系統維護中，暫不能上傳視頻!")
          return
        }
        let vc = UploadImageVC()
        navigationController?.pushViewController(vc, animated: true)
    }
    
    //  退出
    @IBAction func clickClose(_ sender: UIButton) {
//        dismiss(animated: true, completion: nil)
//        navigationController?.dismiss(animated: true, completion: nil)
        navigationController?.popViewController(animated: true)
    }
    
    //MARK:-    API
    
    func requestHotCreationList() {
        Alert.showLoading(parentView: view)
        Session.request(HotCreationListReq()) { [weak self] (error, resp) in
            Alert.hideLoading()
            guard error == nil, let items = resp as? [HotCreationItem] else {
                return
            }
            self?.adapters = items.map { (item) -> UploadCellAdapter in
                let adapter = UploadCellAdapter()
                adapter.model = item
                adapter.controller = self
                return adapter
            }
            self?.collectionView.reloadData()
            self?.pageControl.numberOfPages = self?.adapters.count as! NSInteger
        }
    }
}

extension UploadVC: UICollectionViewDataSource, UIScrollViewDelegate {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return self.adapters.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "ID", for: indexPath) as! UploadCell
        let adapter = adapters[indexPath.row]
        adapter.view = cell
        return cell
    }
    
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        let idx = Int(scrollView.contentOffset.x / scrollView.frame.width)
        pageControl.currentPage = idx
    }
}
