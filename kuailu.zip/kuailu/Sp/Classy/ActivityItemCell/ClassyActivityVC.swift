//
//  ClassyActivityVC.swift
//  Sp
//
//  Created by mac on 2020/7/28.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

enum ClassyActivityType {
    case notStart
    case processing
    case finished
}

class ClassyActivityVC: UIViewController {
    
    private lazy var tableView: UITableView = {
        let tableView = UITableView(frame: .zero, style: .grouped)
        tableView.delegate = self
        tableView.dataSource = self
        tableView.backgroundColor = .none
        tableView.separatorStyle = .none
        tableView.bouncesZoom = false
        tableView.isDirectionalLockEnabled = true
        tableView.showsVerticalScrollIndicator = false
        tableView.contentInset = UIEdgeInsets(top: 10, left: 0, bottom: 10, right: 0)
        tableView.register(ClassyActivityCell.self, forCellReuseIdentifier: "ClassyActivityCell")
        return tableView
    }()
    
    private lazy var classyActivityHeaderView: ClassyActivityHeaderView = {
        let headerView = ClassyActivityHeaderView()
        return headerView
    }()
    
    private let itemHeight: CGFloat = ClassyActivityCell.itemHeight + 10
    
    private var activityData: ClassifyActivityResp?
    
    var classyActivityType: ClassyActivityType = .finished {
        didSet {
            if classyActivityType != .finished {
                tableView.mj_header = getCommonMJHeader(refreshingTarget: self, headerRefreshCallback: #selector(onRefresh))
            }
            classyActivityHeaderView.finishedActivityBtn.isHidden = classyActivityType == .finished
        }
    }
    
    var activityId: Int = 0
    
    var navigationTitle: String = "" {
        didSet {
            navigationItem.title = navigationTitle
        }
    }
    
    override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: Bundle?) {
        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
        hidesBottomBarWhenPushed = true
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = RGB(0x141516)
        view.addSubview(tableView)
        tableView.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
        getData()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.navigationBar.isTranslucent = false
        navigationController?.navigationBar.barTintColor = RGB(0x1C1E2B)
    }
    
    private func getData() {
        var req: BaseRequestModel?
        if classyActivityType == .finished {
            req = QueryActivityReq()
            (req as? QueryActivityReq)?.activityId = activityId
        } else {
            req = ClassifyActivityReq()
        }
        Session.request(req!) { [weak self] (error, resp) in
            guard let `self` = self else { return }
            self.tableView.mj_header?.endRefreshing()
            guard error == nil, let resData = resp as? ClassifyActivityResp else { return }
            self.navigationItem.title = resData.title
            self.classyActivityHeaderView.activityData = resData
            self.activityData = resData
            self.tableView.reloadData()
        }
    }
    
    @objc private func onRefresh() {
        getData()
    }
    
    func refreshActivity() {
        classyActivityHeaderView.activityData = activityData
    }
}

extension ClassyActivityVC: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return activityData?.videos.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 395 + CGFloat(activityData?.actRule.count ?? 0) * ClassyActivityHeaderView.ruleItemHeight
    }
    
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return .leastNonzeroMagnitude
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        return classyActivityHeaderView
    }
    
    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        return nil
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return itemHeight
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ClassyActivityCell", for: indexPath) as! ClassyActivityCell
        let row = indexPath.row
        cell.currentIndex = row
        cell.dataModel = activityData?.videos[row]
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        SearchResultVC.navigationToVideoPlayListVC(indexPath: indexPath, VideoList: activityData?.videos ?? [])
    }
    
}
