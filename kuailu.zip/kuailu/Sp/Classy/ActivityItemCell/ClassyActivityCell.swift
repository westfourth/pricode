//
//  ClassyActivityCell.swift
//  Sp
//
//  Created by mac on 2020/7/28.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class ClassyActivityCell: UITableViewCell {
    
    static let itemHeight: CGFloat = 150
    
    private static let posterRatio: CGFloat = 120 / 150
    
    private static let posterWidth: CGFloat = ClassyActivityCell.itemHeight * ClassyActivityCell.posterRatio
    
    private static let likeImg: UIImage? = {
        return UIImage(named: "classy_activity_like_icon")
    }()

    static let rankImgList: [UIImage?] = {
        var temp: [UIImage?] = []
        for i in 1...25 {
            temp.append(UIImage(named: "classy_activity_rank_\(i)"))
        }
        return temp
    }()
    
    private static let lockIconImg: UIImage? = {
        return UIImage(named: "ic_lock")
    }()
    
    private static let v6IconImg: UIImage? = {
        return UIImage(named: "v6_icon")
    }()
    
    private lazy var posterImgView: UIImageView = {
        let imgView = UIImageView()
        imgView.contentMode = .scaleAspectFill
        imgView.layer.masksToBounds = true
        imgView.layer.cornerRadius = 6
        imgView.addSubview(typeImgView)
        imgView.addSubview(lockMaskView)
        imgView.addSubview(v6ImgView)
        
        typeImgView.snp.makeConstraints { (make) in
            make.left.top.equalToSuperview()
        }
        
        lockMaskView.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
        
        v6ImgView.snp.makeConstraints { (make) in
            make.top.equalToSuperview()
            make.right.equalToSuperview()
            make.width.equalTo(42)
            make.height.equalTo(14)
        }
        return imgView
    }()
    
    private lazy var typeImgView: UIImageView = {
        return UIImageView()
    }()
    
    private lazy var rankImgView: UIImageView = {
        return UIImageView()
    }()
    
    private lazy var nicknameTipLabel: UILabel = {
        let label = UILabel()
        label.text = "昵稱："
        label.textColor = .white
        label.font = UIFont.pingFangMedium(14)
        return label
    }()
    
    private lazy var nicknameLabel: UILabel = {
        let label = UILabel()
        label.textColor = .white
        label.font = UIFont.pingFangRegular(12)
        label.textAlignment = .left
        return label
    }()
    
    private lazy var worksTipLabel: UILabel = {
        let label = UILabel()
        label.text = "作品名稱："
        label.textColor = .white
        label.font = UIFont.pingFangMedium(14)
        return label
    }()
    
    private lazy var worksLabel: UILabel = {
        let label = UILabel()
        label.textColor = .white
        label.font = UIFont.pingFangRegular(14)
        label.numberOfLines = 2
        return label
    }()
    
    private lazy var likeImgView: UIImageView = {
        let imgView = UIImageView(image: ClassyActivityCell.likeImg)
        return imgView
    }()
    
    private lazy var collectionNumLabel: UILabel = {
        let label = UILabel()
        label.textColor = .white
        label.font = UIFont.pingFangMedium(14)
        return label
    }()
    
    private lazy var v6ImgView: UIImageView = {
        let imgView = UIImageView(image: ClassyActivityCell.v6IconImg)
        imgView.isHidden = true
        return imgView
    }()
    
    private lazy var lockImgView: UIImageView = {
        let imgView = UIImageView(image: ClassyActivityCell.lockIconImg)
        return imgView
    }()
    
    private lazy var lockLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.pingFangRegular(12)
        label.textColor = .white
        label.text = "V6專享視頻"
        return label
    }()
    
    private lazy var lockMaskView: UIView = {
         let view = UIView()
         view.backgroundColor = UIColor.black.withAlphaComponent(0.3)
         view.addSubview(lockImgView)
         view.addSubview(lockLabel)
         view.isHidden = true
         
         lockImgView.snp.makeConstraints { (make) in
             make.centerX.equalToSuperview()
             make.centerY.equalToSuperview().offset(-14)
             make.width.equalTo(40)
             make.height.equalTo(44)
         }
         
         lockLabel.snp.makeConstraints { (make) in
             make.centerX.equalToSuperview()
             make.top.equalTo(lockImgView.snp.bottom).offset(10)
         }
         return view
     }()
    
    var currentIndex: Int = 0
    
    var dataModel: VideoItem? {
        didSet {
            guard let item = dataModel else { return }
            posterImgView.kf.setImage(with: item.coverImg, placeholder: SearchResultVideoCell.defaultImg, options: SearchResultVideoCell.animationOption)
            lockMaskView.isHidden = !(item.isSpecial && NetDefaults.userInfo?.specialAuth != true)
            v6ImgView.isHidden = !item.isSpecial
            rankImgView.image = ClassyActivityCell.rankImgList[currentIndex]
            nicknameLabel.text = item.nickName
            worksLabel.text = item.title
            collectionNumLabel.text = num2TenThousandStrFormat(item.fakeLikes)
            rankImgView.snp.updateConstraints { (make) in
                make.height.equalTo(currentIndex > 2 ? 16 : 18)
            }
        }
    }
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        backgroundColor = .none
        selectionStyle = .none
        renderView()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func renderView() {
        addSubview(posterImgView)
        addSubview(typeImgView)
        addSubview(rankImgView)
        addSubview(nicknameTipLabel)
        addSubview(nicknameLabel)
        addSubview(worksTipLabel)
        addSubview(worksLabel)
        addSubview(likeImgView)
        addSubview(collectionNumLabel)
        
        posterImgView.snp.makeConstraints { (make) in
            make.centerY.equalToSuperview()
            make.left.equalToSuperview().inset(12)
            make.height.equalTo(ClassyActivityCell.itemHeight)
            make.width.equalTo(ClassyActivityCell.posterWidth)
        }
        
        rankImgView.snp.makeConstraints { (make) in
            make.left.equalTo(posterImgView.snp.right).offset(10)
            make.top.equalTo(posterImgView)
            make.width.equalTo(63)
            make.height.equalTo(16)
        }
        
        nicknameTipLabel.snp.makeConstraints { (make) in
            make.left.equalTo(rankImgView)
            make.top.equalTo(rankImgView.snp.bottom).offset(9)
        }
        
        nicknameLabel.snp.makeConstraints { (make) in
            make.centerY.equalTo(nicknameTipLabel)
            make.right.equalToSuperview().inset(12)
            make.left.equalToSuperview().inset(ClassyActivityCell.posterWidth + 64)
        }
        
        worksTipLabel.snp.makeConstraints { (make) in
            make.left.equalTo(nicknameTipLabel)
            make.top.equalTo(nicknameTipLabel.snp.bottom).offset(9)
            make.right.equalToSuperview().inset(12)
        }
        
        worksLabel.snp.makeConstraints { (make) in
            make.left.equalTo(worksTipLabel)
            make.right.equalToSuperview().inset(12)
            make.top.equalTo(worksTipLabel.snp.bottom).offset(1)
        }
        
        likeImgView.snp.makeConstraints { (make) in
            make.bottom.equalTo(posterImgView)
            make.left.equalTo(rankImgView)
            make.size.equalTo(20)
        }
        
        collectionNumLabel.snp.makeConstraints { (make) in
            make.centerY.equalTo(likeImgView)
            make.left.equalTo(likeImgView.snp.right).offset(6)
        }

    }
    
}
