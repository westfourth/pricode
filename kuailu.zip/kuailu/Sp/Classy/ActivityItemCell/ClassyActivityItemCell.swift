//
//  ClassyActivityItemCell.swift
//  Sp
//
//  Created by mac on 2020/7/30.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class ClassyActivityItemCell: UICollectionViewCell {
    
    private lazy var classyActivityVC: ClassyActivityVC = {
        let classyActivityVC = ClassyActivityVC()
        classyActivityVC.classyActivityType = .processing
        return classyActivityVC
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        addSubview(classyActivityVC.view)
        classyActivityVC.view.snp.makeConstraints { (make) in
            make.top.equalToSuperview().inset(kTop)
            make.left.right.bottom.equalToSuperview()
        }

    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func refreshActivity() {
        classyActivityVC.refreshActivity()
    }
    
}
