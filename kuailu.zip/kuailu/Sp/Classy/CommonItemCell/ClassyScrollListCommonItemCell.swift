//
//  classyScrollListItemCell.swift
//  Sp
//
//  Created by mac on 2020/5/4.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class ClassyScrollListCommonItemCell: UICollectionViewCell {
    
    static let itemWidth: CGFloat = (UIScreen.main.bounds.size.width - 12 * 2 - 6) / 2
    
    static let itemRatio: CGFloat = 223 / 165
    
    private var bannerListData: [AdvertiseResp] = []
    
    private var listData: [VideoItem] = []
    
    private var isInitState: Bool = true
    
    var classifyId: Int? {
        didSet {
            guard isInitState else { return }
            isInitState = false
            getBannerList()
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) { [weak self] in
                self?.getList(isRefresh: true)
            }
        }
    }
    
    private lazy var collectionView: UICollectionView = {
        let layout = UICollectionViewFlowLayout()
        layout.sectionInset = UIEdgeInsets(top: 0, left: 12, bottom: 0, right: 12)
        layout.itemSize = CGSize(width: ClassyScrollListCommonItemCell.itemWidth, height: ClassyScrollListCommonItemCell.itemWidth * ClassyScrollListCommonItemCell.itemRatio)
        layout.minimumLineSpacing = 6
        layout.minimumInteritemSpacing = 6
        let cv = UICollectionView(frame: .zero, collectionViewLayout: layout)
        cv.register(SearchResultVideoCell.self, forCellWithReuseIdentifier: "SearchResultVideoCell")
        cv.register(ClassyScrollListCommonHeaderView.self, forSupplementaryViewOfKind: UICollectionView.elementKindSectionHeader, withReuseIdentifier: "ClassyScrollListCommonHeaderView")
        cv.backgroundColor = .none
        cv.delegate = self
        cv.dataSource = self
        cv.showsVerticalScrollIndicator = false
        cv.showsHorizontalScrollIndicator = false
        cv.state = .loading
        cv.mj_header = getCommonMJHeader(refreshingTarget: self, headerRefreshCallback: #selector(onRefresh))
        cv.mj_footer = getCommonMJFooter(refreshingTarget: self, footerRefreshCallback: #selector(onLoad))
        return cv
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        addSubview(collectionView)
        collectionView.snp.makeConstraints { (make) in
            make.top.equalToSuperview().inset(8)
            make.left.right.bottom.equalToSuperview()
        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func getBannerList() {
//        guard let id = classifyId, let listData = AdManager.shared.classyItems(id) else { return }
//        self.bannerListData = listData
//        self.collectionView.reloadData()
    }
    
    private func getList(isRefresh: Bool) {
        collectionView.state = listData.isEmpty ? .loading : .normal
        let req = ClassyVideoListByIdReq()
        req.classifyId = classifyId ?? -1
        req.pageSize = isRefresh ? 8 : req.pageSize
        req.lastId = isRefresh ? 0 : (listData.last?.videoId ?? 0)
        if isRefresh {
            collectionView.mj_footer?.resetNoMoreData()
        }
        let collectionView = self.collectionView
        Session.request(req) { [weak self] (error, resp) in
            isRefresh ? collectionView.mj_header?.endRefreshing() : collectionView.mj_footer?.endRefreshing()
            guard let `self` = self else { return }
            guard error == nil, let resData = resp as? [VideoItem] else {
                self.handleListException(isRefresh: isRefresh)
                return
            }
            self.listData = isRefresh ? resData : self.listData + resData
            let isEmpty = self.listData.isEmpty
            collectionView.state = isEmpty ? .empty : .normal
            collectionView.mj_footer?.isHidden = isEmpty
            collectionView.reloadData()
            if resData.count < req.pageSize {
                DispatchQueue.main.async {
                    collectionView.mj_footer?.endRefreshingWithNoMoreData()
                }
            }
        }
    }
    
    private func handleListException(isRefresh: Bool) {
        if isRefresh {
            listData = []
            collectionView.reloadData()
            collectionView.state = .failed
            collectionView.mj_footer?.isHidden = true
        } else {
            collectionView.state = .normal
            collectionView.mj_footer?.endRefreshingWithNoMoreData()
            collectionView.mj_footer?.isHidden = false
        }
    }
    
    @objc private func onLoad() {
        getList(isRefresh: false)
    }
    
    @objc private func onRefresh() {
        getList(isRefresh: true)
    }
}


extension ClassyScrollListCommonItemCell: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout{
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return listData.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "SearchResultVideoCell", for: indexPath) as! SearchResultVideoCell
        cell.dataModel = listData[indexPath.row]
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, referenceSizeForHeaderInSection section: Int) -> CGSize {
        return bannerListData.isEmpty ? .zero : CGSize(width: UIScreen.main.bounds.size.width, height: 108 * ClassyScrollListRecomBannerCell.leaderboardRatio + 10)
    }
    
    func collectionView(_ collectionView: UICollectionView, viewForSupplementaryElementOfKind kind: String, at indexPath: IndexPath) -> UICollectionReusableView {
        guard kind == UICollectionView.elementKindSectionHeader, let header = collectionView.dequeueReusableSupplementaryView(ofKind: kind, withReuseIdentifier: "ClassyScrollListCommonHeaderView", for: indexPath) as? ClassyScrollListCommonHeaderView else {
            return UICollectionReusableView()
        }
        header.bannerListData = bannerListData
        return header
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        SearchResultVC.navigationToVideoPlayListVC(indexPath: indexPath, VideoList: listData)
    }
}
