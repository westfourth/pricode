//
//  ClassyScrollListV6ExlusiveItemCell.swift
//  Sp
//
//  Created by mac on 2020/5/21.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

protocol ClassyScrollListV6ExlusiveItemCellDelegate: NSObjectProtocol {
    
    func handleV6ExlusiveBgConvertToPlain(currentIndex: Int)
    
    func handlePlainConvertToV6ExlusiveBg(currentIndex: Int)
    
}

class ClassyScrollListV6ExlusiveItemCell: UICollectionViewCell {
    
    static let itemWidth: CGFloat = (UIScreen.main.bounds.size.width - 12 * 2 - 6) / 2
    
    static let itemRatio: CGFloat = 223 / 165
    
    private var channelTypeHeightList: [CGFloat] = [20]
    
    private let lockBgMaskAnimation: CABasicAnimation = {
        let animation = CABasicAnimation(keyPath: "transform.scale")
        // 预设是顺时针效果，若将formValue和toValue的值互换，则为逆时针效果
        animation.fromValue = 1
        animation.toValue = 0.7
        animation.duration = 1
        animation.autoreverses = true
        // 解决动画结束后回到原始状态的问题
        animation.isRemovedOnCompletion = false
        animation.fillMode = .forwards
        animation.repeatCount = MAXFLOAT // 一直旋轉的話，就設定為MAXFLOAT
        // 定义动画的节奏
        animation.timingFunction = CAMediaTimingFunction(name: .easeInEaseOut)
        return animation
    }()
    
    private let lockBgCircleAnimation: CABasicAnimation = {
        let animation = CABasicAnimation(keyPath: "transform.rotation.z")
        // 预设是顺时针效果，若将formValue和toValue的值互换，则为逆时针效果
        animation.fromValue = 0
        animation.toValue = Double.pi * 2
        animation.duration = 1
        //        animation.speed = 1
        animation.autoreverses = false
        // 解决动画结束后回到原始状态的问题
        animation.isRemovedOnCompletion = false
        animation.fillMode = .forwards
        animation.repeatCount = MAXFLOAT // 一直旋轉的話，就設定為MAXFLOAT
        // 定义动画的节奏
        animation.timingFunction = CAMediaTimingFunction(name: .easeInEaseOut)
        return animation
    }()
    
    private lazy var lockImgView: UIImageView = {
        let imgView = UIImageView(image: UIImage(named: "classy_v6_lock_icon"))
        return imgView
    }()
    
    private lazy var lockBgMaskImgView: UIImageView = {
        let imgView = UIImageView(image: UIImage(named: "classy_v6_lock_mask_bg"))
        imgView.addSubview(lockImgView)
        lockImgView.snp.makeConstraints { (make) in
            make.center.equalToSuperview()
            make.width.equalTo(78)
            make.height.equalTo(119)
        }
        imgView.layer.add(lockBgMaskAnimation, forKey: nil)
        return imgView
    }()
    
    private lazy var lockBgCircleImgView: UIImageView = {
        let imgView = UIImageView(image: UIImage(named: "classy_v6_lock_circle_bg"))
        imgView.layer.add(lockBgCircleAnimation, forKey: nil)
        return imgView
    }()
    
    private lazy var lockWrapperBtn: UIButton = {
        let btn = UIButton()
        btn.isHidden = true
        btn.addTarget(self, action: #selector(onLockWrapperBtnTap), for: .touchUpInside)
        btn.addSubview(lockBgCircleImgView)
        btn.addSubview(lockBgMaskImgView)
        
        lockBgCircleImgView.snp.makeConstraints { (make) in
            make.center.size.equalToSuperview()
        }
        
        lockBgMaskImgView.snp.makeConstraints { (make) in
            make.center.equalToSuperview()
            make.size.equalTo(190)
        }
        
        return btn
    }()
    
    private lazy var titpLabel: UILabel = {
        let label = UILabel()
        let attributes = [NSAttributedString.Key.font:  UIFont.pingFangMedium(20),
                          NSAttributedString.Key.foregroundColor: RGB(0xFFCA84)]
        let attributedString = NSMutableAttributedString(string: "升級V6或\(Sensitive.gou)專區視頻體驗票", attributes: attributes)
        attributedString.addAttributes([NSAttributedString.Key.foregroundColor: UIColor.white], range: NSRange(location: 4, length: 3))
        label.attributedText = attributedString
        return label
    }()
    
    private lazy var unLockLabel: UILabel = {
        let label = UILabel()
        label.text = "即刻解鎖！"
        label.textColor = RGB(0xFFCA84)
        label.font = UIFont.pingFangMedium(20)
        return label
    }()
    
    private lazy var upgradeLevelBtn: UIButton = {
        let btn = UIButton()
        btn.setBackgroundImage(UIImage(named: "classy_v6_upgrade_level_bg"), for: .normal)
        btn.addTarget(self, action: #selector(onUpgradeLevelBtnTap), for: .touchUpInside)
        return btn
    }()
    
    private lazy var buyTicketsBtn: UIButton = {
        let btn = UIButton()
        btn.setBackgroundImage(UIImage(named: "classy_v6_buy_tickets_bg"), for: .normal)
        btn.addTarget(self, action: #selector(onBuyTicketsBtnTap), for: .touchUpInside)
        return btn
    }()
    
    private lazy var unlockGuideView: UIView = {
        let view = UIView()
        view.isHidden = true
        view.addSubview(unLockLabel)
        view.addSubview(titpLabel)
        view.addSubview(upgradeLevelBtn)
        view.addSubview(buyTicketsBtn)
        
        unLockLabel.snp.makeConstraints { (make) in
            make.center.equalToSuperview()
        }
        
        titpLabel.snp.makeConstraints { (make) in
            make.bottom.equalTo(unLockLabel.snp.top).offset(-28)
            make.centerX.equalToSuperview()
        }
        
        upgradeLevelBtn.snp.makeConstraints { (make) in
            make.top.equalTo(unLockLabel.snp.bottom).offset(44)
            make.centerX.equalToSuperview().offset( -117 / 2 - 22)
            make.width.equalTo(117)
            make.height.equalTo(39)
        }
        
        buyTicketsBtn.snp.makeConstraints { (make) in
            make.top.equalTo(unLockLabel.snp.bottom).offset(44)
            make.left.equalTo(upgradeLevelBtn.snp.right).offset(44)
            make.size.equalTo(upgradeLevelBtn)
        }
        
        return view
    }()
    
    private lazy var tableView: UITableView = {
        let tableView = UITableView(frame: .zero, style: .grouped)
        tableView.delegate = self
        tableView.dataSource = self
        tableView.backgroundColor = .none
        tableView.separatorStyle = .none
        tableView.bouncesZoom = false
        tableView.isDirectionalLockEnabled = true
        tableView.isHidden = true
        tableView.mj_header = getCommonMJHeader(refreshingTarget: self, headerRefreshCallback: #selector(onRefresh))
        tableView.mj_footer = getCommonMJFooter(refreshingTarget: self, footerRefreshCallback: #selector(onLoad))
        return tableView
    }()
    
    weak var delegate: ClassyScrollListV6ExlusiveItemCellDelegate?
    
    private var isShowUnlockGuideView: Bool = false
    
    private var bannerListData: [AdvertiseResp] = []
    
    private var listData: [V6StationItem] = []
    
    private var isInitState: Bool = true
    
    private var isQualified: Bool?
    
    var currentIndex: Int?
    
    var classifyId: String? {
        didSet {
            guard !isInitState else {
                isInitState = false
                getBannerList()
                getDataList()
                return
            }
            guard isQualified != true else { return }
            if isQualified == false {
                rebootAnimations()
            }
            getDataList()
        }
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        NotificationCenter.default.addObserver(self, selector: #selector(refreshDataList), name: .GetV6ExlusiveListDataName, object: nil)
        renderView()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    deinit {
        NotificationCenter.default.removeObserver(self)
    }
    
    private func renderView() {
        addSubview(lockWrapperBtn)
        addSubview(unlockGuideView)
        addSubview(tableView)
        
        lockWrapperBtn.snp.makeConstraints { (make) in
            make.centerX.equalToSuperview()
            make.centerY.equalToSuperview().multipliedBy(0.8)
            make.width.equalTo(262)
            make.height.equalTo(260)
        }
        
        unlockGuideView.snp.makeConstraints { (make) in
            make.centerX.equalToSuperview()
            make.centerY.equalToSuperview().multipliedBy(0.8)
            make.width.equalTo(290)
            make.height.equalTo(200)
        }
        
        tableView.snp.makeConstraints { (make) in
            make.top.equalToSuperview().inset(kTop)
            make.left.right.bottom.equalToSuperview()
        }
    }
    
    @objc private func refreshDataList() {
        guard isQualified != true else { return }
        getList(isRefresh: true)
    }
    
    private func getDataList() {
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) { [weak self] in
            self?.getList(isRefresh: true)
        }
    }
    
    private func getBannerList() {
//        guard let id = classifyId, let listData = AdManager.shared.classyItems(id), !listData.isEmpty else { return }
//        bannerListData = listData
//        channelTypeHeightList[0] = ClassyScrollListV6ExlusiveBannerCell.viewHeight
//        tableView.register(ClassyScrollListV6ExlusiveBannerCell.self, forCellReuseIdentifier: "ClassyScrollListV6ExlusiveBannerCell")
//        tableView.reloadData()
    }
    
    private func getList(isRefresh: Bool) {
        tableView.state = listData.isEmpty ? .loading : .normal
        let req = V6VideosReq()
        req.lastId = isRefresh ? 0 : (listData.last?.stationId ?? 0)
        if isRefresh {
            tableView.mj_footer?.resetNoMoreData()
        }
        let tableView = self.tableView
        Session.request(req) { [weak self] (error, resp) in
            isRefresh ? tableView.mj_header?.endRefreshing() : tableView.mj_footer?.endRefreshing()
            guard let `self` = self else { return }
            guard error == nil, let resData = resp as? [V6StationItem] else {
                guard let e = error as NSError?, let code = e.userInfo["NetRequestErrorCodeKey"] as? Int, code == 1200 else {
                    if self.isQualified == false {
                        self.removeAnimations()
                    }
                    self.isQualified = nil
                    self.isShowUnlockGuideView = false
                    self.unlockGuideView.isHidden = true
                    self.lockWrapperBtn.isHidden = true
                    self.tableView.isHidden = true
                    self.handleListException(isRefresh: isRefresh)
                    return
                }
                if self.isQualified != false {
                    self.rebootAnimations()
                }
                self.isQualified = false
                self.tableView.isHidden = true
                self.lockWrapperBtn.isHidden = self.isShowUnlockGuideView
                self.unlockGuideView.isHidden = !self.isShowUnlockGuideView
                self.currentIndex != nil ? (self.delegate?.handlePlainConvertToV6ExlusiveBg(currentIndex: self.currentIndex!)) : nil
                guard !self.listData.isEmpty else { return }
                self.listData = []
                self.channelTypeHeightList = self.bannerListData.isEmpty ? [] : [ClassyScrollListV6ExlusiveBannerCell.viewHeight]
                tableView.reloadData()
                return
            }
            if self.isQualified == false {
                self.removeAnimations()
            }
            self.isQualified = true
            self.isShowUnlockGuideView = false
            self.unlockGuideView.isHidden = true
            self.lockWrapperBtn.isHidden = true
            self.tableView.isHidden = false
            self.currentIndex != nil ? self.delegate?.handleV6ExlusiveBgConvertToPlain(currentIndex: self.currentIndex!) : nil
            if isRefresh {
                self.channelTypeHeightList = self.bannerListData.isEmpty ? [] : [ClassyScrollListV6ExlusiveBannerCell.viewHeight]
            }
            let bannerCount = self.bannerListData.isEmpty ? 0 : 1
            let previousCount = self.listData.count
            for i in 0..<resData.count {
                let isNew = resData[i].type == .new
                self.channelTypeHeightList.append(isNew ? ClassyScrollListV6ExlusiveNewCell.viewHeight : ClassyScrollListV6ExlusiveCommonCell.viewHeight)
                let index = previousCount + i + bannerCount
                self.tableView.register(isNew ? ClassyScrollListV6ExlusiveNewCell.self : ClassyScrollListV6ExlusiveCommonCell.self, forCellReuseIdentifier: isNew ? "ClassyScrollListV6ExlusiveNewCell\(index)" : "ClassyScrollListV6ExlusiveCommonCell\(index)")
            }
            self.listData = isRefresh ? resData : self.listData + resData
            let isEmpty = self.listData.isEmpty
            tableView.state = isEmpty ? .empty : .normal
            tableView.mj_footer?.isHidden = isEmpty
            tableView.reloadData()
            if resData.count < req.pageSize {
                DispatchQueue.main.async {
                    tableView.mj_footer?.endRefreshingWithNoMoreData()
                }
            }
        }
    }
    
    private func handleListException(isRefresh: Bool) {
        if isRefresh {
            listData = []
            channelTypeHeightList = bannerListData.isEmpty ? [] : [ClassyScrollListV6ExlusiveBannerCell.viewHeight]
            tableView.reloadData()
            tableView.state = .failed
            tableView.mj_footer?.isHidden = true
        } else {
            tableView.state = .normal
            tableView.mj_footer?.endRefreshingWithNoMoreData()
            tableView.mj_footer?.isHidden = false
        }
    }
    
    private func rebootAnimations() {
        guard isQualified == false, !isShowUnlockGuideView else { return }
        removeAnimations()
        startAnimations()
    }
    
    private func startAnimations() {
        DispatchQueue.main.async { [weak self] in
            guard let `self` = self else { return }
            self.lockBgMaskImgView.layer.add(self.lockBgMaskAnimation, forKey: "lockBgMaskAnimation")
            self.lockBgCircleImgView.layer.add(self.lockBgCircleAnimation, forKey: "lockBgCircleAnimation")
        }
    }
    
    private func removeAnimations() {
        lockBgMaskImgView.layer.removeAllAnimations()
        lockBgCircleImgView.layer.removeAllAnimations()
    }
    
    @objc private func onLoad() {
        getList(isRefresh: false)
    }
    
    @objc private func onRefresh() {
        getList(isRefresh: true)
    }
    
    @objc private func onLockWrapperBtnTap() {
        isShowUnlockGuideView = true
        removeAnimations()
        lockWrapperBtn.isHidden = true
        unlockGuideView.isHidden = false
    }
    
    @objc private func onUpgradeLevelBtnTap() {
        guard let currentNavigationController = (UIApplication.shared.delegate as? AppDelegate)?.currentNavigationController else { return }
        VipChargeTipVC.isFromVideoPlayList = false
        currentNavigationController.show(Vip2VC(), sender: nil)
    }
    
    @objc private func onBuyTicketsBtnTap() {
        guard let currentNavigationController = (UIApplication.shared.delegate as? AppDelegate)?.currentNavigationController else { return }
        VipChargeTipVC.isFromVideoPlayList = false
        let vipVC = Vip2VC()
        vipVC.uiType = .ticket
        currentNavigationController.show(vipVC, sender: nil)
    }
}

extension ClassyScrollListV6ExlusiveItemCell: UITableViewDelegate, UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return listData.count + (bannerListData.isEmpty ? 0 : 1)
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return .leastNonzeroMagnitude
    }
    
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return .leastNonzeroMagnitude
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        return nil
    }
    
    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        return nil
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return channelTypeHeightList[indexPath.section]
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let section = indexPath.section
        guard !(section == 0 && !bannerListData.isEmpty) else {
            let cell = tableView.dequeueReusableCell(withIdentifier: "ClassyScrollListV6ExlusiveBannerCell", for: indexPath) as! ClassyScrollListV6ExlusiveBannerCell
            cell.bannerListData = bannerListData
            return cell
        }
        let index = section - (bannerListData.isEmpty ? 0 : 1)
        switch listData[index].type {
        case .new:
            let cell = tableView.dequeueReusableCell(withIdentifier: "ClassyScrollListV6ExlusiveNewCell\(section)", for: indexPath) as! ClassyScrollListV6ExlusiveNewCell
            cell.titleLabel.titleLabel.text = listData[index].stationName
            cell.dataModel = listData[index]
            return cell
        case .few:
            let cell = tableView.dequeueReusableCell(withIdentifier: "ClassyScrollListV6ExlusiveCommonCell\(section)", for: indexPath) as! ClassyScrollListV6ExlusiveCommonCell
            cell.titleLabel.titleLabel.text = listData[index].stationName
            cell.dataModel = listData[index]
            return cell
        }
    }
}
