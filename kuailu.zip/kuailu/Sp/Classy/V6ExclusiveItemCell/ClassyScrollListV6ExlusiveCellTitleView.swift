//
//  ClassyScrollListV6ExlusiveCellTitleView.swift
//  Sp
//
//  Created by mac on 2020/8/5.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class ClassyScrollListV6ExlusiveCellTitleView: UIView {
    
    static let viewHeight: CGFloat = 40
    
    static let newImg: UIImage? = {
        return UIImage(named: "classy_v6_new_icon")
    }()
    
    lazy var iconImgView: UIImageView = {
        return UIImageView(image: ClassyScrollListV6ExlusiveCellTitleView.newImg)
    }()

    lazy var titleLabel: UILabel = {
        let label = UILabel()
        label.textColor = .white
        label.font = UIFont.pingFangMedium(15)
        return label
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        renderView()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func renderView() {
        addSubview(titleLabel)
        addSubview(iconImgView)
        
        titleLabel.snp.makeConstraints { (make) in
            make.left.equalToSuperview().inset(12)
            make.centerY.equalToSuperview()
        }
        
        iconImgView.snp.makeConstraints { (make) in
            make.left.equalTo(titleLabel.snp.right).offset(6)
            make.centerY.equalToSuperview().offset(1)
            make.width.equalTo(30)
            make.height.equalTo(14)
        }
    }

}
