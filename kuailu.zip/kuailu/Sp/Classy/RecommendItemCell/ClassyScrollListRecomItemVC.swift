//
//  ClassyScrollListRecomItemVC.swift
//  Sp
//
//  Created by mac on 2020/11/19.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class ClassyScrollListRecomItemVC: UIViewController {
    
    private let channelTypeClassList: [AnyClass] = [ClassyScrollListRecomBannerCell.self,ClassyScrollListRecomHotspotCell.self,ClassyScrollListRecomCommunityCell.self,ClassyScrollListRecomGoddessCell.self,ClassyScrollListRecomHighlightsCell.self,ClassyScrollListRecomPhotoCell.self, ClassyScrollListRecomMoreExcitingCell.self]
    
    private let channelTypeKeyList: [String] = ["ClassyScrollListRecomBannerCell","ClassyScrollListRecomHotspotCell","ClassyScrollListRecomCommunityCell","ClassyScrollListRecomGoddessCell","ClassyScrollListRecomHighlightsCell","ClassyScrollListRecomPhotoCell", "ClassyScrollListRecomMoreExcitingCell"]
    
    static var channelTypeHeightList: [CGFloat] = [ClassyScrollListRecomBannerCell.minViewHeight, ClassyScrollListRecomHotspotCell.viewHeight, 0, 0, 0, ClassyScrollListRecomPhotoCell.viewHeight, ClassyScrollListRecomMoreExcitingCell.viewHeight]
    
    static var channelNameList: [String] = ["","\(Sensitive.cao)熱點","活動","新晉加盟女神","精彩花絮","\(Sensitive.cao)合作女神寫真","更多精彩"]
    
    private lazy var tableView: UITableView = {
        let tableView = UITableView(frame: .zero, style: .grouped)
        tableView.delegate = self
        tableView.dataSource = self
        tableView.backgroundColor = .none
        tableView.separatorStyle = .none
        tableView.bouncesZoom = false
        tableView.contentInsetAdjustmentBehavior = .never
        tableView.showsHorizontalScrollIndicator = false
        tableView.showsVerticalScrollIndicator = false
        tableView.isDirectionalLockEnabled = true
        for i in 0..<channelTypeClassList.count {
            tableView.register(channelTypeClassList[i], forCellReuseIdentifier: channelTypeKeyList[i])
        }
        return tableView
    }()
    
    private lazy var navigatorBgView: UIView = {
        let view = UIView()
        view.backgroundColor = RGB(0x2F2F2F)
        return view
    }()
    
    private lazy var emptyImg: UIImage = {
        return UIImage()
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = RGB(0x141516)
        view.addSubview(tableView)
        view.addSubview(navigatorBgView)

        tableView.snp.makeConstraints { (make) in
            make.top.left.right.equalToSuperview()
            make.bottom.equalToSuperview().inset(kBottom)
        }
        navigatorBgView.snp.makeConstraints { (make) in
            make.top.left.right.equalToSuperview()
            make.height.equalTo(kTop)
        }
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.navigationBar.isTranslucent = true
        navigationController?.navigationBar.setBackgroundImage(emptyImg, for: .default)
        navigationController?.navigationBar.shadowImage = emptyImg
    }
    
}

extension ClassyScrollListRecomItemVC: UITableViewDelegate, UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return channelTypeClassList.count
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return .leastNonzeroMagnitude
    }
    
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return .leastNonzeroMagnitude
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        return nil
    }
    
    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        return nil
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return ClassyScrollListRecomItemVC.channelTypeHeightList[indexPath.section]
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let section = indexPath.section
        let title = ClassyScrollListRecomItemVC.channelNameList[section]
        switch section {
        case 0:
            let cell = tableView.dequeueReusableCell(withIdentifier: "ClassyScrollListRecomBannerCell", for: indexPath) as! ClassyScrollListRecomBannerCell
            cell.delegate = self
            return cell
        case 1:
            let cell = tableView.dequeueReusableCell(withIdentifier: "ClassyScrollListRecomHotspotCell", for: indexPath) as! ClassyScrollListRecomHotspotCell
            cell.titleLabel.titleLabel.text = title
            return cell
        case 2:
            let cell = tableView.dequeueReusableCell(withIdentifier: "ClassyScrollListRecomCommunityCell", for: indexPath) as! ClassyScrollListRecomCommunityCell
            cell.delegate = self
            return cell
        case 3:
            let cell = tableView.dequeueReusableCell(withIdentifier: "ClassyScrollListRecomGoddessCell", for: indexPath) as! ClassyScrollListRecomGoddessCell
            cell.delegate = self
            cell.titleLabel.titleLabel.text = title
            return cell
        case 4:
            let cell = tableView.dequeueReusableCell(withIdentifier: "ClassyScrollListRecomHighlightsCell", for: indexPath) as! ClassyScrollListRecomHighlightsCell
            cell.delegate = self
            cell.titleLabel.titleLabel.text = title
            return cell
        case 5:
            let cell = tableView.dequeueReusableCell(withIdentifier: "ClassyScrollListRecomPhotoCell", for: indexPath) as! ClassyScrollListRecomPhotoCell
            cell.titleLabel.titleLabel.text = title
            return cell
        case 6:
            let cell = tableView.dequeueReusableCell(withIdentifier: "ClassyScrollListRecomMoreExcitingCell", for: indexPath) as! ClassyScrollListRecomMoreExcitingCell
            cell.delegate = self
            cell.titleLabel.titleLabel.text = title
            return cell
        default:
            return UITableViewCell()
        }
    }
    
}

extension ClassyScrollListRecomItemVC: ClassyScrollListRecomMoreExcitingCellDelegate {
    
    func refreshMoreExcitingCell() {
        ClassyScrollListRecomItemVC.channelTypeHeightList[ClassyScrollListRecomItemVC.channelTypeHeightList.count - 1] = ClassyScrollListRecomMoreExcitingCell.viewHeight
        tableView.reloadData()
    }
    
}


extension ClassyScrollListRecomItemVC: ClassyScrollListRecomItemCellDelegate {
    
    func refreshTableView() {
        tableView.reloadData()
    }
    
}
