//
//  ClassyScrollListRecommendCell.swift
//  Sp
//
//  Created by mac on 2020/5/4.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

protocol ClassyScrollListRecomItemCellDelegate: NSObjectProtocol {
    
    func refreshTableView()
    
}

class ClassyScrollListRecomItemCell: UICollectionViewCell {
    
    private let channelTypeClassList: [AnyClass] = [ClassyScrollListRecomBannerCell.self,ClassyScrollListRecomHotspotCell.self,ClassyScrollListRecomCommunityCell.self,ClassyScrollListRecomGoddessCell.self,ClassyScrollListRecomHighlightsCell.self,ClassyScrollListRecomPhotoCell.self, ClassyScrollListRecomMoreExcitingCell.self]
    
    private let channelTypeKeyList: [String] = ["ClassyScrollListRecomBannerCell","ClassyScrollListRecomHotspotCell","ClassyScrollListRecomCommunityCell","ClassyScrollListRecomGoddessCell","ClassyScrollListRecomHighlightsCell","ClassyScrollListRecomPhotoCell", "ClassyScrollListRecomMoreExcitingCell"]
    
    static var channelTypeHeightList: [CGFloat] = [ClassyScrollListRecomBannerCell.viewHeight, ClassyScrollListRecomHotspotCell.viewHeight, 0, 0, 0, ClassyScrollListRecomPhotoCell.viewHeight, ClassyScrollListRecomMoreExcitingCell.viewHeight]
    
    static var channelNameList: [String] = ["","\(Sensitive.cao)熱點","活動","新晉加盟女神","精彩花絮","\(Sensitive.cao)合作女神寫真","更多精彩"]
    
    private lazy var tableView: UITableView = {
        let tableView = UITableView(frame: .zero, style: .grouped)
        tableView.delegate = self
        tableView.dataSource = self
        tableView.backgroundColor = .none
        tableView.separatorStyle = .none
        tableView.bouncesZoom = false
        tableView.isDirectionalLockEnabled = true
        for i in 0..<channelTypeClassList.count {
            tableView.register(channelTypeClassList[i], forCellReuseIdentifier: channelTypeKeyList[i])
        }
        return tableView
    }()
    
    private lazy var navigatorBgImgView: UIImageView = {
        let imgView = UIImageView()
        imgView.backgroundColor = RGB(0x2F2F2F)
        imgView.alpha = 0
        return imgView
    }()
    
    private let positiveThreshold: CGFloat = ClassyScrollListRecomBannerCell.bannerHeight - kTop
    
    private let negativeThreshold: CGFloat = kTop
    
    private var isInitState: Bool = true
    
    var classifyId: String? {
        didSet {
            guard isInitState else { return }
            isInitState = false
        }
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        addSubview(tableView)
        addSubview(navigatorBgImgView)
        
        tableView.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
        navigatorBgImgView.snp.makeConstraints { (make) in
            make.top.left.right.equalToSuperview()
            make.height.equalTo(kTop)
        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}

extension ClassyScrollListRecomItemCell: UITableViewDelegate, UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return channelTypeClassList.count
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return .leastNonzeroMagnitude
    }
    
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return .leastNonzeroMagnitude
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        return nil
    }
    
    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        return nil
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return ClassyScrollListRecomItemCell.channelTypeHeightList[indexPath.section]
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let section = indexPath.section
        let title = ClassyScrollListRecomItemCell.channelNameList[section]
        switch section {
        case 0:
            let cell = tableView.dequeueReusableCell(withIdentifier: "ClassyScrollListRecomBannerCell", for: indexPath) as! ClassyScrollListRecomBannerCell
            return cell
        case 1:
            let cell = tableView.dequeueReusableCell(withIdentifier: "ClassyScrollListRecomHotspotCell", for: indexPath) as! ClassyScrollListRecomHotspotCell
            cell.titleLabel.titleLabel.text = title
            return cell
        case 2:
            let cell = tableView.dequeueReusableCell(withIdentifier: "ClassyScrollListRecomCommunityCell", for: indexPath) as! ClassyScrollListRecomCommunityCell
            cell.delegate = self
            return cell
        case 3:
            let cell = tableView.dequeueReusableCell(withIdentifier: "ClassyScrollListRecomGoddessCell", for: indexPath) as! ClassyScrollListRecomGoddessCell
            cell.delegate = self
            cell.titleLabel.titleLabel.text = title
            return cell
        case 4:
            let cell = tableView.dequeueReusableCell(withIdentifier: "ClassyScrollListRecomHighlightsCell", for: indexPath) as! ClassyScrollListRecomHighlightsCell
            cell.delegate = self
            cell.titleLabel.titleLabel.text = title
            return cell
        case 5:
            let cell = tableView.dequeueReusableCell(withIdentifier: "ClassyScrollListRecomPhotoCell", for: indexPath) as! ClassyScrollListRecomPhotoCell
            cell.titleLabel.titleLabel.text = title
            return cell
        case 6:
            let cell = tableView.dequeueReusableCell(withIdentifier: "ClassyScrollListRecomMoreExcitingCell", for: indexPath) as! ClassyScrollListRecomMoreExcitingCell
            cell.delegate = self
            cell.titleLabel.titleLabel.text = title
            return cell
        default:
            return UITableViewCell()
        }
    }
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        guard scrollView == tableView else { return }
        let offsetY = scrollView.contentOffset.y
        let threshold = offsetY > 0 ? positiveThreshold : negativeThreshold
        navigatorBgImgView.alpha = abs(offsetY > threshold ? 1 : offsetY / threshold)
    }
    
}

extension ClassyScrollListRecomItemCell: ClassyScrollListRecomMoreExcitingCellDelegate {
    
    func refreshMoreExcitingCell() {
        ClassyScrollListRecomItemCell.channelTypeHeightList[ClassyScrollListRecomItemCell.channelTypeHeightList.count - 1] = ClassyScrollListRecomMoreExcitingCell.viewHeight
        tableView.reloadData()
    }
    
}


extension ClassyScrollListRecomItemCell: ClassyScrollListRecomItemCellDelegate {
    
    func refreshTableView() {
        tableView.reloadData()
    }
    
}
