//
//  ClassyScrollListRecomCellTitleView.swift
//  Sp
//
//  Created by mac on 2020/8/4.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class ClassyScrollListRecomCellTitleView: UIView {
    
    static let viewHeight: CGFloat = 20
    
    lazy var iconImgView: UIImageView = {
        return UIImageView()
    }()

    lazy var titleLabel: UILabel = {
        let label = UILabel()
        label.textColor = .white
        label.font = UIFont.pingFangMedium(15)
        return label
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        renderView()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func renderView() {
        addSubview(iconImgView)
        addSubview(titleLabel)
        
        iconImgView.snp.makeConstraints { (make) in
            make.left.equalToSuperview().inset(12)
            make.centerY.equalToSuperview()
            make.size.equalTo(18)
        }
        
        titleLabel.snp.makeConstraints { (make) in
            make.left.equalTo(iconImgView.snp.right).offset(5)
        }
    }

}
