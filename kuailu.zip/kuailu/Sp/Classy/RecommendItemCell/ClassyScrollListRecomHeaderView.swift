//
//  ClassyScrollListRecomheaderView.swift
//  Sp
//
//  Created by mac on 2020/5/4.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit


class ClassyScrollListRecomHeaderView: UICollectionReusableView {
    
    static let leaderboardRatio: CGFloat = UIScreen.main.bounds.width / 360
    
    var bannerListData: [AdvertiseResp] = [] {
        didSet {
            cycleScrollView.itemSize = bannerListData.isEmpty ? .zero : CGSize(width: itemWidth, height: itemHeight)
            cycleScrollView.reloadData()
        }
    }
    
    private let btnMargin: CGFloat = (UIScreen.main.bounds.width - 104 * 3) / 4
    
    private let itemWidth: CGFloat = UIScreen.main.bounds.width - 12 * 2
    
    private let itemHeight: CGFloat = 108 * ClassyScrollListRecomHeaderView.leaderboardRatio
    
    private lazy var cycleScrollView: CycleScrollView = {
        let cycleScrollView = CycleScrollView()
        cycleScrollView.delegate = self
        cycleScrollView.dataSource = self
        cycleScrollView.register(ClassyCycleScrollViewCell.self, forCellWithReuseIdentifier: "ClassyCycleScrollViewCell")
        cycleScrollView.layer.cornerRadius = 4
        cycleScrollView.layer.masksToBounds = true
        return cycleScrollView
    }()
    
    private lazy var likeImgViewBtn: UIButton = {
        let btn = UIButton()
        btn.setBackgroundImage(UIImage.decrypt("classy_recommend_like_btn.png.enc"), for: .normal)
        btn.addTarget(self, action: #selector(onLikeTap), for: .touchUpInside)
        return btn
    }()
    
    private lazy var coinImgViewBtn: UIButton = {
        let btn = UIButton()
        btn.setBackgroundImage(UIImage.decrypt("classy_recommend_coin_btn.png.enc"), for: .normal)
        btn.addTarget(self, action: #selector(onCoinTap), for: .touchUpInside)
        return btn
    }()
    
    private lazy var popularityImgViewBtn: UIButton = {
        let btn = UIButton()
        btn.setBackgroundImage(UIImage.decrypt("classy_recommend_popularity_btn.png.enc"), for: .normal)
        btn.addTarget(self, action: #selector(onPopularityTap), for: .touchUpInside)
        return btn
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        addSubview(cycleScrollView)
        addSubview(coinImgViewBtn)
        addSubview(likeImgViewBtn)
        addSubview(popularityImgViewBtn)
        cycleScrollView.snp.makeConstraints { (make) in
            make.top.equalToSuperview()
            make.left.right.equalToSuperview().inset(12)
            make.height.equalTo(itemHeight)
        }
        
        coinImgViewBtn.snp.makeConstraints { (make) in
            make.bottom.equalToSuperview().inset(10)
            make.centerX.equalToSuperview()
            make.width.equalTo(104)
            make.height.equalTo(38)
        }
        
        likeImgViewBtn.snp.makeConstraints { (make) in
            make.bottom.equalTo(coinImgViewBtn)
            make.right.equalTo(coinImgViewBtn.snp.left).offset(-btnMargin)
            make.size.equalTo(coinImgViewBtn)
        }
        
        popularityImgViewBtn.snp.makeConstraints { (make) in
            make.bottom.equalTo(coinImgViewBtn)
            make.left.equalTo(coinImgViewBtn.snp.right).offset(btnMargin)
            make.size.equalTo(likeImgViewBtn)
        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    @objc func onLikeTap() {
        jumpToLeaderboardPage(leaderboardType: .like)
    }
    
    @objc func onCoinTap() {
        jumpToLeaderboardPage(leaderboardType: .coin)
    }
    
    @objc func onPopularityTap() {
        jumpToLeaderboardPage(leaderboardType: .popularity)
    }
    
    private func jumpToLeaderboardPage(leaderboardType: LeaderboardType) {
        guard let vc = (UIApplication.shared.delegate as? AppDelegate)?.currentNavigationController else { return }
        LeaderboardVC.leaderboardType = leaderboardType
        let leaderboardVC = LeaderboardVC()
        vc.pushViewController(leaderboardVC, animated: true)
    }
}

extension ClassyScrollListRecomHeaderView: CycleScrollViewDataSource {
    
    func numberOfItems(in cycleScrollView: CycleScrollView) -> Int {
        return bannerListData.count
    }
    
    func cycleScrollView(_ cycleScrollView: CycleScrollView, cellForItemAt index: Int) -> UICollectionViewCell {
        let cell = cycleScrollView.dequeueReusableCell(withReuseIdentifier: "ClassyCycleScrollViewCell", for: index) as! ClassyCycleScrollViewCell
        cell.bannerImgUrl = bannerListData[index].adImage
        return cell
    }
}

extension ClassyScrollListRecomHeaderView: CycleScrollViewDelegate {
    
    func cycleScrollView(_ cycleScrollView: CycleScrollView, didSelectItemAt index: Int) {
        guard index < bannerListData.count else { return }
        let currentItem = bannerListData[index]
        guard let url = currentItem.adJump else { return }
        InnerIntercept.open(url)
    }
    
}
