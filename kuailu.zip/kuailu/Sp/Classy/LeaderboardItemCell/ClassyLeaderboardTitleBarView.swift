//
//  ClassyLeaderboardTitleBarView.swift
//  Sp
//
//  Created by mac on 2020/9/11.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

protocol ClassyLeaderboardTitleBarViewDelegate: NSObjectProtocol {
    
    func switchLeaderboardCycleType(leaderboardCycleType: LeaderboardCycleType)
    
}

class ClassyLeaderboardTitleBarView: UIView {
    
    static let viewHeight: CGFloat = 30
    
    weak var delegate: ClassyLeaderboardTitleBarViewDelegate?
    
    private lazy var indicatorView: UIView = {
        let view = UIView()
        view.backgroundColor = .white
        view.layer.masksToBounds = true
        view.layer.cornerRadius = 11
        return view
    }()
    
    private lazy var weekBtn: UIButton = {
        let btn = UIButton()
        btn.setTitle("周榜", for: .normal)
        btn.titleLabel?.font = UIFont.pingFangMedium(16)
        btn.setTitleColor(RGB(0xFA6400), for: .normal)
        btn.addTarget(self, action: #selector(onWeekBtnTap), for: .touchUpInside)
        return btn
    }()
    
    private lazy var monthBtn: UIButton = {
        let btn = UIButton()
        btn.setTitle("月榜", for: .normal)
        btn.titleLabel?.font = UIFont.pingFangRegular(16)
        btn.setTitleColor(RGB(0xC9C9C9), for: .normal)
        btn.addTarget(self, action: #selector(onMonthBtnTap), for: .touchUpInside)
        return btn
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = RGB(0x141516)
        renderView()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    @objc private func renderView() {
        addSubview(indicatorView)
        addSubview(weekBtn)
        addSubview(monthBtn)
        
        indicatorView.snp.makeConstraints { (make) in
            make.centerY.equalToSuperview()
            make.centerX.equalToSuperview().offset(-22 - 17)
            make.width.equalTo(48)
            make.height.equalTo(22)
        }
        
        weekBtn.snp.makeConstraints { (make) in
            make.top.centerY.bottom.equalToSuperview()
            make.width.equalTo(34)
            make.centerX.equalToSuperview().offset(-22 - 17)
        }
        
        monthBtn.snp.makeConstraints { (make) in
            make.top.centerY.bottom.equalToSuperview()
            make.width.equalTo(34)
            make.centerX.equalToSuperview().offset(22 + 17)
        }
    }
    
    @objc private func onWeekBtnTap() {
        delegate?.switchLeaderboardCycleType(leaderboardCycleType: .week)
        switchBtnStatus(isWeek: true)
        switchIndicatorLayout(isWeek: true)
    }
    
    @objc private func onMonthBtnTap() {
        delegate?.switchLeaderboardCycleType(leaderboardCycleType: .month)
        switchBtnStatus(isWeek: false)
        switchIndicatorLayout(isWeek: false)
    }
    
    private func switchIndicatorLayout(isWeek: Bool) {
        indicatorView.snp.updateConstraints { (make) in
            make.centerX.equalToSuperview().offset(isWeek ?  -22 - 17 : 22 + 17)
        }
        updateLayoutConstraints()
        UIView.animate(withDuration: 0.3) { [weak self] in
            self?.layoutIfNeeded()
        }
    }
    
    private func switchBtnStatus(isWeek: Bool){
        weekBtn.titleLabel?.font = isWeek ? UIFont.pingFangMedium(16) : UIFont.pingFangRegular(16)
        weekBtn.setTitleColor(isWeek ? RGB(0xFA6400) : RGB(0xC9C9C9), for: .normal)
        monthBtn.titleLabel?.font = isWeek ? UIFont.pingFangRegular(16) : UIFont.pingFangMedium(16)
        monthBtn.setTitleColor(isWeek ? RGB(0xC9C9C9) : RGB(0xFA6400), for: .normal)
    }
    
    private func updateLayoutConstraints() {
        updateConstraintsIfNeeded()
        updateFocusIfNeeded()
    }
}
