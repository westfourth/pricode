//
//  ClassyLeaderboardItemCell.swift
//  Sp
//
//  Created by mac on 2020/9/11.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

enum LeaderboardType: Int {
    case coin = 0
    case popularity = 1
    case like = 2
}

enum LeaderboardCycleType: Int {
    case week = 0
    case month = 1
}

class ClassyLeaderboardItemCell: UICollectionViewCell {
    
    static let animationOption: KingfisherOptionsInfo = {
        return [.transition(.fade(0.25))]
    }()
    
    private static let cellTypeArr: [UITableViewCell.Type] = [LeaderboardScrollCoinCell.self, LeaderboardScrollPopularityCell.self, LeaderboardScrollLikeCell.self]
    
    private static let cellTypeStrArr: [String] = ["LeaderboardScrollCoinCell","LeaderboardScrollPopularityCell", "LeaderboardScrollLikeCell",]
    
    private static let paddingTop: CGFloat = 16
    
    private lazy var headerView: ClassyLeaderboardHeaderView = {
        let headerView = ClassyLeaderboardHeaderView()
        headerView.delegate = self
        return headerView
    }()
    
    private lazy var titleBarView: ClassyLeaderboardTitleBarView = {
        let view = ClassyLeaderboardTitleBarView()
        view.delegate = self
        view.isHidden = true
        return view
    }()
    
    private lazy var tableView: UITableView = {
        let tableView = UITableView(frame: CGRect.zero, style: .grouped)
        tableView.delegate = self
        tableView.dataSource = self
        tableView.backgroundColor = .none
        tableView.separatorStyle = .none
        tableView.showsVerticalScrollIndicator = false
        tableView.showsHorizontalScrollIndicator = false
        for i in 0..<ClassyLeaderboardItemCell.cellTypeArr.count {
            tableView.register(ClassyLeaderboardItemCell.cellTypeArr[i], forCellReuseIdentifier: ClassyLeaderboardItemCell.cellTypeStrArr[i])
        }
        tableView.mj_header = getCommonMJHeader(refreshingTarget: self, headerRefreshCallback: #selector(onRefresh))
        return tableView
    }()
    
    private let titleBarMarginTop: CGFloat = kTop
    
    private var leaderboardCycleType: LeaderboardCycleType = .week
    
    private var leaderboardType: LeaderboardType = .coin
    
    private var listData: [BoardItem] = []
    
    private var videoData: [VideoItem] = []
    
    private var headerViewHeight: CGFloat = ClassyLeaderboardHeaderView.minViewHeight + ClassyLeaderboardItemCell.paddingTop
    
    private var isInitState: Bool = true
    
    private var titleBarOffsetY: CGFloat = ClassyLeaderboardHeaderView.minViewHeight - ClassyLeaderboardTitleBarView.viewHeight
    
    var classifyId: String? {
        didSet {
            guard isInitState else { return }
            isInitState = false
            getBannerList()
            Alert.showLoading(parentView: self)
            getList()
        }
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        addSubview(tableView)
        tableView.snp.makeConstraints { (make) in
            make.top.equalToSuperview().inset(kTop)
            make.left.right.bottom.equalToSuperview()
        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func getBannerList() {
//        guard let id = classifyId, let listData = AdManager.shared.classyItems(id), !listData.isEmpty else {
//            headerView.bannerListData = []
//            titleBarView.frame = CGRect(x: 0, y: titleBarMarginTop + titleBarOffsetY, width: UIScreen.main.bounds.width, height: ClassyLeaderboardTitleBarView.viewHeight)
//            addSubview(titleBarView)
//            titleBarView.isHidden = false
//            return
//        }
//        headerView.bannerListData = listData
//        headerViewHeight = ClassyLeaderboardHeaderView.maxViewHeight + ClassyLeaderboardItemCell.paddingTop
//        tableView.register(ClassyScrollListV6ExlusiveBannerCell.self, forCellReuseIdentifier: "ClassyScrollListV6ExlusiveBannerCell")
//        titleBarOffsetY = ClassyLeaderboardHeaderView.maxViewHeight - ClassyLeaderboardTitleBarView.viewHeight
//        titleBarView.frame = CGRect(x: 0, y: titleBarMarginTop + titleBarOffsetY, width: UIScreen.main.bounds.width, height: ClassyLeaderboardTitleBarView.viewHeight)
//        addSubview(titleBarView)
//        titleBarView.isHidden = false
    }
    
    private func getList() {
        let leaderboardType = self.leaderboardType
        var likeReq: LikeBoardReq?
        var coinReq: GoldBoardReq?
        var popularityReq: HotBoardReq?
        let type = leaderboardCycleType == .week ? 1 : 2
        switch leaderboardType {
        case .like:
            likeReq = LikeBoardReq()
            likeReq!.type = type
        case .coin:
            coinReq = GoldBoardReq()
            coinReq!.type = type
        default:
            popularityReq = HotBoardReq()
            popularityReq!.type = type
        }
        let tableView = self.tableView
        Session.request(leaderboardType == .like ? likeReq! : leaderboardType == .coin ? coinReq! : popularityReq!) { [weak self] (error, resp) in
            tableView.mj_header?.endRefreshing()
            Alert.hideLoading()
            guard let `self` = self else { return }
            guard error == nil, let resData = resp as? BoardTotalResp else {
                self.listData = []
                self.videoData = []
                tableView.reloadData()
                return
            }
            self.listData = resData.data
            if self.leaderboardType != .popularity  {
                self.getVideoList()
            }
            tableView.reloadData()
            
        }
    }
    
    private func getCurrentCell(tableView: UITableView, indexPath: IndexPath) -> UITableViewCell? {
        switch leaderboardType {
        case .like:
            return tableView.dequeueReusableCell(withIdentifier: ClassyLeaderboardItemCell.cellTypeStrArr[leaderboardType.rawValue], for: indexPath) as? LeaderboardScrollLikeCell
        case .coin:
            return tableView.dequeueReusableCell(withIdentifier: ClassyLeaderboardItemCell.cellTypeStrArr[leaderboardType.rawValue], for: indexPath) as? LeaderboardScrollCoinCell
        case .popularity:
            return tableView.dequeueReusableCell(withIdentifier: ClassyLeaderboardItemCell.cellTypeStrArr[leaderboardType.rawValue], for: indexPath) as? LeaderboardScrollPopularityCell
        }
    }
    
    private func getVideoList() {
        let req = FetchVideoByIdsReq()
        let videoIds = listData.map{ $0.videoId }
        req.videoIds = videoIds
        guard !req.videoIds.isEmpty else { return }
        Session.request(req) { (error, resp) in
            guard error == nil, let items = resp as? [VideoItem] else { return }
            self.videoData = []
            let count = items.count
            for i in 0..<videoIds.count {
                self.videoData.append(i < count ? items[i] : VideoItem())
            }
        }
    }
    
    @objc private func onRefresh() {
        getList()
    }
}

extension ClassyLeaderboardItemCell: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return listData.count
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return headerViewHeight
    }
    
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return .leastNonzeroMagnitude
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        return headerView
    }
    
    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        return nil
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return leaderboardType == .popularity ? LeaderboardScrollPopularityCell.viewHeight : LeaderboardScrollCoinCell.viewHeight
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let rawCell = getCurrentCell(tableView: tableView, indexPath: indexPath)
        let row = indexPath.row
        let currentItem = listData[row]
        if let cell = rawCell as? LeaderboardScrollLikeCell {
            cell.currentIndex = row
            cell.dataModel = currentItem
            return cell
        }
        if let cell = rawCell as? LeaderboardScrollCoinCell  {
            cell.currentIndex = row
            cell.dataModel = currentItem
            return cell
        }
        if let cell = rawCell as? LeaderboardScrollPopularityCell {
            cell.delegate = self
            cell.levelLabel.text = "\(row + 1)"
            cell.levelLabel.textColor = row == 0 ? RGB(0xFF1D10) : row == 1 ? RGB(0xFF9842) : row == 2 ? RGB(0xFFAB2F) : .white
            cell.levelLabel.font = UIFont.pingFangRegular(row > 2 ? 24 : 32)
            cell.isFocus = currentItem.isAttention
            cell.dataModel = currentItem
            return cell
        }
        return UITableViewCell()
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        guard let vc = (UIApplication.shared.delegate as? AppDelegate)?.currentNavigationController else { return }
        let row = indexPath.row
        let currentItem = listData[row]
        switch leaderboardType {
        case .like, .coin:
            guard !videoData.isEmpty else {
                getVideoList()
                return
            }
            SearchResultVC.navigationToVideoPlayListVC(indexPath: indexPath, VideoList: videoData)
        case .popularity:
            let userId = currentItem.userId
            guard userId != SearchResultFocusCell.userId else { return }
            let usersDynamicVC = UsersDynamicVC()
            usersDynamicVC.userId = userId
            usersDynamicVC.initPageType = .smallVideo
            usersDynamicVC.attentionClosure = { [weak self] (isAttention: Bool) in
                guard let `self` = self else { return }
                self.listData[row].isAttention = isAttention
                self.tableView.reloadData()
                usersDynamicVC.attentionClosure = nil
            }
            vc.show(usersDynamicVC, sender: nil)
        }
    }
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        guard scrollView == tableView else { return }
        titleBarView.frame.origin.y = (scrollView.contentOffset.y < titleBarOffsetY ? titleBarOffsetY - scrollView.contentOffset.y : 0) + titleBarMarginTop
    }
}

extension ClassyLeaderboardItemCell: ClassyLeaderboardHeaderViewDelegate {
    
    func switchLeaderboardType(leaderboardType: LeaderboardType) {
        guard leaderboardType != self.leaderboardType else { return }
        self.leaderboardType = leaderboardType
        Alert.showLoading(parentView: self)
        getList()
    }
    
}

extension ClassyLeaderboardItemCell: ClassyLeaderboardTitleBarViewDelegate {
    
    func switchLeaderboardCycleType(leaderboardCycleType: LeaderboardCycleType) {
        guard leaderboardCycleType != self.leaderboardCycleType else { return }
        self.leaderboardCycleType = leaderboardCycleType
        Alert.showLoading(parentView: self)
        getList()
    }
    
}

extension ClassyLeaderboardItemCell: LeaderboardScrollPopularityCellDelegate {
    
    func switchFocusStatus(dataModel: BoardItem, cell: LeaderboardScrollPopularityCell) {
        guard dataModel.isAttention else {
            Alert.showLoading(parentView: self)
            let req = FocusUserReq()
            req.beenUserId = dataModel.userId
            Session.request(req) { (error, resp) in
                Alert.hideLoading()
                guard error == nil else {
                    mm_showToast(error!.localizedDescription)
                    return
                }
                dataModel.isAttention = true
                cell.isFocus = true
                mm_showToast("關注成功!", type: .succeed)
            }
            return
        }
        Alert.showCommonAlert(parentView: self, contentText: "取消關注後,您將無法及時收到他的動態",
                              cancelText: "再看看",
                              confirmText: "取消關注",
                              onConfirmTap: {
                                Alert.showLoading(parentView: self)
                                let req = CancelFocusUserReq()
                                req.beenUserId = dataModel.userId
                                Session.request(req) { (error, resp) in
                                    Alert.hideLoading()
                                    guard error == nil else {
                                        mm_showToast(error!.localizedDescription)
                                        return
                                    }
                                    dataModel.isAttention = false
                                    cell.isFocus = false
                                    mm_showToast("取消成功!", type: .succeed)
                                }
        }, onCancelTap: nil)
    }
}
