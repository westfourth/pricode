//
//  ClassyVC.swift
//  Sp
//
//  Created by mac on 2020/2/17.
//  Copyright © 2020 mac. All rights reserved.
//

extension Notification.Name {
    /// 获取或刷新V6专区列表通知
    static let GetV6ExlusiveListDataName = Notification.Name(rawValue:"GetV6ExlusiveListDataName")
}

class ClassyVC: UIViewController {
    
    private let screenWidth: CGFloat = UIScreen.main.bounds.width
    
    private let categoryBarHeight: CGFloat = 48
    
    private let categoryBarIndicatorWidth: CGFloat = 40
    
    private let categoryBarIndicatorHeight: CGFloat = 2
    
    private let lineGradientMaskViewWidth: CGFloat = 26
    
    private let classyScrollListItemSize: CGSize = CGSize(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height - kBottom)
    
    private lazy var categoryBarIndicator: UIView = {
        let view = UIView()
        view.backgroundColor = .white
        view.layer.masksToBounds = true
        view.layer.cornerRadius = categoryBarIndicatorHeight / 2
        return view
    }()
    
    private lazy var categoryBarCollectionView: UICollectionView = {
        let layout = UICollectionViewFlowLayout()
        layout.minimumLineSpacing = 0
        layout.minimumInteritemSpacing = 24
        layout.scrollDirection = .horizontal
        let cv = UICollectionView(frame: .zero, collectionViewLayout: layout)
        cv.register(ClassyCategoryCell.self, forCellWithReuseIdentifier: "ClassyCategoryCell")
        cv.contentInset = UIEdgeInsets(top: 0, left: 12, bottom: 0, right: 12)
        cv.showsVerticalScrollIndicator = false
        cv.showsHorizontalScrollIndicator = false
        cv.bouncesZoom = false
        cv.backgroundColor = .none
        cv.delegate = self
        cv.dataSource = self
        return cv
    }()
    
    private lazy var scrollListCollectionView: UICollectionView = {
        let layout = UICollectionViewFlowLayout()
        layout.itemSize = classyScrollListItemSize
        layout.minimumLineSpacing = 0
        layout.minimumInteritemSpacing = 0
        layout.scrollDirection = .horizontal
        layout.sectionInset = UIEdgeInsets(top: kTop - kBottom, left: 0, bottom: 0, right: 0)
        let cv = UICollectionView(frame: .zero, collectionViewLayout: layout)
        cv.showsVerticalScrollIndicator = false
        cv.showsHorizontalScrollIndicator = false
        cv.bouncesZoom = false
        cv.isPagingEnabled = true
        cv.backgroundColor = .none
        cv.delegate = self
        cv.dataSource = self
        return cv
    }()
    
    private lazy var maskView: UIView = {
        let view = UIView()
        let tap = UITapGestureRecognizer(target: self, action:#selector(onSearchIconBtnTap))
        view.addGestureRecognizer(tap)
        return view
    }()
    
    private lazy var searchIconBtn: UIButton = {
        let btn = UIButton()
        btn.setBackgroundImage(UIImage(named: "search_icon_white"), for: .normal)
        btn.addTarget(self, action: #selector(onSearchIconBtnTap), for: .touchUpInside)
        return btn
    }()
    
    private lazy var navigatorBar: UIView = {
        let view = UIView()
        view.addSubview(categoryBarCollectionView)
        view.addSubview(maskView)
        view.addSubview(searchIconBtn)
        categoryBarCollectionView.snp.makeConstraints { (make) in
            make.centerY.left.equalToSuperview()
            make.right.equalToSuperview().inset(lineGradientMaskViewWidth)
            make.height.equalTo(categoryBarHeight)
        }
        
        maskView.snp.makeConstraints { (make) in
            make.top.right.bottom.equalToSuperview()
            make.width.equalTo(lineGradientMaskViewWidth)
        }
        
        searchIconBtn.snp.makeConstraints { (make) in
            make.right.equalToSuperview()
            make.bottom.equalToSuperview().inset(12)
            make.size.equalTo(15)
        }
        
        return view
    }()
    
    private lazy var emptyImg: UIImage = {
        return UIImage()
    }()
    
    private lazy var V6ExlusiveBgImgView: UIImageView = {
        let imgView =  UIImageView(image: UIImage.decrypt("classy_V6_exlusive_bg.jpg.enc"))
        imgView.contentMode = .scaleAspectFill
        imgView.alpha = 0
        return imgView
    }()
    
    private var activeIndex: Int = 0
    
    private var initCategoryType: AppMenuType = .recommend
    
    private var categoryList: [AppMenuItem] = [] {
        didSet {
            categoryBarCollectionView.reloadData()
            scrollListCollectionView.reloadData()
        }
    }
    
    private var categoryBarItemCenterXList: [CGFloat] = []
    
    private var V6ExlusiveConvertToPlainIndexArr: [Int] = []
    
    private var categoryTitleSizeList: [CGSize] = []
    
    private var categoryTitleList: [String] = []
    
    private var isTapCategoryItem: Bool = false
    
    private var isGetCategoryList: Bool = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationController?.navigationBar.isTranslucent = true
        navigationItem.leftBarButtonItem = UIBarButtonItem(customView: navigatorBar)
        view.backgroundColor = RGB(0x141516)
        if #available(iOS 11.0, *) {
            categoryBarCollectionView.contentInsetAdjustmentBehavior = .never
            scrollListCollectionView.contentInsetAdjustmentBehavior = .never
        } else {
            automaticallyAdjustsScrollViewInsets = false
        }
        navigatorBar.snp.makeConstraints { (make) in
            make.width.equalTo(screenWidth - (screenWidth > 375 ? 20 : 16) * 2 + 1)
            make.height.equalTo(categoryBarHeight)
        }
        renderView()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.navigationBar.isTranslucent = true
        navigationController?.navigationBar.setBackgroundImage(emptyImg, for: .default)
        navigationController?.navigationBar.shadowImage = emptyImg
        if !isGetCategoryList, categoryList.isEmpty { getCategoryList() }
        getUserinfo()
        getAccountInfo()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        guard activeIndex < categoryList.count, categoryList[activeIndex].type == .v6, !V6ExlusiveConvertToPlainIndexArr.contains(activeIndex) else { return }
        NotificationCenter.default.post(name: .GetV6ExlusiveListDataName, object: nil)
    }
    
    private func renderView() {
        view.addSubview(V6ExlusiveBgImgView)
        view.addSubview(scrollListCollectionView)
        
        V6ExlusiveBgImgView.snp.makeConstraints { (make) in
            make.top.equalToSuperview().offset(-kTop)
            make.left.right.equalToSuperview()
            make.bottom.equalToSuperview().inset(kBottom)
        }
        
        scrollListCollectionView.snp.makeConstraints { (make) in
            make.top.equalToSuperview().offset(-kTop)
            make.left.right.bottom.equalToSuperview()
        }
    }
    
    private func getCategoryList() {
        isGetCategoryList = true
        Session.request(AppMenuListReq()) { [weak self] (error, resp) in
            guard let `self` = self else { return }
            guard error == nil, let resData = resp as? [AppMenuItem], !resData.isEmpty else {
                self.isGetCategoryList = false
                return
            }
            let font = UIFont.pingFangMedium(18)
            let v6Size = CGSize(width: 30, height: 40)
            for i in 0..<resData.count {
                let type = resData[i].type
                if self.initCategoryType == type, self.activeIndex != i {
                    self.activeIndex = i
                }
                switch type {
                case .welfare:
                    self.scrollListCollectionView.register(ClassyScrollListWelfareItemCell.self, forCellWithReuseIdentifier: "ClassyScrollListWelfareItemCell\(i)")
                case .recommend:
                    self.scrollListCollectionView.register(ClassyScrollListRecomItemCell.self, forCellWithReuseIdentifier: "ClassyScrollListRecomItemCell\(i)")
                case .v6:
                    self.scrollListCollectionView.register(ClassyScrollListV6ExlusiveItemCell.self, forCellWithReuseIdentifier: "ClassyScrollListV6ExlusiveItemCell\(i)")
                case .leapboardActivity:
                    self.scrollListCollectionView.register(ClassyActivityItemCell.self, forCellWithReuseIdentifier: "ClassyActivityItemCell\(i)")
                case .h5:
                    self.scrollListCollectionView.register(ClassyWebViewItemCell.self, forCellWithReuseIdentifier: "ClassyWebViewItemCell\(i)")
                case .leapboard:
                    self.scrollListCollectionView.register(ClassyLeaderboardItemCell.self, forCellWithReuseIdentifier: "ClassyLeaderboardItemCell\(i)")
                }
                let isV6 = type == .v6
                self.categoryTitleSizeList.append(!isV6 ? CGSize(width: resData[i].title.getStringSize(rectSize: .zero, font: font).width, height: 40) : v6Size)
            }
            self.categoryList += resData
            guard !self.categoryTitleSizeList.isEmpty else { return }
            self.categoryBarIndicator.frame = CGRect(x: (self.categoryTitleSizeList[0].width - self.categoryBarIndicatorWidth) / 2, y: self.categoryBarHeight - self.categoryBarIndicatorHeight - 6, width:  self.categoryBarIndicatorWidth, height: self.categoryBarIndicatorHeight)
            self.categoryBarCollectionView.addSubview(self.categoryBarIndicator)
            self.scrollListCollectionView.scrollToItem(at: IndexPath(row: self.activeIndex, section: 0), at: .centeredHorizontally, animated: true)
            self.isGetCategoryList = false
        }
    }
    
    private func getUserinfo() {
        Session.request(FetchUserInfoReq()) { (error, resp) in }
    }
    
    private func getAccountInfo() {
        Session.request(UserAccountInfoReq()) { (error, resp) in
            guard error == nil, let resData = resp as? UserAccountInfo else { return }
            WalletVC.balanceVal = resData.bala
            WalletVC.coinVal = resData.gold
            WalletVC.exchangeVal = resData.welfareNum
        }
    }
    
    @objc private func onSearchIconBtnTap() {
        navigationController?.show(SearchVC(), sender: nil)
    }
    
    private func refreshCategoryBarCollectionView(activeIndex: Int) {
        categoryBarCollectionView.scrollToItem(at: IndexPath(row: activeIndex, section: 0), at: .centeredHorizontally, animated: true)
        UIView.animate(withDuration: 0.15, delay: 0, options: .curveEaseIn, animations: {[weak self] in
            guard let `self` = self else { return }
            let isExlusive = self.categoryList[activeIndex].type == .v6 && !self.V6ExlusiveConvertToPlainIndexArr.contains(activeIndex)
            self.V6ExlusiveBgImgView.alpha = isExlusive ? 1 : 0
            guard let cell = self.categoryBarCollectionView.dequeueReusableCell(withReuseIdentifier: "ClassyCategoryCell", for: IndexPath(row: activeIndex, section: 0)) as? ClassyCategoryCell else {
                return
            }
            self.categoryBarIndicator.center.x = cell.centerX
        }) { [weak self] _ in
            self?.categoryBarCollectionView.reloadData()
            self?.isTapCategoryItem = false
        }
    }
    
    func switchToCategoryBar(type: AppMenuType) {
        guard !categoryList.isEmpty else {
            initCategoryType = type
            return
        }
        guard let index = (categoryList.firstIndex { $0.type == type }), index != self.activeIndex else { return }
        DispatchQueue.main.async { [weak self] in
            guard let `self` = self else { return }
            self.activeIndex = index
            self.isTapCategoryItem = true
            self.scrollListCollectionView.scrollToItem(at: IndexPath(row: index, section: 0), at: .centeredHorizontally, animated: true)
        }
    }
    
}

extension ClassyVC: UICollectionViewDataSource, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return categoryList.count
    }
    
    func collectionView(_ collectionView: UICollectionView,
                        layout collectionViewLayout: UICollectionViewLayout,
                        sizeForItemAt indexPath: IndexPath) -> CGSize {
        let row = indexPath.row
        return collectionView == categoryBarCollectionView ? categoryTitleSizeList[row] : classyScrollListItemSize
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let row = indexPath.row
        guard collectionView == scrollListCollectionView else {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "ClassyCategoryCell", for: indexPath) as! ClassyCategoryCell
            let isV6 = categoryList[row].type == .v6
            cell.imgView.isHidden = !isV6
            cell.titleLabel.isHidden = isV6
            let isActive = activeIndex == row
            cell.titleLabel.textColor = isActive ? .white : RGB(0xD6D6D6)
            cell.titleLabel.font = isActive ? UIFont.pingFangMedium(18) :  UIFont.pingFangRegular(18)
            cell.dataModel = categoryList[row]
            return cell
        }
        var cell: UICollectionViewCell
        switch categoryList[row].type {
        case .welfare:
            cell = collectionView.dequeueReusableCell(withReuseIdentifier: "ClassyScrollListWelfareItemCell\(row)", for: indexPath) as! ClassyScrollListWelfareItemCell
            (cell as? ClassyScrollListWelfareItemCell)?.classifyId = categoryList[row].id
            return cell
        case .recommend:
            cell = collectionView.dequeueReusableCell(withReuseIdentifier: "ClassyScrollListRecomItemCell\(row)", for: indexPath) as! ClassyScrollListRecomItemCell
            (cell as? ClassyScrollListRecomItemCell)?.classifyId = categoryList[row].id
            return cell
        case .v6:
            cell = collectionView.dequeueReusableCell(withReuseIdentifier: "ClassyScrollListV6ExlusiveItemCell\(row)", for: indexPath) as! ClassyScrollListV6ExlusiveItemCell
            let v6Cell = cell as? ClassyScrollListV6ExlusiveItemCell
            v6Cell?.delegate = self
            v6Cell?.currentIndex = row
            v6Cell?.classifyId = categoryList[row].id
            return cell
        case .leapboardActivity:
            cell = collectionView.dequeueReusableCell(withReuseIdentifier: "ClassyActivityItemCell\(row)", for: indexPath) as! ClassyActivityItemCell
            let activityCell = cell as? ClassyActivityItemCell
            activityCell?.refreshActivity()
            return cell
        case .h5:
            cell = collectionView.dequeueReusableCell(withReuseIdentifier: "ClassyWebViewItemCell\(row)", for: indexPath) as! ClassyWebViewItemCell
            (cell as? ClassyWebViewItemCell)?.webviewUrl = categoryList[row].h5Url
            return cell
        case .leapboard:
            cell = collectionView.dequeueReusableCell(withReuseIdentifier: "ClassyLeaderboardItemCell\(row)", for: indexPath) as! ClassyLeaderboardItemCell
            (cell as? ClassyLeaderboardItemCell)?.classifyId = categoryList[row].id
            return cell
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let row = indexPath.row
        guard collectionView == categoryBarCollectionView, activeIndex != row else { return }
        activeIndex = row
        isTapCategoryItem = true
        scrollListCollectionView.scrollToItem(at: indexPath, at: .centeredHorizontally, animated: true)
    }
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        guard scrollView == scrollListCollectionView else { return }
        let currentActivePageIndex = Int(round(scrollView.contentOffset.x / scrollView.frame.width))
        guard isTapCategoryItem else {
            guard activeIndex != currentActivePageIndex else { return }
            activeIndex = currentActivePageIndex
            refreshCategoryBarCollectionView(activeIndex: currentActivePageIndex)
            return
        }
        guard currentActivePageIndex == activeIndex else { return }
        refreshCategoryBarCollectionView(activeIndex: currentActivePageIndex)
    }
}

extension ClassyVC: ClassyScrollListV6ExlusiveItemCellDelegate {
    
    func handleV6ExlusiveBgConvertToPlain(currentIndex: Int) {
        guard !V6ExlusiveConvertToPlainIndexArr.contains(currentIndex) else { return }
        V6ExlusiveConvertToPlainIndexArr.append(currentIndex)
        guard currentIndex == activeIndex else { return }
        V6ExlusiveBgImgView.alpha = 0
    }
    
    func handlePlainConvertToV6ExlusiveBg(currentIndex: Int) {
        guard let index =
                V6ExlusiveConvertToPlainIndexArr.firstIndex(where: { $0 == currentIndex }) else { return }
        V6ExlusiveConvertToPlainIndexArr.remove(at: index)
        guard currentIndex == activeIndex else { return }
        V6ExlusiveBgImgView.alpha = 1
    }
    
}
