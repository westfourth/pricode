//
//  w.swift
//  Sp
//
//  Created by mac on 2020/5/4.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class ClassyScrollListSoftwareView: UIView {
    
    private lazy var leftSplitImgView: UIImageView = {
        let imgView = UIImageView(image: UIImage(named: "classy_welfare_split_right_bg"))
        return imgView
    }()
    
    private lazy var rightSplitImgView: UIImageView = {
        let imgView = UIImageView(image: UIImage(named: "classy_welfare_split_left_bg"))
        return imgView
    }()
    
    private lazy var titleLabel: UILabel = {
        let label = UILabel()
        label.text = "更多福利軟件"
        label.textColor = RGB(0xDFBD9C)
        label.font = UIFont.pingFangRegular(16)
        return label
    }()
    
    private lazy var collectionView: UICollectionView = {
        let layout = UICollectionViewFlowLayout()
        layout.minimumLineSpacing = 45
        layout.minimumInteritemSpacing = 0
        layout.itemSize = CGSize(width: 50, height: 50 + 8 + 18)
        layout.scrollDirection = .horizontal
        let cv = UICollectionView(frame: .zero, collectionViewLayout: layout)
        cv.register(ClassyScrollListSoftwareCell.self, forCellWithReuseIdentifier: "ClassyScrollListSoftwareCell")
        cv.contentInset = UIEdgeInsets(top: 0, left: 12, bottom: 0, right: 12)
        cv.showsVerticalScrollIndicator = false
        cv.showsHorizontalScrollIndicator = false
        cv.bouncesZoom = false
        cv.backgroundColor = .none
        cv.delegate = self
        cv.dataSource = self
        return cv
    }()
    
    var listData: [AdvertiseResp] = [] {
        didSet {
            collectionView.reloadData()
            DispatchQueue.main.async { [weak self] in
                guard let `self` = self else { return }
                let isEmpty = self.listData.isEmpty
                self.titleLabel.snp.updateConstraints { (make) in
                    make.height.equalTo(isEmpty ? 0 : 28)
                }
                self.leftSplitImgView.snp.updateConstraints { (make) in
                    make.height.equalTo(isEmpty ? 0 : 7 * ClassyScrollListPanicBuyingView.ratio)
                }
                self.collectionView.snp.updateConstraints { (make) in
                    make.height.equalTo(isEmpty ? 0 : 50 + 8 + 18)
                }
            }
        }
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        layer.masksToBounds = true
        renderView()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func renderView() {
        addSubview(titleLabel)
        addSubview(leftSplitImgView)
        addSubview(rightSplitImgView)
        addSubview(collectionView)
        titleLabel.snp.makeConstraints { (make) in
            make.top.equalToSuperview().inset(16)
            make.centerX.equalToSuperview()
            make.height.equalTo(28)
        }
        
        let ratio = ClassyScrollListPanicBuyingView.ratio
        
        leftSplitImgView.snp.makeConstraints { (make) in
            make.left.equalToSuperview().inset(12)
            make.centerY.equalTo(titleLabel)
            make.width.equalTo(70 * ratio)
            make.height.equalTo(7 * ratio)
        }
        
        rightSplitImgView.snp.makeConstraints { (make) in
            make.right.equalToSuperview().inset(12)
            make.centerY.equalTo(titleLabel)
            make.size.equalTo(leftSplitImgView)
        }
        
        collectionView.snp.makeConstraints { (make) in
            make.top.equalTo(titleLabel.snp.bottom).offset(18)
            make.left.right.equalToSuperview()
            make.height.equalTo(50 + 8 + 18)
        }
    }
}

extension ClassyScrollListSoftwareView: UICollectionViewDataSource, UICollectionViewDelegate {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return listData.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let  cell = collectionView.dequeueReusableCell(withReuseIdentifier: "ClassyScrollListSoftwareCell", for: indexPath) as! ClassyScrollListSoftwareCell
        cell.dataModel = listData[indexPath.row]
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        guard let url = listData[indexPath.row].adJump, InnerIntercept.canOpenURL(url) else {
            showToast("域名不合法，無法打開哦！")
            return
        }
        InnerIntercept.open(url)
    }
}
