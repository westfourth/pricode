//
//  ClassyScrollListWelfareCell.swift
//  Sp
//
//  Created by mac on 2020/5/4.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

protocol ClassyScrollListWelfareItemCellDelegate: NSObjectProtocol {
    
    func refreshTableView()
    
}

class ClassyScrollListWelfareItemCell: UICollectionViewCell {
    
    private let channelTypeClassList: [AnyClass] = [ClassyScrollListWelfateBannerCell.self,ClassyScrollListPanicBuyingCell.self,ClassyScrollListRedemptionVoucherCell.self,ClassyScrollListSoftwareCell.self]
    
    private let channelTypeKeyList: [String] = ["ClassyScrollListWelfateBannerCell","ClassyScrollListPanicBuyingCell","ClassyScrollListRedemptionVoucherCell","ClassyScrollListSoftwareCell"]
    
    static var channelTypeHeightList: [CGFloat] = [20, 35, 0, 0]
    
    private var isInitState: Bool = true
    
    var classifyId: String? {
        didSet {
            guard isInitState else { return }
            isInitState = false
            getList()
        }
    }
    
    private lazy var tableView: UITableView = {
        let tableView = UITableView(frame: .zero, style: .grouped)
        tableView.delegate = self
        tableView.dataSource = self
        tableView.backgroundColor = .none
        tableView.separatorStyle = .none
        tableView.bouncesZoom = false
        tableView.isDirectionalLockEnabled = true
        for i in 0..<channelTypeClassList.count {
            tableView.register(channelTypeClassList[i], forCellReuseIdentifier: channelTypeKeyList[i])
        }
        return tableView
    }()
    
    /// 定制福利
    public var customizedListData: [WelFareItem] = []
    /// 秒杀列表
    public var seckillListData: [SecKillItem] = []
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        addSubview(tableView)
        tableView.snp.makeConstraints { (make) in
            make.top.equalToSuperview().inset(kTop)
            make.left.right.bottom.equalToSuperview()
        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func getList() {
        Session.request(WelfareListReq()) { [weak self] (error, resp) in
            guard let `self` = self, error == nil, let resData = resp as? WelfareResp else {
                return
            }
            self.customizedListData = resData.customizedList
            self.seckillListData = resData.seckillList
            self.tableView.reloadData()
        }
    }
    
}

extension ClassyScrollListWelfareItemCell: UITableViewDelegate, UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return channelTypeClassList.count
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return .leastNonzeroMagnitude
    }
    
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return .leastNonzeroMagnitude
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        return nil
    }
    
    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        return nil
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return ClassyScrollListWelfareItemCell.channelTypeHeightList[indexPath.section]
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let section = indexPath.section
        switch section {
        case 0:
            let cell = tableView.dequeueReusableCell(withIdentifier: "ClassyScrollListWelfateBannerCell", for: indexPath) as! ClassyScrollListWelfateBannerCell
            cell.delegate = self
            if let id = classifyId {
                cell.classifyId = id
            }
            return cell
        case 1:
            let cell = tableView.dequeueReusableCell(withIdentifier: "ClassyScrollListPanicBuyingCell", for: indexPath) as! ClassyScrollListPanicBuyingCell
            cell.delegate = self
            return cell
        case 2:
            let cell = tableView.dequeueReusableCell(withIdentifier: "ClassyScrollListRedemptionVoucherCell", for: indexPath) as! ClassyScrollListRedemptionVoucherCell
            cell.delegate = self
            return cell
        case 3:
            let cell = tableView.dequeueReusableCell(withIdentifier: "ClassyScrollListSoftwareCell", for: indexPath) as! ClassyScrollListSoftwareCell
            cell.delegate = self
            return cell
        default:
            return UITableViewCell()
        }
    }
    
}

extension ClassyScrollListWelfareItemCell: ClassyScrollListWelfareItemCellDelegate {
    
    func refreshTableView() {
        tableView.reloadData()
    }
}

