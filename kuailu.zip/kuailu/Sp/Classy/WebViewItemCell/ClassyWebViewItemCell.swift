
import UIKit
import WebKit

class ClassyWebViewItemCell: UICollectionViewCell {
    
    private static var activityFuncTypeNameArr: [String] = ["startArea", "startShare", "startVip", "startProxy", "startHome"]
    
    private var isInitState: Bool = true
    
    var webviewUrl: URL? {
        didSet {
            guard isInitState, let url = webviewUrl else { return }
            isInitState = false
            webView.load(URLRequest(url: url))
        }
    }
    
    private lazy var webView: WKWebView = {
        ///偏好设置
        let preferences = WKPreferences()
        preferences.javaScriptEnabled = true
        let configuration = WKWebViewConfiguration()
        configuration.preferences = preferences
        configuration.userContentController = WKUserContentController()
        /// 给webview与swift交互起名字，webview给swift发消息的时候会用到
        ClassyWebViewItemCell.activityFuncTypeNameArr.forEach{ configuration.userContentController.add(WeakScriptMessageDelegate(self), name: $0) }
        let webView = WKWebView(frame: .zero, configuration: configuration)
        /// 允许右滑返回 允许webView里的页面可以右滑返回上一个web页面, 如果webview的控制器有导航栏，那么就会出现手势冲突问题
        webView.allowsBackForwardNavigationGestures = false
        /// KVO 监听 canGoBack，注意只有跳转到第二个页面，和返回到第一个页面时，该属性值才会变化
        //        webView.addObserver(self, forKeyPath: "canGoBack", options: .new, context: nil)
        webView.backgroundColor = .none
        webView.scrollView.bounces = true
        webView.scrollView.alwaysBounceVertical = true
        webView.navigationDelegate = self
        return webView
    }()
    
    ///MARK: 进度条
    private lazy var progressView: UIProgressView = {
        let progress = UIProgressView()
        progress.progressTintColor = RGB(255, 91, 111)
        progress.trackTintColor = .clear
        return progress
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        addSubview(webView)
        addSubview(progressView)
        webView.snp.makeConstraints { (make) in
            make.top.equalToSuperview().inset(kTop + 10)
            make.left.right.bottom.equalToSuperview()
        }
        
        progressView.snp.makeConstraints { (make) in
            make.top.equalTo(webView)
            make.left.right.equalToSuperview()
            make.height.equalTo(2)
        }
        progressView.isHidden = false
        progressView.progress = 0
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    /// 移除观察者
    deinit {
        //        webView.removeObserver(self, forKeyPath: "canGoBack", context: nil)
        WebVC.webViewType = .activity
        WebVC.webTitle = nil
        WebVC.webviewLoadedInitFunc = nil
    }
    
    //    override func observeValue(forKeyPath keyPath: String?,
    //                               of object: Any?,
    //                               change: [NSKeyValueChangeKey: Any]?,
    //                               context: UnsafeMutableRawPointer?) {
    //        guard let theKeyPath = keyPath, object as? WKWebView == webView, theKeyPath == "canGoBack", let newValue = change?[NSKeyValueChangeKey.newKey] as? Bool else {
    //            super.observeValue(forKeyPath: keyPath, of: object, change: change, context: context)
    //            return
    //        }
    //        navigationController?.interactivePopGestureRecognizer?.isEnabled = !newValue
    //    }
}

extension ClassyWebViewItemCell: WKNavigationDelegate {
    
    ///MARK: 页面开始加载时调用
    func webView(_ webView: WKWebView, didStartProvisionalNavigation navigation: WKNavigation!){
        UIView.animate(withDuration: 0.1, delay: 0, options: .curveLinear, animations: { [weak self] in
            guard let `self` = self else { return }
            self.progressView.progress = Float(self.webView.estimatedProgress)
            }, completion: nil)
    }
    
    ///MARK: 当内容开始返回时调用
    func webView(_ webView: WKWebView, didCommit navigation: WKNavigation!){
        UIView.animate(withDuration: 0.2, delay: 0, options: .curveLinear, animations: { [weak self] in
            guard let `self` = self else { return }
            self.progressView.progress = Float(self.webView.estimatedProgress)
            }, completion: nil)
    }
    
    ///MARK: 在网页加载完成时调用js方法
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        if let funcName = WebVC.webviewLoadedInitFunc {
            webView.evaluateJavaScript(funcName, completionHandler: nil)
        }
        UIView.animate(withDuration: 0.5, delay: 0, options: .curveEaseIn, animations: { [weak self] in
            guard let `self` = self else { return }
            self.progressView.progress = 1
            self.progressView.layer.opacity = 0
            }, completion: nil)
    }
    
    ///MARK: 页面加载失败时调用
    func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error){
        UIView.animate(withDuration: 0.5) { [weak self] in
            guard let `self` = self else { return }
            self.progressView.progress = 0
            self.progressView.layer.opacity = 0
        }
    }
}

extension ClassyWebViewItemCell: WKScriptMessageHandler {
    
    ///MARK: 接收js调用方法
    func userContentController(_ userContentController: WKUserContentController,
                               didReceive message: WKScriptMessage) {
        /// 在控制台中打印html中console.log的内容,方便调试
        let typeName = message.name
        /// message.name是约定好的方法名, message.body是携带的参数
        ///不接收参数时直接不处理message.body即可,不用管Html传了什么
        let typeNameArr = ClassyWebViewItemCell.activityFuncTypeNameArr
        guard let navigationController = (UIApplication.shared.delegate as? AppDelegate)?.currentNavigationController else { return }
        switch typeName {
        case typeNameArr[0]:
            guard let params = message.body as? Dictionary<String, Any>, let choiceId = params["choiceId"] as? Int, let choiceTitle = params["choiceTitle"] as? String else { return }
            let classyItem = ClassyItem()
            classyItem.choiceId = choiceId
            ClassyVideoSetVC.isFromClassy = false
            let classyVideoSetVC = ClassyVideoSetVC()
            classyVideoSetVC.navigationItem.title = choiceTitle
            classyVideoSetVC.itemData = classyItem
            classyVideoSetVC.hidesBottomBarWhenPushed = true
            navigationController.show(classyVideoSetVC, sender: nil)
        case typeNameArr[1]:
            guard let params = message.body as? Dictionary<String, Any>, let videoId = params["videoId"] as? Int, let nickName = params["nickName"] as? String, let title = params["title"] as? String, let imgUrl = params["imgUrl"] as? String else { return }
            let videoItem = VideoItem()
            videoItem.videoId = videoId
            videoItem.nickName = nickName
            videoItem.title = title
            videoItem.coverImg = URL(string: imgUrl)
            let shareVideoVC = ShareVideoVC()
            shareVideoVC.video = videoItem
            shareVideoVC.hidesBottomBarWhenPushed = true
            navigationController.show(shareVideoVC, sender: nil)
        case typeNameArr[2]:
            VipChargeTipVC.isFromVideoPlayList = false
            navigationController.show(Vip2VC(), sender: nil)
        case typeNameArr[3]:
            let spreadVC = SpreadVC()
            spreadVC.hidesBottomBarWhenPushed = true
            navigationController.show(spreadVC, sender: nil)
        case typeNameArr[4]:
            navigationController.popToRootViewController(animated: true)
        default:
            break
        }
    }
}

