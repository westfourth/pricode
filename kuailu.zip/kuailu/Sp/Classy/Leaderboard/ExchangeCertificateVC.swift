//
//  ExchangeCertificateVC.swift
//  Sp
//
//  Created by mac on 2020/5/4.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class ExchangeCertificateVC: UIViewController {
    
    var items = [MyWelFareItem]()
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.navigationBar.barTintColor = RGB(0x141516)
        navigationController?.navigationBar.isTranslucent = false
        self.navigationController?.navigationBar.shadowImage = UIImage()
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.title = "\(Sensitive.dui)券"
        view.backgroundColor = RGB(0x141516)
        self.tableView.backgroundColor = .clear
        view.addSubview(self.tableView)
        self.tableView.snp.makeConstraints { (make) in
            make.bottom.top.equalToSuperview()
            make.left.equalTo(16)
            make.right.equalTo(-16)
        }
        loadData()
    }
    
    lazy var tableView : UITableView = {
        let tableView = UITableView.init(frame: CGRect.zero, style: .grouped)
        tableView.delegate = self
        tableView.dataSource = self
        tableView.clipsToBounds = true
        tableView.backgroundColor = .clear
        tableView.separatorStyle = UITableViewCell.SeparatorStyle.none
        tableView.tableFooterView = UIView()
        tableView.showsVerticalScrollIndicator = false
        tableView.register(UINib(nibName: "ExchangeCell", bundle: Bundle.main), forCellReuseIdentifier: "ExchangeCell")
        tableView.state = .loading
        return tableView
    }()
    
    //MARK:-数据加载
    func loadData()  {
        Session.request(MyWelfareReq()) { [weak self] (error, resp) in
            guard error == nil else {
                self?.tableView.state = .failed
                return
            }
            guard let result = resp as? MyWelFareListResp else {
                self?.tableView.state = .empty
                return
            }
            guard !result.myWelfares.isEmpty else {
                self?.tableView.state = .empty
                return
            }
            self?.items = result.myWelfares
            self?.tableView.state = .normal
            self?.tableView.reloadData()
        }
        
    }
}

// MARK: -UITableViewDataSource && Delegate
extension ExchangeCertificateVC:UITableViewDataSource,UITableViewDelegate {
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ExchangeCell") as! ExchangeCell
        cell.item = items[indexPath.section]
        return cell
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        return items.count
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 78.5
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 20
    }
    
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return 1
    }
    
    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        return nil
    }
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        return nil
    }
}
