//
//  ExchangeCell.swift
//  Sp
//
//  Created by mac on 2020/5/4.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class ExchangeCell: UITableViewCell {

    static  let standardFormatStr = "yyyy.MM.dd"
    static var formater:DateFormatter = {
       let format = DateFormatter()
        format.dateFormat = ExchangeCell.standardFormatStr
        return format
    }()
    
    override func awakeFromNib() {
        super.awakeFromNib()
        self.backgroundColor = .clear
        selectionStyle = .none
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        status.isUserInteractionEnabled = true
        let tap = UITapGestureRecognizer(target: self, action:#selector(tapAction(_:)))
        status.addGestureRecognizer(tap)
    }
    
    @IBOutlet weak var name: UILabel!
    @IBOutlet weak var time: UILabel!
    @IBOutlet weak var status: UILabel!
    @IBOutlet weak var appIcon: UIImageView!
    
    @IBOutlet weak var bgImageView: UIImageView!
    
    private static let avatarImg: UIImage? = {
        return Sensitive.avatar
    }()
    
    //MARK:-item didSet
    var item:MyWelFareItem? {
        didSet {
            guard let item = item else {
                return
            }
            self.name.text = "\(Sensitive.dui)碼：\(item.code)"
            let start = ExchangeCell.formater.string(from: item.startTerm ?? Date())
            let end = ExchangeCell.formater.string(from: item.endTerm ?? Date())
            self.time.text = "使用期限:\(start)-\(end) "
            
            if item.appIcon == nil {
                self.appIcon.image = ExchangeCell.avatarImg
            } else {
                self.appIcon.kf.setImage(with: item.appIcon!,placeholder:ExchangeCell.avatarImg)
            }
            if item.endTerm != nil {
             let outDate = item.endTerm!.timeIntervalSince1970 - Date().timeIntervalSince1970 < 0
                if outDate {
                    self.contentView.backgroundColor = RGB(0xff7A7C8E)
                    self.status.text = """
                    已
                    過
                    期
                    """
                    self.status.textColor = RGB(0xffEDEDED)
                    self.bgImageView.image = UIImage(named: "exchange_bg_y")
                } else {
                     self.status.text = """
                    去
                    使
                    用
                    """
                    self.contentView.backgroundColor = RGB(0xffFFC379)
                     self.status.textColor = RGB(0xffA35D00)
                    self.bgImageView.image = UIImage(named: "exchange_bg_n")

                }
            } else {
                self.status.text = """
                去
                使
                用
                """
                self.contentView.backgroundColor = RGB(0xffFFC379)
                self.status.textColor = RGB(0xffA35D00)
                self.bgImageView.image = UIImage(named: "exchange_bg_n")
            }
        }
    }
    
    @objc func tapAction(_ sender: Any) {
        guard let item = self.item else {
            return
        }
        guard item.url  != nil else {
            return
        }
        let url = item.url!
        if InnerIntercept.canOpenURL(url) {
            InnerIntercept.open(url)
        } else {
            mm_showToast("非法鏈接!")
        }
    }
}
