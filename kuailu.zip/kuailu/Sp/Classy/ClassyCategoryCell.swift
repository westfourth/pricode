//
//  ClassyCategoryCell.swift
//  Sp
//
//  Created by mac on 2020/3/6.
//  Copyright © 2020 mac. All rights reserved.
//


class ClassyCategoryCell: UICollectionViewCell {
    
    private static let v6Img: UIImage? =  {
        return UIImage(named: "classy_v6_category_icon")
    }()
    
    lazy var titleLabel: UILabel = {
        let label = UILabel()
        label.textAlignment = .center
        return label
    }()
    
    lazy var imgView: UIImageView = {
        let imgView = UIImageView(image: ClassyCategoryCell.v6Img)
        imgView.contentMode = .scaleAspectFit
        imgView.isHidden = true
        return imgView
    }()
    
    var dataModel: AppMenuItem? {
        didSet {
            guard let item = dataModel else { return }
            titleLabel.text = item.title
            imgView.kf.setImage(with: item.image)
        }
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        addSubview(titleLabel)
        addSubview(imgView)
        
        titleLabel.snp.makeConstraints { (make) in
            make.left.right.equalToSuperview()
            make.bottom.equalToSuperview().inset(4)
        }
        
        imgView.snp.makeConstraints { (make) in
            make.height.equalTo(33)
            make.bottom.left.right.equalToSuperview()
        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}
