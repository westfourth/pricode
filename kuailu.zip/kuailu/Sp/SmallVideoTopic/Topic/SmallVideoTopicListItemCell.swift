//
//  SmallVideoTopicListItemCell.swift
//  Sp
//
//  Created by mac on 2021/1/15.
//  Copyright © 2021 mac. All rights reserved.
//

import UIKit

class SmallVideoTopicListItemCell: UICollectionViewCell {
    
    static let itemInteritemSpacing: CGFloat = 8
    
    private static let itemLineSpacing: CGFloat = 10
    
    static let itemEdgeInsetMargin: CGFloat = 12
    
    private lazy var collectionView: UICollectionView = {
        let layout = UICollectionViewFlowLayout()
        layout.itemSize = CGSize(width: SmallVideoTopicListCell.itemWidth, height: SmallVideoTopicListCell.itemHeight)
        layout.minimumInteritemSpacing = SmallVideoTopicListItemCell.itemInteritemSpacing
        layout.minimumLineSpacing = SmallVideoTopicListItemCell.itemLineSpacing
        layout.sectionInset = UIEdgeInsets(top: 0, left: SmallVideoTopicListItemCell.itemEdgeInsetMargin, bottom: 0, right: SmallVideoTopicListItemCell.itemEdgeInsetMargin)
        let cv = UICollectionView(frame: .zero, collectionViewLayout: layout)
        cv.register(SmallVideoTopicListCell.self, forCellWithReuseIdentifier: "SmallVideoTopicListCell")
        cv.contentInset = UIEdgeInsets(top: 10, left: 0, bottom: 20, right: 0)
        cv.showsHorizontalScrollIndicator = false
        cv.contentInsetAdjustmentBehavior = .never
        cv.bouncesZoom = false
        cv.backgroundColor = .none
        cv.state = .loading
        cv.delegate = self
        cv.dataSource = self
        return cv
    }()
    
    private var listData: [ClassyItem] = []
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        addSubview(collectionView)
        
        collectionView.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
        initList()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func initList() {
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.4) { [weak self] in
            self?.getList()
        }
    }
    
    private func getList() {
        Session.request(SmallVideoTopicListReq()) { [weak self] (error, resp) in
            guard let `self` = self else { return }
            guard error == nil, let resData = resp as? [ClassyItem] else {
                self.collectionView.state = .failed
                self.collectionView.reloadData()
                return
            }
            self.listData = resData
            self.collectionView.state = self.listData.isEmpty ? .empty : .normal
            self.collectionView.reloadData()
        }
    }
    
}

extension SmallVideoTopicListItemCell: UICollectionViewDataSource, UICollectionViewDelegate {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return listData.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "SmallVideoTopicListCell", for: indexPath) as! SmallVideoTopicListCell
        cell.dataModel = listData[indexPath.row]
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        guard let currentNaviController = (UIApplication.shared.delegate as? AppDelegate)?.currentNavigationController else { return }
        let smallVideoTopicMoreListVC = SmallVideoTopicMoreListVC()
        smallVideoTopicMoreListVC.type = .topic
        smallVideoTopicMoreListVC.topicData = listData[indexPath.row]
        currentNaviController.show(smallVideoTopicMoreListVC, sender: nil)
    }
    
}
