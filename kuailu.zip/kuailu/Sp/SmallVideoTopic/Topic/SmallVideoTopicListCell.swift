//
//  SmallVideoTopicListCell.swift
//  Sp
//
//  Created by mac on 2021/1/14.
//  Copyright © 2021 mac. All rights reserved.
//

import UIKit

class SmallVideoTopicListCell: UICollectionViewCell {
    
    static let itemWidth: CGFloat = {
        return (UIScreen.main.bounds.width - SmallVideoTopicListItemCell.itemEdgeInsetMargin * 2 - SmallVideoTopicListItemCell.itemInteritemSpacing) / 2
    }()
    
    static let itemHeight: CGFloat = {
        return SmallVideoTopicListCell.posterHeight
    }()
    
    private static let posterSizeRatio: CGFloat = 164 / 197
    
    private static let posterHeight: CGFloat = {
        return SmallVideoTopicListCell.itemWidth / SmallVideoTopicListCell.posterSizeRatio
    }()
    
    private lazy var posterImgView: UIImageView = {
        let imgView = UIImageView()
        imgView.contentMode = .scaleAspectFill
        imgView.layer.masksToBounds = true
        imgView.layer.cornerRadius = 4
        return imgView
    }()

    var dataModel: ClassyItem? {
        didSet {
            guard let item = dataModel else { return }
            posterImgView.kf.setImage(with: item.coverImg?.column2, placeholder: Sensitive.default_bg, options: SearchResultVideoCell.animationOption)
        }
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = rgb(0x1C1C1C)
        layer.masksToBounds = true
        layer.cornerRadius = 4
        addSubview(posterImgView)
        
        posterImgView.snp.makeConstraints { (make) in
            make.top.left.right.equalToSuperview()
            make.height.equalTo(SmallVideoTopicListCell.posterHeight)
        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}
