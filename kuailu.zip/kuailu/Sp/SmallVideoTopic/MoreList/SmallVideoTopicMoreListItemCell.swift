//
//  SmallVideoTopicMoreListItemCell.swift
//  Sp
//
//  Created by mac on 2021/1/14.
//  Copyright © 2021 mac. All rights reserved.
//

import UIKit

class SmallVideoTopicMoreListItemCell: UICollectionViewCell {
    
    private static let itemInteritemSpacing: CGFloat = 8
    
    private static let itemLineSpacing: CGFloat = 10
    
    private static let itemEdgeInsetMargin: CGFloat = 12
    
    private lazy var collectionView: UICollectionView = {
        let layout = UICollectionViewFlowLayout()
        layout.itemSize = CGSize(width: SmallVideoRecommendVerticalFourGridCell.itemWidth, height: SmallVideoRecommendVerticalFourGridCell.itemHeight)
        layout.minimumInteritemSpacing = SmallVideoRecommendVerticalFourGridItemCell.itemInteritemSpacing
        layout.minimumLineSpacing = SmallVideoRecommendVerticalFourGridItemCell.itemLineSpacing
        layout.sectionInset = UIEdgeInsets(top: 0, left: SmallVideoRecommendVerticalFourGridItemCell.itemEdgeInsetMargin, bottom: 0, right: SmallVideoRecommendVerticalFourGridItemCell.itemEdgeInsetMargin)
        let cv = UICollectionView(frame: .zero, collectionViewLayout: layout)
        cv.register(SmallVideoRecommendVerticalFourGridCell.self, forCellWithReuseIdentifier: "SmallVideoRecommendVerticalFourGridCell")
        cv.showsHorizontalScrollIndicator = false
        cv.bouncesZoom = false
        cv.backgroundColor = .none
        cv.state = .loading
        cv.delegate = self
        cv.dataSource = self
        cv.mj_header = getCommonMJHeader(refreshingTarget: self, headerRefreshCallback: #selector(onRefresh))
        cv.mj_footer = getCommonMJFooter(refreshingTarget: self, footerRefreshCallback: #selector(onLoad))
        return cv
    }()
    
    private var listData: [VideoItem] = []
    
    private var isInitState: Bool = true
    
    var type: SmallVideoTopicMoreListType = .topic
    
    var itemType: FeaturedTopicDetailsType = .latest
    
    var tagData: PublishCateItem? {
        didSet {
            guard isInitState else { return }
            isInitState = false
            initList()
        }
    }
    
    var topicData: ClassyItem? {
        didSet {
            guard isInitState else { return }
            isInitState = false
            initList()
        }
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        addSubview(collectionView)
        
        collectionView.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func initList() {
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.4) { [weak self] in
            self?.onRefresh()
        }
    }
    private func getList(isRefresh: Bool) {
        collectionView.state = listData.isEmpty ? .loading : .normal
        var req: AnyObject
        switch type {
        case .tag:
            guard let item = tagData else { return }
            req = SmallVideoTopicTagsDetailsListReq()
            (req as! SmallVideoTopicTagsDetailsListReq).lastId = isRefresh ? 0 : (listData.last?.videoId ?? 0)
            (req as! SmallVideoTopicTagsDetailsListReq).choiceSort = itemType.rawValue
            (req as! SmallVideoTopicTagsDetailsListReq).tagTitle = item.tagsTitle
        case .topic:
            guard let item = topicData else { return }
            req = SmallVideoTopicDetailsListReq()
            (req as! SmallVideoTopicDetailsListReq).lastId = isRefresh ? 0 : (listData.last?.videoId ?? 0)
            (req as! SmallVideoTopicDetailsListReq).choiceSort = itemType.rawValue
            (req as! SmallVideoTopicDetailsListReq).choiceId = item.choiceId
        }
        if isRefresh {
            collectionView.mj_footer?.resetNoMoreData()
        }
        let collectionView = self.collectionView
        Session.request(type == .tag ? (req as! SmallVideoTopicTagsDetailsListReq) : (req as! SmallVideoTopicDetailsListReq)) { [weak self] (error, resp) in
            isRefresh ? collectionView.mj_header?.endRefreshing() : collectionView.mj_footer?.endRefreshing()
            guard let `self` = self else { return }
            guard error == nil, let resData = resp as? [VideoItem] else {
                self.handleListException(isRefresh: isRefresh)
                return
            }
            self.listData = isRefresh ? resData : self.listData + resData
            let isEmpty = self.listData.isEmpty
            collectionView.state = isEmpty ? .empty : .normal
            collectionView.mj_footer?.isHidden = isEmpty
            collectionView.reloadData()
            if resData.count < req.pageSize {
                DispatchQueue.main.async {
                    collectionView.mj_footer?.endRefreshingWithNoMoreData()
                }
            }
        }
    }
    
    private func handleListException(isRefresh: Bool) {
        if isRefresh {
            listData = []
            collectionView.reloadData()
            collectionView.state = .failed
            collectionView.mj_footer?.isHidden = true
        } else {
            collectionView.state = .normal
            collectionView.mj_footer?.endRefreshingWithNoMoreData()
            collectionView.mj_footer?.isHidden = false
        }
    }
    
    @objc private func onLoad() {
        getList(isRefresh: false)
    }
    
    @objc private func onRefresh() {
        getList(isRefresh: true)
    }
    
}

extension SmallVideoTopicMoreListItemCell: UICollectionViewDataSource, UICollectionViewDelegate {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return listData.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "SmallVideoRecommendVerticalFourGridCell", for: indexPath) as! SmallVideoRecommendVerticalFourGridCell
        cell.dataModel = listData[indexPath.row]
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        SearchResultVC.navigationToVideoPlayListVC(indexPath: indexPath, VideoList: listData)
    }
    
}
