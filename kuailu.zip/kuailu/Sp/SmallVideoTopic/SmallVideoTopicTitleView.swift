//
//  SmallVideoTopicTitleView.swift
//  Sp
//
//  Created by mac on 2021/1/15.
//  Copyright © 2021 mac. All rights reserved.
//

import UIKit

protocol SmallVideoTopicTitleViewDelegate: NSObjectProtocol {
    
    func onTitleBtnTap(type: SmallVideoTopicMoreListType)
    
}

class SmallVideoTopicTitleView: UIView {
    
    lazy var tagTitleBtn: UIButton = {
        let btn = UIButton()
        btn.setTitle("全部標籤", for: .normal)
        btn.titleLabel?.font = font(18, .medium)
        btn.setTitleColor(.white, for: .normal)
        btn.setTitleColor(Color.theme_color, for: .selected)
        btn.addTarget(self, action: #selector(onTagTitleBtnTap), for: .touchUpInside)
        return btn
    }()
    
    lazy var topicTitleBtn: UIButton = {
        let btn = UIButton()
        btn.setTitle("熱門主題", for: .normal)
        btn.titleLabel?.font = font(18, .medium)
        btn.setTitleColor(.white, for: .normal)
        btn.setTitleColor(Color.theme_color, for: .selected)
        btn.addTarget(self, action: #selector(onTopicTitleBtn), for: .touchUpInside)
        return btn
    }()
    
    weak var delegate: SmallVideoTopicTitleViewDelegate?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        renderView()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func renderView() {
        addSubview(tagTitleBtn)
        addSubview(topicTitleBtn)
        
        tagTitleBtn.snp.makeConstraints { (make) in
            make.left.centerY.equalToSuperview()
        }
        
        topicTitleBtn.snp.makeConstraints { (make) in
            make.right.centerY.equalToSuperview()
        }
    }
    
    @objc private func onTagTitleBtnTap() {
        delegate?.onTitleBtnTap(type: .tag)
    }
    
    @objc private func onTopicTitleBtn() {
        delegate?.onTitleBtnTap(type: .topic)
    }
    
}
