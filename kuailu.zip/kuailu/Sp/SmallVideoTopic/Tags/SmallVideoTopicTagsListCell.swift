//
//  SmallVideoTopicTagsListCell.swift
//  Sp
//
//  Created by mac on 2021/1/15.
//  Copyright © 2021 mac. All rights reserved.
//

import UIKit

class SmallVideoTopicTagsListCell: UICollectionViewCell {
    
    static let viewWidth: CGFloat = {
        return (UIScreen.main.bounds.width - SmallVideoTopicTagsListItemCell.itemEdgeInsetMargin * 2 - SmallVideoTopicTagsListItemCell.itemInteritemSpacing * (SmallVideoTopicTagsListItemCell.columnNum - 1)) / SmallVideoTopicTagsListItemCell.columnNum
    }()
    
    static let viewHeight: CGFloat = 50
    
    private lazy var titleLabel: UILabel = {
        let label = UILabel()
        label.textColor = .white
        label.font = font(14, .medium)
        label.textAlignment = .center
        return label
    }()
    
    private lazy var worksNumLabel: UILabel = {
        let label = UILabel()
        label.textColor = .white
        label.font = font(12, .medium)
        label.textAlignment = .center
        return label
    }()
    
    private lazy var gradientLayer: CAGradientLayer = {
        let gradientLayer = CAGradientLayer()
        gradientLayer.frame = bounds
        return gradientLayer
    }()
    
    var gradientColors: [CGColor]? {
        didSet {
            guard let colors =  gradientColors else { return }
            gradientLayer.colors = colors
        }
    }
    
    var dataModel: PublishCateItem? {
        didSet {
            guard let item = dataModel else { return }
            titleLabel.text = "#\(item.tagsTitle)"
            worksNumLabel.text = "共\(item.videoNum)部片"
        }
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        layer.masksToBounds = true
        layer.cornerRadius = 4
        layer.insertSublayer(gradientLayer, at: 0)
        renderView()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func renderView() {
        addSubview(titleLabel)
        addSubview(worksNumLabel)
        
        titleLabel.snp.makeConstraints { (make) in
            make.top.equalToSuperview().inset(6)
            make.left.right.equalToSuperview()
        }
        
        worksNumLabel.snp.makeConstraints { (make) in
            make.left.right.equalToSuperview()
            make.bottom.equalToSuperview().inset(6)
        }
        
    }
    
}
