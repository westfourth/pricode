//
//  SmallVideoTopicTagsListSectionHeaderView.swift
//  Sp
//
//  Created by mac on 2021/1/15.
//  Copyright © 2021 mac. All rights reserved.
//

import UIKit

class SmallVideoTopicTagsListSectionHeaderView: UICollectionReusableView {
    
    static let viewHeight: CGFloat = 46
    
    lazy var titleLabel: UILabel = {
        let label = UILabel()
        label.textColor = .white
        label.font = UIFont.pingFangMedium(20)
        return label
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        addSubview(titleLabel)
        
        titleLabel.snp.makeConstraints { (make) in
            make.left.right.equalToSuperview().inset(18)
            make.top.bottom.equalToSuperview()
        }
       
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

}
