//
//  SmallVideoTopicTagsItemCell.swift
//  Sp
//
//  Created by mac on 2021/1/15.
//  Copyright © 2021 mac. All rights reserved.
//

import UIKit

class SmallVideoTopicTagsListItemCell: UICollectionViewCell {
    
    static let itemInteritemSpacing: CGFloat = 6
    
    static let itemLineSpacing: CGFloat = 8
    
    static let itemEdgeInsetMargin: CGFloat = 15
    
    static let columnNum: CGFloat = 3
    
    private static let sectionHeaderSize: CGSize = {
        return CGSize(width: UIScreen.main.bounds.width, height: SmallVideoTopicTagsListSectionHeaderView.viewHeight)
    }()
    
    private static let itemSize: CGSize = {
        return CGSize(width: SmallVideoTopicTagsListCell.viewWidth, height: SmallVideoTopicTagsListCell.viewHeight)
    }()
    
    private lazy var collectionView: UICollectionView = {
        let layout = UICollectionViewFlowLayout()
        layout.itemSize = SmallVideoTopicTagsListItemCell.itemSize
        layout.minimumInteritemSpacing = SmallVideoTopicTagsListItemCell.itemInteritemSpacing
        layout.minimumLineSpacing = SmallVideoTopicTagsListItemCell.itemLineSpacing
        layout.sectionInset = UIEdgeInsets(top: 0, left: SmallVideoTopicTagsListItemCell.itemEdgeInsetMargin, bottom: 10, right: SmallVideoTopicTagsListItemCell.itemEdgeInsetMargin)
        let cv = UICollectionView(frame: .zero, collectionViewLayout: layout)
        cv.register(SmallVideoTopicTagsListCell.self, forCellWithReuseIdentifier: "SmallVideoTopicTagsListCell")
        cv.register(SmallVideoTopicTagsListSectionHeaderView.self, forSupplementaryViewOfKind: UICollectionView.elementKindSectionHeader, withReuseIdentifier: "SmallVideoTopicTagsListSectionHeaderView")
        cv.contentInset = UIEdgeInsets(top: 10, left: 0, bottom: 20, right: 0)
        cv.showsHorizontalScrollIndicator = false
        cv.contentInsetAdjustmentBehavior = .never
        cv.bouncesZoom = false
        cv.backgroundColor = .none
        cv.state = .loading
        cv.delegate = self
        cv.dataSource = self
        return cv
    }()
    
    private var listData: [PublishCateListResp] = []
    
    private var itemGradientColorsList: [[[CGColor]]] = []
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        addSubview(collectionView)
        
        collectionView.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
        initList()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func initList() {
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.4) { [weak self] in
            self?.getList()
        }
    }
    
    private func getList() {
        Session.request(PublishCateListReq()) { [weak self] (error, resp) in
            guard let `self` = self else { return }
            guard error == nil, let resData = resp as? [PublishCateListResp], !resData.isEmpty else {
                self.listData = []
                self.collectionView.state = .failed
                self.collectionView.reloadData()
                return
            }
            self.listData = resData
            self.handleItemGradientColors()
            self.collectionView.state = self.listData.isEmpty ? .empty : .normal
            self.collectionView.reloadData()
        }
    }
    
    private func handleItemGradientColors() {
        for i in 0..<listData.count {
            let currentItem = listData[i]
            let starColorRGB = UIColor.getRGB(hexStr: currentItem.startColor)
            let endColorRGB = UIColor.getRGB(hexStr: currentItem.endColor)
            let rowTotalNum: CGFloat = getRowNum(index: CGFloat(currentItem.tagsList.count))
            let redValOffset: CGFloat = (endColorRGB[0] - starColorRGB[0]) / rowTotalNum
            let greenValOffset: CGFloat = (endColorRGB[1] - starColorRGB[1]) / rowTotalNum
            let blueValOffset: CGFloat = (endColorRGB[2] - starColorRGB[2]) / rowTotalNum
            let colorValOffset: [CGFloat] = [redValOffset, greenValOffset, blueValOffset]
            var colorsList: [[CGColor]] = []
            for k in 0..<currentItem.tagsList.count {
                let rowNum = getRowNum(index: CGFloat(k + 1)) - 1
                let nextRowNum = rowNum + 1
                let starColor = UIColor(red: starColorRGB[0] + rowNum * colorValOffset[0], green: starColorRGB[1] + rowNum * colorValOffset[1], blue: starColorRGB[2] + rowNum * colorValOffset[2], alpha: 1).cgColor
                let endColor = UIColor(red: starColorRGB[0] + nextRowNum * colorValOffset[0], green: starColorRGB[1] + nextRowNum * colorValOffset[1], blue: starColorRGB[2] + nextRowNum * colorValOffset[2], alpha: 1).cgColor
                colorsList.append([starColor, endColor])
            }
            itemGradientColorsList.append(colorsList)
        }
    }
    
    private func getRowNum(index: CGFloat) -> CGFloat {
        let columnNum = SmallVideoTopicTagsListItemCell.columnNum
        return CGFloat(index.truncatingRemainder(dividingBy: columnNum) == 0 ? Int(index / columnNum) : Int(index / columnNum) + 1)
    }
    
}

extension SmallVideoTopicTagsListItemCell: UICollectionViewDataSource, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout {
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return listData.count
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return listData[section].tagsList.count
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, referenceSizeForHeaderInSection section: Int) -> CGSize {
        return SmallVideoTopicTagsListItemCell.sectionHeaderSize
    }
    
    func collectionView(_ collectionView: UICollectionView, viewForSupplementaryElementOfKind kind: String, at indexPath: IndexPath) -> UICollectionReusableView {
        guard kind == UICollectionView.elementKindSectionHeader, let sectionHeader = collectionView.dequeueReusableSupplementaryView(ofKind: kind, withReuseIdentifier: "SmallVideoTopicTagsListSectionHeaderView", for: indexPath) as? SmallVideoTopicTagsListSectionHeaderView else {
            return UICollectionReusableView()
        }
        sectionHeader.titleLabel.text = listData[indexPath.section].tagsTitle
        return sectionHeader
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "SmallVideoTopicTagsListCell", for: indexPath) as! SmallVideoTopicTagsListCell
        let section = indexPath.section
        let row = indexPath.row
        cell.gradientColors = itemGradientColorsList[section][row]
        cell.dataModel = listData[section].tagsList[row]
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        guard let currentNaviController = (UIApplication.shared.delegate as? AppDelegate)?.currentNavigationController else { return }
        let smallVideoTopicMoreListVC = SmallVideoTopicMoreListVC()
        smallVideoTopicMoreListVC.type = .tag
        smallVideoTopicMoreListVC.tagData = listData[indexPath.section].tagsList[indexPath.row]
        currentNaviController.show(smallVideoTopicMoreListVC, sender: nil)
    }
    
}

