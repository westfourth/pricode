//
//  SmallVideoTopicVC.swift
//  Sp
//
//  Created by mac on 2021/1/14.
//  Copyright © 2021 mac. All rights reserved.
//

import UIKit

class SmallVideoTopicVC: UIViewController {
    
    private static let emptyImg: UIImage = {
        return UIImage()
    }()
    
    private static let itemSize: CGSize = {
        return CGSize(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height - kTop)
    }()
    
    private lazy var titleView: SmallVideoTopicTitleView = {
        let view = SmallVideoTopicTitleView()
        view.delegate = self
        return view
    }()
    
    private lazy var collectionView: UICollectionView = {
        let layout = UICollectionViewFlowLayout()
        layout.minimumInteritemSpacing = 0
        layout.minimumLineSpacing = 0
        layout.itemSize = SmallVideoTopicVC.itemSize
        layout.scrollDirection = .horizontal
        let cv = UICollectionView(frame: .zero, collectionViewLayout: layout)
        cv.register(SmallVideoTopicTagsListItemCell.self, forCellWithReuseIdentifier: "SmallVideoTopicTagsListItemCell")
        cv.register(SmallVideoTopicListItemCell.self, forCellWithReuseIdentifier: "SmallVideoTopicListItemCell")
        cv.showsHorizontalScrollIndicator = false
        cv.showsVerticalScrollIndicator = false
        cv.bounces = false
        cv.bouncesZoom = false
        cv.isPagingEnabled = true
        cv.delegate = self
        cv.dataSource = self
        cv.backgroundColor = .none
        return cv
    }()
    
    private var activePageIndex: Int = 0
    
    override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: Bundle?) {
        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
        hidesBottomBarWhenPushed = true
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        if #available(iOS 11.0, *) {
            collectionView.contentInsetAdjustmentBehavior = .never
        } else {
            automaticallyAdjustsScrollViewInsets = false
        }
        navigationItem.titleView = titleView
        view.backgroundColor = RGB(0x141516)
        view.addSubview(collectionView)
        
        titleView.snp.makeConstraints { (make) in
            make.width.equalTo(158)
            make.height.equalTo(25)
        }
        
        collectionView.snp.makeConstraints { (make) in
            make.top.left.right.equalToSuperview()
            make.height.equalTo(SmallVideoTopicVC.itemSize.height)
        }
        switchCurrentPageByScrolling(activePageIndex: activePageIndex)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.navigationBar.isTranslucent = false
        navigationController?.navigationBar.setBackgroundImage(SmallVideoTopicVC.emptyImg, for: .default)
        navigationController?.navigationBar.shadowImage = SmallVideoTopicVC.emptyImg
        navigationController?.navigationBar.barTintColor = RGB(0x1C1C1C)
    }
    
    private func switchCurrentPageByTapping(activePageIndex: Int) {
        collectionView.scrollToItem(at: IndexPath(item: activePageIndex == 0 ? 0 : 1, section: 0), at: .centeredHorizontally, animated: true)
    }
    
    private func switchCurrentPageByScrolling(activePageIndex: Int) {
        let isTagsActive = activePageIndex == 0
        titleView.tagTitleBtn.isSelected = isTagsActive
        titleView.topicTitleBtn.isSelected = !isTagsActive
    }
    
}

extension SmallVideoTopicVC: UICollectionViewDataSource, UICollectionViewDelegate {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 2
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        switch SmallVideoTopicMoreListType(rawValue: indexPath.row) {
        case .tag:
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "SmallVideoTopicTagsListItemCell", for: indexPath) as! SmallVideoTopicTagsListItemCell
            return cell
        case .topic:
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "SmallVideoTopicListItemCell", for: indexPath) as! SmallVideoTopicListItemCell
            return cell
        case .none:
            return UICollectionViewCell()
        }
        
    }
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        let currentActivePageIndex = scrollView.contentOffset.x <= scrollView.frame.width / 2 ? 0 : 1
        guard currentActivePageIndex != activePageIndex else { return }
        activePageIndex = currentActivePageIndex
        switchCurrentPageByScrolling(activePageIndex: activePageIndex)
    }
    
}

extension SmallVideoTopicVC: SmallVideoTopicTitleViewDelegate {
    
    func onTitleBtnTap(type: SmallVideoTopicMoreListType) {
        switchCurrentPageByTapping(activePageIndex: type.rawValue)
    }
    
}
