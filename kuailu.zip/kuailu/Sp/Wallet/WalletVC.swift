//
//  WalletVC.swift
//  Sp
//
//  Created by mac on 2020/2/26.
//  Copyright © 2020 mac. All rights reserved.
//


enum WalletInfoType: Int {
    case balance = 0
    case coin = 1
    case coupon = 2
}

class WalletVC: UIViewController {
    
    static var balanceVal: Double = 0.0
    
    static var coinVal: Double = 0
    
    static var exchangeVal: Int = 0
    
    private static let balanceTitleArr: [String] = ["賬戶\(Sensitive.yu)", "\(Sensitive.jin)\(Sensitive.yu)", "\(Sensitive.dui)券"]
    
    private static let balanceBtnTitleArr: [String] = ["\(Sensitive.ti)", "\(Sensitive.ti)", "使用"]
    
    private static let valQuantifierArr: [String] = ["元", "個", "張"]
    
    private static let balanceImgList: [UIImage?] = {
        return [UIImage(named: "wallet_btn_yellow_bg"), UIImage(named: "wallet_btn_yellow_bg"), UIImage(named: "wallet_btn_blue_bg")]
    }()
    
    private static let chargeImgList: [UIImage?] = {
        return [UIImage(named: "wallet_vip_icon"), UIImage(named: "wallet_coin_icon")]
    }()
    
    private static let balanceTableViewRowHeight: CGFloat = 90
    
    private static let chargeTableViewRowHeight: CGFloat = 60
    
    private lazy var balanceTableView: UITableView = {
        let tableView = UITableView(frame: CGRect.zero, style: .plain)
        tableView.delegate = self
        tableView.dataSource = self
        tableView.backgroundColor = .none
        tableView.estimatedRowHeight = 0
        tableView.estimatedSectionFooterHeight = 0
        tableView.estimatedSectionHeaderHeight = 0
        tableView.separatorStyle = .none
        tableView.isScrollEnabled = false
        tableView.rowHeight = WalletVC.balanceTableViewRowHeight
        tableView.register(WalletCell.self, forCellReuseIdentifier: "WalletCell")
        return tableView
    }()
    
    private lazy var splitLine: UIView = {
        let view = UIView()
        view.backgroundColor = RGB(0x1F2022)
        return view
    }()
    
    private lazy var chargeTitleLabel: UILabel = {
        let label = UILabel()
        label.text = "充值中心"
        label.font = UIFont.pingFangRegular(18)
        label.textColor = RGB(0xA8A8A8)
        return label
    }()
    
    private lazy var chargeTableView: UITableView = {
        let tableView = UITableView(frame: CGRect.zero, style: .plain)
        tableView.delegate = self
        tableView.dataSource = self
        tableView.backgroundColor = .none
        tableView.estimatedRowHeight = 0
        tableView.estimatedSectionFooterHeight = 0
        tableView.estimatedSectionHeaderHeight = 0
        tableView.separatorStyle = .none
        tableView.isScrollEnabled = false
        tableView.rowHeight = WalletVC.chargeTableViewRowHeight
        tableView.register(WalletChargeCell.self, forCellReuseIdentifier: "WalletChargeCell")
        return tableView
    }()
    
    override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: Bundle?) {
        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
        hidesBottomBarWhenPushed = true
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationItem.title = "\(Sensitive.qian)"
        view.backgroundColor = RGB(0x141516)
        renderView()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        renderNavigator()
        getAccountInfo()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        if navigationController?.topViewController is MineVC {
            navigationController?.navigationBar.isTranslucent = true
        }
    }
    
    private func renderNavigator() {
        navigationController?.navigationBar.barTintColor = RGB(0x141516)
        navigationController?.navigationBar.isTranslucent = false
        navigationController?.navigationBar.shadowImage = UIImage()
    }
    
    private func getAccountInfo() {
        Session.request(UserAccountInfoReq()) { [weak self] (error, resp) in
            guard let `self` = self, error == nil, let resData = resp as? UserAccountInfo else { return }
            WalletVC.balanceVal = resData.bala
            WalletVC.coinVal = resData.gold
            WalletVC.exchangeVal = resData.welfareNum
            self.balanceTableView.reloadData()
        }
    }
    
    private func renderView() {
        view.addSubview(balanceTableView)
        view.addSubview(splitLine)
        view.addSubview(chargeTitleLabel)
        view.addSubview(chargeTableView)
        
        balanceTableView.snp.makeConstraints { (make) in
            make.top.left.right.equalToSuperview()
            make.height.equalTo(CGFloat(WalletVC.balanceTitleArr.count) * WalletVC.balanceTableViewRowHeight)
        }
        
        splitLine.snp.makeConstraints { (make) in
            make.top.equalTo(balanceTableView.snp.bottom).offset(10)
            make.left.right.equalToSuperview()
            make.height.equalTo(4)
        }
        
        chargeTitleLabel.snp.makeConstraints { (make) in
            make.top.equalTo(splitLine.snp.bottom).offset(28)
            make.left.equalToSuperview().inset(12)
        }
        
        chargeTableView.snp.makeConstraints { (make) in
            make.top.equalTo(chargeTitleLabel.snp.bottom).offset(10)
            make.left.right.equalToSuperview()
            make.height.equalTo(CGFloat(WalletVC.chargeImgList.count) * WalletVC.chargeTableViewRowHeight)
        }
    }
    
    @objc private func onDetailClick() {
        let walletDetailVC = WalletDetailVC()
        walletDetailVC.isBlance = true
        navigationController?.show(walletDetailVC, sender: nil)
    }
}

extension WalletVC: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return tableView == balanceTableView ? WalletVC.balanceTitleArr.count : WalletVC.chargeImgList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let row = indexPath.row
        guard tableView == balanceTableView else {
            let cell = tableView.dequeueReusableCell(withIdentifier: "WalletChargeCell", for: indexPath) as! WalletChargeCell
            cell.iconImgView.image = WalletVC.chargeImgList[row]
            return cell
        }
        let cell: WalletCell = tableView.dequeueReusableCell(withIdentifier: "WalletCell", for: indexPath) as! WalletCell
        cell.delegate = self
        cell.currentIndex = row
        cell.detailsBtn.isHidden = row == 2
        cell.titleLabel.text = WalletVC.balanceTitleArr[row]
        cell.confirmBtn.setTitle(WalletVC.balanceBtnTitleArr[row], for: .normal)
        cell.confirmBtn.setBackgroundImage(WalletVC.balanceImgList[row], for: .normal)
        cell.valLabel.text = (row == 0 ? "\(numberZeroTruncationFormat(WalletVC.balanceVal))" : row == 2 ?  "\(WalletVC.exchangeVal)" : "\(Int(WalletVC.coinVal))") + WalletVC.valQuantifierArr[row]
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        guard tableView == chargeTableView else { return }
        let vipVC = Vip2VC()
        if indexPath.row != 0 {
            vipVC.uiType = .coin
        }
        navigationController?.show(vipVC, sender: nil)
    }
    
}

extension WalletVC: WalletCellDelegate {
    
    func onDetailsBtnTap(index: Int) {
        switch index {
        case 0:
            let walletDetailVC = WalletDetailVC()
            walletDetailVC.isBlance = true
            navigationController?.show(walletDetailVC, sender: nil)
        case 1:
            let walletDetailVC = WalletDetailVC()
            walletDetailVC.isBlance = false
            navigationController?.show(walletDetailVC, sender: nil)
        default:
            break
        }
    }
    
    func onConfirmBtnTap(index: Int) {
        switch index {
        case 0:
            let walletWithdrawVC = WalletWithdrawVC()
            walletWithdrawVC.isBalance = true
            navigationController?.show(walletWithdrawVC, sender: nil)
        case 1:
            let walletWithdrawVC = WalletWithdrawVC()
            walletWithdrawVC.isBalance = false
            navigationController?.show(walletWithdrawVC, sender: nil)
        case 2:
            let exchangeCertificateVC = ExchangeCertificateVC()
            exchangeCertificateVC.hidesBottomBarWhenPushed = true
            navigationController?.show(exchangeCertificateVC, sender: nil)
        default:
            break
        }
    }
    
}
