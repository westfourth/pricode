//
//  WalletreChargeCellTableViewCell.swift
//  Sp
//
//  Created by mac on 2020/9/16.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class WalletChargeCell: UITableViewCell {
    
    private static let arrowImg: UIImage? = {
        return UIImage(named: "ic_right")
    }()
    
    private lazy var arrowIconImgView: UIImageView = {
        return  UIImageView(image: WalletChargeCell.arrowImg)
    }()
    
    lazy var iconImgView: UIImageView = {
        let imgView = UIImageView()
        imgView.contentMode = .scaleAspectFit
        return imgView
    }()
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        backgroundColor = .none
        selectionStyle = .none
        renderView()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func renderView() {
        contentView.addSubview(iconImgView)
        contentView.addSubview(arrowIconImgView)
        
        iconImgView.snp.makeConstraints { (make) in
            make.centerY.equalToSuperview()
            make.left.equalToSuperview().inset(12)
            make.width.equalTo(87)
            make.height.equalTo(24)
        }
   
        arrowIconImgView.snp.makeConstraints { (make) in
            make.centerY.equalToSuperview()
            make.right.equalToSuperview().inset(20)
            make.size.equalTo(16)
        }
        
    }
    
}
