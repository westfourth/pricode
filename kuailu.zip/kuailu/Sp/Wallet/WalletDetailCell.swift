//
//  WalletDetailCell.swift
//  Sp
//
//  Created by mac on 2020/2/27.
//  Copyright © 2020 mac. All rights reserved.
//


class WalletDetailCell: UITableViewCell {
    
    static let formatDate: DateFormatter = {
        let f = DateFormatter()
        f.dateFormat = "yyyy-MM-dd HH:mm:ss"
        return f
    }()
    
    private lazy var titleLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.pingFangMedium(16)
        label.textColor = .white
        label.numberOfLines = 1
        return label
    }()
    
    private lazy var remarkLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.pingFangMedium(13)
        label.numberOfLines = 1
        label.textColor = .white
        return label
    }()
    
    private lazy var dateTime: UILabel = {
        let label = UILabel()
        label.font = UIFont.pingFangMedium(13)
        label.numberOfLines = 1
        label.textColor = RGB(0x848484)
        return label
    }()
    
    private lazy var amountVal: UILabel = {
        let label = UILabel()
        label.font =  UIFont.pingFangMedium(16)
        return label
    }()
    
    private lazy var splitLine: UIView = {
        let view = UIView()
        view.backgroundColor = RGB(0x2D2D2D)
        return view
    }()
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        backgroundColor = .none
        selectionStyle = .none
        rendView()
    }
    
    var dataModel: TrandeHistoryItem? {
        didSet{
            guard let item = dataModel else { return }
            titleLabel.text = item.desc
            let isEmpty = item.remark.isEmpty
            if !isEmpty {
                remarkLabel.text = "備註： \(item.remark)"
            }
            remarkLabel.isHidden = isEmpty
            dateTime.text = "交易時間: \(WalletDetailCell.formatDate.string(from: item.createdAt ?? Date()))"
            let isIncome = item.mark == .profit
            amountVal.textColor = isIncome ? .white : RGB(0xFF2C2C)
            amountVal.text =  "\(isIncome ? "+" : "-")\(numberZeroTruncationFormat(item.amount))"
        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func rendView() {
        contentView.addSubview(titleLabel)
        contentView.addSubview(remarkLabel)
        contentView.addSubview(dateTime)
        contentView.addSubview(amountVal)
        contentView.addSubview(splitLine)
        
        titleLabel.snp.makeConstraints { (make) in
            make.top.equalToSuperview().inset(12)
            make.left.equalToSuperview().inset(12)
            make.right.equalToSuperview().inset(70)
        }
        
        remarkLabel.snp.makeConstraints { (make) in
            make.top.equalTo(titleLabel.snp.bottom).offset(5)
            make.left.equalTo(titleLabel)
            make.right.equalToSuperview().inset(70)
        }
        
        dateTime.snp.makeConstraints { (make) in
            make.left.equalTo(titleLabel)
            make.bottom.equalToSuperview().inset(12)
        }
        
        amountVal.snp.makeConstraints { (make) in
            make.centerY.equalToSuperview()
            make.right.equalToSuperview().inset(12)
        }
        
        splitLine.snp.makeConstraints { (make) in
            make.left.right.equalToSuperview().inset(12)
            make.height.equalTo(0.5)
            make.bottom.equalToSuperview()
        }
    }
}
