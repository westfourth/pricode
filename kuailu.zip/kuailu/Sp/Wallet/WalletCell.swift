//
//  WalletCell.swift
//  Sp
//
//  Created by mac on 2020/4/30.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

protocol WalletCellDelegate: NSObjectProtocol {
    
    func onConfirmBtnTap(index: Int)
    
    func onDetailsBtnTap(index: Int)
    
}

class WalletCell: UITableViewCell {
    
    lazy var titleLabel: UILabel = {
        let label = UILabel()
        label.textColor = RGB(0xA8A8A8)
        label.font = UIFont.pingFangRegular(13)
        return label
    }()
    
    lazy var valLabel: UILabel = {
        let label = UILabel()
        label.textColor = .white
        label.font = UIFont.pingFangRegular(30)
        return label
    }()
    
    lazy var detailsBtn: UIButton = {
        let btn = UIButton()
        btn.setTitle("明細", for: .normal)
        btn.setTitleColor(RGB(0xFA6400), for: .normal)
        btn.titleLabel?.font = UIFont.pingFangRegular(13)
        btn.layer.masksToBounds = true
        btn.layer.cornerRadius = 13
        btn.layer.borderColor = RGB(0xFA6400).cgColor
        btn.layer.borderWidth = 1
        btn.addTarget(self, action: #selector(onDetailsBtnTap), for: .touchUpInside)
        btn.isHidden = true
        return btn
    }()
    
    lazy var confirmBtn: UIButton = {
        let btn = UIButton()
        btn.setTitleColor(.white, for: .normal)
        btn.titleLabel?.font = UIFont.pingFangRegular(13)
        btn.addTarget(self, action: #selector(onConfirmBtnTap), for: .touchUpInside)
        return btn
    }()
    
    weak var delegate: WalletCellDelegate?
    
    var currentIndex: Int = 0
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        backgroundColor = .none
        selectionStyle = .none
        rendView()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func rendView() {
        contentView.addSubview(titleLabel)
        contentView.addSubview(valLabel)
        contentView.addSubview(confirmBtn)
        contentView.addSubview(detailsBtn)
        
        titleLabel.snp.makeConstraints { (make) in
            make.left.equalToSuperview().inset(12)
            make.top.equalToSuperview().inset(10)
        }
        
        valLabel.snp.makeConstraints { (make) in
            make.left.equalToSuperview().inset(12)
            make.top.equalTo(titleLabel.snp.bottom).offset(6)
        }
        
        confirmBtn.snp.makeConstraints { (make) in
            make.centerY.equalTo(valLabel)
            make.right.equalToSuperview().inset(18)
            make.width.equalTo(83)
            make.height.equalTo(30)
        }
        
        detailsBtn.snp.makeConstraints { (make) in
            make.centerY.equalTo(confirmBtn)
            make.right.equalTo(confirmBtn.snp.left).offset(-24)
            make.width.equalTo(80)
            make.height.equalTo(26)
        }
    }
    
    @objc private func onConfirmBtnTap() {
        delegate?.onConfirmBtnTap(index: currentIndex)
    }
    
    @objc private func onDetailsBtnTap() {
        delegate?.onDetailsBtnTap(index: currentIndex)
    }
}
