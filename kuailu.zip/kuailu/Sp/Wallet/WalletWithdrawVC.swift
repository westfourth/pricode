//
//  WalletWithdrawVC.swift
//  Sp
//
//  Created by mac on 2020/2/27.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

private enum WalletWithdrawType {
    case ali
    case bank
}

class WalletWithdrawVC: UIViewController {
    
    private static let characterSet: CharacterSet = {
        let inputLimitCharacters: String = "0123456789"
        return NSCharacterSet(charactersIn: inputLimitCharacters).inverted
    }()
    
    private static var walletWithdrawType: WalletWithdrawType = .ali
    
    private static var firstItemParamsValArr:[[String]] = [["姓名","\u{652f}\u{4ed8}\u{5bf6}賬戶"],["請輸入姓名","請輸入\u{652f}\u{4ed8}\u{5bf6}賬戶"]]
    
    private static var secondItemParamsValArr: [[String]] = [["姓名","\u{9280}\u{884c}卡"
        ]
        ,["請輸入姓名","請輸入\u{9280}\u{884c}卡號"
        ]]
    
    private lazy var tipLabel: UILabel = {
        let label = UILabel()
        label.text = "提取\(Sensitive.e)(收取\(isBalance ? "10%" : "30%")手續費)"
        label.textColor = RGB(0xA8A8A8)
        label.font = UIFont.pingFangRegular(13)
        return label
    }()
    
    private lazy var amountSymbolLabel: UILabel = {
        let label = UILabel()
        label.text = "¥"
        label.textColor = .white
        label.font = UIFont.pingFangHeavy(21)
        return label
    }()
    
    private lazy var balanceLabel: UILabel = {
        let label = UILabel()
        label.text = isBalance ? "\(Sensitive.yu)" : "\(Sensitive.jin)"
        label.textColor = RGB(0xA8A8A8)
        label.font = UIFont.pingFangRegular(14)
        return label
    }()
    
    private lazy var ruleLabel: UILabel = {
        let label = UILabel()
        label.text = "(滿\(Int(lowestLimit))可\(Sensitive.ti)，最高額度\(Int(highestLimit)))"
        label.textColor = RGB(0xA8A8A8)
        label.font = UIFont.pingFangRegular(13)
        return label
    }()
    
    private lazy var balanceValLabel: UILabel = {
        let label = UILabel()
        label.text = isBalance ? numberZeroTruncationFormat(WalletVC.balanceVal) : "\(Int(WalletVC.coinVal))"
        label.textColor = RGB(0xFA6400)
        label.font = UIFont.pingFangRegular(14)
        return label
    }()
    
    private lazy var highestExchangeValLabel: UILabel = {
        let label = UILabel()
        guard !isBalance else { return label }
        let attributes = [NSAttributedString.Key.font: UIFont.pingFangRegular(14),
                          NSAttributedString.Key.foregroundColor: RGB(0xA8A8A8)]
        let val = Int(Double(self.balanceValLabel.text ?? "0")! / 10)
        let strAttributes = NSMutableAttributedString(string: "可\(Sensitive.dui) \(val) 元", attributes: attributes)
        strAttributes.addAttributes([ NSAttributedString.Key.foregroundColor: UIColor.white],range: NSRange(location: 4, length: "\(val)".count))
        label.attributedText = strAttributes
        return label
    }()
    
    private lazy var allWidthdrawBtn: UIButton = {
        let btn = UIButton()
        btn.setTitle("全部\(Sensitive.ti)", for: .normal)
        btn.setTitleColor(RGB(0xFA6400), for: .normal)
        btn.titleLabel?.font = UIFont.pingFangRegular(16)
        btn.addTarget(self, action: #selector(onWithdrawAllClick), for: .touchUpInside)
        return btn
    }()
    
    private lazy var leftTabbar: UIButton = {
        return renderTabBar(title: "\(Sensitive.ti)到\u{652f}\u{4ed8}\u{5bf6}", action: #selector(onLeftTabBarClick),index: 0)
    }()
    
    private lazy var rightTabbar: UIButton = {
        return renderTabBar(title: "\(Sensitive.ti)到\u{9280}\u{884c}卡", action: #selector(onRightTabBarClick),index: 1)
    }()
    
    private lazy var indicatorLine: UIView = {
        let line = UIView()
        line.backgroundColor = RGB(0xFA6400)
        line.layer.cornerRadius = 1.5
        line.clipsToBounds = true
        return line
    }()
    
    private lazy var confirmGradientLayer: CAGradientLayer = {
        let gradientColors = [RGB(0xFE6000).cgColor, RGB(0xFC9239).cgColor]
        let gradientLocations:[NSNumber] = [0, 1]
        let gradientLayer = CAGradientLayer()
        gradientLayer.colors = gradientColors
        gradientLayer.locations = gradientLocations
        gradientLayer.startPoint = CGPoint(x: 0, y: 1)
        gradientLayer.endPoint  = CGPoint(x: 1.0, y: 1)
        gradientLayer.frame = CGRect(x: 0, y: 0, width: 270, height: 44)
        return gradientLayer
    }()
    
    private lazy var confirmBtn: UIButton = {
        let btn = UIButton()
        btn.setTitleColor(.white, for: .normal)
        btn.setTitle("確認\(Sensitive.ti)", for: .normal)
        btn.titleLabel?.font = UIFont.pingFangRegular(17)
        btn.backgroundColor = RGB(0x999999)
        btn.clipsToBounds = true
        btn.layer.cornerRadius = 20
        btn.addTarget(self, action: #selector(onConfirmBtnClick), for: .touchUpInside)
        btn.layer.insertSublayer(confirmGradientLayer, at: 0)
        return btn
    }()
    
    private lazy var inputField: UITextField = {
        let input  = UITextField()
        input.placeholder = "0"
        input.text = ""
        input.textColor = .white
        input.setValue(RGB(0xA8A8A8), forKeyPath: "placeholderLabel.textColor")
        input.setValue(UIFont.pingFangRegular(28), forKeyPath: "placeholderLabel.font")
        input.font = UIFont.pingFangRegular(28)
        input.delegate = self
        input.textAlignment = .left
        input.keyboardType = .numberPad
        input.returnKeyType = .done
        input.addDoneOnKeyboardWithTarget(self, action: #selector(onConfirmBtnClick))
        input.addTarget(self, action: #selector(onInputFieldChanged), for: .editingChanged)
        return input
    }()
    
    private lazy var aliTableView: UITableView = {
        let tableView = UITableView(frame: CGRect.zero, style: .plain)
        tableView.delegate = self
        tableView.dataSource = self
        tableView.backgroundColor = .none
        tableView.isScrollEnabled = false
        tableView.estimatedRowHeight = 0
        tableView.estimatedSectionFooterHeight = 0
        tableView.estimatedSectionHeaderHeight = 0
        tableView.showsVerticalScrollIndicator = false
        tableView.separatorColor = RGB(0x25264D)
        tableView.rowHeight = 50
        tableView.register(WalletWithdrawCell.self, forCellReuseIdentifier: "WalletWithdrawAliCell")
        return tableView
    }()
    
    private lazy var bankTableView: UITableView = {
        let tableView = UITableView(frame: CGRect.zero, style: .plain)
        tableView.delegate = self
        tableView.dataSource = self
        tableView.backgroundColor = .none
        tableView.isScrollEnabled = false
        tableView.estimatedRowHeight = 0
        tableView.estimatedSectionFooterHeight = 0
        tableView.estimatedSectionHeaderHeight = 0
        tableView.showsVerticalScrollIndicator = false
        tableView.separatorColor = RGB(0x25264D)
        tableView.isHidden = true
        tableView.rowHeight = 50
        tableView.register(WalletWithdrawCell.self, forCellReuseIdentifier: "WalletWithdrawBankCell")
        return tableView
    }()
    
    private lazy var ruleTipView: UILabel = {
        let label = UILabel()
        label.numberOfLines = 0
        let ruleTipText = """
        溫馨提示:
        1、請填寫正確的\u{652f}\u{4ed8}\u{5bf6}賬號及姓名，如信息填寫錯誤可能導致\(Sensitive.ti)失敗
        2、\(Sensitive.ti)到賬時間為1-2個工作日，請隨時留意\u{9280}\u{884c}賬單狀態注意查收
        3、您的個人信息將嚴格保密，不會用於任何第三方
        """
        let paraph = NSMutableParagraphStyle()
        paraph.lineSpacing = 6 // 字型的行間距
        let attributes = [NSAttributedString.Key.font: UIFont.pingFangRegular(12),
                          NSAttributedString.Key.foregroundColor: RGB(0x868787),
                          NSAttributedString.Key.paragraphStyle: paraph]
        label.attributedText = NSAttributedString(string: ruleTipText, attributes: attributes)
        return label
    }()
    
    private lazy var confirmTipLabel: UILabel = {
        let label = UILabel()
        label.textColor = RGB(0x383838)
        label.font = UIFont.pingFangRegular(22)
        return label
    }()
    
    private lazy var alertConfirmIcon: UIImageView = {
        return UIImageView(image: UIImage(named: "alert_confirm"))
    }()
    
    private lazy var confirmAlertGradientLayer: CAGradientLayer = {
        let gradientColors = [RGB(0xFE6000).cgColor, RGB(0xFC9239).cgColor]
        let gradientLocations:[NSNumber] = [0, 1]
        let gradientLayer = CAGradientLayer()
        gradientLayer.colors = gradientColors
        gradientLayer.locations = gradientLocations
        gradientLayer.startPoint = CGPoint(x: 0, y: 1)
        gradientLayer.endPoint  = CGPoint(x: 1.0, y: 1)
        gradientLayer.frame = CGRect(x: 0, y: 0, width: 288 - 18 * 2, height: 36)
        return gradientLayer
    }()
    
    private lazy var confirmAlertBtn: UIButton = {
        let btn = UIButton()
        btn.setTitleColor(.white, for: .normal)
        btn.setTitle("確定", for: .normal)
        btn.titleLabel?.font = UIFont.pingFangRegular(16)
        btn.backgroundColor = RGB(0xFE6000)
        btn.clipsToBounds = true
        btn.layer.cornerRadius = 4
        btn.addTarget(self, action: #selector(onConfirmAlertBtnClick), for: .touchUpInside)
        btn.layer.insertSublayer(confirmAlertGradientLayer, at: 0)
        return btn
    }()
    
    private lazy var confirmAlertContentView: UIView = {
        let view = UIView()
        view.backgroundColor = .white
        view.layer.cornerRadius = 12
        view.clipsToBounds = true
        view.addSubview(confirmTipLabel)
        view.addSubview(alertConfirmIcon)
        view.addSubview(confirmAlertBtn)
        
        confirmTipLabel.snp.makeConstraints { (make) in
            make.top.equalToSuperview().offset(40)
            make.centerX.equalToSuperview()
        }
        
        alertConfirmIcon.snp.makeConstraints { (make) in
            make.centerX.equalToSuperview()
            make.top.equalTo(confirmTipLabel.snp.bottom).offset(11)
            make.size.equalTo(63)
        }
        
        confirmAlertBtn.snp.makeConstraints { (make) in
            make.bottom.equalToSuperview().inset(16)
            make.left.right.equalToSuperview().inset(18)
            make.height.equalTo(36)
        }
        return view
    }()
    
    private lazy var confirmAlert: CustomMBProgressHUD = {
        let hud = CustomMBProgressHUD(view: self.view)
        self.view.addSubview(hud)
        hud.customView = confirmAlertContentView
        confirmAlertContentView.snp.makeConstraints { (make) in
            make.width.equalTo(288)
            make.height.equalTo(231)
        }
        return hud
    }()
    
    private var withdrawName = ""
    
    private var withdrawAccount = ""
    
    private let exchangeRate: Double = 10
    
    private lazy var lowestLimit: Double = 100
    
    private lazy var highestLimit: Double = 10000
    
    private var isSubmitEnabled: Bool = false {
        didSet{
            switchSubmitBtnEnabled()
        }
    }
    
    var isBalance: Bool = true
    
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationItem.title = isBalance ? "\(Sensitive.yu)\(Sensitive.ti)" : "\(Sensitive.jin)\(Sensitive.ti)"
        view.backgroundColor = RGB(0x141516)
        renderView()
        getAccountInfo()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.navigationBar.barTintColor = RGB(0x141516)
        navigationController?.navigationBar.isTranslucent = false
    }
    
    private func renderView() {
        view.addSubview(tipLabel)
        view.addSubview(amountSymbolLabel)
        view.addSubview(inputField)
        view.addSubview(balanceLabel)
        view.addSubview(balanceValLabel)
        view.addSubview(allWidthdrawBtn)
        view.addSubview(highestExchangeValLabel)
        view.addSubview(ruleLabel)
        view.addSubview(leftTabbar)
        view.addSubview(rightTabbar)
        view.addSubview(indicatorLine)
        view.addSubview(aliTableView)
        view.addSubview(bankTableView)
        view.addSubview(ruleTipView)
        view.addSubview(confirmBtn)
        leftTabbar.isSelected = true
        tipLabel.snp.makeConstraints { (make) in
            make.top.equalToSuperview().inset(10)
            make.left.equalToSuperview().inset(12)
        }
        amountSymbolLabel.snp.makeConstraints { (make) in
            make.top.equalTo(tipLabel.snp.bottom).offset(20)
            make.left.equalToSuperview().inset(15)
        }
        inputField.snp.makeConstraints { (make) in
            make.right.equalToSuperview().inset(12)
            make.left.equalTo(amountSymbolLabel.snp.right).offset(14)
            make.centerY.equalTo(amountSymbolLabel)
        }
        renderSeparateLine(lastView: inputField, topMarginVal: 4)
        balanceLabel.snp.makeConstraints { (make) in
            make.left.equalToSuperview().inset(12)
            make.top.equalTo(inputField.snp.bottom).offset(16)
        }
        balanceValLabel.snp.makeConstraints { (make) in
            make.centerY.equalTo(balanceLabel)
            make.left.equalTo(balanceLabel.snp.right).offset(3)
        }
        allWidthdrawBtn.snp.makeConstraints { (make) in
            make.centerY.equalTo(balanceLabel)
            make.right.equalToSuperview().inset(12)
        }
        highestExchangeValLabel.snp.makeConstraints { (make) in
            make.centerY.equalTo(balanceLabel)
            make.left.equalTo(balanceValLabel.snp.right).offset(3)
            make.right.equalTo(allWidthdrawBtn.snp.left).offset(-10)
        }
        
        ruleLabel.snp.makeConstraints { (make) in
            make.top.equalTo(allWidthdrawBtn.snp.bottom)
            make.right.equalTo(allWidthdrawBtn)
        }
        renderSeparateLine(lastView: ruleLabel, topMarginVal: 8)
        leftTabbar.snp.makeConstraints { (make) in
            make.centerY.equalTo(ruleLabel.snp.centerY).offset(50)
            make.left.equalToSuperview().inset(58)
        }
        rightTabbar.snp.makeConstraints { (make) in
            make.centerY.equalTo(leftTabbar)
            make.right.equalToSuperview().inset(58)
        }
        indicatorLine.snp.makeConstraints { (make) in
            make.top.equalTo(leftTabbar.snp.bottom).offset(6)
            make.width.equalTo(97)
            make.height.equalTo(3)
            make.centerX.equalTo(leftTabbar)
        }
        aliTableView.snp.makeConstraints { (make) in
            make.top.equalTo(indicatorLine.snp.bottom).offset(10)
            make.left.right.equalToSuperview()
            make.height.equalTo(44 * 2)
        }
        bankTableView.snp.makeConstraints { (make) in
            make.top.equalTo(indicatorLine.snp.bottom).offset(10)
            make.left.right.equalToSuperview()
            make.height.equalTo(44 * 2)
        }
        ruleTipView.snp.makeConstraints { (make) in
            make.top.equalTo(aliTableView.snp.bottom).offset(30)
            make.left.right.equalToSuperview().inset(8)
        }
        confirmBtn.snp.makeConstraints { (make) in
            make.centerX.equalToSuperview()
            make.bottom.equalToSuperview().inset(40)
            make.width.equalTo(270)
            make.height.equalTo(44)
        }
    }
    
    @objc private func onWithdrawAllClick() {
        let amount = isBalance ? WalletVC.balanceVal : WalletVC.coinVal
        guard amount > 0 else { return }
        inputField.text =  "\(Int(isBalance ? WalletVC.balanceVal : (WalletVC.coinVal / 10)))"
        onInputFieldChanged()
    }
    
    @objc private func onLeftTabBarClick() {
        WalletWithdrawVC.walletWithdrawType = .ali
        leftTabbar.isSelected = true
        rightTabbar.isSelected = false
        bankTableView.isHidden = true
        aliTableView.isHidden = false
        checkWithdrawStatus()
        indicatorLine.snp.remakeConstraints { (make) in
            make.top.equalTo(leftTabbar.snp.bottom).offset(6)
            make.width.equalTo(97)
            make.height.equalTo(3)
            make.centerX.equalTo(leftTabbar)
        }
        updateConstraints()
    }
    
    @objc private func onRightTabBarClick() {
        WalletWithdrawVC.walletWithdrawType = .bank
        leftTabbar.isSelected = false
        rightTabbar.isSelected = true
        aliTableView.isHidden = true
        bankTableView.isHidden = false
        checkWithdrawStatus()
        indicatorLine.snp.remakeConstraints { (make) in
            make.top.equalTo(leftTabbar.snp.bottom).offset(6)
            make.width.equalTo(97)
            make.height.equalTo(3)
            make.centerX.equalTo(rightTabbar)
        }
        updateConstraints()
    }
    
    private func updateConstraints() {
        indicatorLine.needsUpdateConstraints()
        indicatorLine.updateConstraintsIfNeeded()
        UIView.animate(withDuration: 0.2) { [weak self] in
            self?.view.layoutIfNeeded()
        }
    }
    
    private func getAccountInfo() {
        let req = AccountInfoReq()
        Session.request(req) { [weak self] (error, resp) in
            guard let `self` = self, error == nil, let resData = resp as? AccountInfo else { return }
            WalletVC.balanceVal = resData.bala
            WalletVC.coinVal = resData.gold
            self.balanceValLabel.text = self.isBalance ? numberZeroTruncationFormat(WalletVC.balanceVal) : "\(Int(WalletVC.coinVal))"
            guard !self.isBalance else {
                self.checkWithdrawStatus()
                return
            }
            let attributes = [NSAttributedString.Key.font: UIFont.pingFangRegular(14),
                              NSAttributedString.Key.foregroundColor: RGB(0xA8A8A8)]
            let val = Int(Double(self.balanceValLabel.text ?? "0")! / 10)
            let strAttributes = NSMutableAttributedString(string: "可\(Sensitive.dui) \(val) 元", attributes: attributes)
            strAttributes.addAttributes([ NSAttributedString.Key.foregroundColor: UIColor.white],range: NSRange(location: 4, length: "\(val)".count))
            self.highestExchangeValLabel.attributedText = strAttributes
            self.checkWithdrawStatus()
        }
    }
    
    private func submitWithdrawInfo() {
        guard let text = inputField.text, let money = Double(text) else { return }
        confirmAlert.hide(animated: false)
        Alert.showLoading(parentView: self.view)
        let req = WithDrawReq()
        req.money = isBalance ? money : money * 10
        let isAli = WalletWithdrawVC.walletWithdrawType == .ali
        req.accountNo = withdrawAccount
        req.receiptName = withdrawName
        req.payType = isAli ? 1 : 2
        req.purType = isBalance ? 1 : 2
        Session.request(req) { [weak self] (error, resp) in
            Alert.hideLoading()
            guard let `self` = self else { return }
            self.getAccountInfo()
            guard error == nil else {
                mm_showToast(error?.localizedDescription ?? "\(Sensitive.ti)失敗！")
                return
            }
            self.confirmTipLabel.text = "成功申請\(Sensitive.ti)\(numberZeroTruncationFormat(money))元"
            self.confirmAlert.show(animated: true)
        }
    }
    
    @objc private func onConfirmAlertBtnClick() {
        confirmAlert.hide(animated: true)
    }
    
    @objc private func onInputFieldChanged() {
        checkWithdrawStatus()
    }
    
    private func checkInputField()-> Bool {
        
        guard var text = inputField.text else {
            return false
        }
        
        if text.hasPrefix("0") {
            text = String(text.dropFirst())
            inputField.text = text
        }
        
        guard text != "" else {
            return false
        }
        
        let amount = isBalance ? WalletVC.balanceVal : (WalletVC.coinVal / 10)
        
        guard let withdrawVal =  Double(text) else {
            return false
        }
        
        guard withdrawVal <= amount && withdrawVal <= highestLimit && withdrawVal >= lowestLimit else {
            return false
        }
        return true
    }
    
    private func checkWithdrawInfo()-> Bool {
        var name = ""
        var account = ""
        let firstCell = IndexPath(row: 0, section: 0)
        let secondCell = IndexPath(row: 1, section: 0)
        let isAli = WalletWithdrawVC.walletWithdrawType == .ali
        if isAli {
            name = (aliTableView.cellForRow(at: firstCell) as! WalletWithdrawCell).inputField.text ?? ""
            account = (aliTableView.cellForRow(at: secondCell) as! WalletWithdrawCell).inputField.text ?? ""
        } else {
            name = (bankTableView.cellForRow(at: firstCell) as! WalletWithdrawCell).inputField.text ?? ""
            account = (bankTableView.cellForRow(at: secondCell) as! WalletWithdrawCell).inputField.text ?? ""
        }
        withdrawName = name
        withdrawAccount = account
        return !name.isEmpty && !account.isEmpty
    }
    
    private func switchSubmitBtnEnabled() {
        confirmBtn.backgroundColor = isSubmitEnabled ? RGB(0xF86104) : RGB(0x999999)
    }
    
    private func renderSeparateLine(lastView: UIView, topMarginVal: Int) {
        let line = UIView()
        line.backgroundColor = RGB(0x25264D)
        view.addSubview(line)
        line.snp.makeConstraints { (make) in
            make.top.equalTo(lastView.snp.bottom).offset(topMarginVal)
            make.left.right.equalToSuperview().inset(12)
            make.height.equalTo(0.5)
        }
    }
    
    private func renderTabBar(title: String, action: Selector, index: Int)-> UIButton {
        let btn = UIButton()
        btn.setTitle(title, for: .normal)
        btn.setTitleColor(UIColor.white.withAlphaComponent(0.5), for: .normal)
        btn.setTitleColor(.white, for: .selected)
        btn.titleLabel?.font = UIFont.pingFangRegular(14)
        btn.addTarget(self, action: index == 0 ? #selector(onLeftTabBarClick) : #selector(onRightTabBarClick), for: .touchUpInside)
        return btn
    }
    
}

extension WalletWithdrawVC: WalletWithdrawCellDelegate {
    
    func checkWithdrawStatus() {
        isSubmitEnabled = checkInputField() && checkWithdrawInfo()
    }
    
    @objc func onConfirmBtnClick() {
        inputField.resignFirstResponder()
        checkWithdrawStatus()
        guard isSubmitEnabled else { return }
        submitWithdrawInfo()
    }
}

extension WalletWithdrawVC: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return  2
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let row = indexPath.row
        let isAli = tableView == aliTableView
        let cell: WalletWithdrawCell  = tableView.dequeueReusableCell(withIdentifier: isAli ? "WalletWithdrawAliCell" : "WalletWithdrawBankCell", for: indexPath) as! WalletWithdrawCell
        let currentData = isAli ? WalletWithdrawVC.firstItemParamsValArr : WalletWithdrawVC.secondItemParamsValArr
        cell.ruleLabel.text = currentData[0][row]
        cell.inputField.placeholder = currentData[1][row]
        cell.delegate = self
        if row == 1 && !isAli  {
            cell.inputField.keyboardType = .numberPad
        }
        return cell
    }
}


extension WalletWithdrawVC: UITextFieldDelegate {
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        let filtered = string.components(separatedBy: WalletWithdrawVC.characterSet).joined(separator: "")
        guard string == filtered else { return false }
        guard string == "0" else {
            //            guard string != "." else { return false }
            return true
        }
        guard let text = textField.text else { return true }
        if text.count == 0 {
            textField.text = ""
            return false
        }
        return true
    }
}
