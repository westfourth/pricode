//
//  WalletWithdrawCell.swift
//  Sp
//
//  Created by mac on 2020/2/27.
//  Copyright © 2020 mac. All rights reserved.
//


protocol WalletWithdrawCellDelegate: NSObjectProtocol {
    
    func checkWithdrawStatus()
    
    func onConfirmBtnClick()
}

class WalletWithdrawCell: UITableViewCell {
    
    weak var delegate: WalletWithdrawCellDelegate?
    
    lazy var ruleLabel: UILabel = {
        let label = UILabel()
        label.textColor = .white
        label.font = UIFont.pingFangRegular(14)
        return label
    }()
    
    lazy var inputField: UITextField = {
        let input  = UITextField()
        input.delegate = self
        input.textColor = .white
        input.text = ""
        input.font = UIFont.pingFangRegular(14)
        input.placeholder = " "
        input.textAlignment = .right
        input.setValue(UIColor.white.withAlphaComponent(0.5), forKeyPath: "placeholderLabel.textColor")
        input.setValue(UIFont.pingFangRegular(14), forKeyPath: "placeholderLabel.font")
        input.returnKeyType = .done
        input.addDoneOnKeyboardWithTarget(self, action: #selector(onKeybordDoneClick))
        input.addTarget(self, action: #selector(onInputFieldChanged), for: .editingChanged)
        return input
    }()
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        backgroundColor = .none
        selectionStyle = .none
        renderView()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func renderView() {
        contentView.addSubview(ruleLabel)
        contentView.addSubview(inputField)
        
        ruleLabel.snp.makeConstraints { (make) in
            make.centerY.equalToSuperview()
            make.left.equalToSuperview().inset(12)
        }
        
        inputField.snp.makeConstraints { (make) in
            make.centerY.equalToSuperview()
            make.right.equalToSuperview().inset(12)
            make.left.equalTo(ruleLabel.snp.right).offset(10)
        }
    }
    
    @objc private func onInputFieldChanged() {
        inputField.text = inputField.text!.trimmingCharacters(in: .whitespacesAndNewlines)
        delegate?.checkWithdrawStatus()
    }
    
    @objc private func onKeybordDoneClick() {
        delegate?.onConfirmBtnClick()
        inputField.resignFirstResponder()
    }
}

extension WalletWithdrawCell: UITextFieldDelegate {
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        onKeybordDoneClick()
        return true
    }
}
