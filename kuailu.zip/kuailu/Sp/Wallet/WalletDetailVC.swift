//
//  WalletDetailVC.swift
//  Sp
//
//  Created by mac on 2020/2/27.
//  Copyright © 2020 mac. All rights reserved.
//


class WalletDetailVC: UIViewController {
    
    private static let emptyImg: UIImage = {
        return UIImage()
    }()
    
    private lazy var monthBar: UIButton = {
        let btn = UIButton()
        btn.addSubview(monthLabel)
        btn.addSubview(arrowIcon)
        monthLabel.snp.makeConstraints { (make) in
            make.centerY.equalToSuperview()
            make.left.equalToSuperview()
        }
        arrowIcon.snp.makeConstraints { (make) in
            make.centerY.equalToSuperview()
            make.left.equalTo(monthLabel.snp.right).offset(6)
            make.size.equalTo(16)
        }
        btn.addTarget(self, action: #selector(onMonthBarClick), for: .touchUpInside)
        return btn
    }()
    
    private lazy var monthLabel: UILabel = {
        let label = UILabel()
        label.text = "本月"
        label.textColor = RGB(0xA8A8A8)
        label.font = UIFont.pingFangRegular(15)
        return label
    }()
    
    private lazy var arrowIcon: UIImageView = {
        return UIImageView(image: UIImage(named: "arrow_down_white"))
    }()
    
    private lazy var withdrawTableView: UITableView = {
        let tableView = UITableView(frame: .zero, style: .plain)
        tableView.delegate = self
        tableView.dataSource = self
        tableView.backgroundColor = .none
        tableView.estimatedRowHeight = 0
        tableView.estimatedSectionFooterHeight = 0
        tableView.estimatedSectionHeaderHeight = 0
        tableView.separatorStyle = .none
        tableView.register(WalletDetailCell.self, forCellReuseIdentifier: "WalletDetailCell")
        return tableView
    }()
    
    private lazy var datePickerCancelBtn: UIButton = {
        let btn = UIButton()
        btn.setTitleColor(.black, for: .normal)
        btn.setTitle("取消", for: .normal)
        btn.titleLabel?.font = UIFont.pingFangRegular(22)
        btn.addTarget(self, action: #selector(onDatePickerCancelClick), for: .touchUpInside)
        return btn
    }()
    
    private lazy var datePickerConfirmBtn: UIButton = {
        let btn = UIButton()
        btn.setTitleColor(RGB(0xFA6400), for: .normal)
        btn.setTitle("確定", for: .normal)
        btn.titleLabel?.font = UIFont.pingFangRegular(22)
        btn.addTarget(self, action: #selector(onDatePickerConfirmClick), for: .touchUpInside)
        return btn
    }()
    
    private lazy var datePickerView: UIView = {
        let view = UIView()
        let tap = UITapGestureRecognizer(target: self, action: #selector(onDatePickerMaskClick))
        view.addGestureRecognizer(tap)
        view.backgroundColor = UIColor.black.withAlphaComponent(0.3)
        view.alpha = 0
        view.addSubview(datePicker)
        view.addSubview(datePickerCancelBtn)
        view.addSubview(datePickerConfirmBtn)
        
        datePicker.snp.makeConstraints { (make) in
            make.left.right.equalToSuperview()
            make.height.equalTo(235 + 16)
            make.bottom.equalToSuperview().offset(235 + 16)
        }
        
        datePickerCancelBtn.snp.makeConstraints { (make) in
            make.top.equalTo(datePicker.snp.top).offset(12)
            make.left.equalToSuperview().inset(18)
        }
        
        datePickerConfirmBtn.snp.makeConstraints { (make) in
            make.top.equalTo(datePicker.snp.top).offset(12)
            make.right.equalToSuperview().inset(18)
        }
        return view
    }()
    
    private lazy var datePicker: UIPickerView = {
        let datePicker = UIPickerView()
        datePicker.dataSource = self
        datePicker.delegate = self
        //让pickerView预设选中中间项
        datePicker.selectRow(lastRow, inComponent: 1, animated: false)
        datePicker.backgroundColor = .white
        datePicker.clipsToBounds = true
        datePicker.layer.cornerRadius = 14
        return datePicker
    }()
    
    private let pickerMonthSize: Int = 1200
    
    private lazy var  pickerYearData: [String] = {
        return ["\(currentYear)年"]
    }()
    
    private lazy var pickerMonthData: [String] = {
        return ["1月", "2月", "3月", "4月", "5月", "6月",
                "7月", "8月", "9月", "10月", "11月", "12月"]
    }()
    
    var walletList: [TrandeHistoryItem] = [] {
        didSet{
            withdrawTableView.reloadData()
        }
    }
    
    private lazy var lastRow: Int = {
        return currentMonth - 1 + pickerMonthSize / 2
    }()
    
    private var tempRow: Int = 0
    
    private lazy var currentYear: Int = {
        return  Calendar.current.component(.year, from: Date())
    }()
    
    private lazy var currentMonth: Int = {
        return  Calendar.current.component(.month, from: Date())
    }()
    
    var isBlance: Bool = true
    
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationItem.title = isBlance ? "\(Sensitive.yu)明細" : "\(Sensitive.jin)明細"
        view.backgroundColor = RGB(0x141516)
        navigationItem.rightBarButtonItem = UIBarButtonItem(customView: monthBar)
        monthBar.snp.makeConstraints { (make) in
            make.width.equalTo(50)
            make.height.equalTo(48)
        }
        renderView()
        tempRow = lastRow
        getList(chosenYear: currentYear, chosenMonth: currentMonth)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        renderNavigator()
    }
    
    private func renderNavigator() {
        navigationController?.navigationBar.setBackgroundImage(WalletDetailVC.emptyImg, for: .default)
        navigationController?.navigationBar.shadowImage = WalletDetailVC.emptyImg
        navigationController?.navigationBar.barTintColor = RGB(0x141516)
        navigationController?.navigationBar.isTranslucent = false
    }
    
    private func renderView() {
        view.addSubview(withdrawTableView)
        view.addSubview(datePickerView)
        
        withdrawTableView.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
        
        datePickerView.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
        
    }
    
    private func getList(chosenYear: Int, chosenMonth: Int) {
        Alert.showLoading(parentView: self.view)
        let req = TrandeHistoryListReq()
        req.currencyType = isBlance ? 1 : 2
        let isDoubleDigit = chosenMonth > 9
        let isTurnNextYear = chosenMonth == 12
        let nextMonth = isTurnNextYear ? 1 : chosenMonth + 1
        let nextYear = isTurnNextYear ? chosenYear + 1 : chosenYear
        let monthStr = isDoubleDigit ? "\(chosenMonth)" : "0\(chosenMonth)"
        let nextMonthStr = isDoubleDigit ? "\(nextMonth)" : "0\(nextMonth)"
        let startDateStr = "\(chosenYear)-\(monthStr)-01"
        let endDateStr = "\(nextYear)-\(nextMonthStr)-01"
        let standardFormat = DateFormatter()
        standardFormat.dateFormat = "yyyy-MM-dd"
        let startDate = standardFormat.date(from: startDateStr)
        let endDate = standardFormat.date(from: endDateStr)
        req.startTime = BaseModel.format.string(from:startDate!)
        req.endTime = BaseModel.format.string(from:endDate!)
        monthLabel.text = Calendar.current.component(.month, from: Date()) == chosenMonth ?  "本月" :  pickerMonthData[chosenMonth - 1]
        Session.request(req) { [weak self] (error, resp) in
            Alert.hideLoading()
            guard let `self` = self else { return }
            guard error == nil, let resData = resp as? [TrandeHistoryItem] else {
                self.walletList = []
                self.withdrawTableView.state = .failed
                return
            }
            self.withdrawTableView.state =  resData.isEmpty ? .empty : .normal
            self.walletList = resData
        }
    }
    
    @objc private func onDatePickerCancelClick() {
        onDatePickerMaskClick()
    }
    
    @objc private func onDatePickerConfirmClick() {
        lastRow = tempRow
        let currentMonth = (lastRow % pickerMonthData.count) + 1
        onDatePickerMaskClick()
        getList(chosenYear: currentYear, chosenMonth: currentMonth)
    }
    
    @objc private func onMonthBarClick() {
        guard datePickerView.alpha == 0 else {
            onDatePickerMaskClick()
            return
        }
        //隐藏中间两条分割线
        if #available(iOS 14.0, *) {
        } else if datePicker.subviews.count >= 2 {
            datePicker.subviews[1].isHidden = true
            datePicker.subviews[2].isHidden = true
        }
        
        datePicker.snp.updateConstraints { (make) in
            make.bottom.equalToSuperview().offset(16)
        }
        updateConstraints()
        UIView.animate(withDuration: 0.3) { [weak self] in
            self?.datePickerView.alpha = 1
            self?.view.layoutIfNeeded()
        }
    }
    
    @objc private func onDatePickerMaskClick() {
        datePicker.selectRow(lastRow, inComponent: 1, animated: false)
        datePicker.snp.updateConstraints { (make) in
            make.bottom.equalToSuperview().offset(235 + 16)
        }
        updateConstraints()
        UIView.animate(withDuration: 0.3) { [weak self] in
            self?.datePickerView.alpha = 0
            self?.view.layoutIfNeeded()
        }
    }
    
    private func updateConstraints() {
        datePicker.updateConstraintsIfNeeded()
        datePicker.updateFocusIfNeeded()
    }
    
}

extension WalletDetailVC: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return walletList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "WalletDetailCell", for: indexPath) as! WalletDetailCell
        cell.dataModel = walletList[indexPath.row]
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return walletList[indexPath.row].remark.isEmpty ? 70 : 79
    }
}

extension WalletDetailVC: UIPickerViewDelegate, UIPickerViewDataSource {
    
    //设定pickerView的列数
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 2
    }
    
    //设定pickerView的行数
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int)
    -> Int {
        return component == 0 ? pickerYearData.count : pickerMonthSize
    }
    
    //设定pickerView各选项的内容
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int,
                    forComponent component: Int) -> String? {
        return component == 0 ? pickerYearData[row % pickerYearData.count] : pickerMonthData[row % pickerMonthData.count]
    }
    
    //pickerView选中某一项后会触发
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int,
                    inComponent component: Int) {
        //重新让pickerView又选回中间部分的资料项
        guard component == 1 else { return }
        tempRow = row
    }
    
    func pickerView(_ pickerView: UIPickerView, widthForComponent component: Int) -> CGFloat {
        return component == 0 ? self.view.width * (2 / 5) : self.view.width * (3 / 5)
    }
}
