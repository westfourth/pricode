//
//  PublishVC.swift
//  Sp
//
//  Created by mac on 2020/2/17.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

/// 这个档案什么都不需要实现，只是做占位
class PublishVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }
}
