//
//  UsersDynamicPhoto.swift
//  Sp
//
//  Created by mac on 2020/9/7.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class UsersDynamicPhotoItemCell: UICollectionViewCell {
    
    private lazy var collectionView: UICollectionView = {
        let layout = UICollectionViewFlowLayout()
        layout.sectionInset = UIEdgeInsets(top: 0, left: 12, bottom: 0, right: 12)
        layout.itemSize = CGSize(width: PhotoCell.viewWidth, height: PhotoCell.viewHeight)
        layout.minimumLineSpacing = 12
        layout.minimumInteritemSpacing = 4
        let cv = UICollectionView(frame: .zero, collectionViewLayout: layout)
        cv.register(UsersDynamicPhotoCell.self, forCellWithReuseIdentifier: "UsersDynamicPhotoCell")
        cv.backgroundColor = .none
        cv.delegate = self
        cv.dataSource = self
        cv.showsVerticalScrollIndicator = false
        cv.showsHorizontalScrollIndicator = false
        cv.state = .loading
        cv.mj_header = getCommonMJHeader(refreshingTarget: self, headerRefreshCallback: #selector(onRefresh))
        cv.mj_footer = getCommonMJFooter(refreshingTarget: self, footerRefreshCallback: #selector(onLoad))
        return cv
    }()
    
    private var listData: [PortrayItem] = []
    
    private lazy var pageNum: Int = 0
    
    private var isInitState: Bool = true
    
    weak var delegate: UsersDynamicVCDelegate?
    
    var userId: Int? {
        didSet {
            guard isInitState else { return }
            isInitState = userId == nil
            getList(isRefresh: true)
        }
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        addSubview(collectionView)
        collectionView.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func getList(isRefresh: Bool) {
        guard let userId = self.userId else { return }
        collectionView.state = listData.isEmpty ? .loading : .normal
        let req = PortrayListReq()
        req.userId = userId
        let pageNum = self.pageNum
        req.page = isRefresh ? 1 : pageNum + 1
        if isRefresh {
            collectionView.mj_footer?.resetNoMoreData()
        }
        let collectionView = self.collectionView
        Session.request(req) { [weak self] (error, resp) in
            isRefresh ? collectionView.mj_header?.endRefreshing() : collectionView.mj_footer?.endRefreshing()
            guard let `self` = self else { return }
            guard error == nil, let resData = resp as? [PortrayItem] else {
                self.handleListException(isRefresh: isRefresh, pageNum: pageNum)
                return
            }
            self.pageNum = req.page
            self.listData = isRefresh ? resData : self.listData + resData
            let isEmpty = self.listData.isEmpty
            collectionView.state = isEmpty ? .empty : .normal
            collectionView.mj_footer?.isHidden = isEmpty
            collectionView.reloadData()
            if resData.count < req.pageSize {
                collectionView.mj_footer?.endRefreshingWithNoMoreData()
            }
        }
    }
    
    private func handleListException(isRefresh: Bool, pageNum: Int) {
        if isRefresh || pageNum == 1 {
            collectionView.state = .failed
            collectionView.mj_footer?.isHidden = true
            collectionView.reloadData()
            delegate?.refreshCategoryBarNum(listCount: 0, type: .photo)
        } else {
            collectionView.state = .normal
            collectionView.mj_footer?.endRefreshingWithNoMoreData()
            collectionView.mj_footer?.isHidden = false
            delegate?.refreshCategoryBarNum(listCount: listData.count, type: .photo)
        }
    }
    
    @objc private func onLoad() {
        getList(isRefresh: false)
    }
    
    @objc private func onRefresh() {
        getList(isRefresh: true)
    }
}


extension UsersDynamicPhotoItemCell: UICollectionViewDelegate, UICollectionViewDataSource {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return listData.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "UsersDynamicPhotoCell", for: indexPath) as! UsersDynamicPhotoCell
        cell.dataModel = listData[indexPath.row]
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        guard let navigationController = (UIApplication.shared.delegate as? AppDelegate)?.currentNavigationController else { return }
        let currentData = listData[indexPath.row]
        let photoPreviewVC = PhotoPreviewVC()
        photoPreviewVC.titleLabel.text = currentData.nickName
        photoPreviewVC.userId = currentData.userId
        photoPreviewVC.portrayId = currentData.portrayId
        photoPreviewVC.descLabel.text = currentData.title
        navigationController.show(photoPreviewVC, sender: nil)
    }
}
