//
//  UsersDynamicPhotoCell.swift
//  Sp
//
//  Created by mac on 2020/9/7.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class UsersDynamicPhotoCell: UICollectionViewCell {
    
    static let viewWidth: CGFloat = (UIScreen.main.bounds.width - 12 * 2 - 4) / 2
    
    static let viewHeight: CGFloat = PhotoCell.viewWidth / 166 * 266
    
    private static let photoNumImg: UIImage? = {
        return UIImage(named: "photo_num_icon")
    }()
    
    private lazy var posterImgView: UIImageView = {
        let imgView = UIImageView()
        imgView.layer.masksToBounds = true
        imgView.contentMode = .scaleAspectFill
        return imgView
    } ()
    
    private lazy var photoNumImgView: UIImageView = {
        let imgView = UIImageView(image: UsersDynamicPhotoCell.photoNumImg)
        return imgView
    }()
    
    private lazy var photoNumLabel: UILabel = {
        let label = UILabel()
        label.textColor = .white
        label.font = UIFont.pingFangRegular(14)
        return label
    }()
    
    private lazy var maskLayerView: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor.black.withAlphaComponent(0.5)
        view.addSubview(titleLabel)
        
        titleLabel.snp.makeConstraints { (make) in
            make.left.right.top.equalToSuperview().inset(8)
        }
        return view
    }()
    
    private lazy var titleLabel: UILabel = {
        let label = UILabel()
        label.textColor = .white
        label.font = UIFont.pingFangRegular(14)
        label.numberOfLines = 2
        return label
    }()
    
    var dataModel: PortrayItem? {
        didSet {
            guard let item = dataModel else { return }
            posterImgView.kf.setImage(with: item.coverImg?.column2, placeholder: PhotoPreviewCell.bannerDefaultImg, options: PhotoPreviewCell.animationOption)
            photoNumLabel.text = "\(item.imgNums)p"
            titleLabel.text = item.title
        }
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        renderView()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func renderView() {
        addSubview(posterImgView)
        addSubview(photoNumImgView)
        addSubview(photoNumLabel)
        addSubview(maskLayerView)
        
        posterImgView.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
        
        photoNumImgView.snp.makeConstraints { (make) in
            make.top.right.equalToSuperview()
            make.width.equalTo(55)
            make.height.equalTo(22)
        }
        
        photoNumLabel.snp.makeConstraints { (make) in
            make.right.equalToSuperview().inset(8)
            make.centerY.equalTo(photoNumImgView)
        }
        
        maskLayerView.snp.makeConstraints { (make) in
            make.left.right.bottom.equalToSuperview()
            make.height.equalTo(54)
        }
        
    }
}

