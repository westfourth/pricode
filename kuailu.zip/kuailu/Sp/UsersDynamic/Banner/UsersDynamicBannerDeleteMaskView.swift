//
//  UsersDynamicBannerDeleteMaskView.swift
//  Sp
//
//  Created by mac on 2020/6/18.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

protocol UsersDynamicBannerDeleteMaskViewDelegate: NSObjectProtocol {
    
    func deleteBannerSuccessCallBack()
    
}

class UsersDynamicBannerDeleteMaskView: UIView {
    
    private static let screenWidth: CGFloat = UIScreen.main.bounds.width
    
    private static let deleteBtnSize: CGFloat = 20
    
    private static let backArrowSize: CGFloat = 30
    
    private static let animationDuration: TimeInterval = 0.3
    
    private static let deleteImg: UIImage? = {
        return UIImage(named: "delete_white_icon")
    }()
    
    private static let backArrowImg: UIImage? = {
        return UIImage(named: "arrow_left_white")
    }()

    private lazy var cycleScrollView: CycleScrollView = {
        let cycleScrollView = CycleScrollView()
        cycleScrollView.isAutoScroll = false
        cycleScrollView.dataSource = self
        cycleScrollView.delegate = self
        cycleScrollView.hidesPageControl = true
        cycleScrollView.register(UsersDynamicBannerCycleScrollCell.self, forCellWithReuseIdentifier: "UsersDynamicBannerCycleScrollCell")
        cycleScrollView.layer.masksToBounds = true
        return cycleScrollView
    }()
    
    private lazy var pageControl: CarouselPageControl = {
        let view = CarouselPageControl()
        return view
    }()
    
    lazy var nicknameLabel: UILabel = {
        let label = UILabel()
        label.textColor = .white
        label.font = UIFont.pingFangRegular(18)
        label.textAlignment = .center
        label.numberOfLines = 1
        return label
    }()
    
    private lazy var deleteBtn: UIButton = {
        let btn = UIButton()
        btn.setBackgroundImage(UsersDynamicBannerDeleteMaskView.deleteImg, for: .normal)
        btn.addTarget(self, action: #selector(onDeleteBtnTap), for: .touchUpInside)
        btn.isHidden = true
        return btn
    }()
    
    private lazy var backArrowBtn: UIButton = {
        let btn = UIButton()
        btn.setBackgroundImage(UsersDynamicBannerDeleteMaskView.backArrowImg, for: .normal)
        btn.addTarget(self, action: #selector(onBackArrowBtnTap), for: .touchUpInside)
        return btn
    }()
    
    var bannerListData: [URL] = []
    
    var bannerRawListData: [String] = []
    
    var bannerReviewFailedListData: [ReviewImage] = []
    
    weak var delegate: UsersDynamicBannerDeleteMaskViewDelegate?
    
    var isDeleteBtnEnabled: Bool = false
    
    var initPageIndex: Int = 0
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        alpha = 0
        deleteBtn.isHidden = !isDeleteBtnEnabled || (bannerRawListData.isEmpty && bannerReviewFailedListData.isEmpty)
        backgroundColor = .black
        addSubview(backArrowBtn)
        addSubview(cycleScrollView)
        addSubview(pageControl)
        addSubview(nicknameLabel)
        addSubview(deleteBtn)
        
        let screenWidth = UsersDynamicBannerDeleteMaskView.screenWidth
        
        backArrowBtn.snp.makeConstraints { (make) in
            make.top.equalToSuperview().inset(kTop - UsersDynamicBannerDeleteMaskView.backArrowSize - 7)
            make.left.equalToSuperview().inset(screenWidth > 375 ? 6 : 3)
            make.size.equalTo(UsersDynamicBannerDeleteMaskView.backArrowSize)
        }
        
        nicknameLabel.snp.makeConstraints { (make) in
            make.bottom.equalToSuperview().inset(IS_IPHONEX ? 24 : 10)
            make.left.right.equalToSuperview().inset(UsersDynamicBannerDeleteMaskView.deleteBtnSize + 12)
        }
        
        deleteBtn.snp.makeConstraints { (make) in
            make.centerY.equalTo(nicknameLabel)
            make.right.equalToSuperview().inset(12)
            make.size.equalTo(UsersDynamicBannerDeleteMaskView.deleteBtnSize)
        }
        
        pageControl.snp.makeConstraints { (make) in
            make.centerX.equalToSuperview()
            make.bottom.equalTo(nicknameLabel.snp.top).offset(-20)
            make.width.equalTo(CGFloat(bannerListData.count) * 14)
            make.height.equalTo(6)
        }
        
        cycleScrollView.snp.makeConstraints { (make) in
            make.top.equalToSuperview().inset(kTop)
            make.left.width.equalToSuperview()
            make.bottom.equalTo(pageControl.snp.top).offset(-14)
        }
        
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func startAnimation() {
        reloadData()
        UIView.animate(withDuration: UsersDynamicBannerDeleteMaskView.animationDuration) { [weak self] in
            self?.alpha = 1
        }
    }
    
    private func stopAnimation() {
        UIView.animate(withDuration: UsersDynamicBannerDeleteMaskView.animationDuration, animations: { [weak self] in
            self?.alpha = 0
        }) { [weak self] _ in
            self?.removeFromSuperview()
        }
    }
    
    private func reloadData() {
        updatePageControl()
        cycleScrollView.initPageIndex = initPageIndex
        cycleScrollView.reloadData()
    }
    
    private func updatePageControl() {
        deleteBtn.isHidden = !isDeleteBtnEnabled || (bannerRawListData.isEmpty && bannerReviewFailedListData.isEmpty)
        pageControl.currentPage = initPageIndex
        pageControl.numberOfPages = bannerListData.count + bannerReviewFailedListData.count
        pageControl.isHidden = pageControl.numberOfPages < 2
        pageControl.snp.updateConstraints { (make) in
            make.width.equalTo(CGFloat(pageControl.numberOfPages) * 14)
        }
    }
    
    private func deleteBanner() {
        let currentPgaeIndex = cycleScrollView.pageIndex
        guard currentPgaeIndex < bannerRawListData.count + bannerReviewFailedListData.count else { return }
        Alert.showLoading(parentView: self)
        let isBannerList = currentPgaeIndex < bannerRawListData.count
        let req = ChatSexUserDeleteBgImgReq()
        req.bgImg = isBannerList ? bannerRawListData[currentPgaeIndex] : (bannerReviewFailedListData[currentPgaeIndex - bannerRawListData.count].bgImgs.first ?? "")
        Session.request(req) { [weak self] (error, resp) in
            Alert.hideLoading()
            guard let `self` = self, error == nil else {
                mm_showToast(error!.localizedDescription, type: .failed)
                return
            }
            self.delegate?.deleteBannerSuccessCallBack()
            if isBannerList {
                self.bannerListData.remove(at: currentPgaeIndex)
                self.bannerRawListData.remove(at: currentPgaeIndex)
            } else {
                self.bannerReviewFailedListData.remove(at: currentPgaeIndex - self.bannerRawListData.count)
            }
            
            self.initPageIndex = 0
            self.reloadData()
            mm_showToast("恭喜您，背景牆圖片刪除成功！", type: .succeed)
        }
    }
    
    @objc private func onBackArrowBtnTap() {
        stopAnimation()
    }
    
    @objc private func onDeleteBtnTap() {
        deleteBanner()
    }
    
}

extension UsersDynamicBannerDeleteMaskView: CycleScrollViewDataSource {
    
    func numberOfItems(in cycleScrollView: CycleScrollView) -> Int {
        return bannerListData.count + bannerReviewFailedListData.count
    }
    
    func cycleScrollView(_ cycleScrollView: CycleScrollView, cellForItemAt index: Int) -> UICollectionViewCell {
        let cell = cycleScrollView.dequeueReusableCell(withReuseIdentifier: "UsersDynamicBannerCycleScrollCell", for: index) as! UsersDynamicBannerCycleScrollCell
        let bannerListLen = bannerListData.count
        guard index >= bannerListLen else {
            cell.reviewStatus = .approved
            cell.bannerImgUrl = bannerListData[index]
            return cell
        }
        let idx = index - bannerListLen
        guard idx < bannerReviewFailedListData.count else { return cell }
        cell.reviewStatus = bannerReviewFailedListData[idx].status
        cell.bannerImgUrl = bannerReviewFailedListData[idx].displayImage
        return cell
    }
    
    func cycleScrollView(_ cycleScrollView: CycleScrollView, didSelectItemAt index: Int) {
        stopAnimation()
    }
}

extension UsersDynamicBannerDeleteMaskView: CycleScrollViewDelegate {
    
    func cycleScrollView(_ cycleScrollView: CycleScrollView, didScrollFromIndex fromIndex: Int, toIndex: Int) {
        pageControl.currentPage = toIndex
    }
    
}
