//
//  UsersDynamicBannerCycleScrollCell.swift
//  Sp
//
//  Created by mac on 2020/6/24.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class UsersDynamicBannerCycleScrollCell: UICollectionViewCell {
    
    private static let UsersDynamicDefaultBannerImg: UIImage? = {
        return Sensitive.usersDynamicBannerDefaultImg
    }()
    
    private static let bannerDefaultImg: UIImage? = {
        return  Sensitive.default_bg
    }()
    
    private static let animationOptionGif: KingfisherOptionsInfo = {
        return [.transition(.fade(0.25)), .backgroundDecode, .fromMemoryCacheOrRefresh]
    }()
    
    private static let animationOption: KingfisherOptionsInfo = {
        return [.transition(.fade(0.25))]
    }()
    
    private static let approvalStatusLabelSize: CGFloat = 140
    
    private lazy var bannerImgView: AnimatedImageView = {
        let imgView = AnimatedImageView()
        imgView.contentMode = .scaleAspectFit
        imgView.layer.masksToBounds = true
        imgView.runLoopMode = .default
        return imgView
    }()
    
    private lazy var approvalStatusLabel: UILabel = {
        let label = UILabel()
        label.textColor = RGB(0x323232)
        label.textAlignment = .center
        label.font = UIFont.pingFangRegular(24)
        label.backgroundColor = UIColor.white.withAlphaComponent(0.38)
        label.layer.cornerRadius = UsersDynamicBannerCycleScrollCell.approvalStatusLabelSize / 2
        label.layer.masksToBounds = true
        label.isHidden = reviewStatus == .approved
        return label
    }()
    
    var reviewStatus: ReviewImageStatus = .approved {
        didSet {
            let isApproved = reviewStatus == .approved
            approvalStatusLabel.isHidden = isApproved
            approvalStatusLabel.text = isApproved ? "" : reviewStatus == .reviewing ? "圖片審核中" : "審核未通過"
        }
    }
    
    var bannerImgUrl: URL? {
        didSet {
            let isGif = bannerImgUrl?.column0?.absoluteString.contains(".gif") ?? false
            bannerImgView.kf.setImage(with: bannerImgUrl?.column0, placeholder: UsersDynamicBannerCycleScrollCell.bannerDefaultImg, options: isGif ? UsersDynamicBannerCycleScrollCell.animationOptionGif : UsersDynamicBannerCycleScrollCell.animationOption)
        }
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        addSubview(bannerImgView)
        addSubview(approvalStatusLabel)
        
        bannerImgView.snp.makeConstraints { (maker) in
            maker.edges.equalToSuperview()
        }
        
        approvalStatusLabel.snp.makeConstraints { (make) in
            make.center.equalToSuperview()
            make.size.equalTo(UsersDynamicBannerCycleScrollCell.approvalStatusLabelSize)
        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
