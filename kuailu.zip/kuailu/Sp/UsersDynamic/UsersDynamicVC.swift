//
//  UsersDynamicVC.swift
//  Sp
//
//  Created by mac on 2020/6/16.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

enum UsersDynamicVCCategory: Int {
    case oneself = 0
    case other = 1
}

enum UsersDynamicVCType {
    case profile
    case dynamic
    case smallVideo
    case photo
    case highlights
}

protocol UsersDynamicVCDelegate: NSObjectProtocol {
    
    func refreshCategoryBarNum(listCount: Int , type: UsersDynamicVCType)
    
}


class UsersDynamicVC: UIViewController {
    
    static let screenWidth: CGFloat = UIScreen.main.bounds.width
    
    static let categoryBarHeight: CGFloat = 40
    
    static let subScrollListItemSize: CGSize = CGSize(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height - kTop - UsersDynamicVC.categoryBarHeight)
    
    static let wrappeSrollViewSize: CGSize = CGSize(width: UIScreen.main.bounds.width, height: UsersDynamicHeaderView.viewMaxHeight + UsersDynamicVC.categoryBarHeight + UsersDynamicVC.subScrollListItemSize.height)
    
    static let categoryBarIndicatorWidth: CGFloat = 30
    
    static let categoryBarIndicatorHeight: CGFloat = 3
    
    static let categoryBarBottomLineHeight: CGFloat = 0.5
    
    static let emptyImg: UIImage = {
        return UIImage()
    }()
    
    private static let publishImg: UIImage? = {
        return UIImage(named: "chat_publish")
    }()
    
    private lazy var headerView: UsersDynamicHeaderView = {
        let view = UsersDynamicHeaderView()
        view.delegate = self
        return view
    }()
    
    private lazy var categoryBarIndicator: UIView = {
        let view = UIView(frame: CGRect(x: (UIScreen.main.bounds.width / 5 - UsersDynamicVC.categoryBarIndicatorWidth) / 2, y: UsersDynamicVC.categoryBarHeight - UsersDynamicVC.categoryBarIndicatorHeight - 2, width: UsersDynamicVC.categoryBarIndicatorWidth, height: UsersDynamicVC.categoryBarIndicatorHeight))
        view.backgroundColor = RGB(0xFA6400)
        view.layer.masksToBounds = true
        view.layer.cornerRadius = 1.5
        view.isHidden = true
        return view
    }()
    
    private lazy var categoryBarBottomLine: UIView = {
        let view = UIView(frame: CGRect(x: 12, y: UsersDynamicVC.categoryBarHeight - UsersDynamicVC.categoryBarBottomLineHeight, width: UIScreen.main.bounds.width - 12 * 2, height: UsersDynamicVC.categoryBarBottomLineHeight))
        view.backgroundColor = UIColor.white.withAlphaComponent(0.1)
        return view
    }()
    
    private lazy var categoryBarCollectionView: UICollectionView = {
        let layout = UICollectionViewFlowLayout()
        layout.minimumLineSpacing = 0
        layout.minimumInteritemSpacing = 0
        layout.scrollDirection = .horizontal
        let cv = UICollectionView(frame: .zero, collectionViewLayout: layout)
        cv.register(UsersDynamicCategoryCell.self, forCellWithReuseIdentifier: "UsersDynamicCategoryCell")
        cv.showsVerticalScrollIndicator = false
        cv.showsHorizontalScrollIndicator = false
        cv.bouncesZoom = false
        cv.backgroundColor = RGB(0x141516)
        cv.delegate = self
        cv.dataSource = self
        cv.addSubview(categoryBarIndicator)
        cv.addSubview(categoryBarBottomLine)
        cv.isHidden = true
        return cv
    }()
    
    private lazy var subScrollListCollectionView: UICollectionView = {
        let layout = UICollectionViewFlowLayout()
        layout.minimumLineSpacing = 0
        layout.minimumInteritemSpacing = 0
        layout.scrollDirection = .horizontal
        let cv = UICollectionView(frame: .zero, collectionViewLayout: layout)
        cv.register(UsersDynamicProfileItemCell.self, forCellWithReuseIdentifier: "UsersDynamicProfileItemCell")
        cv.register(UsersDynamicDetailsItemCell.self, forCellWithReuseIdentifier: "UsersDynamicDetailsItemCell")
        cv.register(UsersDynamicSmallVideoItemCell.self, forCellWithReuseIdentifier: "UsersDynamicSmallVideoItemCell")
        cv.register(UsersDynamicPhotoItemCell.self, forCellWithReuseIdentifier: "UsersDynamicPhotoItemCell")
        cv.register(UsersDynamicHighlightsItemCell.self, forCellWithReuseIdentifier: "UsersDynamicHighlightsItemCell")
        cv.showsVerticalScrollIndicator = false
        cv.showsHorizontalScrollIndicator = false
        cv.isDirectionalLockEnabled = true
        cv.bouncesZoom = false
        cv.isPagingEnabled = true
        cv.backgroundColor = RGB(0x141516)
        cv.delegate = self
        cv.dataSource = self
        return cv
    }()
    
    private lazy var wrappeSrollView: UIScrollView = {
        let scrollView = UIScrollView()
        scrollView.contentSize = UsersDynamicVC.wrappeSrollViewSize
        scrollView.showsHorizontalScrollIndicator = false
        scrollView.showsVerticalScrollIndicator = false
        scrollView.isDirectionalLockEnabled = true
        scrollView.bouncesZoom = false
        scrollView.delegate = self
        scrollView.addSubview(headerView)
        scrollView.addSubview(categoryBarCollectionView)
        scrollView.addSubview(subScrollListCollectionView)
        let screenWidth = UsersDynamicVC.screenWidth
        headerView.snp.makeConstraints { (make) in
            make.top.left.equalToSuperview()
            make.width.equalTo(screenWidth)
            make.height.equalTo(UsersDynamicHeaderView.viewMaxHeight)
        }
        
        categoryBarCollectionView.snp.makeConstraints { (make) in
            make.top.equalTo(headerView.snp.bottom)
            make.left.equalToSuperview()
            make.width.equalTo(screenWidth)
            make.height.equalTo(UsersDynamicVC.categoryBarHeight)
        }
        
        subScrollListCollectionView.snp.makeConstraints { (make) in
            make.top.equalTo(categoryBarCollectionView.snp.bottom)
            make.left.equalToSuperview()
            make.width.equalTo(screenWidth)
            make.height.equalTo(UsersDynamicVC.subScrollListItemSize.height)
        }
        
        return scrollView
    }()
    
    private lazy var publishBtn: UIButton = {
        let btn = UIButton()
        btn.setBackgroundImage(UsersDynamicVC.publishImg, for: .normal)
        btn.addTarget(self, action: #selector(onPublishBtnTap), for: .touchUpInside)
        btn.isHidden = true
        return btn
    }()
    
    private lazy var datingBtn: UsersDynamicDatingBtn = {
        let btn = UsersDynamicDatingBtn()
        btn.delegate = self
        return btn
    }()
    
    private lazy var unlockBtn: UsersDynamicUnlockBtn = {
        let btn = UsersDynamicUnlockBtn()
        btn.delegate = self
        return btn
    }()
    
    private lazy var takePhotosActionSheet: UsersDynamicTakePhotosActionSheet = {
        let actionSheet = UsersDynamicTakePhotosActionSheet()
        actionSheet.delegate = self
        return actionSheet
    }()
    
    private lazy var unlockAlert: UsersDynamicUnlockAlert = {
        let view = UsersDynamicUnlockAlert()
        return view
    }()
    
    private lazy var bannerDeleteMaskView: UsersDynamicBannerDeleteMaskView = {
        let view = UsersDynamicBannerDeleteMaskView()
        view.delegate = self
        return view
    }()
    
    private var categoryBarItemSize: CGSize = .zero
    
    private var activePageIndex: Int = 0
    
    private var userinfo: UserBase?
    
    private var detailsListCount: Int = 0
    
    private var smallVideoListCount: Int = 0
    
    private var photoListCount: Int = 0
    
    private var highlightsListCount: Int = 0
    
    private var type: UsersDynamicVCCategory = .other
    
    private var categoryBarTypeList: [UsersDynamicVCType] = []
    
    private var categoryBarTitleList: [String] = []
    
    private var categoryBarItemCenterXList: [CGFloat] = []
    
    var viewWillDisappearCallback: (() -> Void)?
    
    var attentionClosure: ((_ isAttention: Bool) ->())?
    
    var userId: Int? {
        didSet {
            getList(isInit: true)
        }
    }
    
    var initPageType: UsersDynamicVCType = .profile
    
    override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: Bundle?) {
        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
        hidesBottomBarWhenPushed = true
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        if #available(iOS 11.0, *) {
            wrappeSrollView.contentInsetAdjustmentBehavior = .never
            categoryBarCollectionView.contentInsetAdjustmentBehavior = .never
            subScrollListCollectionView.contentInsetAdjustmentBehavior = .never
        } else {
            automaticallyAdjustsScrollViewInsets = false
        }
        view.backgroundColor = RGB(0x141516)
        renderView()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        guard let navigationBar = navigationController?.navigationBar else { return }
        navigationBar.isTranslucent = false
        navigationBar.barTintColor = RGB(0x141516)
        navigationBar.setBackgroundImage(UsersDynamicVC.emptyImg, for: .default)
        navigationBar.shadowImage = UsersDynamicVC.emptyImg
        getAccountInfo()
        getList(isInit: false)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        viewWillDisappearCallback?()
        guard let isAttention = userinfo?.attentionHe else { return }
        attentionClosure?(isAttention)
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        bannerDeleteMaskView.removeFromSuperview()
        viewWillDisappearCallback = nil
        attentionClosure = nil
    }
    
    deinit {
        viewWillDisappearCallback = nil
        attentionClosure = nil
        UsersDynamicProfileItemCell.subCellHeightList = []
        UsersDynamicProfileItemCell.subCellContentHeightList = []
    }
    
    private func renderView() {
        view.addSubview(wrappeSrollView)
        view.addSubview(datingBtn)
        view.addSubview(publishBtn)
        view.addSubview(unlockBtn)
        view.addSubview(takePhotosActionSheet)
        view.addSubview(unlockAlert)
        
        wrappeSrollView.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
        
        datingBtn.snp.makeConstraints { (make) in
            make.centerX.equalToSuperview()
            make.bottom.equalToSuperview().inset(20)
            make.width.equalTo(336)
            make.height.equalTo(50)
        }
        
        publishBtn.snp.makeConstraints { (make) in
            make.bottom.equalToSuperview().inset(50)
            make.right.equalToSuperview().inset(12)
            make.size.equalTo(92)
        }
        
        unlockBtn.snp.makeConstraints { (make) in
            make.edges.equalTo(datingBtn)
        }
        
        takePhotosActionSheet.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
        
        unlockAlert.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
    }
    
    private func getList(isInit: Bool) {
        guard let Id = userId else { return }
        isInit ? Alert.showLoading(parentView: UIApplication.shared.keyWindow!) : nil
        let req = ChatSexUserInfoReq()
        req.userId = Id
        Session.request(req) { [weak self] (error, resp) in
            isInit ? Alert.hideLoading() : nil
            guard let `self` = self, error == nil, let resData = resp as? UserBase else { return }
            self.userinfo = resData
            //小视频数
            self.smallVideoListCount = resData.worksNum
            self.detailsListCount = resData.dynamicNum
            self.photoListCount = resData.portrayNum
            self.highlightsListCount = resData.blooperNum
            let userId = NetDefaults.userInfo?.userId
            self.type = userId == resData.userId ? .oneself : .other
            self.handleCategoryBar(isInit: isInit, listData: resData)
            self.headerView.snp.updateConstraints { (make) in
                make.height.equalTo(self.type == .other ? UsersDynamicHeaderView.viewMaxHeight : UsersDynamicHeaderView.viewMinHeight)
            }
            self.headerView.dataModel = resData
            self.publishBtn.isHidden = userId == nil || resData.userId != userId || resData.dynamicNum <= 0
            self.datingBtn.isHidden = !(resData.userType == 4 && resData.isRecommend)
            self.datingBtn.subjectLabel.isHidden = resData.meetCard
            self.datingBtn.contactLabel.isHidden = !resData.meetCard
            self.datingBtn.contactLabel.text = resData.phone
            let isShowContact = resData.userType == 5 || (resData.userType == 4 && !resData.isRecommend)
            self.unlockBtn.isHidden = !isShowContact
            self.unlockBtn.subjectLabel.isHidden = resData.meetLock
            self.unlockBtn.contactLabel.isHidden = !resData.meetLock
            self.unlockBtn.contactLabel.text = resData.phone
            self.categoryBarCollectionView.reloadData()
            self.subScrollListCollectionView.reloadData()
            NotificationCenter.default.post(name: .UpdateUsersDynamicProfileLockStatus, object: nil)
            NotificationCenter.default.post(name: .UpdateUsersDynamicDetailsList, object: nil)
            if isInit {
                self.subScrollListCollectionView.scrollToItem(at: IndexPath(item: self.activePageIndex, section: 0), at: .centeredHorizontally, animated: false)
            }
        }
    }
    
    private func handleCategoryBar(isInit: Bool, listData: UserBase) {
        var categoryBarTypeList: [UsersDynamicVCType] = [.profile, .dynamic]
        var categoryBarTitleList: [String] = ["資料", "動態"]
        
        if !(type == .other && listData.worksNum <= 0) {
            categoryBarTypeList.append(.smallVideo)
            categoryBarTitleList.append("小視頻")
        }
        
        if listData.portrayNum > 0 {
            categoryBarTypeList.append(.photo)
            categoryBarTitleList.append("寫真")
        }
        if listData.blooperNum > 0 {
            categoryBarTypeList.append(.highlights)
            categoryBarTitleList.append("花絮")
        }
        self.categoryBarTypeList = categoryBarTypeList
        self.categoryBarTitleList = categoryBarTitleList
        let count = categoryBarTypeList.count
        let dividend = CGFloat(count * 2)
        let screenWidth = UsersDynamicVC.screenWidth
        var categoryBarItemCenterXList: [CGFloat] = []
        for i in 0..<count {
            categoryBarItemCenterXList.append(screenWidth / dividend * (CGFloat(i) * 2 + 1))
        }
        self.categoryBarItemCenterXList = categoryBarItemCenterXList
        if isInit {
            activePageIndex = self.categoryBarTypeList.firstIndex { $0 == initPageType } ?? 0
        }
        categoryBarIndicator.center.x = self.categoryBarItemCenterXList[activePageIndex]
        categoryBarItemSize = CGSize(width: screenWidth / CGFloat(self.categoryBarItemCenterXList.count), height: UsersDynamicVC.categoryBarHeight)
        categoryBarIndicator.center.x = self.categoryBarItemCenterXList[activePageIndex]
        categoryBarCollectionView.isHidden = false
        categoryBarIndicator.isHidden = false
    }
    
    private func getAccountInfo() {
        Session.request(UserAccountInfoReq()) { (error, resp) in
            guard error == nil, let resData = resp as? UserAccountInfo else { return }
            WalletVC.balanceVal = resData.bala
            WalletVC.coinVal = resData.gold
            WalletVC.exchangeVal = resData.welfareNum
        }
    }
    
    @objc private func onPublishBtnTap() {
        
        guard NetDefaults.userInfo?.freeWatches == -1 else {
            PurchaseVipAlert.showPurchaseVipAlert()
            return
        }
        
        guard UploadConfig.shared.info.allow else {
            mm_showToast("系統維護中，暫不能上傳視頻!")
            return
        }
        
        let vc = TimeLinePublishVC()
        vc.hidesBottomBarWhenPushed = true
        navigationController?.pushViewController(vc, animated: true)
    }
}

extension UsersDynamicVC: UICollectionViewDataSource, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int)
    -> Int {
        return categoryBarTypeList.count
    }
    
    func collectionView(_ collectionView: UICollectionView,
                        layout collectionViewLayout: UICollectionViewLayout,
                        sizeForItemAt indexPath: IndexPath) -> CGSize {
        return collectionView == categoryBarCollectionView ? categoryBarItemSize : UsersDynamicVC.subScrollListItemSize
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let row = indexPath.row
        let categoryType = categoryBarTypeList[row]
        guard collectionView != categoryBarCollectionView else {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "UsersDynamicCategoryCell", for: indexPath) as! UsersDynamicCategoryCell
            let numStr = (categoryType == .profile ? "" : categoryType == .dynamic ? " \(detailsListCount)" : categoryType == .smallVideo ? " \(smallVideoListCount)" : categoryType == .photo ? " \(photoListCount)" : " \(highlightsListCount)")
            cell.titleLabel.text = categoryBarTitleList[row] + numStr
            let isActive = activePageIndex == row
            cell.titleLabel.textColor = isActive ? .white : RGB(165, 165, 165)
            cell.titleLabel.font = isActive ? UIFont.pingFangSemibold(16) : UIFont.pingFangMedium(16)
            return cell
        }
        switch categoryType {
        case .profile:
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "UsersDynamicProfileItemCell", for: indexPath) as! UsersDynamicProfileItemCell
            cell.dataModel = userinfo
            return cell
        case .dynamic:
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "UsersDynamicDetailsItemCell", for: indexPath) as! UsersDynamicDetailsItemCell
            cell.delegate = self
            cell.switchDelegate = self
            cell.userId = userId
            return cell
        case .smallVideo:
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "UsersDynamicSmallVideoItemCell", for: indexPath) as! UsersDynamicSmallVideoItemCell
            cell.delegate = self
            cell.userId = userId
            return cell
        case .photo:
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "UsersDynamicPhotoItemCell", for: indexPath) as! UsersDynamicPhotoItemCell
            cell.delegate = self
            cell.userId = userId
            return cell
        case .highlights:
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "UsersDynamicHighlightsItemCell", for: indexPath) as! UsersDynamicHighlightsItemCell
            cell.delegate = self
            cell.userId = userId
            return cell
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let row = indexPath.row
        guard collectionView == categoryBarCollectionView, activePageIndex != row else { return }
        activePageIndex = row
        subScrollListCollectionView.scrollToItem(at: indexPath, at: .centeredHorizontally, animated: true)
    }
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        guard scrollView == subScrollListCollectionView else { return }
        let currentActivePageIndex = Int(round(scrollView.contentOffset.x / scrollView.frame.width))
        guard currentActivePageIndex != activePageIndex else { return }
        activePageIndex = currentActivePageIndex
        categoryBarCollectionView.scrollToItem(at: IndexPath(row: currentActivePageIndex, section: 0), at: .centeredHorizontally, animated: true)
        UIView.animate(withDuration: 0.15, delay: 0, options: .curveEaseIn, animations: {[weak self] in
            guard let `self` = self else { return }
            self.categoryBarIndicator.center.x = self.categoryBarItemCenterXList[currentActivePageIndex]
        }) { [weak self] _ in
            self?.categoryBarCollectionView.reloadData()
        }
    }
    
}

extension UsersDynamicVC: UsersDynamicTakePhotosActionSheetDelegate {
    
    func choosePhotosType(type: TakePhotosType) {
        switch type {
        case .takePhotos:
            guard UIImagePickerController.isSourceTypeAvailable(.camera) else {
                mm_showToast("無法打開相機哦!")
                return
            }
            let cameraPicker = UIImagePickerController()
            cameraPicker.modalPresentationStyle = .fullScreen
            if #available(iOS 13.0, *) {
                cameraPicker.isModalInPresentation = true
            }
            GlobalSettings.setImagePickerNatiBarAttribute()
            cameraPicker.delegate = self
            cameraPicker.allowsEditing = true
            cameraPicker.sourceType = .camera
            present(cameraPicker, animated: true, completion: nil)
        default:
            let photoPicker = UIImagePickerController()
            photoPicker.modalPresentationStyle = .fullScreen
            if #available(iOS 13.0, *) {
                photoPicker.isModalInPresentation = true
            }
            GlobalSettings.setImagePickerNatiBarAttribute()
            photoPicker.delegate = self
            photoPicker.allowsEditing = true
            photoPicker.sourceType = .photoLibrary
            present(photoPicker, animated: true, completion: nil)
        }
    }
    
}

extension UsersDynamicVC: UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        GlobalSettings.resetNaviBarAttribute()
        let image = info[UIImagePickerController.InfoKey.editedImage] as! UIImage
        Alert.showLoading(parentView: view)
        ImageUploader.upload(image) { (e, domain, suffix) in
            let req = ChatSexUserAddBgImgsReq()
            req.bgImgs = [suffix]
            Session.request(req) { [weak self] (e, resp) in
                Alert.hideLoading()
                guard let `self` = self, e == nil else {
                    mm_showToast(e!.localizedDescription, type: .failed)
                    return
                }
                self.getList(isInit: false)
                mm_showToast("恭喜您，背景牆圖片上傳成功！", type: .succeed)
            }
        }
        dismiss(animated: true, completion: nil)
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true, completion: nil)
        GlobalSettings.resetNaviBarAttribute()
    }
    
}

extension UsersDynamicVC: UsersDynamicHeaderViewDelegate {
    
    func refreshAccountInfo() {
        getAccountInfo()
    }
    
    func refreshUserinfo() {
        getList(isInit: false)
    }
    
    func showBannerDeleteMaskView(pageIndex: Int) {
        guard let userinfo = self.userinfo else { return }
        bannerDeleteMaskView.removeFromSuperview()
        UIApplication.shared.keyWindow!.addSubview(bannerDeleteMaskView)
        bannerDeleteMaskView.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
        bannerDeleteMaskView.isDeleteBtnEnabled = userinfo.userId == NetDefaults.userInfo?.userId
        bannerDeleteMaskView.bannerListData = userinfo.bgCovers
        bannerDeleteMaskView.bannerRawListData = userinfo.bgImgs
        bannerDeleteMaskView.bannerReviewFailedListData = userinfo.checkImgs
        bannerDeleteMaskView.nicknameLabel.text = userinfo.nickName
        bannerDeleteMaskView.initPageIndex = pageIndex
        bannerDeleteMaskView.startAnimation()
    }
    
    func showTakePhotosActionSheet() {
        takePhotosActionSheet.startAnimation()
    }
    
}

extension UsersDynamicVC: UsersDynamicBannerDeleteMaskViewDelegate {
    
    func deleteBannerSuccessCallBack() {
        getList(isInit: false)
    }
    
}

extension UsersDynamicVC: UsersDynamicVCDelegate {
    
    func refreshCategoryBarNum(listCount: Int , type: UsersDynamicVCType) {
        switch type {
        case .dynamic:
            detailsListCount = listCount
        case .smallVideo:
            smallVideoListCount = listCount
        case .photo:
            photoListCount = listCount
        case .highlights:
            highlightsListCount = listCount
        default:
            return
        }
        categoryBarCollectionView.reloadData()
    }
    
}

extension UsersDynamicVC: UsersDynamicDatingBtnDelegate {
    
    func handleDatingBtnTap() {
        guard let userData = userinfo else { return }
        guard !userData.meetCard else {
            mm_showToast("親，您已購買約炮卡哦！")
            return
        }
        VipChargeTipVC.isFromVideoPlayList = false
        VipChargeTicketItemCell.initActiveTicketType = .meetSex
        let vipVC = Vip2VC()
        vipVC.uiType = .ticket
        navigationController?.pushViewController(vipVC, animated: true)
    }
    
}

extension UsersDynamicVC: UsersDynamicUnlockBtnDelegate {
    
    func handleUnlockBtnTap() {
        guard let userData = userinfo else { return }
        guard !userData.meetLock else {
            mm_showToast("親，您已解鎖聯繫方式哦！")
            return
        }
        unlockAlert.userId = userData.userId
        unlockAlert.coinNum = userData.meetPrice
        unlockAlert.successClosure = { [weak self] in
            guard let `self` = self else { return }
            self.userinfo?.meetLock = true
            NotificationCenter.default.post(name: NSNotification.Name.UpdateUsersDynamicProfileLockStatus, object: nil)
            self.getList(isInit: false)
            self.getAccountInfo()
            self.unlockAlert.successClosure = nil
        }
        unlockAlert.showAlert()
    }
}

extension UsersDynamicVC: UsersDynamicDetailsItemCellDelegate {
    
    func switchToHighlights() {
        guard let index = (categoryBarTypeList.firstIndex { $0 == .highlights }), index < categoryBarItemCenterXList.count else { return }
        subScrollListCollectionView.scrollToItem(at: IndexPath(item: index, section: 0), at: .centeredHorizontally, animated: true)
    }
    
}

