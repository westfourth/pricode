//
//  UsersDynamicTakePhotosActionSheet.swift
//  Sp
//
//  Created by mac on 2020/6/18.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

enum TakePhotosType: Int {
    case takePhotos = 0
    case photoAlbum = 1
}

protocol UsersDynamicTakePhotosActionSheetDelegate: NSObjectProtocol {
    
    func choosePhotosType(type: TakePhotosType)
    
}

class UsersDynamicTakePhotosActionSheet: UIView {
    
    private static let sheetHeight: CGFloat = 50 + (IS_IPHONEX ? 20 : 0)
    
    private static let splitLineHeight: CGFloat = 0.5
    
    private static let actionSheetMarginBottom: CGFloat = 10
    
    private static let actionSheetViewHeight: CGFloat = UsersDynamicTakePhotosActionSheet.sheetHeight * 3 + UsersDynamicTakePhotosActionSheet.actionSheetMarginBottom
    
    weak var delegate: UsersDynamicTakePhotosActionSheetDelegate?
    
    private lazy var takePhotosBtn: UIButton = {
        let btn = UIButton()
        btn.setTitle("拍一張", for: .normal)
        btn.setTitleColor(RGB(0x363636), for: .normal)
        btn.titleLabel?.font = UIFont.pingFangRegular(18)
        btn.addTarget(self, action: #selector(onTakePhotosBtnTap), for: .touchUpInside)
        return btn
    }()
    
    private lazy var photoAlbumBtn: UIButton = {
        let btn = UIButton()
        btn.setTitle("從手機相冊選擇", for: .normal)
        btn.setTitleColor(RGB(0x363636), for: .normal)
        btn.titleLabel?.font = UIFont.pingFangRegular(18)
        btn.addTarget(self, action: #selector(onPhotoAlbumBtnTap), for: .touchUpInside)
        return btn
    }()
    
    private lazy var cancelBtn: UIButton = {
        let btn = UIButton()
        btn.setTitle("取消", for: .normal)
        btn.setTitleColor(RGB(0x363636), for: .normal)
        btn.titleLabel?.font = UIFont.pingFangRegular(18)
        btn.addTarget(self, action: #selector(onCancelBtnTap), for: .touchUpInside)
        return btn
    }()
    
    private lazy var firstSplitLine: UIView = {
        let view = UIView()
        view.backgroundColor = RGB(0x979797)
        return view
    }()
    
    private lazy var secondSplitLine: UIView = {
        let view = UIView()
        view.backgroundColor = RGB(0x979797)
        return view
    }()
    
    private lazy var actionSheetView: UIView = {
        let view = UIView()
        view.backgroundColor = .white
        view.layer.cornerRadius = 10
        view.layer.masksToBounds = true
        view.addSubview(takePhotosBtn)
        view.addSubview(firstSplitLine)
        view.addSubview(photoAlbumBtn)
        view.addSubview(secondSplitLine)
        view.addSubview(cancelBtn)
        
        takePhotosBtn.snp.makeConstraints { (make) in
            make.top.left.right.equalToSuperview()
            make.height.equalTo(UsersDynamicTakePhotosActionSheet.sheetHeight)
        }
        
        firstSplitLine.snp.makeConstraints { (make) in
            make.top.equalTo(takePhotosBtn.snp.bottom)
            make.left.right.equalToSuperview().inset(8)
            make.height.equalTo(UsersDynamicTakePhotosActionSheet.splitLineHeight)
        }
        
        photoAlbumBtn.snp.makeConstraints { (make) in
            make.top.equalTo(firstSplitLine.snp.bottom)
            make.left.right.equalToSuperview()
            make.height.equalTo(UsersDynamicTakePhotosActionSheet.sheetHeight)
        }
        
        secondSplitLine.snp.makeConstraints { (make) in
            make.top.equalTo(photoAlbumBtn.snp.bottom)
            make.left.right.equalToSuperview().inset(8)
            make.height.equalTo(UsersDynamicTakePhotosActionSheet.splitLineHeight)
        }
        
        cancelBtn.snp.makeConstraints { (make) in
            make.top.equalTo(secondSplitLine.snp.bottom)
            make.left.right.equalToSuperview()
            make.height.equalTo(UsersDynamicTakePhotosActionSheet.sheetHeight)
        }
        
        return view
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        alpha = 0
        backgroundColor = UIColor.black.withAlphaComponent(0.3)
        let tap = UITapGestureRecognizer(target: self, action: #selector(onCancelBtnTap))
        isUserInteractionEnabled = true
        addGestureRecognizer(tap)
        addSubview(actionSheetView)
        addSubview(actionSheetView)
        
        actionSheetView.snp.makeConstraints { (make) in
            make.height.equalTo(UsersDynamicTakePhotosActionSheet.actionSheetViewHeight)
            make.left.right.equalToSuperview()
            make.bottom.equalToSuperview().inset(-UsersDynamicTakePhotosActionSheet.actionSheetViewHeight)
        }
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func renderView() {
        
    }
    
    @objc private func onTakePhotosBtnTap() {
        delegate?.choosePhotosType(type: .takePhotos)
        stopAnimation()
    }
    
    @objc private func onPhotoAlbumBtnTap() {
        delegate?.choosePhotosType(type: .photoAlbum)
        stopAnimation()
    }
    
    @objc private func onCancelBtnTap() {
        stopAnimation()
    }
    
    func startAnimation() {
        actionSheetView.snp.updateConstraints { (make) in
            make.bottom.equalToSuperview().inset(-UsersDynamicTakePhotosActionSheet.actionSheetMarginBottom)
        }
        updateViewConstraints()
        UIView.animate(withDuration: 0.3) { [weak self] in
            self?.alpha = 1
            self?.layoutIfNeeded()
        }
    }
    
    func stopAnimation() {
        actionSheetView.snp.updateConstraints { (make) in
            make.bottom.equalToSuperview().inset(-UsersDynamicTakePhotosActionSheet.actionSheetViewHeight)
        }
        updateViewConstraints()
        UIView.animate(withDuration: 0.3) { [weak self] in
            self?.alpha = 0
            self?.layoutIfNeeded()
        }
    }
    
    private func updateViewConstraints() {
        self.updateConstraintsIfNeeded()
        self.updateFocusIfNeeded()
    }
}
