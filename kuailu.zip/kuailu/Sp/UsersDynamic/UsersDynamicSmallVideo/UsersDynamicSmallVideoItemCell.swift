//
//  UsersDynamicSmallVideoItemCell.swift
//  Sp
//
//  Created by mac on 2020/11/10.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class UsersDynamicSmallVideoItemCell: UICollectionViewCell {
    
    static let horizontalMargin: CGFloat = 0
    
    static let itemInteritemSpacing: CGFloat = 2
    
    static let columnNum: CGFloat = 2
    
    private static let contentInset: UIEdgeInsets = {
        return UIEdgeInsets(top: 0, left: UsersDynamicSmallVideoItemCell.horizontalMargin, bottom: 0, right: UsersDynamicSmallVideoItemCell.horizontalMargin)
    }()
    
    private static let itemSize: CGSize = {
        return CGSize(width: UsersDynamicSmallVideoSubCell.itemWidth, height: UsersDynamicSmallVideoSubCell.itemHeight)
    }()
    
    private lazy var collectionView: UICollectionView = {
        let layout = UICollectionViewFlowLayout()
        layout.minimumLineSpacing = UsersDynamicSmallVideoItemCell.itemInteritemSpacing
        layout.minimumInteritemSpacing = UsersDynamicSmallVideoItemCell.itemInteritemSpacing
        layout.itemSize = UsersDynamicSmallVideoItemCell.itemSize
        let cv = UICollectionView(frame: .zero, collectionViewLayout: layout)
        cv.register(UsersDynamicSmallVideoSubCell.self, forCellWithReuseIdentifier: "UsersDynamicSmallVideoSubCell")
        cv.contentInset = UsersDynamicSmallVideoItemCell.contentInset
        cv.backgroundColor = .none
        cv.delegate = self
        cv.dataSource = self
        cv.showsHorizontalScrollIndicator = false
        cv.isDirectionalLockEnabled = true
        cv.state = .loading
        cv.mj_header = getCommonMJHeader(refreshingTarget: self, headerRefreshCallback: #selector(onRefresh))
        cv.mj_footer = getCommonMJFooter(refreshingTarget: self, footerRefreshCallback: #selector(onLoad))
        return cv
    }()
    
    private lazy var pageNum: Int = 0
    
    private lazy var listData: [VideoItem] = []
    
    private var isInitState: Bool = true
    
    weak var delegate: UsersDynamicVCDelegate?
    
    var userId: Int? {
        didSet {
            guard isInitState else { return }
            isInitState = userId == nil
            getList(isRefresh: true)
        }
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        addSubview(collectionView)
        collectionView.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func getList(isRefresh: Bool) {
        guard let Id = userId else { return }
        collectionView.state = listData.isEmpty ? .loading : .normal
        let req = PublishedVideoReq()
        req.userId = Id
        let pageNum = self.pageNum
        req.page =  isRefresh ? 1 : pageNum + 1
        if isRefresh {
            collectionView.mj_footer?.resetNoMoreData()
        }
        let collectionView = self.collectionView
        Session.request(req) { [weak self] (error, resp) in
            isRefresh ? collectionView.mj_header?.endRefreshing() : collectionView.mj_footer?.endRefreshing()
            guard let `self` = self else { return }
            guard error == nil, let resData = resp as? [VideoItem] else {
                self.handleListException(isRefresh: isRefresh, pageNum: pageNum)
                return
            }
            
            self.pageNum = req.page
            self.listData = isRefresh ? resData : self.listData + resData
            
            let isEmpty = self.listData.isEmpty
            collectionView.reloadData()
            collectionView.state = isEmpty ? .empty : .normal
            collectionView.mj_footer?.isHidden = isEmpty
            if resData.count < req.pageSize {
                collectionView.mj_footer?.endRefreshingWithNoMoreData()
            }
        }
    }
    
    private func handleListException(isRefresh: Bool, pageNum: Int) {
        if isRefresh || pageNum == 1 {
            listData = []
            collectionView.reloadData()
            collectionView.state = .failed
            collectionView.mj_footer?.isHidden = true
            delegate?.refreshCategoryBarNum(listCount: 0, type: .smallVideo)
        } else {
            collectionView.state = .normal
            collectionView.mj_footer?.endRefreshingWithNoMoreData()
            collectionView.mj_footer?.isHidden = false
            delegate?.refreshCategoryBarNum(listCount: listData.count, type: .smallVideo)
        }
    }
    
    @objc private func onLoad() {
        getList(isRefresh: false)
    }
    
    @objc private func onRefresh() {
        getList(isRefresh: true)
    }
    
    private func deleteUploadVideo(videoId: Int) {
        Alert.showLoading(parentView: UIApplication.shared.keyWindow!)
        let req = DeleteVideoReq()
        req.videoId = videoId
        Session.request(req) {[weak self] (error, resp) in
            Alert.hideLoading()
            guard let `self` = self else { return }
            guard error == nil else {
                mm_showToast(error?.localizedDescription ?? "伺服器異常！")
                return
            }
            self.onRefresh()
            mm_showToast("視頻刪除成功！", type: .succeed)
        }
    }
    
}

extension UsersDynamicSmallVideoItemCell: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return listData.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "UsersDynamicSmallVideoSubCell", for: indexPath) as! UsersDynamicSmallVideoSubCell
        cell.dataModel = listData[indexPath.row]
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let currentItem = listData[indexPath.row]
        guard currentItem.videoStatus == .approved else {
            Alert.showCommonAlert(parentView: UIApplication.shared.keyWindow!, contentText: currentItem.videoStatus != .denied ? "確定要刪除該視頻嗎？" : "\(currentItem.notPass)，確定要刪除該視頻嗎？", cancelText: "取消", confirmText: "確定", onConfirmTap: { [weak self] in
                self?.deleteUploadVideo(videoId: currentItem.videoId)
            }, onCancelTap: nil)
            return
        }
        let videoList = listData.filter{ $0.videoStatus == .approved }
        SearchResultVC.navigationToVideoPlayListVC(indexPath: IndexPath(item: videoList.firstIndex(where: { $0.videoId == currentItem.videoId
        }) ?? 0, section: 0), VideoList: videoList)
    }
}

