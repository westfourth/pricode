//
//  UsersDynamicSmallVideoSubCell.swift
//  Sp
//
//  Created by mac on 2020/11/10.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class UsersDynamicSmallVideoSubCell: UICollectionViewCell {
    
    static let itemWidth: CGFloat = {
        return (UIScreen.main.bounds.width - UsersDynamicSmallVideoItemCell.horizontalMargin * 2 - (UsersDynamicSmallVideoItemCell.columnNum - 1) * UsersDynamicSmallVideoItemCell.itemInteritemSpacing) / UsersDynamicSmallVideoItemCell.columnNum
    }()
    
    static let itemHeight: CGFloat = {
        return UsersDynamicSmallVideoSubCell.posterImgViewHeight + UsersDynamicSmallVideoSubCell.titleLabelMarginTop +  UsersDynamicSmallVideoSubCell.titleLabelHeight
    }()
    
    private static let posterImgViewHeight: CGFloat = {
        return UsersDynamicSmallVideoSubCell.itemWidth / 178 * 236
    }()
    
    private static let titleLabelHeight: CGFloat = 36
    
    private static let titleLabelMarginTop: CGFloat = 9
    
    static let animationOption: KingfisherOptionsInfo = {
        return [.transition(.fade(0.25))]
    }()
    
    private static let collectionIconImg: UIImage? = {
        return UIImage(named: "ic_b_like_2")
    }()
    
    private static let lockIconImg: UIImage? = {
        return UIImage(named: "ic_lock")
    }()
    
    private static let v6IconImg: UIImage? = {
        return UIImage(named: "v6_icon")
    }()
    
    private static let gradientColors: [CGColor] = {
        return [UIColor.black.withAlphaComponent(0).cgColor, UIColor.black.withAlphaComponent(0.4).cgColor]
    }()
    
    private static let gradientLocations: [NSNumber] = {
        return [0, 1]
    }()
    
    private static let maskLayerViewHeight: CGFloat = 40
    
    private static let reviewColors: [CGColor] = {
        let startColor = UIColor(red: CGFloat(255)/255, green: CGFloat(103)/255, blue:CGFloat(103)/255, alpha: 0)
        let endColor = UIColor(red: 216/255, green: 0, blue: 255/255, alpha: 0.2)
        return [startColor.cgColor, endColor.cgColor]
    }()
    
    private lazy var posterImgView: UIImageView = {
        let imgView = UIImageView()
        imgView.contentMode = .scaleAspectFill
        imgView.layer.masksToBounds = true
        return imgView
    }()
    
    private lazy var collectionIconImgView: UIImageView = {
        let imgView = UIImageView(image: UsersDynamicSmallVideoSubCell.collectionIconImg)
        return imgView
    }()
    
    private lazy var collectionNumberLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.pingFangRegular(12)
        label.textColor = .white
        return label
    }()
    
    private lazy var maskLayerView: UIView = {
        let maskView = UIView()
        let gradientLayer = CAGradientLayer()
        gradientLayer.colors = UsersDynamicSmallVideoSubCell.gradientColors
        gradientLayer.locations = UsersDynamicSmallVideoSubCell.gradientLocations
        gradientLayer.frame = CGRect(x: 0, y: 0, width: self.width, height: UsersDynamicSmallVideoSubCell.maskLayerViewHeight)
        maskView.layer.insertSublayer(gradientLayer, at: 0)
        maskView.addSubview(collectionIconImgView)
        maskView.addSubview(collectionNumberLabel)
        
        collectionIconImgView.snp.makeConstraints { (make) in
            make.size.equalTo(12)
            make.left.equalToSuperview().inset(9)
            make.bottom.equalToSuperview().inset(10)
        }
        
        collectionNumberLabel.snp.makeConstraints { (make) in
            make.left.equalTo(collectionIconImgView.snp.right).offset(4.5)
            make.centerY.equalTo(collectionIconImgView)
        }
        return maskView
    }()
    
    private lazy var v6ImgView: UIImageView = {
        let imgView = UIImageView(image: UsersDynamicSmallVideoSubCell.v6IconImg)
        imgView.isHidden = true
        return imgView
    }()
    
    private lazy var lockImgView: UIImageView = {
        let imgView = UIImageView(image: UsersDynamicSmallVideoSubCell.lockIconImg)
        return imgView
    }()
    
    private lazy var lockLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.pingFangRegular(12)
        label.textColor = .white
        label.text = "V6專享視頻"
        return label
    }()
    
    private lazy var lockMaskView: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor.black.withAlphaComponent(0.3)
        view.addSubview(lockImgView)
        view.addSubview(lockLabel)
        view.isHidden = true
        
        lockImgView.snp.makeConstraints { (make) in
            make.centerX.equalToSuperview()
            make.centerY.equalToSuperview().offset(-14)
            make.width.equalTo(40)
            make.height.equalTo(44)
        }
        
        lockLabel.snp.makeConstraints { (make) in
            make.centerX.equalToSuperview()
            make.top.equalTo(lockImgView.snp.bottom).offset(10)
        }
        return view
    }()
    
    private lazy var reviewGradientLayer: CAGradientLayer = {
        let gradientLayer = CAGradientLayer()
        gradientLayer.colors = UsersDynamicSmallVideoSubCell.reviewColors
        gradientLayer.startPoint = .zero
        gradientLayer.endPoint = CGPoint(x: 1, y: 1)
        gradientLayer.frame = reviewLabel.bounds
        return gradientLayer
    }()
    
    private lazy var reviewLabel: UILabel = {
        let label = UILabel()
        label.textColor = .white
        label.font = UIFont.pingFangHeavy(13)
        label.textAlignment = .center
        return label
    }()
    
    private lazy var titleLabel: CustomLabel = {
        let label = CustomLabel()
        label.textColor = .white
        label.font = UIFont.pingFangRegular(11)
        label.numberOfLines = 2
        label.verticalAlignment = .top
        return label
    }()
    
    var dataModel: VideoItem? {
        didSet {
            guard let item = dataModel else { return }
            posterImgView.kf.setImage(with: item.coverImg?.column2, placeholder: Sensitive.default_bg, options: UsersDynamicSmallVideoSubCell.animationOption)
            collectionNumberLabel.text = item.fakeLikes > 0 ? num2TenThousandStrFormat(item.fakeLikes) : "0"
            titleLabel.text = item.title
            reviewLabel.isHidden = item.videoStatus == .approved
            reviewLabel.text = item.videoStatus == .approved ? "" : item.videoStatus == .waitingApproved ? "審核中..." : "審核未通過"
            lockMaskView.isHidden = !(item.isSpecial && NetDefaults.userInfo?.specialAuth != true)
            v6ImgView.isHidden = !item.isSpecial
        }
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        renderView()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func renderView() {
        addSubview(posterImgView)
        addSubview(maskLayerView)
        addSubview(titleLabel)
        addSubview(reviewLabel)
        addSubview(lockMaskView)
        addSubview(v6ImgView)
        
        posterImgView.snp.makeConstraints { (make) in
            make.top.left.right.equalToSuperview()
            make.height.equalTo(UsersDynamicSmallVideoSubCell.posterImgViewHeight)
        }
        
        maskLayerView.snp.makeConstraints { (make) in
            make.left.right.bottom.equalTo(posterImgView)
            make.height.equalTo(UsersDynamicSmallVideoSubCell.maskLayerViewHeight)
        }
        
        titleLabel.snp.makeConstraints { (make) in
            make.top.equalTo(posterImgView.snp.bottom).offset(UsersDynamicSmallVideoSubCell.titleLabelMarginTop)
            make.left.right.equalToSuperview().inset(4)
            make.height.equalTo(UsersDynamicSmallVideoSubCell.titleLabelHeight)
        }
        
        reviewLabel.snp.makeConstraints { (make) in
            make.top.left.right.equalToSuperview()
            make.height.equalTo(30)
        }
        
        lockMaskView.snp.makeConstraints { (make) in
            make.edges.equalTo(posterImgView)
        }
        
        v6ImgView.snp.makeConstraints { (make) in
            make.top.equalToSuperview().inset(8)
            make.left.equalToSuperview()
            make.width.equalTo(42)
            make.height.equalTo(14)
        }
        
        reviewLabel.layer.insertSublayer(reviewGradientLayer, at: 0)
    }
}
