//
//  UsersDynamicRewardAlert.swift
//  Sp
//
//  Created by mac on 2020/7/1.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class UsersDynamicRewardAlert: UIView {
    
    private static let characterSet: CharacterSet = {
        let inputLimitCharacters: String = "0123456789"
        return NSCharacterSet(charactersIn: inputLimitCharacters).inverted
    }()
    
    private static let rewardAlertTopImg: UIImage? = {
        let img = UIImage.decrypt("users_dynamic_reward_alert_bg.png.enc")
        return img
    }()
    
    private static let maxKeyWordsLen: Int = 15
    
    private lazy var topImgView: UIImageView = {
        let imgView = UIImageView(image: UsersDynamicRewardAlert.rewardAlertTopImg)
        return imgView
    }()
    
    private lazy var confirmGradientLayer: CAGradientLayer = {
        let gradientColors = [RGB(0xFE6000).cgColor, RGB(0xFC9239).cgColor]
        let gradientLocations:[NSNumber] = [0, 1]
        let gradientLayer = CAGradientLayer()
        gradientLayer.colors = gradientColors
        gradientLayer.locations = gradientLocations
        gradientLayer.startPoint = CGPoint(x: 0, y: 1)
        gradientLayer.endPoint  = CGPoint(x: 1.0, y: 1)
        gradientLayer.frame = CGRect(x: 0, y: 0, width: 144, height: 49)
        return gradientLayer
    }()
    
    private lazy var cancelGradientLayer: CAGradientLayer = {
        let gradientColors = [RGB(0xB0B0B0).cgColor, RGB(0x898989).cgColor]
        let gradientLocations:[NSNumber] = [0, 1]
        let gradientLayer = CAGradientLayer()
        gradientLayer.colors = gradientColors
        gradientLayer.locations = gradientLocations
        gradientLayer.startPoint = CGPoint(x: 0, y: 1)
        gradientLayer.endPoint  = CGPoint(x: 1.0, y: 1)
        gradientLayer.frame = CGRect(x: 0, y: 0, width: 144, height: 49)
        return gradientLayer
    }()
    
    private lazy var rewardConfirmBtn: UIButton = {
        let btn = UIButton()
        btn.setTitle("立即\(Sensitive.shang)", for: .normal)
        btn.setTitleColor(.white, for: .normal)
        btn.titleLabel?.font = UIFont.pingFangMedium(15)
        btn.addTarget(self, action: #selector(onRewardConfirmBtnTap), for: .touchUpInside)
        btn.layer.insertSublayer(confirmGradientLayer, at: 0)
        return btn
    }()
    
    private lazy var rewardCancelBtn: UIButton = {
        let btn = UIButton()
        btn.setTitle("取消", for: .normal)
        btn.titleLabel?.font = UIFont.pingFangMedium(15)
        btn.addTarget(self, action: #selector(onRewardCancelBtnTap), for: .touchUpInside)
        btn.layer.insertSublayer(cancelGradientLayer, at: 0)
        return btn
    }()
    
    private lazy var coinLabel: UILabel = {
        let label = UILabel()
        label.text = Sensitive.jin
        label.textColor = RGB(0xFA6400)
        label.font = UIFont.pingFangRegular(15)
        return label
    }()
    
    private lazy var inputFieldWrapperView: UIView = {
        let view = UIView()
        view.layer.cornerRadius = 4
        view.backgroundColor = RGB(0xF5F5F5)
        return view
    }()
    
    private lazy var inputField: UITextField = {
        let input  = UITextField()
        input.placeholder = "請輸入\(Sensitive.shang)\(Sensitive.e)"
        input.text = ""
        input.textColor = .black
        input.setValue(rgb(0xA4A4A4), forKeyPath: "placeholderLabel.textColor")
        input.setValue(font(14), forKeyPath: "placeholderLabel.font")
        input.font = font(14)
        input.delegate = self
        input.textAlignment = .left
        input.keyboardType = .numberPad
        input.returnKeyType = .done
        input.backgroundColor = .none
        input.addDoneOnKeyboardWithTarget(self, action: #selector(onInputDoneBtnTap))
        return input
    }()
    
    private lazy var placeholderLabel: UILabel = {
        let label = UILabel()
        label.text = "備註"
        label.textColor = rgb(0x949494)
        label.font = font(14)
        return label
    }()
    
    private lazy var remarkTextView: UITextView = {
        let textView = UITextView()
        textView.delegate = self
        textView.addSubview(placeholderLabel)
        textView.setValue(placeholderLabel, forKeyPath: "placeholderLabel")
        textView.font = font(16)
        textView.textColor = .black
        textView.textColor = rgb(0x4C4C4C)
        textView.layer.masksToBounds = true
        textView.layer.cornerRadius = 4
        textView.backgroundColor = RGB(0xF5F5F5)
        textView.addDoneOnKeyboardWithTarget(self, action: #selector(onRemarkTextDoneBtnTap))
        return textView
    }()
    
    private lazy var rewardAlertWrapperView: UIView = {
        let view = UIView()
        view.backgroundColor = .white
        view.isUserInteractionEnabled = true
        view.layer.masksToBounds = true
        view.layer.cornerRadius = 12
        view.addSubview(inputFieldWrapperView)
        view.addSubview(coinLabel)
        view.addSubview(inputField)
        view.addSubview(remarkTextView)
        view.addSubview(rewardCancelBtn)
        view.addSubview(rewardConfirmBtn)
        
        inputFieldWrapperView.snp.makeConstraints { (make) in
            make.top.equalToSuperview().inset(56)
            make.left.right.equalToSuperview().inset(28)
            make.height.equalTo(32)
        }
        
        coinLabel.snp.makeConstraints { (make) in
            make.centerY.equalTo(inputFieldWrapperView)
            make.right.equalTo(inputFieldWrapperView).offset(-18)
        }
        
        inputField.snp.makeConstraints { (make) in
            make.left.equalTo(inputFieldWrapperView).offset(9)
            make.top.bottom.equalTo(inputFieldWrapperView)
            make.right.equalTo(inputFieldWrapperView).offset(-60)
        }
        
        remarkTextView.snp.makeConstraints { (make) in
            make.top.equalTo(inputField.snp.bottom).offset(13)
            make.centerX.equalToSuperview()
            make.width.equalTo(232)
            make.height.equalTo(95)
        }
        
        rewardCancelBtn.snp.makeConstraints { (make) in
            make.left.bottom.equalToSuperview()
            make.width.equalToSuperview().multipliedBy(0.5)
            make.height.equalTo(49)
        }
        
        rewardConfirmBtn.snp.makeConstraints { (make) in
            make.right.bottom.equalToSuperview()
            make.width.equalToSuperview().multipliedBy(0.5)
            make.height.equalTo(49)
        }
        return view
    }()
    
    private lazy var wrapperMaskView: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor.black.withAlphaComponent(0.3)
        let tap = UITapGestureRecognizer(target: self, action: #selector(onMaskViewTap))
        view.isUserInteractionEnabled = true
        view.addGestureRecognizer(tap)
        return view
    }()
    
    var successClosure: (() -> ())?
    
    var userId: Int?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        alpha = 0
        renderView()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    deinit {
        successClosure = nil
    }
    
    private func renderView() {
        addSubview(wrapperMaskView)
        addSubview(rewardAlertWrapperView)
        addSubview(topImgView)
        
        wrapperMaskView.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
        
        rewardAlertWrapperView.snp.makeConstraints { (make) in
            make.center.equalToSuperview()
            make.width.equalTo(288)
            make.height.equalTo(290)
        }
        
        topImgView.snp.makeConstraints { (make) in
            make.top.equalTo(rewardAlertWrapperView).offset(-72)
            make.centerX.equalToSuperview()
            make.width.equalTo(90)
            make.height.equalTo(120)
        }
    }
    
    @objc private func onInputDoneBtnTap() {
        inputField.resignFirstResponder()
    }
    
    @objc private func onRemarkTextDoneBtnTap() {
        remarkTextView.resignFirstResponder()
    }
    
    @objc private func onMaskViewTap() {
        stopAnimation()
    }
    
    @objc private func onRewardConfirmBtnTap() {
        guard let userId = self.userId else { return }
        guard let val = inputField.text, let gold = Double(val) else {
            mm_showToast("親，請輸入\(Sensitive.shang)\(Sensitive.jin)哦！")
            return
        }
        guard gold <= WalletVC.coinVal else {
            stopAnimation()
            mm_showToast("\(Sensitive.jin)不足哦，請\(Sensitive.gou)\(Sensitive.jin)！") {
                guard let navigationController = (UIApplication.shared.delegate as? AppDelegate)?.currentNavigationController else { return }
                VipChargeTipVC.isFromVideoPlayList = false
                let vipVC = Vip2VC()
                vipVC.uiType = .coin
                navigationController.show(vipVC, sender: nil)
            }
            return
        }
        Alert.showLoading(parentView: UIApplication.shared.keyWindow!)
        let req = RewardHostReq()
        req.gold = Int(gold)
        if !remarkTextView.text.isEmpty {
            req.remark = remarkTextView.text
        }
        req.userId = userId
        Session.request(req) { [weak self] (error, resp) in
            Alert.hideLoading()
            guard let `self` = self else { return }
            guard error == nil else {
                self.stopAnimation()
                mm_showToast(error!.localizedDescription, type: .failed)
                return
            }
            self.successClosure?()
            self.stopAnimation()
            mm_showToast("恭喜您，\(Sensitive.shang)成功！", type: .succeed)
        }
    }
    
    @objc private func onRewardCancelBtnTap() {
        stopAnimation()
    }
    
    func startAnimation() {
        UIView.animate(withDuration: 0.3) { [weak self] in
            self?.alpha = 1
        }
    }
    
    func stopAnimation() {
        inputField.resignFirstResponder()
        UIView.animate(withDuration: 0.3, animations: { [weak self] in
            self?.alpha = 0
        }) { [weak self] _ in
            guard let `self` = self else { return }
            self.inputField.text = ""
            self.remarkTextView.text = ""
            self.removeFromSuperview()
        }
    }
}

extension UsersDynamicRewardAlert: UITextFieldDelegate {
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        let filtered = string.components(separatedBy: UsersDynamicRewardAlert.characterSet).joined(separator: "")
        guard string == filtered else { return false }
        guard string == "0" else {
            //            guard string != "." else { return false }
            return true
        }
        guard let text = textField.text else { return true }
        if text.count == 0 {
            textField.text = ""
            return false
        }
        return true
    }
    
}

extension UsersDynamicRewardAlert: UITextViewDelegate {
    
    func textView(_ textView: UITextView, shouldChangeTextIn range: NSRange, replacementText text: String) -> Bool {
        let len = textView.text!.count + text.count - range.length
        if len <= UsersDynamicRewardAlert.maxKeyWordsLen {
            return true
        } else {
            remarkTextView.resignFirstResponder()
            mm_showToast("備註最長\(UsersDynamicRewardAlert.maxKeyWordsLen)個字符")
            return false
        }
    }
    
}
