//
//  UsersDynamicDetailsEmptyView.swift
//  Sp
//
//  Created by mac on 2020/6/22.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class UsersDynamicDetailsEmptyView: UIView {
    
    private static let publishImg: UIImage? = {
        return UIImage(named: "publish_icon_big")
    }()
    
    private lazy var titleLabel: UILabel = {
        let label = UILabel()
        label.text = "您當前還未發布任何動態哦"
        label.font = UIFont.pingFangRegular(13)
        label.textColor = RGB(0xD5D5D5)
        return label
    }()
    
    private lazy var publishBtn: UIButton = {
        let btn = UIButton()
        btn.setBackgroundImage(UsersDynamicDetailsEmptyView.publishImg, for: .normal)
        btn.addTarget(self, action: #selector(onPublishBtn), for: .touchUpInside)
        return btn
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        addSubview(titleLabel)
        
        addSubview(publishBtn)
        
        titleLabel.snp.makeConstraints { (make) in
            make.centerX.equalToSuperview()
            make.top.equalToSuperview().inset(IS_IPHONEX ? 80 : 60)
        }
        
        
        publishBtn.snp.makeConstraints { (make) in
            make.top.equalTo(titleLabel.snp.bottom).offset(50)
            make.centerX.equalToSuperview()
            make.width.equalTo(122)
            make.height.equalTo(46)
        }
        
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    @objc private func onPublishBtn() {
        
        guard NetDefaults.userInfo?.freeWatches == -1 else {
            PurchaseVipAlert.showPurchaseVipAlert()
            return
        }
        
        guard UploadConfig.shared.info.allow else {
            mm_showToast("系統維護中，暫不能上傳視頻!")
            return
        }
        
        guard let navigationController = (UIApplication.shared.delegate as? AppDelegate)?.currentNavigationController else { return }
        
        let timeLinePublishVC = TimeLinePublishVC()
        timeLinePublishVC.hidesBottomBarWhenPushed = true
        navigationController.show(timeLinePublishVC, sender: nil)
    }
    
}
