//
//  UsersDynamicDetailsItemCell.swift
//  Sp
//
//  Created by mac on 2020/6/16.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

extension Notification.Name {
    /// 更新用户动态模块列表
    static let UpdateUsersDynamicDetailsList = Notification.Name(rawValue:"UpdateUsersDynamicDetailsList")
}

protocol UsersDynamicDetailsItemCellDelegate: NSObjectProtocol {
    
    func switchToHighlights()
}

class UsersDynamicDetailsItemCell: UICollectionViewCell {
    
    private lazy var emptyView: UsersDynamicDetailsEmptyView = {
        let view = UsersDynamicDetailsEmptyView()
        view.isHidden = true
        return view
    }()
    
    private lazy var tableView : UITableView = {
        let tableView = UITableView.init(frame: .zero, style: .plain)
        tableView.delegate = self
        tableView.dataSource = self
        tableView.backgroundColor = .none
        tableView.separatorStyle = .none
        tableView.tableFooterView = nil
        tableView.register(UINib(nibName: "TimeLineCell", bundle: .main), forCellReuseIdentifier: "TimeLineCell")
        tableView.bouncesZoom = false
        tableView.showsHorizontalScrollIndicator = false
        tableView.state = .loading
        tableView.mj_header = getCommonMJHeader(refreshingTarget: self, headerRefreshCallback: #selector(onRefresh))
        tableView.mj_footer = getCommonMJFooter(refreshingTarget: self, footerRefreshCallback: #selector(onLoad))
        return tableView
    }()
    
    private lazy var bannerDeleteMaskView: UsersDynamicBannerDeleteMaskView = {
        let view = UsersDynamicBannerDeleteMaskView()
        return view
    }()
    
    private lazy var listData: [TimeLineItem] = []
    
    private var isInitState: Bool = true
    
    weak var delegate: UsersDynamicVCDelegate?
    
    weak var switchDelegate: UsersDynamicDetailsItemCellDelegate?
    
    var userId: Int? {
        didSet {
            guard isInitState else { return }
            isInitState = userId == nil
            getList(isRefresh: true)
        }
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        NotificationCenter.default.addObserver(self, selector: #selector(refreshCollectionView), name: .UpdateUsersDynamicDetailsList, object: nil)
        addSubview(emptyView)
        addSubview(tableView)
        
        emptyView.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
        
        tableView.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    deinit {
        NotificationCenter.default.removeObserver(self)
    }
    
    private func getList(isRefresh: Bool) {
        guard let Id = userId else { return }
        tableView.state = listData.isEmpty ? .loading : .normal
        let req = TimeLineListReq()
        req.userId = Id
        if !isRefresh {
            req.lastDynamicId = (listData.last?.dynamicId ?? 0)
        }
        if isRefresh {
            tableView.mj_footer?.resetNoMoreData()
        }
        let tableView = self.tableView
        Session.request(req) { [weak self] (error, resp) in
            isRefresh ? tableView.mj_header?.endRefreshing() : tableView.mj_footer?.endRefreshing()
            guard let `self` = self else { return }
            guard error == nil, var resData = resp as? [TimeLineItem] else {
                self.handleListException(isRefresh: isRefresh)
                return
            }
            if let user = NetDefaults.userInfo {
                resData = resData.map {
                    $0.belongType = user.userId == Id ? .mine : .other
                    if let videoUrl = $0.video?.videoUrl {
                        $0.video?.videoUrl = URL(string: videoUrl.absoluteString.replacingOccurrences(of: "?path=", with: "/dynamic?path="))
                    }
                    return $0
                }
            }
            self.listData = isRefresh ? resData : self.listData + resData
            let isEmpty = self.listData.isEmpty
            tableView.state = isEmpty ? .empty : .normal
            self.emptyView.isHidden = !(NetDefaults.userInfo?.userId == self.userId && isEmpty)
            tableView.isHidden = !self.emptyView.isHidden
            tableView.mj_footer?.isHidden = isEmpty
            tableView.reloadData()
            if resData.isEmpty {
                DispatchQueue.main.async {
                    tableView.mj_footer?.endRefreshingWithNoMoreData()
                }
            }
        }
    }
    
    private func handleListException(isRefresh: Bool) {
        if isRefresh {
            listData = []
            tableView.reloadData()
            tableView.state = .failed
            tableView.mj_footer?.isHidden = true
            delegate?.refreshCategoryBarNum(listCount: 0, type: .dynamic)
        } else {
            tableView.state = .normal
            tableView.mj_footer?.endRefreshingWithNoMoreData()
            tableView.mj_footer?.isHidden = false
            delegate?.refreshCategoryBarNum(listCount: listData.count, type: .dynamic)
        }
    }
    
    @objc private func onLoad() {
        getList(isRefresh: false)
    }
    
    @objc private func onRefresh() {
        getList(isRefresh: true)
    }
    
    @objc private func refreshCollectionView() {
        guard listData.isEmpty else { return }
        getList(isRefresh: true)
    }
    
}

extension UsersDynamicDetailsItemCell: UITableViewDataSource,UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return listData.count
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return TimeLineCell.height(listData[indexPath.row])
    }
    
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return .leastNonzeroMagnitude
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return .leastNonzeroMagnitude
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        return nil
    }
    
    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        return nil
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "TimeLineCell") as! TimeLineCell
        cell.item = listData[indexPath.row]
        cell.vip_icon.isHidden = true
        cell.delegate = self
        return cell
    }
    
}


extension UsersDynamicDetailsItemCell:TimeLineCellDelegate {
    
    func timeLineCell(cell: TimeLineCell, avatar: UIImageView, item: TimeLineItem) {
        
    }
    
    func timeLineCell(cell: TimeLineCell, activityItem item: TimeLineItem) {
//        let appDelegate = UIApplication.shared.delegate as! AppDelegate
//        guard let navi = appDelegate.currentNavigationController else {return}
//        let tabbar = UIApplication.shared.keyWindow?.rootViewController as! UITabBarController
//        tabbar.selectedIndex = 1
//        navi.popToRootViewController(animated: true)
//        guard let navi1 = tabbar.selectedViewController as? UINavigationController, let classyVC = navi1.topViewController as? ClassyVC else {return}
//        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() +  0.5) {
//            classyVC.switchToCategoryBar(type: .leapboardActivity)
//        }
        
        let vc = ChatVC()
        vc.fromUserId = item.userId
        vc.name = item.nickName
        vc.hidesBottomBarWhenPushed = true
        InnerIntercept.currentNaviController().pushViewController(vc, animated: true)
    }
    
    func timeLineCell(cell: TimeLineCell, focus: UIButton, item: TimeLineItem) {
        Animation.scaleBounce(focus)
        if item.sourceType == .beauty {
            // 约更多
            let appDelegate = UIApplication.shared.delegate as! AppDelegate
            guard let navi = appDelegate.currentNavigationController else {return}
            if navi.topViewController is UsersDynamicVC {
                let tabbar = UIApplication.shared.keyWindow?.rootViewController as! UITabBarController
                tabbar.selectedIndex = 3
                navi.popViewController(animated: true)
                DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 0.5) {
                    let appDelegate1 = UIApplication.shared.delegate as! AppDelegate
                    guard let navi1 = appDelegate1.currentNavigationController else {return}
                    let vc = navi1.topViewController! as! ChatSexVC
                    vc.topView.currentIndex = 2
                    vc.chatTopBar(didSelect: 2)
                }
            }
        } else if item.sourceType  == .portray {
            //写真
            let appDelegate = UIApplication.shared.delegate as! AppDelegate
            guard let navi = appDelegate.currentNavigationController else {return}
            let vc = PhotoVC()
            vc.hidesBottomBarWhenPushed = true
            navi.pushViewController(vc, animated: true)
        } else if item.sourceType == .feautures {
            switchDelegate?.switchToHighlights()
        }
    }
    
    func timeLineCell(cell: TimeLineCell, playVideo item:TimeLineItem ) {
        
        guard NetDefaults.userInfo?.freeWatches == -1 else {
            PurchaseVipAlert.showPurchaseVipAlert()
            return
        }
        
        guard let video = item.video else {return}
        let vc = ShortVideoListVC()
        vc.fromDynamic = true
        vc.currentPlayingIndexPath = IndexPath(item: 0, section: 0)
        vc.videoItems = [video]
        vc.hidesBottomBarWhenPushed = true
        currentNaviController().show(vc, sender: nil)
    }
    
    // 点击约更多
    func timeLineCell(cell: TimeLineCell, beautyTap item: TimeLineItem) {
        
    }
    
    func timeLineCell(cell: TimeLineCell, like: UIButton,item:TimeLineItem) {
        Animation.scaleBounce(like)
        like.isSelected = !like.isSelected
        var count = Int(like.title(for: .normal) ?? "0") ?? 0
        if like.isSelected {
            //点赞
            let req = TimeLineLikeReq()
            req.dynamicId = item.dynamicId
            Alert.showLoading(parentView: self)
            Session.request(req) { (e, resp) in
                Alert.hideLoading()
                guard e == nil else {
                    mm_showToast(e!.localizedDescription)
                    like.isSelected = false
                    return
                }
                count = count + 1
                like.setTitle("\(count)", for: .normal)
                item.commentNum = count
                item.isLike = true
                mm_showToast("點贊成功！",type: .succeed)
            }
        } else {
            let req = TimeLineCancelLikeReq()
            req.dynamicId = item.dynamicId
            Alert.showLoading(parentView: self)
            Session.request(req) { (e, resp) in
                Alert.hideLoading()
                guard e == nil else {
                    mm_showToast(e!.localizedDescription)
                    like.isSelected = true
                    return
                }
                count = count >= 0 ? count - 1:0
                like.setTitle("\(count)", for: .normal)
                item.commentNum = count
                item.isLike = false
                mm_showToast("取消點贊成功！",type: .succeed)
            }
        }
    }
    
    func timeLineCell(cell: TimeLineCell, comment: UIButton,item:TimeLineItem) {
        Animation.scaleBounce(comment)
        guard item.status == .approved else {
            let warning = item.status == .reviewing ? "動態審核中，請耐心等待哦～" :"審核失敗，理由:\(item.notPass)"
            mm_showToast(warning)
            return
        }
        let commentVC = CommentVC()
        commentVC.timelineItem = item
        currentNaviController().present(commentVC, animated: true, completion: nil)
    }
    
    func currentNaviController()->UINavigationController {
        let rootVC = UIApplication.shared.keyWindow!.rootViewController as! UITabBarController
        let naviController = rootVC.selectedViewController as! UINavigationController
        return naviController
    }
    
    func timeLineCell(cell: TimeLineCell, tapCover item: TimeLineItem, index: Int) {
        
        guard NetDefaults.userInfo?.freeWatches == -1 else {
            PurchaseVipAlert.showPurchaseVipAlert()
            return
        }
        
        let urls = item.dynamicImg.map{ URL(string: $0)! }
        bannerDeleteMaskView.removeFromSuperview()
        UIApplication.shared.keyWindow!.addSubview(bannerDeleteMaskView)
        bannerDeleteMaskView.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
        bannerDeleteMaskView.bannerListData = urls
        bannerDeleteMaskView.nicknameLabel.text = item.nickName
        bannerDeleteMaskView.initPageIndex = index
        bannerDeleteMaskView.startAnimation()
    }
    
}
