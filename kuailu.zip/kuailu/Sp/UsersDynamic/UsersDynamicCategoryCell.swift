//
//  UsersDynamicCategoryCell.swift
//  Sp
//
//  Created by mac on 2020/6/16.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class UsersDynamicCategoryCell: UICollectionViewCell {
    
    lazy var titleLabel: UILabel = {
        let label = UILabel()
        label.textAlignment = .center
        return label
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        addSubview(titleLabel)
        titleLabel.snp.makeConstraints { (make) in
            make.center.equalToSuperview()
        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}
