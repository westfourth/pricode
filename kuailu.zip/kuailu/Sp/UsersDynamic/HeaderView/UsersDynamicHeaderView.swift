


import UIKit

protocol UsersDynamicHeaderViewDelegate: NSObjectProtocol {
    
    func showTakePhotosActionSheet()
    
    func showBannerDeleteMaskView(pageIndex: Int)
    
    func refreshUserinfo()
    
    func refreshAccountInfo()
    
}

class UsersDynamicHeaderView: UIView {
    
    static let viewMaxHeight: CGFloat = 160
    
    static let viewMinHeight: CGFloat = 110
    
    private static let nicknameWidth: CGFloat = {
        return UIScreen.main.bounds.width - UsersDynamicHeaderView.avatarImgSize - 9 - 12 - UsersDynamicHeaderView.sexImgWidth - UsersDynamicHeaderView.certificationImgWidth
    }()
    
    private static let sexImgWidth: CGFloat = 30
    
    private static let certificationImgWidth: CGFloat = 59
    
    private static let nicknameLabelMargin: CGFloat = 12
    
    private static let avatarImgSize: CGFloat = 72
    
    private static let rewardBtnWidth: CGFloat = 104
    
    private static let attentionBtnWidth: CGFloat = {
        return UIScreen.main.bounds.width - 12 * 2 - UsersDynamicHeaderView.rewardBtnWidth - 6
    }()
    
    private static let certificationImg: UIImage? = {
        let img = UIImage(named: "certification_icon")
        return img
    }()
    
    private static let levelImg: UIImage? = {
        let img = UIImage(named: "level_icon")
        return img
    }()
    
    private static let sexMaleImg: UIImage? = {
        let img = UIImage(named: "sex_male")
        return img
    }()
    
    private static let sexFemaleImg: UIImage? = {
        let img = UIImage(named: "sex_female")
        return img
    }()
    
    private static let sexUnknownImg: UIImage? = {
        let img = UIImage(named: "sex_unknown")
        return img
    }()
    
    private static let rewardImg: UIImage? = {
        return UIImage(named: "users_dynamic_reward_icon")
    }()
    
    private static let privateLettersImg: UIImage? = {
        return UIImage(named: "chat_chat")
    }()
    
    private lazy var avtarImgView: UIImageView = {
        let imgView = UIImageView()
        imgView.layer.masksToBounds = true
        imgView.contentMode = .scaleAspectFill
        imgView.layer.cornerRadius = UsersDynamicHeaderView.avatarImgSize / 2
        return imgView
    }()
    
    private lazy var nicknameLabel: UILabel = {
        let label = UILabel()
        label.textColor = .white
        label.text = " "
        label.font = UIFont.pingFangMedium(16)
        label.numberOfLines = 1
        return label
    }()
    
    private lazy var sexImgView: UIImageView = {
        let imgView = UIImageView()
        imgView.contentMode = .scaleAspectFit
        return imgView
    }()
    
    private lazy var certificationImgView: UIImageView = {
        let imgView = UIImageView()
        imgView.contentMode = .scaleAspectFit
        imgView.addSubview(levelNumLabel)
        
        levelNumLabel.snp.makeConstraints { (make) in
            make.centerY.equalToSuperview().offset(1)
            make.right.equalToSuperview().inset(10)
        }
        return imgView
    }()
    
    private lazy var levelNumLabel: UILabel = {
        let label = UILabel()
        label.textColor = RGB(0x323232)
        label.font = UIFont.pingFangSemibold(12)
        label.isHidden = true
        return label
    }()
    
    private lazy var attentionNumLabel: UILabel = {
        let label = UILabel()
        label.textColor = .white
        label.text = "0"
        label.font = UIFont.pingFangMedium(16)
        return label
    }()
    
    private lazy var attentionLabel: UILabel = {
        let label = UILabel()
        label.text = "關注"
        label.textColor = RGB(0xC7C7C7)
        label.font = UIFont.pingFangRegular(13)
        return label
    }()
    
    private lazy var attentionInfoBtn: UIButton = {
        let btn = UIButton()
        btn.addTarget(self, action: #selector(onAttentionInfoBtnTap), for: .touchUpInside)
        btn.addSubview(attentionNumLabel)
        btn.addSubview(attentionLabel)
        
        attentionNumLabel.snp.makeConstraints { (make) in
            make.centerY.left.equalToSuperview()
        }
        
        attentionLabel.snp.makeConstraints { (make) in
            make.left.equalTo(attentionNumLabel.snp.right).offset(2)
            make.centerY.equalTo(attentionNumLabel)
        }
        return btn
    }()
    
    private lazy var fanNumLabel: UILabel = {
        let label = UILabel()
        label.text = "0"
        label.textColor = .white
        label.font = UIFont.pingFangMedium(16)
        return label
    }()
    
    private lazy var fanLabel: UILabel = {
        let label = UILabel()
        label.text = "粉絲"
        label.textColor = RGB(0xC7C7C7)
        label.font = UIFont.pingFangRegular(13)
        return label
    }()
    
    private lazy var fanBtn: UIButton = {
        let btn = UIButton()
        btn.addTarget(self, action: #selector(onFanBtnTap), for: .touchUpInside)
        btn.addSubview(fanNumLabel)
        btn.addSubview(fanLabel)
        
        fanNumLabel.snp.makeConstraints { (make) in
            make.centerY.left.equalToSuperview()
        }
        
        fanLabel.snp.makeConstraints { (make) in
            make.left.equalTo(fanNumLabel.snp.right).offset(2)
            make.centerY.equalTo(fanNumLabel)
        }
        return btn
    }()
    
    private lazy var privateLettersBtn: UIButton = {
        let btn = UIButton()
        btn.setBackgroundImage(UsersDynamicHeaderView.privateLettersImg, for: .normal)
        btn.addTarget(self, action: #selector(onPrivateLettersBtnTap), for: .touchUpInside)
        btn.isHidden = true
        return btn
    }()
    
    private lazy var rewardBtn: UIButton = {
        let btn = UIButton()
        btn.setTitle(Sensitive.shang, for: .normal)
        btn.titleLabel?.font = UIFont.pingFangRegular(14)
        btn.setTitleColor(.white, for: .normal)
        btn.backgroundColor = RGB(0x2C324F)
        btn.addTarget(self, action: #selector(onRewardBtnTap), for: .touchUpInside)
        btn.layer.cornerRadius = 4
        btn.isHidden = true
        return btn
    }()
    
    private lazy var attentionGradientLayer: CAGradientLayer = {
        let gradientColors = [RGB(0xF86104).cgColor, RGB(0xFA9C18).cgColor]
        let gradientLocations:[NSNumber] = [0, 1]
        let gradientLayer = CAGradientLayer()
        gradientLayer.colors = gradientColors
        gradientLayer.locations = gradientLocations
        gradientLayer.startPoint = CGPoint(x: 0, y: 1)
        gradientLayer.endPoint  = CGPoint(x: 1.0, y: 1)
        gradientLayer.frame = CGRect(x: 0, y: 0, width: UsersDynamicHeaderView.attentionBtnWidth, height: 32)
        return gradientLayer
    }()
    
    private lazy var attentionBtn: UIButton = {
        let btn = UIButton()
        btn.titleLabel?.font = UIFont.pingFangRegular(14)
        btn.layer.masksToBounds = true
        btn.layer.cornerRadius = 4
        btn.addTarget(self, action: #selector(onAttentionBtnTap), for: .touchUpInside)
        btn.isHidden = true
        return btn
    }()
    
    private lazy var usersDynamicRewardAlert: UsersDynamicRewardAlert = {
        return UsersDynamicRewardAlert()
    }()
    
    weak var delegate: UsersDynamicHeaderViewDelegate?
    
    var dataModel: UserBase? {
        didSet {
            refreshView()
        }
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        renderView()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    deinit {
        usersDynamicRewardAlert.removeFromSuperview()
    }
    
    private func renderView() {
        addSubview(avtarImgView)
        addSubview(nicknameLabel)
        addSubview(sexImgView)
        addSubview(certificationImgView)
        addSubview(attentionInfoBtn)
        addSubview(fanBtn)
        addSubview(privateLettersBtn)
        addSubview(rewardBtn)
        addSubview(attentionBtn)
        
        avtarImgView.snp.makeConstraints { (make) in
            make.top.equalToSuperview().inset(10)
            make.left.equalToSuperview().inset(12)
            make.size.equalTo(UsersDynamicHeaderView.avatarImgSize)
        }
        
        let nicknameLabelWidth = nicknameLabel.text!.getStringSize(rectSize: .zero, font: UIFont.pingFangSemibold(18)).width
        
        nicknameLabel.snp.makeConstraints { (make) in
            make.left.equalTo(avtarImgView.snp.right).offset(9)
            make.top.equalTo(avtarImgView).offset(10)
            make.width.equalTo(nicknameLabelWidth >= UsersDynamicHeaderView.nicknameWidth ? UsersDynamicHeaderView.nicknameWidth : nicknameLabelWidth)
        }
        
        sexImgView.snp.makeConstraints { (make) in
            make.centerY.equalTo(nicknameLabel)
            make.left.equalTo(nicknameLabel.snp.right)
            make.width.equalTo(UsersDynamicHeaderView.sexImgWidth)
            make.height.equalTo(16)
        }
        
        certificationImgView.snp.makeConstraints { (make) in
            make.left.equalTo(sexImgView.snp.right)
            make.centerY.equalTo(sexImgView)
            make.width.equalTo(UsersDynamicHeaderView.certificationImgWidth)
            make.height.equalTo(16)
        }
        
        attentionInfoBtn.snp.makeConstraints { (make) in
            make.left.equalTo(nicknameLabel)
            make.top.equalTo(nicknameLabel.snp.bottom).offset(3)
            make.size.equalTo(50)
        }
        
        fanBtn.snp.makeConstraints { (make) in
            make.left.equalTo(attentionInfoBtn.snp.right).offset(12)
            make.centerY.equalTo(attentionInfoBtn)
            make.size.equalTo(attentionInfoBtn)
        }
        
        privateLettersBtn.snp.makeConstraints { (make) in
            make.left.equalTo(fanBtn.snp.right).offset(10)
            make.centerY.equalTo(fanBtn).offset(3)
            make.width.equalTo(80)
            make.height.equalTo(34)
        }
        
        rewardBtn.snp.makeConstraints { (make) in
            make.top.equalTo(avtarImgView.snp.bottom).offset(20)
            make.left.equalToSuperview().inset(12)
            make.width.equalTo(UsersDynamicHeaderView.rewardBtnWidth)
            make.height.equalTo(32)
        }
        
        attentionBtn.snp.makeConstraints { (make) in
            make.centerY.equalTo(rewardBtn)
            make.left.equalTo(rewardBtn.snp.right).offset(6)
            make.right.equalToSuperview().inset(12)
            make.height.equalTo(32)
        }
        
    }
    
    private func refreshView() {
        guard let userinfo = dataModel else { return }
        let userId = NetDefaults.userInfo?.userId
        let isOther = userId == nil || userinfo.userId != userId
        avtarImgView.kf.setImage(with: userinfo.logo, placeholder: SearchResultFocusCell.avatarImg, options: SearchResultFocusCell.animationOption)
        nicknameLabel.text = userinfo.nickName
        sexImgView.image = userinfo.gender == .male ? UsersDynamicHeaderView.sexMaleImg : userinfo.gender == .female ? UsersDynamicHeaderView.sexFemaleImg : UsersDynamicHeaderView.sexUnknownImg
        let isRecommend = userinfo.isRecommend
        certificationImgView.image = isRecommend ? UsersDynamicHeaderView.certificationImg : userinfo.freeWatches == -1 ?  UsersDynamicHeaderView.levelImg : nil
        certificationImgView.isHidden = certificationImgView.image == nil
        levelNumLabel.isHidden = isRecommend || userinfo.freeWatches != -1
        attentionNumLabel.text = num2TenThousandStrFormat(userinfo.ua)
        fanNumLabel.text = num2TenThousandStrFormat(userinfo.bu)
        privateLettersBtn.isHidden = !isOther
        attentionBtn.isHidden = !isOther
        rewardBtn.isHidden = !isOther
        updateAttentionBtnStatus(isAttention: userinfo.attentionHe)
        let nicknameLabelWidth = nicknameLabel.text?.getStringSize(rectSize: .zero, font: UIFont.pingFangSemibold(18)).width ?? 0
        let maxNicknameLabelWidth = UIScreen.main.bounds.width - UsersDynamicHeaderView.sexImgWidth - (certificationImgView.isHidden ? 0 : UsersDynamicHeaderView.certificationImgWidth) - UsersDynamicHeaderView.nicknameLabelMargin * 2
        nicknameLabel.snp.updateConstraints { (make) in
            make.width.equalTo(nicknameLabelWidth >= maxNicknameLabelWidth ? maxNicknameLabelWidth : nicknameLabelWidth)
        }
    }
    
    private func updateAttentionBtnStatus(isAttention: Bool) {
        attentionBtn.setTitle(isAttention ? "取消關注" : "關注", for: .normal)
        attentionBtn.setTitleColor(isAttention ? RGB(0xFA6400) : .white, for: .normal)
        attentionBtn.layer.borderColor = isAttention ? RGB(0xFA6400).cgColor : .none
        attentionBtn.layer.borderWidth = isAttention ? 1 : 0
        isAttention ? attentionGradientLayer.removeFromSuperlayer() : attentionBtn.layer.insertSublayer(attentionGradientLayer, at: 0)
    }
    
    @objc private func onAttentionInfoBtnTap() {
        guard let userinfo = dataModel, let currentNaviController = (UIApplication.shared.delegate as? AppDelegate)?.currentNavigationController else { return }
        let focusFansVC = FocusFansVC()
        focusFansVC.navigationTitle = userinfo.nickName
        focusFansVC.titles = ["關注 \(userinfo.ua)","粉絲 \(userinfo.bu)"]
        focusFansVC.userId = userinfo.userId
        focusFansVC.currentIndex = 0
        currentNaviController.pushViewController(focusFansVC, animated: true)
    }
    
    @objc private func onFanBtnTap() {
        guard let userinfo = dataModel, let currentNaviController = (UIApplication.shared.delegate as? AppDelegate)?.currentNavigationController else { return }
        let focusFansVC = FocusFansVC()
        focusFansVC.navigationTitle = userinfo.nickName
        focusFansVC.titles = ["關注 \(userinfo.ua)","粉絲 \(userinfo.bu)"]
        focusFansVC.userId = userinfo.userId
        focusFansVC.currentIndex = 1
        currentNaviController.pushViewController(focusFansVC, animated: true)
    }
    
    @objc private func onPrivateLettersBtnTap() {
        guard let userinfo = dataModel, let currentNaviController = (UIApplication.shared.delegate as? AppDelegate)?.currentNavigationController else { return }
        let vc = ChatVC()
        vc.fromUserId = userinfo.userId
        vc.name = userinfo.nickName
        vc.hidesBottomBarWhenPushed = true
        currentNaviController.pushViewController(vc, animated: true)
    }
    
    @objc private func onRewardBtnTap() {
        usersDynamicRewardAlert.removeFromSuperview()
        UIApplication.shared.keyWindow!.addSubview(usersDynamicRewardAlert)
        usersDynamicRewardAlert.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
        usersDynamicRewardAlert.userId = dataModel?.userId
        usersDynamicRewardAlert.successClosure = { [weak self] in
            self?.delegate?.refreshAccountInfo()
            self?.usersDynamicRewardAlert.successClosure = nil
        }
        usersDynamicRewardAlert.startAnimation()
    }
    
    @objc private func onAttentionBtnTap() {
        guard let dataModel = self.dataModel else { return }
        guard dataModel.attentionHe else {
            Alert.showLoading(parentView: UIApplication.shared.keyWindow!)
            let req = FocusUserReq()
            req.beenUserId = dataModel.userId
            Session.request(req) { [weak self] (error, resp) in
                Alert.hideLoading()
                guard error == nil else {
                    mm_showToast(error!.localizedDescription)
                    return
                }
                dataModel.attentionHe = true
                self?.updateAttentionBtnStatus(isAttention: true)
                self?.delegate?.refreshUserinfo()
                mm_showToast("關注成功!", type: .succeed)
            }
            return
        }
        
        Alert.showCommonAlert(parentView: UIApplication.shared.keyWindow!, contentText: "取消關注後,您將無法及時收到他的動態",
                              cancelText: "再看看",
                              confirmText: "取消關注",
                              onConfirmTap: { [weak self] in
                                Alert.showLoading(parentView: UIApplication.shared.keyWindow!)
                                dataModel.attentionHe = false
                                let req = CancelFocusUserReq()
                                req.beenUserId = dataModel.userId
                                Session.request(req) { (error, resp) in
                                    Alert.hideLoading()
                                    guard error == nil else {
                                        mm_showToast(error!.localizedDescription)
                                        return
                                    }
                                    dataModel.attentionHe = false
                                    self?.updateAttentionBtnStatus(isAttention: false)
                                    self?.delegate?.refreshUserinfo()
                                    mm_showToast("取消成功!", type: .succeed)
                                }
                              }, onCancelTap: nil)
    }
    @objc private func onTakePhotosBtnTap() {
        delegate?.showTakePhotosActionSheet()
    }
    
}

