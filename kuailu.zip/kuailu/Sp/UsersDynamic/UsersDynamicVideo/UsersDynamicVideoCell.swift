//
//  UsersDynamicVideoCell.swift
//  Sp
//
//  Created by mac on 2020/6/18.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class UsersDynamicVideoCell: UICollectionViewCell {
    
    static let defaultImg: UIImage = {
        return Sensitive.default_bg()
    }()
    
    static let animationOption: KingfisherOptionsInfo = {
        return [.transition(.fade(0.25))]
    }()
    
    private static let collectionIconImg: UIImage? = {
        return UIImage(named: "ic_b_like_2")
    }()
    
    private static let lockIconImg: UIImage? = {
        return UIImage(named: "ic_lock")
    }()
    
    private static let v6IconImg: UIImage? = {
        return UIImage(named: "v6_icon")
    }()
    
    private static let gradientColors: [CGColor] = {
        return [UIColor.black.withAlphaComponent(0).cgColor, UIColor.black.withAlphaComponent(0.4).cgColor]
    }()
    
    private static let gradientLocations: [NSNumber] = {
        return [0, 1]
    }()
    
    private static let maskLayerViewHeight: CGFloat = 26
    
    private lazy var poster: UIImageView = {
        let imgView = UIImageView()
        imgView.contentMode = .scaleAspectFill
        imgView.layer.masksToBounds = true
        return imgView
    }()
    
    private lazy var collectionIconImgView: UIImageView = {
        let imgView = UIImageView(image: UsersDynamicVideoCell.collectionIconImg)
        return imgView
    }()
    
    private lazy var collectionNumberLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.pingFangRegular(12)
        label.textColor = .white
        return label
    }()
    
    private lazy var maskLayerView: UIView = {
        let maskView = UIView()
        let gradientLayer = CAGradientLayer()
        gradientLayer.colors = UsersDynamicVideoCell.gradientColors
        gradientLayer.locations = UsersDynamicVideoCell.gradientLocations
        gradientLayer.frame = CGRect(x: 0, y: 0, width: self.width, height: UsersDynamicVideoCell.maskLayerViewHeight)
        maskView.layer.insertSublayer(gradientLayer, at: 0)
        maskView.addSubview(collectionIconImgView)
        maskView.addSubview(collectionNumberLabel)
        
        collectionIconImgView.snp.makeConstraints { (make) in
            make.size.equalTo(12)
            make.left.equalToSuperview().inset(6)
            make.centerY.equalToSuperview().offset(2)
        }
        collectionNumberLabel.snp.makeConstraints { (make) in
            make.left.equalTo(collectionIconImgView.snp.right).offset(4)
            make.centerY.equalTo(collectionIconImgView)
        }
        return maskView
    }()
    
    private lazy var v6ImgView: UIImageView = {
        let imgView = UIImageView(image: UsersDynamicVideoCell.v6IconImg)
        imgView.isHidden = true
        return imgView
    }()
    
    private lazy var lockImgView: UIImageView = {
        let imgView = UIImageView(image: UsersDynamicVideoCell.lockIconImg)
        return imgView
    }()
    
    private lazy var lockLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.pingFangRegular(12)
        label.textColor = .white
        label.text = "V6專享視頻"
        return label
    }()
    
    private lazy var lockMaskView: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor.black.withAlphaComponent(0.3)
        view.addSubview(lockImgView)
        view.addSubview(lockLabel)
        view.isHidden = true
        
        lockImgView.snp.makeConstraints { (make) in
            make.centerX.equalToSuperview()
            make.centerY.equalToSuperview().offset(-14)
            make.width.equalTo(40)
            make.height.equalTo(44)
        }
        
        lockLabel.snp.makeConstraints { (make) in
            make.centerX.equalToSuperview()
            make.top.equalTo(lockImgView.snp.bottom).offset(10)
        }
        return view
    }()
    
    var dataModel: VideoItem? {
        didSet {
            guard let item = dataModel else { return }
            poster.kf.setImage(with: item.coverImg, placeholder: UsersDynamicVideoCell.defaultImg, options: UsersDynamicVideoCell.animationOption)
            collectionNumberLabel.text = item.fakeLikes > 0 ? num2TenThousandStrFormat(item.fakeLikes) : "0"
            lockMaskView.isHidden = !(item.isSpecial && NetDefaults.userInfo?.specialAuth != true)
            v6ImgView.isHidden = !item.isSpecial
        }
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        renderView()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func renderView() {
        addSubview(poster)
        addSubview(maskLayerView)
        addSubview(lockMaskView)
        addSubview(v6ImgView)
        
        poster.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
        
        maskLayerView.snp.makeConstraints { (make) in
            make.left.right.bottom.equalToSuperview()
            make.height.equalTo(UsersDynamicVideoCell.maskLayerViewHeight)
        }
        
        lockMaskView.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
        
        v6ImgView.snp.makeConstraints { (make) in
            make.top.equalToSuperview().inset(8)
            make.left.equalToSuperview()
            make.width.equalTo(42)
            make.height.equalTo(14)
        }
    }
}
