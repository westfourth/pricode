//
//  UsersDynamicUnlockBtn.swift
//  Sp
//
//  Created by mac on 2020/9/7.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

protocol UsersDynamicUnlockBtnDelegate: NSObjectProtocol {
    
    func handleUnlockBtnTap()
    
}

class UsersDynamicUnlockBtn: UIButton {
    
    private static let lockBarImg: UIImage? = {
        return UIImage(named: "user_dynamic_unlock_bottom_bar")
    }()
    
    lazy var subjectLabel: UILabel = {
        let label = UILabel()
        label.text = "\(Sensitive.jin)解鎖即可查看聯繫方式"
        label.textColor = .white
        label.font = UIFont.pingFangMedium(17)
        label.isHidden = true
        return label
    }()
    
    lazy var contactLabel: UILabel = {
        let label = UILabel()
        label.textColor = .white
        label.font = UIFont.pingFangRegular(14)
        label.textAlignment = .center
        label.numberOfLines = 0
        label.isHidden = true
        return label
    }()
    
    weak var delegate: UsersDynamicUnlockBtnDelegate?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setBackgroundImage(UsersDynamicUnlockBtn.lockBarImg, for: .normal)
        addTarget(self, action: #selector(onUnlockBtnTap), for: .touchUpInside)
        isHidden = true
        addSubview(subjectLabel)
        addSubview(contactLabel)
        
        subjectLabel.snp.makeConstraints { (make) in
            make.center.equalToSuperview()
        }
        
        contactLabel.snp.makeConstraints { (make) in
            make.top.bottom.left.equalToSuperview()
            make.right.equalToSuperview().inset(50)
        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    @objc private func onUnlockBtnTap() {
        delegate?.handleUnlockBtnTap()
    }
    
}
