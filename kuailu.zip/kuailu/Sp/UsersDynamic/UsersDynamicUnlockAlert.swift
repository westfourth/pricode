//
//  UsersDynamicUnlockAlert.swift
//  Sp
//
//  Created by mac on 2020/6/18.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class UsersDynamicUnlockAlert: UIView {
    
    private static let wrapperViewHeight: CGFloat = 288
    
    private static let btnWidth: CGFloat = UsersDynamicUnlockAlert.wrapperViewHeight / 2
    
    private lazy var tipLabel: UILabel = {
        let label = UILabel()
        label.textColor = RGB(0x6D7278)
        label.font = UIFont.pingFangRegular(18)
        return label
    }()
    
    private lazy var coinLabel: UILabel = {
        let label = UILabel()
        return label
    }()
    
    private lazy var confirmGradientLayer: CAGradientLayer = {
        let gradientColors = [RGB(0xFE6000).cgColor, RGB(0xFC9239).cgColor]
        let gradientLocations:[NSNumber] = [0, 1]
        let gradientLayer = CAGradientLayer()
        gradientLayer.colors = gradientColors
        gradientLayer.locations = gradientLocations
        gradientLayer.startPoint = CGPoint(x: 0, y: 1)
        gradientLayer.endPoint  = CGPoint(x: 1.0, y: 1)
        gradientLayer.frame = CGRect(x: 0, y: 0, width: 144, height: 49)
        return gradientLayer
    }()
    
    private lazy var cancelGradientLayer: CAGradientLayer = {
        let gradientColors = [RGB(0xB0B0B0).cgColor, RGB(0x898989).cgColor]
        let gradientLocations:[NSNumber] = [0, 1]
        let gradientLayer = CAGradientLayer()
        gradientLayer.colors = gradientColors
        gradientLayer.locations = gradientLocations
        gradientLayer.startPoint = CGPoint(x: 0, y: 1)
        gradientLayer.endPoint  = CGPoint(x: 1.0, y: 1)
        gradientLayer.frame = CGRect(x: 0, y: 0, width: 144, height: 49)
        return gradientLayer
    }()
    
    private lazy var confirmBtn: UIButton = {
        let btn = UIButton()
        btn.setTitle("確定", for: .normal)
        btn.setTitleColor(.white, for: .normal)
        btn.titleLabel?.font = UIFont.pingFangMedium(15)
        btn.layer.insertSublayer(confirmGradientLayer, at: 0)
        btn.addTarget(self, action: #selector(onConfirmBtnTap), for: .touchUpInside)
        return btn
    }()
    
    private lazy var cancelBtn: UIButton = {
        let btn = UIButton()
        btn.setTitle("取消", for: .normal)
        btn.setTitleColor(.white, for: .normal)
        btn.titleLabel?.font = UIFont.pingFangMedium(15)
        btn.layer.insertSublayer(cancelGradientLayer, at: 0)
        btn.addTarget(self, action: #selector(onCancelBtnTap), for: .touchUpInside)
        return btn
    }()
    
    private lazy var wrapperView: UIButton = {
        let view = UIButton()
        view.backgroundColor = .white
        view.layer.cornerRadius = 12
        view.layer.masksToBounds = true
        view.addSubview(tipLabel)
        view.addSubview(coinLabel)
        view.addSubview(cancelBtn)
        view.addSubview(confirmBtn)
        
        tipLabel.snp.makeConstraints { (make) in
            make.top.equalToSuperview().inset(36)
            make.centerX.equalToSuperview()
        }
        
        coinLabel.snp.makeConstraints { (make) in
            make.top.equalTo(tipLabel.snp.bottom).offset(10)
            make.centerX.equalToSuperview()
        }
        
        cancelBtn.snp.makeConstraints { (make) in
            make.bottom.left.equalToSuperview()
            make.width.equalTo(UsersDynamicUnlockAlert.btnWidth)
            make.height.equalTo(44)
        }
        
        confirmBtn.snp.makeConstraints { (make) in
            make.bottom.right.equalToSuperview()
            make.width.height.equalTo(cancelBtn)
        }
        
        return view
    }()
    
    private var isEnough: Bool = false
    
    var userId: Int?
    
    var coinNum: Int?
    
    var successClosure: (() -> ())?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        alpha = 0
        backgroundColor = UIColor.black.withAlphaComponent(0.3)
        let tap = UITapGestureRecognizer(target: self, action: #selector(onCancelBtnTap))
        isUserInteractionEnabled = true
        addGestureRecognizer(tap)
        addSubview(wrapperView)
        
        wrapperView.snp.makeConstraints { (make) in
            make.center.equalToSuperview()
            make.width.equalTo(UsersDynamicUnlockAlert.wrapperViewHeight)
            make.height.equalTo(166)
        }
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    deinit {
        successClosure = nil
    }
    
    func showAlert() {
        guard let coinNum = self.coinNum else {
            successClosure = nil
            return
        }
        isEnough = Double(coinNum) <= WalletVC.coinVal
        tipLabel.text = isEnough ? "解鎖該聯繫方式需\(Sensitive.zhi)" : "\(Sensitive.jin)不足哦，請先\(Sensitive.gou)\(Sensitive.jin)！"
        let attributedString = NSMutableAttributedString(string: "\(coinNum)\(Sensitive.jin)", attributes: [NSAttributedString.Key.font: UIFont.pingFangSemibold(22),
                                                                                                            NSAttributedString.Key.foregroundColor: RGB(0xFE6000)])
        attributedString.addAttributes([NSAttributedString.Key.font: UIFont.pingFangRegular(18)], range: NSRange(location: "\(coinNum)".count, length: 2))
        coinLabel.attributedText = attributedString
        confirmBtn.setTitle(isEnough ? "確定" : "\(Sensitive.gou)\(Sensitive.jin)" , for: .normal)
        startAnimation()
    }
    
    @objc private func onConfirmBtnTap() {
        guard isEnough else {
            guard let navigationController = (UIApplication.shared.delegate as? AppDelegate)?.currentNavigationController else { return }
            VipChargeTipVC.isFromVideoPlayList = false
            let vc = Vip2VC()
            vc.uiType = .coin
            navigationController.pushViewController(vc, animated: true)
            stopAnimation()
            return
        }
        guard let userId = self.userId else {
            stopAnimation()
            mm_showToast("解鎖失敗，請稍後再試！", type: .failed)
            return
        }
        Alert.showLoading(parentView: self)
        let req = UnLockHerReq()
        req.toUserId = userId
        Session.request(req) { [weak self] (error, resp) in
            Alert.hideLoading()
            guard let `self` = self else { return }
            guard error == nil else {
                self.stopAnimation()
                mm_showToast(error!.localizedDescription, type: .failed)
                return
            }
            self.successClosure?()
            self.stopAnimation()
            mm_showToast("恭喜您，解鎖成功！", type: .succeed)
        }
    }
    
    @objc private func onCancelBtnTap() {
        stopAnimation()
    }
    
    func startAnimation() {
        UIView.animate(withDuration: 0.3) { [weak self] in
            self?.alpha = 1
        }
    }
    
    func stopAnimation() {
        UIView.animate(withDuration: 0.3) { [weak self] in
            self?.alpha = 0
        }
    }
    
}
