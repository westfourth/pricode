//
//  UsersDynamicProfileHeaderView.swift
//  Sp
//
//  Created by mac on 2020/6/16.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

protocol UsersDynamicProfileHeaderViewDelegate: NSObjectProtocol {
    
    func showPhotoBannerDeleteMaskView(row: Int)
    
}

class UsersDynamicProfileHeaderView: UICollectionReusableView {
    
    static let minViewHeight: CGFloat = 220
    
    private static let editBtnWidth: CGFloat = 80
    
    static let photoTipLabelHeight: CGFloat = 20 + 20 + 10
    
    private static let editImg: UIImage? = {
        let img = UIImage(named: "edit_icon")
        return img
    }()
    
    private lazy var infoTipLabel: UILabel = {
        let label = UILabel()
        label.text = "基礎信息"
        label.textColor = .white
        label.font = UIFont.pingFangRegular(14)
        return label
    }()
    
    private lazy var editBtn: UIButton = {
        let btn = UIButton()
        btn.titleLabel?.font = UIFont.pingFangRegular(14)
        btn.setTitle("編輯資料", for: .normal)
        btn.setTitleColor(.white, for: .normal)
        btn.setImage(UsersDynamicProfileHeaderView.editImg, for: .normal)
        btn.imagePosition(imageStyle: .left, spacing: 4)
        btn.addTarget(self, action: #selector(onEditBtnTap), for: .touchUpInside)
        btn.isHidden = true
        return btn
    }()
    
    private lazy var priceTipLabel: UILabel = {
        let label = UILabel()
        label.text = "價格"
        label.textColor = RGB(0xA8A8A8)
        label.font = UIFont.pingFangRegular(13)
        label.isHidden = true
        return label
    }()
    
    private lazy var priceLabel: UILabel = {
        let label = UILabel()
        label.textColor = RGB(0xFA6400)
        label.font = UIFont.pingFangMedium(16)
        label.isHidden = true
        return label
    }()
    
    private lazy var ageTipLabel: UILabel = {
        let label = UILabel()
        label.text = "年齡"
        label.textColor = RGB(0xA8A8A8)
        label.font = UIFont.pingFangRegular(13)
        return label
    }()
    
    private lazy var ageLabel: UILabel = {
        let label = UILabel()
        label.textColor = RGB(0xA8A8A8)
        label.font = UIFont.pingFangRegular(13)
        return label
    }()
    
    private lazy var placeTipLabel: UILabel = {
        let label = UILabel()
        label.text = "來自"
        label.textColor = RGB(0xA8A8A8)
        label.font = UIFont.pingFangRegular(13)
        return label
    }()
    
    private lazy var placeLabel: UILabel = {
        let label = UILabel()
        label.textColor = RGB(0xA8A8A8)
        label.font = UIFont.pingFangRegular(13)
        return label
    }()
    
    private lazy var serviceTipLabel: UILabel = {
        let label = UILabel()
        label.text = "服務項目"
        label.textColor = RGB(0xA8A8A8)
        label.font = UIFont.pingFangRegular(13)
        label.isHidden = true
        return label
    }()

    private lazy var serviceCollectionView: UICollectionView = {
        let layout = UICollectionViewFlowLayout()
        layout.minimumLineSpacing = 0
        layout.minimumInteritemSpacing = 6
        layout.scrollDirection = .horizontal
        let cv = UICollectionView(frame: .zero, collectionViewLayout: layout)
        cv.register(UsersDynamicProfileHeaderServiceCell.self, forCellWithReuseIdentifier: "UsersDynamicProfileHeaderServiceCell")
        cv.contentInset = UIEdgeInsets(top: 0, left: 12, bottom: 0, right: 12)
        cv.showsVerticalScrollIndicator = false
        cv.showsHorizontalScrollIndicator = false
        cv.bouncesZoom = false
        cv.backgroundColor = .none
        cv.delegate = self
        cv.dataSource = self
        cv.isHidden = true
        return cv
    }()
    
    private lazy var introTipLabel: UILabel = {
        let label = UILabel()
        label.text = "簡介"
        label.textColor = .white
        label.font = UIFont.pingFangRegular(14)
        return label
    }()
    
    private lazy var introLabel: UILabel = {
        let label = UILabel()
        label.textColor = RGB(0xA8A8A8)
        label.font = UIFont.pingFangRegular(12)
        label.numberOfLines = 0
        return label
    }()
    
    private lazy var  photoTipLabel: UILabel = {
        let label = UILabel()
        label.text = "照片"
        label.textColor = .white
        label.font = UIFont.pingFangRegular(14)
        return label
    }()
    
    private lazy var photoCollectionView: UICollectionView = {
        let layout = UICollectionViewFlowLayout()
        layout.minimumLineSpacing = UsersDynamicProfileCell.itemInteritemSpacing
        layout.minimumInteritemSpacing = UsersDynamicProfileCell.itemInteritemSpacing
        layout.sectionInset = UIEdgeInsets(top: 0, left: UsersDynamicProfileCell.horizontalMargin, bottom: 0, right: UsersDynamicProfileCell.horizontalMargin)
        let cv = UICollectionView(frame: .zero, collectionViewLayout: layout)
        cv.register(UsersDynamicProfileSubCell.self, forCellWithReuseIdentifier: "UsersDynamicProfileSubCell")
        cv.backgroundColor = .none
        cv.delegate = self
        cv.dataSource = self
        cv.showsHorizontalScrollIndicator = false
        cv.showsVerticalScrollIndicator = false
        cv.isDirectionalLockEnabled = true
        cv.isScrollEnabled = false
        cv.bounces = false
        cv.bouncesZoom = false
        return cv
    }()
    
    lazy var wordMouthTipLabel: UILabel = {
        let label = UILabel()
        label.text = "口碑"
        label.textColor = .white
        label.font = UIFont.pingFangRegular(14)
        label.isHidden = true
        return label
    }()
    
    private var serviceListData: [String] = []
    
    private var photoListData: [URL] = []
    
    private var photoCollectionViewItemSize: CGSize = .zero
    
    weak var delegate: UsersDynamicProfileHeaderViewDelegate?
    
    var photoCollectionViewHeight: CGFloat = 0
    
    var dataModel: UserBase? {
        didSet {
            guard let userinfo = dataModel else { return }
            let isGeneralUser = userinfo.userType != 4 && userinfo.userType != 5
            priceTipLabel.isHidden = isGeneralUser
            let userId = NetDefaults.userInfo?.userId
            let isOther = userId == nil || userinfo.userId != userId
            priceLabel.isHidden = isGeneralUser
            editBtn.isHidden = isOther
            priceLabel.text = userinfo.price.isEmpty ? "保密" : userinfo.price
            ageLabel.text = userinfo.age <= 0 ? "保密" : "\(userinfo.age)"
            ageTipLabel.snp.updateConstraints { (make) in
                make.top.equalTo(priceTipLabel.snp.bottom).offset(isGeneralUser ? -16 : 8)
            }
            introTipLabel.snp.updateConstraints { (make) in
                make.top.equalTo(serviceTipLabel.snp.bottom).offset(isGeneralUser ? -10 : 16)
            }
            placeLabel.text = !userinfo.provinceName.isEmpty && !userinfo.cityName.isEmpty ? "\(userinfo.provinceName)·\(userinfo.cityName)" : userinfo.provinceName.isEmpty && userinfo.cityName.isEmpty ? "\(Sensitive.cao)星" : !userinfo.provinceName.isEmpty ? userinfo.provinceName : userinfo.cityName
            serviceTipLabel.isHidden = isGeneralUser
            serviceCollectionView.isHidden = isGeneralUser
            serviceListData = userinfo.userTags
            introLabel.text = userinfo.personSign.isEmpty ? "這個人很懶，什麼都沒有留下" : userinfo.personSign
            serviceCollectionView.reloadData()
            let bgCovers = userinfo.bgCovers
            guard !bgCovers.isEmpty else { return }
            photoListData = bgCovers
            let count = bgCovers.count
            photoCollectionViewItemSize = count == 0 ? .zero : count == 1 ? UsersDynamicProfileCell.singleCellSize : count == 2 ? UsersDynamicProfileCell.doubleCellSize : UsersDynamicProfileCell.threeCellSize
            photoTipLabel.snp.remakeConstraints { (make) in
                make.top.equalTo(introLabel.snp.bottom).offset(20)
                make.left.right.equalToSuperview().inset(12)
                make.height.equalTo(20)
            }
            photoCollectionView.snp.updateConstraints { (make) in
                make.top.equalTo(photoTipLabel.snp.bottom).offset(10)
                make.left.right.equalToSuperview()
                make.height.equalTo(photoCollectionViewHeight)
            }
         
            photoCollectionView.reloadData()
        }
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        renderView()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func renderView() {
        addSubview(infoTipLabel)
        addSubview(editBtn)
        addSubview(priceTipLabel)
        addSubview(priceLabel)
        addSubview(ageTipLabel)
        addSubview(ageLabel)
        addSubview(placeTipLabel)
        addSubview(placeLabel)
        addSubview(serviceTipLabel)
        addSubview(serviceCollectionView)
        addSubview(introTipLabel)
        addSubview(introLabel)
        addSubview(photoTipLabel)
        addSubview(photoCollectionView)
        addSubview(wordMouthTipLabel)
        
        infoTipLabel.snp.makeConstraints { (make) in
            make.top.equalToSuperview().inset(15)
            make.left.equalToSuperview().inset(12)
        }
        
        editBtn.snp.makeConstraints { (make) in
            make.centerY.equalTo(infoTipLabel)
            make.left.equalTo(infoTipLabel.snp.right).offset(9)
            make.width.equalTo(UsersDynamicProfileHeaderView.editBtnWidth)
            make.height.equalTo(20)
        }
        
        priceTipLabel.snp.makeConstraints { (make) in
            make.top.equalTo(infoTipLabel.snp.bottom).offset(8)
            make.left.equalTo(infoTipLabel)
        }
        
        priceLabel.snp.makeConstraints { (make) in
            make.centerY.equalTo(priceTipLabel)
            make.left.equalTo(priceTipLabel.snp.right).offset(12)
        }
        
        ageTipLabel.snp.makeConstraints { (make) in
            make.top.equalTo(priceTipLabel.snp.bottom).offset(8)
            make.left.equalTo(priceTipLabel)
        }
        
        ageLabel.snp.makeConstraints { (make) in
            make.centerY.equalTo(ageTipLabel)
            make.left.equalTo(ageTipLabel.snp.right).offset(12)
        }
        
        placeTipLabel.snp.makeConstraints { (make) in
            make.top.equalTo(ageTipLabel.snp.bottom).offset(8)
            make.left.equalTo(ageTipLabel)
        }
        
        placeLabel.snp.makeConstraints { (make) in
            make.centerY.equalTo(placeTipLabel)
            make.left.equalTo(placeTipLabel.snp.right).offset(12)
        }
        
        serviceTipLabel.snp.makeConstraints { (make) in
            make.top.equalTo(placeTipLabel.snp.bottom).offset(8)
            make.left.equalTo(placeTipLabel)
        }
        
        serviceCollectionView.snp.makeConstraints { (make) in
            make.left.equalTo(serviceTipLabel.snp.right)
            make.centerY.equalTo(serviceTipLabel)
            make.right.equalToSuperview().inset(12)
            make.height.equalTo(16)
        }
        
        introTipLabel.snp.makeConstraints { (make) in
            make.top.equalTo(serviceTipLabel.snp.bottom).offset(16)
            make.left.equalTo(serviceTipLabel)
        }
        
        introLabel.snp.makeConstraints { (make) in
            make.top.equalTo(introTipLabel.snp.bottom).offset(8)
            make.left.right.equalToSuperview().inset(12)
        }
        
        photoTipLabel.snp.makeConstraints { (make) in
            make.top.equalTo(introLabel.snp.bottom).offset(0)
            make.left.equalToSuperview().inset(12)
            make.height.equalTo(0)
        }
        
        photoCollectionView.snp.makeConstraints { (make) in
            make.top.equalTo(photoTipLabel.snp.bottom).offset(0)
            make.left.right.equalToSuperview()
            make.height.equalTo(0)
        }
        
        wordMouthTipLabel.snp.makeConstraints { (make) in
            make.top.equalTo(photoCollectionView.snp.bottom).offset(20)
            make.left.equalTo(infoTipLabel)
        }
    }
    
    @objc private func onEditBtnTap() {
        guard let currentNaviController = (UIApplication.shared.delegate as? AppDelegate)?.currentNavigationController else { return }
        let editInfoVC = EditInfoVC()
        editInfoVC.hidesBottomBarWhenPushed = true
        currentNaviController.pushViewController(editInfoVC, animated: true)
    }
    
}

extension UsersDynamicProfileHeaderView: UICollectionViewDataSource, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return collectionView == serviceCollectionView ? serviceListData.count : photoListData.count
    }
    
    func collectionView(_ collectionView: UICollectionView,
                        layout collectionViewLayout: UICollectionViewLayout,
                        sizeForItemAt indexPath: IndexPath) -> CGSize {
        return collectionView == serviceCollectionView ? CGSize(width: serviceListData[indexPath.row].getStringSize(rectSize: .zero, font: UIFont.pingFangRegular(10)).width + 8 + 5 + 10, height: 16) : photoCollectionViewItemSize
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        guard collectionView == serviceCollectionView else {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "UsersDynamicProfileSubCell", for: indexPath) as! UsersDynamicProfileSubCell
            cell.imgUrl = photoListData[indexPath.row]
            return cell
        }
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "UsersDynamicProfileHeaderServiceCell", for: indexPath) as! UsersDynamicProfileHeaderServiceCell
        cell.titleLabel.text = serviceListData[indexPath.row]
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        guard collectionView == photoCollectionView else { return }
        delegate?.showPhotoBannerDeleteMaskView(row: indexPath.row)
    }
}
