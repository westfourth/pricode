//
//  UsersDynamicProfileHeaderServiceCell.swift
//  Sp
//
//  Created by mac on 2020/9/7.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class UsersDynamicProfileHeaderServiceCell: UICollectionViewCell {
    
    private static let iconImg: UIImage? =  {
        return UIImage(named: "ic_tag")
    }()
    
    lazy var titleLabel: UILabel = {
        let label = UILabel()
        label.textColor = UIColor.white.withAlphaComponent(0.5)
        label.font = UIFont.pingFangRegular(10)
        return label
    }()
    
    private lazy var iconImgView: UIImageView = {
        return UIImageView(image: UsersDynamicProfileHeaderServiceCell.iconImg)
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = RGB(0x2E2D38)
        layer.cornerRadius = 8
        layer.masksToBounds = true
        addSubview(iconImgView)
        addSubview(titleLabel)
                
        iconImgView.snp.makeConstraints { (make) in
            make.left.equalToSuperview().inset(5)
            make.centerY.equalToSuperview()
            make.size.equalTo(8)
        }
        
        titleLabel.snp.makeConstraints { (make) in
            make.left.equalTo(iconImgView.snp.right).offset(5)
            make.right.centerY.equalToSuperview()
        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}
