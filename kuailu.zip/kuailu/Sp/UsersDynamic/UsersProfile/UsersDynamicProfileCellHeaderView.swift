//
//  ContentNumProfileDynamicProfileCellHeaderViewCollectionReusableView.swift
//  CaoLong
//
//  Created by mac on 2020/7/9.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class UsersDynamicProfileCellHeaderView: UICollectionReusableView {
    
    private static let formatDate: DateFormatter = {
        let f = DateFormatter()
        f.timeZone = NSTimeZone(abbreviation: "UTC") as TimeZone?
        f.dateFormat = "yyyy-MM-dd'T'HH:mm:ss.SSSZZZ"
        return f
    }()
    
    static let minViewHeight: CGFloat = 72
    
    private lazy var nicknameLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.pingFangSemibold(16)
        label.textColor = .white
        label.numberOfLines = 1
        return label
    }()
    
    private lazy var datetimeLabel: UILabel = {
        let label = UILabel()
        label.font = FONT(12)
        label.textColor = UIColor.white.withAlphaComponent(0.8)
        return label
    }()
    
    private lazy var contentLabel: UILabel = {
        let label = UILabel()
        label.font = FONT(12)
        label.textColor = UIColor.white.withAlphaComponent(0.8)
        label.numberOfLines = 0
        return label
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        renderView()
    }
    
    var dataModel: FeedBackItem? {
        didSet {
            guard let item = dataModel else { return }
            nicknameLabel.text = item.backUserName
            datetimeLabel.text = Date.getCompareCurrntTime(timeStamp: "\(UsersDynamicProfileCellHeaderView.formatDate.date(from: item.recordAt)?.timeIntervalSince1970 ?? 0)")
            contentLabel.text = item.content
        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func renderView() {
        addSubview(nicknameLabel)
        addSubview(datetimeLabel)
        addSubview(contentLabel)
        
        nicknameLabel.snp.makeConstraints { (make) in
            make.top.left.right.equalToSuperview().inset(12)
        }
        datetimeLabel.snp.makeConstraints { (make) in
            make.left.equalTo(nicknameLabel)
            make.top.equalTo(nicknameLabel.snp.bottom).offset(6)
        }
        contentLabel.snp.makeConstraints { (make) in
            make.top.equalTo(datetimeLabel.snp.bottom).offset(6)
            make.left.right.equalToSuperview().inset(12)
        }
    }
}
