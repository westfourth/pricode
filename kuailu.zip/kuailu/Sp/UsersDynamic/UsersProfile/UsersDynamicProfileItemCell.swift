//
//  UsersDynamicProfileItemCell.swift
//  Sp
//
//  Created by mac on 2020/6/16.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

extension Notification.Name {
    /// 更新用户动态资料模块解锁状态
    static let UpdateUsersDynamicProfileLockStatus = Notification.Name(rawValue:"UpdateUsersDynamicProfileLockStatus")
}

class UsersDynamicProfileItemCell: UICollectionViewCell {
    
    private static let horizontalMargin: CGFloat = 12
    
    static var subCellHeightList: [CGFloat] = []
    
    static var subCellContentHeightList: [CGFloat] = []
    
    private lazy var tableView: UITableView = {
        let tableView = UITableView(frame: .zero, style: .grouped)
        tableView.delegate = self
        tableView.dataSource = self
        tableView.backgroundColor = .none
        tableView.separatorStyle = .none
        tableView.estimatedRowHeight = 0
        tableView.bouncesZoom = false
        tableView.register(UsersDynamicProfileCell.self, forCellReuseIdentifier: "UsersDynamicProfileCell")
        tableView.contentInset = UIEdgeInsets(top: 0, left: 0, bottom: 10, right: 0)
        tableView.mj_footer = getCommonMJFooter(refreshingTarget: self, footerRefreshCallback: #selector(onLoad))
        return tableView
    }()
    
    private lazy var headerView: UsersDynamicProfileHeaderView = {
        return UsersDynamicProfileHeaderView()
    }()
    
    private lazy var bannerDeleteMaskView: UsersDynamicBannerDeleteMaskView = {
        let view = UsersDynamicBannerDeleteMaskView()
        return view
    }()
    
    private var isInitState: Bool = true
    
    private var listData: [FeedBackItem] = []
    
    private var headerViewPhotoCollectionViewHeight: CGFloat = 0
    
    var dataModel: UserBase? {
        didSet {
            guard isInitState else { return }
            isInitState = dataModel == nil
            if let userinfo = dataModel {
                tableView.contentInset.bottom = userinfo.userType == 4 || userinfo.userType == 5 ? 120 : 10
                let count = userinfo.bgCovers.count
                let photoCollectionViewHeight = count == 0 ? 0 : (count == 1 ? UsersDynamicProfileCell.singleCellHeight : count == 2 ? UsersDynamicProfileCell.doubleCellHeight : CGFloat(Int(count / 3) + (count % 3 == 0 ? 0 : 1)) * UsersDynamicProfileCell.threeCellHeight)
                headerViewPhotoCollectionViewHeight = photoCollectionViewHeight + UsersDynamicProfileHeaderView.photoTipLabelHeight
                headerView.photoCollectionViewHeight = photoCollectionViewHeight
            } else {
                headerViewPhotoCollectionViewHeight = 0
                headerView.photoCollectionViewHeight = 0
            }
            UsersDynamicProfileItemCell.subCellHeightList = []
            UsersDynamicProfileItemCell.subCellContentHeightList = []
            listData = []
            tableView.reloadData()
            getList()
        }
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        NotificationCenter.default.addObserver(self, selector: #selector(refreshCollectionView), name: .UpdateUsersDynamicProfileLockStatus, object: nil)
        addSubview(tableView)
        tableView.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    deinit {
        NotificationCenter.default.removeObserver(self)
        bannerDeleteMaskView.removeFromSuperview()
    }
    
    private func getList() {
        guard let userId = dataModel?.userId else { return }
        let req = FeedBackListReq()
        req.userId = userId
        if let date = listData.last?.recordAt {
            req.recordAt = date
        }
        let tableView = self.tableView
        Session.request(req) { [weak self] (error, resp) in
            tableView.mj_footer?.endRefreshing()
            guard let `self` = self else { return }
            guard error == nil, let resData = resp as? [FeedBackItem] else {
                tableView.mj_footer?.endRefreshingWithNoMoreData()
                tableView.mj_footer?.isHidden = false
                return
            }
            let minViewHeight = UsersDynamicProfileCellHeaderView.minViewHeight
            let font = FONT(12)
            resData.forEach {
                let count = $0.imgs.count
                let labelHeight = $0.content.getStringSize(rectSize: UsersDynamicProfileCell.persionSignRectSize, font: font).height
                let subCollectionViewHeight = count == 0 ? UsersDynamicProfileCell.cellMarginBottom : count == 1 ? UsersDynamicProfileCell.singleCellHeight : count == 2 ? UsersDynamicProfileCell.doubleCellHeight : CGFloat(Int(count / 3) + (count % 3 == 0 ? 0 : 1)) * UsersDynamicProfileCell.threeCellHeight
                let contentHeight = minViewHeight + labelHeight
                UsersDynamicProfileItemCell.subCellContentHeightList.append(contentHeight)
                UsersDynamicProfileItemCell.subCellHeightList.append(contentHeight + subCollectionViewHeight)
            }
            self.listData += resData
            if resData.isEmpty {
                tableView.mj_footer?.endRefreshingWithNoMoreData()
            }
            tableView.mj_footer?.isHidden = self.listData.isEmpty
            tableView.reloadData()
        }
    }
    
    @objc private func refreshCollectionView() {
        tableView.reloadData()
    }
    
    @objc private func onLoad() {
        getList()
    }
    
}

extension UsersDynamicProfileItemCell: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return listData.count
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return UsersDynamicProfileHeaderView.minViewHeight + (dataModel?.personSign.getStringSize(rectSize: UsersDynamicProfileCell.persionSignRectSize, font: font(12)).height ?? 0) + headerViewPhotoCollectionViewHeight
    }
    
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return .leastNonzeroMagnitude
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        headerView.delegate = self
        headerView.dataModel = dataModel
        headerView.wordMouthTipLabel.isHidden = listData.isEmpty
        headerView.wordMouthTipLabel.text = "口碑（\(listData.count)）"
        return headerView
    }
    
    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        return nil
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UsersDynamicProfileItemCell.subCellHeightList[indexPath.row]
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "UsersDynamicProfileCell", for: indexPath) as! UsersDynamicProfileCell
        let row = indexPath.row
        cell.currentIndex = row
        cell.delegate = self
        cell.dataModel = listData[row]
        return cell
    }
    
}

extension UsersDynamicProfileItemCell: UsersDynamicProfileCellDelegate {
    
    func showBannerDeleteMaskView(row: Int, subIndex: Int) {
        guard !listData.isEmpty, let userinfo = dataModel else { return }
        bannerDeleteMaskView.removeFromSuperview()
        UIApplication.shared.keyWindow!.addSubview(bannerDeleteMaskView)
        bannerDeleteMaskView.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
        bannerDeleteMaskView.bannerListData = listData[row].imgs
        bannerDeleteMaskView.nicknameLabel.text = userinfo.nickName
        bannerDeleteMaskView.initPageIndex = subIndex
        bannerDeleteMaskView.startAnimation()
    }
    
}

extension UsersDynamicProfileItemCell: UsersDynamicProfileHeaderViewDelegate {
    
    func showPhotoBannerDeleteMaskView(row: Int) {
        guard let userinfo = dataModel, !userinfo.bgCovers.isEmpty else { return }
        bannerDeleteMaskView.removeFromSuperview()
        UIApplication.shared.keyWindow!.addSubview(bannerDeleteMaskView)
        bannerDeleteMaskView.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
        bannerDeleteMaskView.bannerListData = userinfo.bgCovers
        bannerDeleteMaskView.nicknameLabel.text = userinfo.nickName
        bannerDeleteMaskView.initPageIndex = row
        bannerDeleteMaskView.startAnimation()
    }
    
}
