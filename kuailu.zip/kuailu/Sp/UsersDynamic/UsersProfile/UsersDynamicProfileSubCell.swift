//
//  UsersDynamicProfileSubCell.swift
//  Sp
//
//  Created by mac on 2020/6/16.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class UsersDynamicProfileSubCell: UICollectionViewCell {
    
    private static let bannerDefaultImg: UIImage? = {
        return  Sensitive.default_bg
    }()
    
    static let animationOptionGif: KingfisherOptionsInfo = {
        return [.transition(.fade(0.25)), .backgroundDecode, .fromMemoryCacheOrRefresh]
    }()
    
    static let animationOption: KingfisherOptionsInfo = {
        return [.transition(.fade(0.25))]
    }()
    
    private lazy var imgView: AnimatedImageView = {
        let imgView = AnimatedImageView()
        imgView.contentMode = .scaleAspectFill
        imgView.runLoopMode = .default
        imgView.layer.masksToBounds = true
        return imgView
    }()
    
    var imgUrl: URL? {
        didSet {
            guard let url = imgUrl else { return }
            let isGif = url.column0?.absoluteString.contains(".gif") ?? false
            imgView.kf.setImage(with: url.column0, placeholder: UsersDynamicProfileSubCell.bannerDefaultImg, options: isGif ? UsersDynamicProfileSubCell.animationOptionGif : UsersDynamicProfileSubCell.animationOption)
        }
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        addSubview(imgView)
        imgView.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
