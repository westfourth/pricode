//
//  UsersDynamicProfileCell.swift
//  CaoLong
//
//  Created by mac on 2020/7/9.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

protocol UsersDynamicProfileCellDelegate: NSObjectProtocol {
    
    func showBannerDeleteMaskView(row: Int, subIndex: Int)
    
}

class UsersDynamicProfileCell: UITableViewCell {
    
    static let horizontalMargin: CGFloat = 12
    
    static let itemInteritemSpacing: CGFloat = 7
    
    private static let columnNum: CGFloat = 3
    
    static let persionSignRectSize: CGSize = CGSize(width: UIScreen.main.bounds.width - 2 * UsersDynamicProfileCell.horizontalMargin, height: 0)
    
    private static let itemWidth: CGFloat = (UIScreen.main.bounds.width - UsersDynamicProfileCell.horizontalMargin * 2 - (UsersDynamicProfileCell.columnNum - 1) * UsersDynamicProfileCell.itemInteritemSpacing) / UsersDynamicProfileCell.columnNum
    
    private static let singleCellWidth: CGFloat = (UIScreen.main.bounds.width - UsersDynamicProfileCell.itemInteritemSpacing - 2 * UsersDynamicProfileCell.horizontalMargin) / 2
    
    private static let singleCellRatio: CGFloat = 223 / 165
    
    static let singleCellSize: CGSize = CGSize(width: UsersDynamicProfileCell.singleCellWidth, height: UsersDynamicProfileCell.singleCellWidth * UsersDynamicProfileCell.singleCellRatio)
    
    static let doubleCellSize: CGSize = CGSize(width: UsersDynamicProfileCell.singleCellWidth, height: UsersDynamicProfileCell.singleCellWidth)
    
    private static let threeCellWidth: CGFloat = (UIScreen.main.bounds.width - UsersDynamicProfileCell.itemInteritemSpacing * 2 - 2 * UsersDynamicProfileCell.horizontalMargin) / 3
    
    static let threeCellSize: CGSize = CGSize(width: UsersDynamicProfileCell.threeCellWidth, height: UsersDynamicProfileCell.threeCellWidth)
    
    static let cellMarginBottom: CGFloat = 12
    
    static let singleCellHeight = UsersDynamicProfileCell.singleCellSize.height + UsersDynamicProfileCell.cellMarginBottom
    static let doubleCellHeight = UsersDynamicProfileCell.doubleCellSize.height + UsersDynamicProfileCell.cellMarginBottom
    static let threeCellHeight = UsersDynamicProfileCell.threeCellSize.height + UsersDynamicProfileCell.cellMarginBottom
    
    private lazy var collectionView: UICollectionView = {
        let layout = UICollectionViewFlowLayout()
        layout.minimumLineSpacing = UsersDynamicProfileCell.itemInteritemSpacing
        layout.minimumInteritemSpacing = UsersDynamicProfileCell.itemInteritemSpacing
        layout.sectionInset = UIEdgeInsets(top: 0, left: UsersDynamicProfileCell.horizontalMargin, bottom: 12, right: UsersDynamicProfileCell.horizontalMargin)
        let cv = UICollectionView(frame: .zero, collectionViewLayout: layout)
        cv.register(UsersDynamicProfileSubCell.self, forCellWithReuseIdentifier: "UsersDynamicProfileSubCell")
        cv.register(UsersDynamicProfileCellHeaderView.self, forSupplementaryViewOfKind: UICollectionView.elementKindSectionHeader, withReuseIdentifier: "UsersDynamicProfileCellHeaderView")
        cv.backgroundColor = .none
        cv.delegate = self
        cv.dataSource = self
        cv.showsHorizontalScrollIndicator = false
        cv.showsVerticalScrollIndicator = false
        cv.isDirectionalLockEnabled = true
        cv.isScrollEnabled = false
        cv.bounces = false
        cv.bouncesZoom = false
        return cv
    }()
    
    private lazy var bottomSplitLine: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor.white.withAlphaComponent(0.05)
        return view
    }()
    
    weak var delegate: UsersDynamicProfileCellDelegate?
    
    var currentIndex: Int = 0
    
    private var referenceHeaderSize: CGSize = .zero
    
    private var listData: [URL] = []
    
    var dataModel: FeedBackItem? {
        didSet {
            listData = dataModel?.imgs ?? []
            if let layout = collectionView.collectionViewLayout as? UICollectionViewFlowLayout, !UsersDynamicProfileItemCell.subCellContentHeightList.isEmpty {
                layout.headerReferenceSize = CGSize(width: UIScreen.main.bounds.width, height: UsersDynamicProfileItemCell.subCellContentHeightList[currentIndex])
                let count = listData.count
                layout.itemSize = count == 0 ? .zero : count == 1 ? UsersDynamicProfileCell.singleCellSize : count == 2 ? UsersDynamicProfileCell.doubleCellSize : UsersDynamicProfileCell.threeCellSize
            }
            collectionView.reloadData()
        }
    }
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        backgroundColor = .none
        selectionStyle = .none
        renderView()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func renderView() {
        contentView.addSubview(collectionView)
        contentView.addSubview(bottomSplitLine)
        
        collectionView.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
        bottomSplitLine.snp.makeConstraints { (make) in
            make.left.right.equalToSuperview().inset(10)
            make.height.equalTo(0.5)
            make.bottom.equalToSuperview()
        }
    }
    
}

extension UsersDynamicProfileCell: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return listData.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "UsersDynamicProfileSubCell", for: indexPath) as! UsersDynamicProfileSubCell
        cell.imgUrl = listData[indexPath.row]
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, viewForSupplementaryElementOfKind kind: String, at indexPath: IndexPath) -> UICollectionReusableView {
        guard kind == UICollectionView.elementKindSectionHeader, let header = collectionView.dequeueReusableSupplementaryView(ofKind: kind, withReuseIdentifier: "UsersDynamicProfileCellHeaderView", for: indexPath) as? UsersDynamicProfileCellHeaderView else {
            return UICollectionReusableView()
        }
        header.dataModel = dataModel
        return header
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        delegate?.showBannerDeleteMaskView(row: currentIndex, subIndex: indexPath.row)
    }
    
}


