//
//  ImageURL.swift
//  CaoLong
//
//  Created by mac on 2020/10/6.
//  Copyright © 2020 mac. All rights reserved.
//

import Foundation

/**
 图片URL裁剪，默认为2列的大小
 
 # 使用说明
 ```
 KingfisherManager.shared.defaultOptions = [.requestModifier(CustomRequestModifier())]
 ```
 */
public struct CustomRequestModifier: ImageDownloadRequestModifier {
    public func modified(for request: URLRequest) -> URLRequest? {
        let url = request.url?.column2
        guard url != nil else {
            return request
        }
        let request2 = URLRequest(url: url!, cachePolicy: request.cachePolicy, timeoutInterval: request.timeoutInterval)
        return request2
    }
}

//  以@3x为准
enum ImageURLWidth: Int {
    case column0 = 0        //  原图
    case column1 = 1200     //  每行1列
    case column2 = 600      //  每行2列
    case column3 = 400      //  每行3列
}

extension URL {
    //  原图
    var column0: URL? {
        get {
            return image_url(self, width: .column0)
        }
    }
    
    //  1列
    var column1: URL? {
        get {
            return image_url(self, width: .column1)
        }
    }
    
    //  2列
    var column2: URL? {
        get {
            return image_url(self, width: .column2)
        }
    }
    
    //  3列
    var column3: URL? {
        get {
            return image_url(self, width: .column3)
        }
    }
}

private func image_url(_ url: URL?, width: ImageURLWidth) -> URL? {
    return image_url(url, width: width.rawValue)
}

/*
 http://202.79.169.241:8090/image/ri/80/ed/ta/28ff6e0a4bc0467ba585003e2e6403fb.jpeg?m=1&w=256&h=256&s=0.3
    m   int     // 0:原图 1:等比缩放 如果w和h同时存在不裁剪(拉抻变形) 2.等比缩放，居中裁剪(不变形)
    w   int     // 宽, 缩放
    h   int     // 高, 缩放
    s   float64 // 高斯强度
 */
private func image_url(_ url: URL?, width: Int) -> URL? {
//    return url
    
    guard url != nil else {
        return url
    }
    var components = URLComponents(url: url!, resolvingAgainstBaseURL: false)
    var items = components?.queryItems ?? [URLQueryItem]()
    var hasM = false
    //  有m，表示url已经被修改过了，就不用再修改
    for item in items {
        if item.name == "m" {
            hasM = true
            break
        }
    }
    if !hasM {
        let m = URLQueryItem(name: "m", value: String(width == 0 ? 0 : 1))
        let w = URLQueryItem(name: "w", value: String(width))
        items.append(m)
        if width != 0 {
            items.append(w)
        }
    }
    components?.queryItems = items
    let url2 = components?.url
    return url2
}
