//
//  StatusBarOrientationController.swift
//  CaoLong
//
//  Created by mac on 2020/7/14.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class StatusBarOrientationController: UIViewController {
    var supportedOrientations: UIInterfaceOrientationMask
    
    override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: Bundle?) {
        supportedOrientations = .allButUpsideDown
        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override var shouldAutorotate: Bool {
        return true
    }
    
    override var supportedInterfaceOrientations: UIInterfaceOrientationMask {
        return supportedOrientations
    }
}
