//
//  Adapter.swift
//  CaoLong
//
//  Created by mac on 2020/7/8.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

protocol Adapter: NSObject {
    associatedtype M: NSObject
    associatedtype V: UIView
    
    var model: M? { get set }
    var view: V? { get set }
}
