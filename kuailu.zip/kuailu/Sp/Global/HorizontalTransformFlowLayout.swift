//
//  HorizontalTransformFlowLayout.swift
//  Swift-iOS-2
//
//  Created by mac on 2020/11/11.
//

import UIKit

class HorizontalTransformFlowLayout: UICollectionViewFlowLayout {
    open var scaleFactor: CGFloat = 0.001       //  缩放因子
    
    override func prepare() {
        super.prepare()
        scrollDirection = .horizontal
    }
    
    override func shouldInvalidateLayout(forBoundsChange newBounds: CGRect) -> Bool {
        return true
    }
    
    override func layoutAttributesForElements(in rect: CGRect) -> [UICollectionViewLayoutAttributes]? {
        let array = super.layoutAttributesForElements(in: rect)!
        let centerX: CGFloat = collectionView!.contentOffset.x + collectionView!.bounds.width / 2
        for item in array {
            let cellCenterX = item.center.x
            let distance = abs(cellCenterX - centerX)
            let scale: CGFloat = 1 / (1 + distance * scaleFactor)
            item.transform3D = CATransform3DMakeScale(1, scale, 1.0)
        }
        return array
    }
    
    override func targetContentOffset(forProposedContentOffset proposedContentOffset: CGPoint, withScrollingVelocity velocity: CGPoint) -> CGPoint {
        let x = proposedContentOffset.x
        let y = proposedContentOffset.y
        let w = collectionView!.bounds.width
        let h = collectionView!.bounds.height
        
        let targetRect = CGRect(x: x, y: y, width: w, height: h)
        let centerX = proposedContentOffset.x + collectionView!.bounds.size.width / 2
        
        let array = super.layoutAttributesForElements(in: targetRect)!
        var min = array[0]
        for item in array {
            if abs(item.center.x - centerX) < abs(min.center.x - centerX) {
                min = item
            }
        }
        
        let offsetX = min.center.x - centerX
        return CGPoint(x: proposedContentOffset.x + offsetX, y: proposedContentOffset.y)
    }
    
}
