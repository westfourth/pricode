//
//  GlobalSettings.swift
//  Puff
//
//  Created by mac on 2019/10/14.
//  Copyright © 2019 mac. All rights reserved.
//

import UIKit

/// 标识播放器中的滑动条
let sliderTag: Int = -1

/// 全域性外观设定
class GlobalSettings: NSObject {
    
    //  全域性外观设定
    class func setupAppearance() {
        //  隐藏返回文字
        UIBarButtonItem.appearance().setBackButtonTitlePositionAdjustment(UIOffset(horizontal: -1000, vertical: 0), for: .default)
        
        //  UINavigationBar
        let navBar = UINavigationBar.appearance()
        //        navBar.barTintColor = RGB(0x141516)
        navBar.tintColor = .white
        navBar.titleTextAttributes = [
            .font: UIFont.pingFangMedium(17),
            .foregroundColor: UIColor.white,
        ]
        
        //  UITabBar
        let tabBar = UITabBar.appearance()
        tabBar.backgroundImage = UIImage(named: "navi_backImage")
        //        tabBar.backgroundImage = UIImage()
        tabBar.tintColor = UIColor.white
        tabBar.unselectedItemTintColor = RGB(0xA8A8A8)
        tabBar.isTranslucent = true
        
        //  文字阴影
        let shadow = NSShadow()
        shadow.shadowColor = UIColor.black.withAlphaComponent(1)
        shadow.shadowOffset = CGSize(width: 0.5, height: 0.5)
        shadow.shadowBlurRadius = 0;
        
        //  UITabBarItem
        let tabbarItem = UITabBarItem.appearance()
        tabbarItem.setTitleTextAttributes([
            //            .font: font(12, .semibold),
            .foregroundColor: rgb(0xA8A8A8),
            //            .shadow: shadow,
        ], for: .normal)
        tabbarItem.setTitleTextAttributes([
            //            .font: font(12, .semibold),
            .foregroundColor: rgb(0xEA9418),
            //            .shadow: shadow,
        ], for: .selected)
        
        if #available(iOS 14.0, *) {
            UITableViewCell.appearance().backgroundConfiguration = .clear()
        }
    }
    
    class func addBlackShadow(_ view: UIView) {
        view.layer.shadowColor = UIColor.black.cgColor;
        view.layer.shadowOffset = .zero;
        view.layer.shadowRadius = 2;
        view.layer.shadowOpacity = 1;
    }
    
    class func addWhiteShadow(_ view: UIView) {
        view.layer.shadowColor = UIColor.white.cgColor;
        view.layer.shadowOffset = .zero;
        view.layer.shadowRadius = 2;
        view.layer.shadowOpacity = 1;
    }
    
    //MARK:-对imagepickerController做特殊处理
    static func setImagePickerNatiBarAttribute() {
        let navBar = UINavigationBar.appearance()
        navBar.tintColor = .black
        navBar.titleTextAttributes = [
            .font: UIFont.pingFangMedium(17),
            .foregroundColor: UIColor.black,
        ]
    }
    
    static func resetNaviBarAttribute() {
        let navBar = UINavigationBar.appearance()
        navBar.tintColor = .white
        navBar.titleTextAttributes = [
            .font: UIFont.pingFangMedium(17),
            .foregroundColor: UIColor.white,
        ]
    }
    
    //  改变默认支持方向: UIViewController.supportedInterfaceOrientations = .portrait
    //    class func supportedInterfaceOrientations() {
    //        let cls = UIViewController.self
    //        let sel = #selector(getter: UIViewController.supportedInterfaceOrientations)
    //        let method = class_getInstanceMethod(cls, sel)
    //
    //        let block: @convention(block) (UIViewController) -> UIInterfaceOrientationMask = {
    //            (vc) -> UIInterfaceOrientationMask in
    //            return .portrait
    //        }
    //        let imp = imp_implementationWithBlock(block)
    //        method_setImplementation(method!, imp)
    //    }
    
    //  扩大slider点击范围
    class func expandSliderHitScope() {
        let cls = UITabBar.self
        let sel = #selector(UITabBar.hitTest(_:with:))
        let method = class_getInstanceMethod(cls, sel)
        let imp0 = method_getImplementation(method!);
        let block: @convention(block) (UITabBar, CGPoint, UIEvent?) -> UIView? = {
            (tabBar, point, event) -> UIView? in
            if point.y < 15 && point.y >= 0 {
                let view = UIApplication.shared.windows.first?.viewWithTag(sliderTag)
                return view
            }
            typealias ClosureType = @convention(c) (UITabBar, Selector, CGPoint, UIEvent?) -> UIView?
            let hitFunc : ClosureType = unsafeBitCast(imp0, to: ClosureType.self)
            let view = hitFunc(tabBar, sel, point, event)
            return view
        }
        let imp = imp_implementationWithBlock(block)
        method_setImplementation(method!, imp)
    }
}

public func attribute(_ content:String, font:UIFont,lineSpacing:CGFloat,textColor:UIColor)->NSMutableAttributedString {
    let a = NSMutableAttributedString(string: content)
    let r = NSRange(location: 0, length: content.count)
    let p = NSMutableParagraphStyle()
    p.lineSpacing = lineSpacing
    p.alignment = .left
    a.addAttributes([NSAttributedString.Key.font : font], range: r)
    a.addAttributes([NSAttributedString.Key.foregroundColor : textColor], range: r)
    a.addAttributes([NSAttributedString.Key.paragraphStyle :p ], range: r)
    return a
}
