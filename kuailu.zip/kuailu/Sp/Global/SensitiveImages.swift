//
//  SensitiveImages.swift
//  Sp
//
//  Created by mac on 2020/4/21.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

extension Sensitive {
    //  默认背景图
    static let default_bg: UIImage? = {
        return Defaults.didPassReview ? UIImage(named: "default_bg") : nil
    }()
    
    //  登陆背景图
    static let login_bg: UIImage? = {
        return Defaults.didPassReview ? UIImage.decrypt("login_back.png.enc") : nil
    }()
    
    //  分享背景图
    static let share_bg: UIImage? = {
        return Defaults.didPassReview ? UIImage.decrypt("share_back.png.enc") : nil
    }()
  
    //  热点海报
    static let hotspot: UIImage? = {
        return Defaults.didPassReview ? UIImage.decrypt("hotspot_poster.jpg.enc") : nil
    }()

    //  头像
    static let avatar: UIImage? = {
        return Defaults.didPassReview ? UIImage(named: "avatar") : UIImage(named: "avatar_store")!
    }()
    
    //  广告banner
    static let banner: UIImage? = {
        return Defaults.didPassReview ? UIImage(named: "banner_default_bg") : nil
    }()
    
    //  用户动态banner
    static let usersDynamicBannerDefaultImg: UIImage? = {
        return Defaults.didPassReview ? UIImage.decrypt("users_dynamic_default_banner.jpg.enc") : nil
    }()
    
    static let animationOption: KingfisherOptionsInfo = {
        return [.transition(.fade(0.25))]
    }()
    
    static let animationOptionGif: KingfisherOptionsInfo = {
        return [.transition(.fade(0.25)), .backgroundDecode, .fromMemoryCacheOrRefresh]
    }()


}
