//
//  Color.swift
//  KuaiLu
//
//  Created by mac on 2021/2/16.
//  Copyright © 2021 mac. All rights reserved.
//

import UIKit

class Color {
    
    static let bg_color = RGB(0x141516)
    
    static let theme_color = RGB(0xFF9903)
    
}
