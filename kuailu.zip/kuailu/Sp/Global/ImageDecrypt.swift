//
//  ImageDecrypt.swift
//  Test
//
//  Created by mac on 2020/2/27.
//  Copyright © 2020 mac. All rights reserved.
//

import Foundation
import Kingfisher


/**
 图片解码
 
 # 使用说明
 ```
 KingfisherManager.shared.defaultOptions = [.processor(CustomImageProcessor())]
 ```
 */
public struct CustomImageProcessor: ImageProcessor {
    
    public let identifier = ""
    
    public func process(item: ImageProcessItem, options: KingfisherParsedOptionsInfo) -> KFCrossPlatformImage? {
        switch item {
        case .image(let image):
            return image.kf.scaled(to: options.scaleFactor)
        case .data(let data):
            var decryptData = data
            if data.kf.imageFormat == .unknown {
                decryptData = xor_decrypt(data)
            }
            let options = ImageCreatingOptions(
                scale: 1,
                duration: 0,
                preloadAll: true,
                onlyFirstFrame: false)
            return KingfisherWrapper.image(data: decryptData, options: options)
        }
    }
}

/// 解密金钥
private let imageDecryptKey = "2020-zq3-888"

/// 图片解密
private func xor_decrypt(_ data: Data) -> Data {
    if data.count < 100 {
        return data
    }
    let keyData = Data(imageDecryptKey.utf8)
    var decryptData = data
    for i in 0..<100 {
        let idx = i % keyData.count
        let c1: UInt8 = keyData[idx]
        let c2: UInt8 = data[i]
        var c3: UInt8 = c1 ^ c2
        let range: Range<Data.Index> = i..<(i + 1)
        decryptData.replaceSubrange(range, with: &c3, count: 1)
    }
    return decryptData
}


private let novelDecryptKey = "a"
public func xor_decrypt_novel(_ data: Data) -> Data {
    if data.count < 100 {
        return data
    }
    let keyData = Data(novelDecryptKey.utf8)
    var decryptData = data
    for i in 0..<100 {
        let idx = i % keyData.count
        let c1: UInt8 = keyData[idx]
        let c2: UInt8 = data[i]
        var c3: UInt8 = c1 ^ c2
        let range: Range<Data.Index> = i..<(i + 1)
        decryptData.replaceSubrange(range, with: &c3, count: 1)
    }
    return decryptData
}


//_______________________________________________________________________________________________________________
// MARK: - 本地图片解密
public extension UIImage {
    /// 本地图片解密
    /// - Parameter name: 全称，带.jpg、.png
    class func decrypt(_ name: String) -> UIImage {
        let path = Bundle.main.path(forResource: name, ofType: nil)
        let data = NSData(contentsOfFile: path!)
        let data2 = xor_decrypt(data! as Data)
        let image = UIImage(data: data2)
        return image!
    }
}
