//
//  ReviewCheck.swift
//  Swift-iOS
//
//  Created by mac on 2020/10/1.
//  Copyright © 2020 mac. All rights reserved.
//

import Foundation

class ReviewCheck {
    
    //  是否进入主包
    class func shouldEnterMain() -> Bool {
        if isInChina() {
            return true
        }
        return false
    }
    
    //  中国时区（东五区～东九区）
    class func isInChina() -> Bool {
        let tz = TimeZone.current
        if tz.secondsFromGMT() <= +9 * 3600 ||
            tz.secondsFromGMT() >= +5 * 3600 {
            return true
        }
        return false
    }
    
    //  判断是否开启VPN，容易崩溃
    class func isVPNOn() -> Bool {
        let cfDictRef = CFNetworkCopySystemProxySettings()
        let cfDict = cfDictRef?.takeRetainedValue()
        if let dict = cfDict as? [String: Any] {
            if let scoped = dict["__SCOPED__"] as? [String: Any] {
                for key in scoped.keys {
                    if key.contains("tap") ||
                        key.contains("tun") ||
                        key.contains("ipsec") ||
                        key.contains("ppp") {
                        return true
                    }
                }
            }
        }
        cfDictRef?.release()
        return false
    }
    
    //  判断2秒内是否能访问google（google在国内被墙）
    class func canAccessGoogle(completion: @escaping (Bool) -> Void) {
        let url = URL(string: "https://www.google.com")
        var req = URLRequest(url: url!)
        req.timeoutInterval = 2
        let task = URLSession.shared.dataTask(with: req) { (data, res, err) in
            let resp = res as! HTTPURLResponse
            if err != nil || resp.statusCode != 200 {
                completion(false)
                return
            }
            completion(true)
        }
        task.resume()
    }
}
