//
//  Animation.swift
//  Puff
//
//  Created by mac on 2019/10/11.
//  Copyright © 2019 mac. All rights reserved.
//

import Foundation

class Animation {
    //  正常 --> 放大 --> 正常
    class func scaleBounce(_ view: UIView) {
        let s = CAKeyframeAnimation()
        s.keyPath = "transform.scale"
        s.duration = 0.25
        s.values = [1, 1.35, 1]
        view.layer.add(s, forKey: nil)
    }
    
    //  向上移动，同时变透明
    class func moveUp(_ view: UIView) {
        let t = CAKeyframeAnimation()
        t.keyPath = "transform.translation.y"
        t.values = [0, -25]
        
        let o = CAKeyframeAnimation()
        o.keyPath = "opacity"
        o.values = [1, 0]
        
        let g = CAAnimationGroup()
        g.animations = [t, o]
        g.duration = 0.4
        
        view.layer.add(g, forKey: nil)
    }
    
    //  向下移动，同时变透明
    class func moveDown(_ view: UIView) {
        let t = CAKeyframeAnimation()
        t.keyPath = "transform.translation.y"
        t.values = [0, 25]
        
        let o = CAKeyframeAnimation()
        o.keyPath = "opacity"
        o.values = [1, 0]
        
        let g = CAAnimationGroup()
        g.animations = [t, o]
        g.duration = 0.4
        
        view.layer.add(g, forKey: nil)
    }
    
    //  左右抖动
   class func shakeHorizontal(_ view: UIView) {
        let s = CAKeyframeAnimation()
        s.keyPath = "transform.translation.x"
        s.duration = 0.4
        s.values = [-15,15,-15,15,0]
        view.layer.add(s, forKey: nil)
    }
    
}
