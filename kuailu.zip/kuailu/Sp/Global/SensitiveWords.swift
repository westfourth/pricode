//
//  SensitiveWords.swift
//  Sp
//
//  Created by mac on 2020/4/20.
//  Copyright © 2020 mac. All rights reserved.
//

import Foundation

//  敏感词
struct Sensitive {
    //  草榴、草榴
    static let cao = "\u{964c}\u{964c}"
    //  支付、支付
    static let zhi = "\u{652f}\u{4ed8}"
    //  微信、微信
    static let wei = "\u{5fae}\u{4fe1}"
    //  银行、银行
    static let yin = "\u{9280}\u{884c}"
    //  金币、金币
    static let jin = "\u{91d1}\u{5e63}"
    //  价格、价格
    static let jia = "\u{50f9}\u{683c}"
    //  付费、付费
    static let fu = "\u{4ed8}\u{8cbb}"
    //  付款、付款
    static let kuan = "\u{4ed8}\u{6b3e}"
    //  充值、充值
    static let chong = "\u{5145}\u{503c}"
    //  购买、购买
    static let gou = "\u{8cfc}\u{8cb7}"
    //  会员、会员
    static let hui = "\u{6703}\u{54e1}"
    //  钱包、钱包
    static let qian = "\u{9322}\u{5305}"
    //  余额、余额
    static let yu = "\u{9918}\u{984d}"
    //  收入、收入
    static let shou = "\u{6536}\u{5165}"
    //  提现、提现
    static let ti = "\u{63d0}\u{73fe}"
    //  转账、转账
    static let zhuan = "\u{8f6c}\u{8d26}"
    //  兑换、兑换
    static let dui = "\u{514c}\u{63db}"
    //  打赏、打賞
    static let shang = "\u{6253}\u{8cde}"
    //  金额、金額
    static let e = "\u{91d1}\u{984d}"
}
