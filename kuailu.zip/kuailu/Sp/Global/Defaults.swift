//
//  Defaults.swift
//  JsonTest
//
//  Created by mac on 2019/10/12.
//  Copyright © 2019 mac. All rights reserved.
//

import Foundation

/// 偏好设定
class Defaults {
    /// 下载次数
    class var downloadNum: Int {
        get {
            return UserDefaults.standard.integer(forKey: #function)
        }
        set {
            UserDefaults.standard.set(newValue, forKey: #function)
        }
    }
    
    //  是否过了审核。预设为false
    class var didPassReview: Bool {
        get {
            let packageName = Bundle.main.infoDictionary!["VestBag"] as! String
            return UserDefaults.standard.bool(forKey: packageName)
        }
        set {
            let packageName = Bundle.main.infoDictionary!["VestBag"] as! String
            UserDefaults.standard.set(newValue, forKey: packageName)
        }
    }
    
    //  app版本号
    class var appVersion: String? {
        get {
            return UserDefaults.standard.string(forKey: #function)
        }
        set {
            UserDefaults.standard.set(newValue, forKey: #function)
        }
    }
    
    /// 是否弹出过绑定手机号 ，用于我的页面弹出绑定弹框
    class var alertBind: Bool {
        get {
            return UserDefaults.standard.bool(forKey: #function)
        }
        set {
            UserDefaults.standard.set(newValue, forKey: #function)
        }
    }
    
    //  搜索记录历史标签
    class var historyTags: [String]? {
        get {
            return UserDefaults.standard.array(forKey: #function) as? [String]
        }
        set {
            UserDefaults.standard.set(newValue, forKey: #function)
        }
    }
    
    //  成人小说有声读物搜索关键字历史记录
    class var novelReadingHistoryKeywordList: [String]? {
        get {
            return UserDefaults.standard.array(forKey: #function) as? [String]
        }
        set {
            UserDefaults.standard.set(newValue, forKey: #function)
        }
    }
    
    /// 分享url
    class var shareURL:URL? {
        get {
            return UserDefaults.standard.url(forKey: #function)
        }
        set {
            UserDefaults.standard.set(newValue, forKey: #function)
        }
    }
    
    /// app地址
    class var website:String? {
        get {
            return UserDefaults.standard.string(forKey: #function)
        }
        set {
            UserDefaults.standard.set(newValue, forKey: #function)
        }
    }
    
    /// 关注页面最后一次视频ID
    class var focusLastVideoID: Int {
        get {
            return UserDefaults.standard.integer(forKey: #function)
        }
        set {
            UserDefaults.standard.set(newValue, forKey: #function)
        }
    }
    
    /// 最新 用于通知
    class var latestId: Int {
        get {
            return UserDefaults.standard.integer(forKey: #function)
        }
        set {
            UserDefaults.standard.set(newValue, forKey: #function)
        }
    }
    
    /// 当天的每10分钟视频上报次数
    class var todayReportCount: Int {
        get {
            return UserDefaults.standard.integer(forKey: #function + today())
        }
        set {
            UserDefaults.standard.set(newValue, forKey: #function + today())
        }
    }
    
    /// 当天观看的m3u8文件名数组
    //    class var todayWatchedM3u8: [String] {
    //        get {
    //            var array = UserDefaults.standard.array(forKey: #function + today())
    //            if array is [String] == false {
    //                array = [String]()
    //            }
    //            return array as! [String]
    //        }
    //        set {
    //            UserDefaults.standard.set(newValue, forKey: #function + today())
    //        }
    //    }
    
    /// 用于等级 当前用户总分
    class var rechargeTotal: Int? {
        get {
            return UserDefaults.standard.integer(forKey: #function)
        }
        set {
            UserDefaults.standard.set(newValue, forKey: #function)
        }
    }
    
    /// 当前用户等级
    class var currentLevel: Int? {
        get {
            return UserDefaults.standard.integer(forKey: #function)
        }
        set {
            UserDefaults.standard.set(newValue, forKey: #function)
        }
    }
    
    /// 当前城市
    class var officialCurrentCity:String? {
        get {
            return UserDefaults.standard.string(forKey: #function)
        }
        set {
            UserDefaults.standard.set(newValue, forKey: #function)
        }
    }
    
    /// 当前城市
    class var squareCurrentCity:String? {
        get {
            return UserDefaults.standard.string(forKey: #function)
        }
        set {
            UserDefaults.standard.set(newValue, forKey: #function)
        }
    }
    
    
    /// 当前城市
    class var clubCurrentCity:String? {
        get {
            return UserDefaults.standard.string(forKey: #function)
        }
        set {
            UserDefaults.standard.set(newValue, forKey: #function)
        }
    }
    
    
    /// webClip当日日期时间戳缓存
    class var webClipDateTimestamp: Double? {
        get {
            return UserDefaults.standard.double(forKey: #function)
        }
        set {
            UserDefaults.standard.set(newValue, forKey: #function)
        }
    }
    
    class func today() -> String {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd"
        let string = dateFormatter.string(from: Date())
        return string
    }
    
    //MARK:-    调试用
    
    class var debugLineMode: ChooseLineMode {
        get {
            let i = UserDefaults.standard.integer(forKey: #function)
            return ChooseLineMode(rawValue: i)!
        }
        set {
            UserDefaults.standard.set(newValue.rawValue, forKey: #function)
        }
    }
    
    class var debugJumpLaunch: Bool {
        get {
            return UserDefaults.standard.bool(forKey: #function)
        }
        set {
            UserDefaults.standard.set(newValue, forKey: #function)
        }
    }
    
    class var debugJumpVersionUpdate: Bool {
        get {
            return UserDefaults.standard.bool(forKey: #function)
        }
        set {
            UserDefaults.standard.set(newValue, forKey: #function)
        }
    }
    
    //  观看进度，范围: [0, 1]
    class func writeWatchProgress(url: URL, progress: Float) {
        UserDefaults.standard.set(progress, forKey: url.absoluteString)
    }
    class func readWatchProgress(url: URL) -> Float {
        return UserDefaults.standard.float(forKey: url.absoluteString)
    }
    
    ///  观看历史
    class var shortWatchItems:[VideoItem] {
        get {
            var items:[VideoItem] = [VideoItem]()
            if let jsons = UserDefaults.standard.object(forKey: "shortWatch") as? [[String:Any]] {
                for json in jsons {
                    if let item = VideoItem.deserialize(from: json) {
                        items.append(item)
                    }
                }
            }
            return items
        }
    }
    
    static func saveShortWatch(_ videoItem:VideoItem) {
        var results = Defaults.shortWatchItems
        let ids = results.map({return $0.videoId})
        guard !ids.contains(videoItem.videoId) else {return}
        results.insert(videoItem, at: 0)
        UserDefaults.standard.set(results.toJSON(), forKey: "shortWatch")
        UserDefaults.standard.synchronize()
    }
    
    ///  观看历史
    class var longWatchItems:[VideoItem] {
        get {
            var items:[VideoItem] = [VideoItem]()
            if let jsons = UserDefaults.standard.object(forKey: "longWatch") as? [[String:Any]] {
                for json in jsons {
                    if let item = VideoItem.deserialize(from: json) {
                        items.append(item)
                    }
                }
            }
            return items
        }
    }
    
    static func saveLongWatch(_ videoItem:VideoItem) {
        var results = Defaults.longWatchItems
        let ids = results.map({return $0.videoId})
        guard !ids.contains(videoItem.videoId) else {return}
        results.insert(videoItem, at: 0)
        UserDefaults.standard.set(results.toJSON(), forKey: "longWatch")
        UserDefaults.standard.synchronize()
    }
    
    /// 官方群链接
       class var officialUrl:String? {
           get {
               return UserDefaults.standard.string(forKey: #function)
           }
           set {
               UserDefaults.standard.set(newValue, forKey: #function)
           }
       }
    
    /// 是否保存账号凭证
    class var accountCerSaved:Bool{
        get {
            return UserDefaults.standard.bool(forKey: #function)
        }
        set {
            UserDefaults.standard.set(newValue, forKey: #function)
        }
    }
    
    /// 账号凭证弹出时间戳缓存
    class var accountCerDateTimeStamp: Double? {
        get {
            return UserDefaults.standard.double(forKey: #function)
        }
        set {
            UserDefaults.standard.set(newValue, forKey: #function)
        }
    }
    
    /// 是否有活动
    class var hasDiscountActivity: Bool {
        get {
            return UserDefaults.standard.bool(forKey: #function)
        }
        set {
            UserDefaults.standard.set(newValue, forKey: #function)
        }
    }
    
    //// 小说观看历史
    class var novels:[NovelItem]? {
        get {
            if let jsons = UserDefaults.standard.object(forKey: "saveWatch_novels") as? [[String:Any]] {
                var items:[NovelItem] = [NovelItem]()
                for json in jsons {
                    if let item = NovelItem.deserialize(from: json) {
                        items.append(item)
                    }
                }
                return items.isEmpty ? nil : items
            }
            return nil
        }
    }
    
    
    static func saveNovel(_ novel:NovelItem) {
        if var novels = Defaults.novels {
            let ids = novels.map({return $0.fictionId})
            guard !ids.contains(novel.fictionId) else {return}
            novels.insert(novel, at: 0)
            UserDefaults.standard.set(novels.toJSON(), forKey: "saveWatch_novels")
            UserDefaults.standard.synchronize()
        } else {
            // 没有数据
            UserDefaults.standard.set([novel].toJSON(), forKey: "saveWatch_novels")
            UserDefaults.standard.synchronize()
        }
    }
    

}
