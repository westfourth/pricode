//
//  GlobalSettings.swift
//  Puff
//
//  Created by mac on 2019/10/14.
//  Copyright © 2019 mac. All rights reserved.
//

import UIKit

/// 局部外观设定
class Appearance: NSObject {
    
    class func transparent(_ transparent: Bool, navigationBar: UINavigationBar?) {
        if transparent {
            navigationBar?.isTranslucent = true
            navigationBar?.setBackgroundImage(UIImage(), for: .default)
            navigationBar?.shadowImage = UIImage()
        } else {
            navigationBar?.isTranslucent = false
            navigationBar?.setBackgroundImage(nil, for: .default)
            navigationBar?.shadowImage = nil
        }
    }
    
    enum GradientStyle {
        case gray
        case orange
    }
    
    class func gradient(view: UIView, style: GradientStyle) {
        object_setClass(view.layer, CAGradientLayer.self)
        let layer = view.layer as! CAGradientLayer
        layer.startPoint = CGPoint(x: 0, y: 0.5)
        layer.endPoint = CGPoint(x: 1, y: 0.5)
        switch style {
        case .gray:
            layer.colors = [rgb(0xB0B0B0).cgColor,
                            rgb(0x898989).cgColor]
        case .orange:
            layer.colors = [rgb(0xFE6000).cgColor,
                            rgb(0xFC9239).cgColor]
        default:
            break
        }
    }
}

