//
//  InnerIntercept.swift
//  Sp
//
//  Created by mac on 2020/5/5.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

//MARK:-内部跳转拦截器

class InnerIntercept: NSObject {
    
    static func canOpenURL(_ url: URL) -> Bool {
        if UIApplication.shared.canOpenURL(url) {
            return true
        } else if url.scheme == "inner" && url.host == "cao" {
            return true
        }
        return false
    }
    
    /// 1. inner://cao/video?videoId=9911
    /// 2. inner://cao/activity?outer=http://www.baidu.com
    /// 3. inner://cao/rech
    /// 4. inner://cao/welfare
    /// 5. inner://cao/wallet
    /// 6. inner://cao/popularize
    /// 7.inner://cao/meet/official
    /// 8.inner://cao/meet/square
    /// 9.inner://cao/meet/trends
    /// 10.inner://cao/portray   跳转具体写真页面
    /// 11.inner://cao/collection?collectionID=<合集ID>  跳转合集
    /// 12.inner://cao/category/rank  跳转分类（排行榜活动，H5活动页面，V6专区）
    /// 13/inner://cao/category/web
    /// 14.inner://cao/category/v6
    /// 15.inner://cao/community/square   跳转社区
    /// 16.inner://cao/profile?userID=<用户ID>   跳转个人主页
    /// 17.inner://cao/publish   跳转发布
    static func open(_ url:URL) {
        if UIApplication.shared.canOpenURL(url) {
            UIApplication.shared.open(url)
            return
        }
        if !(url.scheme == "inner" && url.host == "cao") {
            return
        }
        
        let component = URLComponents(url: url, resolvingAgainstBaseURL: true)
        let item = component?.queryItems?.first!
        let typeItem = component?.path
        switch typeItem {
        case "/video":      //視頻
            watchVideo(item?.value)
        case "/activity", "/category/web":   //活動
            activity(item?.value)
        case "/rech":       //充值
            recharge()
        case "/wallet":     //錢包
            wallet()
        case "/popularize": //推廣
            popularize()
        case "/meet/official": // 官推
            switchSexChatIndex(0)
        case "/meet/square":    // 廣場
            switchSexChatIndex(1)
        case "/meet/trends":   // 動態朋友圈
            switchSexChatIndex(2)
        case "/publish":   // 发布
            publishAction()
        case "/community/square": // 社区
            communityAction()
        case "/profile":  // 个人主页
            userAction(item?.value)
        case "/portray":  // 写真广场
            portraySquareAction()
        case "/collection": // 合集
            collectionAction(item?.value)
        case "/category/rank": //活动排行榜
            activityRankingAction()
        case "/welfare", "/category/v6": //福利
            switchToAVVCCategoryBar(type: .recommend)
        default:
            break
        }
    }
    
    private static func collectionAction(_ collectionId:String?) {
        guard let cid = collectionId, let choiceId = Int(cid) else { return }
        ClassyVideoSetVC.isFromClassy = true
        let classyVideoSetVC = ClassyVideoSetVC()
        let itemData = ClassyItem()
        itemData.choiceId = choiceId
        classyVideoSetVC.itemData = itemData
        currentNaviController().show(classyVideoSetVC, sender: nil)
    }
    
    private static func switchToAVVCCategoryBar(type : AVCategoryType) {
        let windows = UIApplication.shared.windows
        for i in 0..<windows.count {
            if let rootVC = windows[i].rootViewController as? UITabBarController {
                rootVC.selectedIndex = 1
                DispatchQueue.main.asyncAfter(deadline: .now()) {
                    guard let currrentNavigation = rootVC.selectedViewController as? UINavigationController, let avVC = currrentNavigation.topViewController as? AVVC else { return }
                    avVC.switchToCategoryBar(type: type)
                }
                break
            }
        }
    }
    
    // 写真广场
    private static func portraySquareAction() {
        let vc = PhotoVC()
        vc.hidesBottomBarWhenPushed = true
        currentNaviController().pushViewController(vc, animated: true)
    }
    
    /// 发布
    private static func publishAction() {
        let vc = UploadVC()
        let navVC = UINavigationController(rootViewController: vc)
        navVC.modalPresentationStyle = .fullScreen
        currentNaviController().present(navVC, animated: true, completion: nil)
    }
    
    // 社区
    private static func communityAction() {
        let windows = UIApplication.shared.windows
        for i in 0..<windows.count {
            if let rootVC = windows[i].rootViewController as? UITabBarController {
                rootVC.selectedIndex = 2
                break
            }
        }
    }
    
    // 个人主页
    private static func userAction(_ id:String?) {
        guard let userId = id,let uid = Int(userId) else {return}
        let vc = UsersDynamicVC()
        vc.initPageType = .profile
        vc.userId = uid
        vc.hidesBottomBarWhenPushed = true
        currentNaviController().pushViewController(vc, animated: true)
    }
    
    //    //  视频
    //    private static func  watchVideo(_ videoId:String?) {
    //        guard let videoId = videoId else {
    //            return
    //        }
    //        let req = FetchVideoByIdsReq()
    //        req.videoIds = [Int(videoId) ?? 0]
    //        Session.request(req) { (error, resp) in
    //            guard error == nil else {
    //                return
    //            }
    //            guard let items = resp as? [VideoItem], !items.isEmpty else {
    //                return
    //            }
    //
    //            let VC = ShortVideoListVC()
    //            VC.currentPlayingIndexPath = IndexPath(item: 0, section: 0)
    //            VC.videoItems = items
    //            VC.hidesBottomBarWhenPushed = true
    //            self.currentNaviController().pushViewController(VC, animated: true)
    //        }
    //    }
    
    //  视频
    private static func  watchVideo(_ videoId:String?) {
        guard let videoId = Int(videoId ?? "0") else {return}
        let vc = PlayerController()
        vc.videoId = videoId
        vc.hidesBottomBarWhenPushed = true
        currentNaviController().pushViewController(vc, animated: true)
    }
    
    //  活动
    private static func activity(_ value:String?) {
        guard let value = value else {
            return
        }
        guard let token = NetDefaults.token else {return}
        let activityURL = URL(string: "\(value)?token=\(token)" )
        let VC = WebVC()
        WebVC.webViewType = .activity
        VC.webviewUrl = activityURL
        currentNaviController().pushViewController(VC, animated: true)
    }
    
    //  充值
    private static func recharge() {
        // 充值
        let vc = Vip2VC()
        vc.hidesBottomBarWhenPushed = true
        currentNaviController().pushViewController(vc, animated: true)
    }
    
    //MARK:-    新增
    
    //  钱包
    private static func wallet() {
        let vc = WalletVC()
        vc.hidesBottomBarWhenPushed = true
        currentNaviController().pushViewController(vc, animated: true)
    }
    
    //  推广
    private static func popularize() {
        let vc = ShareViewController()
        vc.hidesBottomBarWhenPushed = true
        currentNaviController().pushViewController(vc, animated: true)
    }
    
    ///约吧切换
    private static func switchSexChatIndex(_ index:Int) {
        let windows = UIApplication.shared.windows
        for i in 0..<windows.count {
            if let rootVC = windows[i].rootViewController as? UITabBarController {
                rootVC.selectedIndex = 3
                DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 0.5) {
                    if let currrentNavi = rootVC.selectedViewController as? UINavigationController {
                        if let chatSexVC = currrentNavi.topViewController as? ChatSexVC {
                            chatSexVC.switchAction(index)
                        }
                    }
                }
                break
            }
        }
    }
    
    // 活动排行榜
    private static func activityRankingAction() {
        guard let navigationController = (UIApplication.shared.delegate as? AppDelegate)?.currentNavigationController else { return }
        let classyActivityVC = ClassyActivityVC()
        classyActivityVC.classyActivityType = .processing
        navigationController.pushViewController(classyActivityVC, animated: true)
    }
    
    //MARK:-获取当时正在显示的ViewController
    static func currentNaviController()->UINavigationController {
        let rootVC = UIApplication.shared.keyWindow!.rootViewController as! UITabBarController
        let naviController = rootVC.selectedViewController as! UINavigationController
        return naviController
    }
    
}
