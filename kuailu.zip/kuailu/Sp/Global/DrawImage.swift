//
//  DrawImage.swift
//  Puff
//
//  Created by mac on 2019/12/10.
//  Copyright © 2019 mac. All rights reserved.
//

import UIKit

//  绘制图片
class DrawImage {
    
    //  画一条水平白色细线
    class func createTabbarWhiteLineImage() -> UIImage {
        let height: CGFloat = 0.25
        let size = CGSize(width: UIScreen.main.bounds.width, height: height)
        UIGraphicsBeginImageContext(size)
        let path = UIBezierPath()
        path.move(to: CGPoint(x: 0, y: height / 2.0))
        path.addLine(to: CGPoint(x: size.width, y: height / 2.0))
        path.lineWidth = height
        UIColor.white.withAlphaComponent(0.5).setStroke()
        path.stroke()
        let image = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        return image!
    }
    
    //  生成竖直分割线图片
    class func speratorImage(color: UIColor) -> UIImage {
        let size = CGSize(width: 1, height: 30)
        let rect = CGRect.init(origin: .zero, size: size).inset(by: UIEdgeInsets(top: 10, left: 0, bottom: 10, right: 0))
        UIGraphicsBeginImageContext(size)
        let path = UIBezierPath(roundedRect: rect, cornerRadius: 0)
        color.setFill()
        path.fill()
        let image = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        return image!
    }
    
    //  生成透明图片
    class func transparentImage() -> UIImage? {
        let size = CGSize(width: 40, height: 40)
        UIGraphicsBeginImageContext(size)
        UIColor.clear.setFill()
        UIRectFill(CGRect(x: 0, y: 0, width: size.width, height: size.height))
        let image = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        return image
    }
    
    //  UISlider的图片
    class func sliderImage() -> UIImage {
        let size = CGSize(width: 40, height: 40)
        UIGraphicsBeginImageContextWithOptions(size, false, UIScreen.main.scale)
        
        var path = UIBezierPath(ovalIn: CGRect(x: 0, y: 0, width: size.width, height: size.height))
//        rgb(0xE78C05).withAlphaComponent(0.1).setFill()
//        path.fill()
        
        let size2 = CGSize(width: 10, height: 10)
        path = UIBezierPath(ovalIn: CGRect(x: (size.width - size2.width) / 2, y: (size.height - size2.height) / 2, width: size2.width, height: size2.height))
        UIColor.white.setFill()
        path.fill()
        
        let image = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        return image!
    }
    
    ///  生成二维码
    /// 返回矢量图形
    class func qrCodeImage(text: String) -> CIImage {
        let filter = CIFilter(name: "CIQRCodeGenerator")
        filter?.setValue(text.data(using: String.Encoding.utf8), forKey: "inputMessage")
        let ciImage = (filter?.outputImage)!
        return ciImage
    }
    
    ///  生成二维码
    /// 返回矢量图形，用UIImageView显示
    class func qrCodeImage(text: String, width: CGFloat) -> UIImage {
        var ciImage = qrCodeImage(text: text)
        let scale = width / ciImage.extent.width
        ciImage = ciImage.transformed(by: CGAffineTransform.init(scaleX: scale, y: scale))
        let image = UIImage(ciImage: ciImage)
        return image
    }
}
