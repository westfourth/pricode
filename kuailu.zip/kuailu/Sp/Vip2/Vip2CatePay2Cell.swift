//
//  Vip2CatePay2Cell.swift
//  Sp
//
//  Created by mac on 2020/12/24.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class Vip2CatePay2Cell: UICollectionViewCell {

    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var selectImageView: UIImageView!
    @IBOutlet weak var priceLabel: UILabel!
    
    private enum ImageType: Int {
        case qianbao
        case zhifubao
        case weixin
        case yunshanfu
    }
    
    var type: PayType? {
        didSet {
            guard type != nil else { return }
            var imageType: ImageType = .qianbao
            switch type!.payMent {
            case .alipay:
                imageType = .zhifubao
            case .wechat:
                imageType = .weixin
            case .union:
                imageType = .yunshanfu
            default:
                imageType = .qianbao
            }
            imageView.image = Vip2CatePay2Cell.payImage(type: imageType)
            selectImageView.isHidden = !type!.selected
            priceLabel.isHidden = imageType != .qianbao
            if type!.payMent == .none, let a = NetDefaults.accountInfo {
                let balance = String(format:"%.2f", a.bala)
                priceLabel.text = "\(balance)元"
            }
        }
    }
    
    private class func payImage(type: ImageType) -> UIImage? {
        var imageName: String = ""
        switch type {
        case .weixin:
            imageName = "vip2_1_weixin"
        case .zhifubao:
            imageName = "vip2_1_zhifubao"
        case .yunshanfu:
            imageName = "vip2_1_yunshanfu"
        default:
            imageName = "vip2_1_wallet"
        }
        return UIImage(named: imageName)
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
