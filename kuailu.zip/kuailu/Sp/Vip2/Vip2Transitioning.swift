//
//  Vip2PopTransitioning.swift
//  Sp
//
//  Created by mac on 2020/11/16.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

protocol Vip2PresentTransitioningDelegate: NSObjectProtocol {
    func transition(didTapContainerView on: Vip2PresentTransitioning)
}

class Vip2PresentTransitioning: NSObject, UIViewControllerAnimatedTransitioning, UIGestureRecognizerDelegate {
    weak var delegate: Vip2PresentTransitioningDelegate?
    
    func transitionDuration(using transitionContext: UIViewControllerContextTransitioning?) -> TimeInterval {
        return 0.2
    }

    func animateTransition(using transitionContext: UIViewControllerContextTransitioning) {
        let toVC = transitionContext.viewController(forKey: .to)!
        let containerView = transitionContext.containerView
        containerView.addSubview(toVC.view)
        
        //  添加点击手势
        let tap = UITapGestureRecognizer(target: self, action: #selector(tap(_:)))
        tap.delegate = self
        containerView.addGestureRecognizer(tap)
        
        let appDelegate = UIApplication.shared.delegate as? AppDelegate
        let currentNavVC = appDelegate?.currentNavigationController
        let navFrame = currentNavVC?.navigationBar.frame
        let navMaxY = navFrame == nil ? 0 : navFrame!.maxY
        
        containerView.backgroundColor = UIColor.clear
        
        toVC.view.frame = CGRect(x: UIScreen.main.bounds.width - 10, y: navMaxY, width: 0, height: 0)
        UIView.animate(withDuration: transitionDuration(using: transitionContext), animations: {
            toVC.view.frame = CGRect(x: UIScreen.main.bounds.width - 110 - 10, y: navMaxY, width: 110, height: 97)
            //
            containerView.backgroundColor = UIColor.black.withAlphaComponent(0.4)
        }) { (finished) in
            transitionContext.completeTransition(!transitionContext.transitionWasCancelled)
        }
    }
    
    @objc func tap(_ tap: UITapGestureRecognizer) {
        self.delegate?.transition(didTapContainerView: self)
    }
    
    func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer, shouldReceive touch: UITouch) -> Bool {
        return gestureRecognizer.view == touch.view
    }
}

class Vip2DismissTransitioning: NSObject, UIViewControllerAnimatedTransitioning {
    func transitionDuration(using transitionContext: UIViewControllerContextTransitioning?) -> TimeInterval {
        return 0.2
    }

    func animateTransition(using transitionContext: UIViewControllerContextTransitioning) {
        let fromVC = transitionContext.viewController(forKey: .from)!
        let containerView = transitionContext.containerView
        
        let appDelegate = UIApplication.shared.delegate as? AppDelegate
        let currentNavVC = appDelegate?.currentNavigationController
        let navFrame = currentNavVC?.navigationBar.frame
        let navMaxY = navFrame == nil ? 0 : navFrame!.maxY
        
        containerView.backgroundColor = UIColor.black.withAlphaComponent(0.4)
        
        fromVC.view.frame = CGRect(x: UIScreen.main.bounds.width - 110 - 10, y: navMaxY, width: 110, height: 97)
        UIView.animate(withDuration: transitionDuration(using: transitionContext), animations: {
            fromVC.view.frame = CGRect(x: UIScreen.main.bounds.width - 10, y: navMaxY, width: 0, height: 0)
            //
            containerView.backgroundColor = UIColor.clear
        }) { (finished) in
            transitionContext.completeTransition(!transitionContext.transitionWasCancelled)
        }
    }
}
