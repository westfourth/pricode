//
//  Vip2VC.swift
//  Sp
//
//  Created by mac on 2020/11/13.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class Vip2VC: UIViewController {
    @IBOutlet weak var avatarButton: UIButton!
    @IBOutlet weak var userNameLabel: UILabel!
    @IBOutlet weak var vipInfoLabel: UILabel!
    @IBOutlet weak var vipLevelButton: UIButton!
    
    @IBOutlet weak var segmentControl: XSIndicatorSegmentedControl!
    @IBOutlet weak var pageView: UIView!
    
    var pageVC: UIPageViewController?
    var items = [Vip2CateVC]()
    
    let popVC = Vip2PopVC()
    var presentTransition = Vip2PresentTransitioning()
    
    //  UI显示
    var uiType: Vip2CateVC.UIType = .vip {
        didSet {
            if isViewLoaded {
                updateHeader()
            }
        }
    }
    
    var account: AccountInfo? {
        didSet {
            updateHeader()
        }
    }
    
    var card: VipCardListResp? {
        didSet {
            updateCard()
        }
    }
    
    var viewWillDisappearClosure: (()->())?
    
    override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: Bundle?) {
        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
        hidesBottomBarWhenPushed = true
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        presentTransition.delegate = self
        
        //  nav
        let imageView = UIImageView(image: UIImage(named: "vip2_charge_title"))
        navigationItem.titleView = imageView
        let rightItem = UIBarButtonItem(image: UIImage(named: "vip2_more"), style: .plain, target: self, action: #selector(clickItem(item:)))
        navigationItem.rightBarButtonItem = rightItem
        
        segmentControl.setTitleTextAttributes([.font: font(16), .foregroundColor: rgb(0xE1B67E)], for: .normal)
        segmentControl.indicatorView.backgroundColor = rgb(0xE1B67E)
        segmentControl.indicatorViewSize = CGSize(width: 34, height: 3)
        
        //
        updateHeader()
        setupPages()
        //
        getAccountInfo()
        getCardList()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.navigationBar.isTranslucent = true
        navigationController?.navigationBar.setBackgroundImage(UIImage(), for: .default)
        navigationController?.navigationBar.shadowImage = UIImage()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        viewWillDisappearClosure?()
    }
    
    deinit {
        viewWillDisappearClosure = nil
    }
    
    func setupPages() {
        for i in 0..<3 {
            let vc = Vip2CateVC()
            vc.delegate = self
            vc.uiType = Vip2CateVC.UIType(rawValue: i)!
            items.append(vc)
        }
        
        let index = uiType.rawValue
        let showVC = items[index]
        
        pageVC = UIPageViewController(transitionStyle: .scroll, navigationOrientation: .horizontal, options: nil)
        pageVC?.setViewControllers([showVC], direction: .forward, animated: false, completion: nil)
        pageVC?.dataSource = self
        pageVC?.delegate = self
        
        pageView.addSubview(pageVC!.view)
        pageVC!.view.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
    }
    
    @IBAction func segmentValueDidChange(_ sender: XSIndicatorSegmentedControl) {
        guard let showVC = pageVC?.viewControllers?.first as? Vip2CateVC else {
            return
        }
        let index = items.firstIndex(of: showVC)!
        let direction: UIPageViewController.NavigationDirection = sender.selectedSegmentIndex > index ? .forward : .reverse
        let nextVC = items[sender.selectedSegmentIndex]
        pageVC?.setViewControllers([nextVC], direction: direction, animated: true, completion: nil)
        //
        uiType = Vip2CateVC.UIType(rawValue: sender.selectedSegmentIndex)!
    }
    
    func updateHeader() {
        segmentControl.selectedSegmentIndex = uiType.rawValue
        vipInfoLabel.text = "開通\(Sensitive.hui)專享更多特權"
        //
        guard let u = NetDefaults.userInfo else { return }
        userNameLabel.text = u.nickName
        let vipLevelImage = UIImage(named: "v\(u.level)")
        vipLevelButton.setImage(vipLevelImage, for: .normal)
        avatarButton.kf.setImage(with: u.logo, for: .normal, placeholder: Sensitive.avatar)
        
        switch uiType {
        case .vip:
            if let date = u.expiredVip {
                let dateFormatter = DateFormatter()
                dateFormatter.dateFormat = "yyyy-MM-dd"
                let dateText = dateFormatter.string(from: date)
                vipInfoLabel.text = "会员到期时间 \(dateText)"
            }
        case .coin:
            if let ac = account {
                vipInfoLabel.text = "剩余金币：\(ac.gold)"
            }
        default:
            if let ac = account {
                vipInfoLabel.text = "剩余金额：\(ac.bala)"
            }
        }
    }
    
    func updateCard() {
        for item in items {
            item.card = self.card
        }
    }
    
    @objc func clickItem(item: UIBarButtonItem) {
        popVC.delegate = self
        popVC.modalPresentationStyle = .custom
        popVC.transitioningDelegate = self
        present(popVC, animated: true, completion: nil)
    }
}

extension Vip2VC: UIViewControllerTransitioningDelegate, Vip2PresentTransitioningDelegate {
    
    func transition(didTapContainerView on: Vip2PresentTransitioning) {
        popVC.dismiss(animated: true, completion: nil)
    }
    
    
    func animationController(forPresented presented: UIViewController, presenting: UIViewController, source: UIViewController) -> UIViewControllerAnimatedTransitioning? {
        return presentTransition
    }
    
    @available(iOS 2.0, *)
    func animationController(forDismissed dismissed: UIViewController) -> UIViewControllerAnimatedTransitioning? {
        return Vip2DismissTransitioning()
    }
}

extension Vip2VC {
    
    //  账户信息
    func getAccountInfo() {
        Session.request(AccountInfoReq()) { [weak self] (error, resp) in
            guard error == nil, let resData = resp as? AccountInfo else { return }
            self?.account = resData
            NetDefaults.accountInfo = resData
            self?.updateBalance()
        }
    }
    
    //  更新余额显示
    func updateBalance() {
        for i in items {
            if i.isViewLoaded {
//                i.tableView.reloadData()
                i.payCollectionView.reloadData()
            }
        }
    }
    
    
    //  卡片信息
    func getCardList() {
        let req =  VipListReq()
        Session.request(req) { [weak self] (error, resp) in
            Alert.hideLoading()
            guard error == nil, let resData = resp as? VipCardListResp  else {
                mm_showToast(error?.localizedDescription ?? "獲取資料失敗！")
                return
            }
            self?.insetWalletPay(card: resData)
            self?.markFirst(card: resData)
            self?.card = resData
        }
    }
    
    //  选中第一张卡片
    func markFirst(card: VipCardListResp) {
        card.goldVipList.first?.selected = true
        card.vipCardList.first?.selected = true
        card.ticketsList.first?.selected = true
        card.meetbarList.first?.selected = true
    }
    
    //  插入钱包支付
    func insetWalletPay(card: VipCardListResp) {
        for item in card.goldVipList {
            //  选中第一个
            item.types.first?.selected = true
            item.types.insert(newPay(), at: 0)
        }
        for item in card.vipCardList {
            item.types.first?.selected = true
            item.types.insert(newPay(), at: 0)
        }
        for item in card.ticketsList {
            item.types.first?.selected = true
            item.types.insert(newPay(), at: 0)
        }
        for item in card.meetbarList {
            item.types.first?.selected = true
            item.types.insert(newPay(), at: 0)
        }
    }
    
    func newPay() -> PayType {
        let pay = PayType()
        pay.name = "钱包"
        return pay
    }
}

extension Vip2VC: UIPageViewControllerDataSource, UIPageViewControllerDelegate {
    
    func pageViewController(_ pageViewController: UIPageViewController, viewControllerBefore viewController: UIViewController) -> UIViewController? {
        var index = items.firstIndex(of: viewController as! Vip2CateVC)!
        index -= 1
        if index < 0 {
            return nil
        }
        return items[index]
    }
    
    func pageViewController(_ pageViewController: UIPageViewController, viewControllerAfter viewController: UIViewController) -> UIViewController? {
        var index = items.firstIndex(of: viewController as! Vip2CateVC)!
        index += 1
        if index >= items.count {
            return nil
        }
        return items[index]
    }
    
    func pageViewController(_ pageViewController: UIPageViewController, didFinishAnimating finished: Bool, previousViewControllers: [UIViewController], transitionCompleted completed: Bool) {
        guard let showVC = pageViewController.viewControllers?.first as? Vip2CateVC else {
            return
        }
        let index = items.firstIndex(of: showVC)
        segmentControl.selectedSegmentIndex = index!
        uiType = Vip2CateVC.UIType(rawValue: index!)!
    }
}
