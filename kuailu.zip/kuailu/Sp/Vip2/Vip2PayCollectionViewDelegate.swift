//
//  Vip2PayCollectionViewDelegate.swift
//  Sp
//
//  Created by mac on 2020/12/24.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class Vip2PayCollectionViewDelegate: NSObject, UICollectionViewDataSource, UICollectionViewDelegate {
    
    weak var payCollectionView: UICollectionView?
    
    var types: [PayType] = [PayType]() {
        didSet {
            payCollectionView?.reloadData()
        }
    }

    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return types.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "ID", for: indexPath) as! Vip2CatePay2Cell
        cell.type = types[indexPath.row]
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        for type in types {
            type.selected = false
        }
        types[indexPath.row].selected = true
        collectionView.reloadData()
    }
}
