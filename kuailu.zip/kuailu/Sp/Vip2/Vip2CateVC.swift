//
//  Vip2CateVC.swift
//  Sp
//
//  Created by mac on 2020/11/13.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class Vip2CateVC: UIViewController {
    //  显示类型
    enum UIType: Int {
        case vip        //  会员
        case coin       //  金币
        case ticket     //  门票
        case bar        //  约吧
    }
    
    //  提示信息类型
    enum InfoType {
        case vip_7          //  周卡
        case vip_30         //  月卡
        case vip_90         //  季卡
        case vip_365        //  年卡
        case vip_9999       //  永久卡
        
        case none
        case yue            //  约炮卡
        case welfare        //  福利门票
        case bar            //  约吧
    }
    
    var uiType: UIType = .vip    //  UI显示
    var infoType: InfoType = .none
    var card: VipCardListResp? {    //
        didSet {
            setupFirst()
            updateSelectedPrice()
            if let vip = card?.vipCardList.first {
                updateInfo(vip: vip)
            }
            if isViewLoaded {
                collectionView.reloadData()
            }
        }
    }
    
    var types: [PayType] = [PayType]() {
        didSet {
            payCollectionViewDelegate.types = types
            if isViewLoaded {
                payCollectionView.reloadData()
            }
        }
    }
    
    var price = 0.0
    
    weak var delegate: Vip2VC?
    //  卡片
    @IBOutlet weak var collectionView: UICollectionView!
    @IBOutlet weak var flowLayout: HorizontalTransformFlowLayout!
    @IBOutlet weak var collectionViewH: NSLayoutConstraint!
    //  支付方式
    @IBOutlet weak var payCollectionView: UICollectionView!
    @IBOutlet weak var payFlowlayout: UICollectionViewFlowLayout!
    @IBOutlet weak var payCollectionViewH: NSLayoutConstraint!
    
//    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var priceLabel: UILabel!
    @IBOutlet weak var payButton: UIButton!
    
    @IBOutlet weak var vipLabel: UILabel?
    @IBOutlet weak var downloadLabel: UILabel?
    @IBOutlet weak var infoImageView: UIImageView?
    
    let payCollectionViewDelegate = Vip2PayCollectionViewDelegate()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        updateLayout(type: uiType)
        updatePayCollectionViewLayout()
        updateSelectedPrice()
        
        var nib = UINib(nibName: "Vip2CateCardCell", bundle: nil)
        collectionView.register(nib, forCellWithReuseIdentifier: "ID")
        collectionView.decelerationRate = .fast
        
        //  payCollectionView
        nib = UINib(nibName: "Vip2CatePay2Cell", bundle: nil)
        payCollectionView.register(nib, forCellWithReuseIdentifier: "ID")
        payCollectionView.dataSource = payCollectionViewDelegate
        payCollectionView.delegate = payCollectionViewDelegate
        payCollectionViewDelegate.payCollectionView = payCollectionView
        
        if uiType == .vip {
            object_setClass(flowLayout, UICollectionViewFlowLayout.self)
        }
    }
    
    //MARK:- update
    
    //  会员专属权/温馨提示
    func updateInfo(type: InfoType) {
        infoType = type
        var imageName = ""
        switch type {
        case .vip_7:
            imageName = "vip2_info_vip_7"
        case .vip_30:
            imageName = "vip2_info_vip_30"
        case .vip_90:
            imageName = "vip2_info_vip_90"
        case .vip_365:
            imageName = "vip2_info_vip_365"
        case .vip_9999:
            imageName = "vip2_info_vip_9999"
        case .none:
            imageName = "vip2_info_none"
        case .yue:
            imageName = "vip2_info_yue"
        case .welfare:
            imageName = "vip2_info_welfare"
        case .bar:
            imageName = "vip2_info_bar"
        }
        let image = UIImage(named: imageName)
        infoImageView?.image = image
    }
    
    //  门票
    func updateInfo(ticket: VipTicketItem) {
        switch ticket.ttype {
        case .specialExpericen:
            updateInfo(type: .yue)
        case .wechatGroup:
            updateInfo(type: .welfare)
        case .meetSex:
            updateInfo(type: .yue)
        }
    }
    
    //  会员
    func updateInfo(vip: VipCardItem) {
        switch vip.vipNumber {
        case 7:
            updateInfo(type: .vip_7)
        case 90:
            updateInfo(type: .vip_90)
        case 365:
            updateInfo(type: .vip_365)
        case 9999:
            updateInfo(type: .vip_9999)
        default:
            updateInfo(type: .vip_30)
        }
        // 下载次数
        updateDownloadNum(vip: vip)
    }
        
    //  默认选中第一张卡片
    func setupFirst() {
        switch uiType {
        case .vip:
            if let t = card?.vipCardList.first?.types {
                types = t
            }
        case .coin:
            if let t = card?.goldVipList.first?.types {
                types = t
            }
        case .ticket:
            if let t = card?.ticketsList.first?.types {
                types = t
            }
        case .bar:
            if let t = card?.meetbarList.first?.types {
                types = t
            }
        }
    }
    
    //  更新支付金额
    func updateSelectedPrice() {
        switch uiType {
        case .vip:
            if let item = card?.vipCardList.filter({ (item) -> Bool in
                return item.selected
            }).first {
                price = item.disPrice == 0 ? item.price : item.disPrice
            }
        case .coin:
            if let item = card?.goldVipList.filter({ (item) -> Bool in
                return item.selected
            }).first {
                price = item.price
            }
        case .ticket:
            if let item = card?.ticketsList.filter({ (item) -> Bool in
                return item.selected
            }).first {
                price = item.disPrice == 0 ? item.price : item.disPrice
            }
        case .bar:
            if let item = card?.meetbarList.filter({ (item) -> Bool in
                return item.selected
            }).first {
                price = item.disPrice == 0 ? item.price : item.disPrice
            }
        }
        let priceText = Int(price)
        let text = "¥\(priceText)元"
        //
        if isViewLoaded {
            priceLabel.text = text
        }
    }
    
    // 更新下载次数
    func updateDownloadNum(vip: VipCardItem) {
        let attr0: [NSAttributedString.Key : Any] = [.foregroundColor: rgb(0xFF3687), .font: font(16, .medium)]
        let attr1: [NSAttributedString.Key : Any] = [.foregroundColor: rgb(0xFFFFFF), .font: font(16, .medium)]
        
        let attrText = NSMutableAttributedString(string: "购买此会员卡，每天可缓存视频", attributes: attr0)
        attrText.append(NSAttributedString(string: String(vip.downloadNum), attributes: attr1))
        attrText.append(NSAttributedString(string: "部", attributes: attr0))
        downloadLabel?.attributedText = attrText
    }
    
    //  购买
    @IBAction func purchase() {
        let rechType = getRechType()
        let balance = NetDefaults.accountInfo?.bala
        if rechType == 0 && balance != nil && balance! < price {
            mm_showToast("\(Sensitive.yu)不足哦！")
            return
        }
        Alert.showLoading(parentView: UIApplication.shared.keyWindow!)
        let req = PurchaseProductReq()
        req.rechType = rechType
        req.money = String(Int(price))
        let (purType, targetId) = getCard()
        req.purType = purType
        req.targetId = targetId
        Session.request(req) { [weak self] (error, resp) in
            Alert.hideLoading()
            guard error == nil else {
                mm_showToast(error!.localizedDescription, type: .failed)
                return
            }
            if rechType == 0 {  //  余额购买
                mm_showToast("恭喜你，\(Sensitive.gou)成功！", type: .succeed)
                self?.delegate?.getAccountInfo()
            } else {
                guard let link = resp as? PayLink, let url = link.url, InnerIntercept.canOpenURL(url) else {
                    mm_showToast("\(Sensitive.gou)失败！", type: .failed)
                    return
                }
                InnerIntercept.open(url)
            }
        }
    }
    
    //  确定充值类型
    func getRechType() -> Int {
        var rechType: Int = 0
        guard let item = types.filter({ (item) -> Bool in
            return item.selected
        }).first else {
            return 0
        }
        switch item.payMent {
        case .alipay:
            rechType = 1
        case .wechat:
            rechType = 2
        case .union:
            rechType = 3
        default:
            break
        }
        return rechType
    }
    
    //  确定卡类型、卡ID
    func getCard() -> (Int, Int) {
        var result: (Int, Int) = (0, 0)
        switch uiType {
        case .vip:
            if let item = card?.vipCardList.filter({ (item) -> Bool in
                return item.selected
            }).first {
                result = (2, item.cardId)
            }
        case .coin:
            if let item = card?.goldVipList.filter({ (item) -> Bool in
                return item.selected
            }).first {
                result = (3, item.goldId)
            }
        case .ticket:
            if let item = card?.ticketsList.filter({ (item) -> Bool in
                return item.selected
            }).first {
                result = (12, item.tid)
            }
        case .bar:
            if let item = card?.meetbarList.filter({ (item) -> Bool in
                return item.selected
            }).first {
                result = (18, item.cardId)
            }
        }
        return result
    }
}

//  flowLayout布局
extension Vip2CateVC {
    
    func updateLayout(type: UIType) {
        switch type {
        case .vip:
            updateVipLayout()
            updateInfo(type: .none)
        case .coin:
            updateCoinLayout()
            updateInfo(type: .none)
        case .ticket:
            updateTicketLayout()
            updateInfo(type: .yue)
        case .bar:
            updateBarLayout()
            updateInfo(type: .bar)
        }
        //
        let hidden = type != .vip
        vipLabel?.isHidden = hidden
        downloadLabel?.isHidden = hidden
    }
    
    func updateVipLayout() {
        let height: CGFloat = 116;
        collectionViewH.constant = height + 16
        flowLayout.scrollDirection = .horizontal
        flowLayout.itemSize = CGSize(width: 108, height: height)
        let gap: CGFloat = 12
        flowLayout.sectionInset = UIEdgeInsets(top: 0, left: gap, bottom: 0, right: gap)
    }
    
    func updateCoinLayout() {
        flowLayout.scrollDirection = .vertical
        let width = (UIScreen.main.bounds.width - 12 * 3) / 2
        flowLayout.itemSize = CGSize(width: width, height: 80 / 166 * width)
        flowLayout.sectionInset = UIEdgeInsets(top: 7, left: 12, bottom: 7, right: 12)
        collectionViewH.constant = flowLayout.itemSize.height * 2 + 10 + 16
    }
    
    func updateTicketLayout() {
        let height: CGFloat = 174;
        collectionViewH.constant = height + 16
        flowLayout.scrollDirection = .horizontal
        flowLayout.itemSize = CGSize(width: height * 804 / 462, height: height)
        let gap = (UIScreen.main.bounds.width - flowLayout.itemSize.width) / 2
        flowLayout.sectionInset = UIEdgeInsets(top: 0, left: gap, bottom: 0, right: gap)
    }
    
    func updateBarLayout() {
        let height: CGFloat = 174;
        collectionViewH.constant = height + 16
        flowLayout.scrollDirection = .horizontal
        flowLayout.itemSize = CGSize(width: height * 804 / 462, height: height)
        let gap = (UIScreen.main.bounds.width - flowLayout.itemSize.width) / 2
        flowLayout.sectionInset = UIEdgeInsets(top: 0, left: gap, bottom: 0, right: gap)
    }
}

//  payCollectionView布局
extension Vip2CateVC {
    func updatePayCollectionViewLayout() {
        var width: CGFloat = (view.width - 12 * 2 - 8) / 2;
        width -= 20;
        payFlowlayout.itemSize = CGSize(width: width, height: width * 46 / 188)
    }
}

extension Vip2CateVC: UICollectionViewDataSource, UICollectionViewDelegate {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        guard card != nil else { return 0 }
        switch uiType {
        case .vip:
            return card!.vipCardList.count
        case .coin:
            return card!.goldVipList.count
        case .ticket:
            return card!.ticketsList.count
        case .bar:
            return card!.meetbarList.count
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "ID", for: indexPath) as! Vip2CateCardCell
        guard card != nil else { return cell }
        switch uiType {
        case .vip:
            cell.item = card!.vipCardList[indexPath.item]
        case .coin:
            cell.item = card!.goldVipList[indexPath.item]
        case .ticket:
            cell.item = card!.ticketsList[indexPath.item]
        case .bar:
            cell.item = card!.meetbarList[indexPath.item]
        }
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        guard card != nil else { return }
        switch uiType {
        case .vip:
            for item in card!.vipCardList {
                item.selected = false
            }
            card!.vipCardList[indexPath.item].selected = true
            types = card!.vipCardList[indexPath.item].types
            //  更新提示信息
            let vip = card!.vipCardList[indexPath.item]
            updateInfo(vip: vip)
        case .coin:
            for item in card!.goldVipList {
                item.selected = false
            }
            card!.goldVipList[indexPath.item].selected = true
            types = card!.goldVipList[indexPath.item].types
        case .ticket:
            for item in card!.ticketsList {
                item.selected = false
            }
            card!.ticketsList[indexPath.item].selected = true
            types = card!.ticketsList[indexPath.item].types
            //  更新提示信息
            let ticket = card!.ticketsList[indexPath.item]
            updateInfo(ticket: ticket)
        case .bar:
            for item in card!.meetbarList {
                item.selected = false
            }
            card!.meetbarList[indexPath.item].selected = true
            types = card!.meetbarList[indexPath.item].types
        }
        collectionView.scrollToItem(at: indexPath, at: .centeredHorizontally, animated: true)
        collectionView.reloadData()
        updateSelectedPrice()
    }
    
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        guard scrollView == collectionView else { return }
        guard uiType != .vip else { return }
        let cells = collectionView.visibleCells
        var destCell: UICollectionViewCell!
        for cell in cells {
            let rect = cell.superview!.convert(cell.frame, to: self.view)
            if rect.minX > 0 && rect.maxX < self.view.bounds.width {
                destCell = cell
                break;
            }
        }
        let destIndexPath = collectionView.indexPath(for: destCell)
        if destIndexPath != nil {
            collectionView(collectionView, didSelectItemAt: destIndexPath!)
        }
    }
}
