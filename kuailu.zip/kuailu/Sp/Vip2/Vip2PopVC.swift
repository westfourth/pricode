//
//  Vip2PopVC.swift
//  Sp
//
//  Created by mac on 2020/11/16.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class Vip2PopVC: UIViewController {
    weak var delegate: Vip2VC?

    override func viewDidLoad() {
        super.viewDidLoad()

    }

    @IBAction func tapRecord(_ sender: UITapGestureRecognizer) {
        dismiss(animated: true) {
            let vc = VipRecordListVC()
            self.delegate?.navigationController?.pushViewController(vc, animated: true)
        }
    }
    
    @IBAction func tapVip(_ sender: UITapGestureRecognizer) {
        dismiss(animated: true) {
            let vc = ExchangeVC()
            self.delegate?.navigationController?.pushViewController(vc, animated: true)
        }
    }
}
