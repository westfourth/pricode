//
//  Vip2CateCardCell.swift
//  Sp
//
//  Created by mac on 2020/11/13.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class Vip2CateCardCell: UICollectionViewCell {
    @IBOutlet weak var icon: UIImageView!
    @IBOutlet weak var select: UIImageView!
    @IBOutlet weak var discount: UIImageView!
    
    @IBOutlet weak var monthLabel: UILabel!
    @IBOutlet weak var priceLabel: UILabel!
    @IBOutlet weak var originalPriceLabel: UILabel!
    
    
    var item: AnyObject? {
        didSet {
            isVIP = item is VipCardItem
            //
            if item is VipCardItem {
                update(item as! VipCardItem)
                updateOnVIP(item as! VipCardItem)
            } else if item is GoldCardVipItem {
                update(item as! GoldCardVipItem)
            } else if item is VipTicketItem {
                update(item as! VipTicketItem)
            } else if item is VipAppointmentItem {
                update(item as! VipAppointmentItem)
            }
        }
    }
    
    var isVIP = false {
        didSet {
            monthLabel.isHidden = !isVIP
            priceLabel.isHidden = !isVIP
            originalPriceLabel.isHidden = !isVIP
            backgroundColor = isVIP ? rgb(0x323232) : UIColor.clear
        }
    }
    
    func updateOnVIP(_ item: VipCardItem) {
        //
        monthLabel.text = item.cardName
        //
        let attrText = NSMutableAttributedString(string: "¥", attributes: [.font: font(12), .foregroundColor: rgb(0xFF9C2B)])
        let price = Int(item.disPrice)
        attrText.append(NSAttributedString(string: String(price), attributes: [.font: font(33, .medium), .foregroundColor: rgb(0xFF9C2B)]))
        priceLabel.attributedText = attrText
        //
        originalPriceLabel.text = item.desc
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    func update(_ item: VipCardItem) {
        contentView.layer.cornerRadius = 12
        select.isHidden = !item.selected
//        if [9999, 365, 90, 60, 30, 7].contains(item.vipNumber) {
//            let image = Vip2CateCardCell.vipImage(with: item.vipNumber)
//            let attrText = Vip2CateCardCell.vipAttrText(item)
//            let image2 = Vip2CateCardCell.draw(attrText: attrText, on: image)
//            icon.image = image2
//        } else {
//            icon.kf.setImage(with: item.imagePath)
//        }
        discount.isHidden = !item.isDeduct
    }
    
    func update(_ item: GoldCardVipItem) {
        contentView.layer.cornerRadius = 6
        select.isHidden = !item.selected
        icon.image = Vip2CateCardCell.coinImage(with: Int(item.price))
    }
    
    func update(_ item: VipTicketItem) {
        contentView.layer.cornerRadius = 12
//        select.isHidden = !item.selected
        icon.kf.setImage(with: item.imagePath)
    }
    
    func update(_ item: VipAppointmentItem) {
        contentView.layer.cornerRadius = 12
//        select.isHidden = !item.selected
        icon.kf.setImage(with: item.imagePath)
    }
}


extension Vip2CateCardCell {
    //  金币
    class func coinImage(with price: Int) -> UIImage {
        let name = "vip2_coin_\(price)"
        return UIImage(named: name)!
    }
    
    //  会员
    class func vipImage(with day: Int) -> UIImage {
        let name = "vip2_card_\(day)"
        return UIImage(named: name)!
    }
    
    //  会员卡文字颜色
    class func vipTextColor(with day: Int) -> UIColor {
        let name = "vip2_color_\(day)"
        return UIColor(named: name)!
    }
    
    //  生成属性文字
    class func vipAttrText(_ item: VipCardItem) -> NSMutableAttributedString {
        let color = vipTextColor(with: item.vipNumber)
        let attrText = NSMutableAttributedString()
        
        let fontB1 = font(40, .semibold)
        let fontB2 = font(80, .semibold)
        let font1 = font(46)
        let font2 = font(40)
        
        let a1 = NSAttributedString(string: "¥", attributes: [.font: fontB1])
        let s1 = NSAttributedString(string: " ", attributes: [.font: fontB1])
        let a2 = NSAttributedString(string: String(Int(item.disPrice)), attributes: [.font: fontB2])
        let s2 = NSAttributedString(string: "  ", attributes: [.font: fontB1])
        let a3 = NSAttributedString(string: "原价", attributes: [.font: font1])
        let a4 = NSAttributedString(string: String(Int(item.price)), attributes: [.font: font2, .strikethroughStyle: 1])
        
        attrText.append(a1)
        attrText.append(s1)
        attrText.append(a2)
        attrText.append(s2)
        attrText.append(a3)
        attrText.append(a4)
        attrText.addAttributes([.foregroundColor: color], range: NSMakeRange(0, attrText.length))
        
        return attrText
    }
    
    class func draw(attrText: NSAttributedString, on image: UIImage) -> UIImage {
        let point = CGPoint(x: 70, y: 294)
        let size = CGSize(width: 804, height: 462)
        UIGraphicsBeginImageContext(size)
        
        image.draw(in: CGRect(origin: .zero, size: size))
        attrText.draw(at: point)
        
        let image2 = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        return image2!
    }
}
