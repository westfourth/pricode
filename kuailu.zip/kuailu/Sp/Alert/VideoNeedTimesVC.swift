//
//  VideoNeedTimesVC.swift
//  Sp
//
//  Created by mac on 2020/4/3.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

/// 获取观看次数
@IBDesignable
class VideoNeedTimesVC: UIViewController, UIGestureRecognizerDelegate {
    
    public var shortVideoModel: ShortVideoModel?
    @IBOutlet weak var discountImageView: UIImageView!
    
    override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: Bundle?) {
        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
        self.modalPresentationStyle = .overFullScreen
        self.modalTransitionStyle = .crossDissolve
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
    @IBOutlet weak var vip: UIButton!
    @IBOutlet weak var share: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        object_setClass(vip.layer, CAGradientLayer.self)
        let i = vip.layer as! CAGradientLayer
        i.colors = [RGB(0xffFEAB13).cgColor,RGB(0xffF28217).cgColor,RGB(0xffFE6000).cgColor,
                    RGB(0xffFC9239).cgColor]
        i.startPoint = CGPoint(x: 0, y: 0)
        i.endPoint = CGPoint(x: 1, y: 0)
        
        share.layer.borderWidth = 1.0
        share.layer.borderColor = rgb(0xffFF9A03).cgColor
        
        getChargeLimitDiscounts()
    }
    
    func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer, shouldReceive touch: UITouch) -> Bool {
        return gestureRecognizer.view == touch.view
    }
    
    @IBAction func tapDismiss(_ sender: UITapGestureRecognizer) {
        dismiss(animated: true, completion: nil)
    }
    
    // 去分享
    @IBAction func clickCharge(_ sender: UIButton) {
        dismiss(animated: true) { [weak self] in
            let VC = ShareVideoVC()
            VC.video = self?.shortVideoModel?.videoItem
            VC.hidesBottomBarWhenPushed = true
            let navVC = (UIApplication.shared.delegate as? AppDelegate)?.currentNavigationController
            navVC?.pushViewController(VC, animated: true)
        }
    }
    
    // 充值VIP
    @IBAction func clickShare(_ sender: UIButton) {
        dismiss(animated: true) {
            let navVC = (UIApplication.shared.delegate as? AppDelegate)?.currentNavigationController
            VipChargeTipVC.isFromVideoPlayList = true
            navVC?.pushViewController(Vip2VC(), animated: true)
        }
    }
    
    //  限时折扣
    func getChargeLimitDiscounts() {
        let req = ChargeLimitDiscountsReq()
        Session.request(req){(erorr, resp) in
            guard erorr == nil, let res = resp as? ChargeLimitDiscounts else {
                self.discountImageView.isHidden = true
                return
            }
            
        }
    }
}
