//
//  ShareActionVC.swift
//  Sp
//
//  Created by mac on 2020/12/25.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class ShareActionVC: UIViewController {
    var transtioner:ModalTransitionManager!
    
    @IBOutlet weak var downloadButton: UIButton!
    @IBOutlet weak var downloadLabel: UILabel!
    
    var videoItem: VideoItem? {
        didSet {
            guard videoItem != nil else { return }

            //
            videoItem!.m3u8Item.progress = {[weak self] (received, expectedToReceive) -> Void in
                let progressText = String(format: "%.2f%%", (Float(received) / Float(expectedToReceive)) * 100)
                self?.downloadLabel.text = progressText
            }
            videoItem!.m3u8Item.completion = {[weak self] (error, String) -> Void in
                self?.updateUI()
            }
        }
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        transtioner = ModalTransitionManager(viewController: self, height: 150)
        updateUI()
    }
    
    func updateUI() {
        var image: UIImage? = UIImage(named: "sv2_download")
        if videoItem?.m3u8Item.status == .downloading {
            image = UIImage(named: "sv2_suspend")
        } else if videoItem?.m3u8Item.status == .downloaded {
            image = UIImage(named: "sv2_complete")
        }
        downloadButton.setImage(image, for: .normal)
        //
        if videoItem?.m3u8Item.status == .downloaded {
            downloadLabel.text = "已下载"
            downloadButton.isEnabled = false
        }
    }

    @IBAction func click(close: UIButton) {
        dismiss(animated: true, completion: nil)
    }
    
    @IBAction func click(share: UIButton) {
        guard let navVC = (UIApplication.shared.delegate as? AppDelegate)?.currentNavigationController else { return }
        
        dismiss(animated: true) { [weak self] in
            let vc = ShareVideoVC()
            vc.hidesBottomBarWhenPushed = true
            vc.video = self?.videoItem
            navVC.pushViewController(vc, animated: true)
        }
    }
    
    @IBAction func click(download: UIButton) {
        guard let videoItem = videoItem else { return }
        
        if !Downloader.hasVidelModel(video: videoItem) {
            PlayerAlert.alert(vc: self, item: videoItem) { (canDownload) in
                guard canDownload == true else { return }
                //  添加到缓存中
                Downloader.addVidelModel(video: videoItem)
                //  开始下载
                let item = videoItem.m3u8Item
                if item.status != .downloading {
                    item.download()
                } else {
                    item.cancel()
                }
                //  更新UI
                self.updateUI()
            }
        } else {
            //  开始下载
            let item = videoItem.m3u8Item
            if item.status != .downloading {
                item.download()
            } else {
                item.cancel()
            }
            //  更新UI
            self.updateUI()
        }
    }
}
