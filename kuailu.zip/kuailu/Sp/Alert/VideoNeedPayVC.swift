//
//  VideoNeedPayVC.swift
//  Sp
//
//  Created by mac on 2020/4/3.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

/// 确认支付
@IBDesignable
class VideoNeedPayVC: UIViewController {
    
    public weak var delegate: UIViewController?
    private var exchangeConfigResp: VideoExchangeConfigResp?
    
    @IBOutlet weak var priceLabel: UILabel!
    @IBOutlet weak var balanceLabel: UILabel!
    
    @IBOutlet weak var noneed: UIButton!
    @IBOutlet weak var pay: UIButton!
    
    override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: Bundle?) {
        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
        self.modalPresentationStyle = .overFullScreen
        self.modalTransitionStyle = .crossDissolve
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
    @IBAction func tapDismiss(_ sender: UITapGestureRecognizer) {
        dismiss(animated: true, completion: nil)
    }
    
    public var shortVideoModel: ShortVideoModel? {
        didSet {
            guard let model = shortVideoModel,let item = model.videoItem else {
                return
            }
            
            let attri  = NSMutableAttributedString(string: "\(item.price)金币", attributes: [NSAttributedString.Key.foregroundColor :rgb(0xffE52400)])
            
            attri.addAttributes([NSAttributedString.Key.font : UIFont.systemFont(ofSize: 36, weight: .medium)], range: NSRange(location: 0, length: "\(item.price)".count))
            
            attri.addAttributes([NSAttributedString.Key.font : UIFont.systemFont(ofSize: 18, weight: .medium)], range: NSRange(location: attri.string.count - 2, length: 2))
            
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
                self.priceLabel.attributedText = attri
            }
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        loadData()
        
        object_setClass(pay.layer, CAGradientLayer.self)
        let i = pay.layer as! CAGradientLayer
        i.colors = [RGB(0xffFEAB13).cgColor,RGB(0xffF28217).cgColor,RGB(0xffFE6000).cgColor,
                    RGB(0xffFC9239).cgColor]
        i.startPoint = CGPoint(x: 0, y: 0)
        i.endPoint = CGPoint(x: 1, y: 0)
        
        noneed.layer.borderWidth = 1.0
        noneed.layer.borderColor = rgb(0xffFF9A03).cgColor
        
    }
    
    @IBAction func click(think: UIButton) {
        dismiss(animated: true, completion: nil)
    }
    
    @IBAction func click(pay: UIButton) {
        guard let item = shortVideoModel?.videoItem,
            let configResp = self.exchangeConfigResp else {
            return
        }
        let enough = Int(configResp.gold) >= item.price
        
        
        if enough {     // 餘額足夠
            self.buyVideo()
        } else {        //  餘額不足
            dismiss(animated: true) {
                VipChargeTipVC.isFromVideoPlayList = true
                let vc = Vip2VC()
                vc.uiType = .coin
                let navVC = (UIApplication.shared.delegate as? AppDelegate)?.currentNavigationController
                navVC?.pushViewController(vc, animated: true)
            }
        }
    }
    
    //_______________________________________________________________________________________________________________
    // MARK: -

    //  获取数据
    func loadData() {
        guard let item = shortVideoModel?.videoItem else {
            return
        }
        let req = VideoExchangeConfigReq()
        req.videoId = item.videoId
        Session.request(req) {[weak self] (error, resp) in
            guard error == nil else {
                mm_showToast(error!.localizedDescription)
                return
            }
            let configResp = resp as! VideoExchangeConfigResp
            self?.exchangeConfigResp = configResp
            self?.balanceLabel.text = "我的金币：\(configResp.gold)"
            //
            let enough = Int(configResp.gold) >= item.price
            if !enough {
                self?.pay.setTitle("购买金币", for: .normal)
            }
        }
    }
    
    //  购买视频
    func buyVideo() {
        guard let item = shortVideoModel?.videoItem,
            let configResp = self.exchangeConfigResp else {
            return
        }
        
        let req = BuyVideoReq()
        req.videoId = item.videoId
        req.ticketDeductNum = configResp.ticketDeductNum
        
        Alert.showLoading(parentView: self.view)
        Session.request(req) {[weak self] (error, resp) in
            Alert.hideLoading()
            guard error == nil else {
                mm_showToast(error!.localizedDescription)
                return
            }
            //  标记为可以观看
            self?.shortVideoModel?.responseWatchType = .canWatch
            /// 标记观看类型为金币观看 （统计要用到）
            self?.shortVideoModel?.watchType = .coin
            //
            self?.dismiss(animated: true) {
                mm_showToast("\(Sensitive.gou)成功!", type: .succeed)
                //金币观看
                self?.shortVideoModel?.watchType = .coin
                //  购买成功后播放。调用viewDidAppear方式很糟糕，但这样处理最简单。
                self?.delegate?.viewDidAppear(false)
            }
        }
    }
}
