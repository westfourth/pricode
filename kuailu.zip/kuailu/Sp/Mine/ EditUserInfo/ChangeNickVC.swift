//
//  ChangeNickVC.swift
//  Sp
//
//  Created by mac on 2020/2/27.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

protocol ChangeNickVCDelegate: NSObjectProtocol {
    
    func updateNickname(nickname: String)
    
}

class ChangeNickVC: UIViewController,UITextFieldDelegate {
    
    @IBOutlet weak var input: UITextField!
    @IBOutlet weak var limit: UILabel!
    
    private let maxKeyWordsLen: Int = 10
    
    weak var delegate: ChangeNickVCDelegate?
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.navigationBar.setBackgroundImage(UIImage(named: "navi_backImage"), for: UIBarMetrics.default)
        self.navigationController?.navigationBar.shadowImage = UIImage()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        self.input.becomeFirstResponder()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.title = "修改暱稱"
        view.backgroundColor = RGB(0xff141516)
        self.navigationItem.rightBarButtonItem = UIBarButtonItem(customView: self.save)
        self.input.addTarget(self, action: #selector(didChangeAction), for: UIControl.Event.editingChanged)
        if let user = NetDefaults.userInfo {
            self.input.text = user.nickName
        }
        let length:Int = self.input.text?.count ?? 0
        self.limit.text = "\(length)/\(maxKeyWordsLen)"
        self.save.isEnabled = false
    }
    
    @objc func didChangeAction() {
        self.save.isEnabled = self.input.text?.count != 0
        let length:Int = self.input.text?.count ?? 0
        self.limit.text = "\(length)/\(maxKeyWordsLen)"
    }
    
    lazy var save : UIButton = {
        let button = UIButton()
        button.setTitle("保存", for: UIControl.State.normal)
        button.setTitleColor(RGB(0xFA6400), for: UIControl.State.normal)
        button.setTitleColor(RGB(33,36,48), for: UIControl.State.disabled)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 14, weight: UIFont.Weight.medium)
        button.frame = CGRect(x: 0, y: 0, width: 28, height: 20)
        button.addTarget(self, action: #selector(saveAction), for: .touchUpInside)
        return button
    }()
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        if string.count == 0 {
            return true
        }
        guard let existedLength = textField.text?.count else { return false }
        let selectedLength = range.length;
        let replaceLength = string.count;
        if (existedLength - selectedLength + replaceLength > maxKeyWordsLen){
            return false
        }
        return true
    }
    
    @objc func saveAction() {
        
        view.endEditing(true)
        
        guard let val = input.text?.trimmingCharacters(in: .whitespacesAndNewlines), !val.isEmpty else {
            input.text = ""
            return
        }
        guard val.count <= maxKeyWordsLen else {
            mm_showToast("暱稱不得大於\(maxKeyWordsLen)個字符")
            return
        }
        input.resignFirstResponder()
        delegate?.updateNickname(nickname: val)
        navigationController?.popViewController(animated: true)
    }
}
