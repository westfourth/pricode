//
//  ChangeIntroductionVC.swift
//  Sp
//
//  Created by mac on 2020/2/27.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

protocol ChangeIntroductionVCDelegate: NSObjectProtocol {
    
    func updateIntro(intro: String)
    
}

class ChangeIntroductionVC: UIViewController {
    
    @IBOutlet weak var input: UITextView!
    
    private let maxKeyWordsLen: Int = 30
    
    weak var delegate: ChangeIntroductionVCDelegate?
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.navigationBar.setBackgroundImage(UIImage(named: "navi_backImage"), for: UIBarMetrics.default)
        self.navigationController?.navigationBar.shadowImage = UIImage()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        self.input.becomeFirstResponder()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.title = "修改簡介"
        view.backgroundColor = RGB(0xff141516)
        
        navigationItem.rightBarButtonItem = UIBarButtonItem(customView: save)
        
        input.addDoneOnKeyboardWithTarget(self, action: #selector(saveAction))
        input.returnKeyType = .done
        
        if let user = NetDefaults.userInfo {
            self.input.text = user.personSign
        }
        self.save.isEnabled = false
        
        self.input.addSubview(place)
        place.snp.makeConstraints { (make) in
            make.left.equalTo(6)
            make.top.equalTo(10)
        }
        self.place.isHidden = true
        
    }
    
    lazy var save : UIButton = {
        let button = UIButton()
        button.setTitle("保存", for: UIControl.State.normal)
        button.setTitleColor(RGB(0xFA6400), for: UIControl.State.normal)
        button.setTitleColor(RGB(33,36,48), for: UIControl.State.disabled)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 14, weight: UIFont.Weight.medium)
        button.frame = CGRect(x: 0, y: 0, width: 28, height: 20)
        button.addTarget(self, action: #selector(saveAction), for: .touchUpInside)
        return button
    }()
    
    lazy var place:UILabel  = {
        let place = UILabel()
        place.text = "請填寫個人簡介，讓更多人關注你"
        place.font = UIFont.boldSystemFont(ofSize: 14)
        place.textColor = UIColor.lightGray
        return place
    }()
    
    @objc func saveAction() {
        self.view.endEditing(true)
        
        guard let val = input.text?.trimmingCharacters(in: .whitespacesAndNewlines), !val.isEmpty else {
            input.text = ""
            return
        }
        guard val.count <= maxKeyWordsLen else {
            mm_showToast("個人簡介不得大於\(maxKeyWordsLen)個字符")
            return
        }
        input.resignFirstResponder()
        delegate?.updateIntro(intro: val)
        navigationController?.popViewController(animated: true)
    }
}

extension ChangeIntroductionVC: UITextViewDelegate {
    
    func textView(_ textView: UITextView, shouldChangeTextIn range: NSRange, replacementText text: String) -> Bool {
        guard text != "\n" else {
            saveAction()
            return false
        }
        let textStr = input.text ?? ""
        let len = textStr.count + text.count - range.length
        guard len <= maxKeyWordsLen else {
            return false
        }
        return true
    }
    
    func textViewDidChange(_ textView: UITextView) {
        if let user = NetDefaults.userInfo {
            if textView.text == "" {
                self.save.isEnabled = false
            } else {
                self.save.isEnabled = user.personSign  != textView.text
            }
        } else {
            self.save.isEnabled = textView.text !=  ""
        }
        self.place.isHidden = textView.text.count != 0
    }
}

