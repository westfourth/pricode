//
//  EditUserSexActionSheet.swift
//  Sp
//
//  Created by mac on 2020/6/18.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

protocol EditUserSexActionSheetDelegate: NSObjectProtocol {
    
    func chosenSex(sexType: SexType)
    
}

class EditUserSexActionSheet: UIView {
    
    private static let sheetHeight: CGFloat = 50 + (IS_IPHONEX ? 20 : 0)
    
    private static let splitLineHeight: CGFloat = 0.5
    
    private static let actionSheetMarginBottom: CGFloat = 10
    
    private static let maleImg: UIImage? = {
        return UIImage(named: "sex_male")
    }()
    
    private static let femaleImg: UIImage? = {
        return UIImage(named: "sex_female")
    }()
    
    private static let actionSheetViewHeight: CGFloat = EditUserSexActionSheet.sheetHeight * 3 + EditUserSexActionSheet.actionSheetMarginBottom
    
    private lazy var maleBtn: UIButton = {
        let btn = UIButton()
        btn.setTitle("男", for: .normal)
        btn.setTitleColor(RGB(0x363636), for: .normal)
        btn.titleLabel?.font = UIFont.pingFangRegular(18)
        btn.setImage(EditUserSexActionSheet.maleImg, for: .normal)
        btn.imagePosition(imageStyle: .left, spacing: 8)
        btn.addTarget(self, action: #selector(onMaleBtnTap), for: .touchUpInside)
        return btn
    }()
    
    private lazy var femaleBtn: UIButton = {
        let btn = UIButton()
        btn.setTitle("女", for: .normal)
        btn.setTitleColor(RGB(0x363636), for: .normal)
        btn.titleLabel?.font = UIFont.pingFangRegular(18)
        btn.setImage(EditUserSexActionSheet.femaleImg, for: .normal)
        btn.imagePosition(imageStyle: .left, spacing: 8)
        btn.addTarget(self, action: #selector(onFemaleBtnTap), for: .touchUpInside)
        return btn
    }()
    
    private lazy var secrectBtn: UIButton = {
        let btn = UIButton()
        btn.setTitle("保密", for: .normal)
        btn.setTitleColor(RGB(0x363636), for: .normal)
        btn.titleLabel?.font = UIFont.pingFangRegular(18)
        btn.addTarget(self, action: #selector(onSecrectBtnTap), for: .touchUpInside)
        return btn
    }()
    
    private lazy var firstSplitLine: UIView = {
        let view = UIView()
        view.backgroundColor = RGB(0x979797)
        return view
    }()
    
    private lazy var secondSplitLine: UIView = {
        let view = UIView()
        view.backgroundColor = RGB(0x979797)
        return view
    }()
    
    private lazy var actionSheetView: UIView = {
        let view = UIView()
        view.backgroundColor = .white
        view.layer.cornerRadius = 10
        view.layer.masksToBounds = true
        view.addSubview(maleBtn)
        view.addSubview(firstSplitLine)
        view.addSubview(femaleBtn)
        view.addSubview(secondSplitLine)
        view.addSubview(secrectBtn)
        
        maleBtn.snp.makeConstraints { (make) in
            make.top.left.right.equalToSuperview()
            make.height.equalTo(EditUserSexActionSheet.sheetHeight)
        }
        
        firstSplitLine.snp.makeConstraints { (make) in
            make.top.equalTo(maleBtn.snp.bottom)
            make.left.right.equalToSuperview().inset(8)
            make.height.equalTo(EditUserSexActionSheet.splitLineHeight)
        }
        
        femaleBtn.snp.makeConstraints { (make) in
            make.top.equalTo(firstSplitLine.snp.bottom)
            make.left.right.equalToSuperview()
            make.height.equalTo(EditUserSexActionSheet.sheetHeight)
        }
        
        secondSplitLine.snp.makeConstraints { (make) in
            make.top.equalTo(femaleBtn.snp.bottom)
            make.left.right.equalToSuperview().inset(8)
            make.height.equalTo(EditUserSexActionSheet.splitLineHeight)
        }
        
        secrectBtn.snp.makeConstraints { (make) in
            make.top.equalTo(secondSplitLine.snp.bottom)
            make.left.right.equalToSuperview()
            make.height.equalTo(EditUserSexActionSheet.sheetHeight)
        }
        
        return view
    }()
    
    weak var delegate: EditUserSexActionSheetDelegate?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        alpha = 0
        backgroundColor = UIColor.black.withAlphaComponent(0.3)
        let tap = UITapGestureRecognizer(target: self, action: #selector(onMaskViewTap))
        isUserInteractionEnabled = true
        addGestureRecognizer(tap)
        addSubview(actionSheetView)
        
        actionSheetView.snp.makeConstraints { (make) in
            make.height.equalTo(EditUserSexActionSheet.actionSheetViewHeight)
            make.left.right.equalToSuperview()
            make.bottom.equalToSuperview().inset(-EditUserSexActionSheet.actionSheetViewHeight)
        }
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    @objc private func onMaleBtnTap() {
        delegate?.chosenSex(sexType: .male)
        stopAnimation()
    }
    
    @objc private func onFemaleBtnTap() {
        delegate?.chosenSex(sexType: .female)
        stopAnimation()
    }
    
    @objc private func onSecrectBtnTap() {
        delegate?.chosenSex(sexType: .secrect)
        stopAnimation()
    }
    
    @objc private func onMaskViewTap() {
        stopAnimation()
    }
    
    func startAnimation() {
        actionSheetView.snp.updateConstraints { (make) in
            make.bottom.equalToSuperview().inset(-EditUserSexActionSheet.actionSheetMarginBottom)
        }
        updateViewConstraints()
        UIView.animate(withDuration: 0.3) { [weak self] in
            self?.alpha = 1
            self?.layoutIfNeeded()
        }
    }
    
    func stopAnimation() {
        actionSheetView.snp.updateConstraints { (make) in
            make.bottom.equalToSuperview().inset(-EditUserSexActionSheet.actionSheetViewHeight)
        }
        updateViewConstraints()
        UIView.animate(withDuration: 0.3) { [weak self] in
            self?.alpha = 0
            self?.layoutIfNeeded()
        }
    }
    
    private func updateViewConstraints() {
        self.updateConstraintsIfNeeded()
        self.updateFocusIfNeeded()
    }
}
