//
//  EditUserBirthdayActionSheet.swift
//  Sp
//
//  Created by mac on 2020/9/8.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

protocol EditUserBirthdayActionSheetDelegate: NSObjectProtocol {
    
    func chosenBirthDay(date: Date)
    
}

class EditUserBirthdayActionSheet: UIView {
    
    private static let sheetHeight: CGFloat = 220 + (IS_IPHONEX ? 20 : 0)
    
    private static let actionSheetMarginBottom: CGFloat = 10
    
    private static let actionSheetViewHeight: CGFloat = EditUserBirthdayActionSheet.sheetHeight + EditUserBirthdayActionSheet.actionSheetMarginBottom
    
    private lazy var datePicker: UIDatePicker = {
        let datePicker = UIDatePicker()
        datePicker.center = self.center
        datePicker.datePickerMode = .date
        datePicker.maximumDate = Date()
        datePicker.locale = Locale(identifier: "zh_CN")
        datePicker.setValue(UIColor.black, forKey: "textColor")
        return datePicker
    }()
    
    private lazy var cancelBtn: UIButton = {
        let btn = UIButton()
        btn.setTitle("取消", for: .normal)
        btn.setTitleColor(RGB(0x141516), for: .normal)
        btn.titleLabel?.font = UIFont.pingFangRegular(16)
        btn.addTarget(self, action: #selector(onCancelBtnTap), for: .touchUpInside)
        btn.layer.borderColor = RGB(0x141516).cgColor
        btn.layer.borderWidth = 1
        btn.layer.masksToBounds = true
        btn.layer.cornerRadius = 6
        return btn
    }()
    
    private lazy var confirmBtn: UIButton = {
        let btn = UIButton()
        btn.setTitle("確定", for: .normal)
        btn.setTitleColor(RGB(0x141516), for: .normal)
        btn.titleLabel?.font = UIFont.pingFangRegular(16)
        btn.addTarget(self, action: #selector(onConfirmBtnTap), for: .touchUpInside)
        btn.layer.borderColor = RGB(0x141516).cgColor
        btn.layer.borderWidth = 1
        btn.layer.masksToBounds = true
        btn.layer.cornerRadius = 6
        return btn
    }()
    
    private lazy var actionSheetView: UIView = {
        let view = UIView()
        view.backgroundColor = .white
        view.layer.cornerRadius = 10
        view.layer.masksToBounds = true
        view.addSubview(datePicker)
        view.addSubview(cancelBtn)
        view.addSubview(confirmBtn)
        
        cancelBtn.snp.makeConstraints { (make) in
            make.top.equalToSuperview().inset(16)
            make.left.equalToSuperview().inset(10)
            make.width.equalTo(70)
            make.height.equalTo(30)
        }
        
        confirmBtn.snp.makeConstraints { (make) in
            make.centerY.size.equalTo(cancelBtn)
            make.right.equalToSuperview().inset(10)
        }
        
        datePicker.snp.makeConstraints { (make) in
            make.top.equalTo(cancelBtn.snp.bottom)
            make.left.right.bottom.equalToSuperview()
        }
        
        return view
    }()
    
    weak var delegate: EditUserBirthdayActionSheetDelegate?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        alpha = 0
        backgroundColor = UIColor.black.withAlphaComponent(0.3)
        let tap = UITapGestureRecognizer(target: self, action: #selector(onMaskViewTap))
        isUserInteractionEnabled = true
        addGestureRecognizer(tap)
        addSubview(actionSheetView)
        
        actionSheetView.snp.makeConstraints { (make) in
            make.height.equalTo(EditUserBirthdayActionSheet.actionSheetViewHeight)
            make.left.right.equalToSuperview()
            make.bottom.equalToSuperview().inset(-EditUserBirthdayActionSheet.actionSheetViewHeight)
        }
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    @objc private func onCancelBtnTap() {
        stopAnimation()
    }
    
    @objc private func onConfirmBtnTap() {
        delegate?.chosenBirthDay(date: datePicker.date)
        stopAnimation()
    }
    
    @objc private func onMaskViewTap() {
        stopAnimation()
    }
    
    func startAnimation() {
        actionSheetView.snp.updateConstraints { (make) in
            make.bottom.equalToSuperview().inset(-EditUserBirthdayActionSheet.actionSheetMarginBottom)
        }
        updateViewConstraints()
        UIView.animate(withDuration: 0.3) { [weak self] in
            self?.alpha = 1
            self?.layoutIfNeeded()
        }
    }
    
    func stopAnimation() {
        actionSheetView.snp.updateConstraints { (make) in
            make.bottom.equalToSuperview().inset(-EditUserBirthdayActionSheet.actionSheetViewHeight)
        }
        updateViewConstraints()
        UIView.animate(withDuration: 0.3) { [weak self] in
            self?.alpha = 0
            self?.layoutIfNeeded()
        }
    }
    
    private func updateViewConstraints() {
        self.updateConstraintsIfNeeded()
        self.updateFocusIfNeeded()
    }
}
