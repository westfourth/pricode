//
//  EditInfoCell.swift
//  Sp
//
//  Created by mac on 2020/2/27.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class EditInfoCell: UITableViewCell {
    
    @IBOutlet weak var name: UILabel!
    
    @IBOutlet weak var detail: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        backgroundColor = .none
        selectionStyle = .none
    }
    
    func set(_ detail:String) {
        self.detail.text = detail
    }
}
