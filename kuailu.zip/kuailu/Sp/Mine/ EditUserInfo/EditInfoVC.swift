//
//  EditInfoVC.swift
//  Sp
//
//  Created by mac on 2020/2/27.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class EditInfoVC: UIViewController {
    
    private static let formatDate: DateFormatter = {
        let f = DateFormatter()
        f.dateFormat = "yyyy/MM/dd"
        return f
    }()
    
    private static let formateUTCDate: DateFormatter = {
        let f = DateFormatter()
        f.timeZone = NSTimeZone(abbreviation: "UTC") as TimeZone?
        f.dateFormat = "yyyy-MM-dd'T'HH:mm:ss.SSSZZZ"
        return f
    }()
    
    private static let avatarImg: UIImage? = {
        return Sensitive.avatar
    }()
    
    private static let animationOption: KingfisherOptionsInfo = {
        return [.transition(.fade(0.25))]
    }()
    
    private static let navigationBarBgImg: UIImage? = {
        return UIImage(named: "navi_backImage")
    }()
    
    private static let emptyImg: UIImage = {
        return UIImage()
    }()
    
    @IBOutlet weak var logo: UIImageView!
    
    @IBOutlet weak var tableView: UITableView!
    
    private lazy var save : UIButton = {
        let button = UIButton()
        button.setTitle("保存", for: UIControl.State.normal)
        button.setTitleColor(RGB(0xFA6400), for: UIControl.State.normal)
        button.setTitleColor(RGB(33,36,48), for: UIControl.State.disabled)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 14, weight: UIFont.Weight.medium)
        button.frame = CGRect(x: 0, y: 0, width: 28, height: 20)
        button.addTarget(self, action: #selector(submitUserinfo), for: .touchUpInside)
        return button
    }()
    
    private lazy var tipLabel:UILabel = {
        let label = UILabel()
        label.numberOfLines = 0
        let attributes = [NSAttributedString.Key.font: UIFont.pingFangMedium(12),
                          NSAttributedString.Key.foregroundColor: RGB(0xB6B6B6)
        ]
        let attributedString = NSMutableAttributedString(string: "溫馨提示：普通用戶每月只能修改資料1次、\(Sensitive.hui)等級達到6級可隨意修改資料哦～", attributes: attributes)
        attributedString.addAttributes([NSAttributedString.Key.foregroundColor: RGB(0xFF1E1E)], range: NSRange(location: 0, length: 5))
        attributedString.addAttributes([NSAttributedString.Key.foregroundColor: UIColor.white], range: NSRange(location: 17, length: 11))
        label.attributedText = attributedString
        return label
    }()
    
    private lazy var sexActionSheet: EditUserSexActionSheet = {
        let view = EditUserSexActionSheet()
        view.delegate = self
        return view
    }()
    
    private lazy var birthdayActionSheet: EditUserBirthdayActionSheet = {
        let view = EditUserBirthdayActionSheet()
        view.delegate = self
        return view
    }()
    
    private let titleList: [String] = ["暱稱", "簡介", "性別", "生日", "所在地"]
    
    private let genderList: [String] = ["", "女", "男", "保密", "保密"]
    
    private lazy var contentList: [String] = {
        return Array(repeating: "", count: titleList.count)
    }()
    //头像
    private var logoUrl: String = ""
    //暱称
    private var nickName: String = ""
    //个性签名
    private var personSign: String = ""
    //性别 用户性别 1-女,2-男
    private var gender: Int = 1
    //生日
    private var birthday: Date?
    ///行政区域code
    private var cityCode: String = ""
    
    override func awakeFromNib() {
        super.awakeFromNib()
        logo.image = EditInfoVC.avatarImg
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationItem.title = "編輯個人資料"
        view.backgroundColor = RGB(0x141516)
        navigationItem.rightBarButtonItem = UIBarButtonItem(customView: save)
        let tap = UITapGestureRecognizer(target: self, action: #selector(changeAvatar))
        logo.isUserInteractionEnabled = true
        logo.addGestureRecognizer(tap)
        tableView.rowHeight = 60
        tableView.backgroundColor = .none
        tableView.isScrollEnabled = false
        tableView.register(UINib(nibName: "EditInfoCell", bundle: Bundle.main), forCellReuseIdentifier: "EditInfoCell")
        view.addSubview(tipLabel)
        view.addSubview(birthdayActionSheet)
        view.addSubview(sexActionSheet)
        
        tipLabel.snp.makeConstraints { (make) in
            make.bottom.equalToSuperview().inset(IS_IPHONEX ? 108 : 64)
            make.left.right.equalToSuperview().inset(12)
        }
        
        birthdayActionSheet.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
        
        sexActionSheet.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
        
        loadData()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.navigationBar.setBackgroundImage(EditInfoVC.navigationBarBgImg, for: .default)
        navigationController?.navigationBar.shadowImage = EditInfoVC.emptyImg
    }
    
    private func loadData () {
        Alert.showLoading(parentView: UIApplication.shared.keyWindow!)
        Session.request(FetchUserInfoReq()) { [weak self] (error, resp) in
            Alert.hideLoading()
            guard let `self` = self, error == nil, let userinfo = resp as? UserBase else { return }
            self.logo.kf.setImage(with: userinfo.logo, placeholder: EditInfoVC.avatarImg, options: EditInfoVC.animationOption)
            self.handleData(userinfo: userinfo)
            self.tableView.reloadData()
        }
    }
    
    private func handleData(userinfo: UserBase) {
        contentList[0] = userinfo.nickName.isEmpty ? "未填寫" : userinfo.nickName
        nickName = userinfo.nickName
        contentList[1] = userinfo.personSign.isEmpty ? "請填寫個人簡介，讓更多人關注你" : userinfo.personSign
        personSign = userinfo.personSign
        contentList[2] = genderList[userinfo.gender.rawValue]
        gender = userinfo.gender.rawValue
        contentList[3] = userinfo.birthday == nil ? "保密" : EditInfoVC.formatDate.string(from: userinfo.birthday!)
        contentList[4] = userinfo.cityName.isEmpty ? "\(Sensitive.cao)星" : userinfo.cityName
        cityCode = userinfo.cityCode
    }
    
    @objc private func submitUserinfo() {
        guard let user = NetDefaults.userInfo, user.updateNum > 0 else {
            mm_showToast("您未達到V6等級權限,請前往\(Sensitive.chong)以提升等級!", type: .warning, duration: 1.5) { [weak self] in
                VipChargeTipVC.isFromVideoPlayList = false
                self?.navigationController?.pushViewController(Vip2VC(), animated: true)
            }
            return
        }
        
        if nickName.isEmpty {
            mm_showToast("暱稱不能空哦！")
            return
        }
        
        Alert.showLoading(parentView: self.view)
        let req = UpdateUserReq()
        req.logo = logoUrl
        req.nickName = nickName
        req.personSign = personSign
        req.gender = gender
        req.code = cityCode
        if let birthday = self.birthday {
            req.birthday = EditInfoVC.formateUTCDate.string(from: birthday)
        }
        Session.request(req) { [weak self] (error, resp) in
            Alert.hideLoading()
            guard error == nil else {
                mm_showToast(error!.localizedDescription)
                return
            }
            if let user = NetDefaults.userInfo {
                user.updateNum -= 1
                NetDefaults.userInfo = user
            }
            mm_showToast("恭喜您，個人資料編輯成功！", type: .succeed, duration: 1.5) { [weak self] in
                self?.navigationController?.popViewController(animated: true)
            }
        }
    }
    
    @objc private func changeAvatar() {
        
        let imageVC = UIImagePickerController()
        imageVC.modalPresentationStyle = .fullScreen
        if #available(iOS 13.0, *) {
            imageVC.isModalInPresentation = true
        }
        imageVC.delegate = self
        imageVC.allowsEditing = true
        
        let alertController = UIAlertController(title: nil, message: nil, preferredStyle: .actionSheet)
        for i in 0..<3 {
            let action = UIAlertAction(title: i == 0 ? "拍照" : i == 1 ? "相簿" : "取消", style: i == 2 ? .cancel : .default) { [weak self] _ in
                if i < 2 {
                    imageVC.sourceType = i == 0 ? .camera : .photoLibrary
                    GlobalSettings.setImagePickerNatiBarAttribute()
                    self?.present(imageVC, animated: true, completion: nil)
                }
            }
            alertController.addAction(action)
        }
        present(alertController, animated: true, completion: nil)
    }
    
}

extension EditInfoVC:UITableViewDataSource,UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "EditInfoCell") as! EditInfoCell
        let row = indexPath.row
        cell.name.text = titleList[row]
        cell.set(contentList[row])
        return cell
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return titleList.count
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        switch indexPath.row {
        case 0:
            let changeNickVC = ChangeNickVC()
            changeNickVC.delegate = self
            navigationController?.pushViewController(changeNickVC, animated: true)
        case 1:
            let changeIntroductionVC = ChangeIntroductionVC()
            changeIntroductionVC.delegate = self
            navigationController?.pushViewController(changeIntroductionVC, animated: true)
        case 2:
            sexActionSheet.startAnimation()
        case 3:
            birthdayActionSheet.startAnimation()
        case 4:
            navigationController?.navigationBar.setBackgroundImage(EditInfoVC.emptyImg, for: .default)
            let chooseCityVC = ChooseCityVC()
            chooseCityVC.delegate = self
            navigationController?.pushViewController(chooseCityVC, animated: true)
        default:
            break
        }
    }
    
}

extension EditInfoVC: ChangeNickVCDelegate {
    
    func updateNickname(nickname: String) {
        nickName = nickname
        contentList[0] = nickname
        tableView.reloadData()
    }
    
}

extension EditInfoVC: ChangeIntroductionVCDelegate {
    
    func updateIntro(intro: String) {
        personSign = intro
        contentList[1] = intro
        tableView.reloadData()
    }
    
}

extension EditInfoVC: EditUserSexActionSheetDelegate {
    
    func chosenSex(sexType: SexType) {
        gender = sexType.rawValue
        contentList[2] = genderList[sexType.rawValue]
        tableView.reloadData()
    }
    
}

extension EditInfoVC: EditUserBirthdayActionSheetDelegate {
    
    func chosenBirthDay(date: Date) {
        birthday = date
        contentList[3] = EditInfoVC.formatDate.string(from: date)
        tableView.reloadData()
    }
    
}

extension EditInfoVC: ChooseCityVCDelegate {
    
    func chosenCity(cityItem: CityItem) {
        cityCode = cityItem.code
        contentList[4] = cityItem.name
        tableView.reloadData()
    }
    
}

extension EditInfoVC: UIImagePickerControllerDelegate,UINavigationControllerDelegate {
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true, completion: nil)
        GlobalSettings.resetNaviBarAttribute()
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        let image = info[UIImagePickerController.InfoKey.editedImage] as! UIImage
        GlobalSettings.resetNaviBarAttribute()
        picker.dismiss(animated: true, completion: nil)
        Alert.showLoading(parentView: self.view)
        ImageUploader.upload(image) { [weak self] (error, domain,suffix) in
            Alert.hideLoading()
            guard error == nil else {
                mm_showToast("頭像上傳失敗，請重新上傳！", type: .failed)
                return
            }
            guard let logo = URL(string: domain + suffix) else { return }
            self?.logoUrl = suffix
            DispatchQueue.main.async { [weak self] in
                self?.logo.kf.setImage(with: logo, placeholder: EditInfoVC.avatarImg, options: EditInfoVC.animationOption)
            }
        }
    }
}

