//
//  LevelFooter.swift
//  Sp
//
//  Created by mac on 2020/5/6.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

@objc protocol LevelFooterDelegate {
    ///点击
    func promtAction()
}

class LevelFooter: UICollectionReusableView {
    
    weak var delegate: LevelFooterDelegate?
    
    @IBOutlet weak var prompt: UIButton!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        object_setClass(prompt.layer, CAGradientLayer.self)
        let i = prompt.layer as! CAGradientLayer
        i.colors = [RGB(0xF8D9B2).cgColor,RGB(0xffE1B67E).cgColor]
        i.startPoint = CGPoint(x: 0, y: 0)
        i.endPoint = CGPoint(x: 1, y: 0)
    }
    
    @IBAction func promtAction(_ sender: Any) {
        self.delegate?.promtAction()
    }
    
}
