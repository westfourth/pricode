//
//  LevelVC.swift
//  Sp
//
//  Created by mac on 2020/5/1.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class LevelVC: UIViewController {
    
    var item:UserGradeResp?
    
    var currentVip:GradeItem?
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.navigationBar.setBackgroundImage(UIImage(), for: UIBarMetrics.default)
        self.navigationController?.navigationBar.shadowImage = UIImage()
        self.navigationController?.navigationBar.isTranslucent = true
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = RGB(14,10,5)
        view.addSubview(self.collectionView)
        collectionView.snp.makeConstraints { (make) in
            make.left.right.bottom.equalTo(0)
            make.top.equalTo(-kTop)
        }
        
        collectionView.contentInset = UIEdgeInsets(top:355, left: 0, bottom: 0, right: 0)
        
        loadData()
        
        object_setClass(view.layer, CAGradientLayer.self)
        let i = view.layer as! CAGradientLayer
        i.colors = [RGB(0xff0E0804).cgColor,RGB(0xff150B05).cgColor]
        i.startPoint = CGPoint(x: 0, y: 0)
        i.endPoint = CGPoint(x: 0, y: 1)
        
        collectionView.addSubview(self.headerView)
        self.headerView.snp.makeConstraints { (make) in
            make.left.right.equalTo(0)
            make.top.equalTo(-355)
            make.height.equalTo(355)
        }
    }
    
    lazy var headerView:LevelHeader = {
        let h = Bundle.main.loadNibNamed("LevelHeader", owner: nil, options: [:])?.first as!LevelHeader
        h.delegate = self
        return h
    }()
    
    lazy var collectionView: UICollectionView = {
        let layout = UICollectionViewFlowLayout()
        layout.minimumLineSpacing = 18
        layout.minimumInteritemSpacing = (UIScreen.main.bounds.size.width - 240 - 66 ) / 3.0
        layout.sectionInset = UIEdgeInsets(top: 10, left: 33, bottom: 0, right: 33)
        layout.itemSize = CGSize(width: 60, height: 75)
        
//        layout.headerReferenceSize = CGSize(width: UIScreen.main.bounds.size.width, height: 355)
        
        layout.footerReferenceSize = CGSize(width: UIScreen.main.bounds.size.width, height: 85)
        let collectionView = UICollectionView(frame: .zero, collectionViewLayout: layout)
        collectionView.dataSource = self
        collectionView.delegate = self
        
        collectionView.register(UINib(nibName: "LevelCell", bundle: Bundle.main), forCellWithReuseIdentifier: "LevelCell")
        
//        collectionView.register(UINib(nibName: "LevelHeader", bundle: Bundle.main), forSupplementaryViewOfKind: UICollectionView.elementKindSectionHeader, withReuseIdentifier: "LevelHeader")
        
        collectionView.register(UINib(nibName: "LevelFooter", bundle: Bundle.main), forSupplementaryViewOfKind: UICollectionView.elementKindSectionFooter, withReuseIdentifier: "LevelFooter")
        
        collectionView.backgroundColor = .clear
        collectionView.showsVerticalScrollIndicator = false
        return collectionView
    }()
    
    //MARK:-加载数据
    func loadData() {
        Alert.showLoading(parentView: self.view)
        Session.request(UserGradeReq()) { [weak self] (error, resp) in
            Alert.hideLoading()
            guard let strongSelf = self else {
                return
            }
            guard error == nil else {
//                strongSelf.collectionView.state = .failed
                return
            }
            guard let item = resp as? UserGradeResp,!item.privilegeList.isEmpty else {
//                strongSelf.collectionView.state = .empty
                return
            }
            strongSelf.item = item
            Defaults.rechargeTotal = item.rechargeTotal
            Defaults.currentLevel = item.level
            strongSelf.currentVip =  item.gradeList.filter({ (g) -> Bool in
                return g.grade == item.level
            }).first
//            strongSelf.collectionView.state = .normal
            strongSelf.headerView.items = item.gradeList
            strongSelf.collectionView.reloadData()
        }
    }
}


extension LevelVC:UICollectionViewDataSource,UICollectionViewDelegate {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return  self.item?.privilegeList.count ?? 0
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "LevelCell", for: indexPath) as! LevelCell
        let pri = self.item?.privilegeList[indexPath.row]
        cell.item = (pri,self.currentVip)
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, viewForSupplementaryElementOfKind kind: String, at indexPath: IndexPath) -> UICollectionReusableView {
//        if kind == UICollectionView.elementKindSectionHeader {
//            let headerView = collectionView.dequeueReusableSupplementaryView(ofKind: UICollectionView.elementKindSectionHeader, withReuseIdentifier: "LevelHeader", for: indexPath) as! LevelHeader
//            headerView.items = self.item?.gradeList
//            headerView.delegate = self
//            return headerView
//        } else
            if kind == UICollectionView.elementKindSectionFooter {
            let footer = collectionView.dequeueReusableSupplementaryView(ofKind: UICollectionView.elementKindSectionFooter, withReuseIdentifier: "LevelFooter", for: indexPath) as! LevelFooter
            footer.delegate = self
            return footer
        }
        return UICollectionReusableView()
    }
}

extension LevelVC:LevelFooterDelegate {
    func promtAction() {
        VipChargeTipVC.isFromVideoPlayList = false
        self.navigationController?.pushViewController(Vip2VC(), animated: true)
    }
}

extension LevelVC:LevelHeaderDelegate {
    func promtAtion() {
        VipChargeTipVC.isFromVideoPlayList = false
        self.navigationController?.pushViewController(Vip2VC(), animated: true)
    }
    
    func didScrollToIndex(index: Int) {
        self.currentVip = self.item?.gradeList[index]
        self.collectionView.reloadData()
    }
}

