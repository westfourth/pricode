//
//  CardSwipView.swift
//  Sp
//
//  Created by mac on 2020/5/6.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

#warning("先不要用這個類來處理##################")
@objc protocol CardSwipViewDelegate {
    ///点击
    func didScrollToIndex(index:Int)
    //去升级
    func promtAtion()
}

class CardSwipView: UIView {
    
    weak var delegate: CardSwipViewDelegate?
    var dragStartX = 0.0
    var dragEndX = 0.0
    var selectedIndex = 0
    
    var items:[GradeItem]? {
        didSet {
            guard let _ = items else {
                return
            }
            self.collectionView.reloadData()
        }
    }
    
    lazy var collectionView: UICollectionView = {
        let collectionView = UICollectionView(frame: .zero, collectionViewLayout: CardSwipLayout())
        collectionView.dataSource = self
        collectionView.delegate = self
        collectionView.register(UINib(nibName: "VipCell", bundle: Bundle.main), forCellWithReuseIdentifier: "VipCell")
        collectionView.backgroundColor = .clear
        collectionView.showsHorizontalScrollIndicator = false
        return collectionView
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        addSubview(UIView())
        addSubview(collectionView)
        backgroundColor = .clear
        collectionView.frame = self.bounds
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    //MARK:- 滑到第几个item
    func swipToIndex(_ index:Int,animated:Bool) {
        selectedIndex = index
        collectionView.scrollToItem(at: IndexPath(row: selectedIndex, section: 0), at: UICollectionView.ScrollPosition.centeredHorizontally, animated: animated)
        delegate?.didScrollToIndex(index: selectedIndex)
    }
}


extension CardSwipView:UIScrollViewDelegate {
    // 开始拖拽
    func scrollViewWillBeginDragging(_ scrollView: UIScrollView) {
        dragStartX = Double(scrollView.contentOffset.x )
    }
    
    func scrollViewDidEndDragging(_ scrollView: UIScrollView, willDecelerate decelerate: Bool) {
        dragEndX = Double(scrollView.contentOffset.x)
        DispatchQueue.main.async {
            self.centerAction()
        }
    }
    
    func centerAction() {
        //最小滚动距离
        let dragMiniDistance = Double(self.bounds.size.width / 20)
        if (dragStartX - dragEndX >= dragMiniDistance) {
            selectedIndex -= 1   //向右
        }else if (dragEndX - dragStartX >= dragMiniDistance) {
            selectedIndex += 1   //向左
        }
        let maxIndex = (items?.count ??  collectionView(collectionView, numberOfItemsInSection: 0) ) - 1
        selectedIndex = selectedIndex <= 0 ? 0 : selectedIndex
        selectedIndex = selectedIndex >= maxIndex ? maxIndex : selectedIndex
        
        delegate?.didScrollToIndex(index: selectedIndex)
        
        collectionView.scrollToItem(at: IndexPath(row: selectedIndex, section: 0), at: UICollectionView.ScrollPosition.centeredHorizontally, animated: true)
    }
}

extension CardSwipView:UICollectionViewDataSource,UICollectionViewDelegate {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return self.items?.count ?? 0
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "VipCell", for: indexPath) as! VipCell
        cell.item = self.items?[indexPath.row]
        cell.delegate = self
        return cell
    }
}

extension CardSwipView:VipCellDelegate {
    func promptAction() {
        delegate?.promtAtion()
    }
}


