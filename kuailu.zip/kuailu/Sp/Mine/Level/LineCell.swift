//
//  LineCell.swift
//  Sp
//
//  Created by mac on 2020/5/7.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class LineCell: UICollectionViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    @IBOutlet weak var level: UILabel!
    @IBOutlet weak var score: UILabel!
    @IBOutlet weak var current: UIView!
    
    var item:(i:GradeItem?,l:Int?) {
        didSet {
            guard let aItem = item.i else {
                return
            }
            guard let currentUserLevel = item.l else {
                return
            }
            
            let isCurrent = currentUserLevel == aItem.grade
            level.text = "V\(aItem.grade)"
            level.backgroundColor = isCurrent ? RGB(0xffD6270F):RGB(0xff2F2F2F)
            level.textColor = isCurrent ? UIColor.white:RGB(0xffFFBF6C)
            score.text = "\(aItem.startScore)-\(aItem.endScore)"
            current.isHidden = !isCurrent
        }
    }
}
