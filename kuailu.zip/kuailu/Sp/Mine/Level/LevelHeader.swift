//
//  LevelHeader.swift
//  Sp
//
//  Created by mac on 2020/5/6.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

@objc protocol LevelHeaderDelegate {
    
    func didScrollToIndex(index:Int)
    
    func promtAtion()
    
}

class LevelHeader: UIView {
    
    //    var swipView : CardSwipView?
    weak var delegate: LevelHeaderDelegate?
    
    
    @IBOutlet weak var line: UIView!
    
    @IBOutlet weak var lineWidth: NSLayoutConstraint!
    @IBOutlet weak var collectionView: UICollectionView!
    @IBOutlet weak var layout: UICollectionViewFlowLayout!
    
    @IBOutlet weak var currentLevel: UILabel!
    
    var items:[GradeItem]? {
        didSet {
            guard  let items = items else {
                return
            }
            //            self.swipView?.items = items
            self.vipView.items = items
            self.collectionView.reloadData()
        }
    }
    
    lazy var vipView:VipCardView  = {
        let gap = IS_IPHONEX ? 10 : 20
        let vip = VipCardView(frame: CGRect(x: 0, y: kTop + CGFloat(gap) , width: UIScreen.main.bounds.size.width, height: UIScreen.main.bounds.size.width * 0.62 * 0.545))
        vip.delegate = self
        return vip
    }()
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        //        let gap = IS_IPHONEX ? 10 : 20
        //         swipView= CardSwipView(frame: CGRect(x: 0, y: kTop + CGFloat(gap) , width: UIScreen.main.bounds.size.width, height: UIScreen.main.bounds.size.width * 0.62 * 0.545))
        //        swipView?.delegate = self
        //        addSubview(swipView!)
        
        addSubview(self.vipView)
        
        layout.itemSize =  CGSize(width: (UIScreen.main.bounds.size.width - 24.0) / 6, height: 50)
        layout.minimumInteritemSpacing = 0.0
        layout.minimumLineSpacing = 0.0
        collectionView.register(UINib(nibName: "LineCell", bundle: Bundle.main), forCellWithReuseIdentifier: "LineCell")
        
        if let index =  Defaults.currentLevel {
            let w = (UIScreen.main.bounds.size.width - 24) / 12
            self.lineWidth.constant = index == 1 ? w : w * CGFloat((index * 2 - 1))
        }
        
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() +  0.5) {
            guard let items = self.items else {return}
            if let index =  Defaults.currentLevel {
                let item = items.filter { (i) -> Bool in
                    return i.grade == index
                }.first
                guard item != nil else {return}
                guard let i =  items.firstIndex(of: item!) else { return }
                //                self.swipView?.swipToIndex(i, animated: true)
                self.vipView.pagerView.scrollToItem(at: i, animate: true)
            }
        }
    }
}

extension LevelHeader:VipCardViewDelegate {
    
    func promtAtion() {
        delegate?.promtAtion()
    }
    
    func didScrollToIndex(index: Int) {
        self.delegate?.didScrollToIndex(index: index)
        self.currentLevel.text = "V\(index + 1)等級特權"
    }
}

extension LevelHeader:UICollectionViewDataSource,UICollectionViewDelegate {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return self.items?.count ?? 0
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "LineCell", for: indexPath) as! LineCell
        if let currentLevel = Defaults.currentLevel {
          cell.item = (self.items?[indexPath.row],currentLevel)
        }
        return cell
    }
}

