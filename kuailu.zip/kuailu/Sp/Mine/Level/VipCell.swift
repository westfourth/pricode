//
//  VipCell.swift
//  Sp
//
//  Created by mac on 2020/5/6.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

@objc protocol VipCellDelegate {
    ///升级
    func promptAction()
}

class VipCell: UICollectionViewCell {
    weak var delegate: VipCellDelegate?
    @IBOutlet weak var promt: UIButton!
    @IBOutlet weak var icon: UIImageView!
    @IBOutlet weak var desc: UILabel!
    @IBOutlet weak var avatar: UIImageView!
    @IBOutlet weak var username: UILabel!
    @IBOutlet weak var promtWidth: NSLayoutConstraint!
    
    static var format :DateFormatter = {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd"
        return dateFormatter
    }()
    
    var item : GradeItem? {
        didSet {
            guard  let item = item else {
                return
            }
            self.icon.image = UIImage(named: "vip_\(item.grade)")
            if item.userAt != nil {
                let time = VipCell.format.string(from: item.userAt!)
                self.desc.text = "已於\(time)達到該等級"
                promt.setTitle("升級攻略", for: .normal)
                promtWidth.constant = 65
            } else {
                promtWidth.constant = 57
                promt.setTitle("去升級", for: .normal)
                let value = item.startScore - (Defaults.rechargeTotal ?? 0)  <= 0 ? 0 : item.startScore - (Defaults.rechargeTotal ?? 0)
                self.desc.text = "距離V\(item.grade)等級僅差\(value)元哦"
            }
            if let l =  Defaults.currentLevel {
                let isMe = item.grade == l
                self.avatar.isHidden = !isMe
                self.username.isHidden = !isMe
                if let user = NetDefaults.userInfo {
                    self.avatar.kf.setImage(with: user.logo,placeholder:Sensitive.avatar)
                    self.username.text = user.nickName
                }
            }
        }
    }
    
    @IBAction func promtAction(_ sender: Any) {
        delegate?.promptAction()
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        object_setClass(promt.layer, CAGradientLayer.self)
        let i = promt.layer as! CAGradientLayer
        i.colors = [RGB(0xffF7D7AF).cgColor,RGB(0xffF9F2E8).cgColor]
        i.startPoint = CGPoint(x: 0, y: 0)
        i.endPoint = CGPoint(x: 1, y: 0)
    }
}
