//
//  VipCardView.swift
//  Sp
//
//  Created by mac on 2020/5/9.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit
import TYCyclePagerView

@objc protocol VipCardViewDelegate {
    ///点击
    func didScrollToIndex(index:Int)
    //去升级
    func promtAtion()
}

class VipCardView: UIView {
    
    weak var delegate:VipCardViewDelegate?
    
    var items:[GradeItem]? {
        didSet {
            guard let _ = items else {
                return
            }
            self.pagerView.reloadData()
        }
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        addSubview(pagerView)
        pagerView.frame = self.bounds
        backgroundColor = .clear
    }
    
    lazy var pagerView: TYCyclePagerView = {
        let pagerView = TYCyclePagerView()
        pagerView.isInfiniteLoop = false
        pagerView.dataSource = self
        pagerView.delegate = self
        pagerView.register(UINib(nibName: "VipCell", bundle: Bundle.main), forCellWithReuseIdentifier: "VipCell")
        return pagerView
    }()
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}

// MARK: TYCyclePagerViewDataSource & Delegate
extension VipCardView: TYCyclePagerViewDelegate, TYCyclePagerViewDataSource {
    
    func numberOfItems(in pageView: TYCyclePagerView) -> Int {
        return self.items?.count ?? 0
    }
    
    func pagerView(_ pagerView: TYCyclePagerView, cellForItemAt index: Int) -> UICollectionViewCell {
        let cell = pagerView.dequeueReusableCell(withReuseIdentifier: "VipCell", for: index) as! VipCell
        cell.item = items?[index]
        cell.delegate = self
        return cell
    }
    
    func layout(for pageView: TYCyclePagerView) -> TYCyclePagerViewLayout {
        let layout = TYCyclePagerViewLayout()
        layout.itemSize = CGSize(width: 0.62 * UIScreen.main.bounds.size.width, height: pagerView.frame.height)
        layout.itemSpacing = 35
        layout.layoutType = .linear
        layout.minimumScale = 0.8

        layout.itemHorizontalCenter = true
        return layout
    }
    
    func pagerView(_ pageView: TYCyclePagerView, didScrollFrom fromIndex: Int, to toIndex: Int) {
        puts(#function)
        self.delegate?.didScrollToIndex(index: toIndex)
    }
}

extension VipCardView:VipCellDelegate {
    func promptAction() {
        self.delegate?.promtAtion()
    }
}


