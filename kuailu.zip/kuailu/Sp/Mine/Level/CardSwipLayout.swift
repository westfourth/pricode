//
//  CardSwipLayout.swift
//  Sp
//
//  Created by mac on 2020/5/6.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class CardSwipLayout: UICollectionViewFlowLayout {
    
    private var cellWidth:CGFloat = {
        return UIScreen.main.bounds.size.width * 0.62
    }()
    
    private var collectionInset:CGFloat = {
        return (UIScreen.main.bounds.size.width  - UIScreen.main.bounds.size.width * 0.62 ) / 2.0
    }()
    
    private var cellMargin:CGFloat = {
        return 25
    }()
    
    override func prepare() {
        super.prepare()
        scrollDirection = .horizontal
        sectionInset = UIEdgeInsets(top: 0, left: collectionInset, bottom: 0, right: collectionInset)
        
        minimumLineSpacing = cellMargin
        
        itemSize = CGSize(width: cellWidth, height:self.cellWidth * 0.545)
        
    }
    
    func getCopyOfAttributes(attributes:[UICollectionViewLayoutAttributes]) -> [UICollectionViewLayoutAttributes] {
        var items = [UICollectionViewLayoutAttributes]()
        items = attributes.map { (item) -> UICollectionViewLayoutAttributes in
            return item
        }
        return items
    }
    
    override func shouldInvalidateLayout(forBoundsChange newBounds: CGRect) -> Bool {
        return true
    }
    
    override func layoutAttributesForElements(in rect: CGRect) -> [UICollectionViewLayoutAttributes]? {
//        // 扩大控制范围，防止出现闪屏现象
//        var bigRect = rect
//        bigRect.size.width = rect.size.width + CGFloat(2 * cellWidth)
//        bigRect.origin.x = rect.origin.x - CGFloat(cellWidth)
        
        let arr = getCopyOfAttributes(attributes: super.layoutAttributesForElements(in: rect)!)
        
        let centerX = (collectionView?.contentOffset.x ?? 0) + (UIScreen.main.bounds.size.width / 2.0)
        // 刷新cell缩放
        for item in arr {
            let distance = fabsf(Float((item.center.x )  - centerX))
            let apartScale = CGFloat(distance) / UIScreen.main.bounds.size.width
            let scale = fabs(cos(Double(apartScale) * Double.pi / 4.0));
            item.transform = CGAffineTransform(scaleX: CGFloat(scale), y: CGFloat(scale))
        }
        return arr;
    }
    
}
