//
//  LevelCell.swift
//  Sp
//
//  Created by mac on 2020/5/1.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class LevelCell: UICollectionViewCell {
    
    override func awakeFromNib() {
        super.awakeFromNib()
        //        object_setClass(circle.layer, CAGradientLayer.self)
        //        let i = circle.layer as! CAGradientLayer
        //        i.colors = [RGB(0xffF0DAB7).cgColor,RGB(0xffD8C39C).cgColor]
        //        i.startPoint = CGPoint(x: 0, y: 0)
        //        i.endPoint = CGPoint(x: 0, y: 1)
    }
    
    @IBOutlet weak var icon: UIImageView!
    
    @IBOutlet weak var name: UILabel!
    
    @IBOutlet weak var circle: UIView!
    
    var item:(pri:PrivilegeItem?,gra:GradeItem?) {
        didSet {
            guard  let pri = item.pri else {
                return
            }
            guard let gra = item.gra else {
                return
            }
            let contain = gra.privilegeIds.contains(pri.privilegeId)
            if contain {
                if pri.highlightLogo != nil {
                    icon.kf.setImage(with:pri.highlightLogo, placeholder: Sensitive.avatar, options: [.transition(.fade(0.25))])
                } else {
                    icon.image = Sensitive.avatar
                }
            } else {
                if pri.logo != nil {
                    icon.kf.setImage(with:pri.logo, placeholder: Sensitive.avatar, options: [.transition(.fade(0.25))])
                } else {
                    icon.image = Sensitive.avatar
                }
            }
            name.text = pri.name
            name.textColor = contain ? RGB(0xffE8D2AE) : RGB(0xff818181)
        }
    }
}
