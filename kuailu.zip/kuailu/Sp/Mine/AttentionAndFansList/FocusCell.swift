//
//  FocusCell.swift
//  Sp
//
//  Created by mac on 2020/2/28.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

@objc protocol FocusCellDelegate {
    /// 点击关注
    func focuCell(cell:FocusCell, button:UIButton)
}

class FocusCell: UITableViewCell {
    
    weak var delegate: FocusCellDelegate?
    
    var isFan: Bool = true
    
    @IBOutlet weak var logo: UIImageView!
    @IBOutlet weak var name: UILabel!
    @IBOutlet weak var focus: UIButton!
    
    static let userId: Int = {
        return NetDefaults.userInfo?.userId ?? -1
    }()
    
    private static let avatarImg: UIImage? = {
        return Sensitive.avatar
    }()
    
    private static let animationOption: KingfisherOptionsInfo = {
        return [.transition(.fade(0.25))]
    }()
    
    override func awakeFromNib() {
        super.awakeFromNib()
        self.contentView.backgroundColor = .clear
        self.backgroundColor = .none
        self.selectionStyle = .none
        self.focus.layer.borderColor = RGB(255,100,34).cgColor
        logo.image = FocusCell.avatarImg
        self.focus.backgroundColor = RGB(255,100,34)
        self.focus.setTitleColor(UIColor.white , for: UIControl.State.normal)
        
    }
    
    var item:AttentionItem? {
        didSet {
            guard let item = item else {
                return
            }
            self.focus.isHidden = isFan ? item.userId == FocusCell.userId : item.beenUserId == FocusCell.userId
            
            self.name.text = item.nickName
            self.logo.kf.setImage(with: item.logo, placeholder: FocusCell.avatarImg, options: FocusCell.animationOption)
            self.focus.backgroundColor = item.isAttention ? UIColor.clear:RGB(255,100,34)
            self.focus.setTitleColor(item.isAttention ?RGB(255,100,34):UIColor.white , for: UIControl.State.normal)
            self.focus.setTitle(item.isAttention ? "取消關注":"關注", for: UIControl.State.normal)
        }
    }
    
    
    var user:UserBase? {
        didSet {
            guard  let item = user else {
                return
            }
            self.name.text = item.nickName
            self.logo.kf.setImage(with: item.logo, placeholder: FocusCell.avatarImg, options: FocusCell.animationOption)
        }
    }
    
    @IBAction func focusAction(_ sender: UIButton) {
        self.delegate?.focuCell(cell: self, button: sender)
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    
}
