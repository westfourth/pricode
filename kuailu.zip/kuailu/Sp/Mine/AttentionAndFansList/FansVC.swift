//
//  AttentionVC.swift
//  Sp
//
//  Created by mac on 2020/2/28.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class FansVC: UIViewController {
    
    var items:[AttentionItem] = [AttentionItem]()
    
    var page:Int = 1
    
    var nomoreData:Bool = false
    
    var userId:Int = -1000
    
    var listViewDidScrollCallback: ((UIScrollView) -> ())?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = RGB(0xff141516)
        view.addSubview(tableView)
        tableView.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
        self.loadData(self.page)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.page = 1
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.navigationBar.setBackgroundImage(UIImage(named: "navi_backImage"), for: UIBarMetrics.default)
    }
    
    //_______________________________________________________________________________________________________________
    // MARK: - UIScrollViewDelegate
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        self.listViewDidScrollCallback?(scrollView)
    }
    func loadData(_ page:Int) {
        let req = FansListReq()
        req.page = page
        req.userId = self.userId
        Session.request(req) { (error, resp) in
            guard error == nil else {
                mm_showToast(error!.localizedDescription)
                self.tableView.state = .failed
                return
            }
            if resp is [AttentionItem] {
                let array = resp as! [AttentionItem]
                self.nomoreData = array.count < 30
                if self.page == 1 {
                    self.items = array
                    if array.isEmpty {
                        self.tableView.state = .empty
                    } else{
                        self.tableView.state = .normal
                    }
                } else {
                    self.items.append(contentsOf: array)
                    if  self.items.isEmpty {
                        self.tableView.state = .empty
                    } else{
                        self.tableView.state = .normal
                    }
                }
            }
            self.tableView.reloadData()
        }
    }
    
    lazy var tableView : UITableView = {
        let tableView = UITableView.init(frame: CGRect.zero, style: .plain)
        tableView.delegate = self
        tableView.dataSource = self
        tableView.clipsToBounds = true
        tableView.backgroundColor = UIColor.clear
        tableView.separatorStyle = UITableViewCell.SeparatorStyle.singleLine
        tableView.register(UINib(nibName: "FocusCell", bundle: Bundle.main), forCellReuseIdentifier: "FocusCell")
        tableView.separatorStyle = .none
        tableView.state = .loading
        tableView.loadMoreBlock = { [unowned self] in
            guard self.nomoreData == false else {
                return
            }
            self.page = self.page + 1
            self.loadData(self.page)
        }
        return tableView
    }()
}

// MARK: -UITableViewDataSource && Delegate
extension FansVC:UITableViewDataSource,UITableViewDelegate {
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "FocusCell") as! FocusCell
        cell.delegate = self
        cell.isFan  = true
        cell.item = self.items[indexPath.row]
        return cell
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.items.count
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let userId = self.items[indexPath.row].userId
        guard userId != FocusCell.userId else { return }
        let usersDynamicVC = UsersDynamicVC()
        usersDynamicVC.userId = userId
        usersDynamicVC.attentionClosure = { [weak self] (isAttention: Bool) in
            guard let `self` = self else { return }
            self.items[indexPath.row].isAttention =  isAttention
            self.tableView.reloadData()
            usersDynamicVC.attentionClosure = nil
        }
        self.navigationController?.pushViewController(usersDynamicVC, animated: true)
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 70
    }
}

//_______________________________________________________________________________________________________________
// MARK: - JXPagingViewListViewDelegate
extension FansVC: JXPagingViewListViewDelegate {
    func listView() -> UIView {
        return view
    }
    
    func listViewDidScrollCallback(callback: @escaping (UIScrollView) -> ()) {
        self.listViewDidScrollCallback = callback
    }
    
    func listScrollView() -> UIScrollView {
        return self.tableView
    }
    
    func listWillAppear() {
        print("\(self.title ?? ""):\(#function)")
    }
    
    func listDidAppear() {
        print("\(self.title ?? ""):\(#function)")
    }
    
    func listWillDisappear() {
        print("\(self.title ?? ""):\(#function)")
    }
    
    func listDidDisappear() {
        print("\(self.title ?? ""):\(#function)")
    }
}

//MARK:-FocusCellDelegate
extension FansVC:FocusCellDelegate {
    
    func focuCell(cell: FocusCell, button: UIButton) {
        print(#function)
        guard let item = cell.item else {
            return
        }
        if item.isAttention {
            Alert.showCommonAlert(parentView: UIApplication.shared.keyWindow!, contentText: "取消關注後,您將無法及時收到他的動態",
                                  cancelText: "再看看",
                                  confirmText: "取消關注",
                                  onConfirmTap: {
                                    item.isAttention = false
                                    //取消关注
                                    let req = CancelFocusUserReq()
                                    req.beenUserId = item.userId
                                    Session.request(req) { (error, resp) in
                                        guard error == nil else {
                                            mm_showToast(error!.localizedDescription)
                                            return
                                        }
                                        mm_showToast("取消成功!", type: .succeed)
                                    }
                                    self.tableView.reloadData()
            }, onCancelTap: nil)
        } else {
            item.isAttention = true
            //关注
            let req = FocusUserReq()
            req.beenUserId = item.userId
            Session.request(req) { (error, resp) in
                guard error == nil else {
                    mm_showToast(error!.localizedDescription)
                    return
                }
                mm_showToast("關注成功!", type: .succeed)
            }
            tableView.reloadData()
        }
    }
    
    func focusCell(cell: FocusCell, avatar: UIImageView) {
        print(#function)
        guard let item = cell.item else {
            return
        }
        let vc = UsersDynamicVC()
        vc.userId = item.userId
        self.navigationController?.pushViewController(vc, animated: true)
    }
}


