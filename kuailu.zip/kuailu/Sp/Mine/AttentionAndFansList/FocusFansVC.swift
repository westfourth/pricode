//
//  FocusFansVC.swift
//  Sp
//
//  Created by mac on 2020/4/7.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit
import JXSegmentedView

class FocusFansVC: UIViewController {
    
    lazy var pagingView: JXPagingView = JXPagingListRefreshView(delegate: self)
    
    let dataSource: JXSegmentedTitleDataSource = JXSegmentedTitleDataSource()
    
    lazy var segmentedView: JXSegmentedView = JXSegmentedView(frame: CGRect(x: 80, y: 0, width: UIScreen.main.bounds.size.width - 160, height: CGFloat(segmentH)))
    
    var segmentH: CGFloat = 44
    
    var userId:Int = -1000
    
    var navigationTitle: String = ""
    
    var currentIndex:Int = 0 {
        didSet {
            
        }
    }
    
    /// 作品 喜欢已购买
    var controllers:[UIViewController & JXPagingViewListViewDelegate] = [UIViewController & JXPagingViewListViewDelegate]()
    
    var titles:[String] = ["關注 0","粉絲 0"] {
        didSet {
            self.segmentedView.reloadData()
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.navigationBar.setBackgroundImage(UIImage(named: "navi_backImage"), for: UIBarMetrics.default)
        self.navigationController?.navigationBar.shadowImage = UIImage()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = RGB(0xff141516)
        navigationItem.title = navigationTitle
        self.edgesForExtendedLayout = .bottom
        let focusVC = AttentionVC()
        focusVC.userId = userId
        
        let fansVC = FansVC()
        fansVC.userId = userId
        
        controllers = [focusVC,fansVC]
        configurePagingView()
        
        DispatchQueue.main.asyncAfter(deadline: .now(), execute: {
            self.segmentedView.selectItemAt(index: self.currentIndex)
        })
    }
    
    func indicators()->[JXSegmentedIndicatorLineView] {
        var items = [JXSegmentedIndicatorLineView]()
        for _ in 0..<2 {
            let lineView = JXSegmentedIndicatorLineView()
            lineView.indicatorColor = RGB(0xffC1C1C1)
            lineView.indicatorWidth = segmentedView.width / 2.0
            lineView.clipsToBounds = true
            lineView.layer.cornerRadius = 1.0
            items.append(lineView)
        }
        return items
    }
    
    func configurePagingView() {
        dataSource.titles = titles
        dataSource.titleSelectedColor = .white
        dataSource.titleNormalColor = UIColor.gray
        dataSource.isTitleColorGradientEnabled = true
        dataSource.isTitleZoomEnabled = true
        dataSource.titleNormalFont = UIFont.systemFont(ofSize: 16, weight: UIFont.Weight.regular)
        dataSource.titleSelectedFont = UIFont.systemFont(ofSize: 16, weight: UIFont.Weight.regular)
        dataSource.isTitleZoomEnabled = false
        segmentedView.backgroundColor = .clear
        segmentedView.delegate = self
        segmentedView.isContentScrollViewClickTransitionAnimationEnabled = false
        segmentedView.dataSource = dataSource
        
        segmentedView.indicators = indicators()
        
        pagingView.mainTableView.gestureDelegate = self
        self.view.addSubview(pagingView)
        
        pagingView.mainTableView.backgroundColor = .clear
        pagingView.frame = CGRect(x: 0, y: 0, width: self.view.bounds.size.width, height: view.height - segmentH - (IS_IPHONEX ? 44 : 20))
        segmentedView.listContainer = pagingView.listContainerView
        
        //扣边返回处理，下面的程式码要加上
        pagingView.listContainerView.scrollView.panGestureRecognizer.require(toFail: self.navigationController!.interactivePopGestureRecognizer!)
        pagingView.mainTableView.panGestureRecognizer.require(toFail: self.navigationController!.interactivePopGestureRecognizer!)
    }
}


extension FocusFansVC: JXPagingViewDelegate {
    
    func tableHeaderViewHeight(in pagingView: JXPagingView) -> Int {
        return 0
    }
    
    func tableHeaderView(in pagingView: JXPagingView) -> UIView {
        return UIView()
    }
    
    func heightForPinSectionHeader(in pagingView: JXPagingView) -> Int {
        return Int(segmentH)
    }
    
    func viewForPinSectionHeader(in pagingView: JXPagingView) -> UIView {
        return segmentedView
    }
    
    func numberOfLists(in pagingView: JXPagingView) -> Int {
        return self.controllers.count
    }
    
    func pagingView(_ pagingView: JXPagingView, initListAtIndex index: Int) -> JXPagingViewListViewDelegate {
        return  self.controllers[index]
    }
}

extension FocusFansVC: JXSegmentedViewDelegate {
    func segmentedView(_ segmentedView: JXSegmentedView, didSelectedItemAt index: Int) {
        self.navigationController?.interactivePopGestureRecognizer?.isEnabled = true
    }
}

extension FocusFansVC: JXPagingMainTableViewGestureDelegate {
    func mainTableViewGestureRecognizer(_ gestureRecognizer: UIGestureRecognizer, shouldRecognizeSimultaneouslyWith otherGestureRecognizer: UIGestureRecognizer) -> Bool {
        //禁止segmentedView左右滑动的时候，上下和左右都可以滚动
        if otherGestureRecognizer == segmentedView.collectionView.panGestureRecognizer {
            return false
        }
        return gestureRecognizer.isKind(of: UIPanGestureRecognizer.self) && otherGestureRecognizer.isKind(of: UIPanGestureRecognizer.self)
    }
}
