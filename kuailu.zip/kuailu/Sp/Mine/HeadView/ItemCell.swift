//
//  ItemCell.swift
//  Sp
//
//  Created by mac on 2020/2/26.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class ItemCell: UICollectionViewCell {

    @IBOutlet weak var logo: UIImageView!
    
    @IBOutlet weak var name: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        name.text = "VIP\(Sensitive.hui)"
    }
    
    func set(_imageName:String,_title:String) {
        self.logo.image = UIImage(named: _imageName)
        self.name.text = _title
    }

}
