//
//  HeadView.swift
//  Sp
//
//  Created by mac on 2020/2/26.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit
import CoreText

@IBDesignable
class HeadView: UIView,UICollectionViewDataSource,UICollectionViewDelegate {
    
    private static let formatDate:DateFormatter = {
        let dateFormat = DateFormatter()
        dateFormat.dateFormat = "yyyy-MM-dd"
        return dateFormat
    }()
    
    weak var delegate: MineVC?
    
    @IBOutlet weak var logo: UIImageView!
    
    @IBOutlet weak var nickName: UILabel!
    
    @IBOutlet weak var userID: UILabel!
    
    @IBOutlet weak var watchTimes: UILabel!
    
    @IBOutlet weak var collectionView: UICollectionView!
    
    @IBOutlet weak var layout: UICollectionViewFlowLayout!
    
    @IBOutlet weak var focus: UILabel!
    
    @IBOutlet weak var fans: UILabel!
    
    @IBOutlet weak var invite: UILabel!
    
    @IBOutlet weak var vipIcon: UIImageView!
    
    @IBOutlet weak var membership: UIImageView!
    
    private static let avatarImg: UIImage? = {
        return Sensitive.avatar
    }()
    
    let titles = [
        "\(Sensitive.chong)中心",
        "我的\(Sensitive.qian)",
        "分享邀請",
        "加群交流",
        "应用中心"]
    
    var user:UserBase? {
        didSet {
            guard  let item = user else {
                return;
            }
            self.logo.kf.setImage(with:item.logo, placeholder: HeadView.avatarImg, options: [.transition(.fade(0.25))])
            self.nickName.text = item.nickName
            self.userID.text = "用户ID：" + String(item.userId)
            let isVip = item.freeWatches == -1
            var dateStr = "vip總時長 "
            if item.expiredVip != nil {
                dateStr = dateStr + HeadView.formatDate.string(from: item.expiredVip!)
            }
            if isVip {
                let attri = NSMutableAttributedString(string: dateStr)
                attri.addAttributes([NSAttributedString.Key.font : UIFont.systemFont(ofSize: 13, weight: .medium)], range: NSRange(location: 0, length: "vip總時長 ".count))
                attri.addAttributes([NSAttributedString.Key.font : UIFont.systemFont(ofSize: 12, weight: .medium)], range: NSRange(location: dateStr.count - HeadView.formatDate.string(from: item.expiredVip!).count, length: HeadView.formatDate.string(from: item.expiredVip!).count))
                attri.addAttributes([NSAttributedString.Key.foregroundColor : UIColor.white], range: NSRange(location: 0, length: dateStr.count))
                watchTimes.attributedText = attri
            } else {
                watchTimes.text = "剩餘觀看次數  \(item.freeWatches - item.watched >= 0 ? item.freeWatches - item.watched: 0)/\(item.freeWatches)"
            }
            //            self.watchTimes.text = isVip ? "\(Sensitive.hui)有效期至\(HeadView.formatDate.string(from: item.expiredVip!))" : "今日观看\(item.freeWatches - item.watched >= 0 ? item.freeWatches - item.watched: 0)/\(item.freeWatches)"
            membership.image = UIImage(named: isVip ? "btn_续费会员" : "btn_成为会员")
            self.focus.attributedText = attribute(item.ua, title: "關注")
            self.fans.attributedText = attribute(item.bu, title: "粉絲")
            self.invite.attributedText = attribute(item.inviteUserNum, title: "邀請")
            let iconName = item.level <= 6 ? "v\(item.level)" : "v1"
            self.vipIcon.image = UIImage(named: iconName)
        }
    }
    
    @IBAction func vipTapAction(_ sender: Any) {
        delegate?.gotoLevelVC()
    }
    
    func attribute(_ count:Int,title:String)-> NSMutableAttributedString {
        let num = num2TenThousandStrFormat(count)
        let x = NSMutableAttributedString(string: "\(num) \(title)")
        x.addAttributes([NSAttributedString.Key.font :UIFont.systemFont(ofSize: 16, weight: .medium), NSAttributedString.Key.foregroundColor:UIColor.white,
        ], range: NSRange(location: 0, length: num.count))
        x.addAttributes([NSAttributedString.Key.font : UIFont.systemFont(ofSize: 14),NSAttributedString.Key.foregroundColor:UIColor.gray], range: NSRange(location: "\(num) \(title)".count - 2, length: 2))
        return x
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        //        let maskPath = UIBezierPath.init(roundedRect: self.login.bounds,
        //        byRoundingCorners: [UIRectCorner.topLeft, UIRectCorner.bottomLeft],
        //        cornerRadii: CGSize(width: 15, height: 15))
        //        let maskLayer = CAShapeLayer()
        //        maskLayer.frame = self.login.bounds
        //        maskLayer.path = maskPath.cgPath
        //        self.login.layer.mask = maskLayer
        logo.image = HeadView.avatarImg
        
        layout.sectionInset = UIEdgeInsets(top: 0, left: 0, bottom: 14, right: 0)
        layout.minimumInteritemSpacing = 0
        let width: CGFloat = (UIScreen.main.bounds.width - 16 * 2) / 5
        layout.itemSize = CGSize(width: width, height: 74)
        
        self.collectionView.register(UINib(nibName: "ItemCell", bundle: Bundle.main), forCellWithReuseIdentifier: "ItemCell")
        
        self.collectionView.isHidden = Defaults.didPassReview ? false : true
        
    }
    
    @IBAction func editInfoAction() {
        delegate?.gotoUsersDynamicVC()
    }
    
    @IBAction func focusAction() {
        delegate?.gotoFocusFansVC()
    }
    
    @IBAction func fansAction() {
        delegate?.gotoFocusFansVC(true)
    }
    
    @IBAction func vipAction(_ sender: Any) {
        delegate?.gotoVipVC()
    }
    
    
    override init(frame: CGRect) {
        super.init(frame: frame)
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    //_______________________________________________________________________________________________________________
    // MARK: - UCIollectionViewDataSource&Delegate
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return titles.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "ItemCell", for: indexPath) as! ItemCell
        cell.set(_imageName: "mine_\(indexPath.row)", _title: titles[indexPath.row])
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        switch indexPath.item {
        case 0:
            delegate?.gotoVipVC()
        case 1:
            delegate?.gotoWalletVC()
        case 2:
            delegate?.gotoShare2VC()
        case 3:
            delegate?.gotoGroupVC()
        case 4:
            delegate?.gotoAppCenter()
        default:
            break;
        }
    }
}

