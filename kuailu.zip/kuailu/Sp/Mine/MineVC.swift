//
//  MineVC.swift
//  Sp
//
//  Created by mac on 2020/2/29.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

import JXSegmentedView

class MineVC: UIViewController, MessageViewDelegate {
    
    func messageAction() {
        let vc = MessageVC()
        vc.hidesBottomBarWhenPushed = true
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    static let indicatorMargin: CGFloat = {
        return UIScreen.main.bounds.width < 414 ? 23.5 : 30
    }()
    
    private static let avatarImg: UIImage? = {
        return Sensitive.avatar
    }()
    
    private static let animationOption: KingfisherOptionsInfo = {
        return [.transition(.fade(0.25))]
    }()
    
    let naviHeight = UIApplication.shared.keyWindow!.naviHeight()
    
    let topSafeMargin = UIApplication.shared.keyWindow!.insets().top
    
    lazy var pagingView: JXPagingView = JXPagingListRefreshView(delegate: self)
    
    let dataSource: JXSegmentedTitleDataSource = JXSegmentedTitleDataSource()
    
    lazy var segmentedView: JXSegmentedView = JXSegmentedView(frame: CGRect(x: 0, y: 0, width: UIScreen.main.bounds.size.width, height: CGFloat(headerInSectionHeight)))
    
    private var tabBarLabelArr =  ["作品 0","喜歡 0","已\(Sensitive.gou) 0"]
    
    private var tabBarLabelInstanceArr: [UILabel] =  []
    
    private let titles =  ["00000000","00000000","00000000"]
    
    var user:UserBase?
    /// 作品 喜欢已购买
    var controllers:[UIViewController & JXPagingViewListViewDelegate] = [UIViewController & JXPagingViewListViewDelegate]()
    
    
    var headHeight: Int = 0
    var headerInSectionHeight: Int = 44
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        headHeight = Defaults.didPassReview ? Int(naviHeight + CGFloat(270)) :  Int(naviHeight + CGFloat(255 - 108))
        
        view.backgroundColor = RGB(0xff141516)
        
        configurePagingView()
        
        pagingView.pinSectionHeaderVerticalOffset = Int(naviHeight)
        
        view.addSubview(naviView)
        naviView.frame = CGRect(x: 0, y: 0, width: self.view.bounds.size.width, height: naviHeight)
        
        view.addSubview(onlineSer)
        let size = CGSize(width: 61, height: 63)
        let tabbarHeight = UIApplication.shared.windows.first!.safeAreaInsets.bottom > 0 ? 83:49
        onlineSer.frame = CGRect(x: view.bounds.width - 12 - size.width , y: view.bounds.height - 30 - size.height - CGFloat(tabbarHeight) , width: size.width, height: size.height)
        loadAppsData()
    }
    
    var appsUrl:URL?
    
    func loadAppsData()  {
        Session.request(MyAppsReq()) { (e, resp) in
            guard e == nil else {return}
            guard let item = resp as?MyAppsItem,let url = item.url else {return}
            self.appsUrl = url
        }
    }
    
    //MARK:-配置controllers
    func configureControllers() {
        var user = UserBase()
        if self.user != nil {
            user = self.user!
        } else {
            if let item = NetDefaults.userInfo {
                user = item
            }
        }
        
        if user.userId != 0 {
            let userId = user.userId
            
            let publishedVC = PublishedListVC()
            publishedVC.userId = userId
            
            
            let collectionVC = CollectionListVC()
            collectionVC.userId = userId
            
            let purchasedVC = PurchasedListVC()
            purchasedVC.userId = userId
            
            controllers = [publishedVC,collectionVC,purchasedVC]
            self.pagingView.reloadData()
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.setNavigationBarHidden(true, animated: animated)
        loadData()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        self.navigationController?.interactivePopGestureRecognizer?.isEnabled = true
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.navigationController?.setNavigationBarHidden(false, animated: animated)
    }
    
    private func renderTabBarView() {
        let width = UIScreen.main.bounds.width / 3
        for i in 0..<tabBarLabelArr.count {
            let tabBar = getTabBarView(index: i)
            segmentedView.addSubview(tabBar)
            segmentedView.sendSubviewToBack(tabBar)
            tabBar.snp.makeConstraints { (make) in
                make.top.height.equalToSuperview()
                make.width.equalTo(width)
                switch i {
                case 0:
                    make.left.equalToSuperview()
                case 1:
                    make.centerX.equalToSuperview()
                default:
                    make.right.equalToSuperview()
                }
            }
            tabBarLabelInstanceArr.append(tabBar)
        }
    }
    
    private func getTabBarView(index: Int)-> UILabel {
        let label = UILabel()
        label.text = tabBarLabelArr[index]
        label.textAlignment = .center
        label.font = UIFont.pingFangRegular(16)
        label.textColor = .white
        label.isUserInteractionEnabled = true
        return label
    }
    
    // MARK: -载入个人信息资料
    func loadData() {
        let req  = FetchUserInfoReq()
        Session.request(req) { (error, resp) in
            guard error == nil  else {
                if let user = NetDefaults.userInfo {
                    self.user = user
                    self.infoView.user = user
                    self.logo.kf.setImage(with: user.logo, placeholder: MineVC.avatarImg, options: MineVC.animationOption)
                    self.nickname.text = user.nickName
                    
                    let length = self.getLableWidth(content: user.nickName, font: UIFont.boldSystemFont(ofSize: 16), height: 30)
                    let X = (UIScreen.main.bounds.size.width - 20 - 4 - length ) / 2.0
                    self.logo.frame = CGRect(x: X, y: self.topSafeMargin + 12, width: 20, height: 20)
                    self.nickname.frame = CGRect(x: X + 24, y: self.topSafeMargin + 7, width:length , height: 30)
                    if self.controllers.isEmpty {
                        self.configureControllers()
                    }
                }
                return
            }
            if let item = resp as? UserBase {
                Defaults.currentLevel = item.level
                self.infoView.user = item
                self.user = item
                self.logo.kf.setImage(with: item.logo, placeholder: MineVC.avatarImg, options: MineVC.animationOption)
                self.nickname.text = item.nickName
                
                let length = self.getLableWidth(content: item.nickName, font: UIFont.boldSystemFont(ofSize: 16), height: 30)
                let X = (UIScreen.main.bounds.size.width - 20 - 4 - length ) / 2.0
                self.logo.frame = CGRect(x: X, y: self.topSafeMargin + 12, width: 20, height: 20)
                self.nickname.frame = CGRect(x: X + 24, y: self.topSafeMargin + 7, width:length , height: 30)
                
                self.tabBarLabelInstanceArr[0].text  = "作品 \(item.worksNum)"
                self.tabBarLabelInstanceArr[1].text = "喜歡 \(item.favoritesNum)"
                self.tabBarLabelInstanceArr[2].text = "已\(Sensitive.gou) \(item.purVideosNum)"
                
                if self.controllers.isEmpty {
                    self.configureControllers()
                }
                //                self.dataSource.titles = self.titles
                //                self.segmentedView.reloadData()
            }
        }
    }
    
    //MARK:-暂时屏蔽
    func bindAlert(_ item:UserBase) {
        if item.mobile == "" {
            if !Defaults.alertBind && Defaults.didPassReview {
                Alert.showCommonAlert(parentView: self.view,
                                      contentText: "為了您的賬號安全，請綁定手機，成功綁定後可立即獲得1天免費VIP",
                                      cancelText: "暫不綁定",
                                      confirmText: "立即綁定",
                                      onConfirmTap: {
                                        print(#function)
                                        let VC = LoginVC()
                                        VC.hidesBottomBarWhenPushed = true
                                        self.navigationController?.pushViewController(VC, animated: true)
                }, onCancelTap: nil)
                Defaults.alertBind = true
            }
        }
    }
    
    private func getLableWidth(content:String, font:UIFont,height:CGFloat) -> CGFloat {
        let size = CGSize.init(width: CGFloat(MAXFLOAT), height: height)
        let dic = [NSAttributedString.Key.font:font]
        let cString = content.cString(using: String.Encoding.utf8)
        let str = String.init(cString: cString!, encoding: String.Encoding.utf8)
        let strSize = str?.boundingRect(with: size, options: .usesLineFragmentOrigin, attributes: dic, context:nil).size
        return strSize?.width ?? 0
    }
    
    func indicators()->[JXSegmentedIndicatorLineView] {
        let width = (UIScreen.main.bounds.size.width - 4) / 3
        var items = [JXSegmentedIndicatorLineView]()
        for _ in 0..<3 {
            let lineView = JXSegmentedIndicatorLineView()
            lineView.indicatorColor = RGB(0xffC1C1C1)
            lineView.indicatorWidth = width
            lineView.lineStyle = .lengthenOffset
            //                getLableWidth(content: self.titles[i], font: UIFont.systemFont(ofSize: 15, weight: UIFont.Weight.medium), height: 3.0)
            lineView.clipsToBounds = true
            lineView.layer.cornerRadius = 1.0
            items.append(lineView)
        }
        return items
    }
    
    func configurePagingView() {
        renderTabBarView()
        dataSource.titles = titles
        dataSource.titleSelectedColor = .clear
        dataSource.titleNormalColor = .clear
        //        dataSource.isTitleColorGradientEnabled = true
        //        dataSource.isTitleZoomEnabled = true
        segmentedView.isContentScrollViewClickTransitionAnimationEnabled = false
        dataSource.titleNormalFont = UIFont.pingFangMedium(16)
        dataSource.titleSelectedFont = UIFont.pingFangMedium(16)
        segmentedView.backgroundColor = RGB(0x141516)
        segmentedView.delegate = self
        segmentedView.dataSource = dataSource
        
        segmentedView.indicators = indicators()
        segmentedView.contentEdgeInsetRight = MineVC.indicatorMargin
        segmentedView.contentEdgeInsetLeft = MineVC.indicatorMargin
        
        pagingView.mainTableView.gestureDelegate = self
        pagingView.backgroundColor = .clear
        self.view.addSubview(pagingView)
        pagingView.mainTableView.backgroundColor = .clear
        pagingView.frame = CGRect(x: 0, y: 0, width: self.view.bounds.size.width, height: self.view.bounds.size.height - kBottom)
        
        segmentedView.listContainer = pagingView.listContainerView
        
        
        
        //扣边返回处理，下面的程式码要加上
        pagingView.listContainerView.scrollView.panGestureRecognizer.require(toFail: self.navigationController!.interactivePopGestureRecognizer!)
        pagingView.mainTableView.panGestureRecognizer.require(toFail: self.navigationController!.interactivePopGestureRecognizer!)
    }
    
    //MARK:-头部view
    lazy var headView : UIView = {
        let view1 = UIView(frame: CGRect(x: 0, y: 0, width: Int(UIScreen.main.bounds.size.width), height: headHeight))
        
        view1.backgroundColor = rgb(20, 21, 22)
        view1.addSubview(topSetting)
        topSetting.frame = CGRect(x:UIScreen.main.bounds.size.width - 15 - 23, y:self.topSafeMargin + 6, width: 23, height: 23)
        
        view1.addSubview(messageView)
        messageView.frame = CGRect(x: UIScreen.main.bounds.size.width - 15 - 23 - 15 - 38, y: self.topSafeMargin + 4, width: 38, height: 25)
        
        view1.addSubview(infoView)
        infoView.frame = CGRect(x: 0, y: naviHeight, width: UIScreen.main.bounds.size.width, height: CGFloat(headHeight) - naviHeight)
        return view1
    }()
    
    lazy var messageView:MessageView = {
        let v = Bundle.main.loadNibNamed("MessageView", owner: nil, options: [:])?.first as! MessageView
        v.isHidden = false
        v.delegate = self
        return v
    }()
    
    
    lazy var messageView2:MessageView = {
        let v = Bundle.main.loadNibNamed("MessageView", owner: nil, options: [:])?.first as! MessageView
        v.isHidden = false
        v.delegate = self
        return v
    }()
    
    lazy var onlineSer:UIImageView = {
        let v = UIImageView(image: UIImage(named: "online_service"))
        let tap = UITapGestureRecognizer(target: self, action:#selector(self.messageAction))
        v.isUserInteractionEnabled = true
        v.addGestureRecognizer(tap)
        return v
    }()
    
    //MARK:-信息view
    lazy var infoView:HeadView = {
        let view =  Bundle.main.loadNibNamed("HeadView", owner: nil, options: nil)?.first as! HeadView
        view.isUserInteractionEnabled = true
        view.delegate = self
        return view
    }()
    
    //MARK:-导航栏view
    lazy var naviView:UIView = {
        let naviFakeView = UIView()
        naviFakeView.alpha = 0
        naviFakeView.backgroundColor = RGB(0xff141516)
        naviFakeView.frame = CGRect(x: 0, y: 0, width: self.view.bounds.size.width, height: naviHeight)
        naviFakeView.addSubview(self.logo)
        naviFakeView.addSubview(self.nickname)
        naviFakeView.addSubview(setting)
        setting.frame = CGRect(x:UIScreen.main.bounds.size.width - 15 - 23, y: self.topSafeMargin + 10, width: 23, height: 23)
        naviFakeView.addSubview(messageView2)
        messageView2.frame = CGRect(x:UIScreen.main.bounds.size.width - 15 - 23 - 38 - 15, y: self.topSafeMargin + 8, width: 38, height: 25)
        
        nickname.snp.makeConstraints { (make) in
            make.centerY.equalTo(logo)
            make.left.equalTo(logo.snp.right).offset(6)
            make.right.equalTo(setting.snp.left).offset(-4)
        }
        return naviFakeView
    }()
    
    //MARK:-暱称
    lazy var nickname:UILabel = {
        let name = UILabel()
        name.textColor = UIColor.white
        name.font = UIFont.boldSystemFont(ofSize: 16)
        name.numberOfLines = 1
        return name
    }()
    
    //MARK:-头像
    lazy var logo:UIImageView = {
        let img = UIImageView()
        img.clipsToBounds = true
        img.layer.cornerRadius = 10
        img.image = UIImage(named: "beatuty")
        return img
    }()
    
    //MARK:-设定按钮
    lazy var setting:UIButton = {
        let setting = UIButton()
        setting.setImage(UIImage(named: "setting"), for: .normal)
        setting.addTarget(self, action: #selector(self.settingAction), for:.touchUpInside)
        return setting
    }()
    
    //MARK:-设定按钮
    lazy var topSetting:UIButton = {
        let setting = UIButton()
        setting.setImage(UIImage(named: "setting"), for: .normal)
        setting.addTarget(self, action: #selector(self.settingAction), for:.touchUpInside)
        return setting
    }()
    
    
    func mainTableViewDidScroll(_ scrollView: UIScrollView) {
        let thresholdDistance: CGFloat = 100
        var percent = scrollView.contentOffset.y/thresholdDistance
        percent = max(0, min(1, percent))
        naviView.alpha = percent
    }
    
    @objc func settingAction() {
        let settingVC = SettingVC()
        settingVC.hidesBottomBarWhenPushed = true
        self.navigationController?.pushViewController(settingVC, animated: true)
    }
}


extension MineVC: JXPagingViewDelegate {
    
    func tableHeaderViewHeight(in pagingView: JXPagingView) -> Int {
        return headHeight
    }
    
    func tableHeaderView(in pagingView: JXPagingView) -> UIView {
        return headView
    }
    
    func heightForPinSectionHeader(in pagingView: JXPagingView) -> Int {
        return headerInSectionHeight
    }
    
    func viewForPinSectionHeader(in pagingView: JXPagingView) -> UIView {
        return segmentedView
    }
    
    func numberOfLists(in pagingView: JXPagingView) -> Int {
        return self.controllers.count
    }
    
    func pagingView(_ pagingView: JXPagingView, initListAtIndex index: Int) -> JXPagingViewListViewDelegate {
        return  self.controllers[index]
    }
    
    func segmentedView(_ segmentedView: JXSegmentedView, didScrollSelectedItemAt index: Int) {
        segmentedView.selectItemAt(index: index)
    }
}

extension MineVC: JXSegmentedViewDelegate {
    func segmentedView(_ segmentedView: JXSegmentedView, didSelectedItemAt index: Int) {
        self.navigationController?.interactivePopGestureRecognizer?.isEnabled = true
    }
}

extension MineVC: JXPagingMainTableViewGestureDelegate {
    func mainTableViewGestureRecognizer(_ gestureRecognizer: UIGestureRecognizer, shouldRecognizeSimultaneouslyWith otherGestureRecognizer: UIGestureRecognizer) -> Bool {
        //禁止segmentedView左右滑动的时候，上下和左右都可以滚动
        if otherGestureRecognizer == segmentedView.collectionView.panGestureRecognizer {
            return false
        }
        return gestureRecognizer.isKind(of: UIPanGestureRecognizer.self) && otherGestureRecognizer.isKind(of: UIPanGestureRecognizer.self)
    }
}


extension MineVC {
    //个人主页
    func gotoUsersDynamicVC() {
        guard let user = NetDefaults.userInfo else {return}
        let vc = UsersDynamicVC()
        vc.userId = user.userId
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    func gotoAppsVC() {
        guard appsUrl != nil else {
            mm_showToast("獲取應用中心地址失敗!",type: .warning)
            return
        }
        UIApplication.shared.open(appsUrl!, options: [:], completionHandler: nil)
    }
    
    //关注粉丝列表，默认为关注
    func gotoFocusFansVC(_ fan: Bool = false) {
        guard let user = self.user else {
            return
        }
        let VC = FocusFansVC()
        if let nickname = NetDefaults.userInfo?.nickName {
            VC.navigationTitle = nickname
        }
        VC.currentIndex = fan ? 1 : 0
        VC.titles = ["關注 \(user.ua)","粉絲 \(user.bu)"]
        VC.hidesBottomBarWhenPushed = true
        self.navigationController?.pushViewController(VC, animated: true)
    }
    
    //登陆
    func gotoLoginVC() {
        let VC = LoginVC()
        VC.hidesBottomBarWhenPushed = true
        self.navigationController?.pushViewController(VC, animated: true)
    }
    
    //vip会员
    func gotoVipVC() {
        VipChargeTipVC.isFromVideoPlayList = false
        self.navigationController?.pushViewController(Vip2VC(), animated: true)
    }
    
    //钱包
    func gotoWalletVC() {
        let VC = WalletVC()
        VC.hidesBottomBarWhenPushed = true
        self.navigationController?.pushViewController(VC, animated: true)
    }
    
    //全民代理
    func gotoShare2VC() {
        //        let VC = ShareViewController()
        let VC = Share2VC()
        VC.hidesBottomBarWhenPushed = true
        self.navigationController?.pushViewController(VC, animated: true)
    }
    
    //加群交流
    func gotoGroupVC() {
        let VC = GroupVC()
        VC.hidesBottomBarWhenPushed = true
        self.navigationController?.pushViewController(VC, animated: true)
    }
    
    //会员等级
    func gotoLevelVC() {
        let VC = LevelVC()
        VC.hidesBottomBarWhenPushed = true
        self.navigationController?.pushViewController(VC, animated: true)
    }
    
    //应用中心
    func gotoAppCenter() {
        // app应用中心
        guard appsUrl != nil else {
            mm_showToast("獲取應用中心地址失敗!",type: .warning)
            return
        }
        UIApplication.shared.open(appsUrl!, options: [:], completionHandler: nil)
    }
}

extension UIWindow {
    func insets() -> UIEdgeInsets {
        if #available(iOS 11.0, *) {
            let safeAreaInsets: UIEdgeInsets = self.safeAreaInsets
            if safeAreaInsets.bottom > 0 {
                return safeAreaInsets
            }
            return UIEdgeInsets.init(top: 20, left: 0, bottom: 0, right: 0)
        }
        return UIEdgeInsets.init(top: 20, left: 0, bottom: 0, right: 0)
    }
    
    func naviHeight() -> CGFloat {
        let statusBarHeight = insets().top
        return statusBarHeight + 44
    }
}

