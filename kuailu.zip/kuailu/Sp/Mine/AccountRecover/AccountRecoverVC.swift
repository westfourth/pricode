//
//  AccountRecoverVC.swift
//  Sp
//
//  Created by mac on 2020/8/29.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class AccountRecoverVC: UIViewController {
    
    @IBOutlet weak var tableView: UITableView!
    
    var onlineURL:URL?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "找回賬號"
        view.backgroundColor = RGB(0xff141516)
        tableView.register(UINib(nibName: "SettingCell", bundle: Bundle.main), forCellReuseIdentifier: "SettingCell")
        loadOnlineURL()
    }
    
    func loadOnlineURL() {
        Session.request(OnLineWebReq()) { (error, resp) in
            guard error == nil else {
                return
            }
            if resp is OnLineWebItem {
                let item = resp as! OnLineWebItem
                self.onlineURL = item.signUrl
            }
        }
    }
    
    
    @IBAction func recoverAction(_ sender: Any) {
        self.navigationController?.pushViewController(LoginVC(), animated: true)
    }
}

// MARK: -UITableViewDataSource && Delegate
extension AccountRecoverVC:UITableViewDataSource,UITableViewDelegate {
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "SettingCell") as! SettingCell
        cell.icon.isHidden = true
        cell.isAccountRecover = true
        cell.name.text = indexPath.row == 0 ? "賬號憑證找回":"聯繫客服找回"
        return cell
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 2
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if indexPath.row == 0  {
            self.navigationController?.pushViewController(RecoverVC(), animated: true)
        } else {
            //在线客服
            guard self.onlineURL != nil else {
                mm_showToast("在線客服地址獲取失敗!")
                return
            }
            let webVC = WebVC()
            webVC.webviewUrl = self.onlineURL!
            self.navigationController?.pushViewController(webVC, animated: true)
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 44
    }
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return .leastNonzeroMagnitude
    }
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return .leastNonzeroMagnitude
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        return nil
    }
    
    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        return nil
    }
}
