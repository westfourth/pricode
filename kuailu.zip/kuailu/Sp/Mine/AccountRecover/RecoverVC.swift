//
//  RecoverVC.swift
//  Sp
//
//  Created by mac on 2020/9/2.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit
import CoreImage
class RecoverVC: UIViewController {
    @IBOutlet weak var tableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "賬號憑證找回"
        view.backgroundColor = RGB(0xff141516)
        tableView.register(UINib(nibName: "SettingCell", bundle: Bundle.main), forCellReuseIdentifier: "SettingCell")
    }
}


// MARK: -UITableViewDataSource && Delegate
extension RecoverVC:UITableViewDataSource,UITableViewDelegate {
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "SettingCell") as! SettingCell
        cell.icon.isHidden = true
        cell.isAccountRecover = true
        cell.name.text = "手機相冊上傳憑證"
        return cell
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let imageVC = UIImagePickerController()
        imageVC.modalPresentationStyle = .fullScreen
        if #available(iOS 13.0, *) {
            imageVC.isModalInPresentation = true
        }
        imageVC.delegate = self
        imageVC.allowsEditing = false
        imageVC.sourceType = .photoLibrary
        GlobalSettings.setImagePickerNatiBarAttribute()
        present(imageVC, animated: true, completion: nil)
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 44
    }
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return .leastNonzeroMagnitude
    }
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return .leastNonzeroMagnitude
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        return nil
    }
    
    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        return nil
    }
}


extension RecoverVC: UIImagePickerControllerDelegate,UINavigationControllerDelegate {
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true, completion: nil)
        GlobalSettings.resetNaviBarAttribute()
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        let image = info[UIImagePickerController.InfoKey.originalImage] as! UIImage
        GlobalSettings.resetNaviBarAttribute()
        picker.dismiss(animated: true, completion: nil)
        let  detector = CIDetector(ofType:CIDetectorTypeQRCode , context: nil, options: [CIDetectorAccuracy:CIDetectorAccuracyHigh])
        guard  let features = detector?.features(in: CIImage(cgImage: image.cgImage!)) else{return}
        guard !features.isEmpty, let feature = features.first as? CIQRCodeFeature, let content = feature.messageString else {
            return
        }
        print("result = " + content)
        guard content.contains("*") == true else {return}
        let array  = content.components(separatedBy: "*") as! [String]
        guard array.count == 2 else {
            return
        }
        Alert.showLoading(parentView: self.view)
        let req = RecoverAccountReq()
        req.deviceId = array.first!
        req.userId = Int(array[1]) ?? 0
        Session.request(req) { (e, resp) in
            Alert.hideLoading()
            guard e == nil else {return}
            mm_showToast("恭喜您，賬號已恢復！", type: .succeed, duration: 2.0) {
                self.navigationController?.popToRootViewController(animated: true)
            }
        }
    }
}

