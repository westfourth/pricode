//
//  AccountCerVC.swift
//  Sp
//
//  Created by mac on 2020/8/31.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class AccountCerVC: UIViewController {
    
    var isLunch = false
        
    @IBOutlet weak var cerView: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "賬號憑證"
        view.backgroundColor = RGB(0xff141516)
        if UIScreen.main.bounds.width <= 375 {
            codeHeightCons.constant = view.bounds.width - 200
            topCons.constant = 0
            saveTopCons.constant = 5
            codeTopCons.constant  = 80
        }
        if let user = NetDefaults.userInfo {
            let combine = DeviceId.deviceId + "*" + "\(user.userId)"
            code.image = creatQRCodeImage(text: combine, WH: UIScreen.main.bounds.width - 200)
        }
        
        cerView.image = UIImage(named: "account_cer")

        if isLunch {
            self.navigationItem.leftBarButtonItem = UIBarButtonItem(image: UIImage(named: "navigation_back"), style: .plain, target: self, action: #selector(self.backAction))
        }
    }
    
    @objc func backAction() {
        self.navigationController?.dismiss(animated: true, completion: nil)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.navigationBar.setBackgroundImage(UIImage(named: "navi_backImage"), for: UIBarMetrics.default)
        self.navigationController?.navigationBar.shadowImage = UIImage()
    }
    
    @IBOutlet weak var code: UIImageView!
    @IBOutlet weak var codeHeightCons: NSLayoutConstraint!
    @IBOutlet weak var topCons: NSLayoutConstraint!
    @IBOutlet weak var codeTopCons: NSLayoutConstraint!
    
    @IBOutlet weak var saveTopCons: NSLayoutConstraint!
    @IBAction func saveAction(_ sender: Any) {
        UIGraphicsBeginImageContextWithOptions(CGSize(width: UIScreen.main.bounds.width, height: view.bounds.height), true, UIScreen.main.scale)
        view.layer.render(in: UIGraphicsGetCurrentContext()!)
        let allImage = UIGraphicsGetImageFromCurrentImageContext()!
        let rect = CGRect(x: 0, y: 0, width: UIScreen.main.bounds.size.width * UIScreen.main.scale, height: view.bounds.height  * UIScreen.main.scale)
        let partImage = UIImage(cgImage: allImage.cgImage!.cropping(to: rect)!, scale: UIScreen.main.scale, orientation: .up)
        UIImageWriteToSavedPhotosAlbum(partImage, self, #selector(saveImage(image:didFinishSavingWithError:contextInfo:)), nil)
        UIGraphicsEndImageContext()
    }
    
    //MARK:- 生成二维码
      private func creatQRCodeImage(text: String, WH: CGFloat) -> UIImage{
          
          //建立滤镜
          let filter = CIFilter(name: "CIQRCodeGenerator")
          //还原滤镜的预设属性
          filter?.setDefaults()
          //设定需要生成二维码的资料
          filter?.setValue(text.data(using: String.Encoding.utf8), forKey: "inputMessage")
          //从滤镜中取出生成的图片
          let ciImage = filter?.outputImage
          //这个清晰度好
          let bgImage = createNonInterpolatedUIImageFormCIImage(image: ciImage!, size: CGSize(width: WH, height: WH))
          return bgImage
      }
      
      private func createNonInterpolatedUIImageFormCIImage(image: CIImage, size: CGSize) -> UIImage {
          
          let extent: CGRect = image.extent.integral
          let scale: CGFloat = min(size.width / extent.width, size.height / extent.height)
          
          let width = extent.width * scale
          let height = extent.height * scale
          let cs: CGColorSpace = CGColorSpaceCreateDeviceGray()
          let bitmapRef = CGContext(data: nil, width: Int(width), height: Int(height), bitsPerComponent: 8, bytesPerRow: 0, space: cs, bitmapInfo: 0)!
          
          let context = CIContext(options: nil)
          let bitmapImage: CGImage = context.createCGImage(image, from: extent)!
          
          bitmapRef.interpolationQuality = .none
          bitmapRef.scaleBy(x: scale, y: scale)
          bitmapRef.draw(bitmapImage, in: extent)
          let scaledImage: CGImage = bitmapRef.makeImage()!
          return UIImage(cgImage: scaledImage)
      }
      
    //MARK:-保存图片到相簿
    @objc private func saveImage(image:UIImage,didFinishSavingWithError error:Error?,contextInfo:UnsafeMutableRawPointer) {
        if error == nil {
            mm_showToast("已成功保存到相簿, 请您妥善保存您的账号凭证!", type: .succeed)
            Defaults.accountCerSaved = true
            if isLunch {
                self.navigationController?.dismiss(animated: true, completion: nil)
            }
        } else {
            openSystemSettingPhotoLibrary()
        }
    }
    
    //弹出弹窗去设置
    private func openSystemSettingPhotoLibrary() {
        let alert = UIAlertController(title:"未獲得許可權將圖片保存到相冊", message:"請前往設置-隱私-照片, 打開相冊許可權", preferredStyle: .alert)
        let confirm = UIAlertAction(title:"馬上去設置", style: .default) { _ in
            let url = URL.init(string: UIApplication.openSettingsURLString)
            if  InnerIntercept.canOpenURL(url!) {
                InnerIntercept.open(url!)
            }
        }
        let cancel = UIAlertAction(title:"取消", style: .cancel, handler:nil)
        alert.addAction(cancel)
        alert.addAction(confirm)
        present(alert, animated:true, completion:nil)
    }
}
