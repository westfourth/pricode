//
//  LoginVC.swift
//  Sp
//
//  Created by mac on 2020/2/28.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class LoginVC: UIViewController {
    
    var isFromKickedOut:Bool = false
    
    @IBOutlet weak var areaCode: UITextField!
    
    @IBOutlet weak var tel: UITextField!
    
    @IBOutlet weak var verifyCode: UITextField!
    
    //// 底部登陆
    @IBOutlet weak var login: UIButton!
    
    @IBOutlet weak var fetchCode: UIButton!
    
    @IBOutlet weak var helloLabel: UILabel!
    
    var count:Int = 60
    var timer:Timer!
    
    private static let logoImg: UIImage? = {
        return Sensitive.avatar
    }()
    
    private static let loginBackImg: CGImage? = {
        return Sensitive.login_bg?.cgImage
    }()
    
    private lazy var logo: UIImageView = {
        return UIImageView(image: LoginVC.logoImg)
    }()
    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.navigationBar.setBackgroundImage(UIImage(), for: UIBarMetrics.default)
        self.navigationController?.navigationBar.shadowImage = UIImage()
        self.navigationController?.navigationBar.isTranslucent = true
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.layer.contents = LoginVC.loginBackImg
        self.fetchCode.layer.borderColor = UIColor.white.cgColor
        view.addSubview(logo)
        logo.clipsToBounds = true
        logo.layer.cornerRadius = 35
        logo.snp.makeConstraints { (make) in
            make.size.equalTo(70)
            make.centerX.equalToSuperview()
            make.top.equalToSuperview().offset(IS_IPHONEX ? 150 : 126)
        }
        
        Appearance.gradient(view: login, style: .orange)
        
        #if STORE
        #else
        helloLabel.text = "Hello/擼友"
        #endif
        
        let telP = NSAttributedString(string: "請輸入手機號碼", attributes: [NSAttributedString.Key.foregroundColor : RGB(89,99,125),NSAttributedString.Key.font:UIFont.systemFont(ofSize: 16)])
        self.tel.attributedPlaceholder = telP
        
        let verifyP = NSAttributedString(string: "請輸入驗證碼", attributes: [NSAttributedString.Key.foregroundColor : RGB(89,99,125),NSAttributedString.Key.font:UIFont.systemFont(ofSize: 16)])
        self.verifyCode.attributedPlaceholder = verifyP
        
        self.fetchCode.setTitleColor(.white, for: UIControl.State.normal)
        
        //预设隐藏
        self.action = nil
        if self.isFromKickedOut {
            self.login.isHidden = false
            self.login.setTitle("立即登錄", for: UIControl.State.normal)
        }
    }
    
    @IBAction func fetchVerifyCodeAction(_ sender: Any) {
        guard  (self.areaCode.text!) != "" else {
            mm_showToast("輸入區號！")
            return
        }
        
        guard  (self.tel.text!) != "" else {
            mm_showToast("輸入手機號!")
            return
        }
        
        Alert.showLoading(parentView: view)
        let req =  CaptchaReqCaptchaReq()
        let mobile = self.tel.text!
        let area = self.areaCode.text!
        req.mobile = "+\(area)\(mobile)"
        Session.request(req) { (error, resp) in
            Alert.hideLoading()
            guard error == nil else {
                mm_showToast(error!.localizedDescription)
                return
            }
            mm_showToast("發送成功，請前往手機接收！", type: .succeed)
            self.timer = Timer(timeInterval: 1.0,
                               target: self,
                               selector: #selector(self.timeAction),
                               userInfo: nil,
                               repeats: true)
            self.fetchCode.isEnabled = false
            RunLoop.current.add(self.timer, forMode: RunLoop.Mode.default)
        }
    }
    
    @objc func timeAction() {
        if self.count > 0 {
            self.count = self.count - 1
            self.fetchCode.setTitle("\(self.count)s", for: UIControl.State.disabled)
        } else {
            self.fetchCode.setTitle("獲取驗證碼", for: UIControl.State.normal)
            self.timer.invalidate()
            self.fetchCode.isEnabled = true
        }
    }
    
    //MARK:-登陆
    @IBAction func loginAction(_ sender: Any) {
        guard (self.tel.text) != "" else {
            mm_showToast("請輸入手機號!")
            return
        }
        
        guard (self.verifyCode.text) != "" else {
            mm_showToast("請輸入驗證碼!")
            return
        }
        
        let mobile = self.tel.text!
        let area = self.areaCode.text!
        if isFromKickedOut {
            /// 手机号登陆
            Alert.showLoading(parentView: self.view)
            let req = LoginReq()
            req.mobile = "+\(area)\(mobile)"
            req.captcha = self.verifyCode.text!
            Session.request(req) { (error, _) in
                Alert.hideLoading()
                guard error == nil else {
                    mm_showToast(error!.localizedDescription)
                    return
                }
                self.navigationController?.dismiss(animated: true, completion: nil)
            }
        } else {
            // //绑定手机号
            Alert.showLoading(parentView: self.view)
            let req =  BindMobileReq()
            req.mobile = "+\(area)\(mobile)"
            req.captcha = self.verifyCode.text!
            Session.request(req) { (error, _) in
                Alert.hideLoading()
                guard error == nil else {
                    mm_showToast(error!.localizedDescription)
                    return
                }
                self.navigationController?.popToRootViewController(animated: true)
            }
        }
    }
    
    //MARK:-手机号型别
    var action:MobileActionResp? {
        didSet {
            guard  let item = action else {
//                self.login.isHidden = true
                return
            }
            self.login.isHidden = false
            switch item.actionType {
            case .bind:
                self.login.setTitle("立即綁定", for: UIControl.State.normal)
                break
            case .change:
                self.login.setTitle("更換綁定手機號", for: UIControl.State.normal)
                break
            case .switchA:
                self.login.setTitle("立即切換", for: UIControl.State.normal)
                break
            }
        }
    }
    
    //MARK:-手机号动作
    func mobleAction(_ tel:String) {
        let req = MobileActionTypeReq()
        req.mobile = tel
        Session.request(req) { (error, resp) in
            guard error == nil else {
                mm_showToast(error!.localizedDescription)
                return
            }
            if resp is MobileActionResp {
                let item = resp as! MobileActionResp
                self.action = item
                
            }
        }
    }
}

extension LoginVC:UITextFieldDelegate {
    func textFieldDidEndEditing(_ textField: UITextField) {
        if textField == self.areaCode {
            guard self.areaCode.text != "" else {
                mm_showToast("請輸入區號!")
                return
            }
        }
        if textField == self.tel {
            guard  self.tel.text != "" else {
                mm_showToast("請輸入手機號!")
                return
            }
            guard self.areaCode.text != "" else {
                mm_showToast("請輸入區號!")
                return
            }
            let mobile = textField.text!
            let areaCode = self.areaCode.text!
            if !self.isFromKickedOut {
                mobleAction("+\(areaCode)\(mobile)")
            }
        }
    }
}
