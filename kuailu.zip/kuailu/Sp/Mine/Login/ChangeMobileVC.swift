//
//  ChangeMobileVC.swift
//  Sp
//
//  Created by mac on 2020/3/6.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class ChangeMobileVC: UIViewController {
    
    var tel:String!
    var count:Int = 60
    var timer:Timer!
    
    @IBOutlet weak var changeTel: UITextField!
    @IBOutlet weak var verifyInput: UITextField!
    @IBOutlet weak var verify: UIButton!
    @IBOutlet weak var nextButton: UIButton!
    
    private static let logoImg: UIImage? = {
        return Sensitive.avatar
    }()
    
    private static let loginBackImg: CGImage? = {
        return Sensitive.login_bg?.cgImage
    }()
    
    private lazy var logo: UIImageView = {
        return UIImageView(image: ChangeMobileVC.logoImg)
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.layer.contents = ChangeMobileVC.loginBackImg
        self.changeTel.text = String.init(format:"已綁定手機號:%@" , self.tel)
        self.verify.layer.borderColor = UIColor.white.cgColor
        view.addSubview(logo)
        logo.clipsToBounds = true
        logo.layer.cornerRadius = 35
        logo.snp.makeConstraints { (make) in
            make.size.equalTo(70)
            make.centerX.equalToSuperview()
            make.top.equalToSuperview().offset(IS_IPHONEX ? 150 : 126)
        }
    }
    
    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.navigationBar.setBackgroundImage(UIImage(), for: UIBarMetrics.default)
        self.navigationController?.navigationBar.shadowImage = UIImage()
        self.navigationController?.navigationBar.isTranslucent = true
    }
    
    
    @IBAction func sendVerifyAction(_ sender: UIButton) {
        Alert.showLoading(parentView: self.view)
        let req = CaptchaReqCaptchaReq()
        req.mobile = self.tel
        Session.request(req) { (error, resp) in
            Alert.hideLoading()
            guard error == nil else {
                mm_showToast(error!.localizedDescription)
                return
            }
            mm_showToast("發送成功，請前往手機接收！", type: .succeed)
            self.timer = Timer(timeInterval: 1.0,
                               target: self,
                               selector: #selector(self.timeAction),
                               userInfo: nil,
                               repeats: true)
            self.verify.isEnabled = false
            RunLoop.current.add(self.timer, forMode: RunLoop.Mode.default)
        }
    }
    
    @IBAction func nextAction(_ sender: UIButton) {
        guard self.verifyInput.text?.count == 4 else {
            mm_showToast("請輸入驗證碼!")
            return
        }
        
        //校验验证码
        Alert.showLoading(parentView: self.view)
        let code = self.verifyInput.text!
        let req = CheckCaptchaReq()
        req.mobile = self.tel
        req.captcha = code
        Session.request(req) { (error, resp) in
            Alert.hideLoading()
            guard error == nil else {
                mm_showToast(error!.localizedDescription)
                return
            }
            mm_showToast("解綁成功!前往綁定新手機號", type: .succeed)
            self.navigationController?.pushViewController(LoginVC(), animated: true)
        }
    }
    
    
    @objc func timeAction() {
        if self.count > 0 {
            self.count = self.count - 1
            self.verify.setTitle("\(self.count)s", for: UIControl.State.disabled)
        } else {
            self.verify.setTitle("獲取驗證碼", for: UIControl.State.normal)
            self.timer.invalidate()
            self.verify.isEnabled = true
        }
    }
}
