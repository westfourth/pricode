//
//  GroupCell.swift
//  Sp
//
//  Created by mac on 2020/5/15.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

@objc protocol GroupCellDelegate {
    ///点击
    func cell(_ cell:GroupCell, item:GroupItem)
}

class GroupCell: UITableViewCell {
    weak var delegate: GroupCellDelegate?

    @IBOutlet weak var bgView: UIImageView!
    @IBOutlet weak var logo: UIImageView!
    @IBOutlet weak var name: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        backgroundColor = .clear
        contentView.backgroundColor = .clear
        selectionStyle = .none
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    @IBAction func addAction(_ sender: Any) {
        guard let item = self.item else {
            return
        }
        delegate?.cell(self, item: item)
    }
    
    var item:GroupItem? {
        didSet {
            guard let item = item else {
                return
            }
           let imageName = "group_\(item.groupType.rawValue)"
            logo.image = UIImage(named: imageName)
            bgView.image = item.groupType == .wechat ? UIImage(named: "group_bg_2"):UIImage(named: "group_bg_1")
            let title = item.groupType == .telgram ? "Telegram":item.groupType == .potato ? "Potato": item.groupType == .qq ? "QQ" : "微信"
            let suffix = item.groupType == .wechat ? "專屬福利群" : "福利群"
            let nameStr = "\(title)\(suffix)"
            let name = NSMutableAttributedString(string:nameStr)
            name.addAttributes([NSAttributedString.Key.font :UIFont.systemFont(ofSize: 24, weight: .medium),.foregroundColor:UIColor.white], range: NSRange(location: 0, length: title.count))
            name.addAttributes([NSAttributedString.Key.font :UIFont.systemFont(ofSize: 16, weight: .light),.foregroundColor:UIColor.white], range: NSRange(location: title.count, length: suffix.count))
            self.name.attributedText = name
        }
    }
    
    
}
