//
//  ScorePresentTransition.swift
//  CaoLong
//
//  Created by mac on 2020/5/23.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class WeChatPresentTransition: NSObject, UIViewControllerAnimatedTransitioning, UIGestureRecognizerDelegate {
    weak var delegate:WeChatPresentTransitionDelegate?
    var size = CGSize(width: 350, height: 350)
    
    func transitionDuration(using transitionContext: UIViewControllerContextTransitioning?) -> TimeInterval {
        return 0.25
    }
    
    func animateTransition(using transitionContext: UIViewControllerContextTransitioning) {
        let toVC = transitionContext.viewController(forKey: .to)!
        let containerView = transitionContext.containerView
        containerView.addSubview(toVC.view)
        
        //  添加点击手势
        let tap = UITapGestureRecognizer(target: self, action: #selector(tap(_:)))
        tap.delegate = self
        containerView.addGestureRecognizer(tap)
        
        let toVCToRect = transitionContext.finalFrame(for: toVC)
        toVC.view.frame = CGRect(x: (toVCToRect.width - size.width) / 2,
                                 y: (toVCToRect.height - size.height) / 2,
                                 width: size.width, height: size.height)
        
        containerView.backgroundColor = UIColor.clear
        UIView.animateKeyframes(withDuration: transitionDuration(using: transitionContext), delay: 0, options: [], animations: {
            containerView.backgroundColor = UIColor.black.withAlphaComponent(0.4)
            
            UIView.addKeyframe(withRelativeStartTime: 0, relativeDuration: 0.5) {
                toVC.view.transform = CGAffineTransform.init(scaleX: 1.05, y: 1.05)
            }
            UIView.addKeyframe(withRelativeStartTime: 0.5, relativeDuration: 0.5) {
                toVC.view.transform = CGAffineTransform.identity
            }
        }) { (finished) in
            transitionContext.completeTransition(!transitionContext.transitionWasCancelled)
        }
    }
    
    @objc func tap(_ tap: UITapGestureRecognizer) {
        self.delegate?.transition(didTapContainerView: self)
    }
    
    func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer, shouldReceive touch: UITouch) -> Bool {
        return gestureRecognizer.view == touch.view
    }
}


protocol WeChatPresentTransitionDelegate: NSObjectProtocol {
    func transition(didTapContainerView on: WeChatPresentTransition)
}
