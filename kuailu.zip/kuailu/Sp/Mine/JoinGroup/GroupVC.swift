//
//  GroupVC.swift
//  Sp
//
//  Created by mac on 2020/5/15.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class GroupVC: UIViewController {
    var items:[GroupItem] = [GroupItem]()
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.navigationItem.title = "加群交流"
        view.backgroundColor = RGB(0xff141516)
        view.addSubview(self.tableView)
        tableView.snp.makeConstraints { (make) in
            make.top.equalTo(15)
            make.left.equalTo(15)
            make.right.equalTo(-15)
            make.bottom.equalTo(0)
        }
        loadData()
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.navigationBar.setBackgroundImage(UIImage(named: "navi_backImage"), for: UIBarMetrics.default)
        self.navigationController?.navigationBar.shadowImage = UIImage()
    }
    
    func loadData() {
        Alert.showLoading(parentView: self.view)
        Session.request(GroupListReq()) {[weak self] (error, resp) in
            Alert.hideLoading()
            guard error == nil else {
                self?.tableView.state = .empty
                return
            }
            if resp is [GroupItem] {
                guard let items = resp as? [GroupItem],!items.isEmpty else {
                    self?.tableView.state = .empty
                    return
                }
                self?.items = items
                self?.tableView.reloadData()
            }
        }
    }
    
    lazy var tableView : UITableView = {
        let tableView = UITableView.init(frame: CGRect.zero, style: .grouped)
        tableView.delegate = self
        tableView.dataSource = self
        tableView.clipsToBounds = true
        tableView.backgroundColor = UIColor.clear
        tableView.separatorStyle = UITableViewCell.SeparatorStyle.none
        tableView.showsVerticalScrollIndicator = false
        tableView.alwaysBounceVertical = true
        
        tableView.rowHeight = 120
        tableView.sectionHeaderHeight = .leastNonzeroMagnitude
        tableView.sectionFooterHeight = 20
        tableView.contentInset = UIEdgeInsets(top: -35, left: 0, bottom: 0, right: 0)
        tableView.register(UINib(nibName: "GroupCell", bundle: Bundle.main), forCellReuseIdentifier: "GroupCell")
        return tableView
    }()
}
// MARK: -UITableViewDataSource && Delegate
extension GroupVC:UITableViewDataSource,UITableViewDelegate {
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "GroupCell") as! GroupCell
        cell.item = self.items[indexPath.section]
        cell.delegate = self
        return cell
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return self.items.count
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let item = self.items[indexPath.section]
        openAction(item)
    }
    
    
    func openAction(_ item:GroupItem) {
        if item.groupType == .qq {
            //打开qq
            openQQGroup(qqGroup: item.link)
        } else if item.groupType == .wechat {
            guard item.isInto else {
                mm_showToast("您等級還不夠,請前往\(Sensitive.chong)!", callback: { [weak self] in
                    VipChargeTipVC.isFromVideoPlayList = false
                    VipChargeTicketItemCell.initActiveTicketType = .wechatGroup
                    let vipVC = Vip2VC()
                    vipVC.uiType = .ticket
                    self?.navigationController?.pushViewController(vipVC, animated: true)
                })
                return
            }
            //打开微信
            guard !item.link.isEmpty else {
                mm_showToast("鏈接地址不合法!", type: .failed)
                return
            }
            let VC = WeChatAlertVC()
            VC.link = item.link
            present(VC, animated: true, completion: nil)
        } else  {
            //  打开其他
            let url = URL(string: item.link)
            guard url != nil else {
                mm_showToast("鏈接地址不合法!", type: .failed)
                return
            }
            if InnerIntercept.canOpenURL(url!)  {
                InnerIntercept.open(url!)
            } else {
                mm_showToast("鏈接地址不合法!", type: .failed)
            }
        }
    }
    
    //  打开QQ群
    func openQQGroup(qqGroup: String) {
        let urlStr = "mqqapi://card/show_pslcard?src_type=internal&version=1&uin=\(qqGroup)&card_type=group&source=external"
        let url = URL(string: urlStr)!
        let canOpen = InnerIntercept.canOpenURL(url)
        if canOpen {
            InnerIntercept.open(url)
        } else {
            mm_showToast("您還未安裝QQ哦！", type: .failed)
        }
    }
}

extension GroupVC:GroupCellDelegate {
    func cell(_ cell: GroupCell, item: GroupItem) {
        openAction(item)
    }
}
