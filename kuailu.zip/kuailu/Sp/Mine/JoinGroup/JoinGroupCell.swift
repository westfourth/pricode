//
//  JoinGroupCell.swift
//  Sp
//
//  Created by mac on 2020/2/27.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class JoinGroupCell: UITableViewCell {
    @IBOutlet weak var icon: UIImageView!
    @IBOutlet weak var name: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        self.backgroundColor = .clear
        self.selectionStyle = .none
        self.contentView.backgroundColor = .clear
        self.isUserInteractionEnabled = true
    }
    
    func set(icon:String, name:String) {
        self.icon.image = UIImage(named: icon)
        self.name.text = name
    }
}
