//
//  WeChatAlertVC.swift
//  Sp
//
//  Created by mac on 2020/5/25.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

@IBDesignable
class WeChatAlertVC: UIViewController,UIViewControllerTransitioningDelegate, WeChatPresentTransitionDelegate {

    @IBOutlet weak var qrcode: UIImageView!
    @IBOutlet weak var centerView: UIView!
    
     var presentTransition = WeChatPresentTransition()
    
    override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: Bundle?) {
        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
        modalPresentationStyle = .overFullScreen
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    var link:String? {
        didSet {
            guard let _ = link else {return}
        }
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        guard let url = self.link else {
            return
        }
        self.qrcode.image = self.creatQRCodeImage(text: url, WH: 170)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        transitioningDelegate = self
        presentTransition.delegate = self
    }
    
    @IBAction func cancel(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    
    @IBAction func saveAction(_ sender: Any) {
        guard let image = self.qrcode.image else {return}
        UIImageWriteToSavedPhotosAlbum(image, self, #selector(saveImage(image:didFinishSavingWithError:contextInfo:)), nil)
        dismiss(animated: true, completion: nil)
    }
    
    //MARK:- 生成二维码
    private func creatQRCodeImage(text: String, WH: CGFloat) -> UIImage{
        
        //建立滤镜
        let filter = CIFilter(name: "CIQRCodeGenerator")
        //还原滤镜的预设属性
        filter?.setDefaults()
        //设定需要生成二维码的资料
        filter?.setValue(text.data(using: String.Encoding.utf8), forKey: "inputMessage")
        //从滤镜中取出生成的图片
        let ciImage = filter?.outputImage
        //这个清晰度好
        let bgImage = createNonInterpolatedUIImageFormCIImage(image: ciImage!, size: CGSize(width: WH, height: WH))
        return bgImage
    }
    
    private func createNonInterpolatedUIImageFormCIImage(image: CIImage, size: CGSize) -> UIImage {
        
        let extent: CGRect = image.extent.integral
        let scale: CGFloat = min(size.width / extent.width, size.height / extent.height)
        
        let width = extent.width * scale
        let height = extent.height * scale
        let cs: CGColorSpace = CGColorSpaceCreateDeviceGray()
        let bitmapRef = CGContext(data: nil, width: Int(width), height: Int(height), bitsPerComponent: 8, bytesPerRow: 0, space: cs, bitmapInfo: 0)!
        
        let context = CIContext(options: nil)
        let bitmapImage: CGImage = context.createCGImage(image, from: extent)!
        
        bitmapRef.interpolationQuality = .none
        bitmapRef.scaleBy(x: scale, y: scale)
        bitmapRef.draw(bitmapImage, in: extent)
        let scaledImage: CGImage = bitmapRef.makeImage()!
        return UIImage(cgImage: scaledImage)
    }
    
    
    //MARK:-保存图片到相簿
    @objc private func saveImage(image:UIImage,didFinishSavingWithError error:Error?,contextInfo:UnsafeMutableRawPointer) {
        if error == nil {
            mm_showToast("已成功保存到相簿!", type: .succeed)
        }
    }
    
    //MARK:-    转场动画
       
       func animationController(forPresented presented: UIViewController, presenting: UIViewController, source: UIViewController) -> UIViewControllerAnimatedTransitioning? {
           return presentTransition
       }
       
       func animationController(forDismissed dismissed: UIViewController) -> UIViewControllerAnimatedTransitioning? {
           return WeChatDismissTransition()
       }

       func transition(didTapContainerView on: WeChatPresentTransition) {
           dismiss(animated: true, completion: nil)
       }
    
}
