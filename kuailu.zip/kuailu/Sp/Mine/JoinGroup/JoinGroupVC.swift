//
//  JoinGroupVC.swift
//  Sp
//
//  Created by mac on 2020/2/27.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class JoinGroupVC: UIViewController {
    var items:[GroupItem] = [GroupItem]()
    let names = ["Telegram福利群", "Potato福利群", "QQ福利群"]
    let imageNames = ["share_1", "share_0", "share_2"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.title = "加群交流"
        view.backgroundColor = RGB(0xff141516)
        view.addSubview(self.tableView)
        tableView.snp.makeConstraints { (make) in
            make.top.equalTo(0)
            make.left.equalTo(30)
            make.right.equalTo(-30)
            make.bottom.equalTo(0)
        }
        loadData()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.navigationBar.setBackgroundImage(UIImage(named: "navi_backImage"), for: UIBarMetrics.default)
        self.navigationController?.navigationBar.shadowImage = UIImage()
    }
    
    func loadData() {
        Session.request(GroupListReq()) { (error, resp) in
            guard error == nil else {
                return
            }
            if resp is  [GroupItem] {
                let items = resp as! [GroupItem]
                self.items = items
                self.tableView.reloadData()
            }
        }
    }
    
    lazy var tableView : UITableView = {
        let tableView = UITableView.init(frame: CGRect.zero, style: .grouped)
        tableView.delegate = self
        tableView.dataSource = self
        tableView.clipsToBounds = true
        tableView.backgroundColor = UIColor.clear
        tableView.separatorStyle = UITableViewCell.SeparatorStyle.none
        tableView.showsVerticalScrollIndicator = false
        tableView.alwaysBounceVertical = false
        
        tableView.rowHeight = 180
        tableView.sectionHeaderHeight = .leastNonzeroMagnitude
        tableView.sectionFooterHeight = 20
        tableView.contentInset = UIEdgeInsets(top: -35, left: 0, bottom: 0, right: 0)
        
        tableView.register(UINib(nibName: "JoinGroupCell", bundle: Bundle.main), forCellReuseIdentifier: "JoinGroupCell")
        return tableView
    }()
}

// MARK: -UITableViewDataSource && Delegate
extension JoinGroupVC:UITableViewDataSource,UITableViewDelegate {
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "JoinGroupCell") as! JoinGroupCell
        let index = indexPath.section
        cell.set(icon: imageNames[index], name: names[index])
        return cell
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return names.count
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let title = names[indexPath.section]
        let item = groupItem(title: title)
        if let item2 = item {
            if item2.groupType == .qq {
                let qqGroup = item2.link
                openQQGroup(qqGroup: qqGroup)
                return
            }
            let url = URL(string: item2.link)
            guard url != nil else {
                mm_showToast("鏈接地址不合法!", type: .failed)
                return
            }
            if InnerIntercept.canOpenURL(url!)  {
                InnerIntercept.open(url!)
            } else {
                mm_showToast("鏈接地址不合法!", type: .failed)
            }
        }
    }
    
    //  打开QQ群
    func openQQGroup(qqGroup: String) {
        let urlStr = "mqqapi://card/show_pslcard?src_type=internal&version=1&uin=\(qqGroup)&card_type=group&source=external"
        let url = URL(string: urlStr)!
        let canOpen = InnerIntercept.canOpenURL(url)
        if canOpen {
            InnerIntercept.open(url)
        } else {
            mm_showToast("您還未安裝QQ哦！", type: .failed)
        }
    }
    
    //  根据标题，找到GroupItem
    func groupItem(title: String) -> GroupItem? {
        let t = type(title: title)
        guard let t2 = t else {
            return nil
        }
        for item in items {
            if t2 == item.groupType {
                return item
            }
        }
        return nil
    }
    
    //  根据标题，找到对应的type
    func type(title: String) -> GroupType? { 
        switch title {
        case names[0]: //  "Telegram福利群"
            return .telgram
        case names[1]: //  "Potato福利群"
            return .potato
        default: //  "QQ福利群"
            return .qq
        }
    }
}

