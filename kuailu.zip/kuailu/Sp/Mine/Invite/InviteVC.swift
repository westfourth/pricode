//
//  InviteVC.swift
//  Sp
//
//  Created by mac on 2020/9/3.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit
class InviteVC: UIViewController {
    
    private static let characterSet: CharacterSet = {
        let inputLimitCharacters: String = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789"
        return NSCharacterSet(charactersIn: inputLimitCharacters).inverted
    }()
    private lazy var inputPanel: UIView = {
        let view = UIView()
        view.backgroundColor = RGB(0x212430)
        view.layer.cornerRadius = 6
        view.clipsToBounds = true
        return view
    }()
    
    private lazy var inputField: UITextField = {
        let input  = UITextField()
        input.placeholder = "請輸入邀请碼"
        input.text = ""
        input.textColor = .white
        input.setValue(UIColor.white.withAlphaComponent(0.36), forKeyPath: "placeholderLabel.textColor")
        input.setValue(UIFont.pingFangMedium(16), forKeyPath: "placeholderLabel.font")
        input.font = UIFont.pingFangMedium(16)
        input.keyboardType = .asciiCapable
        input.delegate = self
        input.addTarget(self, action: #selector(onInputFieldChanged), for: .editingChanged)
        return input
    }()
    
    private lazy var confirmBtn: UIButton = {
        let btn = UIButton()
        btn.setTitleColor(RGB(0xE62865), for: .normal)
        btn.setTitle("確認绑定", for: .normal)
        btn.titleLabel?.font = UIFont.pingFangMedium(17)
        btn.clipsToBounds = true
        btn.layer.cornerRadius = 3.5
        btn.layer.borderColor = RGB(0xE62865).cgColor
        btn.layer.borderWidth = 1
        btn.addTarget(self, action: #selector(onConfirmBtnClick), for: .touchUpInside)
        return btn
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationItem.title = "绑定邀请码"
        navigationController?.navigationBar.barTintColor = RGB(0x141516)
        navigationController?.navigationBar.isTranslucent = false
        navigationController?.navigationBar.shadowImage = UIImage()
        view.backgroundColor = RGB(0x141516)
        renderView()
    }
    
    private func renderView() {
        view.addSubview(inputPanel)
        view.addSubview(inputField)
        view.addSubview(confirmBtn)
        inputPanel.snp.makeConstraints { (make) in
            make.top.equalToSuperview().inset(10)
            make.left.right.equalToSuperview().inset(12)
            make.height.equalTo(44)
        }
        
        inputField.snp.makeConstraints { (make) in
            make.centerY.equalTo(inputPanel)
            make.left.equalTo(inputPanel).offset(12)
            make.right.equalTo(inputPanel)
        }
        
        confirmBtn.snp.makeConstraints { (make) in
            make.bottom.equalToSuperview().inset(44)
            make.left.right.equalToSuperview().inset(12)
            make.height.equalTo(44)
        }
    }
    
    @objc private func onConfirmBtnClick() {
        let val = inputField.text
        if val == "" {
            mm_showToast("請輸入邀请碼哦！")
            return
        }
        
        if val!.count == 6 {
            onInputFieldChanged()
            return
        }
        
        mm_showToast("邀请碼無效", type: .failed)
    }
    
    private func exchangeExchangeCode() {
        Alert.showLoading(parentView: self.view)
        let req = BindInviteCodeReq()
        req.proxyCode = inputField.text!
        Session.request(req) { (error, resp) in
            Alert.hideLoading()
            guard error == nil else {
                mm_showToast(error!.localizedDescription, type: .failed)
                return
            }
            mm_showToast("邀请人绑定成功", type: .succeed, callback: { [weak self] in
                self?.navigationController?.popViewController(animated: true)
            })
        }
    }
    
    @objc private func onInputFieldChanged() {
        let val = inputField.text!.trimmingCharacters(in: .whitespacesAndNewlines)
        inputField.text = val
        guard val.count == 6 else {
            return
        }
        inputField.resignFirstResponder()
        Alert.showLoading(parentView: self.view)
        let req = BindInviteCodeReq()
        req.proxyCode = val
        Session.request(req) { [weak self] (error, resp) in
            Alert.hideLoading()
            guard let `self` = self else { return }
            guard error == nil else {
                mm_showToast(error!.localizedDescription, type: .failed)
                return
            }
            mm_showToast("邀请人绑定成功", type: .succeed, callback: { [weak self] in
                self?.navigationController?.popViewController(animated: true)
            })
        }
    }
}

extension InviteVC: UITextFieldDelegate {
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        let text = textField.text!
        let len = text.count + string.count - range.length
        guard len <= 6 else {
            return false
        }
        let filtered = string.components(separatedBy: InviteVC.characterSet).joined(separator: "")
        return string == filtered
    }
}
