//
//  MineVideoLiscollectionViewC.swift
//  Sp
//
//  Created by mac on 2020/2/26.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit
class CollectionListVC: UIViewController,UICollectionViewDataSource,UICollectionViewDelegate {
    
    //必传引数
    var userId:Int!
    
    var list:[VideoItem] = [VideoItem]()
    
    var page:Int = 1
    
    var listViewDidScrollCallback: ((UIScrollView) -> ())?
    
    var nomoreData:Bool = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = RGB(0xff141516)
        view.addSubview(self.collectionView)
        self.collectionView.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        collectionView.mj_header?.endRefreshing()
        collectionView.mj_footer?.endRefreshing()
        refreshAction()
    }
    
    @objc func loadData(_ page:Int, isRefresh: Bool) {
        let req = CollectVideoReq()
        req.userId = self.userId
        req.page = page
        Session.request(req) { (error, resp) in
            isRefresh ? self.collectionView.mj_header?.endRefreshing() :
            self.collectionView.mj_footer?.endRefreshing()
            guard error == nil else {
                mm_showToast(error!.localizedDescription)
                self.collectionView.state = .failed
                return
            }
            if resp is [VideoItem] {
                let array = resp as! [VideoItem]
                self.nomoreData = array.count < 30
                if self.page == 1 {
                    self.list = array
                    if array.isEmpty {
                        self.collectionView.state = .empty
                    } else{
                        self.collectionView.state = .normal
                    }
                } else {
                    self.list.append(contentsOf: array)
                    if  self.list.isEmpty {
                        self.collectionView.state = .empty
                    } else{
                        self.collectionView.state = .normal
                    }
                }
            }
            self.collectionView.reloadData()
        }
    }
    
    lazy var collectionView: UICollectionView = {
        let layout = UICollectionViewFlowLayout()
        layout.minimumLineSpacing = 1.0
        layout.minimumInteritemSpacing = 2.0
        let itemW = (UIScreen.main.bounds.size.width - 4.0) / 3.0
        layout.itemSize = CGSize(width: itemW, height: (160 / 120) * itemW )
        
        let collectionView = UICollectionView(frame: .zero, collectionViewLayout: layout)
        collectionView.dataSource = self
        collectionView.delegate = self
        
        collectionView.register(UINib(nibName: "MineVideoCell", bundle: Bundle.main), forCellWithReuseIdentifier: "MineVideoCell")
        collectionView.backgroundColor = RGB(0xff141516)
        collectionView.showsVerticalScrollIndicator = false
        collectionView.state = .loading
        collectionView.mj_header = getCommonMJHeader(refreshingTarget: self, headerRefreshCallback: #selector(refreshAction))
        collectionView.loadMoreBlock = { [unowned self] in
            guard self.nomoreData == false else {
                return
            }
            self.page = self.page + 1
            self.loadData(self.page, isRefresh: false)
        }
        return collectionView
    }()
    
    @objc func refreshAction() {
        self.page = 1
        loadData(self.page, isRefresh: true)
    }
    //_______________________________________________________________________________________________________________
    // MARK: - UICollectionDataSource&Delegate
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return self.list.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "MineVideoCell", for: indexPath) as! MineVideoCell
        cell.item = self.list[indexPath.row]
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let currentItem = list[indexPath.row]
        guard !currentItem.isSpecial else {
            if let user = NetDefaults.userInfo,user.specialAuth {
                //等级是6 随意看
                let vc = ShortVideoListVC()
                vc.currentPlayingIndexPath = IndexPath(item:indexPath.row, section: 0)
                vc.videoItems = self.list
                vc.hidesBottomBarWhenPushed = true
                navigationController?.show(vc, sender: nil)
            } else {
                Alert.showCommonAlert(parentView: UIApplication.shared.keyWindow!, contentText: "該視頻為V6專享，是否購買門票", cancelText: "升級\(Sensitive.hui)等級", confirmText: "購買", onConfirmTap: {
                    //购买
                    let vc = Vip2VC()
                    vc.uiType = .ticket
                    InnerIntercept.currentNaviController().pushViewController(vc, animated: true)
                    }, onCancelTap: {
                         //升级会员等级
                        let vc = Vip2VC()
                        vc.uiType = .vip
                        vc.hidesBottomBarWhenPushed = true
                        InnerIntercept.currentNaviController().pushViewController(vc, animated: true)
                })
            }
            return
        }
        let vc = ShortVideoListVC()
        vc.currentPlayingIndexPath = IndexPath(item: indexPath.row, section: 0)
        vc.videoItems = self.list
        vc.hidesBottomBarWhenPushed = true
        navigationController?.show(vc, sender: nil)
    }
    
    //_______________________________________________________________________________________________________________
    // MARK: - UIScrollViewDelegate
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        self.listViewDidScrollCallback?(scrollView)
    }
    
}

//_______________________________________________________________________________________________________________
// MARK: - JXPagingViewListViewDelegate
extension CollectionListVC: JXPagingViewListViewDelegate {
    func listView() -> UIView {
        return view
    }
    
    func listViewDidScrollCallback(callback: @escaping (UIScrollView) -> ()) {
        self.listViewDidScrollCallback = callback
    }
    
    func listScrollView() -> UIScrollView {
        return self.collectionView
    }
    
//    func listWillAppear() {
//        print("\(self.title ?? ""):\(#function)")
//    }
//    
//    func listDidAppear() {
//        print("\(self.title ?? ""):\(#function)")
//    }
//    
//    func listWillDisappear() {
//        print("\(self.title ?? ""):\(#function)")
//    }
//    
//    func listDidDisappear() {
//        print("\(self.title ?? ""):\(#function)")
//    }
}


