//
//  MineVideoCell.swift
//  Sp
//
//  Created by mac on 2020/2/28.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class MineVideoCell: UICollectionViewCell {
    @IBOutlet weak var cover: UIImageView!
    @IBOutlet weak var like: UILabel!
    @IBOutlet weak var backView: UIView!
    @IBOutlet weak var reviewing: UILabel!
    
    @IBOutlet weak var vipView: UIView!
    
    private static let defaultImg: UIImage? = {
           return Sensitive.default_bg
    }()
       
    private static let animationOption: KingfisherOptionsInfo = {
       return [.transition(.fade(0.25))]
    }()
    
    override func awakeFromNib() {
        super.awakeFromNib()
        cover.image = MineVideoCell.defaultImg
        let startC = UIColor(red: 36/255.0, green: 3/255.0, blue: 33/255.0, alpha: 0.0)
        let endC = UIColor(red: 36/255.0, green: 3/255.0, blue: 33/255.0, alpha: 0.6)
        let gradientColors: [CGColor] = [startC.cgColor, endC.cgColor]
        let gradientLayer: CAGradientLayer = CAGradientLayer()
        gradientLayer.colors = gradientColors
        gradientLayer.startPoint = .zero
        gradientLayer.endPoint = CGPoint(x: 1, y: 1)
        gradientLayer.frame = self.backView.bounds
        self.backView.layer.insertSublayer(gradientLayer, at: 0)
        
        
        let startC1 = UIColor(red: CGFloat(255)/255.0 , green: CGFloat(103)/255.0, blue:CGFloat(103)/255.0, alpha: 0.0)
        let endC1 = UIColor(red: 216/255.0, green: 0, blue: 255/255.0, alpha: 0.2)
        let gradientColors1: [CGColor] = [startC1.cgColor, endC1.cgColor]
        let gradientLayer1: CAGradientLayer = CAGradientLayer()
        gradientLayer1.colors = gradientColors1
        gradientLayer1.startPoint = .zero
        gradientLayer1.endPoint = CGPoint(x: 1, y: 1)
        
        gradientLayer1.frame = self.reviewing.bounds
        self.reviewing.layer.insertSublayer(gradientLayer1, at: 0)
        
//        vipView.isHidden = true
    }
    
    var item:VideoItem? {
        didSet {
            guard let video = item else {
                return
            }
            self.cover.kf.setImage(with: video.coverImg, placeholder: MineVideoCell.defaultImg, options: MineVideoCell.animationOption)
            self.like.text = video.fakeLikes < 0 ? "0": num2TenThousandStrFormat(video.fakeLikes)
            self.reviewing.text = item?.videoStatus == .approved ? "" : item?.videoStatus == .waitingApproved ? "審核中..." : "審核未通過"
            self.reviewing.isHidden = item?.videoStatus == .approved
            vipView.isHidden = !video.isSpecial
        }
    }
}
