//
//  ShareViewController.swift
//  Sp
//
//  Created by mac on 2020/5/25.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class ShareViewController: UIViewController {
    
    @IBOutlet weak var bottomPadding1: NSLayoutConstraint!
    
    var qrURL:URL?
    
    var shareLink:String?
    
    var webSite:String?
    
    @IBOutlet weak var code: UIImageView!
    
    @IBOutlet weak var shareImageView: UIImageView!
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.navigationBar.setBackgroundImage(UIImage(), for: UIBarMetrics.default)
        self.navigationController?.navigationBar.shadowImage = UIImage()
         self.navigationController?.navigationBar.isTranslucent = true
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.shareImageView.image = UIImage.decrypt("share_bg.jpg.enc")
        loadData()
    }
        
    @IBAction func copyAction(_ sender: UITapGestureRecognizer) {
        puts(#function)
        guard let shareLink = self.shareLink else {
            return
        }
        UIPasteboard.general.string = shareLink
        mm_showToast("已經複製到貼上板!", type: .succeed)
    }
    
    @IBAction func saveAction(_ sender: Any) {
        puts(#function)
        saveAction()
    }
    
    func saveAction() {
        guard let user = NetDefaults.userInfo else {return}
        
        let bgView = UIView(frame: CGRect(x: 0, y: 0, width: UIScreen.main.bounds.size.width, height: UIScreen.main.bounds.size.height))
        bgView.layer.contents = UIImage.decrypt("download_bg.jpg.enc").cgImage
        
        let is_iphoneX = UIApplication.shared.windows.first!.safeAreaInsets.bottom > 0
        let padding:CGFloat = is_iphoneX ? 200:160
        // 二维码
        let qrcode = UIImageView(frame: CGRect(x: (UIScreen.main.bounds.size.width - 100) / 2.0, y: UIScreen.main.bounds.size.height - padding, width: 100, height: 100))
        qrcode.contentMode = .scaleAspectFit
        qrcode.backgroundColor = .white
        bgView.addSubview(qrcode)
        if let url = self.qrURL {
            qrcode.image = creatQRCodeImage(text: url.absoluteString, WH: 100)
        }
        
        // 头像
//        let avatar = UIImageView(frame: CGRect(x: (UIScreen.main.bounds.size.width - 45) / 2.0, y: qrcode.frame.origin.y + (50 - 22.5), width: 45, height: 45))
//        avatar.clipsToBounds = true
//        avatar.layer.cornerRadius = 22.5
//        avatar.contentMode = .scaleAspectFill
//        avatar.kf.setImage(with: user.logo,placeholder:Sensitive.avatar,options: [.transition(.fade(0.25))])
//        bgView.addSubview(avatar)
        
        //网址
        let webSite = UILabel(frame: CGRect(x: 0, y: qrcode.frame.origin.y + qrcode.frame.size.height + 10, width: UIScreen.main.bounds.size.width, height: 20))
        webSite.font = UIFont.boldSystemFont(ofSize: 22)
        webSite.textColor = .white
        webSite.textAlignment = .center
        webSite.text = self.webSite == nil ? "clsp.site":self.webSite
        bgView.addSubview(webSite)
        
        // 推广码
        let inviteCode = UILabel(frame: CGRect(x: 0, y: webSite.frame.origin.y + webSite.frame.size.height + 5, width: UIScreen.main.bounds.size.width, height: 20))
        inviteCode.font = UIFont.boldSystemFont(ofSize: 12)
        inviteCode.textColor = .white
        inviteCode.textAlignment = .center
        inviteCode.text = "推廣碼:\(user.inviteCode)"
        bgView.addSubview(inviteCode)
        
        
        UIGraphicsBeginImageContextWithOptions(bgView.bounds.size, true, UIScreen.main.scale)
        bgView.layer.render(in: UIGraphicsGetCurrentContext()!)
        let allImage = UIGraphicsGetImageFromCurrentImageContext()!
        let rect = CGRect(x: 0, y: 0, width: UIScreen.main.bounds.size.width * UIScreen.main.scale, height: UIScreen.main.bounds.size.height  * UIScreen.main.scale)
        let partImage = UIImage(cgImage: allImage.cgImage!.cropping(to: rect)!, scale: UIScreen.main.scale, orientation: .up)
        UIImageWriteToSavedPhotosAlbum(partImage, self, #selector(saveImage(image:didFinishSavingWithError:contextInfo:)), nil)
        UIGraphicsEndImageContext()
    }
    
    
    private func loadData() {
        Alert.showLoading(parentView: view)
        if let url = Defaults.shareURL {
            self.qrURL = url
        }
        Session.request(ShareLinkReq()) { [weak self] (error, resp) in
            Alert.hideLoading()
            guard let `self` = self else { return }
            guard error == nil, let item = resp as? ShareLinkResp, let urlStr = item.url?.absoluteString else {
                mm_showToast(error!.localizedDescription)
                return
            }
            let urlStrArr = urlStr.components(separatedBy: "?p=")
            self.webSite = urlStrArr.first
            if item.url != Defaults.shareURL {
                Defaults.shareURL = item.url
                self.qrURL = item.url
            }
            self.code.image = self.creatQRCodeImage(text: item.url?.absoluteString ?? "", WH: 75)
            self.shareLink = item.linkText == nil ? urlStr : item.linkText! + "：" + urlStr
        }
    }
    
    //MARK:- 生成二维码
    private func creatQRCodeImage(text: String, WH: CGFloat) -> UIImage{
        
        //建立滤镜
        let filter = CIFilter(name: "CIQRCodeGenerator")
        //还原滤镜的预设属性
        filter?.setDefaults()
        //设定需要生成二维码的资料
        filter?.setValue(text.data(using: String.Encoding.utf8), forKey: "inputMessage")
        //从滤镜中取出生成的图片
        let ciImage = filter?.outputImage
        //这个清晰度好
        let bgImage = createNonInterpolatedUIImageFormCIImage(image: ciImage!, size: CGSize(width: WH, height: WH))
        return bgImage
    }
    
    private func createNonInterpolatedUIImageFormCIImage(image: CIImage, size: CGSize) -> UIImage {
        
        let extent: CGRect = image.extent.integral
        let scale: CGFloat = min(size.width / extent.width, size.height / extent.height)
        
        let width = extent.width * scale
        let height = extent.height * scale
        let cs: CGColorSpace = CGColorSpaceCreateDeviceGray()
        let bitmapRef = CGContext(data: nil, width: Int(width), height: Int(height), bitsPerComponent: 8, bytesPerRow: 0, space: cs, bitmapInfo: 0)!
        
        let context = CIContext(options: nil)
        let bitmapImage: CGImage = context.createCGImage(image, from: extent)!
        
        bitmapRef.interpolationQuality = .none
        bitmapRef.scaleBy(x: scale, y: scale)
        bitmapRef.draw(bitmapImage, in: extent)
        let scaledImage: CGImage = bitmapRef.makeImage()!
        return UIImage(cgImage: scaledImage)
    }
    
    //MARK:-保存图片到相簿
       @objc private func saveImage(image:UIImage,didFinishSavingWithError error:Error?,contextInfo:UnsafeMutableRawPointer) {
           if error == nil {
               mm_showToast("已成功保存到相簿!", type: .succeed)
           }
       }
}
