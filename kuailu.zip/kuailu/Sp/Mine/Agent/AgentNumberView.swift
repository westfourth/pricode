//
//  AgentNumberView.swift
//  Sp
//
//  Created by mac on 2020/4/21.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class AgentNumberView: UIView {
    
    static let rowHeight: CGFloat = 70 * AgentVC.ratio
    
    var dataModel: AgentInfo? {
        didSet {
            collectionView.reloadData()
        }
    }
    
    private lazy var collectionView: UICollectionView = {
        let layout = UICollectionViewFlowLayout()
        layout.itemSize = CGSize(width: AgentNumberCell.cellWidth, height: AgentNumberView.rowHeight)
        layout.minimumLineSpacing = 9
        layout.minimumInteritemSpacing = 0
        layout.scrollDirection = .horizontal
        let cv = UICollectionView(frame: .zero, collectionViewLayout: layout)
        cv.register(AgentNumberCell.self, forCellWithReuseIdentifier: "AgentNumberCell")
        cv.backgroundColor = .none
        cv.delegate = self
        cv.dataSource = self
        cv.showsHorizontalScrollIndicator = false
        return cv
    }()
    
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        addSubview(collectionView)
        
        collectionView.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}


extension AgentNumberView: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout  {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return AgentVC.agentLevelArr.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "AgentNumberCell", for: indexPath) as! AgentNumberCell
        let row = indexPath.row
        cell.titleLabel.text = AgentVC.agentLevelArr[row]
        guard let item = dataModel else { return cell }
        cell.valLabel.text = "\(row == 0 ? item.inviteUserNum : row == 1 ? item.twoInviteUserNum : row == 2 ? item.threeInviteUserNum : item.fourInviteUserNum)"
        return cell
    }
}
