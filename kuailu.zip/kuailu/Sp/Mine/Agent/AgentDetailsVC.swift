//
//  AgentDetailsView.swift
//  Sp
//
//  Created by mac on 2020/4/21.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class AgentDetailsVC: UIViewController {
    
    static let rowHeight: CGFloat = 60
    
    private lazy var pageNum: Int = 0
    
    private var listData: [AgentListItem] = [] {
        didSet{
            tableView.reloadData()
        }
    }
    
    private lazy var leftTitleLabel: UILabel = {
        let label = UILabel()
        label.text = "推廣人"
        label.font = UIFont.pingFangMedium(16)
        label.textColor = .white
        return label
    }()
    
    private lazy var rightTitleLabel: UILabel = {
        let label = UILabel()
        label.text = "金額"
        label.font = UIFont.pingFangMedium(16)
        label.textColor = .white
        return label
    }()
    
    private lazy var tableView: UITableView = {
        let tableView = UITableView(frame: CGRect.zero, style: .plain)
        tableView.delegate = self
        tableView.dataSource = self
        tableView.backgroundColor = .none
        tableView.estimatedRowHeight = 0
        tableView.estimatedSectionFooterHeight = 0
        tableView.estimatedSectionHeaderHeight = 0
        tableView.showsVerticalScrollIndicator = false
        tableView.rowHeight = AgentDetailsVC.rowHeight
        tableView.register(AgentDetailsCell.self, forCellReuseIdentifier: "AgentDetailsCell")
        tableView.separatorColor = RGB(0x25264D)
        tableView.tableFooterView = UIView()
        tableView.state = .loading
        tableView.mj_header = getCommonMJHeader(refreshingTarget: self, headerRefreshCallback: #selector(onRefresh))
        tableView.mj_footer = getCommonMJFooter(refreshingTarget: self, footerRefreshCallback: #selector(onLoad))
        return tableView
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationItem.title = "業績明細"
        navigationController?.navigationBar.barTintColor = RGB(0x141516)
        view.backgroundColor = RGB(0x141516)
        renderView()
        
        getList(isRefresh: true)
    }
    
    private func renderView() {
        view.addSubview(leftTitleLabel)
        view.addSubview(rightTitleLabel)
        view.addSubview(tableView)
        
        leftTitleLabel.snp.makeConstraints { (make) in
            make.top.equalToSuperview()
            make.centerX.equalToSuperview().dividedBy(2)
            make.height.equalTo(48)
        }
        rightTitleLabel.snp.makeConstraints { (make) in
            make.top.equalToSuperview()
            make.centerX.equalToSuperview().multipliedBy(1.5)
            make.height.equalTo(48)
        }
        tableView.snp.makeConstraints { (make) in
            make.top.equalTo(leftTitleLabel.snp.bottom)
            make.left.right.bottom.equalToSuperview()
        }
    }
    
    private func getList(isRefresh: Bool) {
        tableView.state = listData.isEmpty ? .loading : .normal
        let req = AgentListReq()
        req.createdAt =  isRefresh ? nil : listData.last!.createdAt
        if  isRefresh {
            tableView.mj_footer?.resetNoMoreData()
        }
        let tableView = self.tableView
        Session.request(req) { [weak self] (error, resp) in
            isRefresh ? tableView.mj_header?.endRefreshing() : tableView.mj_footer?.endRefreshing()
            guard let `self` = self else { return }
            guard error == nil else {
                self.handleListException(isRefresh: isRefresh)
                return
            }
            
            guard let resData = resp as? [AgentListItem] else {
                if isRefresh {
                    self.listData = []
                    tableView.mj_footer?.isHidden = true
                    tableView.state = .empty
                } else {
                    tableView.state = .normal
                    tableView.mj_footer?.endRefreshingWithNoMoreData()
                    tableView.mj_footer?.isHidden = false
                }
                return
            }
            
            self.listData = isRefresh ? resData : self.listData + resData
            
            if resData.count < req.pageSize {
                tableView.mj_footer?.endRefreshingWithNoMoreData()
            }
            
            if self.listData.isEmpty {
                tableView.state = .empty
                tableView.mj_footer?.isHidden = true
            } else {
                tableView.state = .normal
                tableView.mj_footer?.isHidden = false
            }
        }
    }
    
    private func handleListException(isRefresh: Bool) {
        if isRefresh {
            listData = []
            tableView.state = .failed
            tableView.mj_footer?.isHidden = true
        } else {
            tableView.state = .normal
            tableView.mj_footer?.endRefreshingWithNoMoreData()
            tableView.mj_footer?.isHidden = false
        }
    }
    
    @objc private func onLoad() {
        getList(isRefresh: false)
    }
    
    @objc private func onRefresh() {
        getList(isRefresh: true)
    }
}
extension AgentDetailsVC: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return listData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell  = tableView.dequeueReusableCell(withIdentifier: "AgentDetailsCell", for: indexPath) as! AgentDetailsCell
        cell.dataModel = listData[indexPath.row]
        return cell
        
    }
    
}
