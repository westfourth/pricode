//
//  AgentDetailsCell.swift
//  Sp
//
//  Created by mac on 2020/4/21.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class AgentDetailsCell: UITableViewCell {
    
    var dataModel: AgentListItem? {
        didSet{
            guard let item = dataModel else { return }
            nicknameLabel.text = item.nikeName
            amountLabel.text = numberZeroTruncationFormat(item.amount)
        }
    }
    
    lazy var nicknameLabel: UILabel = {
        let label = UILabel()
        label.textColor = RGB(0xE6C08E)
        label.font = UIFont.pingFangRegular(13)
        label.numberOfLines = 1
        label.textAlignment = .center
        return label
    }()
    
    lazy var amountLabel: UILabel = {
        let label = UILabel()
        label.textColor = RGB(0xE6C08E)
        label.font = UIFont.pingFangRegular(13)
        label.numberOfLines = 1
        label.textAlignment = .center
        return label
    }()
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        backgroundColor = .none
        selectionStyle = .none
        renderView()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func renderView() {
        contentView.addSubview(nicknameLabel)
        contentView.addSubview(amountLabel)
        
        nicknameLabel.snp.makeConstraints { (make) in
            make.centerY.equalToSuperview()
            make.centerX.equalToSuperview().dividedBy(2)
            make.width.equalToSuperview().dividedBy(2)
        }
        
        amountLabel.snp.makeConstraints { (make) in
            make.centerY.equalToSuperview()
            make.centerX.equalToSuperview().multipliedBy(1.5)
            make.width.equalToSuperview().dividedBy(2)
        }
    }
}
