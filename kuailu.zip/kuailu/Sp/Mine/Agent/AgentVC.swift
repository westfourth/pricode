//
//  AgentVC.swift
//  Sp
//
//  Created by mac on 2020/4/21.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class AgentVC: UIViewController {
    
    static let ratio: CGFloat = (UIScreen.main.bounds.width - 12 * 2) / 336
    
    static let agentLevelArr: [String] = ["一級推廣","二級推廣","三級推廣","四級推廣"]
    
    private lazy var agentOverviewView: AgentOverviewView = {
        let agentOverviewView = AgentOverviewView()
        agentOverviewView.delegate = self
        return agentOverviewView
    }()
    
    private lazy var agentPerformanceView: AgentPerformanceView = {
        return AgentPerformanceView()
    }()
    
    private lazy var agentNumberView: AgentNumberView = {
        return AgentNumberView()
    }()
    
    private lazy var numberLabel: UILabel = {
        let label = UILabel()
        label.text = "推廣人數統計"
        label.textColor = RGB(0xF5D3A9)
        label.font = UIFont.pingFangMedium(14)
        return label
    }()
    
    private lazy var detailsBtn: UIButton = {
        let btn = UIButton()
        btn.setBackgroundImage(UIImage(named: "agent_btn"), for: .normal)
        btn.setTitle("查看業績明細", for: .normal)
        btn.setTitleColor(RGB(0x323232), for: .normal)
        btn.titleLabel?.font = UIFont.pingFangMedium(14)
        btn.addTarget(self, action: #selector(onDetailsBtnTap), for: .touchUpInside)
        return btn
    }()
    
    override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: Bundle?) {
        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
        hidesBottomBarWhenPushed = true
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        renderNavigator()
        view.backgroundColor = RGB(0x141516)
        renderView()
        getAgentData()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.navigationBar.barTintColor = RGB(0x141516)
        navigationController?.navigationBar.isTranslucent = false
    }
    
    private func renderNavigator() {
        navigationItem.title = "代理賺錢"
        navigationController?.navigationBar.barTintColor = RGB(0x141516)
        navigationItem.rightBarButtonItem = UIBarButtonItem(title: "規則", style: .done, target: self, action: #selector(onRuleTap))
        navigationItem.rightBarButtonItem?.tintColor = RGB(0xCCCCCD)
        navigationItem.rightBarButtonItem?.setTitleTextAttributes([NSAttributedString.Key.font: UIFont.pingFangMedium(16)], for: .normal)
    }
    
    private func renderView() {
        
        view.addSubview(agentOverviewView)
        view.addSubview(agentPerformanceView)
        view.addSubview(numberLabel)
        view.addSubview(agentNumberView)
        view.addSubview(detailsBtn)
        
        agentOverviewView.snp.makeConstraints { (make) in
            make.top.equalToSuperview().inset(17)
            make.left.right.equalToSuperview().inset(12)
            make.height.equalTo(157 * AgentVC.ratio)
        }
        
        agentPerformanceView.snp.makeConstraints { (make) in
            make.top.equalTo(agentOverviewView.snp.bottom).offset(11)
            make.left.right.equalToSuperview().inset(12)
            make.height.equalTo(AgentPerformanceView.rowHeight)
        }
        
        numberLabel.snp.makeConstraints { (make) in
            make.top.equalTo(agentPerformanceView.snp.bottom).offset(17)
            make.centerX.equalToSuperview()
            make.height.equalTo(20)
        }
        
        agentNumberView.snp.makeConstraints { (make) in
            make.top.equalTo(numberLabel.snp.bottom).offset(17)
            make.left.right.equalToSuperview().inset(12)
            make.height.equalTo(AgentNumberView.rowHeight)
        }
    
        detailsBtn.snp.makeConstraints { (make) in
            make.top.equalTo(agentNumberView.snp.bottom).offset(30)
            make.centerX.equalToSuperview()
        }
        
    }
    
    private func getAgentData() {
        Alert.showLoading(parentView: view)
        Session.request(AgentInfoReq()) { [weak self] (error, resp) in
            Alert.hideLoading()
            guard let `self` = self else { return }
            guard error == nil, let resData = resp as? AgentInfo else {
                mm_showToast(error!.localizedDescription)
                return
            }
            self.agentOverviewView.dataModel = resData
            self.agentPerformanceView.dataModel = resData
            self.agentNumberView.dataModel = resData
        }
    }
    
    @objc private func onRuleTap() {
        let spreadVC = SpreadVC()
        spreadVC.hidesBottomBarWhenPushed = true
        navigationController?.show(spreadVC, sender: nil)
    }
    
    @objc private func onDetailsBtnTap() {
        let agentDetailsVC = AgentDetailsVC()
        agentDetailsVC.hidesBottomBarWhenPushed = true
        navigationController?.show(agentDetailsVC, sender: nil)
    }
    
}

extension AgentVC: AgentOverviewViewDelegate {
    
    func onWithdrawTap() {
        let walletWithdrawVC = WalletWithdrawVC()
        walletWithdrawVC.isBalance = true
        walletWithdrawVC.hidesBottomBarWhenPushed = true
        navigationController?.show(walletWithdrawVC, sender: nil)
    }
    
}
