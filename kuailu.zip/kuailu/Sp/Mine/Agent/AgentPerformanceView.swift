//
//  AgentPerformanceView.swift
//  Sp
//
//  Created by mac on 2020/4/21.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class AgentPerformanceView: UIView {
    
    static let rowHeight: CGFloat = 72 * AgentVC.ratio
    
    static let incomeLabelArr: [String] = ["當月收益","當月業績","當月推廣人數"]
    
    var dataModel: AgentInfo? {
        didSet {
            collectionView.reloadData()
        }
    }
    
    private lazy var leftSplitImgView: UIImageView = {
        return UIImageView(image: UIImage(named: "agent_line"))
    }()
    
    private lazy var rightSplitImgView: UIImageView = {
        return UIImageView(image: UIImage(named: "agent_line"))
    }()
    
    private lazy var collectionView: UICollectionView = {
        let layout = UICollectionViewFlowLayout()
        layout.itemSize = CGSize(width: AgentPerformanceCell.cellWidth, height: AgentPerformanceView.rowHeight)
        layout.minimumLineSpacing = 0
        layout.minimumInteritemSpacing = 0
        layout.scrollDirection = .horizontal
        let cv = UICollectionView(frame: .zero, collectionViewLayout: layout)
        cv.register(AgentPerformanceCell.self, forCellWithReuseIdentifier: "AgentPerformanceCell")
        cv.backgroundColor = .none
        cv.delegate = self
        cv.dataSource = self
        cv.showsHorizontalScrollIndicator = false
        return cv
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = RGB(0x34355D)
        layer.masksToBounds = true
        layer.cornerRadius = 4
        renderView()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func renderView() {
        
        addSubview(collectionView)
        addSubview(leftSplitImgView)
        addSubview(rightSplitImgView)
        
        collectionView.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
        
        
        leftSplitImgView.snp.makeConstraints { (make) in
            make.centerY.equalToSuperview()
            make.centerX.equalToSuperview().multipliedBy(0.666666)
            make.width.equalTo(1)
            make.height.equalTo(58 * AgentVC.ratio)
        }
        
        rightSplitImgView.snp.makeConstraints { (make) in
            make.centerY.equalToSuperview()
            make.centerX.equalToSuperview().multipliedBy(1.333333)
            make.width.equalTo(1)
            make.height.equalTo(58 * AgentVC.ratio)
        }
    }
    
}

extension AgentPerformanceView: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout  {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return AgentPerformanceView.incomeLabelArr.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "AgentPerformanceCell", for: indexPath) as! AgentPerformanceCell
        let row = indexPath.row
        cell.titleLabel.text = AgentPerformanceView.incomeLabelArr[row]
        guard let item = dataModel else { return cell }
        cell.valLabel.text =  row == 0 ? numberZeroTruncationFormat(item.brokerageMonth) : row == 1 ? numberZeroTruncationFormat(item.performanceMonth) : "\(item.inviteUserMonthNum)"
        return cell
    }
}
