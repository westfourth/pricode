    //
    //  AgentNumberCell.swift
    //  Sp
    //
    //  Created by mac on 2020/4/21.
    //  Copyright © 2020 mac. All rights reserved.
    //
    
    import UIKit
    
    class AgentNumberCell: UICollectionViewCell {
        
        static let cellWidth: CGFloat = (UIScreen.main.bounds.width - 12 * 2 - 9 * 3) / 4
        
        lazy var titleLabel: UILabel = {
            let label = UILabel()
            label.textColor = .white
            label.font = UIFont.pingFangRegular(13)
            return label
        }()
        
        lazy var valLabel: UILabel = {
            let label = UILabel()
            label.text = "0"
            label.textColor = RGB(0xE6C08E)
            label.font = UIFont.pingFangRegular(13)
            return label
        }()
        
        override init(frame: CGRect) {
            super.init(frame: frame)
            backgroundColor = RGB(0x1F2048)
            layer.cornerRadius = 4
            clipsToBounds = true
            renderView()
        }
        
        required init?(coder aDecoder: NSCoder) {
            fatalError("init(coder:) has not been implemented")
        }
        
        private func renderView() {
            contentView.addSubview(titleLabel)
            contentView.addSubview(valLabel)
        
            titleLabel.snp.makeConstraints { (make) in
                make.centerX.equalToSuperview()
                make.top.equalToSuperview().inset(AgentVC.ratio * 13)
            }
            
            valLabel.snp.makeConstraints { (make) in
                make.centerX.equalToSuperview()
                make.bottom.equalToSuperview().inset(AgentVC.ratio * 11)
            }
        }
    }
