//
//  AgentOverviewView.swift
//  Sp
//
//  Created by mac on 2020/4/21.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

protocol AgentOverviewViewDelegate: NSObjectProtocol {
    
    func onWithdrawTap()
    
}

class AgentOverviewView: UIView {
    
    weak var delegate: AgentOverviewViewDelegate?
    
    var dataModel: AgentInfo? {
        didSet {
            guard let item = dataModel else { return }
            performanceValLabel.text = numberZeroTruncationFormat(item.performance)
            incomeValLabel.text = numberZeroTruncationFormat(item.brokerage)
        }
    }
    
    private lazy var bgImgView: UIImageView = {
        let imgView = UIImageView(image: UIImage(named: "agent_bg"))
        imgView.layer.cornerRadius = 4
        imgView.layer.masksToBounds = true
        return imgView
    }()
    
    private lazy var performanceLabel: UILabel = {
        let label = UILabel()
        label.text = "總業績"
        label.textColor = .white
        label.font = UIFont.pingFangMedium(13)
        return label
    }()
    
    private lazy var performanceValLabel: UILabel = {
        let label = UILabel()
        label.text = "0"
        label.textColor = .white
        label.font = UIFont.pingFangMedium(16)
        return label
    }()
    
    private lazy var incomeLabel: UILabel = {
        let label = UILabel()
        label.text = "總收益"
        label.textColor = .white
        label.font = UIFont.pingFangMedium(13)
        return label
    }()
    
    private lazy var incomeValLabel: UILabel = {
        let label = UILabel()
        label.text = "0"
        label.textColor = .white
        label.font = UIFont.pingFangMedium(16)
        return label
    }()
    
    private lazy var withdrawBtn: UIButton = {
        let btn = UIButton()
        btn.setBackgroundImage(UIImage(named: "agent_btn"), for: .normal)
        btn.setTitle(Sensitive.ti, for: .normal)
        btn.setTitleColor(RGB(0x323232), for: .normal)
        btn.titleLabel?.font = UIFont.pingFangMedium(14)
        btn.addTarget(self, action: #selector(onBtnTap), for: .touchUpInside)
        return btn
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        renderView()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func renderView() {
        addSubview(bgImgView)
        addSubview(performanceLabel)
        addSubview(incomeLabel)
        addSubview(performanceValLabel)
        addSubview(incomeValLabel)
        addSubview(withdrawBtn)
        
        let ratio = AgentVC.ratio
        
        bgImgView.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
        
        performanceLabel.snp.makeConstraints { (make) in
            make.top.equalToSuperview().inset(20 * ratio)
            make.left.equalToSuperview().inset(59 * ratio)
            make.height.equalTo(18)
        }
        
        incomeLabel.snp.makeConstraints { (make) in
            make.top.equalToSuperview().inset(20 * ratio)
            make.right.equalToSuperview().inset(59 * ratio)
            make.height.equalTo(18)
        }
        
        performanceValLabel.snp.makeConstraints { (make) in
            make.top.equalTo(performanceLabel.snp.bottom).offset(19 * ratio)
            make.centerX.equalTo(performanceLabel)
        }
        
        incomeValLabel.snp.makeConstraints { (make) in
            make.top.equalTo(incomeLabel.snp.bottom).offset(19 * ratio)
            make.centerX.equalTo(incomeLabel)
        }
        
        withdrawBtn.snp.makeConstraints { (make) in
            make.bottom.equalToSuperview().inset(13)
            make.centerX.equalToSuperview()
            make.width.equalTo(216)
            make.height.equalTo(32)
        }
    }
    
    @objc private func onBtnTap() {
        delegate?.onWithdrawTap()
    }
}
