//
//  SettingVC.swift
//  Sp
//
//  Created by mac on 2020/2/27.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit
import M3U8

class SettingVC: UIViewController {
    
    var titles: [String] = ["手機號碼", "\(Sensitive.dui)碼","邀請碼","視頻上傳規則", "全民代理","賬號憑證","找回賬號","聯繫官方", "清理緩存", "檢查更新"]
    var cacheSize: UInt = 0;
    
    private static let emptyImg: UIImage = {
        return UIImage()
    }()
    
    //MARK:-    生命周期
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "設定"
        view.backgroundColor = RGB(0xff141516)
        renderNavigator()
        view.addSubview(self.tableView)
        self.tableView.snp.makeConstraints { (make) in
            make.left.top.right.bottom.equalTo(0)
        }
        view.addSubview(self.switchAccount)
        self.switchAccount.snp.makeConstraints { (make) in
            make.centerX.equalToSuperview()
            make.width.equalTo(270)
            make.height.equalTo(44)
            make.bottom.equalTo(-40)
        }
        DispatchQueue.main.async {
            self.cacheSize = M3U8CacheManager.size()
            self.tableView.reloadData()
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        renderNavigator()
    }
    
    private func renderNavigator() {
        navigationController?.navigationBar.barTintColor = RGB(0xff141516)
        navigationController?.navigationBar.setBackgroundImage(SettingVC.emptyImg, for: UIBarMetrics.default)
        navigationController?.navigationBar.shadowImage = SettingVC.emptyImg
    }
    
    lazy var tableView : UITableView = {
        let tableView = UITableView.init(frame: CGRect.zero, style: .plain)
        tableView.delegate = self
        tableView.dataSource = self
        tableView.clipsToBounds = true
        tableView.backgroundColor = UIColor.clear
        tableView.separatorStyle = UITableViewCell.SeparatorStyle.none
        tableView.isScrollEnabled = false
        tableView.rowHeight = 44
        tableView.register(UINib(nibName: "SettingCell", bundle: Bundle.main), forCellReuseIdentifier: "cell")
        return tableView
    }()
    
    lazy var switchAccount:UIButton = {
        let button = UIButton()
        button.setTitle("切換賬號", for: UIControl.State.normal)
        button.clipsToBounds = true
        button.layer.cornerRadius = 22
        button.titleLabel?.font = UIFont.systemFont(ofSize: 16, weight: UIFont.Weight.medium)
        button.setTitleColor(UIColor.white, for: UIControl.State.normal)
        button.addTarget(self, action: #selector(self.switchAccountAction), for: UIControl.Event.touchUpInside)
        Appearance.gradient(view: button, style: .orange)
        return button
    }()
    
    @objc func switchAccountAction() {
        self.navigationController?.pushViewController(LoginVC(), animated: true)
    }
}

// MARK: -UITableViewDataSource && Delegate
extension SettingVC:UITableViewDataSource,UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell") as! SettingCell
        let titleX = self.titles[indexPath.row]
        var detail = ""
        if titleX == "手機號碼" {
            if let user = NetDefaults.userInfo {
                detail = user.mobile != "" ? user.mobile : "未綁定"
            }
        } else if titleX == "檢查更新" {
            detail = "V\(NetDefaults.version)"
        } else if titleX == "清理緩存" {
            detail = "\(self.cacheSize / 1024 / 1024)M"
        }
        cell.set("ic_shezhi_\(indexPath.row + 1)", titles[indexPath.row], detail)
        return cell
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return titles.count
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let titleX = self.titles[indexPath.row]
        if titleX == "手機號碼" {
            clickPhoneNumber()
        } else if titleX == "視頻上傳規則" {
            let uploadRuleVC = UploadRuleVC()
            self.navigationController?.show(uploadRuleVC, sender: nil)
        } else if titleX == "\(Sensitive.dui)碼" {
            self.navigationController?.show(ExchangeVC(), sender: nil)
        }  else if titleX == "清理緩存" {
            clearCache()
        } else if titleX == "全民代理" {
            navigationController?.pushViewController(AgentVC(), animated: true)
        } else if titleX == "檢查更新"{
            checkVersionUpdate()
        } else if titleX == "找回賬號" {
            self.navigationController?.show(AccountRecoverVC(), sender: nil)
        } else if titleX == "賬號憑證" {
            self.navigationController?.show(AccountCerVC(), sender: nil)
        } else if titleX == "邀請碼"  {
            self.navigationController?.show(InviteVC(), sender: nil)
        } else if titleX == "聯繫官方" {
            self.navigationController?.show(InviteAgentVC(), sender: nil)
        }
    }
    
    //MARK:-    点击事件
    
    //  手机号码
    func clickPhoneNumber() {
        if let user = NetDefaults.userInfo, user.mobile == "" {
            //绑定手机号
            self.navigationController?.pushViewController(LoginVC(), animated: true)
        } else {
            //更换手机号页面
            let VC = ChangeMobileVC()
            VC.tel = NetDefaults.userInfo?.mobile
            Alert.showCommonAlert(parentView: self.view,
                                  contentText: "更換已綁定的手機號碼？",
                                  cancelText: "取消",
                                  confirmText: "更換",
                                  onConfirmTap: {
                                    self.navigationController?.pushViewController(VC, animated: true)
                                    
                                  }, onCancelTap: nil)
        }
    }
    
    //  清理缓存
    func clearCache() {
        M3U8CacheManager.clear()
        mm_showToast("清理成功!", type: .succeed)
        self.cacheSize = 0
        tableView.reloadData()
    }
    
    //  版本更新
    func checkVersionUpdate() {
        Alert.showLoading(parentView: self.view)
        let req = VersionUpadateReq()
        Session.request(req) { (error, resp) in
            Alert.hideLoading()
            
            guard error == nil, let item = resp as? VersionUpadateResp else {
                mm_showToast(error!.localizedDescription)
                return
            }
            
            guard item.hasNewVersion else {
                mm_showToast("已是最新版啦!", type: .succeed)
                return
            }
            
            guard let url = item.link, InnerIntercept.canOpenURL(url) else {
                mm_showToast("下載鏈接不合法!", type: .failed)
                return
            }
            
            InnerIntercept.open(url)
        }
    }
}
