//
//  UploadRuleVC.swift
//  Sp
//
//  Created by mac on 2020/3/6.
//  Copyright © 2020 mac. All rights reserved.
//

class UploadRuleVC: UIViewController {
    
    private lazy var firstTitleLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.pingFangMedium(15)
        label.textColor = .white
        label.text = "上傳規則及要求:"
        return label
    }()
    
    private lazy var firstRuleLabel: UILabel = {
        let label = UILabel()
        label.numberOfLines = 0
        let ruleTipText = """
    1.每位用戶每日可申請上傳10部視頻
    2.上傳視頻要求：豎屏格式為9:16（觀看角度也需要是豎屏），MP4或MOV格式，畫質高清，內容豐富（禁止上傳反人類例如幼女人獸等題材），無水印鏈接廣告與個人聯繫方式，時長為三十秒以上，五分鐘以下，視頻內存大小控制在200M以下，十部視頻裡面可以根據質量設置1到3部金幣視頻。
    3.平台會對所有上傳的視頻進行內容審核，審核周期為24小時，通過後視頻內容可在首頁展示，通過後可在個人資料-視頻內查看
    """
        let paraph = NSMutableParagraphStyle()
        paraph.lineSpacing = 6 // 字型的行間距
        let attributes = [NSAttributedString.Key.font: UIFont.pingFangRegular(13),
                          NSAttributedString.Key.foregroundColor: UIColor.white.withAlphaComponent(0.5),
                          NSAttributedString.Key.paragraphStyle: paraph]
        label.attributedText = NSAttributedString(string: ruleTipText, attributes: attributes)
        return label
    }()
    
    private lazy var secondTitleLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.pingFangMedium(15)
        label.textColor = .white
        label.text = "上傳違規的處理辦法:"
        return label
    }()
    
    private lazy var secondRuleLabel: UILabel = {
        let label = UILabel()
        label.numberOfLines = 0
        let ruleTipText = """
    1.上傳視頻內容不符合要求的審核不通過
    2.在視頻任意位置，添加聯繫方式或插入廣告的，不予審核，情形嚴重者，將封號處理
    """
        let paraph = NSMutableParagraphStyle()
        paraph.lineSpacing = 6 // 字型的行間距
        let attributes = [NSAttributedString.Key.font: UIFont.pingFangRegular(13),
                          NSAttributedString.Key.foregroundColor: UIColor.white.withAlphaComponent(0.5),
                          NSAttributedString.Key.paragraphStyle: paraph]
        label.attributedText = NSAttributedString(string: ruleTipText, attributes: attributes)
        return label
    }()
    
    private lazy var tipTitleLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.pingFangRegular(13)
        label.textColor = RGB(0xFFE05D)
        label.text = "溫馨提示:"
        return label
    }()
    
    private lazy var tipLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.pingFangRegular(13)
        label.textColor = RGB(0xFFE05D)
        label.text = "平台將不定期對本規則進行補充，請各位視頻主及時關注調整動態，避免違規，本須知所有內容的最終解釋權歸平台所有，若有其他需要 咨詢的問題，請聯繫在線客服哦~"
        label.numberOfLines = 0
        return label
    }()
    
    private lazy var comfirmBtn: UIButton = {
        let btn = UIButton()
        btn.setTitle("已閱讀", for: .normal)
        btn.setTitleColor(.white, for: .normal)
        btn.titleLabel?.font = UIFont.pingFangMedium(17)
        Appearance.gradient(view: btn, style: .orange)
        btn.layer.cornerRadius = 22
        btn.layer.masksToBounds = true
        btn.addTarget(self, action: #selector(onComfirmTap), for: .touchUpInside)
        return btn
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationItem.title = "\(Sensitive.cao)視頻上傳須知"
        view.backgroundColor = RGB(0xff141516)
        renderView()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        renderNavigator()
    }
    
    private func renderNavigator() {
        navigationController?.navigationBar.shadowImage = UIImage()
        navigationController?.navigationBar.isTranslucent = false
    }
    
    private func renderView() {
        view.addSubview(firstTitleLabel)
        view.addSubview(firstRuleLabel)
        view.addSubview(secondTitleLabel)
        view.addSubview(secondRuleLabel)
        view.addSubview(tipTitleLabel)
        view.addSubview(tipLabel)
        view.addSubview(comfirmBtn)
        
        firstTitleLabel.snp.makeConstraints { (make) in
            make.top.equalToSuperview().offset(5)
            make.left.right.equalToSuperview().inset(12)
        }
        
        firstRuleLabel.snp.makeConstraints { (make) in
            make.top.equalTo(firstTitleLabel.snp.bottom).offset(12)
            make.left.right.equalToSuperview().inset(12)
        }
        
        secondTitleLabel.snp.makeConstraints { (make) in
            make.top.equalTo(firstRuleLabel.snp.bottom).offset(20)
            make.left.right.equalToSuperview().inset(12)
        }
        
        secondRuleLabel.snp.makeConstraints { (make) in
            make.top.equalTo(secondTitleLabel.snp.bottom).offset(12)
            make.left.right.equalToSuperview().inset(12)
        }
        
        tipTitleLabel.snp.makeConstraints { (make) in
            make.top.equalTo(secondRuleLabel.snp.bottom).offset(20)
            make.left.right.equalToSuperview().inset(12)
        }
        
        tipLabel.snp.makeConstraints { (make) in
            make.top.equalTo(tipTitleLabel.snp.bottom)
            make.left.right.equalToSuperview().inset(12)
        }
        
        comfirmBtn.snp.makeConstraints { (make) in
            make.top.equalTo(tipLabel.snp.bottom).offset(IS_IPHONEX ? 40 : 20)
            make.centerX.equalToSuperview()
            make.width.equalTo(270)
            make.height.equalTo(44)
        }
    }
    
    @objc private func onComfirmTap() {
        navigationController?.popViewController(animated: true)
    }
}
