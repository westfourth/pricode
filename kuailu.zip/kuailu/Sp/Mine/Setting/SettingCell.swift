//
//  SettingCell.swift
//  Sp
//
//  Created by mac on 2020/2/27.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class SettingCell: UITableViewCell {
    
    @IBOutlet weak var icon: UIImageView!
    @IBOutlet weak var name: UILabel!
    @IBOutlet weak var detail: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        self.backgroundColor = UIColor.clear
        self.contentView.backgroundColor = UIColor.clear
        self.selectionStyle = .none
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    
    func set(_ icon:String,_ name:String,_ detail:String) {
        self.icon.image = UIImage(named: icon)
        self.name.text = name
        self.detail.text = detail
    }
    @IBOutlet weak var nameLeftCons: NSLayoutConstraint!
    var isAccountRecover:Bool = false {
        didSet {
            nameLeftCons.constant = isAccountRecover ? 13:49
        }
    }
}
