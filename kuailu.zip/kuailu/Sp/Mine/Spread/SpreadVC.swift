//
//  SpreadVC.swift
//  Sp
//
//  Created by mac on 2020/3/24.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class SpreadVC: UIViewController {
    
    private lazy var scrollView: UIScrollView = {
        let scrollView = UIScrollView()
        let clientWidth = UIScreen.main.bounds.width
        scrollView.contentSize = CGSize(width: view.width, height: clientWidth * SpreadView.spreadImgViewRatio + 20 + clientWidth * SpreadView.middleImgViewRatio + 20 + clientWidth * SpreadView.footerImgViewRatio)
        scrollView.isScrollEnabled = true
        scrollView.isUserInteractionEnabled = true
        scrollView.showsVerticalScrollIndicator = false
        scrollView.backgroundColor = RGB(0x0E0D25)
        return scrollView
    }()
    
    private lazy var spreadView: SpreadView = {
        let view = SpreadView()
        view.backgroundColor = RGB(0x0E0D25)
        return view
    }()
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.navigationBar.setBackgroundImage(UIImage(named: "navi_backImage"), for: UIBarMetrics.default)
        navigationController?.navigationBar.shadowImage = UIImage()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = RGB(0x0E0D25)
        navigationItem.title = "推廣權益"
        
        view.addSubview(scrollView)
        
        scrollView.addSubview(spreadView)
        
        scrollView.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
        
        spreadView.snp.makeConstraints { (make) in
            make.centerX.top.width.height.equalToSuperview()
        }
        
        loadData()
    }
    
    private func loadData() {
        Alert.showLoading(parentView: view)
        
        if let url = Defaults.shareURL {
            self.spreadView.codeImgView.image = creatQRCodeImage(text: url.absoluteString, WH: 104 * SpreadView.ratio)
        }
        
        Session.request(ShareLinkReq()) { [weak self] (error, resp) in
            Alert.hideLoading()
            guard let `self` = self else { return }
            guard error == nil, let item = resp as? ShareLinkResp, let urlStr = item.url?.absoluteString else {
                mm_showToast(error!.localizedDescription)
                return
            }
            //            let splitedArr = urlStr.components(separatedBy: "?p=")
            //            if splitedArr.count > 1 {
            //                self.spreadCodeLabel.text = splitedArr[1]
            //            }
            self.spreadView.shareLink = item.linkText == nil ? urlStr : item.linkText! + "：" + urlStr
            self.spreadView.codeImgView.image = self.creatQRCodeImage(text:urlStr, WH: 104 * SpreadView.ratio)
        }
    }
    
    //MARK:- 生成二维码
    private func creatQRCodeImage(text: String, WH: CGFloat) -> UIImage{
        
        //建立滤镜
        let filter = CIFilter(name: "CIQRCodeGenerator")
        //还原滤镜的预设属性
        filter?.setDefaults()
        //设定需要生成二维码的资料
        filter?.setValue(text.data(using: String.Encoding.utf8), forKey: "inputMessage")
        //从滤镜中取出生成的图片
        let ciImage = filter?.outputImage
        //这个清晰度好
        let bgImage = createNonInterpolatedUIImageFormCIImage(image: ciImage!, size: CGSize(width: WH, height: WH))
        return bgImage
    }
    
    private func createNonInterpolatedUIImageFormCIImage(image: CIImage, size: CGSize) -> UIImage {
        
        let extent: CGRect = image.extent.integral
        let scale: CGFloat = min(size.width / extent.width, size.height / extent.height)
        
        let width = extent.width * scale
        let height = extent.height * scale
        let cs: CGColorSpace = CGColorSpaceCreateDeviceGray()
        let bitmapRef = CGContext(data: nil, width: Int(width), height: Int(height), bitsPerComponent: 8, bytesPerRow: 0, space: cs, bitmapInfo: 0)!
        
        let context = CIContext(options: nil)
        let bitmapImage: CGImage = context.createCGImage(image, from: extent)!
        
        bitmapRef.interpolationQuality = .none
        bitmapRef.scaleBy(x: scale, y: scale)
        bitmapRef.draw(bitmapImage, in: extent)
        let scaledImage: CGImage = bitmapRef.makeImage()!
        return UIImage(cgImage: scaledImage)
    }
}
