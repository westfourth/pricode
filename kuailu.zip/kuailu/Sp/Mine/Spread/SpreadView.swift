//
//  SpreadView.swift
//  Sp
//
//  Created by mac on 2020/3/24.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit
import Photos
class SpreadView: UIView {
    
    static let spreadImgViewRatio: CGFloat = 1433 / 1080
    
    static let middleImgViewRatio: CGFloat = 1540 / 1080
    
    static let footerImgViewRatio: CGFloat = 2481 / 1080
    
    static let ratio: CGFloat = UIScreen.main.bounds.width / 414
    
    private static let defaultImg: UIImage? = {
        return Sensitive.default_bg
    }()
    
    private static let headerSpreadImg: UIImage = {
        return UIImage.decrypt("spread_1.jpg.enc")
    }()
    
    private static var middleSpreadImg: UIImage = {
        return UIImage.decrypt("spread_2.jpg.enc")
    }()
    
    private static var footerSpreadImg: UIImage = {
        return UIImage.decrypt("spread_3.jpg.enc")
    }()
    
    private lazy var spreadImgView: UIImageView = {
        let imgView = UIImageView(image: SpreadView.headerSpreadImg)
        imgView.isUserInteractionEnabled = true
        imgView.addSubview(codeImgView)
        imgView.addSubview(spreadCodeLabel)
        imgView.addSubview(copyLinkBtn)
        imgView.addSubview(saveSpreadCodeBtn)
        
        let ratio = SpreadView.ratio
        
        codeImgView.snp.makeConstraints { (make) in
            make.centerY.equalToSuperview().offset(102 * ratio)
            make.centerX.equalToSuperview().dividedBy(1.97)
            make.size.equalTo(104 * ratio)
        }
        
        spreadCodeLabel.snp.makeConstraints { (make) in
            make.centerY.equalTo(codeImgView).offset(16.5 * ratio)
            make.centerX.equalToSuperview().multipliedBy(1.47)
        }
        
        copyLinkBtn.snp.makeConstraints { (make) in
            make.top.equalTo(codeImgView.snp.bottom).offset(55 * ratio)
            make.centerX.equalTo(codeImgView)
            make.width.equalTo(145)
            make.height.equalTo(42)
        }
        
        saveSpreadCodeBtn.snp.makeConstraints { (make) in
            make.centerY.equalTo(copyLinkBtn)
            make.centerX.equalTo(spreadCodeLabel)
            make.size.equalTo(copyLinkBtn)
        }
        return imgView
    }()
    
    lazy var codeImgView: UIImageView = {
        return UIImageView(image: SpreadView.defaultImg)
    }()
    
    private lazy var spreadCodeLabel: UILabel = {
        let label = UILabel()
        label.textColor = .white
        label.font = UIFont.pingFangMedium(16)
        return label
    }()
    
    private lazy var copyLinkBtn: UIButton = {
        let btn = UIButton()
        btn.setTitle("複製鏈接分享", for: .normal)
        btn.setTitleColor(RGB(0x2E2A21), for: .normal)
        btn.titleLabel?.font = UIFont.pingFangRegular(15)
        btn.addTarget(self, action: #selector(copySpreadLink), for: .touchUpInside)
        btn.setBackgroundImage(UIImage(named: "spread_btn_bg"), for: .normal)
        return btn
    }()
    
    private lazy var saveSpreadCodeBtn: UIButton = {
        let btn = UIButton()
        btn.setTitle("保存圖片分享", for: .normal)
        btn.setTitleColor(RGB(0x2E2A21), for: .normal)
        btn.titleLabel?.font = UIFont.pingFangRegular(15)
        btn.addTarget(self, action: #selector(isPHPhotoLibraryAuthorized), for: .touchUpInside)
        btn.setBackgroundImage(UIImage(named: "spread_btn_bg"), for: .normal)
        return btn
    }()
    
    private lazy var middleImgView: UIImageView = {
        return UIImageView(image: SpreadView.middleSpreadImg)
    }()
    
    private lazy var footerImgView: UIImageView = {
        return UIImageView(image: SpreadView.footerSpreadImg)
    }()
    
    var shareLink:String?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        if let user = NetDefaults.userInfo {
            spreadCodeLabel.text = user.inviteCode
        }
        renderView()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func renderView() {
        
        addSubview(spreadImgView)
        addSubview(middleImgView)
        addSubview(footerImgView)
        
        let clientWidth = UIScreen.main.bounds.width
        
        spreadImgView.snp.makeConstraints { (make) in
            make.top.left.right.equalToSuperview()
            make.height.equalTo(clientWidth * SpreadView.spreadImgViewRatio)
        }
        
        middleImgView.snp.makeConstraints { (make) in
            make.top.equalTo(spreadImgView.snp.bottom).offset(20)
            make.left.right.equalToSuperview()
            make.height.equalTo(clientWidth * SpreadView.middleImgViewRatio)
        }
        
        footerImgView.snp.makeConstraints { (make) in
            make.top.equalTo(middleImgView.snp.bottom).offset(20)
            make.left.right.equalToSuperview()
            make.height.equalTo(clientWidth * SpreadView.footerImgViewRatio)
        }
    }
    
    @objc private func copySpreadLink() {
        guard self.shareLink != nil else { return }
        UIPasteboard.general.string = self.shareLink
        mm_showToast("已經複製到貼上板!", type: .succeed)
    }
    
    @objc private func isPHPhotoLibraryAuthorized() {
        if #available(iOS 11.0, *) {
            PHPhotoLibrary.requestAuthorization { (status) in
                DispatchQueue.main.async {
                    status == .authorized || status == .notDetermined ? self.saveQRCode() : self.openSystemSettingPhotoLibrary()
                }
            }
        } else {
            self.canPhotoLibary() ? self.saveQRCode() : self.openSystemSettingPhotoLibrary()
        }
    }
    
    private func canPhotoLibary() -> Bool {
        let authStatus = PHPhotoLibrary.authorizationStatus()
        return authStatus == .authorized || authStatus == .notDetermined
    }
    
    //弹出弹窗去设置
    private func openSystemSettingPhotoLibrary() {
        let alert = UIAlertController(title:"未獲得許可權將圖片保存到相冊", message:"請前往設置-隱私-照片，打開相冊許可權", preferredStyle: .alert)
        let confirm = UIAlertAction(title:"馬上去設置", style: .default) { _ in
            let url = URL.init(string: UIApplication.openSettingsURLString)
            if  InnerIntercept.canOpenURL(url!) {
                InnerIntercept.open(url!)
            }
        }
        let cancel = UIAlertAction(title:"取消", style: .cancel, handler:nil)
        alert.addAction(cancel)
        alert.addAction(confirm)
        (UIApplication.shared.delegate as? AppDelegate)?.currentNavigationController?.present(alert, animated:true, completion:nil)
    }
    
    @objc private func saveQRCode() {
        let scrollView = self.superview as! UIScrollView
        scrollView.setContentOffset(CGPoint.zero, animated: true)
        UIGraphicsBeginImageContextWithOptions(self.bounds.size, true, UIScreen.main.scale)
        self.layer.render(in: UIGraphicsGetCurrentContext()!)
        let allImage = UIGraphicsGetImageFromCurrentImageContext()!
        let rect = CGRect(x: 0, y: 0, width: UIScreen.main.bounds.size.width * UIScreen.main.scale, height: 480 * SpreadView.ratio * UIScreen.main.scale)
        let partImage = UIImage(cgImage: allImage.cgImage!.cropping(to: rect)!, scale: UIScreen.main.scale, orientation: .up)
        UIGraphicsEndImageContext()
        UIImageWriteToSavedPhotosAlbum(partImage, self, #selector(saveImage(image:didFinishSavingWithError:contextInfo:)), nil)
    }
    
    //MARK:-保存图片到相簿
    @objc private func saveImage(image:UIImage,didFinishSavingWithError error:Error?,contextInfo:UnsafeMutableRawPointer) {
        if error == nil {
            mm_showToast("已成功保存到相簿!", type: .succeed)
        }
    }
}
