//
//  SmallVideoRecommendVC.swift
//  Sp
//
//  Created by mac on 2021/1/13.
//  Copyright © 2021 mac. All rights reserved.
//

import UIKit

class SmallVideoRecommendVC: UIViewController {
    
    private lazy var channelTypeHeightList: [CGFloat] = {
        return [0]
    }()
    
    private lazy var channelTypeClassList: [AnyClass] = {
        return [AVRecommendBannerView.self]
    }()
    
    private lazy var channelTypeKeyList: [String] = {
        return ["AVRecommendBannerView"]
    }()
    
    private lazy var searchBarView: AVRecommendSearchBarView = {
        return AVRecommendSearchBarView()
    }()
    
    private lazy var tableView: UITableView = {
        let tableView = UITableView(frame: .zero, style: .grouped)
        tableView.delegate = self
        tableView.dataSource = self
        tableView.backgroundColor = .none
        tableView.separatorStyle = .none
        tableView.bouncesZoom = false
        tableView.isDirectionalLockEnabled = true
        tableView.showsVerticalScrollIndicator = false
        tableView.showsHorizontalScrollIndicator = false
        tableView.contentInset = UIEdgeInsets(top: 0, left: 0, bottom: 20, right: 0)
        tableView.contentInsetAdjustmentBehavior = .never
        for i in 0..<channelTypeClassList.count {
            tableView.register(channelTypeClassList[i], forCellReuseIdentifier: channelTypeKeyList[i])
        }
        return tableView
    }()
    
    private var listData: [AVCategoryRecommendSubListResp] = []
    
    private var isInitState: Bool = true
    
    var classifyId: Int = 0 {
        didSet {
            guard isInitState else { return }
            isInitState = false
            getList()
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = RGB(0x141516)
        if #available(iOS 11.0, *) {
        } else {
            automaticallyAdjustsScrollViewInsets = false
        }
        renderView()
    }
    
    private func renderView() {
        view.addSubview(searchBarView)
        view.addSubview(tableView)
        
        searchBarView.snp.makeConstraints { (make) in
            make.top.equalToSuperview().inset(kTop + 10)
            make.left.right.equalToSuperview()
            make.height.equalTo(AVRecommendSearchBarView.viewHeight)
        }
        
        tableView.snp.makeConstraints { (make) in
            make.top.equalTo(searchBarView.snp.bottom).offset(20)
            make.left.right.equalToSuperview()
            make.bottom.equalToSuperview().inset(kBottom)
        }
    }
    
    private func getList() {
        let req = SmallVideoRecommendSubListReq()
        req.classifyId = classifyId
        Session.request(req) { [weak self] (error, resp) in
            guard let `self` = self, error == nil, let resData = resp as? [AVCategoryRecommendSubListResp], !resData.isEmpty else {
                return
            }
            self.listData = resData
            for i in 0..<resData.count {
                switch resData[i].type {
                case .horizontalFourGrid:
                    self.tableView.register(SmallVideoRecommendVerticalFourGridItemCell.self, forCellReuseIdentifier: "SmallVideoRecommendVerticalFourGridItemCell\(i)")
                    self.channelTypeHeightList.append(SmallVideoRecommendVerticalFourGridItemCell.viewHeight)
                    self.channelTypeClassList.append(SmallVideoRecommendVerticalFourGridItemCell.self)
                    self.channelTypeKeyList.append("SmallVideoRecommendVerticalFourGridItemCell\(i)")
                case .verticalSixGrid:
                    self.tableView.register(AVRecommendVerticalSixGridItemCell.self, forCellReuseIdentifier: "AVRecommendVerticalSixGridItemCell\(i)")
                    self.channelTypeHeightList.append(AVRecommendVerticalSixGridItemCell.viewHeight)
                    self.channelTypeClassList.append(AVRecommendVerticalSixGridItemCell.self)
                    self.channelTypeKeyList.append("AVRecommendVerticalSixGridItemCell\(i)")
                case .verticalFourGrid:
                    self.tableView.register(AVRecommendVerticalFourGridItemCell.self, forCellReuseIdentifier: "AVRecommendVerticalFourGridItemCell\(i)")
                    self.channelTypeHeightList.append(AVRecommendVerticalFourGridItemCell.viewHeight)
                    self.channelTypeClassList.append(AVRecommendVerticalFourGridItemCell.self)
                    self.channelTypeKeyList.append("AVRecommendVerticalFourGridItemCell\(i)")
                case .horizontalScrollHorizontalChannel:
                    self.tableView.register(AVRecommendHorizontalScrollHorizontalItemCell.self, forCellReuseIdentifier: "AVRecommendHorizontalScrollHorizontalItemCell\(i)")
                    self.channelTypeHeightList.append(AVRecommendHorizontalScrollHorizontalItemCell.viewHeight)
                    self.channelTypeClassList.append(AVRecommendHorizontalScrollHorizontalItemCell.self)
                    self.channelTypeKeyList.append("AVRecommendHorizontalScrollHorizontalItemCell\(i)")
                }
                
            }
            self.tableView.reloadData()
        }
    }
    
}

extension SmallVideoRecommendVC: UITableViewDelegate, UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return channelTypeClassList.count
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return .leastNonzeroMagnitude
    }
    
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return .leastNonzeroMagnitude
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        return nil
    }
    
    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        return nil
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return channelTypeHeightList[indexPath.section]
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let section = indexPath.section
        switch section {
        case 0:
            let cell = tableView.dequeueReusableCell(withIdentifier: "AVRecommendBannerView", for: indexPath) as! AVRecommendBannerView
            cell.delegate = self
            cell.type = .smallVideoRecommend
            cell.classifyId = classifyId
            return cell
        default:
            let currentData = listData[section - 1]
            switch currentData.type {
            case .horizontalFourGrid:
                let cell = tableView.dequeueReusableCell(withIdentifier: "SmallVideoRecommendVerticalFourGridItemCell\(section - 1)", for: indexPath) as! SmallVideoRecommendVerticalFourGridItemCell
                cell.dataModel = currentData
                return cell
            case .verticalSixGrid:
                let cell = tableView.dequeueReusableCell(withIdentifier: "AVRecommendVerticalSixGridItemCell\(section - 1)", for: indexPath) as! AVRecommendVerticalSixGridItemCell
                cell.type = .smallVideo
                cell.dataModel = currentData
                return cell
            case .verticalFourGrid:
                let cell = tableView.dequeueReusableCell(withIdentifier: "AVRecommendVerticalFourGridItemCell\(section - 1)", for: indexPath) as! AVRecommendVerticalFourGridItemCell
                cell.type = .smallVideo
                cell.dataModel = currentData
                return cell
            case .horizontalScrollHorizontalChannel:
                let cell = tableView.dequeueReusableCell(withIdentifier: "AVRecommendHorizontalScrollHorizontalItemCell\(section - 1)", for: indexPath) as! AVRecommendHorizontalScrollHorizontalItemCell
                cell.type = .smallVideo
                cell.dataModel = currentData
                return cell
            }
        }
    }
    
}

extension SmallVideoRecommendVC: AVRecommendBannerViewDelegate {
    
    func refreshTableView() {
        channelTypeHeightList[0] = AVRecommendBannerView.viewHeight
        tableView.reloadData()
    }
}
