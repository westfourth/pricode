//
//  SmallVideoRecommendVerticalFourGridItemCell.swift
//  Sp
//
//  Created by mac on 2021/1/13.
//  Copyright © 2021 mac. All rights reserved.
//

import UIKit

class SmallVideoRecommendVerticalFourGridItemCell: UITableViewCell {
    
    private static let itemRowNumber: Int = 2
    
    private static let itemColumnNumber: Int = 2
    
    static let itemInteritemSpacing: CGFloat = 8
    
    static let itemLineSpacing: CGFloat = 10
    
    static let itemEdgeInsetMargin: CGFloat = 12
    
    static let viewHeight: CGFloat = {
        return SmallVideoRecommendVerticalFourGridItemCell.topMargin + SmallVideoRecommendVerticalFourGridItemCell.headerViewHeight +  SmallVideoRecommendVerticalFourGridItemCell.collectionViewTopMargin + SmallVideoRecommendVerticalFourGridItemCell.collectionViewHeight + SmallVideoRecommendVerticalFourGridItemCell.moreBtnMarginTop + SmallVideoRecommendVerticalFourGridItemCell.moreBtnHeight + SmallVideoRecommendVerticalFourGridItemCell.marginBottom
    }()
    
    private static let collectionViewHeight: CGFloat = {
        return (SmallVideoRecommendVerticalFourGridCell.itemHeight + SmallVideoRecommendVerticalFourGridItemCell.itemLineSpacing) * CGFloat(SmallVideoRecommendVerticalFourGridItemCell.itemRowNumber) - SmallVideoRecommendVerticalFourGridItemCell.itemLineSpacing
    }()
    
    private static let headerViewHeight: CGFloat = 22
    
    private static let topMargin: CGFloat = 15
    
    private static let marginBottom: CGFloat = 20
    
    private static let collectionViewTopMargin: CGFloat = 15
    
    private static let moreBtnMarginTop: CGFloat = 18
    
    private static let moreBtnHeight: CGFloat = 38
    
    private static let arrowImg: UIImage? = {
        return UIImage(named: "recommend_arrow_yellow")
    }()
    
    private lazy var subjectLabel: UILabel = {
        let label = UILabel()
        label.textColor = Color.theme_color
        label.font = UIFont.pingFangMedium(18)
        return label
    }()
    
    private lazy var detailsLabel: UILabel = {
        let label = UILabel()
        label.textColor = .white
        label.font = UIFont.pingFangRegular(14)
        return label
    }()
    
    private lazy var moreBtn: UIButton = {
        let btn = UIButton()
        btn.setTitle("查看更多", for: .normal)
        btn.setTitleColor(.white, for: .normal)
        btn.setImage(SmallVideoRecommendVerticalFourGridItemCell.arrowImg, for: .normal)
        btn.titleLabel?.font = UIFont.pingFangRegular(14)
        btn.backgroundColor = rgb(0x313131)
        btn.addTarget(self, action: #selector(onMoreBtnTap), for: .touchUpInside)
        return btn
    }()
    
    private lazy var collectionView: UICollectionView = {
        let layout = UICollectionViewFlowLayout()
        layout.itemSize = CGSize(width: SmallVideoRecommendVerticalFourGridCell.itemWidth, height: SmallVideoRecommendVerticalFourGridCell.itemHeight)
        layout.minimumInteritemSpacing = SmallVideoRecommendVerticalFourGridItemCell.itemInteritemSpacing
        layout.minimumLineSpacing = SmallVideoRecommendVerticalFourGridItemCell.itemLineSpacing
        layout.sectionInset = UIEdgeInsets(top: 0, left: SmallVideoRecommendVerticalFourGridItemCell.itemEdgeInsetMargin, bottom: 0, right: SmallVideoRecommendVerticalFourGridItemCell.itemEdgeInsetMargin)
        let cv = UICollectionView(frame: .zero, collectionViewLayout: layout)
        cv.register(SmallVideoRecommendVerticalFourGridCell.self, forCellWithReuseIdentifier: "SmallVideoRecommendVerticalFourGridCell")
        cv.showsVerticalScrollIndicator = false
        cv.showsHorizontalScrollIndicator = false
        cv.bouncesZoom = false
        cv.bounces = false
        cv.backgroundColor = .none
        cv.isScrollEnabled = false
        cv.delegate = self
        cv.dataSource = self
        return cv
    }()
    
    private var listData: [VideoItem] = []
    
    private var isInitState: Bool = true
    
    private var isGetListState: Bool = false
    
    var dataModel: AVCategoryRecommendSubListResp? {
        didSet {
            guard isInitState else { return }
            isInitState = false
            guard let item = dataModel else{  return }
            subjectLabel.text = item.stationName
            detailsLabel.text = item.subName
            guard !item.videoList.isEmpty else { return }
            refreshCollectionView(listData: item.videoList)
        }
    }
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        backgroundColor = .none
        selectionStyle = .none
        renderView()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func renderView() {
        contentView.addSubview(subjectLabel)
        contentView.addSubview(detailsLabel)
        contentView.addSubview(collectionView)
        contentView.addSubview(moreBtn)
        
        subjectLabel.snp.makeConstraints { (make) in
            make.top.equalTo(SmallVideoRecommendVerticalFourGridItemCell.topMargin)
            make.left.equalToSuperview().inset(12)
            make.height.equalTo(SmallVideoRecommendVerticalFourGridItemCell.headerViewHeight)
        }
        
        detailsLabel.snp.makeConstraints { (make) in
            make.centerY.equalTo(subjectLabel)
            make.left.equalTo(subjectLabel.snp.right).offset(10)
        }
        
        collectionView.snp.makeConstraints { (make) in
            make.top.equalTo(subjectLabel.snp.bottom).offset(SmallVideoRecommendVerticalFourGridItemCell.collectionViewTopMargin)
            make.left.right.equalToSuperview()
            make.height.equalTo(SmallVideoRecommendVerticalFourGridItemCell.collectionViewHeight)
        }
        
        moreBtn.snp.makeConstraints { (make) in
            make.left.right.equalToSuperview()
            make.top.equalTo(collectionView.snp.bottom).offset(SmallVideoRecommendVerticalFourGridItemCell.moreBtnMarginTop)
            make.height.equalTo(SmallVideoRecommendVerticalFourGridItemCell.moreBtnHeight)
        }
        
        moreBtn.imagePosition(imageStyle: .right, spacing: 4)
    }
    
    private func getListData() {
        guard let item = dataModel, !isGetListState else { return }
        isGetListState = true
        let req = AVCategoryRecommendSubListSwitchReq()
        req.stationId = item.stationId
        req.pageSize = 4
        req.lastId = listData.last?.videoId ?? 0
        Session.request(req) { [weak self] (error, resp) in
            guard let `self` = self else { return }
            self.isGetListState = false
            guard error == nil, let resData = resp as? [VideoItem], !resData.isEmpty else { return }
            self.refreshCollectionView(listData: resData)
        }
    }
    
    private func refreshCollectionView(listData: [VideoItem]) {
        let maxNum = SmallVideoRecommendVerticalFourGridItemCell.itemRowNumber * SmallVideoRecommendVerticalFourGridItemCell.itemColumnNumber
        self.listData = listData.count > maxNum ? Array(listData[0..<maxNum]) : listData
        collectionView.reloadData()
    }
    
    @objc private func onMoreBtnTap() {
        guard let navigationController = (UIApplication.shared.delegate as? AppDelegate)?.currentNavigationController else { return }
        let smallVideoRecommendVerticalFourGridMoreListVC = SmallVideoRecommendVerticalFourGridMoreListVC()
        smallVideoRecommendVerticalFourGridMoreListVC.navigationTitle = dataModel?.stationName ?? "視頻列表"
        smallVideoRecommendVerticalFourGridMoreListVC.stationId = dataModel?.stationId
        navigationController.show(smallVideoRecommendVerticalFourGridMoreListVC, sender: nil)
    }
}

extension SmallVideoRecommendVerticalFourGridItemCell: UICollectionViewDataSource, UICollectionViewDelegate {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return listData.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "SmallVideoRecommendVerticalFourGridCell", for: indexPath) as! SmallVideoRecommendVerticalFourGridCell
        cell.dataModel = listData[indexPath.row]
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        SearchResultVC.navigationToVideoPlayListVC(indexPath: indexPath, VideoList: listData)
    }
    
}

extension SmallVideoRecommendVerticalFourGridItemCell: AVRecommendSwitchBottomBarDelegate {
    
    func refreshList() {
        getListData()
    }
    
}
