//
//  SmallVideoRecommendVerticalFourGridCell.swift
//  Sp
//
//  Created by mac on 2021/1/13.
//  Copyright © 2021 mac. All rights reserved.
//

import UIKit

class SmallVideoRecommendVerticalFourGridCell: UICollectionViewCell {
    
    static let itemWidth: CGFloat = {
        return (UIScreen.main.bounds.width - SmallVideoRecommendVerticalFourGridItemCell.itemEdgeInsetMargin * 2 - SmallVideoRecommendVerticalFourGridItemCell.itemInteritemSpacing) / 2
    }()
    
    static let itemHeight: CGFloat = {
        return SmallVideoRecommendVerticalFourGridCell.posterHeight + SmallVideoRecommendVerticalFourGridCell.titleMarginTop + SmallVideoRecommendVerticalFourGridCell.titleHeight
    }()
    
    private static let titleMarginTop: CGFloat = 7
    
    private static let titleHeight: CGFloat = 44
    
    private static let posterSizeRatio: CGFloat = 165 / 230
    
    private static let posterHeight: CGFloat = {
        return SmallVideoRecommendVerticalFourGridCell.itemWidth / SmallVideoRecommendVerticalFourGridCell.posterSizeRatio
    }()
    
    static let HDImg: UIImage? = {
        return UIImage(named: "video_HD_icon")
    }()
    
    static let vipDefaultImg: UIImage? = {
        return UIImage(named: "video_vip_icon")
    }()
    
    static let payDefaultImg: UIImage? = {
        return UIImage(named: "video_pay_icon")
    }()
    
    static let animationOption: KingfisherOptionsInfo = {
        return [.transition(.fade(0.25))]
    }()
    
    static let lineGradientMaskImg: UIImage? = {
        return UIImage(named: "line_gradient_mask_bg")
    }()
    
    static let originalPriceAttributes: [NSAttributedString.Key : Any] = {
        return [NSAttributedString.Key.font: UIFont.pingFangRegular(7),
                NSAttributedString.Key.foregroundColor: RGB(0xFFDFC9),
                NSAttributedString.Key.strikethroughStyle: NSNumber(1)]
    }()
    
    private lazy var posterImgView: UIImageView = {
        let imgView = UIImageView()
        imgView.contentMode = .scaleAspectFill
        imgView.layer.masksToBounds = true
        imgView.layer.cornerRadius = 4
        imgView.addSubview(lineGradientMaskImgView)
        imgView.addSubview(playTimesLabel)
        imgView.addSubview(datetimeLabel)
        imgView.addSubview(HDImgView)
        imgView.addSubview(vipOrPayImgView)
        imgView.addSubview(coinNumLabel)
        imgView.addSubview(discountImgView)
        
        lineGradientMaskImgView.snp.makeConstraints { (make) in
            make.left.right.bottom.equalToSuperview()
            make.height.equalTo(27)
        }
        
        playTimesLabel.snp.makeConstraints { (make) in
            make.left.equalToSuperview().inset(6)
            make.bottom.equalToSuperview().inset(3)
        }
        
        datetimeLabel.snp.makeConstraints { (make) in
            make.centerY.equalTo(playTimesLabel)
            make.right.equalToSuperview().inset(6)
        }
        
        HDImgView.snp.makeConstraints { (make) in
            make.left.top.equalToSuperview()
            make.width.equalTo(28)
            make.height.equalTo(14)
        }
        
        vipOrPayImgView.snp.makeConstraints { (make) in
            make.top.right.equalToSuperview()
            make.width.equalTo(36)
            make.height.equalTo(18)
        }
        
        coinNumLabel.snp.makeConstraints { (make) in
            make.left.equalTo(vipOrPayImgView.snp.left).offset(16)
            make.centerY.right.equalTo(vipOrPayImgView)
        }
        
        discountImgView.snp.makeConstraints { (make) in
            make.right.equalToSuperview().inset(4)
            make.top.equalToSuperview()
            make.width.equalTo(38)
            make.height.equalTo(34)
        }
        
        return imgView
    }()
    
    private lazy var HDImgView: UIImageView = {
        return UIImageView(image: SmallVideoRecommendVerticalFourGridCell.HDImg)
    }()
    
    private lazy var vipOrPayImgView: UIImageView = {
        let imgView = UIImageView()
        imgView.contentMode = .scaleAspectFit
        return imgView
    }()
    
    private lazy var coinNumLabel: UILabel = {
        let label = UILabel()
        label.textColor = .white
        label.font = UIFont.pingFangRegular(10)
        return label
    }()
    
    private lazy var discountIconImgView: UIImageView = {
        return UIImageView(image: ActressDetailsCell.discountIconImg)
    }()
    
    private lazy var priceLabel: UILabel = {
        let label = UILabel()
        label.font = UIFont.pingFangMedium(10)
        label.textColor = .white
        return label
    }()
    
    private lazy var originalPriceLabel: UILabel = {
        let label = UILabel()
        label.textAlignment = .center
        return label
    }()
    
    private lazy var discountImgView: UIImageView = {
        let imgView = UIImageView(image: ActressDetailsCell.discountImg)
        imgView.addSubview(discountIconImgView)
        imgView.addSubview(priceLabel)
        imgView.addSubview(originalPriceLabel)
        imgView.isHidden = true
        
        discountIconImgView.snp.makeConstraints { (make) in
            make.top.equalToSuperview().inset(2)
            make.left.equalToSuperview().inset(3)
            make.size.equalTo(12)
        }
        
        priceLabel.snp.makeConstraints { (make) in
            make.left.equalTo(discountIconImgView.snp.right)
            make.right.equalToSuperview()
            make.centerY.equalTo(discountIconImgView)
        }
        
        originalPriceLabel.snp.makeConstraints { (make) in
            make.top.equalTo(discountIconImgView.snp.bottom).offset(1)
            make.left.right.equalToSuperview()
        }
        
        return imgView
    }()
    
    private lazy var lineGradientMaskImgView: UIImageView = {
        let imgView = UIImageView(image: SmallVideoRecommendVerticalFourGridCell.lineGradientMaskImg)
        imgView.contentMode = .scaleAspectFill
        return imgView
    }()
    
    private lazy var playTimesLabel: UILabel = {
        let label = UILabel()
        label.font = font(10, .semibold)
        label.textColor = .white
        return label
    }()
    
    private lazy var datetimeLabel: UILabel = {
        let label = UILabel()
        label.font = font(10, .semibold)
        label.textColor = .white
        return label
    }()
    
    private lazy var titleLabel: CustomLabel = {
        let label = CustomLabel()
        label.font = font(14)
        label.textColor = .white
        label.numberOfLines = 2
        label.verticalAlignment = .top
        return label
    }()
    
    var dataModel: VideoItem? {
        didSet {
            guard let item = dataModel else { return }
            posterImgView.kf.setImage(with: item.verticalImg?.column2, placeholder: Sensitive.default_bg, options: SmallVideoRecommendVerticalFourGridCell.animationOption)
            playTimesLabel.text = "\(num2TenThousandStrFormatWithChinese(item.fakeWatchTimes))播放"
            datetimeLabel.text = Date.getFormatPlayTime(secounds: TimeInterval(item.playTime))
            titleLabel.text = item.title
            vipOrPayImgView.isHidden = !(item.videoPayMark == .vip || item.videoPayMark == .pay && !item.discount)
            vipOrPayImgView.image = item.videoPayMark == .vip ? SmallVideoRecommendVerticalFourGridCell.vipDefaultImg : item.videoPayMark == .pay ? SmallVideoRecommendVerticalFourGridCell.payDefaultImg : nil
            HDImgView.isHidden = !item.hd
            coinNumLabel.isHidden = !(!item.discount && item.videoPayMark == .pay)
            coinNumLabel.text = "\(item.price)"
            discountImgView.isHidden = !(item.videoPayMark == .pay && item.discount)
            priceLabel.text = "\(item.price)"
            originalPriceLabel.attributedText = NSMutableAttributedString(string: "原價\(item.originalPrice)", attributes: SmallVideoRecommendVerticalFourGridCell.originalPriceAttributes)
        }
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = rgb(0x1C1C1C)
        layer.masksToBounds = true
        layer.cornerRadius = 4
        renderView()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func renderView() {
        addSubview(posterImgView)
        addSubview(titleLabel)
        
        posterImgView.snp.makeConstraints { (make) in
            make.top.left.right.equalToSuperview()
            make.height.equalTo(SmallVideoRecommendVerticalFourGridCell.posterHeight)
        }
        
        titleLabel.snp.makeConstraints { (make) in
            make.top.equalTo(posterImgView.snp.bottom).offset(SmallVideoRecommendVerticalFourGridCell.titleMarginTop)
            make.left.right.equalToSuperview().inset(4)
            make.bottom.equalToSuperview()
        }
        
    }
}
