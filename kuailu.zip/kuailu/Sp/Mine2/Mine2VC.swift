//
//  Mine2VC.swift
//  Sp
//
//  Created by mac on 2020/11/10.
//  Copyright © 2020 mac. All rights reserved.
//

import UIKit

class Mine2VC: UIViewController {
    //MARK:-    头像部分
    @IBOutlet weak var vipLevelButton: UIButton!
    @IBOutlet weak var userNameLabel: UILabel!
    @IBOutlet weak var userIDLabel: UILabel!
    @IBOutlet weak var avatarButton: UIButton!
    
    @IBOutlet weak var praiseButton: UIButton?
    @IBOutlet weak var postButton: UIButton?
    @IBOutlet weak var fanButton: UIButton?
    
    //MARK:-    成为会员
    @IBOutlet weak var gradientView: UIView!
    @IBOutlet weak var vipButton: UIButton!
    @IBOutlet weak var remainWatchLabel: UILabel!
    @IBOutlet weak var vipValidLabel: UILabel!
    @IBOutlet weak var notVipLabel: UILabel!
    
    //MARK:-    创作中心 + 广告
    @IBOutlet weak var adButton: UIButton!
    
    //  92、20
    @IBOutlet weak var sixButtonsTop: NSLayoutConstraint!
    
    @IBOutlet weak var myMessageButton: UIButton!   //  我的消息
    //
    var appsURL:URL?
    var onlineURL:URL?
    
    //MARK:-    life circle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationItem.rightBarButtonItem = UIBarButtonItem(image: UIImage(named: "mine2_message_none"), style: .plain, target: self, action: #selector(click(message:)))
        
        setupGradient()
        let adImage = UIImage.decrypt("mine2_get_vip.jpg.enc")
        adButton.setImage(adImage, for: .normal)
        //
        if let user = NetDefaults.userInfo {
            self.user = user
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        Appearance.transparent(true, navigationBar: navigationController?.navigationBar)
        //
        loadAppsURL()
        loadOnlineURL()
        loadUserInfo()
        loadCreateCenterImage()
        loadNoticeList()
    }
    
    func setupGradient() {
        object_setClass(gradientView.layer, CAGradientLayer.self)
        let layer = gradientView.layer as! CAGradientLayer
        layer.colors = [rgb(36,32,32).cgColor,
                        rgb(46,45,45).cgColor,
                        rgb(36,32,32).cgColor]
        layer.startPoint = CGPoint(x: 0, y: 0.5)
        layer.endPoint = CGPoint(x: 1, y: 0.5)
    }
    
    //MARK:-    network
    
    func loadAppsURL()  {
        Session.request(MyAppsReq()) { (e, resp) in
            guard e == nil else { return }
            guard let item = resp as? MyAppsItem, let url = item.url else { return }
            self.appsURL = url
        }
    }
    
    func loadOnlineURL() {
        Session.request(OnLineWebReq()) { (error, resp) in
            guard error == nil else {
                return
            }
            if resp is OnLineWebItem {
                let item = resp as! OnLineWebItem
                self.onlineURL = item.signUrl
            }
        }
    }
    
    func loadCreateCenterImage() {
        Session.request(CreateCenterImageReq()) { (error, resp) in
            guard error == nil else { return }
            guard let item = resp as? CreateCenterImage else { return }
            self.adButton.kf.setImage(with: item.data, for: .normal)
            var top: CGFloat = 92
            self.adButton.isHidden = false
            if item.data == nil {
                top = 20
                self.adButton.isHidden = true
            }
            self.sixButtonsTop.constant = top
        }
    }
    
    func loadUserInfo() {
        let req  = FetchUserInfoReq()
        Session.request(req) { (error, resp) in
            guard error == nil  else {
                if let user = NetDefaults.userInfo {
                    self.user = user
                }
                return
            }
            if let item = resp as? UserBase {
                Defaults.currentLevel = item.level
                self.user = item
            }
        }
    }
    
    func loadNoticeList() {
        let req = NoticeListReq()
        req.page = 1
        Session.request(req) { [weak self] (error, resp) in
            guard error == nil else {
                return
            }
            if resp is [NoticeItem]  {
                let array = resp as! [NoticeItem]
                guard !array.isEmpty else {
                    return
                }
                let item = array.first!
                let hasNewMessage = Defaults.latestId != item.annId
                let imageName = hasNewMessage ? "mine2_message_new" : "mine2_message_none"
                self?.navigationItem.rightBarButtonItem?.image = UIImage(named: imageName)
            }
        }
    }
    
    var user: UserBase? {
        didSet {
            guard let u = user else { return }
            userNameLabel.text = u.nickName
            userIDLabel.text = "用户ID：\(u.userId)"
            let vipLevelImage = UIImage(named: "v\(u.level)")
            vipLevelButton.setImage(vipLevelImage, for: .normal)
            avatarButton.kf.setImage(with: u.logo, for: .normal, placeholder: Sensitive.avatar)
            //
            var at = attrText(num: u.ua, text: " 获赞")
            praiseButton?.setAttributedTitle(at, for: .normal)
            at = attrText(num: u.worksNum, text: " 发帖")
            postButton?.setAttributedTitle(at, for: .normal)
            at = attrText(num: u.bu, text: " 粉丝")
            fanButton?.setAttributedTitle(at, for: .normal)
            
            //  会员
            if let date = u.expiredVip, date > Date() {
                let dateFormatter = DateFormatter()
                dateFormatter.dateFormat = "yyyy-MM-dd"
                let dateText = dateFormatter.string(from: date)
                vipValidLabel.text = "会员有效期：\(dateText)"
                vipValidLabel.isHidden = false
                remainWatchLabel.isHidden = true
                notVipLabel.isHidden = true
                vipButton.setImage(UIImage(named: "btn_续费会员"), for: .normal)
            } else {
                let smallVideoRemainTimes = "\(max(0, u.freeWatches - u.watched))"
                let avRemainTimes = "\(max(0, u.avFreeWatches - u.avWatched))"
                let remainTimesAttributedStr = NSMutableAttributedString(string: "今日免費小視頻剩餘\(smallVideoRemainTimes)次；AV\(avRemainTimes)次", attributes: [NSAttributedString.Key.font: UIFont.pingFangRegular(12), NSAttributedString.Key.foregroundColor: UIColor.white])
                let stressAttributes = [NSAttributedString.Key.foregroundColor: rgb(0xFF0400)]
                let samllVideoRemainRang = NSRange(location: 9, length: smallVideoRemainTimes.count)
                let avRemainRang = NSRange(location: samllVideoRemainRang.upperBound + 4, length: avRemainTimes.count)
                remainTimesAttributedStr.addAttributes(stressAttributes, range: samllVideoRemainRang)
                remainTimesAttributedStr.addAttributes(stressAttributes, range: avRemainRang)
                remainWatchLabel.attributedText = remainTimesAttributedStr
                
                vipValidLabel.isHidden = true
                remainWatchLabel.isHidden = false
                notVipLabel.isHidden = false
                vipButton.setImage(UIImage(named: "btn_成为会员"), for: .normal)
            }
        }
    }
    
    func attrText(num: Int, text: String) -> NSAttributedString {
        let at = NSMutableAttributedString()
        let at1 = NSAttributedString(string: String(num), attributes: [.font: font(16, .semibold), .foregroundColor: UIColor.white])
        let at2 = NSAttributedString(string: text, attributes: [.font: font(13), .foregroundColor: rgb(0xC7C7C7)])
        at.append(at1)
        at.append(at2)
        return at
    }
    
    //MARK:-    头像部分
    @IBAction func tap(personInfo: UITapGestureRecognizer) {
        guard let user = NetDefaults.userInfo else { return }
        let vc = UsersDynamicVC()
        vc.userId = user.userId
        navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func click(vipLevel: UIButton) {
        let vc = LevelVC()
        vc.hidesBottomBarWhenPushed = true
        navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func click(avatar: UIButton) {
        
    }
    
    @IBAction func click(praise: UIButton) {
        let vc =  LikeListVC()
        vc.hidesBottomBarWhenPushed = true
        navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func click(post: UIButton) {
        
    }
    
    @IBAction func click(fan: UIButton) {
        let vc =  FansListVC()
        vc.hidesBottomBarWhenPushed = true
        navigationController?.pushViewController(vc, animated: true)
    }
    
    //MARK:-    成为会员
    @IBAction func click(vip: UIButton) {
        let vc = Vip2VC()
        vc.hidesBottomBarWhenPushed = true
        navigationController?.pushViewController(vc, animated: true)
    }
    
    //MARK:-    充值、钱包、分享、加群
    @IBAction func click(charge: UIButton) {
        let vc = Vip2VC()
        vc.hidesBottomBarWhenPushed = true
        navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func click(wallet: UIButton) {
        let vc = WalletVC()
        vc.hidesBottomBarWhenPushed = true
        navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func click(share: UIButton) {
        let vc = Share2VC()
        vc.hidesBottomBarWhenPushed = true
        navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func click(group: UIButton) {
        let vc = GroupVC()
        vc.hidesBottomBarWhenPushed = true
        navigationController?.pushViewController(vc, animated: true)
    }
    
    //MARK:-    创作中心 + 广告
    @IBAction func tap(create: UITapGestureRecognizer) {
        let vc = UploadVC()
        vc.modalPresentationStyle = .fullScreen
        vc.hidesBottomBarWhenPushed = true
        navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func click(ad: UIButton) {
        let vc = UploadVideoVC()
        vc.modalPresentationStyle = .fullScreen
        vc.hidesBottomBarWhenPushed = true
        navigationController?.pushViewController(vc, animated: true)
    }
    
    //MARK:-    购买、关注、收藏、观看、消息、应用
    @IBAction func click(purchase: UIButton) {
        let vc = Purchase2VC()
        vc.apiType = .purchase
        vc.hidesBottomBarWhenPushed = true
        navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func click(focus: UIButton) {
        guard user != nil else { return }
        let vc = FocusFansVC()
        vc.navigationTitle = user!.nickName
        vc.currentIndex = 0
        vc.titles = ["關注 \(user!.ua)","粉絲 \(user!.bu)"]
        vc.hidesBottomBarWhenPushed = true
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func click(collect: UIButton) {
        let vc = Purchase2VC()
        vc.apiType = .favorite
        vc.hidesBottomBarWhenPushed = true
        navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func click(watch: UIButton) {
        let vc = Purchase2VC()
        vc.apiType = .history
        vc.hidesBottomBarWhenPushed = true
        navigationController?.pushViewController(vc, animated: true)
    }
    
    @objc @IBAction func click(message: UIButton) {
        let vc = MessageVC()
        vc.hidesBottomBarWhenPushed = true
        navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func click(download: UIButton) {
        let vc = DownloadController()
        vc.hidesBottomBarWhenPushed = true
        navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func click(app: UIButton) {
        guard appsURL != nil else {
            mm_showToast("獲取應用中心地址失敗!",type: .warning)
            return
        }
        UIApplication.shared.open(appsURL!, options: [:], completionHandler: nil)
    }
    
    //MARK:-    官方、客服、设置
    @IBAction func tap(official: UITapGestureRecognizer) {
        let vc = InviteAgentVC()
        vc.hidesBottomBarWhenPushed = true
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func tap(setting: UITapGestureRecognizer) {
        let vc = SettingVC()
        vc.hidesBottomBarWhenPushed = true
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func click(service: UIButton) {
        guard self.onlineURL != nil else {
            mm_showToast("在線客服地址獲取失敗!")
            return
        }
        let vc = WebVC()
        vc.webviewUrl = self.onlineURL!
        navigationController?.pushViewController(vc, animated: true)
    }
}
