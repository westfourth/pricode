//
//  NovelReadingCommonNovelCell.swift
//  CaoLong
//
//  Created by mac on 2021/1/25.
//  Copyright © 2021 mac. All rights reserved.
//

import UIKit

class NovelReadingCommonNovelCell: UITableViewCell {
    
    static let viewHeight: CGFloat = 120
    
    private static let readImg: UIImage? = {
        return UIImage(named: "novel_reading_read_icon")
    }()
    
    private static let collectionImg: UIImage? = {
        return UIImage(named: "novel_reading_collection_icon")
    }()
    
    private lazy var titleLabel: UILabel = {
        let label = UILabel()
        label.font = FONT(15, .medium)
        label.textColor = .white
        return label
    }()
    
    private lazy var introLabel: CustomLabel = {
        let label = CustomLabel()
        label.font = FONT(14)
        label.textColor = rgb(0x9E9E9E)
        label.numberOfLines = 2
        label.verticalAlignment = .top
        return label
    }()
    
    private lazy var readImgView: UIImageView = {
        let imgView = UIImageView(image: NovelReadingCommonNovelCell.readImg)
        imgView.contentMode = .scaleAspectFit
        return imgView
    }()
    
    private lazy var readNumLabel: UILabel = {
        let label = UILabel()
        label.font = FONT(10)
        label.textColor = rgb(0x6A6C6D)
        return label
    }()
    
    private lazy var collectionImgView: UIImageView = {
        let imgView = UIImageView(image: NovelReadingCommonNovelCell.collectionImg)
        imgView.contentMode = .scaleAspectFit
        return imgView
    }()
    
    private lazy var collectionNumLabel: UILabel = {
        let label = UILabel()
        label.font = FONT(10)
        label.textColor = rgb(0x6A6C6D)
        return label
    }()
    
    private lazy var wrapperView: UIView = {
        let view = UIView()
        view.backgroundColor = rgb(0x202225)
        view.layer.masksToBounds = true
        view.layer.cornerRadius = 6
        
        view.addSubview(titleLabel)
        view.addSubview(introLabel)
        view.addSubview(readImgView)
        view.addSubview(readNumLabel)
        view.addSubview(collectionImgView)
        view.addSubview(collectionNumLabel)
        
        titleLabel.snp.makeConstraints { (make) in
            make.top.equalToSuperview().inset(9)
            make.left.right.equalToSuperview().inset(20)
            make.height.equalTo(21)
        }
        
        introLabel.snp.makeConstraints { (make) in
            make.top.equalTo(titleLabel.snp.bottom).offset(5)
            make.left.right.equalTo(titleLabel)
            make.height.equalTo(40)
        }
        
        readImgView.snp.makeConstraints { (make) in
            make.left.equalTo(titleLabel)
            make.bottom.equalToSuperview().inset(12)
            make.width.equalTo(11)
            make.height.equalTo(8)
        }
        
        readNumLabel.snp.makeConstraints { (make) in
            make.centerY.equalTo(readImgView)
            make.left.equalTo(readImgView.snp.right).offset(5)
        }
        
        collectionImgView.snp.makeConstraints { (make) in
            make.centerY.equalTo(readImgView)
            make.left.equalTo(readNumLabel.snp.right).offset(16)
            make.width.equalTo(10)
            make.height.equalTo(11)
        }
        
        collectionNumLabel.snp.makeConstraints { (make) in
            make.centerY.equalTo(readImgView)
            make.left.equalTo(collectionImgView.snp.right).offset(6)
        }
        return view
    }()
    
    var dataModel: NovelReadingItem? {
        didSet {
            guard let item = dataModel else { return }
            titleLabel.text = item.fictionTitle
            introLabel.text = item.info
            readNumLabel.text = num2TenThousandStrFormat(item.fakeWatchTimes)
            collectionNumLabel.text = num2TenThousandStrFormat(item.fakeLikes)
        }
    }
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        backgroundColor = .none
        selectionStyle = .none
        contentView.addSubview(wrapperView)
        
        wrapperView.snp.makeConstraints { (make) in
            make.top.bottom.equalToSuperview().inset(6)
            make.left.right.equalToSuperview().inset(10)
        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}
