//
//  NovelReadingSearchVC.swift
//  CaoLong
//
//  Created by mac on 2021/1/25.
//  Copyright © 2021 mac. All rights reserved.
//

import UIKit

class NovelReadingSearchVC: UIViewController {
    
    private static let searchBgBtnHeight: CGFloat = 34
    
    private static let maxKeyWordsLen: Int = 20
    
    private static let maxHistoryTagListLen: Int = 20
    
    private static let cancelBtnWidth: CGFloat = 34
    
    private lazy var searchImgView: UIImageView = {
        let imgView = UIImageView(image: NovelReadingScrollListItemCellHeaderView.searchImg)
        imgView.contentMode = .scaleAspectFit
        return imgView
    }()
    
    private lazy var inputField: UITextField = {
        let input  = UITextField()
        input.delegate = self
        input.font = font(14)
        input.textColor = rgb(0xF8F8F8)
        input.placeholder = "搜索成人小說或有聲讀物"
        input.setValue(UIColor.white.withAlphaComponent(0.4), forKeyPath: "placeholderLabel.textColor")
        input.setValue(input.font, forKeyPath: "placeholderLabel.font")
        input.textAlignment = .left
        input.clearButtonMode = .whileEditing
        input.returnKeyType = .done
        input.addDoneOnKeyboardWithTarget(self, action: #selector(onDoneKeyboardTap))
        return input
    }()
    
    private lazy var cancelBtn: UIButton = {
        let btn = UIButton()
        btn.setTitle("取消", for: .normal)
        btn.setTitleColor(.white, for: .normal)
        btn.titleLabel?.font = font(16)
        btn.addTarget(self, action: #selector(onCancelBtnTap), for: .touchUpInside)
        return btn
    }()
    
    private lazy var searchBgBar: UIView = {
        let view = UIView()
        view.backgroundColor = rgb(0x3A3A3A)
        view.layer.cornerRadius = NovelReadingSearchVC.searchBgBtnHeight / 2
        view.layer.masksToBounds = true
        view.addSubview(searchImgView)
        view.addSubview(inputField)
        
        searchImgView.snp.makeConstraints { (make) in
            make.left.equalToSuperview().inset(10)
            make.centerY.equalToSuperview()
            make.size.equalTo(14)
        }
        
        inputField.snp.makeConstraints { (make) in
            make.left.equalTo(searchImgView.snp.right).offset(8)
            make.top.bottom.equalToSuperview()
            make.right.equalToSuperview().inset(10)
        }
        
        return view
    }()
    
    private lazy var searchWrapperView: UIView = {
        let view = UIView()
        view.addSubview(cancelBtn)
        view.addSubview(searchBgBar)
        
        cancelBtn.snp.makeConstraints { (make) in
            make.top.bottom.equalToSuperview()
            if #available(iOS 14.0, *) {
                make.right.equalToSuperview().inset(20)
            } else {
                make.right.equalToSuperview()
            }
            make.width.equalTo(NovelReadingSearchVC.cancelBtnWidth)
        }
        
        searchBgBar.snp.makeConstraints { (make) in
            make.left.top.bottom.equalToSuperview()
            make.right.equalTo(cancelBtn.snp.left).offset(-20)
        }
        
        return view
    }()
    
    private lazy var searchRecommendVC: NovelReadingSearchRecommendVC = {
        let vc = NovelReadingSearchRecommendVC()
        vc.delegate = self
        return vc
    }()
    
    private lazy var searchResultVC: NovelReadingSearchResultVC = {
        let vc = NovelReadingSearchResultVC()
        vc.view.isHidden = true
        return vc
    }()
    
    private var isGetUserinfo: Bool = false
    
    var type: NovelReadingType = .novel {
        didSet {
            searchRecommendVC.type = type
            searchResultVC.type = type
        }
    }
    
    override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: Bundle?) {
        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
        hidesBottomBarWhenPushed = true
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        if #available(iOS 11.0, *) {
        } else {
            automaticallyAdjustsScrollViewInsets = false
        }
        navigationItem.title = nil
        navigationItem.rightBarButtonItem = UIBarButtonItem(customView: searchWrapperView)
        
        view.backgroundColor = Color.bg_color
        renderView()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.navigationBar.barTintColor = rgb(0x222425)
        Appearance.transparent(false, navigationBar: navigationController?.navigationBar)
        if !isGetUserinfo {
            getUserinfo()
        }
    }
    
    private func renderView() {
        addChild(searchResultVC)
        addChild(searchRecommendVC)
        view.addSubview(searchResultVC.view)
        view.addSubview(searchRecommendVC.view)
        
        searchWrapperView.snp.makeConstraints { (make) in
            if #available(iOS 14.0, *) {
                make.width.equalTo(UIScreen.main.bounds.width - 50)
            } else {
                make.width.equalTo(UIScreen.main.bounds.width - 60)
            }
            make.height.equalTo(NovelReadingSearchVC.searchBgBtnHeight)
        }
        
        searchResultVC.view.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
        
        searchRecommendVC.view.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
    }
    
    @objc private func onDoneKeyboardTap() {
        checkSearchKeyword()
    }
    
    @objc private func onCancelBtnTap() {
        navigationController?.popViewController(animated: true)
    }
    
    private func switchToSearchResultVC(keyword: String) {
        saveHistoryTagsData()
        searchRecommendVC.view.isHidden = true
        searchResultVC.view.isHidden = false
        searchResultVC.type = type
        searchResultVC.keyword = keyword
    }
    
    private func saveHistoryTagsData() {
        guard let val = inputField.text else { return }
        if var historyKeywordList = Defaults.novelReadingHistoryKeywordList {
            if let index = historyKeywordList.firstIndex(of: val) {
                historyKeywordList.remove(at: index)
            }
            historyKeywordList.insert(val, at: 0)
            Defaults.novelReadingHistoryKeywordList = historyKeywordList.count > NovelReadingSearchVC.maxHistoryTagListLen ? Array(historyKeywordList[0..<NovelReadingSearchVC.maxHistoryTagListLen]) : historyKeywordList
        } else {
            Defaults.novelReadingHistoryKeywordList = [val]
        }
    }
    
    private func checkSearchKeyword() {
        inputField.resignFirstResponder()
        guard let keyword = inputField.text?.trimmingCharacters(in: .whitespacesAndNewlines), !keyword.isEmpty else { return }
        switchToSearchResultVC(keyword: keyword)
    }
    
    private func getUserinfo() {
        guard !isGetUserinfo else { return }
        isGetUserinfo = true
        Session.request(FetchUserInfoReq()) { [weak self] (error, resp) in
            guard let `self` = self else { return }
            self.isGetUserinfo = false
        }
    }
    
}

extension NovelReadingSearchVC: NovelReadingSearchRecommendVCDelegate {
    
    func onRecomHeaderViewHistoryTagTap(keyword: String) {
        inputField.text = keyword
        checkSearchKeyword()
    }
    
}

extension NovelReadingSearchVC: UITextFieldDelegate {
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        guard let keyword = textField.text?.trimmingCharacters(in: .whitespacesAndNewlines), !keyword.isEmpty else { return false }
        checkSearchKeyword()
        return true
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        let len = textField.text!.count + string.count - range.length
        if len <= NovelReadingSearchVC.maxKeyWordsLen {
            return true
        } else {
            inputField.resignFirstResponder()
            iToast(inputField.placeholder!)
            return false
        }
    }
}

