//
//  NovelReadingSearchRecomHotListItemCell.swift
//  CaoLong
//
//  Created by mac on 2021/1/29.
//  Copyright © 2021 mac. All rights reserved.
//

import UIKit

protocol NovelReadingSearchRecomHotListItemCellDelegate: NSObjectProtocol {
    
    func switchParentScrollViewScrollEnabled(childScrollViewOffsetY: CGFloat)
    
}

class NovelReadingSearchRecomHotListItemCell: UICollectionViewCell {
    
    private lazy var tableView: UITableView = {
        let tableView = UITableView(frame: .zero, style: .grouped)
        tableView.delegate = self
        tableView.dataSource = self
        tableView.backgroundColor = .none
        tableView.separatorStyle = .none
        tableView.bouncesZoom = false
        tableView.isDirectionalLockEnabled = true
        tableView.showsHorizontalScrollIndicator = false
        tableView.showsVerticalScrollIndicator = false
        tableView.contentInsetAdjustmentBehavior = .never
        tableView.isScrollEnabled = false
        tableView.rowHeight = NovelReadingSearchRecomHotListCell.viewHeight
        tableView.estimatedRowHeight = tableView.rowHeight
        tableView.state = .loading
        tableView.register(NovelReadingSearchRecomHotListCell.self, forCellReuseIdentifier: "NovelReadingSearchRecomHotListCell")
        tableView.mj_footer = getCommonMJFooter(refreshingTarget: self, footerRefreshCallback: #selector(onLoad))
        return tableView
    }()
    
    private var listData: [NovelReadingHotSearchItem] = [] {
        didSet {
            tableView.reloadData()
        }
    }
    
    private var isInitState: Bool = true
    
    private var isGetListState: Bool = false
    
    private var isShowLoading: Bool = false
    
    weak var delegate: NovelReadingSearchRecomHotListItemCellDelegate?
    
    var isScrollEnabled: Bool = false {
        didSet {
            tableView.isScrollEnabled = isScrollEnabled
        }
    }
    
    var type: NovelReadingType = .novel {
        didSet {
            guard isInitState else { return }
            isInitState = false
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.4) { [weak self] in
                self?.getList(isRefresh: true)
            }
        }
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        contentView.addSubview(tableView)
        
        tableView.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func getList(isRefresh: Bool) {
        tableView.state = listData.isEmpty ? .loading : .normal
        if isRefresh {
            tableView.mj_footer?.resetNoMoreData()
        }
        let req = NovelReadingHotSearchListAllListReq()
        req.fictionType = type == .novel ? 1 : 2
        req.lastId = isRefresh ? 0 : listData.last?.fictionId ?? 0
        Session.request(req) { [weak self] (error, resp) in
            guard let `self` = self else { return }
            self.isGetListState = false
            isRefresh ? self.tableView.mj_header?.endRefreshing() : self.tableView.mj_footer?.endRefreshing()
            guard error == nil, let resData = resp as? [NovelReadingHotSearchItem] else {
                self.handleListException(isRefresh: isRefresh)
                return
            }
            self.listData = isRefresh ? resData : self.listData + resData
            let isEmpty = self.listData.isEmpty
            self.tableView.state = isEmpty ? .empty : .normal
            self.tableView.mj_footer?.isHidden = isEmpty
            if resData.count < req.pageSize {
                DispatchQueue.main.async {
                    self.tableView.mj_footer?.endRefreshingWithNoMoreData()
                }
            }
        }
    }
    
    private func handleListException(isRefresh: Bool) {
        if isRefresh {
            listData = []
            tableView.state = .failed
            tableView.mj_footer?.isHidden = true
        } else {
            tableView.state = .normal
            tableView.mj_footer?.endRefreshingWithNoMoreData()
            tableView.mj_footer?.isHidden = false
        }
    }
    
    @objc private func onLoad() {
        getList(isRefresh: false)
    }
    
}

extension NovelReadingSearchRecomHotListItemCell: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return listData.count
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return .leastNonzeroMagnitude
    }
    
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return .leastNonzeroMagnitude
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        return nil
    }
    
    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        return nil
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "NovelReadingSearchRecomHotListCell", for: indexPath) as! NovelReadingSearchRecomHotListCell
        let row = indexPath.row
        cell.currentIndex = row
        cell.dataModel = listData[row]
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let fictionId = listData[indexPath.row].fictionId
        switch type {
        case .novel:
            NovelReadingVC.navigationToTextNovelDetailVC(fictionId: fictionId)
        case .reading:
            NovelReadingVC.navigationToAudioNovelDetailVC(fictionId: fictionId)
        }
    }
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        guard scrollView == tableView else { return }
        delegate?.switchParentScrollViewScrollEnabled(childScrollViewOffsetY: scrollView.contentOffset.y)
    }
    
}
