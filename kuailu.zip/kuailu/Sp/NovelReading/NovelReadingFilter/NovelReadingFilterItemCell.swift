//
//  NovelReadingFilterItemCell.swift
//  CaoLong
//
//  Created by mac on 2021/1/29.
//  Copyright © 2021 mac. All rights reserved.
//

import UIKit

class NovelReadingFilterItemCell: UICollectionViewCell {
    
    private static let scrollToTopImg: UIImage? = {
        return UIImage(named: "discovery_tag_video_top_icon")
    }()
    
    private lazy var headerView: NovelReadingFilterHeaderView = {
        return NovelReadingFilterHeaderView()
    }()
    
    private lazy var tableView: UITableView = {
        let tableView = UITableView(frame: .zero, style: .grouped)
        tableView.delegate = self
        tableView.dataSource = self
        tableView.backgroundColor = .none
        tableView.separatorStyle = .none
        tableView.bouncesZoom = false
        tableView.isDirectionalLockEnabled = true
        tableView.showsVerticalScrollIndicator = false
        tableView.contentInsetAdjustmentBehavior = .never
        tableView.mj_header = getCommonMJHeader(refreshingTarget: self, headerRefreshCallback: #selector(onRefresh))
        tableView.mj_footer = getCommonMJFooter(refreshingTarget: self, footerRefreshCallback: #selector(onLoad))
        return tableView
    }()
    
    private lazy var scrollToTopBtn: UIButton = {
        let btn = UIButton()
        btn.setBackgroundImage(NovelReadingFilterItemCell.scrollToTopImg, for: .normal)
        btn.addTarget(self, action: #selector(onScrollToTopBtn), for: .touchUpInside)
        btn.isHidden = true
        return btn
    }()
    
    private var listData: [NovelReadingItem] = [] {
        didSet {
            tableView.reloadData()
        }
    }
    
    private var isInitState: Bool = true
    
    private var isGetListState: Bool = false
    
    private var isShowLoading: Bool = false
    
    private var pageNum: Int = 1
    
    var type: NovelReadingType = .novel
    
    var itemData: NovelReadingClassifyItem? {
        didSet {
            guard isInitState, let item = itemData else { return }
            isInitState = false
            switch type {
            case .novel:
                tableView.rowHeight = NovelReadingCommonNovelCell.viewHeight
                tableView.register(NovelReadingCommonNovelCell.self, forCellReuseIdentifier: "NovelReadingCommonNovelCell")
            case .reading:
                tableView.rowHeight = NovelReadingCommonReadingCell.viewHeight
                tableView.register(NovelReadingCommonReadingCell.self, forCellReuseIdentifier: "NovelReadingCommonReadingCell")
            }
            tableView.estimatedRowHeight = tableView.rowHeight
            headerView.delegate = self
            headerView.tagList = item.tagList
            getReadingCommonListOrNovelList(isRefresh: true)
        }
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        renderView()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func renderView() {
        addSubview(tableView)
        addSubview(scrollToTopBtn)
        
        tableView.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
        
        scrollToTopBtn.snp.makeConstraints { (make) in
            make.right.equalToSuperview().inset(10)
            make.bottom.equalToSuperview().inset(230)
            make.size.equalTo(42)
        }
    }
    
    private func getReadingCommonListOrNovelList(isRefresh: Bool) {
        guard !isGetListState, let item = itemData else { return }
        isGetListState = true
        let isShowLoading = self.isShowLoading
        if isShowLoading {
            loading()
        }
        if isRefresh {
            pageNum = 1
            tableView.mj_footer?.resetNoMoreData()
        }
        let req = NovelReadingAccordingToClassifySubListReq()
        req.classId = item.classId
        // 小说篇幅：1、长篇小说 2、短篇小说
        req.fictionType = type == .novel ? 1 : 2
        req.page = isRefresh ? 1 : pageNum + 1
        // 排序方式：1-最新 2-最热 3-最多收藏，默认1
        req.orderType = headerView.sortType.rawValue
        // 小说篇幅：1、长篇小说 2、短篇小说
        req.fictionSpace = headerView.novelLengthType?.rawValue ?? kInterOptionValue
        // 筛选标签数组集合
        req.tagIds = headerView.selectedTagIdList
        Session.request(req) { [weak self] (error, resp) in
            guard let `self` = self else { return }
            self.isGetListState = false
            if isShowLoading {
                hideLoading()
            }
            isRefresh ? self.tableView.mj_header?.endRefreshing() : self.tableView.mj_footer?.endRefreshing()
            guard error == nil, let resData = resp as? [NovelReadingItem] else {
                self.handleListException(isRefresh: isRefresh)
                return
            }
            self.pageNum = req.page
            self.listData = isRefresh ? resData : self.listData + resData
            let isEmpty = self.listData.isEmpty
            self.tableView.state = isEmpty ? .empty : .normal
            self.tableView.mj_footer?.isHidden = isEmpty
            if resData.count < req.pageSize {
                DispatchQueue.main.async {
                    self.tableView.mj_footer?.endRefreshingWithNoMoreData()
                }
            }
        }
    }
    
    private func handleListException(isRefresh: Bool) {
        if isRefresh {
            listData = []
            tableView.state = .failed
            tableView.mj_footer?.isHidden = true
        } else {
            tableView.state = .normal
            tableView.mj_footer?.endRefreshingWithNoMoreData()
            tableView.mj_footer?.isHidden = false
        }
    }
    
    @objc private func onRefresh() {
        isShowLoading = false
        getReadingCommonListOrNovelList(isRefresh: true)
    }
    
    @objc private func onLoad() {
        isShowLoading = false
        getReadingCommonListOrNovelList(isRefresh: false)
    }
    
    @objc private func onScrollToTopBtn() {
        guard !listData.isEmpty else { return }
        tableView.scrollToRow(at: IndexPath(row: 0, section: 0), at: .top, animated: true)
    }
}

extension NovelReadingFilterItemCell: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return listData.count
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return headerView.viewHeight
    }
    
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return .leastNonzeroMagnitude
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        return headerView
    }
    
    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        return nil
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let row = indexPath.row
        switch type {
        case .novel:
            let cell = tableView.dequeueReusableCell(withIdentifier: "NovelReadingCommonNovelCell", for: indexPath) as! NovelReadingCommonNovelCell
            cell.dataModel = listData[row]
            return cell
        case .reading:
            let cell = tableView.dequeueReusableCell(withIdentifier: "NovelReadingCommonReadingCell", for: indexPath) as! NovelReadingCommonReadingCell
            cell.dataModel = listData[row]
            return cell
        }
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let fictionId = listData[indexPath.row].fictionId
        switch type {
        case .novel:
            NovelReadingVC.navigationToTextNovelDetailVC(fictionId: fictionId)
        case .reading:
            NovelReadingVC.navigationToAudioNovelDetailVC(fictionId: fictionId)
        }
    }
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        scrollToTopBtn.isHidden = listData.isEmpty || scrollView.contentOffset.y < height
    }
    
}

extension NovelReadingFilterItemCell: NovelReadingFilterHeaderViewDelegate {
    
    func refreshList() {
        isShowLoading = true
        getReadingCommonListOrNovelList(isRefresh: true)
    }
    
    func initList() {
        isShowLoading = false
        getReadingCommonListOrNovelList(isRefresh: true)
    }
}
