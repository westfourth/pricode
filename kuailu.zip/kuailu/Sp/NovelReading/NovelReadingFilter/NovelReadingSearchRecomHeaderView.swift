//
//  NovelReadingSearchRecomHeaderView.swift
//  CaoLong
//
//  Created by mac on 2021/1/29.
//  Copyright © 2021 mac. All rights reserved.
//

import UIKit

protocol NovelReadingSearchRecomHeaderViewDelegate: NSObjectProtocol {
    
    func refreshWrapperScrollViewHeight()
    
    func onRecomHeaderViewHistoryTagTap(keyword: String)
    
    
}

class NovelReadingSearchRecomHeaderView: UIView {
    
    private static let marginTop: CGFloat = 18
    
    private static let marginBottom: CGFloat = 18
    
    private static let verticalMargin: CGFloat = {
        return NovelReadingSearchRecomHeaderView.marginTop + NovelReadingSearchRecomHeaderView.marginBottom
    }()
    
    private static let sectionHeaderTitleList: [String] = {
        return ["搜索歷史", "熱門標籤", "熱搜榜"]
    }()
    
    private static let miniViewHeight: CGFloat = {
        return NovelReadingSearchRecomHeaderView.verticalMargin + NovelReadingSearchRecomHVSectionHeaderView.viewHeight
    }()
    
    private lazy var collectionView: UICollectionView = {
        let layout = UICollectionViewFlowLayout()
        let cv = UICollectionView(frame: .zero, collectionViewLayout: layout)
        cv.register(NovelReadingSearchRecomHistoryCell.self, forCellWithReuseIdentifier: "NovelReadingSearchRecomHistoryCell")
        cv.register(NovelReadingSearchRecomHotTagCell.self, forCellWithReuseIdentifier: "NovelReadingSearchRecomHotTagCell")
        cv.register(NovelReadingSearchRecomHVSectionHeaderView.self, forSupplementaryViewOfKind: UICollectionView.elementKindSectionHeader, withReuseIdentifier: "NovelReadingSearchRecomHVSectionHeaderView")
        cv.backgroundColor = Color.bg_color
        cv.delegate = self
        cv.dataSource = self
        return cv
    }()
    
    private lazy var sectionHeaderSize: CGSize = {
        return CGSize(width: UIScreen.main.bounds.width, height: NovelReadingSearchRecomHVSectionHeaderView.viewHeight)
    }()
    
    private lazy var sectionEdgeInsets: UIEdgeInsets = {
        return UIEdgeInsets(top: 20, left: 30, bottom: 20, right: 30)
    }()
    
    private let historyCellHeight: CGFloat = NovelReadingSearchRecomHistoryCell.viewHeight
    
    private let hotTagCellHeight: CGFloat = NovelReadingSearchRecomHotTagCell.viewHeight
    
    private var historyKeywordList: [String] = [] {
        didSet {
            refreshCollectionViewHeight()
        }
    }
    
    private var hotTagList: [NovelReadingTagItem] = []  {
        didSet {
            refreshCollectionViewHeight()
        }
    }
    
    weak var delegate: NovelReadingSearchRecomHeaderViewDelegate?
    
    var type: NovelReadingType = .novel
    
    var viewHeight: CGFloat = NovelReadingSearchRecomHeaderView.miniViewHeight {
        didSet {
            delegate?.refreshWrapperScrollViewHeight()
        }
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        addSubview(collectionView)
        
        collectionView.snp.makeConstraints { (make) in
            make.top.equalToSuperview().inset(NovelReadingSearchRecomHeaderView.marginTop)
            make.left.right.equalToSuperview()
            make.bottom.equalToSuperview().inset(NovelReadingSearchRecomHeaderView.marginBottom)
        }
        getHistoryTagsData()
        getHotTagList()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func getHotTagList() {
        Session.request(NovelReadingSearchHotTagsListReq()) { [weak self] (error, resp) in
            guard let `self` = self, error == nil, let resData = resp as? [NovelReadingTagItem], !resData.isEmpty else { return }
            self.hotTagList = resData
        }
    }
    
    private func refreshCollectionViewHeight() {
        collectionView.reloadData()
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.02) { [weak self] in
            guard let `self` = self else { return }
            self.viewHeight = max(self.collectionView.contentSize.height + NovelReadingSearchRecomHeaderView.verticalMargin, NovelReadingSearchRecomHeaderView.miniViewHeight)
        }
    }
    
    private func getHistoryTagsData() {
        if let historyKeywordList = Defaults.novelReadingHistoryKeywordList {
            self.historyKeywordList = historyKeywordList
        } else {
            historyKeywordList = []
        }
    }
    
}

extension NovelReadingSearchRecomHeaderView: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return NovelReadingSearchRecomHeaderView.sectionHeaderTitleList.count
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return section == 0 ? historyKeywordList.count : section == 1 ? hotTagList.count : 0
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        return section == 0 ? (historyKeywordList.isEmpty ? .zero : sectionEdgeInsets) : section == 1 ? (hotTagList.isEmpty ? .zero : sectionEdgeInsets) : .zero
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, referenceSizeForHeaderInSection section: Int) -> CGSize {
        return section == 0 ? (historyKeywordList.isEmpty ? .zero : sectionHeaderSize) : section == 1 ? (hotTagList.isEmpty ? .zero : sectionHeaderSize) : sectionHeaderSize
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        switch indexPath.section {
        case 0:
            return CGSize(width: historyKeywordList[indexPath.row].getStringSize(rectSize: .zero, font: font(14)).width + 20, height: historyCellHeight)
        case 1:
            return CGSize(width: hotTagList[indexPath.row].hotWordName.getStringSize(rectSize: .zero, font: font(13, .medium)).width + 17, height: hotTagCellHeight)
        default:
            return .zero
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return section == 0 ? 10 : section == 1 ? 36 : 0
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return section == 0 ? 30 : section == 1 ? 39 : 0
    }
    
    func collectionView(_ collectionView: UICollectionView, viewForSupplementaryElementOfKind kind: String, at indexPath: IndexPath) -> UICollectionReusableView {
        guard kind == UICollectionView.elementKindSectionHeader, let headerView = collectionView.dequeueReusableSupplementaryView(ofKind: kind, withReuseIdentifier: "NovelReadingSearchRecomHVSectionHeaderView", for: indexPath) as? NovelReadingSearchRecomHVSectionHeaderView else {
            return UICollectionReusableView()
        }
        let section = indexPath.section
        headerView.delegate = self
        headerView.titleLabel.text = NovelReadingSearchRecomHeaderView.sectionHeaderTitleList[section]
        headerView.deleteBtn.isHidden = section != 0
        return headerView
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let row = indexPath.row
        switch indexPath.section {
        case 0:
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "NovelReadingSearchRecomHistoryCell", for: indexPath) as! NovelReadingSearchRecomHistoryCell
            cell.titleLabel.text = historyKeywordList[row]
            return cell
        case 1:
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "NovelReadingSearchRecomHotTagCell", for: indexPath) as! NovelReadingSearchRecomHotTagCell
            cell.titleLabel.text = hotTagList[row].hotWordName
            cell.currentIndex = row
            return cell
        default:
            return UICollectionViewCell()
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let row = indexPath.row
        switch indexPath.section {
        case 0:
            delegate?.onRecomHeaderViewHistoryTagTap(keyword: historyKeywordList[row])
        case 1:
            guard let navigationController = (UIApplication.shared.delegate as? AppDelegate)?.currentNavigationController else { return }
            let currentItem = hotTagList[row]
            let novelReadingRecomChannelAndTagsListVC = NovelReadingRecomChannelAndTagsListVC()
            novelReadingRecomChannelAndTagsListVC.type = NovelReadingType(rawValue: currentItem.hotType) ?? .novel
            novelReadingRecomChannelAndTagsListVC.readingType = .tag
            novelReadingRecomChannelAndTagsListVC.navigationTitle = novelReadingRecomChannelAndTagsListVC.type == .reading ? currentItem.hotWordName : "#\(currentItem.hotWordName)"
            novelReadingRecomChannelAndTagsListVC.tagId = currentItem.tagId
            navigationController.show(novelReadingRecomChannelAndTagsListVC, sender: nil)
        default:
            break
        }
    }
}

extension NovelReadingSearchRecomHeaderView: NovelReadingSearchRecomHVSectionHeaderViewDelegate {
    
    func onDeleteBtnTap() {
        Defaults.novelReadingHistoryKeywordList = []
        historyKeywordList = []
    }
    
}
