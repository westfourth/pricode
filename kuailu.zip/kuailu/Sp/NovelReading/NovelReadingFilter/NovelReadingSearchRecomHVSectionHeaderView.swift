//
//  NovelReadingSearchRecomHVSectionHeaderView.swift
//  CaoLong
//
//  Created by mac on 2021/1/29.
//  Copyright © 2021 mac. All rights reserved.
//

import UIKit

protocol NovelReadingSearchRecomHVSectionHeaderViewDelegate: NSObjectProtocol {
    
    func onDeleteBtnTap()
    
}

class NovelReadingSearchRecomHVSectionHeaderView: UICollectionReusableView {
    
    static let viewHeight: CGFloat = 24
    
    private static let deleteImg: UIImage? = {
        return UIImage(named: "novel_reading_search_delete")
    }()
    
    lazy var titleLabel: UILabel = {
        let label = UILabel()
        label.font = font(16, .medium)
        label.textColor = .white
        return label
    }()
    
    lazy var deleteBtn: UIButton = {
        let btn = UIButton()
        btn.setImage(NovelReadingSearchRecomHVSectionHeaderView.deleteImg, for: .normal)
        btn.addTarget(self, action: #selector(onDeleteBtnTap), for: .touchUpInside)
        btn.isHidden = true
        return btn
    }()
    
    weak var delegate: NovelReadingSearchRecomHVSectionHeaderViewDelegate?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        renderView()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func renderView() {
        addSubview(titleLabel)
        addSubview(deleteBtn)
        
        titleLabel.snp.makeConstraints { (make) in
            make.left.right.equalToSuperview().inset(10)
            make.top.bottom.equalToSuperview()
        }
        
        deleteBtn.snp.makeConstraints { (make) in
            make.right.equalToSuperview().inset(17)
            make.centerY.equalToSuperview()
            make.width.equalTo(20)
            make.height.equalTo(19)
        }
        
    }
    
    @objc private func onDeleteBtnTap() {
        delegate?.onDeleteBtnTap()
    }
    
}

