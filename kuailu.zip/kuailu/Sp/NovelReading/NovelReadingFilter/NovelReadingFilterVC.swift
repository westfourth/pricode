//
//  NovelReadingFilterVC.swift
//  CaoLong
//
//  Created by mac on 2021/1/25.
//  Copyright © 2021 mac. All rights reserved.
//

import UIKit

class NovelReadingFilterVC: UIViewController {
    
    private static let searchBgBtnHeight: CGFloat = 34
    
    private static let categoryBarHeight: CGFloat = 48
    
    private static let categoryBarWidth: CGFloat = 70
    
    private static let categoryBarIndicatorWidth: CGFloat = 32
    
    private static let categoryBarIndicatorHeight: CGFloat = 4
    
    private static let categoryBarCollectionViewLineSpacing: CGFloat = 20
    
    private static let categoryBarCollectionViewHeight: CGFloat = 54
    
    private static let cancelBtnWidth: CGFloat = 34
    
    private static let scrollListItemSize: CGSize = {
        return CGSize(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height - MARGIN_TOP - NovelReadingFilterVC.categoryBarCollectionViewHeight)
    }()
    
    private static let categoryDefaultList: [NovelReadingClassifyItem] = {
        let categoryDefaultNameList: [String] = ["全部"]
        var tempList: [NovelReadingClassifyItem] = []
        for i in 0..<categoryDefaultNameList.count {
            let novelReadingClassifyItem = NovelReadingClassifyItem()
            novelReadingClassifyItem.title = categoryDefaultNameList[i]
            tempList.append(novelReadingClassifyItem)
        }
        return tempList
    }()
    
    private lazy var categoryBarIndicatorView: UIView = {
        let view = UIView()
        view.backgroundColor = Color.theme_color
        view.layer.masksToBounds = true
        view.layer.cornerRadius = NovelReadingFilterVC.categoryBarIndicatorHeight / 2
        return view
    }()
    
    private lazy var searchImgView: UIImageView = {
        let imgView = UIImageView(image: NovelReadingScrollListItemCellHeaderView.searchImg)
        imgView.contentMode = .scaleAspectFit
        return imgView
    }()
    
    private lazy var searchTipLabel: UILabel = {
        let label = UILabel()
        label.text = "搜索成人小說或有聲讀物"
        label.font = FONT(14)
        label.textColor = rgb(0x8A8A8A)
        return label
    }()
    
    private lazy var cancelBtn: UIButton = {
        let btn = UIButton(frame: CGRect(x: 0, y: 0, width: 34, height: 22))
        btn.setTitle("取消", for: .normal)
        btn.setTitleColor(.white, for: .normal)
        btn.titleLabel?.font = font(16)
        btn.addTarget(self, action: #selector(onCancelBtnTap), for: .touchUpInside)
        return btn
    }()
    
    private lazy var searchBgBar: UIView = {
        let view = UIView()
        view.backgroundColor = rgb(0x3A3A3A)
        view.layer.cornerRadius = NovelReadingFilterVC.searchBgBtnHeight / 2
        view.layer.masksToBounds = true
        view.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(onSearchBgBtnTap)))
        view.addSubview(searchImgView)
        view.addSubview(searchTipLabel)
        
        searchImgView.snp.makeConstraints { (make) in
            make.left.equalToSuperview().inset(10)
            make.centerY.equalToSuperview()
            make.size.equalTo(14)
        }
        
        searchTipLabel.snp.makeConstraints { (make) in
            make.left.equalTo(searchImgView.snp.right).offset(8)
            make.top.bottom.equalToSuperview()
            make.right.equalToSuperview().inset(10)
        }
        
        return view
    }()
    
    private lazy var searchWrapperView: UIView = {
        let view = UIView()
        view.addSubview(cancelBtn)
        view.addSubview(searchBgBar)
        
        cancelBtn.snp.makeConstraints { (make) in
            make.top.bottom.equalToSuperview()
            if #available(iOS 14.0, *) {
                make.right.equalToSuperview().inset(20)
            } else {
                make.right.equalToSuperview()
            }
            make.width.equalTo(NovelReadingFilterVC.cancelBtnWidth)
        }
        
        searchBgBar.snp.makeConstraints { (make) in
            make.left.top.bottom.equalToSuperview()
            make.right.equalTo(cancelBtn.snp.left).offset(-20)
        }
        
        return view
    }()
    
    private lazy var categoryBarCollectionView: UICollectionView = {
        let layout = UICollectionViewFlowLayout()
        layout.minimumLineSpacing = NovelReadingFilterVC.categoryBarCollectionViewLineSpacing
        layout.minimumInteritemSpacing = layout.minimumLineSpacing
        layout.scrollDirection = .horizontal
        let cv = UICollectionView(frame: .zero, collectionViewLayout: layout)
        cv.register(NovelReadingFilterCategoryCell.self, forCellWithReuseIdentifier: "NovelReadingFilterCategoryCell")
        cv.contentInset = UIEdgeInsets(top: 0, left: 10, bottom: 0, right: 10)
        cv.showsVerticalScrollIndicator = false
        cv.showsHorizontalScrollIndicator = false
        cv.bouncesZoom = false
        cv.backgroundColor = rgb(0x222425)
        cv.delegate = self
        cv.dataSource = self
        return cv
    }()
    
    private lazy var scrollListCollectionView: UICollectionView = {
        let layout = UICollectionViewFlowLayout()
        layout.minimumLineSpacing = 0
        layout.minimumInteritemSpacing = 0
        layout.itemSize = NovelReadingFilterVC.scrollListItemSize
        layout.scrollDirection = .horizontal
        let cv = UICollectionView(frame: .zero, collectionViewLayout: layout)
        cv.showsVerticalScrollIndicator = false
        cv.showsHorizontalScrollIndicator = false
        cv.bouncesZoom = false
        cv.isPagingEnabled = true
        cv.backgroundColor = .none
        cv.delegate = self
        cv.dataSource = self
        return cv
    }()
    
    private var categoryList: [NovelReadingClassifyItem] = [] {
        didSet {
            categoryBarCollectionView.reloadData()
        }
    }
    
    private var activePageIndex: Int = 0
    
    private var isGetUserinfo: Bool = false
    
    private var isTapCategoryItem: Bool = false
    
    var type: NovelReadingType = .novel {
        didSet {
            getAllCategoryTagList()
        }
    }
    
    override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: Bundle?) {
        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
        hidesBottomBarWhenPushed = true
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        if #available(iOS 11.0, *) {
            categoryBarCollectionView.contentInsetAdjustmentBehavior = .never
            scrollListCollectionView.contentInsetAdjustmentBehavior = .never
        } else {
            automaticallyAdjustsScrollViewInsets = false
        }
        navigationItem.rightBarButtonItem = UIBarButtonItem(customView: searchWrapperView)
        view.backgroundColor = Color.bg_color
        renderView()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.navigationBar.barTintColor = rgb(0x222425)
        Appearance.transparent(false, navigationBar: navigationController?.navigationBar)
        if !isGetUserinfo {
            getUserinfo()
        }
    }
    
    private func renderView() {
        view.addSubview(scrollListCollectionView)
        view.addSubview(categoryBarCollectionView)
        
        searchWrapperView.snp.makeConstraints { (make) in
            if #available(iOS 14.0, *) {
                make.width.equalTo(UIScreen.main.bounds.width - 50)
            } else {
                make.width.equalTo(UIScreen.main.bounds.width - 60)
            }
            make.height.equalTo(NovelReadingFilterVC.searchBgBtnHeight)
        }
        
        
        categoryBarCollectionView.snp.makeConstraints { (make) in
            make.top.left.right.equalToSuperview()
            make.height.equalTo(NovelReadingFilterVC.categoryBarCollectionViewHeight)
        }
        
        scrollListCollectionView.snp.makeConstraints { (make) in
            make.top.equalTo(categoryBarCollectionView.snp.bottom)
            make.left.right.equalToSuperview()
            make.height.equalTo(NovelReadingFilterVC.scrollListItemSize.height)
        }
    }
    
    private func getAllCategoryTagList() {
        let req = NovelReadingFilterAllTagsListReq()
        req.tagType = type == .novel ? 1 : 2
        Session.request(req) { [weak self] (error, resp) in
            guard let `self` = self else { return }
            guard error == nil, let resData = resp as? [NovelReadingTagItem], !resData.isEmpty else {
                self.initDefaultCategoryList()
                return
            }
            if !NovelReadingFilterVC.categoryDefaultList.isEmpty {
                NovelReadingFilterVC.categoryDefaultList[0].tagList = resData
            }
            self.initDefaultCategoryList()
        }
    }
    
    private func initDefaultCategoryList() {
        categoryList = NovelReadingFilterVC.categoryDefaultList
        assemblyScrollList(startIndex: 0)
        getCategoryList()
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.05){ [weak self] in
            if let `self` = self, let cell = self.categoryBarCollectionView.dequeueReusableCell(withReuseIdentifier: "NovelReadingFilterCategoryCell", for: IndexPath(row: self.activePageIndex, section: 0)) as? NovelReadingFilterCategoryCell {
                self.categoryBarCollectionView.addSubview(self.categoryBarIndicatorView)
                let indicatorViewWidth = NovelReadingFilterVC.categoryBarIndicatorWidth
                let indicatorViewHeight = NovelReadingFilterVC.categoryBarIndicatorHeight
                self.categoryBarIndicatorView.frame = CGRect(x: cell.centerX - indicatorViewWidth / 2, y: NovelReadingFilterVC.categoryBarCollectionViewHeight - indicatorViewHeight, width: indicatorViewWidth, height: indicatorViewHeight)
            }
        }
    }
    
    private func getCategoryList() {
        let req = NovelReadingClassifyListReq()
        req.fictionType = type == .novel ? 1 : 2
        Session.request(req) { [weak self] (error, resp) in
            guard let `self` = self else { return }
            guard error == nil, let resData = resp as? [NovelReadingClassifyItem], !resData.isEmpty else { return }
            let initCategoryListLen = self.categoryList.count
            self.categoryList += resData
            self.assemblyScrollList(startIndex: initCategoryListLen)
        }
    }
    
    private func assemblyScrollList(startIndex: Int) {
        for i in startIndex..<categoryList.count {
            scrollListCollectionView.register(NovelReadingFilterItemCell.self, forCellWithReuseIdentifier: "NovelReadingFilterItemCell\(i)")
        }
        scrollListCollectionView.reloadData()
    }
    
    @objc private func onSearchBgBtnTap() {
        let novelReadingSearchVC = NovelReadingSearchVC()
        novelReadingSearchVC.type = type
        navigationController?.show(novelReadingSearchVC, sender: nil)
    }
    
    @objc private func onCancelBtnTap() {
        navigationController?.popViewController(animated: true)
    }
    
    private func refreshCategoryBarCollectionView(activePageIndex: Int) {
        categoryBarCollectionView.scrollToItem(at: IndexPath(row: activePageIndex, section: 0), at: .centeredHorizontally, animated: true)
        UIView.animate(withDuration: 0.15, delay: 0, options: .curveEaseIn, animations: {}) { [weak self] _ in
            guard let `self` = self else { return }
            self.categoryBarCollectionView.reloadData()
            if let cell = self.categoryBarCollectionView.dequeueReusableCell(withReuseIdentifier: "NovelReadingFilterCategoryCell", for: IndexPath(row: self.activePageIndex, section: 0)) as? NovelReadingFilterCategoryCell {
                self.categoryBarIndicatorView.center.x = cell.centerX
            }
            self.isTapCategoryItem = false
        }
    }
    
    private func getUserinfo() {
        guard !isGetUserinfo else { return }
        isGetUserinfo = true
        Session.request(FetchUserInfoReq()) { [weak self] (error, resp) in
            guard let `self` = self else { return }
            self.isGetUserinfo = false
        }
    }
    
}

extension  NovelReadingFilterVC: UICollectionViewDataSource, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int)
    -> Int {
        return categoryList.count
    }
    
    func collectionView(_ collectionView: UICollectionView,
                        layout collectionViewLayout: UICollectionViewLayout,
                        sizeForItemAt indexPath: IndexPath) -> CGSize {
        return collectionView == categoryBarCollectionView ? CGSize(width: categoryList[indexPath.row].title.getStringSize(rectSize: .zero, font: font(16, .medium)).width, height: NovelReadingFilterVC.categoryBarCollectionViewHeight) : NovelReadingFilterVC.scrollListItemSize
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let row = indexPath.row
        guard collectionView == scrollListCollectionView else {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "NovelReadingFilterCategoryCell", for: indexPath) as! NovelReadingFilterCategoryCell
            cell.titleLabel.text = categoryList[row].title
            let isActive = activePageIndex == row
            cell.titleLabel.textColor = isActive ? .white : rgb(0xC2C2C2)
            cell.titleLabel.font = isActive ? font(16, .medium) : font(16)
            return cell
        }
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "NovelReadingFilterItemCell\(row)", for: indexPath) as! NovelReadingFilterItemCell
        cell.type = type
        cell.itemData = categoryList[row]
        return cell
        
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let row = indexPath.row
        guard collectionView == categoryBarCollectionView, activePageIndex != row else { return }
        activePageIndex = row
        isTapCategoryItem = true
        scrollListCollectionView.scrollToItem(at: indexPath, at: .centeredHorizontally, animated: true)
    }
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        guard scrollView == scrollListCollectionView else { return }
        let currentActivePageIndex = Int(round(scrollView.contentOffset.x / scrollView.frame.width))
        guard isTapCategoryItem else {
            guard activePageIndex != currentActivePageIndex else { return }
            activePageIndex = currentActivePageIndex
            refreshCategoryBarCollectionView(activePageIndex: currentActivePageIndex)
            return
        }
        guard currentActivePageIndex == activePageIndex else { return }
        refreshCategoryBarCollectionView(activePageIndex: currentActivePageIndex)
    }
    
}
