//
//  NovelReadingVC.swift
//  CaoLong
//
//  Created by mac on 2021/1/25.
//  Copyright © 2021 mac. All rights reserved.
//

import UIKit

enum NovelReadingType: Int {
    /// 小说
    case novel = 0
    /// 有声读物
    case reading = 1
}

class NovelReadingVC: UIViewController {
    
    private static let categoryBarHeight: CGFloat = 48
    
    private static let categoryBarWidth: CGFloat = 70
    
    private static let categoryBarIndicatorWidth: CGFloat = 32
    
    private static let categoryBarIndicatorHeight: CGFloat = 4
    
    private static let categoryBarCollectionViewLineSpacing: CGFloat = 28
    
    private static let categoryBarItemSize: CGSize = {
        return CGSize(width: NovelReadingVC.categoryBarWidth, height: NovelReadingVC.categoryBarHeight)
    }()
    
    private static let categoryBarIndicatorInitFrame: CGRect = {
        return CGRect(x: (NovelReadingVC.categoryBarWidth - NovelReadingVC.categoryBarIndicatorWidth) / 2, y: NovelReadingVC.categoryBarHeight - NovelReadingVC.categoryBarIndicatorHeight - 8, width: NovelReadingVC.categoryBarIndicatorWidth, height: NovelReadingVC.categoryBarIndicatorHeight)
    }()
    
    private static let categoryBarCollectionViewWidth: CGFloat = {
        return NovelReadingVC.categoryBarWidth * CGFloat(NovelReadingVC.categoryNameList.count) + NovelReadingVC.categoryBarCollectionViewLineSpacing
    }()
    
    private static let scrollListItemSize: CGSize = {
        return CGSize(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height -  MARGIN_TOP)
    }()
    
    private static let categoryNameList: [String] = {
        return ["成人小說", "有聲讀物"]
    }()
    
    private lazy var categoryBarIndicatorView: UIView = {
        let view = UIView(frame: NovelReadingVC.categoryBarIndicatorInitFrame)
        view.backgroundColor = Color.theme_color
        view.layer.masksToBounds = true
        view.layer.cornerRadius = NovelReadingVC.categoryBarIndicatorHeight / 2
        return view
    }()
    
    private lazy var categoryBarCollectionView: UICollectionView = {
        let layout = UICollectionViewFlowLayout()
        layout.minimumLineSpacing = NovelReadingVC.categoryBarCollectionViewLineSpacing
        layout.minimumInteritemSpacing = layout.minimumLineSpacing
        layout.itemSize = NovelReadingVC.categoryBarItemSize
        layout.scrollDirection = .horizontal
        let cv = UICollectionView(frame: .zero, collectionViewLayout: layout)
        cv.register(NovelReadingCategoryCell.self, forCellWithReuseIdentifier: "NovelReadingCategoryCell")
        cv.showsVerticalScrollIndicator = false
        cv.showsHorizontalScrollIndicator = false
        cv.bouncesZoom = false
        cv.isScrollEnabled = false
        cv.bounces = false
        cv.backgroundColor = .none
        cv.delegate = self
        cv.dataSource = self
        cv.addSubview(categoryBarIndicatorView)
        return cv
    }()
    
    private lazy var scrollListCollectionView: UICollectionView = {
        let layout = UICollectionViewFlowLayout()
        layout.minimumLineSpacing = 0
        layout.minimumInteritemSpacing = 0
        layout.itemSize = NovelReadingVC.scrollListItemSize
        layout.scrollDirection = .horizontal
        let cv = UICollectionView(frame: .zero, collectionViewLayout: layout)
        cv.register(NovelReadingScrollListItemCell.self, forCellWithReuseIdentifier: "NovelReadingScrollListItemNovelCell")
        cv.register(NovelReadingScrollListItemCell.self, forCellWithReuseIdentifier: "NovelReadingScrollListItemReadingCell")
        cv.showsVerticalScrollIndicator = false
        cv.showsHorizontalScrollIndicator = false
        cv.bouncesZoom = false
        cv.isPagingEnabled = true
        cv.backgroundColor = .none
        cv.bounces = false
        cv.delegate = self
        cv.dataSource = self
        return cv
    }()
    
    private var categoryBarBottomLine: UIView = {
        let view = UIView()
        view.backgroundColor = rgb(0x2A2B2C)
        return view
    }()
    
    private var activePageIndex: Int = 0
    
    private var isGetUserinfo: Bool = false
    
    private var isTapCategoryItem: Bool = false
    
    var initPageType: NovelReadingType = .novel {
        didSet {
            guard initPageType != .novel else { return }
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.05) { [weak self] in
                guard let `self` = self else { return }
                self.scrollListCollectionView.scrollToItem(at: IndexPath(item: self.initPageType.rawValue, section: 0), at: .centeredHorizontally, animated: false)
            }
        }
    }
    
    override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: Bundle?) {
        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
        hidesBottomBarWhenPushed = true
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        if #available(iOS 11.0, *) {
            categoryBarCollectionView.contentInsetAdjustmentBehavior = .never
            scrollListCollectionView.contentInsetAdjustmentBehavior = .never
        } else {
            automaticallyAdjustsScrollViewInsets = false
        }
        navigationItem.title = nil
        view.backgroundColor = Color.bg_color
        renderView()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.navigationBar.barTintColor = .clear
        Appearance.transparent(true, navigationBar: navigationController?.navigationBar)
        if !isGetUserinfo {
            getUserinfo()
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        navigationController?.navigationBar.barTintColor = rgb(0x222425)
        Appearance.transparent(false, navigationBar: navigationController?.navigationBar)
    }
    
    private func renderView() {
        navigationItem.titleView = categoryBarCollectionView
        view.addSubview(scrollListCollectionView)
        view.addSubview(categoryBarBottomLine)
        
        categoryBarBottomLine.snp.makeConstraints { (make) in
            make.top.equalToSuperview().inset(MARGIN_TOP)
            make.left.right.equalToSuperview().inset(10)
            make.height.equalTo(0.5)
        }
        
        categoryBarCollectionView.snp.makeConstraints { (make) in
            make.width.equalTo(NovelReadingVC.categoryBarCollectionViewWidth)
            make.height.equalTo(NovelReadingVC.categoryBarHeight)
        }
        
        scrollListCollectionView.snp.makeConstraints { (make) in
            make.top.equalTo(categoryBarBottomLine)
            make.left.right.equalToSuperview()
            make.height.equalTo(NovelReadingVC.scrollListItemSize.height)
        }
    }
    
    private func getUserinfo() {
        guard !isGetUserinfo else { return }
        isGetUserinfo = true
        Session.request(FetchUserInfoReq()) { [weak self] (error, resp) in
            guard let `self` = self else { return }
            self.isGetUserinfo = false
        }
    }
    
    private func refreshCategoryBarCollectionView(activePageIndex: Int) {
        categoryBarCollectionView.scrollToItem(at: IndexPath(row: activePageIndex, section: 0), at: .centeredHorizontally, animated: true)
        UIView.animate(withDuration: 0.15, delay: 0, options: .curveEaseIn, animations: { [weak self] in
            guard let `self` = self, let cell = self.categoryBarCollectionView.dequeueReusableCell(withReuseIdentifier: "NovelReadingCategoryCell", for: IndexPath(row: activePageIndex, section: 0)) as? NovelReadingCategoryCell else {
                return
            }
            self.categoryBarIndicatorView.center.x = cell.centerX
        }) { [weak self] _ in
            self?.categoryBarCollectionView.reloadData()
            self?.isTapCategoryItem = false
        }
    }
    
    static func navigationToAudioNovelDetailVC(fictionId: Int) {
        guard NetDefaults.userInfo?.freeWatches == -1 else {
            PurchaseVipAlert.showPurchaseVipAlert()
            return
        }
        guard let topViewController = (UIApplication.shared.delegate as? AppDelegate)?.currentNavigationController?.topViewController else { return }
        let vc = AudioNovelDetailVC()
        vc.id = fictionId
        vc.hidesBottomBarWhenPushed = true
        topViewController.present(vc, animated: true, completion: nil)
    }
    
    static func navigationToTextNovelDetailVC(fictionId: Int) {
        guard NetDefaults.userInfo?.freeWatches == -1 else {
            PurchaseVipAlert.showPurchaseVipAlert()
            return
        }
        guard let navigationController = (UIApplication.shared.delegate as? AppDelegate)?.currentNavigationController else { return }
        let vc = TextNovelDetailVC()
        vc.id = fictionId
        vc.hidesBottomBarWhenPushed = true
        navigationController.show(vc, sender: nil)
    }
    
}

extension NovelReadingVC: UICollectionViewDataSource, UICollectionViewDelegate {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return NovelReadingVC.categoryNameList.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let row = indexPath.row
        guard collectionView == scrollListCollectionView else {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "NovelReadingCategoryCell", for: indexPath) as! NovelReadingCategoryCell
            cell.titleLabel.text = NovelReadingVC.categoryNameList[row]
            cell.titleLabel.textColor = activePageIndex == row ? .white : rgb(0xBBBBBB)
            return cell
        }
        switch NovelReadingType(rawValue: row) {
        case .novel:
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "NovelReadingScrollListItemNovelCell", for: indexPath) as! NovelReadingScrollListItemCell
            cell.type = .novel
            return cell
        case .reading:
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "NovelReadingScrollListItemReadingCell", for: indexPath) as! NovelReadingScrollListItemCell
            cell.type = .reading
            return cell
        default:
            return UICollectionViewCell()
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let row = indexPath.row
        guard collectionView == categoryBarCollectionView, activePageIndex != row else { return }
        activePageIndex = row
        isTapCategoryItem = true
        scrollListCollectionView.scrollToItem(at: indexPath, at: .centeredHorizontally, animated: true)
    }
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        guard scrollView == scrollListCollectionView else { return }
        let currentActivePageIndex = Int(round(scrollView.contentOffset.x / scrollView.frame.width))
        guard isTapCategoryItem else {
            guard activePageIndex != currentActivePageIndex else { return }
            activePageIndex = currentActivePageIndex
            refreshCategoryBarCollectionView(activePageIndex: currentActivePageIndex)
            return
        }
        guard currentActivePageIndex == activePageIndex else { return }
        refreshCategoryBarCollectionView(activePageIndex: currentActivePageIndex)
    }
}

