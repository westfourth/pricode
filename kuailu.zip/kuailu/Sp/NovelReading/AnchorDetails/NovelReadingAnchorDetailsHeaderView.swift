//
//  NovelReadingAnchorDetailsHeaderView.swift
//  CaoLong
//
//  Created by mac on 2021/1/26.
//  Copyright © 2021 mac. All rights reserved.
//

import UIKit

protocol NovelReadingAnchorDetailsHeaderViewDelegate: NSObjectProtocol {
    
    func refreshTitleViewAttensionStatus()
    
    func onOpenVipBtnTap()
    
}

class NovelReadingAnchorDetailsHeaderView: UIView {
    
    static let maxViewHeight: CGFloat = {
        return NovelReadingAnchorDetailsHeaderView.marginTop +
            NovelReadingAnchorDetailsHeaderView.avatarSize +
            NovelReadingAnchorDetailsHeaderView.vipBtnMarginTop + NovelReadingAnchorDetailsHeaderView.openVipBtnHeight + NovelReadingAnchorDetailsHeaderView.marginBottom
    }()
    
    static let minViewHeight: CGFloat = {
        return NovelReadingAnchorDetailsHeaderView.marginTop +
            NovelReadingAnchorDetailsHeaderView.avatarSize + NovelReadingAnchorDetailsHeaderView.marginBottom
    }()
    
    private static let marginTop: CGFloat = 20
    
    private static let avatarSize: CGFloat = 88
    
    private static let vipBtnMarginTop: CGFloat = 24
    
    private static let marginBottom: CGFloat = 24
    
    private static let openVipBtnWidth: CGFloat = {
        return UIScreen.main.bounds.width - 18 * 2
    }()
    
    private static let openVipBtnHeight: CGFloat = {
        return NovelReadingAnchorDetailsHeaderView.openVipBtnWidth / 384 * 38
    }()
    
    static let attentionImg: UIImage? = {
        return UIImage(named: "novel_reading_anchor_details_attention")
    }()
    
    private static let openVipImg: UIImage? = {
        return UIImage.decrypt("novel_reading_anchor_details_open_vip.png.enc")
    }()
    
    private lazy var avatarImgView: UIImageView = {
        let imgView = UIImageView()
        imgView.contentMode = .scaleAspectFill
        imgView.layer.masksToBounds = true
        imgView.layer.cornerRadius = NovelReadingAnchorDetailsHeaderView.avatarSize / 2
        return imgView
    }()
    
    private lazy var nicknameLabel: UILabel = {
        let label = UILabel()
        label.textColor = .white
        label.font = font(24, .semibold)
        return label
    }()
    
    private lazy var detailsLabel: UILabel = {
        let label = UILabel()
        label.text = "0人關注·0人收聽"
        label.textColor = rgb(0xB1B1B1)
        label.font = font(12)
        return label
    }()
    
    private lazy var attentionBtn: UIButton = {
        let btn = UIButton()
        btn.setTitle("關注主播", for: .normal)
        btn.setTitleColor(rgb(0xB1B1B1), for: .normal)
        btn.titleLabel?.font = font(12)
        btn.setImage(NovelReadingAnchorDetailsHeaderView.attentionImg, for: .normal)
        btn.addTarget(self, action: #selector(onAttentionBtnTap), for: .touchUpInside)
        return btn
    }()
    
    private lazy var openVipBtn: UIButton = {
        let btn = UIButton()
        btn.addTarget(self, action: #selector(onOpenVipBtnTap), for: .touchUpInside)
        btn.isHidden = true
        return btn
    }()
    
    weak var delegate: NovelReadingAnchorDetailsHeaderViewDelegate?
    
    var isVip: Bool = false {
        didSet {
            openVipBtn.setBackgroundImage(isVip ? nil : NovelReadingAnchorDetailsHeaderView.openVipImg, for: .normal)
            openVipBtn.isHidden = isVip
        }
    }
    
    var dataModel: ReadingAnchorDetatilsItem? {
        didSet {
            guard let item = dataModel else { return }
            avatarImgView.kf.setImage(with: item.anchorLogo?.column3, placeholder: Sensitive.default_bg, options: Sensitive.animationOption)
            nicknameLabel.text = item.anchorName
            detailsLabel.text = "\(num2TenThousandStrFormat(item.attentionNum))人關注·\(num2TenThousandStrFormat(item.fakeWatchTimes))人收聽"
            updateAttentionBtnStatus(isAttention: item.attention)
        }
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        renderView()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func renderView() {
        addSubview(avatarImgView)
        addSubview(nicknameLabel)
        addSubview(detailsLabel)
        addSubview(attentionBtn)
        addSubview(openVipBtn)
        
        avatarImgView.snp.makeConstraints { (make) in
            make.top.equalToSuperview().inset(NovelReadingAnchorDetailsHeaderView.marginTop)
            make.left.equalToSuperview().inset(18)
            make.size.equalTo(NovelReadingAnchorDetailsHeaderView.avatarSize)
        }
        
        nicknameLabel.snp.makeConstraints { (make) in
            make.top.equalTo(avatarImgView).offset(12)
            make.left.equalTo(avatarImgView.snp.right).offset(24)
            make.right.equalToSuperview().inset(130)
            make.height.equalTo(34)
        }
        
        attentionBtn.snp.makeConstraints { (make) in
            make.right.equalToSuperview().inset(30)
            make.width.equalTo(90)
            make.height.equalTo(45)
            make.centerY.equalTo(nicknameLabel)
        }
        
        detailsLabel.snp.makeConstraints { (make) in
            make.top.equalTo(nicknameLabel.snp.bottom).offset(12)
            make.left.equalTo(nicknameLabel)
            make.right.equalTo(attentionBtn)
        }
        
        openVipBtn.snp.makeConstraints { (make) in
            make.top.equalTo(avatarImgView.snp.bottom).offset(NovelReadingAnchorDetailsHeaderView.vipBtnMarginTop)
            make.centerX.equalToSuperview()
            make.width.equalTo(NovelReadingAnchorDetailsHeaderView.openVipBtnWidth)
            make.height.equalTo(NovelReadingAnchorDetailsHeaderView.openVipBtnHeight)
        }
        
        attentionBtn.imagePosition(imageStyle: .left, spacing: 7)
        
    }
    
    private func updateAttentionBtnStatus(isAttention: Bool) {
        attentionBtn.setTitle(isAttention ? "取消關注" : "關注主播", for: .normal)
        attentionBtn.setImage(isAttention ? NovelReadingAnchorDetailsHeaderView.attentionImg : NovelReadingAnchorDetailsHeaderView.attentionImg, for: .normal)
    }
    
    @objc private func onAttentionBtnTap() {
        guard let item = dataModel else { return }
        loading()
        let req = ReadingAnchorAttentionReq()
        req.anchorId = item.anchorId
        req.isAttention = !item.attention
        Session.request(req) { [weak self] (error, resp) in
            hideLoading()
            guard error == nil else {
                iToast(error!.localizedDescription)
                return
            }
            item.attention = req.isAttention
            item.attentionNum = max(0, item.attention ? item.attentionNum + 1 : item.attentionNum - 1)
            self?.updateAttentionBtnStatus(isAttention: req.isAttention)
            self?.detailsLabel.text = "\(num2TenThousandStrFormat(item.attentionNum))人關注·\(num2TenThousandStrFormat(item.fakeWatchTimes))人收聽"
            self?.delegate?.refreshTitleViewAttensionStatus()
            iToast(req.isAttention ? "關注成功!" : "取消關注成功!", type: .succeed)
        }
    }
    
    @objc private func onOpenVipBtnTap() {
        delegate?.onOpenVipBtnTap()
    }
    
}
