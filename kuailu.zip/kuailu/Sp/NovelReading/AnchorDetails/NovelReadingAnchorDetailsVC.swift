//
//  NovelReadingAnchorDetailsVC.swift
//  CaoLong
//
//  Created by mac on 2021/1/26.
//  Copyright © 2021 mac. All rights reserved.
//

import UIKit

class NovelReadingAnchorDetailsVC: UIViewController {
    
    private static let categoryBarCollectionViewHeight: CGFloat = 40
    
    private static let scrollListItemSize: CGSize = {
        return CGSize(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height - MARGIN_TOP - NovelReadingAnchorDetailsVC.categoryBarCollectionViewHeight)
    }()
    
    private static let categoryBarIndicatorWidth: CGFloat = 32
    
    private static let categoryBarIndicatorHeight: CGFloat = 4
    
    private static let categoryBarBottomLineHeight: CGFloat = 0.5
    
    private static let categoryBarMinLineSpacing: CGFloat = 20
    
    private lazy var titleView: NovelReadingAnchorDetailsTitleView = {
        let titleView = NovelReadingAnchorDetailsTitleView()
        titleView.delegate = self
        return titleView
    }()
    
    private lazy var headerView: NovelReadingAnchorDetailsHeaderView = {
        let headerView = NovelReadingAnchorDetailsHeaderView()
        headerView.delegate = self
        return headerView
    }()
    
    private lazy var categoryBarIndicatorView: UIView = {
        let view = UIView()
        view.backgroundColor = Color.theme_color
        view.layer.masksToBounds = true
        view.layer.cornerRadius = NovelReadingAnchorDetailsVC.categoryBarIndicatorHeight / 2
        view.isHidden = true
        return view
    }()
    
    private lazy var categoryBarBottomLine: UIView = {
        let view = UIView()
        view.backgroundColor = rgb(0x2A2B2C)
        return view
    }()
    
    private lazy var categoryBarCollectionView: UICollectionView = {
        let layout = UICollectionViewFlowLayout()
        layout.minimumLineSpacing = NovelReadingAnchorDetailsVC.categoryBarMinLineSpacing
        layout.minimumInteritemSpacing = layout.minimumLineSpacing
        layout.scrollDirection = .horizontal
        let cv = UICollectionView(frame: .zero, collectionViewLayout: layout)
        cv.register(NovelReadingAnchorDetailsCategoryCell.self, forCellWithReuseIdentifier: "NovelReadingAnchorDetailsCategoryCell")
        cv.contentInset = UIEdgeInsets(top: 0, left: 18, bottom: 0, right: 18)
        cv.showsVerticalScrollIndicator = false
        cv.showsHorizontalScrollIndicator = false
        cv.bouncesZoom = false
        cv.backgroundColor = Color.bg_color
        cv.delegate = self
        cv.dataSource = self
        return cv
    }()
    
    private lazy var scrollListCollectionView: UICollectionView = {
        let layout = UICollectionViewFlowLayout()
        layout.minimumLineSpacing = 0
        layout.minimumInteritemSpacing = 0
        layout.scrollDirection = .horizontal
        let cv = UICollectionView(frame: .zero, collectionViewLayout: layout)
        cv.showsVerticalScrollIndicator = false
        cv.showsHorizontalScrollIndicator = false
        cv.isDirectionalLockEnabled = true
        cv.bouncesZoom = false
        cv.bounces = false
        cv.isPagingEnabled = true
        cv.backgroundColor = Color.bg_color
        cv.delegate = self
        cv.dataSource = self
        return cv
    }()
    
    private lazy var wrapperSrollView: UIScrollView = {
        let scrollView = UIScrollView()
        scrollView.contentSize = CGSize(width: UIScreen.main.bounds.width, height: NovelReadingAnchorDetailsHeaderView.maxViewHeight + NovelReadingAnchorDetailsVC.categoryBarCollectionViewHeight + NovelReadingAnchorDetailsVC.scrollListItemSize.height)
        scrollView.showsHorizontalScrollIndicator = false
        scrollView.showsVerticalScrollIndicator = false
        scrollView.isDirectionalLockEnabled = true
        scrollView.bouncesZoom = false
        scrollView.delegate = self
        scrollView.isScrollEnabled = false
        scrollView.addSubview(headerView)
        scrollView.addSubview(categoryBarCollectionView)
        scrollView.addSubview(categoryBarBottomLine)
        scrollView.addSubview(scrollListCollectionView)
        
        let screenWidth = UIScreen.main.bounds.width
        
        headerView.snp.makeConstraints { (make) in
            make.top.left.equalToSuperview()
            make.width.equalTo(screenWidth)
            make.height.equalTo(wrapperSrollViewScrollEnabledThresholdVal)
        }
        
        categoryBarCollectionView.snp.makeConstraints { (make) in
            make.top.equalTo(headerView.snp.bottom)
            make.left.equalToSuperview()
            make.width.equalTo(screenWidth)
            make.height.equalTo(NovelReadingAnchorDetailsVC.categoryBarCollectionViewHeight)
        }
        
        categoryBarBottomLine.snp.makeConstraints { (make) in
            make.left.equalToSuperview().inset(10)
            make.bottom.equalTo(categoryBarCollectionView)
            make.width.equalTo(screenWidth - 10 * 2)
            make.height.equalTo(0.5)
        }
        
        scrollListCollectionView.snp.makeConstraints { (make) in
            make.top.equalTo(categoryBarCollectionView.snp.bottom)
            make.left.equalToSuperview()
            make.width.equalTo(screenWidth)
            make.height.equalTo(NovelReadingAnchorDetailsVC.scrollListItemSize.height)
        }
        
        return scrollView
    }()
    
    private lazy var wrapperSrollViewScrollEnabledThresholdVal: CGFloat = {
        return NovelReadingAnchorDetailsHeaderView.maxViewHeight
    }()
    
    private var isTapCategoryItem: Bool = false
    
    private var isGetUserinfo: Bool = false
    
    private var isGetAnchorinfo: Bool = false
    
    private var activePageIndex: Int = 0
    
    private var wrapperSrollViewOffsetY: CGFloat = 0 {
        willSet {
            switchChildrenScrollViewScrollEnabled(srollViewOffsetY: newValue)
            titleView.changeTitleViewStatus(changeValRate: max(0, min(newValue / wrapperSrollViewScrollEnabledThresholdVal, 1)))
        }
    }
    
    private var categoryList: [NovelReadingClassifyItem] = [] {
        didSet {
            categoryBarCollectionView.reloadData()
            assemblyCategoryBarAndSubScrollList(listData: categoryList)
            if let cell = categoryBarCollectionView.dequeueReusableCell(withReuseIdentifier: "NovelReadingAnchorDetailsCategoryCell", for: IndexPath(row: activePageIndex, section: 0)) as? NovelReadingAnchorDetailsCategoryCell {
                categoryBarCollectionView.addSubview(categoryBarIndicatorView)
                let indicatorViewWidth = NovelReadingAnchorDetailsVC.categoryBarIndicatorWidth
                let indicatorViewHeight = NovelReadingAnchorDetailsVC.categoryBarIndicatorHeight
                categoryBarIndicatorView.frame = CGRect(x: cell.centerX - indicatorViewWidth / 2, y: NovelReadingAnchorDetailsVC.categoryBarCollectionViewHeight - indicatorViewHeight, width: indicatorViewWidth, height: indicatorViewHeight)
                categoryBarIndicatorView.isHidden = false
            }
        }
    }
    
    private var anchorinfo: ReadingAnchorDetatilsItem? {
        didSet {
            guard let item = anchorinfo else { return }
            headerView.dataModel = item
            titleView.dataModel = item
        }
    }
    
    private var userinfo: UserBase? {
        didSet {
            guard let item = userinfo else { return }
            let isVip = item.freeWatches == -1
            wrapperSrollViewScrollEnabledThresholdVal = isVip ? NovelReadingAnchorDetailsHeaderView.minViewHeight : NovelReadingAnchorDetailsHeaderView.maxViewHeight
            headerView.snp.updateConstraints { (make) in
                make.height.equalTo(wrapperSrollViewScrollEnabledThresholdVal)
            }
            headerView.isVip = isVip
            wrapperSrollView.contentSize.height = wrapperSrollViewScrollEnabledThresholdVal + NovelReadingAnchorDetailsVC.categoryBarCollectionViewHeight + NovelReadingAnchorDetailsVC.scrollListItemSize.height
            wrapperSrollView.isScrollEnabled = true
        }
    }
    
    var anchorId: Int? {
        didSet {
            getAnchorinfo(isInit: true)
            getUserinfo()
        }
    }
    
    override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: Bundle?) {
        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
        hidesBottomBarWhenPushed = true
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        if #available(iOS 11.0, *) {
            wrapperSrollView.contentInsetAdjustmentBehavior = .never
            categoryBarCollectionView.contentInsetAdjustmentBehavior = .never
            scrollListCollectionView.contentInsetAdjustmentBehavior = .never
        } else {
            automaticallyAdjustsScrollViewInsets = false
        }
        view.backgroundColor = Color.bg_color
        navigationItem.rightBarButtonItem = UIBarButtonItem(customView: titleView)
        view.addSubview(wrapperSrollView)
        
        titleView.snp.makeConstraints { (make) in
            if #available(iOS 14.0, *) {
                make.width.equalTo(UIScreen.main.bounds.width - 50)
            } else {
                make.width.equalTo(UIScreen.main.bounds.width - 60)
            }
            make.height.equalTo(34)
        }
        
        wrapperSrollView.snp.makeConstraints { (make) in
            make.top.left.right.equalToSuperview()
            make.height.equalTo(UIScreen.main.bounds.height - MARGIN_TOP)
        }
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        Appearance.transparent(false, navigationBar: navigationController?.navigationBar)
        if !isGetUserinfo {
            getUserinfo()
        }
        if !isGetAnchorinfo {
            getAnchorinfo(isInit: false)
        }
    }
    
    private func getAnchorinfo(isInit: Bool) {
        guard !isGetAnchorinfo, let Id = anchorId else { return }
        isGetAnchorinfo = true
        isInit ? loading() : nil
        let req = ReadingAnchorDetailsReq()
        req.anchorId = Id
        Session.request(req) { [weak self] (error, resp) in
            isInit ? hideLoading() : nil
            guard let `self` = self else { return }
            self.isGetAnchorinfo = false
            guard error == nil, let resData = resp as? ReadingAnchorDetatilsItem else { return }
            self.anchorinfo = resData
            if isInit, !resData.classList.isEmpty {
                self.categoryList = resData.classList
            }
        }
    }
    
    private func getUserinfo() {
        guard !isGetUserinfo else { return }
        isGetUserinfo = true
        Session.request(FetchUserInfoReq()) { [weak self] (error, resp) in
            guard let `self` = self else { return }
            self.isGetUserinfo = false
            guard let resData = resp as? UserBase else { return }
            self.userinfo = resData
        }
    }
    
    private func assemblyCategoryBarAndSubScrollList(listData: [NovelReadingClassifyItem]) {
        for i in 0..<listData.count {
            scrollListCollectionView.register(NovelReadingAnchorDetailsItemCell.self, forCellWithReuseIdentifier: "NovelReadingAnchorDetailsItemCell\(i)")
        }
        scrollListCollectionView.reloadData()
    }
    
    private func refreshCategoryBarCollectionView(activePageIndex: Int) {
        categoryBarCollectionView.scrollToItem(at: IndexPath(row: activePageIndex, section: 0), at: .centeredHorizontally, animated: true)
        UIView.animate(withDuration: 0.15, delay: 0, options: .curveEaseIn, animations: {}) { [weak self] _ in
            guard let `self` = self else { return }
            self.categoryBarCollectionView.reloadData()
            if let cell = self.categoryBarCollectionView.dequeueReusableCell(withReuseIdentifier: "NovelReadingAnchorDetailsCategoryCell", for: IndexPath(row: activePageIndex, section: 0)) as? NovelReadingAnchorDetailsCategoryCell {
                self.categoryBarIndicatorView.center.x = cell.centerX
            }
            self.isTapCategoryItem = false
        }
    }
    
    private func switchChildrenScrollViewScrollEnabled(srollViewOffsetY: CGFloat) {
        switch activePageIndex {
        case 0:
            guard !scrollListCollectionView.visibleCells.isEmpty, let cell = scrollListCollectionView.visibleCells[0] as? NovelReadingAnchorDetailsItemCell else { return }
            cell.isScrollEnabled = srollViewOffsetY == wrapperSrollViewScrollEnabledThresholdVal
        case 1:
            guard !scrollListCollectionView.visibleCells.isEmpty, let cell = scrollListCollectionView.visibleCells[0] as? NovelReadingAnchorDetailsItemCell else  { return }
            cell.isScrollEnabled = srollViewOffsetY == wrapperSrollViewScrollEnabledThresholdVal
        default:
            break
        }
    }
    
}


extension NovelReadingAnchorDetailsVC: UICollectionViewDataSource, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int)
    -> Int {
        return categoryList.count
    }
    
    func collectionView(_ collectionView: UICollectionView,
                        layout collectionViewLayout: UICollectionViewLayout,
                        sizeForItemAt indexPath: IndexPath) -> CGSize {
        return collectionView == scrollListCollectionView ? NovelReadingAnchorDetailsVC.scrollListItemSize : CGSize(width: categoryList[indexPath.row].title.getStringSize(rectSize: .zero, font: font(16, .semibold)).width, height: NovelReadingAnchorDetailsVC.categoryBarCollectionViewHeight)
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let row = indexPath.row
        guard collectionView == scrollListCollectionView else {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "NovelReadingAnchorDetailsCategoryCell", for: indexPath) as! NovelReadingAnchorDetailsCategoryCell
            let isActive = activePageIndex == row
            cell.titleLabel.text = categoryList[row].title
            cell.titleLabel.textColor = isActive ? .white : rgb(0xDBDBDE)
            cell.titleLabel.font = isActive ? font(16, .semibold) : font(16)
            return cell
        }
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "NovelReadingAnchorDetailsItemCell\(row)", for: indexPath) as! NovelReadingAnchorDetailsItemCell
        cell.delegate = self
        cell.classId = categoryList[row].classId
        cell.anchorId = anchorinfo?.anchorId
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let row = indexPath.row
        guard collectionView == categoryBarCollectionView, activePageIndex != row else { return }
        activePageIndex = row
        isTapCategoryItem = true
        scrollListCollectionView.scrollToItem(at: indexPath, at: .centeredHorizontally, animated: true)
    }
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        switch scrollView {
        case scrollListCollectionView:
            let currentActivePageIndex = Int(round(scrollView.contentOffset.x / scrollView.frame.width))
            guard isTapCategoryItem else {
                guard activePageIndex != currentActivePageIndex else { return }
                activePageIndex = currentActivePageIndex
                refreshCategoryBarCollectionView(activePageIndex: currentActivePageIndex)
                return
            }
            guard currentActivePageIndex == activePageIndex else { return }
            refreshCategoryBarCollectionView(activePageIndex: currentActivePageIndex)
        case wrapperSrollView:
            wrapperSrollViewOffsetY = scrollView.contentOffset.y
        default:
            break
        }
    }
    
}

extension NovelReadingAnchorDetailsVC: NovelReadingAnchorDetailsItemCellDelegate {
    
    func switchParentScrollViewScrollEnabled(childScrollViewOffsetY: CGFloat) {
        let newOffsetYVal = childScrollViewOffsetY < 0 ? wrapperSrollViewScrollEnabledThresholdVal + childScrollViewOffsetY : wrapperSrollViewScrollEnabledThresholdVal
        guard newOffsetYVal != wrapperSrollViewOffsetY else { return }
        wrapperSrollView.setContentOffset(CGPoint(x: 0, y: newOffsetYVal), animated: true)
    }
    
}

extension NovelReadingAnchorDetailsVC: NovelReadingAnchorDetailsHeaderViewDelegate {
    
    func refreshTitleViewAttensionStatus() {
        guard let item = anchorinfo else { return }
        titleView.dataModel = item
    }
    
    func onOpenVipBtnTap() {
        PurchaseVipAlert.showPurchaseVipAlert()
    }
    
}
extension NovelReadingAnchorDetailsVC: NovelReadingAnchorDetailsTitleViewDelegate {
    
    func refreshHeaderViewAttensionStatus() {
        guard let item = anchorinfo else { return }
        headerView.dataModel = item
    }
    
}

