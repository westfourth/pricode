//
//  NovelReadingAnchorDetailsTitleView.swift
//  CaoLong
//
//  Created by mac on 2021/1/26.
//  Copyright © 2021 mac. All rights reserved.
//

import UIKit

protocol NovelReadingAnchorDetailsTitleViewDelegate: NSObjectProtocol {
    
    func refreshHeaderViewAttensionStatus()
    
}

class NovelReadingAnchorDetailsTitleView: UIView {
    
    private lazy var nicknameLabel: UILabel = {
        let label = UILabel()
        label.textColor = .white
        label.textAlignment = .center
        label.font = font(24, .semibold)
        return label
    }()
    
    private lazy var attentionBtn: UIButton = {
        let btn = UIButton()
        btn.setTitle("關注主播", for: .normal)
        btn.setTitleColor(rgb(0xB1B1B1), for: .normal)
        btn.titleLabel?.font = font(12)
        btn.setImage(NovelReadingAnchorDetailsHeaderView.attentionImg, for: .normal)
        btn.addTarget(self, action: #selector(onAttentionBtnTap), for: .touchUpInside)
        return btn
    }()
    
    weak var delegate: NovelReadingAnchorDetailsTitleViewDelegate?
    
    var dataModel: ReadingAnchorDetatilsItem? {
        didSet {
            guard let item = dataModel else { return }
            nicknameLabel.text = item.anchorName
            updateAttentionBtnStatus(isAttention: item.attention)
        }
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        alpha = 0
        layer.masksToBounds = true
        renderView()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func renderView() {
        addSubview(attentionBtn)
        addSubview(nicknameLabel)
        
        attentionBtn.snp.makeConstraints { (make) in
            make.top.bottom.equalToSuperview()
            if #available(iOS 14.0, *) {
                make.right.equalToSuperview().inset(10)
            } else {
                make.right.equalToSuperview()
            }
            make.width.equalTo(90)
        }
        
        nicknameLabel.snp.makeConstraints { (make) in
            make.top.bottom.equalToSuperview()
            if #available(iOS 14.0, *) {
                make.left.equalToSuperview().inset(50)
            } else {
                make.left.equalToSuperview().inset(68)
            }
            make.right.equalTo(attentionBtn.snp.left)
        }
        
        attentionBtn.imagePosition(imageStyle: .left, spacing: 7)
        
    }
    
    private func updateAttentionBtnStatus(isAttention: Bool) {
        attentionBtn.setTitle(isAttention ? "取消關注" : "關注主播", for: .normal)
        attentionBtn.setImage(isAttention ? NovelReadingAnchorDetailsHeaderView.attentionImg : NovelReadingAnchorDetailsHeaderView.attentionImg, for: .normal)
    }
    
    @objc private func onAttentionBtnTap() {
        guard let item = dataModel else { return }
        loading()
        let req = ReadingAnchorAttentionReq()
        req.anchorId = item.anchorId
        req.isAttention = !item.attention
        Session.request(req) { [weak self] (error, resp) in
            hideLoading()
            guard error == nil else {
                iToast(error!.localizedDescription)
                return
            }
            item.attention = req.isAttention
            item.attentionNum = max(0, item.attention ? item.attentionNum + 1 : item.attentionNum - 1)
            self?.updateAttentionBtnStatus(isAttention: req.isAttention)
            self?.delegate?.refreshHeaderViewAttensionStatus()
            iToast(req.isAttention ? "關注成功!" : "取消關注成功!", type: .succeed)
        }
    }
    
    func changeTitleViewStatus(changeValRate: CGFloat) {
        alpha = changeValRate
    }
    
}
