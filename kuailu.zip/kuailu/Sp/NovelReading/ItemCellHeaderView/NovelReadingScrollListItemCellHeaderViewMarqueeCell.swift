//
//  NovelReadingScrollListItemCellHeaderViewMarqueeCell.swift
//  CaoLong
//
//  Created by mac on 2021/2/3.
//  Copyright © 2021 mac. All rights reserved.
//

import UIKit

class NovelReadingScrollListItemCellHeaderViewMarqueeCell: UICollectionViewCell {
    
    lazy var titleLabel: UILabel = {
        let label = UILabel()
        label.font = UIScreen.main.bounds.width >= 414 ? font(14) : font(11)
        label.textColor = rgb(0x8A8A8A)
        return label
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        addSubview(titleLabel)
        titleLabel.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
