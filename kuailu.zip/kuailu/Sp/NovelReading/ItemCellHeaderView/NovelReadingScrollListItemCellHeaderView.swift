//
//  NovelReadingScrollListItemCellHeaderView.swift
//  CaoLong
//
//  Created by mac on 2021/1/25.
//  Copyright © 2021 mac. All rights reserved.
//

import UIKit

protocol NovelReadingScrollListItemCellHeaderViewDelegate: NSObjectProtocol {
    
    func onSearchBarTap()
    
    func onFilterBarTap()
    
}

class NovelReadingScrollListItemCellHeaderView: UIView {
    
    static let viewHeight: CGFloat = 33
    
    private static let horizontalMargin: CGFloat = 10
    
    private static let horizontalSearchAndFilterMargin: CGFloat = 10
    
    private static let searchWrapperViewWidth: CGFloat = {
        return UIScreen.main.bounds.width - NovelReadingScrollListItemCellHeaderView.horizontalMargin * 2 - NovelReadingScrollListItemCellHeaderView.filterWrapperViewWidth - NovelReadingScrollListItemCellHeaderView.horizontalSearchAndFilterMargin
    }()
    
    private static let filterWrapperViewWidth: CGFloat = 180
    
    private static let searchBtnHeight: CGFloat = 28
    
    private static let cornerRadius: CGFloat = {
        return  NovelReadingScrollListItemCellHeaderView.viewHeight / 2
    }()
    
    static let searchImg: UIImage? = {
        return UIImage(named: "novel_reading_search_icon")
    }()
    
    private static let filterImg: UIImage? = {
        return UIImage(named: "novel_reading_filter_icon")
    }()
    
    private lazy var searchImgView: UIImageView = {
        let imgView = UIImageView(image: NovelReadingScrollListItemCellHeaderView.searchImg)
        imgView.contentMode = .scaleAspectFit
        return imgView
    }()
    
    private lazy var searchBtnLabel: UILabel = {
        let label = UILabel()
        label.text = "搜索"
        label.backgroundColor = .white
        label.font = font(14)
        label.textColor = Color.theme_color
        label.textAlignment = .center
        label.layer.masksToBounds = true
        label.layer.cornerRadius = NovelReadingScrollListItemCellHeaderView.searchBtnHeight / 2
        return label
    }()
    
    private lazy var marqueeScrollView: CycleScrollView = {
        let cycleScrollView = CycleScrollView()
        cycleScrollView.delegate = self
        cycleScrollView.dataSource = self
        cycleScrollView.scrollDirection = .vertical
        cycleScrollView.hidesPageControl = true
        cycleScrollView.isAutoScroll = true
        cycleScrollView.allowsDragging = true
        cycleScrollView.autoScrollInterval = 3
        cycleScrollView.register(NovelReadingScrollListItemCellHeaderViewMarqueeCell.self, forCellWithReuseIdentifier: "NovelReadingScrollListItemCellHeaderViewMarqueeCell")
        return cycleScrollView
    }()
    
    
    private lazy var searchWrapperView: UIView = {
        let view = UIView()
        view.layer.masksToBounds = true
        view.layer.cornerRadius = NovelReadingScrollListItemCellHeaderView.cornerRadius
        view.backgroundColor = rgb(0x2A2B2C)
        view.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(onSearchBarTap)))
        view.isUserInteractionEnabled = true
        view.addSubview(searchImgView)
        view.addSubview(searchBtnLabel)
        view.addSubview(marqueeScrollView)
        
        searchImgView.snp.makeConstraints { (make) in
            make.left.equalToSuperview().inset(10)
            make.centerY.equalToSuperview()
            make.size.equalTo(14)
        }
        
        searchBtnLabel.snp.makeConstraints { (make) in
            make.right.equalToSuperview().inset(2)
            make.centerY.equalToSuperview()
            make.width.equalTo(60)
            make.height.equalTo(NovelReadingScrollListItemCellHeaderView.searchBtnHeight)
        }
        
        marqueeScrollView.snp.makeConstraints { (make) in
            make.left.equalTo(searchImgView.snp.right).offset(5)
            make.right.equalTo(searchBtnLabel.snp.left).offset(-5)
            make.top.bottom.equalToSuperview()
        }
        
        return view
    }()
    
    private lazy var filterNewLabel: UILabel = {
        let label = UILabel()
        label.text = "最新"
        label.font = font(14, .medium)
        label.textColor = .white
        return label
    }()
    
    private lazy var filterHotLabel: UILabel = {
        let label = UILabel()
        label.text = "最熱"
        label.font = font(14, .medium)
        label.textColor = .white
        return label
    }()
    
    private lazy var filterBtn: UIButton = {
        let btn = UIButton()
        btn.setTitle("篩選", for: .normal)
        btn.setTitleColor(.white, for: .normal)
        btn.titleLabel?.font = font(14, .medium)
        btn.setImage(NovelReadingScrollListItemCellHeaderView.filterImg, for: .normal)
        btn.isUserInteractionEnabled = false
        btn.imagePosition(imageStyle: .left, spacing: 5)
        return btn
    }()
    
    private lazy var filterWrapperView: UIView = {
        let view = UIView()
        view.layer.masksToBounds = true
        view.layer.cornerRadius = NovelReadingScrollListItemCellHeaderView.cornerRadius
        view.backgroundColor = Color.theme_color
        view.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(onFilterBarTap)))
        view.isUserInteractionEnabled = true
        view.addSubview(filterNewLabel)
        view.addSubview(filterHotLabel)
        view.addSubview(filterBtn)
        
        filterNewLabel.snp.makeConstraints { (make) in
            make.left.equalToSuperview().inset(16)
            make.top.bottom.equalToSuperview()
            make.width.equalTo(30)
        }
        
        filterHotLabel.snp.makeConstraints { (make) in
            make.left.equalTo(filterNewLabel.snp.right).offset(20)
            make.top.bottom.equalToSuperview()
            make.width.equalTo(30)
        }
        
        filterBtn.snp.makeConstraints { (make) in
            make.right.equalToSuperview().inset(16)
            make.top.bottom.equalToSuperview()
            make.width.equalTo(50)
        }
        
        return view
    }()
    
    private var listData: [NovelReadingHotSearchItem] = [] {
        didSet {
            marqueeScrollView.reloadData()
        }
    }
    
    private var initState: Bool = true
    
    var type: NovelReadingType = .novel {
        didSet {
            guard initState else { return }
            initState = false
            getList()
        }
    }
    
    weak var delegate: NovelReadingScrollListItemCellHeaderViewDelegate?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        renderView()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func renderView() {
        addSubview(searchWrapperView)
        addSubview(filterWrapperView)
        
        searchWrapperView.snp.makeConstraints { (make) in
            make.left.equalToSuperview().inset(NovelReadingScrollListItemCellHeaderView.horizontalMargin)
            make.top.bottom.equalToSuperview()
            make.width.equalTo(NovelReadingScrollListItemCellHeaderView.searchWrapperViewWidth)
        }
        
        filterWrapperView.snp.makeConstraints { (make) in
            make.right.equalToSuperview().inset(NovelReadingScrollListItemCellHeaderView.horizontalMargin)
            make.top.bottom.equalToSuperview()
            make.width.equalTo(NovelReadingScrollListItemCellHeaderView.filterWrapperViewWidth)
        }
    }
    
    private func getList() {
        let req = NovelReadingHotSearchListAllListReq()
        req.fictionType = type == .novel ? 1 : 2
        req.pageSize = 30
        Session.request(req) { [weak self] (error, resp) in
            guard let `self` = self, error == nil, let resData = resp as? [NovelReadingHotSearchItem], !resData.isEmpty else { return }
            self.listData = resData
        }
    }
    
    @objc private func onSearchBarTap() {
        delegate?.onSearchBarTap()
    }
    
    @objc private func onFilterBarTap() {
        delegate?.onFilterBarTap()
    }
    
}

extension NovelReadingScrollListItemCellHeaderView: CycleScrollViewDataSource {
    
    func numberOfItems(in cycleScrollView: CycleScrollView) -> Int {
        return listData.count
    }
    
    func cycleScrollView(_ cycleScrollView: CycleScrollView, cellForItemAt index: Int) -> UICollectionViewCell {
        let cell = cycleScrollView.dequeueReusableCell(withReuseIdentifier: "NovelReadingScrollListItemCellHeaderViewMarqueeCell", for: index) as! NovelReadingScrollListItemCellHeaderViewMarqueeCell
        cell.titleLabel.text = listData[index].fictionTitle
        return cell
    }
}

extension NovelReadingScrollListItemCellHeaderView: CycleScrollViewDelegate {
    
    func cycleScrollView(_ cycleScrollView: CycleScrollView, didSelectItemAt index: Int) {
        
    }
    
}
