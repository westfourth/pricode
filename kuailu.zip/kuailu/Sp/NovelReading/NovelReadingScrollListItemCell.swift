//
//  NovelReadingScrollListItemCell.swift
//  CaoLong
//
//  Created by mac on 2021/1/25.
//  Copyright © 2021 mac. All rights reserved.
//

import UIKit

class NovelReadingScrollListItemCell: UICollectionViewCell {
    
    private static let scrollToTopImg: UIImage? = {
        return UIImage(named: "discovery_tag_video_top_icon")
    }()
    
    private static let marginTop: CGFloat = 20
    
    private static let categoryBarCollectionViewMarginTop: CGFloat = 10
    
    private static let categoryBarCollectionViewHeight: CGFloat = 30
    
    private static let tableViewMarginTop: CGFloat = 10
    
    private static let categoryBarLineSpacing: CGFloat = 20
    
    private static let categoryReadingDefaultList: [NovelReadingClassifyItem] = {
        let categoryDefaultNameList: [String] = ["推薦", "主播"]
        var tempList: [NovelReadingClassifyItem] = []
        for i in 0..<categoryDefaultNameList.count {
            let novelReadingClassifyItem = NovelReadingClassifyItem()
            novelReadingClassifyItem.title = categoryDefaultNameList[i]
            novelReadingClassifyItem.readingClassifyType = ReadingClassifyType(rawValue: i) ?? .recommend
            tempList.append(novelReadingClassifyItem)
        }
        return tempList
    }()
    
    private static let categoryNovelDefaultList: [NovelReadingClassifyItem] = {
        let categoryDefaultNameList: [String] = ["全部"]
        var tempList: [NovelReadingClassifyItem] = []
        for i in 0..<categoryDefaultNameList.count {
            let novelReadingClassifyItem = NovelReadingClassifyItem()
            novelReadingClassifyItem.title = categoryDefaultNameList[i]
            tempList.append(novelReadingClassifyItem)
        }
        return tempList
    }()
    
    private static let tableViewHeight: CGFloat = {
        return UIScreen.main.bounds.height - MARGIN_TOP - NovelReadingScrollListItemCell.marginTop - NovelReadingScrollListItemCellHeaderView.viewHeight - NovelReadingScrollListItemCell.categoryBarCollectionViewMarginTop - NovelReadingScrollListItemCell.categoryBarCollectionViewHeight - NovelReadingScrollListItemCell.tableViewMarginTop
    }()
    
    private lazy var headerView: NovelReadingScrollListItemCellHeaderView = {
        let headerView = NovelReadingScrollListItemCellHeaderView()
        headerView.delegate = self
        return headerView
    }()
    
    private lazy var categoryBarCollectionView: UICollectionView = {
        let layout = UICollectionViewFlowLayout()
        layout.minimumLineSpacing =  NovelReadingScrollListItemCell.categoryBarLineSpacing
        layout.minimumInteritemSpacing = layout.minimumLineSpacing
        layout.scrollDirection = .horizontal
        let cv = UICollectionView(frame: .zero, collectionViewLayout: layout)
        cv.register(NovelReadingScrollListItemCategoryCell.self, forCellWithReuseIdentifier: "NovelReadingScrollListItemCategoryCell")
        cv.contentInset = UIEdgeInsets(top: 0, left: 10, bottom: 0, right: 10)
        cv.showsVerticalScrollIndicator = false
        cv.showsHorizontalScrollIndicator = false
        cv.contentInsetAdjustmentBehavior = .never
        cv.bouncesZoom = false
        cv.backgroundColor = .none
        cv.delegate = self
        cv.dataSource = self
        return cv
    }()
    
    private lazy var footerView: NovelReadingReadingRecomHotSearchListFooterView = {
        return NovelReadingReadingRecomHotSearchListFooterView()
    }()
    
    private lazy var scrollToTopBtn: UIButton = {
        let btn = UIButton()
        btn.setBackgroundImage(NovelReadingScrollListItemCell.scrollToTopImg, for: .normal)
        btn.addTarget(self, action: #selector(onScrollToTopBtn), for: .touchUpInside)
        btn.isHidden = true
        return btn
    }()
    
    private var tableView: UITableView?
    
    private var categoryList: [NovelReadingClassifyItem] = [] {
        didSet {
            categoryBarCollectionView.reloadData()
        }
    }
    
    private var commonlistData: [NovelReadingItem] = []
    
    private var readingRecomListData: [ReadingRecomListItem] = []
    
    private var readingAnchorListData: [ReadingAnchorDetatilsItem] = []
    
    private var isInitState: Bool = true
    
    private var isGetListState: Bool = false
    
    private var isShowLoading: Bool = true
    
    private var isGetRecommendList: Bool = false
    
    private var pageNum: Int = 1
    
    private var activePageIndex: Int = 0 {
        didSet {
            if type == .reading {
                readingClassifyType = categoryList[activePageIndex].readingClassifyType
            }
            initTableView()
            scrollToTopBtn.isHidden = true
            getList(isRefresh: true, isArtificial: false)
        }
    }
    
    private var readingClassifyType: ReadingClassifyType = .recommend
    
    var type: NovelReadingType = .novel {
        didSet {
            guard isInitState else { return }
            isInitState = false
            headerView.type = type
            categoryList = type == .novel ? NovelReadingScrollListItemCell.categoryNovelDefaultList : NovelReadingScrollListItemCell.categoryReadingDefaultList
            activePageIndex = 0
            getCategoryList()
        }
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        renderView()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func renderView() {
        contentView.addSubview(headerView)
        contentView.addSubview(categoryBarCollectionView)
        addSubview(scrollToTopBtn)
        
        headerView.snp.makeConstraints { (make) in
            make.top.equalToSuperview().inset(NovelReadingScrollListItemCell.marginTop)
            make.left.right.equalToSuperview()
            make.height.equalTo(NovelReadingScrollListItemCellHeaderView.viewHeight)
        }
        
        categoryBarCollectionView.snp.makeConstraints { (make) in
            make.top.equalTo(headerView.snp.bottom).offset(NovelReadingScrollListItemCell.categoryBarCollectionViewMarginTop)
            make.left.right.equalToSuperview()
            make.height.equalTo(NovelReadingScrollListItemCell.categoryBarCollectionViewHeight)
        }
        
        scrollToTopBtn.snp.makeConstraints { (make) in
            make.right.equalToSuperview().inset(10)
            make.bottom.equalToSuperview().inset(230)
            make.size.equalTo(42)
        }
        
    }
    
    private func getCategoryList() {
        let req = NovelReadingClassifyListReq()
        req.fictionType = type == .novel ? 1 : 2
        Session.request(req) { [weak self] (error, resp) in
            guard let `self` = self else { return }
            guard error == nil, let resData = resp as? [NovelReadingClassifyItem], !resData.isEmpty else { return }
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.4) { [weak self] in
                self?.categoryList += resData
            }
        }
    }
    
    private func getList(isRefresh: Bool, isArtificial: Bool) {
        guard !isGetListState else { return }
        isGetListState = true
        if isShowLoading {
            loading()
        }
        switch type {
        case .novel:
            getReadingCommonListOrNovelList(isRefresh: isRefresh, isArtificial: isArtificial)
        case .reading:
            switch readingClassifyType {
            case .common:
                getReadingCommonListOrNovelList(isRefresh: isRefresh, isArtificial: isArtificial)
            case .anchor:
                getReadingAnchorList(isRefresh: isRefresh, isArtificial: isArtificial)
            case .recommend:
                getReadingRecommendList(isRefresh: isRefresh, isArtificial: isArtificial)
            }
        }
    }
    
    private func getReadingCommonListOrNovelList(isRefresh: Bool, isArtificial: Bool) {
        tableView?.state = !isRefresh ? .loading : .normal
        if isRefresh {
            pageNum = 1
            tableView?.mj_footer?.resetNoMoreData()
        }
        let req = NovelReadingAccordingToClassifySubListReq()
        req.classId = categoryList[activePageIndex].classId
        req.fictionType = type == .novel ? 1 : 2
        req.page = isRefresh ? 1 : pageNum + 1
        Session.request(req) { [weak self] (error, resp) in
            guard let `self` = self else { return }
            self.isGetListState = false
            if self.isShowLoading {
                hideLoading()
            }
            isRefresh ? self.tableView?.mj_header?.endRefreshing() : self.tableView?.mj_footer?.endRefreshing()
            guard error == nil, let resData = resp as? [NovelReadingItem] else {
                self.handleListException(isRefresh: isRefresh ,isArtificial: isArtificial)
                return
            }
            self.pageNum = req.page
            self.commonlistData = isRefresh ? resData : self.commonlistData + resData
            if isRefresh, !isArtificial {
                self.initTableView()
            }
            let isEmpty = self.commonlistData.isEmpty
            self.tableView?.state = isEmpty ? .empty : .normal
            self.tableView?.mj_footer?.isHidden = isEmpty
            self.tableView?.reloadData()
            if resData.count < req.pageSize {
                DispatchQueue.main.async {
                    self.tableView?.mj_footer?.endRefreshingWithNoMoreData()
                }
            }
        }
    }
    
    private func getReadingAnchorList(isRefresh: Bool, isArtificial: Bool) {
        tableView?.state = !isRefresh ? .loading : .normal
        if isRefresh {
            tableView?.mj_footer?.resetNoMoreData()
        }
        let req = ReadingAnchorListReq()
        req.lastId = isRefresh ? 0 : readingAnchorListData.last?.anchorId ?? 0
        Session.request(req) { [weak self] (error, resp) in
            guard let `self` = self else { return }
            self.isGetListState = false
            if self.isShowLoading {
                hideLoading()
            }
            isRefresh ? self.tableView?.mj_header?.endRefreshing() : self.tableView?.mj_footer?.endRefreshing()
            guard error == nil, let resData = resp as? [ReadingAnchorDetatilsItem] else {
                self.handleListException(isRefresh: isRefresh ,isArtificial: isArtificial)
                return
            }
            self.readingAnchorListData = isRefresh ? resData : self.readingAnchorListData + resData
            if isRefresh, !isArtificial {
                self.initTableView()
            }
            let isEmpty = self.readingAnchorListData.isEmpty
            self.tableView?.state = isEmpty ? .empty : .normal
            self.tableView?.mj_footer?.isHidden = isEmpty
            self.tableView?.reloadData()
            if resData.count < req.pageSize {
                DispatchQueue.main.async {
                    self.tableView?.mj_footer?.endRefreshingWithNoMoreData()
                }
            }
        }
    }
    
    private func getReadingRecommendList(isRefresh: Bool, isArtificial: Bool) {
        tableView?.state = !isRefresh ? .loading : .normal
        Session.request(ReadingRecomListReq()) { [weak self] (error, resp) in
            self?.tableView?.mj_header?.endRefreshing()
            guard let `self` = self else { return }
            self.isGetListState = false
            if self.isShowLoading {
                hideLoading()
            }
            guard error == nil, let resData = resp as? [ReadingRecomListItem] else {
                self.isGetRecommendList = true
                self.readingRecomListData = []
                self.initTableView()
                self.tableView?.reloadData()
                self.tableView?.state = .failed
                return
            }
            self.isGetRecommendList = true
            self.readingRecomListData = resData
            if isRefresh, !isArtificial {
                self.initTableView()
            }
            self.tableView?.state = resData.isEmpty ? .empty : .normal
            self.tableView?.reloadData()
        }
    }
    
    private func initTableView() {
        let tableView = getNewTableView()
        registerTableViewCell(tableView: tableView)
        self.tableView?.removeFromSuperview()
        self.tableView = tableView
        insertSubview(tableView, belowSubview: scrollToTopBtn)
        tableView.snp.makeConstraints { (make) in
            make.top.equalTo(categoryBarCollectionView.snp.bottom).offset(NovelReadingScrollListItemCell.tableViewMarginTop)
            make.left.right.equalToSuperview()
            make.height.equalTo(NovelReadingScrollListItemCell.tableViewHeight)
        }
    }
    
    private func registerTableViewCell(tableView: UITableView) {
        tableView.mj_header = getCommonMJHeader(refreshingTarget: self, headerRefreshCallback: #selector(onRefresh))
        if type == .novel || readingClassifyType != .recommend {
            tableView.mj_footer = getCommonMJFooter(refreshingTarget: self, footerRefreshCallback: #selector(onLoad))
        }
        switch type {
        case .novel:
            tableView.rowHeight = NovelReadingCommonNovelCell.viewHeight
            tableView.register(NovelReadingCommonNovelCell.self, forCellReuseIdentifier: "NovelReadingCommonNovelCell")
        case .reading:
            switch readingClassifyType {
            case .recommend:
                tableView.rowHeight = NovelReadingScrollListReadingRecomCell.viewHeight
                for i in 0..<readingRecomListData.count {
                    tableView.register(NovelReadingScrollListReadingRecomCell.self, forCellReuseIdentifier: "NovelReadingScrollListReadingRecomCell\(i)")
                }
            case .anchor:
                tableView.rowHeight = NovelReadingScrollListReadingAnchorCell.viewHeight
                tableView.register(NovelReadingScrollListReadingAnchorCell.self, forCellReuseIdentifier: "NovelReadingScrollListReadingAnchorCell")
            case .common:
                tableView.rowHeight = NovelReadingCommonReadingCell.viewHeight
                tableView.register(NovelReadingCommonReadingCell.self, forCellReuseIdentifier: "NovelReadingCommonReadingCell")
            }
        }
        tableView.estimatedRowHeight = tableView.rowHeight
    }
    
    private func getNewTableView() -> UITableView {
        let newTableView = UITableView(frame: .zero, style: .grouped)
        newTableView.delegate = self
        newTableView.dataSource = self
        newTableView.backgroundColor = .none
        newTableView.separatorStyle = .none
        newTableView.bouncesZoom = false
        newTableView.isDirectionalLockEnabled = true
        newTableView.showsHorizontalScrollIndicator = false
        newTableView.contentInsetAdjustmentBehavior = .never
        return newTableView
    }
    
    private func handleListException(isRefresh: Bool ,isArtificial: Bool) {
        if isRefresh {
            if !isArtificial {
                self.initTableView()
            }
            if type == .novel || readingClassifyType == .common {
                commonlistData = []
            } else {
                readingAnchorListData = []
            }
            tableView?.state = .failed
            tableView?.mj_footer?.isHidden = true
            tableView?.reloadData()
        } else {
            tableView?.state = .normal
            tableView?.mj_footer?.endRefreshingWithNoMoreData()
            tableView?.mj_footer?.isHidden = false
        }
    }
    
    @objc private func onRefresh() {
        isShowLoading = false
        getList(isRefresh: true, isArtificial: true)
    }
    
    @objc private func onLoad() {
        isShowLoading = false
        getList(isRefresh: false, isArtificial: true)
    }
    
    @objc private func onScrollToTopBtn() {
        guard !isListDataEmpty() else { return }
        tableView?.scrollToRow(at: IndexPath(row: 0, section: 0), at: .top, animated: true)
    }
    
    private func isListDataEmpty() ->Bool {
        switch type {
        case .novel:
            return commonlistData.isEmpty
        case .reading:
            switch readingClassifyType {
            case .common:
                return commonlistData.isEmpty
            case .anchor:
                return readingAnchorListData.isEmpty
            case .recommend:
                return readingRecomListData.isEmpty
            }
        }
    }
    
}

extension  NovelReadingScrollListItemCell: UICollectionViewDataSource, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int)
    -> Int {
        return categoryList.count
    }
    
    func collectionView(_ collectionView: UICollectionView,
                        layout collectionViewLayout: UICollectionViewLayout,
                        sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: categoryList[indexPath.row].title.getStringSize(rectSize: .zero, font: font(14, .medium)).width, height: NovelReadingScrollListItemCell.categoryBarCollectionViewHeight)
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let row = indexPath.row
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "NovelReadingScrollListItemCategoryCell", for: indexPath) as! NovelReadingScrollListItemCategoryCell
        cell.titleLabel.text = categoryList[row].title
        let isActive = activePageIndex == row
        cell.titleLabel.textColor = isActive ? Color.theme_color : rgb(0xC2C2C2)
        cell.titleLabel.font = isActive ? font(14, .medium) : font(14)
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let row = indexPath.row
        guard collectionView == categoryBarCollectionView, activePageIndex != row else { return }
        isShowLoading = true
        activePageIndex = row
        categoryBarCollectionView.scrollToItem(at: indexPath, at: .centeredHorizontally, animated: true)
        categoryBarCollectionView.reloadData()
    }
    
}

extension NovelReadingScrollListItemCell: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        switch type {
        case .novel:
            return commonlistData.count
        case .reading:
            switch readingClassifyType {
            case .common:
                return commonlistData.count
            case .recommend:
                return readingRecomListData.count
            case .anchor:
                return readingAnchorListData.count
            }
        }
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return .leastNonzeroMagnitude
    }
    
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return type == .reading && readingClassifyType == .recommend && isGetRecommendList ? NovelReadingReadingRecomHotSearchListFooterView.viewHeight : .leastNonzeroMagnitude
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        return nil
    }
    
    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        return type == .reading && readingClassifyType == .recommend && isGetRecommendList ? footerView : nil
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let row = indexPath.row
        switch type {
        case .novel:
            let cell = tableView.dequeueReusableCell(withIdentifier: "NovelReadingCommonNovelCell", for: indexPath) as! NovelReadingCommonNovelCell
            cell.dataModel = commonlistData[row]
            return cell
        case .reading:
            switch readingClassifyType {
            case .common:
                let cell = tableView.dequeueReusableCell(withIdentifier: "NovelReadingCommonReadingCell", for: indexPath) as! NovelReadingCommonReadingCell
                cell.dataModel = commonlistData[row]
                return cell
            case .anchor:
                let cell = tableView.dequeueReusableCell(withIdentifier: "NovelReadingScrollListReadingAnchorCell", for: indexPath) as! NovelReadingScrollListReadingAnchorCell
                cell.dataModel = readingAnchorListData[row]
                return cell
            case .recommend:
                let cell = tableView.dequeueReusableCell(withIdentifier: "NovelReadingScrollListReadingRecomCell\(row)", for: indexPath) as! NovelReadingScrollListReadingRecomCell
                cell.dataModel = readingRecomListData[row]
                return cell
            }
        }
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let row = indexPath.row
        switch type {
        case .novel:
            NovelReadingVC.navigationToTextNovelDetailVC(fictionId: commonlistData[row].fictionId)
        case .reading:
            switch readingClassifyType {
            case .common:
                NovelReadingVC.navigationToAudioNovelDetailVC(fictionId: commonlistData[row].fictionId)
            case .recommend, .anchor:
                break
            }
        }
    }
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        scrollToTopBtn.isHidden = isListDataEmpty() || scrollView.contentOffset.y < height
    }
    
}

extension NovelReadingScrollListItemCell: NovelReadingScrollListItemCellHeaderViewDelegate {
    
    func onSearchBarTap() {
        guard let navigationController = (UIApplication.shared.delegate as? AppDelegate)?.currentNavigationController else { return }
        let novelReadingSearchVC = NovelReadingSearchVC()
        novelReadingSearchVC.type = type
        navigationController.show(novelReadingSearchVC, sender: nil)
    }
    
    func onFilterBarTap() {
        guard let navigationController = (UIApplication.shared.delegate as? AppDelegate)?.currentNavigationController else { return }
        let novelReadingFilterVC = NovelReadingFilterVC()
        novelReadingFilterVC.type = type
        navigationController.show(novelReadingFilterVC, sender: nil)
    }
    
}
