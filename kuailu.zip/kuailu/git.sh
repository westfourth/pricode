#!/bin/bash

git init
git remote add origin git@192.168.1.77:ios/kuailu.git
git add .
git commit -m "Initial commit"
git push -u origin master
